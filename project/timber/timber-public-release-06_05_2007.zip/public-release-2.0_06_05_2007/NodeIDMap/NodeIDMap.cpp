/*
COPYRIGHT  (c) 2000-2004 
THE REGENTS OF THE UNIVERSITY OF MICHIGAN
ALL RIGHTS RESERVED

PERMISSION IS GRANTED TO USE, COPY, CREATE DERIVATIVE WORKS AND
REDISTRIBUTE THIS SOFTWARE AND SUCH DERIVATIVE WORKS FOR NONCOMMERCIAL
EDUCATION AND RESEARCH PURPOSES, SO LONG AS NO FEE IS CHARGED, AND SO LONG
AS THE COPYRIGHT NOTICE ABOVE, THIS GRANT OF PERMISSION, AND THE
DISCLAIMER BELOW APPEAR IN ALL COPIES MADE; AND SO LONG AS THE NAME OF THE
UNIVERSITY OF MICHIGAN IS NOT USED IN ANY ADVERTISING OR PUBLICITY
PERTAINING TO THE USE OR DISTRIBUTION OF THIS SOFTWARE WITHOUT SPECIFIC,
WRITTEN PRIOR AUTHORIZATION.

THIS SOFTWARE IS PROVIDED AS IS, WITHOUT REPRESENTATION FROM THE
UNIVERSITY OF MICHIGAN AS TO ITS FITNESS FOR ANY PURPOSE, AND WITHOUT
WARRANTY BY THE UNIVERSITY OF MICHIGAN OF ANY KIND, EITHER EXPRESS OR
IMPLIED, INCLUDING WITHOUT LIMITATION THE IMPLIED WARRANTIES OF
MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE. THE REGENTS OF THE
UNIVERSITY OF MICHIGAN SHALL NOT BE LIABLE FOR ANY DAMAGES, INCLUDING
SPECIAL, INDIRECT, INCIDENTAL, OR CONSEQUENTIAL DAMAGES, WITH RESPECT TO
ANY CLAIM ARISING OUT OF OR IN CONNECTION WITH THE USE OF THE SOFTWARE,
EVEN IF IT HAS BEEN OR IS HEREAFTER ADVISED OF THE POSSIBILITY OF SUCH
DAMAGES.
*/

/**
 * @author Yuqing (Melanie) Wu
 */

#pragma warning(disable: 4702)
#include "NodeIDMap.h"

/**
* class NodeIDMap
* 
* NodeIDMap acts as a buffer in timber. It keeps the nodes that have been bought from the disk for later fetching and
* controls the number/size of nodes in memory.
* 
* Currently, the replacement policy implemented is LRU. A doubly linked list is used to keep the LRU order of
* the nodes, according to the time when the node is fetched/accessed. 
*
* A map is used to map the key of a node to a pointer that point to the in-memory locate where the content of the node is. 
* This is used to achieve fast key-based access.
* 
* @see NodeIDMapItem
* @see DataMng
* @see DoublyLinkedList
*/

/**
* Constructor
* 
* Initialize the NodeIDMap with the the management choices, including how the capacity is measured
* and how the replacement is to be done. 
* 
* @param capacityChoice The choice on how the capacity of the NodeIDMap is measured, by the number of nodes or the size of nodes.
* @param capacity The capacity of the NodeIDMap, in node count (for NODE_NUMBER_CAPACITY) and in bytes for (BUFFER_SIZE_CAPACITY).
* @param rpPolicy The choice of the replacement policy (The one currently implemented is LRU).
* @param LRURemove The ratio of nodes to be removed on one LRU replacement. A number between 0 and 1. 
* 
* For each of these parameters, if the value given is less than 0, the default value will be used. 
*/

NodeIDMap::NodeIDMap(int capacityChoice,
					 int capacity, 	
					 int rpPolicy, 
					 float LRURemove)
{
	// capacityyChoice
	this->capacityChoice = capacityChoice;
	if (this->capacityChoice < 0)
		this->capacityChoice = NODE_NUMBER_CAPACITY;

	// capacity
	this->capacity = capacity;
	if (this->capacity < 0)
	{
		switch (this->capacityChoice)
		{
		case NODE_NUMBER_CAPACITY:
			this->capacity = gSettings->getIntegerValue("DEFAULT_NODE_NUM_CAPACITY",100000);
			break;
		case BUFFER_SIZE_CAPACITY:
			this->capacity = gSettings->getIntegerValue("DEFAULT_SIZE_CAPACITY",100000000);
			break;
		default:
			globalErrorInfo.insertProblem(ERR_TYPE_WARNING,__LINE__,"NodeIDMap",__FILE__,"Warning: not value capacity choice");
			break;
		}
	}

	// replacementPolicy
	this->replacementPolicy = rpPolicy;
	if (this->replacementPolicy < 0)
		this->replacementPolicy = REPLACEMENT_POLICY_LRU;

	// remove rate
	this->LRURemovePercentage = LRURemove;
	if (this->LRURemovePercentage < 0)
		this->LRURemovePercentage = (float)gSettings->getDoubleValue("DEFAULT_LRU_REMOVE_RATE",0.30);
	
	this->crtSize = 0;

#ifdef DEBUG_NODEIDMAP
	{
		cout <<"NodeIDMap parameters" << endl;
		cout <<"capacitychoice: " <<  this->capacityChoice << endl;
		cout <<"capacity: " << this->capacity << endl;
		cout <<"replacementPolicy: " << this->replacementPolicy << endl;
		cout <<"LRURemovePercentage: " << this->LRURemovePercentage << endl;
	}
#endif

	// initialize the key map
	this->keyMap = new KeyItemMapType;

	// initialize the doubly linked list
	this->dList = new DoublyLinkedList();

	// initialize the varialbes for statistics
	this->crtSizeRequirement = 0;
	this->peakSizeRequirement = 0;
	this->replacementTimes = 0;

}

/**
* Destructor
* Release the keyMap and the doubly-linked list
*/
NodeIDMap::~NodeIDMap(void)
{
	delete this->keyMap;
	delete this->dList;
}

/**
* Process Method
* Given the node key, get the node from NodeIDMap, return NULL if it is not in there.
* 
* @param key The key of the node to be looked for
* @returns The node with the given key, NULL if the node is not in the NodeIDMap
*/
DM_DataNode* NodeIDMap::getNode(KeyType key)
{
	DM_DataNode* node;

	// find the node in the keyMap
	KeyItemMapType::iterator mapItem = this->keyMap->find(key);

	if (mapItem == this->keyMap->end())
		// if no such node is found, return NULL
		node = NULL;
	else
	{

#ifdef DEBUG_NODEIDMAP
		cout <<"getnode from NodeIDMap" << endl;
#endif

		// get the node from the map item 
		NodeIDMapItem* item = mapItem->second;
		node = item->getMMLink();

#ifdef DEBUG_NODEIDMAP
		{
			cout <<"before moving a node to the tail of the list" << endl;
			this->dList->printContent();
		}
#endif

		// move the node to the tail of the doubly linked list, since it is just visited
		this->dList->moveToTail(item);
	
#ifdef DEBUG_NODEIDMAP
		{
			cout <<"after moving a node to the tail of the list" << endl;
			this->dList->printContent();
		}
#endif

	}

	return node;
}

/**
* Process Method
* Remove a node from the NodeIDMap
*
* @param key The key of the node  to be removed.
*/

void NodeIDMap::deleteNode(KeyType key)
{
	// find the node in the keyMap
	KeyItemMapType::iterator mapItem = this->keyMap->find(key);
	if (mapItem == this->keyMap->end())
	{
		// if the node is not in NodeIDMap, do nothing and return. 
		return;
	}
	else
	{
		// if the node is found in NodeIDMap, erase it. 
		//		(decrease the buffer size and the size count for the time stamp)

		NodeIDMapItem* item = mapItem->second;

		int nodeSize = item->getSize();
		if (this->capacityChoice == NODE_NUMBER_CAPACITY)
		{
			this->crtSize --;
			this->crtSizeRequirement --;
		}
		else 
		{
			this->crtSize -= nodeSize;
			this->crtSizeRequirement -= nodeSize;
		}

		// remove the item from the keymap
		this->keyMap->erase(mapItem);

		// remove the item from the doubly linked list
		this->dList->deleteItem(item);

		// delete the node
		delete item;
	}
}

/**
* Process Method
* Insert a node to the NodeIDMap.  
* It may cause timestamp increase (if the current timestamp already has a certain number of nodes
* It may also cause buffer replacement, if the buffer is full.
* 
* @param pNode The point to the node to be inserted to the NodeIDMap
*/

void NodeIDMap::insertNode(DM_DataNode* pNode)
{
	// fine out whether the buffer is full
	int nodeSize = 0;
	if (this->capacityChoice == BUFFER_SIZE_CAPACITY)
		nodeSize = pNode->getNodeSize();
	bool bufferFull = this->bufferIsFull(nodeSize);
	
	// if it is full, call buffer replacement method to remove some nodes from the NodeIDMap
	if (bufferFull)
	{
#ifdef DEBUG_NODEIDMAP
		{
			cout <<"before buffer replacement" << endl;
			this->printContent();
		}
#endif

		bufferReplacement();

#ifdef DEBUG_NODEIDMAP
		{
			cout <<"after buffer replacement" << endl;
			this->printContent();
		}
#endif
	}

	// then, it is for sure the new node can fit in the buffer, insert it
	
	KeyType key = pNode->getKey();
	NodeIDMapItem* item = new NodeIDMapItem(key, pNode, nodeSize);

	// insert the item to the doubly linked list
	this->dList->insertAtTail(item);

	// insert the item to the key map
	this->keyMap->insert(KeyItemMapType::value_type(key, item));

	// maintain the buffet size statistics
	if (this->capacityChoice == NODE_NUMBER_CAPACITY)
	{
		this->crtSize++;
		this->crtSizeRequirement++;
	}
	else 
	{
		this->crtSize += nodeSize;
		this->crtSizeRequirement += nodeSize;
	}

	if (this->crtSizeRequirement > this->peakSizeRequirement)
		this->peakSizeRequirement = this->crtSizeRequirement;

}

/**
* Process Method
* Check whether the buffer is full after a new node is in. 
* 
* Whether the buffer is full depends on the capacity choice (how the size is messured) and the
* actual space taken by the nodes. 
*
* @param nodeSize The size of the node to be inserted to the buffer. 
* @returns A  boolean value which indicate whether the buffer will be full after the node is in. 
*/

bool NodeIDMap::bufferIsFull(int nodeSize)
{
	bool full;

	// whether the buffer is full depends on the capacity choice (how the size is messured) and the
	// actual space taken by the nodes. 
	
	switch (this->capacityChoice)
	{
	case NODE_NUMBER_CAPACITY:
		{
			// count the number of nodes
			if (this->crtSize == this->capacity)
				full = true;
			else full = false;
		}
		break;

	case BUFFER_SIZE_CAPACITY:
		{
			// check the accumulated size of the nodes. 
			if (this->crtSize + nodeSize > this->capacity)
				full = true;
			else full = false;
		}
		break;

	default:
		char msg[100];
		sprintf(msg, "Warning: %s is not valid capacity choice", this->capacityChoice);		
		globalErrorInfo.insertProblem(ERR_TYPE_WARNING,__LINE__,"NodeIDMap",__FILE__,msg);
		full = true;
		break;
	}

	return full;
}


/**
* Process Method
* Handles buffer replacement
* 
* The currently implemented replacement strategy is LRU. Instead of replace nodes one at a time, I choose
* to swap out a portion of  the buffer (given by the replacement rate) when the buffer is full. 
*/

void NodeIDMap::bufferReplacement()
{
	// find out the desired remove size, based on the capacity and the LRURemovePercentage.
	int desiredRemoveSize = (int) ((float) this->capacity * this->LRURemovePercentage);
	int accumulatedRemoveSize = 0;

	// continuously remove nodes from the head of the LRU list, untill the desiredRemoveSize is met. 
	while (accumulatedRemoveSize < desiredRemoveSize)
	{
		// remove an item from the head of the doubly linked list
		NodeIDMapItem* item = this->dList->deleteAtHead();

		// remove the item from map
		int nodeSize = item->getSize();
		KeyType nodekey = item->getKey();
		this->keyMap->erase(nodekey);

		// free space
		delete item;

		// maintain buffer size statistics
		if (this->capacityChoice == NODE_NUMBER_CAPACITY)
		{
			this->crtSize --;
			accumulatedRemoveSize++;
		}
		else
		{
			this->crtSize -= nodeSize;
			accumulatedRemoveSize += nodeSize;
		}
	}

	// this is for the NodeIDMap statistics
	this->replacementTimes ++;
}

/** 
* Process Method
* 
* Get a list of nodes within the key range. The nodes picked are put in nodelist.
* 
* @param start/end The boundary of the nodes to be picked.
* @param nodelist A list that is prepared to hold the nodes. Nodes that are picked will be put into the list as return value. 
* @param listLen The length of the list. This gives the boundary of the number of list to be picked at a time. 
* @returns The number of nodes picked, upto listLen. 
*/

int NodeIDMap::getNodesInRange(KeyType start,
							   KeyType end, 
							   DM_DataNode** nodelist, 
							   int listLen)
{
	int count = 0;

	// start to scan the key map from the key at the start of the range. 
	
	KeyItemMapType::iterator nodeItem = this->keyMap->find(start);

	// putting nodes into the list, until the scan run out of the range, or the list is used up. 
	while ((nodeItem != this->keyMap->end()) && (count < listLen))
	{
		KeyType key = nodeItem->first;
		if (key < end)
		{
			nodelist[count] = nodeItem->second->getMMLink();
			count++;
		}
		else break;
		nodeItem++;
	}
	return count;
}

/**
* Debug Method
* Print the content of the NodeIDMap
*/
void NodeIDMap::printContent()
{
	cout <<"\n\n-------------------------------------------------" << endl;
	cout <<"NodeIDMap parameters" << endl;
	cout <<"capacitychoice: " << this->capacityChoice << endl;
	cout <<"capacity: " << this->capacity << endl;
	cout <<"replacementPolicy: " << this->replacementPolicy << endl;
	cout <<"LRURemovePercentage: " << this->LRURemovePercentage << endl;

	cout <<"\nnodes:" << endl;
	KeyItemMapType::iterator nodeItem = this->keyMap->begin();
	while (nodeItem != this->keyMap->end())
	{
		KeyType key = nodeItem->first;
		cout <<"	key = " << key.toString()
			<< ", node pointer = " << nodeItem->second->mainMemoryLink
			<< ", size = " << nodeItem->second->getSize() << endl;
		nodeItem++;
	}

	cout <<"\n\nLRU lists" << endl;
	this->dList->printContent();	
}


/**
* Debug Methods
* The following methods are used to get the statistical information about the NodeIDMap. It has nothing to do with
* how the NodeIDMap works. It is just to monitor the performance of the the NodeIDMap. 
*/
int NodeIDMap::getSizeRequirement()
{
	return this->peakSizeRequirement;
}

int NodeIDMap::getReplacementTimes()
{
	return this->replacementTimes;
}

#pragma warning(default: 4702)

