#ifndef _TIMBER_COMPAT_H
#define _TIMBER_COMPAT_H

#ifndef _BERKELEYDB
#define _BERKELEYDB
#endif

#ifdef WIN32
#include "config-msvc.h"
#else
#include "../config.h"
#endif

#ifdef HAVE_SYS_STAT_H
#define MKDIR_H <sys/stat.h>
#elif defined(HAVE_DIRECT_H)
#define MKDIR_H <direct.h>
#endif

#ifndef HAVE_ITOA
#include <itoa-compat.h>
#endif

#ifdef HAVE_UNISTD_H
#define UNISTD_IO_H <unistd.h>
#endif

#ifdef HAVE_IO_H
#define UNISTD_IO_H <io.h>
#endif

#ifdef HAVE_GETPID
    #define GETPID() getpid()
#elif defined(HAVE__GETPID)
    #define GETPID() _getpid()
#else
    #define GETPID() -1
#endif

#ifndef HAVE__ACCESS
    #define _access access
    #ifndef HAVE_ACCESS
	inline int access(const char* path, int mode) { return 0; }
    #endif
#endif

#ifndef HAVE__STRLWR
    #define _strlwr strlwr
    #define _strupr strupr
    #ifndef HAVE_STRLWR
	#include <strlwr-compat.h>
    #endif
#endif

#ifndef HAVE__STRTIME
    #define _strtime strtime
    #ifndef HAVE_STRTIME
	#include <strtime-compat.h>
    #endif
#endif

#ifdef HAVE_DRAND48
#define HAVE_RAND48
#endif

#ifdef HAVE_DECL_DRAND48 
#define HAVE_RAND48_PROTOS
#endif

/* #ifdef WIN32
#define DB_H "../BerkeleyDB/build_win32/db.h"
#elif defined(DB_43) */
#ifdef DB_43
#define DB_H <db4.3/db.h>
#else
#define DB_H <db.h>
#endif

// FIXME: autoconf test is not right -- need to include math.h #ifdef HAVE_DECL_COPYSIGN
#define HAVE_COPYSIGN_PROTOS
// #endif

#if SIZEOF_OFF_T == 8
# define _lseeki64 lseek
# define __int64 off_t
#elif defined(HAVE_LSEEK64)
# ifndef _LARGEFILE64_SOURCE
#  define _LARGEFILE64_SOURCE
# endif
# define _lseeki64 lseek64
# define __int64 off64_t
#endif // defined(HAVE_LSEEK64)


#ifdef HAVE_STDDEF_H
#include <stddef.h>
#endif

#endif /* _TIMBER_COMPAT */
