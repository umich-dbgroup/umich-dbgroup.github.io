#ifndef __HASH_MAP_COMPAT_H
#define __HASH_MAP_COMPAT_H

#include "timber-compat.h"

#if defined(WIN32)
#include <hash_map>
using stdext::hash_map;
using stdext::hash_multimap;
#elif defined(HAVE_EXT_HASH_MAP)
#	include <ext/hash_map>
using std::hash_map;
using std::hash_multimap;
#elif defined(HAVE_GNUCXX_HASHMAP)
#	include <ext/hash_map>
using __gnu_cxx::hash_map;
using __gnu_cxx::hash_multimap;

/* from libstdc++ functional_hash.h 
 * TODO: add autoconf check for hash<double> support? */
namespace __gnu_cxx
{

    struct _Fnv_hash
    {
	static std::size_t
	    hash(const char* __first, std::size_t __length)
	    {
		std::size_t __result = 0;
		for (; __length > 0; --__length)
		    __result = (__result * 131) + *__first++;
		return __result;
	    }
    };

    template<>
	struct hash<double>
	: public std::unary_function<double, std::size_t>
	{
	    std::size_t
		operator()(double __dval) const
		{
		    std::size_t __result = 0;

		    // 0 and -0 both hash to zero.
		    if (__dval != 0.0)
			__result = _Fnv_hash::hash(reinterpret_cast<const char*>(&__dval),
				sizeof(__dval));
		    return __result;
		}
	};
}

#elif defined(HAVE_STL)
#	include <hash_map>
using std::hash_map;
using std::hash_multimap;
#else
#	error Can't find hash_map header !
#endif

#endif
