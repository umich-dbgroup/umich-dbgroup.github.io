/* config.h.in.  Generated from configure.ac by autoheader.  */

#define HAVE_DIRECT_H
#define HAVE__MKDIR
#define HAVE_WINDOWS_H
#define HAVE__STRLWR
#define HAVE__STRTIME
#define HAVE_STDDEF_H
#define HAVE_SHLWAPI_H

/* Define to 1 if you have the `access' function. */
#define HAVE__ACCESS

/* Define to 1 if you have the declaration of `copysign', and to 0 if you
   don't. */
#define HAVE_DECL_COPYSIGN

/* Define to 1 if you have the declaration of `drand48', and to 0 if you
   don't. */
#undef HAVE_DECL_DRAND48

/* Define to 1 if you have the `drand48' function. */
#undef HAVE_DRAND48

/* define if the compiler has ext/hash_map */
#undef HAVE_EXT_HASH_MAP

/* Define to 1 if you have the `getpid' function. */
#define HAVE__GETPID

/* define if the compiler supports __gnu_cxx::hash_map */
#undef HAVE_GNUCXX_HASHMAP

/* Define to 1 if you have the <inttypes.h> header file. */
#undef HAVE_INTTYPES_H

/* Define to 1 if you have the <io.h> header file. */
#define HAVE_IO_H

/* Define to 1 if you have the `itoa' function. */
#define HAVE_ITOA

/* Define to 1 if you have the `lseek64' function. */
#undef HAVE_LSEEK64

/* Define to 1 if you have the <malloc.h> header file. */
#undef HAVE_MALLOC_H

/* Define to 1 if you have the <math.h> header file. */
#define HAVE_MATH_H

/* Define to 1 if you have the <memory.h> header file. */
#define HAVE_MEMORY_H

/* define if the compiler implements namespaces */
#define HAVE_NAMESPACES

/* Define to 1 if you have the <process.h> header file. */
#define HAVE_PROCESS_H

/* Define to 1 if you have the <stdint.h> header file. */
#undef HAVE_STDINT_H

/* Define to 1 if you have the <stdlib.h> header file. */
#define HAVE_STDLIB_H

/* define if the compiler supports Standard Template Library */
#define HAVE_STL

/* Define to 1 if you have the `strdup' function. */
#define HAVE_STRDUP

/* Define to 1 if you have the <strings.h> header file. */
#undef HAVE_STRINGS_H

/* Define to 1 if you have the <string.h> header file. */
#undef HAVE_STRING_H

/* Define to 1 if you have the `strlwr' function. */
#define HAVE__STRLWR

/* Define to 1 if you have the `strtime' function. */
#define HAVE__STRTIME

/* Define to 1 if you have the <sys/stat.h> header file. */
#undef HAVE_SYS_STAT_H

/* Define to 1 if you have the <sys/types.h> header file. */
#undef HAVE_SYS_TYPES_H

/* Define to 1 if you have the <unistd.h> header file. */
#undef HAVE_UNISTD_H

/* Define to 1 if you have the <values.h> header file. */
#undef HAVE_VALUES_H

/* Name of package */
#undef PACKAGE

/* Define to the address where bug reports for this package should be sent. */
#undef PACKAGE_BUGREPORT

/* Define to the full name of this package. */
#undef PACKAGE_NAME

/* Define to the full name and version of this package. */
#undef PACKAGE_STRING

/* Define to the one symbol short name of this package. */
#undef PACKAGE_TARNAME

/* Define to the version of this package. */
#undef PACKAGE_VERSION

/* Define to 1 if you have the ANSI C header files. */
#define STDC_HEADERS

/* Version number of package */
#undef VERSION
