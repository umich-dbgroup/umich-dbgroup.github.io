#ifndef _ITOA_COMPAT_H
#define _ITOA_COMPAT_H

char* itoa (int value, char* str, int base);

#endif
