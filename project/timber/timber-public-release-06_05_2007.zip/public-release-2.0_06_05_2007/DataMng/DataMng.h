#ifndef __DataMng_H
#define __DataMng_H
#include <timber-compat.h>

#include "StdAfx.h"
#include "Handlers/FileHandler.h"
#include "Handlers/LoadingHandler.h"
#include "Handlers/UpdateHandler.h"

/*
COPYRIGHT  � 2000-2004 
THE REGENTS OF THE UNIVERSITY OF MICHIGAN
ALL RIGHTS RESERVED

PERMISSION IS GRANTED TO USE, COPY, CREATE DERIVATIVE WORKS AND
REDISTRIBUTE THIS SOFTWARE AND SUCH DERIVATIVE WORKS FOR NONCOMMERCIAL
EDUCATION AND RESEARCH PURPOSES, SO LONG AS NO FEE IS CHARGED, AND SO
LONG AS THE COPYRIGHT NOTICE ABOVE, THIS GRANT OF PERMISSION, AND THE
DISCLAIMER BELOW APPEAR IN ALL COPIES MADE; AND SO LONG AS THE NAME OF
THE UNIVERSITY OF MICHIGAN IS NOT USED IN ANY ADVERTISING OR PUBLICITY
PERTAINING TO THE USE OR DISTRIBUTION OF THIS SOFTWARE WITHOUT
SPECIFIC, WRITTEN PRIOR AUTHORIZATION.

THIS SOFTWARE IS PROVIDED AS IS, WITHOUT REPRESENTATION FROM THE
UNIVERSITY OF MICHIGAN AS TO ITS FITNESS FOR ANY PURPOSE, AND WITHOUT
WARRANTY BY THE UNIVERSITY OF MICHIGAN OF ANY KIND, EITHER EXPRESS OR
IMPLIED, INCLUDING WITHOUT LIMITATION THE IMPLIED WARRANTIES OF
MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE. THE REGENTS OF
THE UNIVERSITY OF MICHIGAN SHALL NOT BE LIABLE FOR ANY DAMAGES,
INCLUDING SPECIAL, INDIRECT, INCIDENTAL, OR CONSEQUENTIAL DAMAGES,
WITH RESPECT TO ANY CLAIM ARISING OUT OF OR IN CONNECTION WITH THE USE
OF THE SOFTWARE, EVEN IF IT HAS BEEN OR IS HEREAFTER ADVISED OF THE
POSSIBILITY OF SUCH DAMAGES.
*/

/**
* class DataMng
* This class provide data access interface to all other modules in Timber. It hides the detail of those
* data access operations provided by the data parser, physical data manager and the buffer manager (NodeIDMap). 
* 
* The interface provided by DataMng can be classified as: File interface, Loading interface, Navigation interface, 
* Scan interface and update interface. 
* 
* In the implementation, a tasks are further divided among a set of handlers. Each takes care of one class of 
* interface. 
* 
* @see PhyscicalDataMng
* @see NodeIDMap
* @see FileHandler
* @see LoadingHandler
* @see NavigationHandler
* @see ScanHandler
* @see UpdateHandler
* 
* @author Yuqing Melanie Wu
* @version 1.0
*/

class DataMng
{
public:
	/**
	* Constructor
	* Initialize the DataMng.
	* Initialize all the handlers. 
	*/
	DataMng(PhysicalDataMng* pdatamng
		//, 
		//IndexMng* indexmng
		);

	~DataMng(void);

	/** 
	* Access  Method
	* Get the volumnID where the database is on
	*/
	lvid_t getVolumeID();

	/**
	* Process Method
	* Begin a transaction in the database
	* This is done by calling the beginTransaction function in PhyscialDataMng.
	*/
	void beginTransaction();
	
	/**
	* Process Method
	* Commit a transaction in the database
	* This is done by calling the endTransaction function in PhyscialDataMng.
	*/
	void endTransaction();

	/**
	* Process Method
	* Abort a transaction in the database
	* This is done by calling the abortTransaction function in PhyscialDataMng.
	*/
	void abortTransaction();

	/* ----------------------------------------------------------- */
	/*						file interface					       */
	/* ----------------------------------------------------------- */

	/**
	* File Interface
	* 
	* Find out whether XML document with the given name exists in the database or not. 
	*
	* This task is handled by the FileHandler. 
	*
	* @param filename The name of the file to look for.
	* @returns A boolean value which indicate whether the file exists in the database or not. 
	* 
	* @see FileHandler
	*/
	bool fileExist(char* filename);

	/**
	* File Interface
	* Open a data file, prepare for further operation on the file. 
	* This task is handled by the FileHandler. 
	*
	* @param filename The name of the file to be opened
	* @param rootkey The key of the root node in the file (return value)
	* @param capacityChoice/idmapCapacity/rpPolicy/LRURemovePercentage The parameters for NodeIDMap.
	* @returns The dynamic file id assigned to the file. -1 if any error happens, or when no more file can be opened.
	*
	* @see FileHandler
	*/
	FileIDType openFile(char* XMLFileName,
						KeyType* rootkey,
						int capacityChoice = -1, 
						int idmapCapacity  = -1, 
						int rpPolicy  = -1, 
						float LRURemovePercentage = -1);


	/**
	* File Interface
	* 
	* Close a data file. 
	* This task is handled by the FileHandler.
	* 
	* @param fileid The dynamic id of the file to be closed. 
	* @param sizeRequirement/replacementTimes The statistical information related to the buffer (NodeIDMap) usage.
	*		These are return values. These info will be provided when the input is not NULL.   
	*/
	void closeFile(FileIDType fileid, 
		int* sizeRequired = NULL, 
		int* replacementTimes = NULL);

	/**
	* File Interface 
	*
	* Reorganize a file (most possiblly after updates), to make sure nodes are stored in key order.
	*
	* This is done by directly calling the reorganizeFile function in PhysicalDataMng. 
	* 
	* @param filename The name of the file to be reorganized.
	* @returns Error code. 
	*/
	int reorganizeFile(char* filename);

	/**
	* File Interface
	* Get the names of all the data files in the database. 
	* This task is handled by the FileHandler. 
	*
	* @param num The total number of data files in the database (return value).
	* @returns The list of names of the data file. 
	*/
	char** getFileNames(int* num);

	/**
	* Debug Method
	* Print the content of the buffer (NodeIDMap) associated with a data file. 
	* This task is done through the FileHandler. 
	* @param fileid The dynamic id of the data file. 
	*/
	void printNodeIDMap(FileIDType fileid);


	/* ----------------------------------------------------------- */
	/*						loading  interface					   */
	/* ----------------------------------------------------------- */
	
	/**
	* Loading Interface
	* Load an xml document into database.
	* This task is handled by the loading handler.
	* 
	* @param filename The name of the xml document (with path) to be loaded to the database.
	* @param maxdepth The esitmated depth of the xml document.  
	* @param convertmulticolor The flag saying whether to convert pointer-based to multicolor model (Nuwee added 07/14/03)
	* @returns Error Code
	*/
	int loadXMLFile(char* XMLFile , bool convertmulticolor = false, int maxdepth = 100);

	/**
	* Loading Interace
	* This function append an XML document an existing data file in the database, and incrementally maintain
	* the indicies built on the data file, as well as statistial informations about the database. 
	* 
	* This task is handled by the LoadingHandler. 
	* 
	* @param newXMLFile The name of the XML document to loaded into the database.
	* @param maxdepth The estimated depth of the new XML document. 
	* @param appendToFile The name of the data file where the new document is to be appended to. 
	* @param mergeAt The key of the node in the data file that will be the parent of the root node of the new 
	*	XML document after merging. 
	* @returns Error Code
	*/
	int appendXMLFile(char* newXMLFile,
		int maxdepth,
		char* appendToXMLFile,
		KeyType mergeAt,
		IndexIncrementalUpdate* indexUpdater);	

	/* ----------------------------------------------------------- */
	/*					Navigation  interface					   */
	/* ----------------------------------------------------------- */


	/**
	* Navigation Interface
	* 
	* Get the data node, given the dynamic file id of a file and the key of a node.
	* This task is handled by the FileHandler and the NavigationHandler. 
	* 
	* @param fileid The dynamic file id of the data file. 
	* @param nodekey The key of the node which data we are looking for. 
	* @param writetoNodeMap A boolean value which inidcate whether the node is to be written to the NodeIDMap.
	* @returns A pointer to the data node, or NULL is no such node exists in the database. 
	*/
	DM_DataNode* getDataNode(FileIDType fileid,
		KeyType nodekey,
		bool writetoNodeMap = true);

	/**
	* Navigation Interface
	* 
	* Given the dynamic file id of a file and the key of a node, 
	* get all the data node in the sub-tree rooted at the node given.
	* 
	* Cutting is possible, which specify the kind(s) of node to fetch, as well as the height of the result subtree. 
	* 
	* This task is handled by the FileHandler and the NavigationHandler. 
	*
	* @param fileid The dynamic file id of the data file. 
	* @param nodekey The key of the node, the subtree at that node is we are looking for. 
	* @param cutting The cutting sepcification (type of nodes, depth).
	* @param writetoNodeMap A boolean value which inidcate whether the nodes in the subtree are to be written to the NodeIDMap.
	* @returns A pointer to a data node, which is the root of the subtree, or NULL is the root node does not exist.
	*/
	DM_DataNode* getSubTree(FileIDType fileid,
		KeyType nodekey,
		CuttingType* cutting,
		bool writetoNodeMap );

	/**
	* Navigation Interface
	* 
	* Given the dynamic file id of a file and the key of a node, 
	* get the data node which is the parent of the node with the given key. 
	* 
	* This task is handled by the FileHandler and the NavigationHandler. 
	*
	* @param fileid The dynamic file id of the data file. 
	* @param nodekey The key of the node whose parent is we are looking for. 
	* @param writetoNodeMap A boolean value which inidcate whether the node is to be written to the NodeIDMap.
	* @returns A pointer to the parent node of the node with the given key. NULL if no node has the given key, 
	*	or the node does not have a parent.
	*/
	DM_DataNode* getParent(FileIDType fileid,
		KeyType nodekey,
		bool writetoNodeMap = true);

	/**
	* Navigation Interface
	* 
	* Given the dynamic file id of a file and the key of a node, and a number (n)
	* get the data node which is the n'th child of the node with the given key. 
	* 
	* This task is handled by the FileHandler and the NavigationHandler. 
	*
	* @param fileid The dynamic file id of the data file. 
	* @param nodekey The key of the node whose child is we are looking for. 
	* @param index The index of the child starting from 0. Index = -1 mean that the last child is what we are looking for. 
	* @param writetoNodeMap A boolean value which inidcate whether the node is to be written to the NodeIDMap.
	* @returns A pointer to a data node, which is the (index'th) child of the node with the given key.
	*		returns NULL if node with the given key does not exist in the database, or the node does not have 
	*		as many children as needed for fetching the (index'th).
	*/
	DM_DataNode* getChild(FileIDType fileid,
		KeyType nodekey,
		int index,
		bool writetoNodeMap =true);

	/**
	* Navigation Interface
	* 
	* Given the dynamic file id of a file and the key of a node, get the data node which is a sibling 
	* to the node with the given key, and its position is right in front of that node. 
	* 
	* This task is handled by the FileHandler and the NavigationHandler. 
	*
	* @param fileid The dynamic file id of the data file. 
	* @param nodekey The key of the node whose previous sibling is we are looking for. 
	* @param parentkey The key of the parent of the node whose sibling is to be get, use for Multicolor (Nuwee added 07/01/03)
	* @param writetoNodeMap A boolean value which inidcate whether the result node is to be written to the NodeIDMap.
	* @returns A pointer to a data node, which is the sibling node in front of the node with the given key. 
	*	returns NULL if node with the given key does not exist in the database, or the node is the first child of
	*	its parent.
	*/
	DM_DataNode* getPrevSibling(FileIDType fileid,
		KeyType nodekey,
		KeyType parentkey = NULL,
		bool writetoNodeMap = true);

	/**
	* Navigation Interface
	* 
	* Given the dynamic file id of a file and the key of a node, get the data node which is a sibling 
	* to the node given, and its position is right after that node. 
	* 
	* This task is handled by the FileHandler and the NavigationHandler. 
	*
	* @param fileid The dynamic file id of the data file. 
	* @param nodekey The key of the node whose next sibling is we are looking for. 
	* @param parentkey The key of the parent of the node whose sibling is to be get, use for Multicolor (Nuwee added 07/01/03)
	* @param writetoNodeMap A boolean value which inidcate whether the result node is to be written to the NodeIDMap.
	* @returns A pointer to the data node, which is the sibling node after the node given. 
	*	returns NULL if node with the given key does not exist in the database, or the node is the last child of
	*	its parent.
	*/
	DM_DataNode* getNextSibling(FileIDType fileid,
		KeyType nodekey,
		KeyType parentkey = NULL,
		bool writetoNodeMap = true );

	/**
	* Navigation Interface
	* 
	* Given the dynamic file id of a file and the key of a node, find out the number of children the node has. 
	* 
	* This task is handled by the FileHandler and the NavigationHandler. 
	*
	* @param fileid The dynamic file id of the data file. 
	* @param nodekey The key of the node.
	* @param writetoNodeMap A boolean value which inidcate whether the node is to be written to the NodeIDMap.
	* @returns The number of children of the  node with the given key. -1 if no such node exists in the database. 
	*/
	int getNumChildren(FileIDType fileid,
		KeyType nodekey,
		bool writetoNodeMap = true );

	/**
	* Navigation Interface
	* 
	* Given the dynamic file id of a file and the key of a node, find out the height of the subtree rooted at the node.  
	* 
	* This task is handled by the FileHandler and the NavigationHandler. 
	*
	* @param fileid The dynamic file id of the data file. 
	* @param nodekey The key of the node.
	* @param writetoNodeMap A boolean value which inidcate whether the node is to be written to the NodeIDMap.
	* @returns The height of the subtree rooted at the node with the given key. -1 if no such node exists in the database. 
	*/
	int getSubtreeDepth(FileIDType fileid, 
		KeyType nodekey,
		bool writetoNodeMap = true );

	/**
	* Navigation Interface
	* 
	* Given the dynamic file id of a file and the key of an element node, get the data node which contains 
	* the attributes belongs to the element node. 
	*
	* This task is handled by the FileHandler and the NavigationHandler. 
	*
	* @param fileid The dynamic file id of the data file. 
	* @param nodekey The key of the element node.
	* @param writetoNodeMap A boolean value which inidcate whether the node is to be written to the NodeIDMap.
	* @returns A pointer to the attribute node which contains all the attributes belonging to the element node. 
	*	returns -1 if no element node with the given key exists, or the element does not have attribute. 
	*/
	DM_DataNode* getAttributes(FileIDType fileid,
		KeyType nodekey,
		bool writetoNodeMap = true);

	/**
	* Navigation Interface
	* 
	* Given the dynamic file id of a file and the key of a node and a number (n)
	* get the name and value of the attribute which is the n'th attribute of the node given. 
	* The node with the given key can be an element node or an attribute node. 
	*
	* This task is handled by the FileHandler and the NavigationHandler. 
	*
	* @param fileid The dynamic file id of the data file. 
	* @param nodekey The key of the node (it can be an element node or an attribute node).
	* @param index The index of the attribute we are looking for. 
	* @param writetoNodeMap A boolean value which inidcate whether the node is to be written to the NodeIDMap.
	* @param attrname The name of the attribute (return value)
	* @param value The value of the attribute (return value). 
	* @returns Error Code
	*/
	int getAttribute(
		// input
		FileIDType fileid,
		KeyType nodekey,
		short index,
		bool writetoNodeMap,
		// output
		char* attrname,
		Value* value
		);

	/**
	* Navigation Interface
	* 
	* Given the dynamic file id of a file and the key of a node and the attribute name
	* get the value of the attribute which is an attribute of the node given, and
	* whose name is the same as the name given.
	*
	* This task is handled by the FileHandler and the NavigationHandler. 
	*
	* @param fileid The dynamic file id of the data file. 
	* @param nodekey The key of the node (it can be an element node or an attribute node).
	* @param attrname The name of the attribute whose value is what we are looking for.
	* @param writetoNodeMap A boolean value which inidcate whether the node is to be written to the NodeIDMap.
	* @returns The value of the attribute. returns NULL if the node with the given key does not exist,
	* or it is not an element node or attribute, or the element node does not have attribute, or there
	* is no attribute has the name given. 
	*/
	Value* getAttribute(FileIDType fileid,
		KeyType nodekey,
		char* attrname,
		bool writetoNodeMap);

	/* ----------------------------------------------------------- */
	/*						scan  interface						   */
	/* ----------------------------------------------------------- */
	
	/**
	* Scan Interface
	* Start A scan. 
	*
	* This task is handled by the FileHandler and the ScanHandler. 
	*
	* @param fileid The dynamic file id of the data file. 
	* @param nodekey The key of the node which is the root of the subtree to be scanned
	* @param scanmethod The scan method (reserved for later use)
	* @param depth The depth to get into the subtree. Only nodes within "depth" to the subtree root can be result of the scan.					 
	* @param scanrange A list of ranges. Only nodes fall in to  the scan range can be result of the scan. 
	* @param condition The scan condition in CNF format.
	* @param overflowSetting: 0=scan both sorted and overflow sections, 1=just sorted, 2=just overflow (and scanranges == NULL)
	* @returns The scan id of the new scan just started. -1 if any error happens in the process. 
	*/
	ScanIDType startScan(FileIDType fileid,
		KeyType nodekey,
		int scanmethod,
		int depth,
		ScanRange* scanranges,
		SelectionCondition* condition,
		bool writetonodemap = false,
		int overflowSetting = 0);

	/**
	* Scan Interface
	* Finish a scan. 
	* 
	* This task is handled by the FileHandler and the ScanHandler. 
	*
	* @param fileid The dynamic file id of the data file. 
	* @param scanid The id of the scan to be finished.
	* @returns Error code
	*/
	int clearScan(FileIDType fileid,
		ScanIDType scanid);

	/**
	* Scan Interface
	* 
	* Fetch the next result of the scan. 
	*
	* This task is handled by the FileHandler and the ScanHandler. 
	*
	* @param fileid The dynamic file id of the data file. 
	* @param scanid The id of the scan.
	* @returns The next result node in the scan. NULL if all nodes have been fetched already. 
	*/
	DM_DataNode* scanFetchNext(FileIDType fileid,
		ScanIDType scanid);

	/**
	* Scan Interface
	* Instantiate node(s) by bringing the nodes from database to the memory buffer (NodeIDMap). 
	* 
	* This task is handled by the FileHandler and the ScanHandler. 
	*
	* @param fileid The dynamic id of the data file.
	* @param nodekey The key of the node to be instantiated. 
	* @param diSpec The data instantiation specification. 
	* @returns A pointer to the node. 
	*/
	DM_DataNode* dataInstantiation(FileIDType fileid,
		KeyType nodekey, 
		DataInstantiationSpecification* diSpec);

	/**
	* Process Method
	* Discard nodes from buffer (NodeIDMap). 
	* 
	* This task is handled by the FileHandler and the ScanHandler. 
	*
	* @param fileid The dynamic id of the data file.
	* @param nodekey The key of the node to be discarded from the buffer. 
	* @param diSpec The data instantiation specification which specify what nodes are to be discarded. 
	*/
	void dataDiscard(FileIDType fileid,
		KeyType nodekey, 
		DataInstantiationSpecification* diSpec);

	/* ----------------------------------------------------------- */
	/*						update  interface					   */
	/* ----------------------------------------------------------- */

	/**
	* Updating Interface
	* 
	* Update the XML document that is already loaded into the database.
	* The update operations include:
	* 
	*@@ insert a leaf node.
	*@@ insert a non-leaf node (the new node becomes a child of a node in the XML document, and the children of that node become the children of the new nodes).
	*@@ insert a subtree. (not supported right now)
	*@@ delete a node (if the node is a non-leaf node, its children become the children of its parent).
	*@@ delete a subtree
	*@@ modify a node (only modify the content of node, like element tag, attribute value, 
	*		text content, not the structure). 
	*
	* @param fileid The dynamic id of the file on which the scan is opened
	* 
	* @param operation Specify what kind of update to perform. It can be one of the following:
	*@@ DATAMNG_UPDATEOP_INSERTLEAFNODE
	*@@ DATAMNG_UPDATEOP_INSERTNONLEAFNODE
	*@@ DATAMNG_UPDATEOP_INSERTSUBTREE
	*@@ DATAMNG_UPDATEOP_DELETENODE
	*@@ DATAMNG_UPDATEOP_DELETESUBTREE
	*@@ DATAMNG_UPDATEOP_MODIFYNODE
	* 
	* @param key: for insertion, it is the key of the node which will be the parent of the inserted 
	*			node (sub-tree); for deletion, it is the key of the node to be deleted, or the key 
	*			of the root of the sub-tree; for modification, it is the key of the node to be 
	*			modified.
	* 
	* @param childIndex: it specifies the position of the new node (sub-tree) among all the 
	*			children of the nodes (specified by �key?. For DATAMNG_UPDATEOP_INSERTLEAFNODE 
	*			and DATAMNG_UPDATEOP_INSERTSUBTREE, all the children after �childIndex?will be 
	*			pushed right. For DATAMNG_UPDATEOP_INSERTNONLEAFNODE, the old childIndex�th 
	*			child will become the child of the new node.
	* 
	* @param newNode: the data to be inserted or to be used to replace the old node. For 
	*			DATAMNG_UPDATEOP_INSERTSUBTREE, it should be the root of the sub-tree to be 
	*			inserted. For DATAMNG_UPDATEOP_MODIFYNODE, the new nodes should have exactly the 
	*			same structural as the node to be replaced. The fields that can be changed are: 
	*			element tag, text content and attribute value.
	* @param updateNodeParentKey: For Multicolor, the key of the parent of the node to update, currently for text and attribute
	*			node deletion where parent key is needed, so that to know which colored tree it is performing on
	* @returns Whether the operation is performed successfully.
	*/

	double update(IndexIncrementalUpdate *indexUpdater,
		FileIDType fileid, 
		int operation,
		KeyType key,
		int childIndex,
		DM_DataNode* newnode,
		serial_t* newNodeRid = NULL,
		KeyType updateNodeParentKey = -1);

	FileInfoType*	getFileInfo(FileIDType fileid);

    /**
    * @return PhysicalDataMng
    */
    PhysicalDataMng* getPhysicalDataMng();
	serial_t getNodeRid(FileIDType fileID, KeyType startKey);

private:
	/**
	* The PhysicalDataMng which provide support for data access at physical level
	*/	
	PhysicalDataMng* physicalDataMng;
	
	//IndexMng* indexMng;

	/**
	* The handlers that carry out the tasks. 
	*/
	FileHandler* fileHandler;
	NavigationHandler* navigationHandler;
	LoadingHandler* loadingHandler;
	ScanHandler* scanHandler;
	UpdateHandler* updateHandler;
};

#endif

