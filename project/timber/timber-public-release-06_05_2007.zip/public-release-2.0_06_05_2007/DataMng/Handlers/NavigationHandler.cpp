/*
  COPYRIGHT  � 2000-2004 
  THE REGENTS OF THE UNIVERSITY OF MICHIGAN
  ALL RIGHTS RESERVED

  PERMISSION IS GRANTED TO USE, COPY, CREATE DERIVATIVE WORKS AND
  REDISTRIBUTE THIS SOFTWARE AND SUCH DERIVATIVE WORKS FOR NONCOMMERCIAL
  EDUCATION AND RESEARCH PURPOSES, SO LONG AS NO FEE IS CHARGED, AND SO
  LONG AS THE COPYRIGHT NOTICE ABOVE, THIS GRANT OF PERMISSION, AND THE
  DISCLAIMER BELOW APPEAR IN ALL COPIES MADE; AND SO LONG AS THE NAME OF
  THE UNIVERSITY OF MICHIGAN IS NOT USED IN ANY ADVERTISING OR PUBLICITY
  PERTAINING TO THE USE OR DISTRIBUTION OF THIS SOFTWARE WITHOUT
  SPECIFIC, WRITTEN PRIOR AUTHORIZATION.

  THIS SOFTWARE IS PROVIDED AS IS, WITHOUT REPRESENTATION FROM THE
  UNIVERSITY OF MICHIGAN AS TO ITS FITNESS FOR ANY PURPOSE, AND WITHOUT
  WARRANTY BY THE UNIVERSITY OF MICHIGAN OF ANY KIND, EITHER EXPRESS OR
  IMPLIED, INCLUDING WITHOUT LIMITATION THE IMPLIED WARRANTIES OF
  MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE. THE REGENTS OF
  THE UNIVERSITY OF MICHIGAN SHALL NOT BE LIABLE FOR ANY DAMAGES,
  INCLUDING SPECIAL, INDIRECT, INCIDENTAL, OR CONSEQUENTIAL DAMAGES,
  WITH RESPECT TO ANY CLAIM ARISING OUT OF OR IN CONNECTION WITH THE USE
  OF THE SOFTWARE, EVEN IF IT HAS BEEN OR IS HEREAFTER ADVISED OF THE
  POSSIBILITY OF SUCH DAMAGES.
*/

#include "NavigationHandler.h"
#include "../../Utilities/ErrorInfoClass.h"

/**
 * class NavigationHandler
 * This handler provide support for the nagivation interface at the DataMng level. 
 * 
 * The major different between the navigation at the PhysicalDataMng level and at the DataMng level is that
 * at PhysicalDataMng level, nodes are access by given fileinfo and node key, and at DataMng level, nodes
 * are accessed by given filename, node key, and the relationship of the node you want to find with the node  
 * with the given key. This Interface provide the ability to navigate in the XML tree structure, from one node
 * to its parent, child, sibling, attribute, etc. 
 * 
 * Another difference is that the PhysicalDataMng always fetch node from database, on each such request, while
 * the DataMng has the support from a memory buffer (NodeIDMap) which keeps some nodes in memory, and can 
 * access them quick on the requests that refer to nodes that are currently in the NodeIDMap. The buffer 
 * (NodeIDMap) is not visible to the user of the Navigation Interface of DataMng. 
 * 
 * @see PhysicalDataMng
 * @see DataMng
 * @see NodeIDMap
 * 
 * @author Yuqing Melanie Wu
 * @version 1.0
 */


/**
 * Constructor
 * Initialize the NavigationHandler with the PhysicalDataMng which provide support to it. 
 */

NavigationHandler::NavigationHandler(PhysicalDataMng* pdatamng)
{
  this->physicalDataMng = pdatamng;
}

NavigationHandler::~NavigationHandler(void)
{
}



/**
 * Navigation Interface
 * 
 * Get the data node, given the dynamic file id of a file and the key of a node.
 * 
 * @param idmap The NodeIDMap associated with the data file. 
 * @param fileinfo The information about the datafile 
 * @param nodekey The key of the node which data we are looking for. 
 * @param writetoNodeMap A boolean value which inidcate whether the node is to be written to the NodeIDMap.
 * @returns A pointer to the data node, or NULL is no such node exists in the database. 
 */

DM_DataNode* NavigationHandler::getDataNode(NodeIDMap* idmap,
                                            FileInfoType* fileinfo,
                                            KeyType nodekey,
                                            bool writetoNodeMap)
{
  DM_DataNode* nodepnt;

  //// debug: added by Cong to see if IDMap is correct: bypass all NodeIDMap operations
  //nodepnt = this->physicalDataMng->fetchDataNodeFromDBFile((const FileInfoType) *fileinfo, nodekey);
  //return nodepnt;

  if (idmap == NULL)
    // if the NodeIDMap is empty, just get the node from database. 
    nodepnt = this->physicalDataMng->fetchDataNodeFromDBFile((const FileInfoType) *fileinfo, nodekey);
  else
    {
      // first try the NodeIDMap, see whether the node with the given key is in it. 
      nodepnt = idmap->getNode(nodekey);
      if (nodepnt == NULL)
        {
          // go to the database for the data fetching only when the node is not in the NodeIDMap. 
          nodepnt = this->physicalDataMng->fetchDataNodeFromDBFile((const FileInfoType) *fileinfo, nodekey);

          if (nodepnt != NULL)
            if (writetoNodeMap)
              // write the node to NodeIDMap if specified so. 
              idmap->insertNode(nodepnt);
        }
    }

  return nodepnt;
}
		
		

/**
 * Navigation Interface
 * 
 * Given the dynamic file id of a file and the key of a node, 
 * get all the data node in the sub-tree rooted at the node given.
 * 
 * Cutting is possible, which specify the kind(s) of node to fetch, as well as the height of the result subtree. 
 * 
 * @param idmap The NodeIDMap associated with the data file. 
 * @param fileinfo The information about the datafile. 
 * @param nodekey The key of the node, the subtree at that node is we are looking for. 
 * @param cutting The cutting sepcification (type of nodes, depth).
 * @param writetoNodeMap A boolean value which inidcate whether the nodes in the subtree are to be written to the NodeIDMap.
 * @returns A pointer to a data node, which is the root of the subtree, or NULL is the root node does not exist.
 */

DM_DataNode* NavigationHandler::getSubTree(NodeIDMap* idmap,
                                           FileInfoType* fileinfo,
                                           KeyType nodekey,
                                           CuttingType* cutting,
                                           bool writetoNodeMap)
{
  CuttingType newcutting;

  // get the root node. 
  DM_DataNode* node = getDataNode(idmap, fileinfo, nodekey, writetoNodeMap);
  if (node == NULL)
    {
      // report error is the root node can not be found in the database. 
      globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"NavigationHandler",__FILE__,"The specified node does not exist");

      return NULL;
    }

  else if ((node->getFlag() == ELEMENT_NODE) || 
           (node->getFlag() == DOCUMENT_NODE))
    {
      // only element node and document node can have subtree rooted at the node. 

      // get its first child
      KeyType childkey = node->getFirstChild();

      if (childkey != -1)
        {
          // child exists. 

          DM_DataNode* childnode;
          if (cutting == NULL)
            // if cutting is NULL, all the nodes in the subtree is to be fetched. 
            // use getNextSibling to move right, and use getSubTree to get the subtree recursively. 
            while (childkey != -1)
              {
                childnode = getSubTree(idmap, fileinfo,childkey, NULL, writetoNodeMap);
                childkey = childnode->getNextSibling();
                //Nuwee added: 06/23/2003 for Multicolor
                //If key is not valid , and it is char node, and attribute key is valid
                if ((!childkey.isValid()) && 
                    ((childnode->getFlag() == TEXT_NODE) || (childnode->getFlag() == COMMENT_NODE)) &&
                    (((DM_CharNode*)childnode)->getAttributes().isValid())) {
                  // it is part of the children of Multicolor node
                  //go to that attribute node to get next sibling of this char node
                  DM_DataNode* attrnode;
                  attrnode = getDataNode(idmap,fileinfo,((DM_CharNode*)childnode)->getAttributes(),writetoNodeMap);
                  childkey = ((DM_AttributeNode*)attrnode)->getMCTNextSibling(nodekey,childnode->getKey());
                  //delete attrnode;
                }
                //end Multicolor
              }
          else
            {
              // if some cutting specification is given, need to consider it in the recursive fetching

              // reset the cutting specification for the subtree root at the child, 
              newcutting.Depth = cutting->Depth-1;
              newcutting.NodeTypes = cutting->NodeTypes;

              if (newcutting.Depth > 0)
                // go down only when it is still in the range specified by the cutting. 
                while (childkey != -1)
                  { 
                    // use getNextSibling to move right, and use getSubTree to get the subtree recursively. 
                    childnode = getSubTree(idmap, fileinfo, childkey, &newcutting, writetoNodeMap);
                    childkey = childnode->getNextSibling();
                    //Nuwee added: 06/30/2003 for Multicolor
                    //If key is not valid , and it is char node, and attribute key is valid
                    if ((!childkey.isValid()) && 
                        ((childnode->getFlag() == TEXT_NODE) || (childnode->getFlag() == COMMENT_NODE)) &&
                        (((DM_CharNode*)childnode)->getAttributes().isValid())) {
                      // it is part of the children of Multicolor node
                      //go to that attribute node to get next sibling of this char node
                      DM_DataNode* attrnode;
                      attrnode = getDataNode(idmap,fileinfo,((DM_CharNode*)childnode)->getAttributes(),writetoNodeMap);
                      childkey = ((DM_AttributeNode*)attrnode)->getMCTNextSibling(nodekey,childnode->getKey());
                      //delete attrnode;
                    }
                    //end Multicolor
                  }
            }
        }
	
      if (node->getFlag() == ELEMENT_NODE)
        {
          // for element node, need to get its  attribute node if there is one. 
          KeyType attrkey = ((DM_ElementNode*) node)->getAttributes();
          if (attrkey != -1){
            DM_DataNode* attrnode;
            attrnode = getDataNode(idmap, fileinfo, attrkey, writetoNodeMap);
          }
        }
    }
  return node;
}

/**
 * Navigation Interface
 * 
 * Given the dynamic file id of a file and the key of a node, 
 * get the data node which is the parent of the node with the given key. 
 * 
 * @param idmap The NodeIDMap associated with the data file. 
 * @param fileinfo The information about the datafile 
 * @param nodekey The key of the node whose parent is we are looking for. 
 * @param writetoNodeMap A boolean value which inidcate whether the node is to be written to the NodeIDMap.
 * @returns A pointer to the parent node of the node with the given key. NULL if no node has the given key, 
 *	or the node does not have a parent.
 */
DM_DataNode* NavigationHandler::getParent(NodeIDMap* idmap,
										  FileInfoType* fileinfo,
										  KeyType nodekey,
										  bool writetoNodeMap)
{
	// get the node with the given key.
	DM_DataNode* node = getDataNode(idmap, fileinfo, nodekey, writetoNodeMap);

	if (node == NULL)
	{
		// report error is no such node exist.
		globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"NavigationHandler",__FILE__,"The specified node does not exist"); 
		return NULL;
	}
	else 
	{
		// get the parent key of the node
		KeyType parentkey = node->getParent();

		//if idmap == NULL then we need to delete the child node ourselves:
		if (idmap == NULL)
			delete node;
		//also, if we did not write the node to the nodeIDMap, we are responsible for deleting the child node
		//but only if it didn't exist in the nodeIDMap outside of this method:
		else if (!writetoNodeMap) {
			if (idmap->getNode(nodekey) == NULL)
				delete node;
		}

		if (parentkey == -1)
			// the node has no parent. 
			return NULL;
		else
		{
			// get the parent node. 
			DM_DataNode* parentnode = getDataNode(idmap, fileinfo, parentkey, writetoNodeMap);
			return parentnode;
		}
	}
}

/**
 * Navigation Interface
 * 
 * Given the dynamic file id of a file and the key of a node, and a number (n)
 * get the data node which is the n'th child of the node with the given key. 
 * 
 * @param idmap The NodeIDMap associated with the data file. 
 * @param fileinfo The information about the datafile 
 * @param nodekey The key of the node whose child is we are looking for. 
 * @param index The index of the child starting from 0. Index = -1 mean that the last child is what we are looking for. 
 * @param writetoNodeMap A boolean value which inidcate whether the node is to be written to the NodeIDMap.
 * @returns A pointer to a data node, which is the (index'th) child of the node with the given key.
 *		returns NULL if node with the given key does not exist in the database, or the node does not have 
 *		as many children as needed for fetching the (index'th).
 */

DM_DataNode* NavigationHandler::getChild(NodeIDMap* idmap,
                                         FileInfoType* fileinfo,
                                         KeyType nodekey,
                                         int index,
                                         bool writetoNodeMap)
{
  KeyType childkey;
  DM_DataNode* node;
  DM_DataNode* childnode;			
	
  if (index < -1)
    {
      // the input is not a valid child index
      globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"NavigationHandler",__FILE__,"Not a Valid Child Index."); 
      return NULL;
    }

  // get the node with the given key. 
  node = getDataNode(idmap, fileinfo, nodekey, writetoNodeMap);
  if (node == NULL)
    {
      // report error if no such node exists in the database. 
      globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"NavigationHandler",__FILE__,"The specified node does not exist"); 
      return NULL;
    }
  else 
    {
      // get the child number of the node. 
      int childnumber = node->getChildNumber();
      if (childnumber == 0)
        // the node has no child. 
        return NULL;

      if (index >= childnumber)
        {
          // the node does  not have enough child for fetching the index'th child. 
#ifdef _DEBUG
          if (index != 0) 
            globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"NavigationHandler",__FILE__,"A child at that position does not exist"); 
#endif
          return NULL;
        }
      else if (index == -1)
        {
          // fetch the last child is the input index is -1.
          childkey = node->getLastChild();
          childnode = getDataNode(idmap, fileinfo, childkey, writetoNodeMap);
          return childnode;
        }
		
      else
        {
          // find the index'th child, by following sibling link, starting from the first child. 
          childkey = node->getFirstChild();
          childnode = getDataNode(idmap, fileinfo, childkey, writetoNodeMap);
          for (int i=0;i<index;i++)
            {
              childkey = childnode->getNextSibling();

              //Nuwee added: 06/30/2003 for Multicolor
              //If key is not valid , and it is char node, and attribute key is valid
              if ((!childkey.isValid()) && 
                  ((childnode->getFlag() == TEXT_NODE) || (childnode->getFlag() == COMMENT_NODE)) &&
                  (((DM_CharNode*)childnode)->getAttributes().isValid())) {
                // it is part of the children of Multicolor node
                //go to that attribute node to get next sibling of this char node
                DM_DataNode* attrnode;
                attrnode = getDataNode(idmap,fileinfo,((DM_CharNode*)childnode)->getAttributes(),writetoNodeMap);
                childkey = ((DM_AttributeNode*)attrnode)->getMCTNextSibling(nodekey,childnode->getKey());
                //delete attrnode;
              }
              //end Multicolor

			  //AN: we should check writetoNodeMap before deleting childnode, if writetoNodeMap==true,
				//then the nodeIDMap will delete the childnode
			  if (!writetoNodeMap)
	              delete childnode;
              if (childkey.isValid())
                childnode = getDataNode(idmap, fileinfo, childkey, writetoNodeMap);
              else childnode = NULL;
            }
          return childnode;
        }
    }
}

/**
 * Navigation Interface
 * 
 * Given the dynamic file id of a file and the key of a node, get the data node which is a sibling 
 * to the node with the given key, and its position is right in front of that node. 
 * 
 * @param idmap The NodeIDMap associated with the data file. 
 * @param fileinfo The information about the datafile 
 * @param nodekey The key of the node whose previous sibling is we are looking for. 
 * @param parentkey The key of the parent of the node whose sibling is to be get, use for Multicolor (Nuwee added 07/01/03)
 * @param writetoNodeMap A boolean value which inidcate whether the result node is to be written to the NodeIDMap.
 * @returns A pointer to a data node, which is the sibling node in front of the node with the given key. 
 *	returns NULL if node with the given key does not exist in the database, or the node is the first child of
 *	its parent.
 */
DM_DataNode* NavigationHandler::getPrevSibling(NodeIDMap* idmap,
                                               FileInfoType* fileinfo,
                                               KeyType nodekey,
                                               KeyType parentkey,
                                               bool writetoNodeMap)
{
  // get the node with the given key. 
  DM_DataNode* node = getDataNode(idmap, fileinfo, nodekey, writetoNodeMap);
  if (node == NULL)
    {
      // report error if no such node exists. 
      globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"NavigationHandler",__FILE__,"The specified node does not exist"); 
      return NULL;
    }
  else 
    {
      // get the privious sibling of the node. 
      KeyType siblingkey = node->getPrevSibling();

      //Nuwee added: 06/30/2003 for Multicolor
      //If key is not valid , and it is char node, and attribute key is valid
      if ((!siblingkey.isValid()) && 
          ((node->getFlag() == TEXT_NODE) || (node->getFlag() == COMMENT_NODE)) &&
          (((DM_CharNode*)node)->getAttributes().isValid())) {
        // it is part of the children of Multicolor node
        //go to that attribute node to get next sibling of this char node
        DM_DataNode* attrnode;
        attrnode = getDataNode(idmap,fileinfo,((DM_CharNode*)node)->getAttributes(),writetoNodeMap);
        siblingkey = ((DM_AttributeNode*)attrnode)->getMCTPrevSibling(parentkey,nodekey);
        //delete attrnode;
      }
      //end Multicolor

      if (siblingkey == -1)
        {
          // this node does not have a previous sibling.
          globalErrorInfo.insertProblem(ERR_TYPE_WARNING,__LINE__,"NavigationHandler",__FILE__,"This node is the first child of its parent, no previous sibling exists");  
          return NULL;
        }
      else
        {
          DM_DataNode* siblingnode = getDataNode(idmap, fileinfo, siblingkey, writetoNodeMap);
          return siblingnode;
        }
    }
}

/**
 * Navigation Interface
 * 
 * Given the dynamic file id of a file and the key of a node, get the data node which is a sibling 
 * to the node given, and its position is right after that node. 
 * 
 * @param idmap The NodeIDMap associated with the data file. 
 * @param fileinfo The information about the datafile 
 * @param nodekey The key of the node whose next sibling is we are looking for. 
 * @param parentkey The key of the parent of the node whose sibling is to be get, use for Multicolor (Nuwee added 07/01/03)
 * @param writetoNodeMap A boolean value which inidcate whether the result node is to be written to the NodeIDMap.
 * @returns A pointer to the data node, which is the sibling node after the node given. 
 *	returns NULL if node with the given key does not exist in the database, or the node is the last child of
 *	its parent.
 */
DM_DataNode* NavigationHandler::getNextSibling(NodeIDMap* idmap, 
                                               FileInfoType* fileinfo,
                                               KeyType nodekey,
                                               KeyType parentkey,
                                               bool writetoNodeMap)
{
  // get the node with the given key. 
  DM_DataNode* node = getDataNode(idmap, fileinfo, nodekey, writetoNodeMap);
  if (node == NULL)
    {
      // report error if no such node exist.
      globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"NavigationHandler",__FILE__,"The specified node does not exist");  
      return NULL;
    }
  else 
    {
      // get the next sibling of the node. 
      KeyType siblingkey = node->getNextSibling();

      //Nuwee added: 06/30/2003 for Multicolor
      //If key is not valid , and it is char node, and attribute key is valid
      if ((!siblingkey.isValid()) && 
          ((node->getFlag() == TEXT_NODE) || (node->getFlag() == COMMENT_NODE)) &&
          (((DM_CharNode*)node)->getAttributes().isValid())) {
        // it is part of the children of Multicolor node
        //go to that attribute node to get next sibling of this char node
        DM_DataNode* attrnode;
        attrnode = getDataNode(idmap,fileinfo,((DM_CharNode*)node)->getAttributes(),writetoNodeMap);
        siblingkey = ((DM_AttributeNode*)attrnode)->getMCTNextSibling(parentkey,nodekey); 
        //delete attrnode;
      }
      //end Multicolor

      if (siblingkey == -1)
        {
          return NULL;
        }
      else
        {
          DM_DataNode* siblingnode = getDataNode(idmap, fileinfo, siblingkey, writetoNodeMap);
          return siblingnode;
        }
    }
}

/**
 * Navigation Interface
 * 
 * Given the dynamic file id of a file and the key of a node, find out the number of children the node has. 
 * 
 * @param idmap The NodeIDMap associated with the data file. 
 * @param fileinfo The information about the datafile.
 * @param nodekey The key of the node.
 * @param writetoNodeMap A boolean value which inidcate whether the node is to be written to the NodeIDMap.
 * @returns The number of children of the  node with the given key. -1 if no such node exists in the database. 
 */
int NavigationHandler::getNumChildren(NodeIDMap* idmap,
                                      FileInfoType* fileinfo,
                                      KeyType nodekey, 
                                      bool writetoNodeMap)
{
  DM_DataNode* node;		
	
  // get the node with the given key. 
  node = this->getDataNode(idmap, fileinfo, nodekey, writetoNodeMap);
  if (node == NULL)
    {
      // return -1 if no such node exists in the database. 
      globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"NavigationHandler",__FILE__,"The specified node does not exist");  
      return -1;
    }

  // get the child number. 
  int numChildren =  node->getChildNumber();
  return numChildren;
}



/**
 * Navigation Interface
 * 
 * Given the dynamic file id of a file and the key of a node, find out the height of the subtree rooted at the node.  
 * 
 * @param idmap The NodeIDMap associated with the data file. 
 * @param fileinfo The information about the datafile.
 * @param nodekey The key of the node.
 * @param writetoNodeMap A boolean value which inidcate whether the node is to be written to the NodeIDMap.
 * @returns The height of the subtree rooted at the node with the given key. -1 if no such node exists in the database. 
 */
int NavigationHandler::getSubtreeDepth(NodeIDMap* idmap,
                                       FileInfoType* fileinfo,
                                       KeyType nodekey,
                                       bool writetoNodeMap)
{

  DM_DataNode* node;		
	
  // get the node with the given key. 
  node = getDataNode(idmap, fileinfo, nodekey, writetoNodeMap);
  if (node == NULL)
    {
      // if no such node exists in the database, return -1. 
      globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"NavigationHandler",__FILE__,"The specified node does not exist");  
      return -1;
    }

  // get the height of the subtree. 
  int depth = node->getDescendantDepth();
  return depth;
}		


/**
 * Navigation Interface
 * 
 * Given the dynamic file id of a file and the key of an element node, get the data node which contains 
 * the attributes belongs to the element node. 
 *
 * @param idmap The NodeIDMap associated with the data file. 
 * @param fileinfo The information about the datafile.
 * @param nodekey The key of the element node.
 * @param writetoNodeMap A boolean value which inidcate whether the node is to be written to the NodeIDMap.
 * @returns A pointer to the attribute node which contains all the attributes belonging to the element node. 
 *	returns -1 if no element node with the given key exists, or the element does not have attribute. 
 */

DM_DataNode* NavigationHandler::getAttributes(NodeIDMap* idmap, 
                                              FileInfoType* fileinfo,
                                              KeyType nodekey,
                                              bool writetoNodeMap)
{
  // get the element node with the given key. 
  DM_DataNode* node = getDataNode(idmap, fileinfo, nodekey, writetoNodeMap);
  if (node == NULL)
    {
      globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"NavigationHandler",__FILE__,"The specified node does not exist");  
      return NULL;
    }
  else if (node->getFlag() != ELEMENT_NODE)
    {
      // report error is the node with the given key is not an element node. 
      globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"NavigationHandler",__FILE__,"The specified node does not exist");  
      return NULL;
    }
  else
    {
      // get the attribute node associated with the element node. 
      KeyType attrkey = ((DM_ElementNode*) node)->getAttributes();
      if (attrkey == -1)
        {
          return NULL;
        }
      else
        {
          DM_DataNode* attrnode = getDataNode(idmap, fileinfo, attrkey, writetoNodeMap);
          return attrnode;
        }
    }

}

/**
 * Navigation Interface
 * 
 * Given the dynamic file id of a file and the key of a node and a number (n)
 * get the name and value of the attribute which is the n'th attribute of the node given. 
 * The node with the given key can be an element node or an attribute node. 
 *
 * @param idmap The NodeIDMap associated with the data file. 
 * @param fileinfo The information about the datafile.
 * @param nodekey The key of the node (it can be an element node or an attribute node).
 * @param index The index of the attribute we are looking for. 
 * @param writetoNodeMap A boolean value which inidcate whether the node is to be written to the NodeIDMap.
 * @param attrname The name of the attribute (return value)
 * @param value The value of the attribute (return value). 
 * @returns Error Code
 */

int NavigationHandler::getAttribute(// input
                                    NodeIDMap* idmap,
                                    FileInfoType* fileinfo,
                                    KeyType nodekey,
                                    short index,
                                    bool writetoNodeMap,
                                    // output
                                    char* attrname,
                                    Value* value)
						  
{
  // get the node with the given key. 
  DM_DataNode* node = getDataNode(idmap, fileinfo, nodekey, writetoNodeMap);
  DM_AttributeNode* attrnode;

  if (node == NULL)
    {
      globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"NavigationHandler",__FILE__,"The specified node does not exist");  
      return -1;
    }

  else if ((node->getFlag() == ELEMENT_NODE))
    {
      // the node is an element node, get its attribute node
      KeyType attrkey = ((DM_ElementNode*) node)->getAttributes();
      if (attrkey == -1) return -1;
      else
        {
          attrnode = (DM_AttributeNode*) getDataNode(idmap, fileinfo, attrkey, writetoNodeMap);
          if (attrnode == NULL) return -1;
        }
    }
  else if (node->getFlag() == ATTRIBUTE_NODE)
    // the node itself is attribute node. 
    attrnode = (DM_AttributeNode*) node;
  else
    {
      // the node is not an element node or attribute node
      globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"NavigationHandler",__FILE__,"The specified node is not a node from which attributes can be fetched");  
      return -1;
    }
	
  if (attrnode->getAttributeNumber() <= index)
    // the index value is  not proper. 
    return -1;
  else 
    // get the name and value of the attribute. 
    value = ((DM_AttributeNode*) attrnode)->getAttr(index, attrname);

  return NO_ERROR;
}


/**
 * Navigation Interface
 * 
 * Given the dynamic file id of a file and the key of a node and the attribute name
 * get the value of the attribute which is an attribute of the node given, and
 * whose name is the same as the name given.
 *
 * @param idmap The NodeIDMap associated with the data file. 
 * @param fileinfo The information about the datafile.
 * @param nodekey The key of the node (it can be an element node or an attribute node).
 * @param attrname The name of the attribute whose value is what we are looking for.
 * @param writetoNodeMap A boolean value which inidcate whether the node is to be written to the NodeIDMap.
 * @returns The value of the attribute. returns NULL if the node with the given key does not exist,
 * or it is not an element node or attribute, or the element node does not have attribute, or there
 * is no attribute has the name given. 
 */

Value* NavigationHandler::getAttribute(NodeIDMap* idmap,
                                       FileInfoType* fileinfo,
                                       KeyType nodekey,
                                       char* attrname, 
                                       bool writetoNodeMap)
{
  // get the node with the given key. 
  DM_DataNode* node = getDataNode(idmap, fileinfo, nodekey, writetoNodeMap);
  DM_AttributeNode* attrnode;

  if (node == NULL)
    {
      // node with the given key does not exist in the database. 
      globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"NavigationHandler",__FILE__,"The specified node does not exist.");  
      return NULL;
    }

  else if (node->getFlag() == ELEMENT_NODE)
    {
      // the node is an element node, get its attribute
      KeyType attrkey = ((DM_ElementNode*) node)->getAttributes();

      if (attrkey == -1)	
        // the element has no attribute
        return NULL;
      else
        {
          // get the attribute node.
          attrnode = (DM_AttributeNode*) getDataNode(idmap,  fileinfo, attrkey, writetoNodeMap);
          if (attrnode == NULL) 
            // the attribute node does not exist
            return NULL;
        }
    }

  else if (node->getFlag() == ATTRIBUTE_NODE)
    // the node itself is an attribute node
    attrnode = (DM_AttributeNode*) node;
	
  else
    {
      // the node is not an element node or attribute node, report error
      globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"NavigationHandler",__FILE__,"The specified node is an element node and could not have an attribute.");  
      return NULL;
    }

  // get the attribute value. 
  Value* val = ((DM_AttributeNode*) attrnode)->getAttr(attrname);
  if (val == NULL)
    {
      // there is no attribute with the given name
      globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"NavigationHandler",__FILE__,"There is no attribute with that name.");  
      return NULL;
    }
  else return val;
}

