/*
COPYRIGHT  � 2000-2004 
THE REGENTS OF THE UNIVERSITY OF MICHIGAN
ALL RIGHTS RESERVED

PERMISSION IS GRANTED TO USE, COPY, CREATE DERIVATIVE WORKS AND
REDISTRIBUTE THIS SOFTWARE AND SUCH DERIVATIVE WORKS FOR NONCOMMERCIAL
EDUCATION AND RESEARCH PURPOSES, SO LONG AS NO FEE IS CHARGED, AND SO
LONG AS THE COPYRIGHT NOTICE ABOVE, THIS GRANT OF PERMISSION, AND THE
DISCLAIMER BELOW APPEAR IN ALL COPIES MADE; AND SO LONG AS THE NAME OF
THE UNIVERSITY OF MICHIGAN IS NOT USED IN ANY ADVERTISING OR PUBLICITY
PERTAINING TO THE USE OR DISTRIBUTION OF THIS SOFTWARE WITHOUT
SPECIFIC, WRITTEN PRIOR AUTHORIZATION.

THIS SOFTWARE IS PROVIDED AS IS, WITHOUT REPRESENTATION FROM THE
UNIVERSITY OF MICHIGAN AS TO ITS FITNESS FOR ANY PURPOSE, AND WITHOUT
WARRANTY BY THE UNIVERSITY OF MICHIGAN OF ANY KIND, EITHER EXPRESS OR
IMPLIED, INCLUDING WITHOUT LIMITATION THE IMPLIED WARRANTIES OF
MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE. THE REGENTS OF
THE UNIVERSITY OF MICHIGAN SHALL NOT BE LIABLE FOR ANY DAMAGES,
INCLUDING SPECIAL, INDIRECT, INCIDENTAL, OR CONSEQUENTIAL DAMAGES,
WITH RESPECT TO ANY CLAIM ARISING OUT OF OR IN CONNECTION WITH THE USE
OF THE SOFTWARE, EVEN IF IT HAS BEEN OR IS HEREAFTER ADVISED OF THE
POSSIBILITY OF SUCH DAMAGES.
*/

#ifndef __DynamicFileTable_H
#define __DynamicFileTable_H
#include <timber-compat.h>

#include "DynamicFileTableItem.h"

// the number of tables that can be opened at the same time. 
#define DYNAMICFILETABLE_LIST_SIZE		 16

/**
* class DynamicFileTable
* 
* This class keeps tract of all the data files opened. 
* 
* When a file is opened, a dynamic ID is assigned to it and an item is added to this table
* It keeps the information of the data file and keeps track of the operations on the data file, 
* such as the scan. 
*
* DynamicFileTable has fixed number of items for opened files, which gives the upper bound of 
* the number of files that can be opened at the same time. 
*
* @see DynamicFileTableItem
* @see FileHandler
* 
* @author Yuqing Melanie Wu
* @version 1.0
*/


class DynamicFileTable  
{
public:
	/**
	* Constructor
	* Initialize variables to default value. 
	*/
	DynamicFileTable();

	/**
	* Default Destructor
	*/
	virtual ~DynamicFileTable();
	
	/**
	* Process Method
	* 
	* Find an available dynamicfile ID and reserve it for a file. 
	* 
	* The size of DynamicFileTable has a upper-bound, which defines the number of 
	* files that can be opened at the same time. 
	*
	* @returns The dynamic file id reserved, if there is still space available. Otherwise, -1. 
	*/
	FileIDType	getNewDynamicFileID();

	/**
	* Process Method
	*
	* Take an available DynamicFileTableItem and assign it to the data file. 
	*
	* @param filename The name of the file to be inserted into the DynamicFileTable.
	* @returns The dynamic file id assigned to the file, -1 of the dynamicFileTable is full. 
	*/
	FileIDType	newItem(char* filename);

	/**
	* Access Method
	* Get the total number of valid items in the DynamicFileTable.
	* @returns The total number of valid items in the DynamicFileTable
	*/
	int			getItemNumber();

	/**
	* Access Method
	* Get the information about the data file, given the dynamic id .
	* @param dynamicid The dynamic file id of the file
	* @returns The information of the data file. 
	*/
	FileInfoType*	getFileInfo(const FileIDType dynamicid);

	/**
	* Access Method
	*
	* Get the name of a data file, given the dynamic file id
	* @param dynamicid The dynamic file id of a file
	* @returns The name of the data file. 
	*/
	char*			getFileName(const FileIDType dynamicid);
	
	/**
	* Access Method
	* Get the NodeIDMap associated with a data file, given the dynamic file id
	* @param dynamicid The dynamic file id of a file
	* @returns The NodeIDMap associated with the data file.
	*/
	NodeIDMap*		getCurrentNodeIDMap(const FileIDType dynamicid);

	/**
	* Access Method
	*
	* Check whether the file info of a given file has been changed while the file is open
	*
	* @param The dynamic id of the file
	* @returns A boolean value that indicate whether the file info has been changed
	*/
	bool fileInfoIsChanged(const FileIDType dynamicid);


	/**
	* Process Method
	* Find the DynamicFileTableItem, given the name of the data file
	* @param filename The name of a data file
	* @returns The DynamicFileTableItem which contains information of the file.
	*/
	DynamicFileTableItem* findItemByFileName(char* filename);;

	/**
	* Process Method
	*
	* Find the dynamic id of a file, given the filename
	* @param filename The name of a data file 
	* @returns The dynamicfile id of the DynamicFileTableItem , which stores informaiton about the data file with the give name. 
	*/
	FileIDType findDynamicIDByFileName(char* filename);
	
	/**
	* Set Method
	* Set the information of a data file to the DynamicFileTableItem with the given id.  
	* @param dynamicid The dynamic file id of the DynamicFileTableItem that stores the info about the data file. 
	* @param fileinfo The information about the data file.
	*/
	void		setFileInfo(const FileIDType dynamicid, FileInfoType* fileinfo);
	
	/**
	* Set Method
	* Set the NodeIDMap associated with a data file to the DynamicFileTableItem which stores the info about the data file. 
	* @param dynamicid The dynamic file id of the file.
	* @param nodemap The NodeIDMap associated with the file
	*/
	void		setNodeMap(const FileIDType dynamicid, NodeIDMap* nodemap);

	/**
	* Process Method
	* Invalidate the DynamicFileTableItem in the DynamicFileTable, which has the given id. 
	* @param dynamicid The dynamic file id of the file to be removed from the DynamicFileTable.
	*/
	void		invalidate(FileIDType dynamicid);

	/**
	* Access Method
	* Get the ScanTable associated with a data file, given the dynamic file id of the file. 
	* @param dynamicid The dynamic file id of a file
	* @returns The ScanTable associated with the file
	*/
	ScanTable*	getScanTable(const FileIDType dynamicid);

	/**
	* Process Method
	* Reserve a new scan id for a coming scan in the ScanTable associated with a data file, 
	* given the dynamic id of the file. 
	* @param dynamicid The dynamic file id of the data file. 
	* @returns The scan id reserved. -1 if no more scan can be openned on the file. 
	*/
	ScanIDType getNewScanID(const FileIDType dynamicid);


	/**
	* Process Method
	* Validate a scan for a data file with the given id, but providing information about the scan. 
	* 
	* @param fileid The dynamic id of the data file.
	* @param scanid The reserved scan id for the scan. 
	* @param scaninfo The information about the scan, at physical data management level. 
	* @param writetonodemap A boolean value which indicate whether the results of the scan are to be written to the memory buffer (NodeIDMap). 
	* @returns Error code. 
	*/
	int validateScan(FileIDType fileid, 
		ScanIDType scanid, 
		ScanInfo* scaninfo, bool writetonodemap);

	/**
	* Process Method
	* Invalidate a scan, with the given dynamic file id and scan id
	* @param dynamicid The dynamic file id of a file
	* @param scanid The scanid of the scan.
	* @returns Error code. 
	*/
	int invalidateScan(FileIDType fileid, ScanIDType scanid);

	/**
	* Access Method
	* Get the information about a scan, given the dynamic file id and scan id.
	*
	* @param dynamicid The dynamic file id of a file
	* @param scanid The scanid of the scan
	* @returns A ScanTableItem, which contains information about the scan. 
	*/
	ScanTableItem* getScan(const FileIDType dynamicid, 
					const ScanIDType scanid);

	/**
	* Process Method
	* Check whether a scan with given scanid is still valid .
	*
	* @param dynamicid The dynamic file id of a file.
	* @param scanid The scanid of the scan.
	* @returns A boolean value which indicate whether the scan is still valid.
	*/
	bool		checkScanValid(const FileIDType dynamicid, 
					const ScanIDType scanid);


	/**
	* Debug Method
	* Print information of each of the items in the DynamicFileTable
	*/
	void printValue();

private:
	/**
	* Total number of items in the DynamicFileTable
	* 
	* This is the total number of opened files in the system
	*/
	int itemNumber;

	/**
	* The Largest dynamic file id assigned to an opened file
	* Used to keep each dynamic file id unique
	*/
	FileIDType largestDynamicID;

	/**
	* The list of DynamicFileTableItems
	* 
	* Since the queue is not long, use linear search to find an item.
	* When insert a new item, add it at the end of the list.
	* When remove an item, move the last item to the empty position.
	*/
	DynamicFileTableItem itemList[DYNAMICFILETABLE_LIST_SIZE];

	/**
	* Bitmap which indicate which items in the list are valid.
	*/
	bool valid[DYNAMICFILETABLE_LIST_SIZE];
};


#endif

