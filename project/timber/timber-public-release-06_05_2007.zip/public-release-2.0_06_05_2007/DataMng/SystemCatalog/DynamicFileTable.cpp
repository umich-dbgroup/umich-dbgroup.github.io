/*
COPYRIGHT  � 2000-2004 
THE REGENTS OF THE UNIVERSITY OF MICHIGAN
ALL RIGHTS RESERVED

PERMISSION IS GRANTED TO USE, COPY, CREATE DERIVATIVE WORKS AND
REDISTRIBUTE THIS SOFTWARE AND SUCH DERIVATIVE WORKS FOR NONCOMMERCIAL
EDUCATION AND RESEARCH PURPOSES, SO LONG AS NO FEE IS CHARGED, AND SO
LONG AS THE COPYRIGHT NOTICE ABOVE, THIS GRANT OF PERMISSION, AND THE
DISCLAIMER BELOW APPEAR IN ALL COPIES MADE; AND SO LONG AS THE NAME OF
THE UNIVERSITY OF MICHIGAN IS NOT USED IN ANY ADVERTISING OR PUBLICITY
PERTAINING TO THE USE OR DISTRIBUTION OF THIS SOFTWARE WITHOUT
SPECIFIC, WRITTEN PRIOR AUTHORIZATION.

THIS SOFTWARE IS PROVIDED AS IS, WITHOUT REPRESENTATION FROM THE
UNIVERSITY OF MICHIGAN AS TO ITS FITNESS FOR ANY PURPOSE, AND WITHOUT
WARRANTY BY THE UNIVERSITY OF MICHIGAN OF ANY KIND, EITHER EXPRESS OR
IMPLIED, INCLUDING WITHOUT LIMITATION THE IMPLIED WARRANTIES OF
MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE. THE REGENTS OF
THE UNIVERSITY OF MICHIGAN SHALL NOT BE LIABLE FOR ANY DAMAGES,
INCLUDING SPECIAL, INDIRECT, INCIDENTAL, OR CONSEQUENTIAL DAMAGES,
WITH RESPECT TO ANY CLAIM ARISING OUT OF OR IN CONNECTION WITH THE USE
OF THE SOFTWARE, EVEN IF IT HAS BEEN OR IS HEREAFTER ADVISED OF THE
POSSIBILITY OF SUCH DAMAGES.
*/

#include "DynamicFileTable.h"
#include "../../Utilities/ErrorInfoClass.h"

/**
* class DynamicFileTable
* 
* This class keeps tract of all the data files opened. 
* 
* When a file is opened, a dynamic ID is assigned to it and an item is added to this table
* It keeps the information of the data file and keeps track of the operations on the data file, 
* such as the scan. 
*
* DynamicFileTable has fixed number of items for opened files, which gives the upper bound of 
* the number of files that can be opened at the same time. 
*
* @see DynamicFileTableItem
* @see FileHandler
* 
* @author Yuqing Melanie Wu
* @version 1.0
*/

/**
* Constructor
* Initialize variables to default value. 
*/
DynamicFileTable::DynamicFileTable()
{
	this->itemNumber = 0;
	this->largestDynamicID = (FileIDType) -1;
	
	for (int i=0;i<DYNAMICFILETABLE_LIST_SIZE;i++)
		this->valid[i] = false;

}

/**
* Default Destructor
*/
DynamicFileTable::~DynamicFileTable()
{
}

	
/**
* Process Method
* 
* Find an available dynamicfile ID and reserve it for a file. 
* 
* The size of DynamicFileTable has a upper-bound, which defines the number of 
* files that can be opened at the same time. 
*
* @returns The dynamic file id reserved, if there is still space available. Otherwise, -1. 
*/

FileIDType DynamicFileTable::getNewDynamicFileID()
{
	if (this->itemNumber == DYNAMICFILETABLE_LIST_SIZE)
		return -1;
	else 
	{
		int i;
		for (i=0; i<DYNAMICFILETABLE_LIST_SIZE; i++)
			// return the first available dynamic id. 
			if (!this->valid[i]) return i;
		return -1;
	}
}

/**
* Process Method
*
* Take an available DynamicFileTableItem and assign it to the data file. 
*
* @param filename The name of the file to be inserted into the DynamicFileTable.
* @returns The dynamic file id assigned to the file, -1 of the dynamicFileTable is full. 
*/
FileIDType DynamicFileTable::newItem(char* filename )
{
	// find an free DynamicFileTableItem
	FileIDType dynid = getNewDynamicFileID();
	// if no such DynamicFileTableItem is avaialble, return -1.
	if (dynid < 0) return dynid;

	// initialize the DynamicFileTableItem with the filename given. 
	this->itemList[dynid].setFileID(dynid);
	this->itemList[dynid].setFileName(filename);

	// occupy the DynamicFileTableItem by setting  the valid flag. 
	this->valid[dynid] = true;
	this->itemNumber++;

	// return the dynamic file id. 
	return dynid;
}


/**
* Access Method
* Get the total number of valid items in the DynamicFileTable.
* @returns The total number of valid items in the DynamicFileTable
*/
int	DynamicFileTable::getItemNumber()
{
	return this->itemNumber;
}

/**
* Access Method
* Get the information about the data file, given the dynamic id .
* @param dynamicid The dynamic file id of the file
* @returns The information of the data file. 
*/
FileInfoType* DynamicFileTable::getFileInfo(const FileIDType dynamicid)
{
	if (this->valid[dynamicid])
		return this->itemList[dynamicid].getFileInfo();
	else 
		// return NULL if the DynamicFileTableItem with the given ID is not valid. 
		return NULL;
}

/**
* Access Method
*
* Get the name of a data file, given the dynamic file id
* @param dynamicid The dynamic file id of a file
* @returns The name of the data file. 
*/
char* DynamicFileTable::getFileName(const FileIDType dynamicid)
{
	if (this->valid[dynamicid])
		return this->itemList[dynamicid].getFileName();
	else 
		// return NULL if the DynamicFileTableItem with the given ID is not valid. 
		return NULL;
}

/**
* Access Method
* Get the NodeIDMap associated with a data file, given the dynamic file id
* @param dynamicid The dynamic file id of a file
* @returns The NodeIDMap associated with the data file.
*/
NodeIDMap*	DynamicFileTable::getCurrentNodeIDMap(const FileIDType dynamicid)
{
	if (this->valid[dynamicid])
		return this->itemList[dynamicid].getNodeMap();
	else return NULL;
}


/**
* Set Method
* Set the information of a data file to the DynamicFileTableItem with the given id.  
* @param dynamicid The dynamic file id of the DynamicFileTableItem that stores the info about the data file. 
* @param fileinfo The information about the data file.
*/

void DynamicFileTable::setFileInfo(const FileIDType dynamicid, FileInfoType* fileinfo)
{
	if (this->valid[dynamicid])
		this->itemList[dynamicid].setFileInfo(fileinfo);
	else 
          globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"DynamicFileTable",__FILE__,"The dynamicic does not exist.");
}


/**
* Access Method
*
* Check whether the file info of a given file has been changed while the file is open
*
* @param The dynamic id of the file
* @returns A boolean value that indicate whether the file info has been changed
*/
bool DynamicFileTable::fileInfoIsChanged(const FileIDType dynamicid)
{
	if (this->valid[dynamicid])
		return this->itemList[dynamicid].fileInfoIsChange();
	else return false;
}

/**
* Set Method
* Set the NodeIDMap associated with a data file to the DynamicFileTableItem which stores the info about the data file. 
* @param dynamicid The dynamic file id of the file.
* @param nodemap The NodeIDMap associated with the file
*/
void DynamicFileTable::setNodeMap(FileIDType dynamicid, NodeIDMap* nodemap)
{
	if (this->valid[dynamicid])
		this->itemList[dynamicid].setNodeMap(nodemap);
	else           
          globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"DynamicFileTable",__FILE__,"The dynamicic does not exist.");

}


/**
* Process Method
* Find the DynamicFileTableItem, given the name of the data file
* @param filename The name of a data file
* @returns The DynamicFileTableItem which contains information of the file.
*/
DynamicFileTableItem* DynamicFileTable::findItemByFileName(char* filename)
{
	int i;

	// going over the list, compare the file name of each valid item with the file name given
	// return the one that matches. 
	for (i=0; i<DYNAMICFILETABLE_LIST_SIZE; i++)
	{
		if (this->valid[i])
			if (strcmp(this->itemList[i].getFileName(), filename) == 0)
				return &(this->itemList[i]);
	}

	return NULL;

}

/**
* Process Method
*
* Find the dynamic id of a file, given the filename
* @param filename The name of a data file 
* @returns The dynamicfile id of the DynamicFileTableItem , which stores informaiton about the data file with the give name. 
*/
FileIDType DynamicFileTable::findDynamicIDByFileName(char* filename)
{
	DynamicFileTableItem* item = findItemByFileName(filename);
	if (item == NULL)
		return -1;
	else return item->getDynamicFileID();
}



/**
* Process Method
* Invalidate the DynamicFileTableItem in the DynamicFileTable, which has the given id. 
* @param dynamicid The dynamic file id of the file to be removed from the DynamicFileTable.
*/
void DynamicFileTable::invalidate(FileIDType dynamicid)
{
	this->itemList[dynamicid].invalidate();
	this->valid[dynamicid] = false;

	this->itemNumber--;
}

/**
* Access Method
* Get the ScanTable associated with a data file, given the dynamic file id of the file. 
* @param dynamicid The dynamic file id of a file
* @returns The ScanTable associated with the file
*/
ScanTable* DynamicFileTable::getScanTable(const FileIDType dynamicid)
{
	if (this->valid[dynamicid])
		return this->itemList[dynamicid].getScanTable();
	else 
	{
          globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"DynamicFileTable",__FILE__,"The dynamicic does not exist.");
		return NULL;
	}
}


/**
* Process Method
* Reserve a new scan id for a coming scan in the ScanTable associated with a data file, 
* given the dynamic id of the file. 
* @param dynamicid The dynamic file id of the data file. 
* @returns The scan id reserved. -1 if no more scan can be openned on the file. 
*/
ScanIDType DynamicFileTable::getNewScanID(const FileIDType dynamicid)
{
	if (this->valid[dynamicid])
	{
		// get the scan table associated with the file. 
		ScanTable* ScanTable = this->itemList[dynamicid].getScanTable();

		// get a new scan id. 
		ScanIDType scanid = ScanTable->getNewScanID();
		return scanid;
	}
	else 
	{
		// return -1 if the given file is not valid in the DynamicFileTable. 
          globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"DynamicFileTable",__FILE__,"The dynamicic does not exist.");
		return -1;
	}
}

/**
* Process Method
* Validate a scan for a data file with the given id, but providing information about the scan. 
* 
* @param fileid The dynamic id of the data file.
* @param scanid The reserved scan id for the scan. 
* @param scaninfo The information about the scan, at physical data management level. 
* @param writetonodemap A boolean value which indicate whether the results of the scan are to be written to the memory buffer (NodeIDMap). 
* @returns Error code. 
*/
int DynamicFileTable::validateScan(FileIDType fileid, 
		ScanIDType scanid, 
		ScanInfo* scaninfo, bool writetonodemap)
{
	// get the scanTable. 
	ScanTable* scanTable = this->getScanTable(fileid);

	if (scanTable != NULL)
	{
		// validate the scan table item with the given id. 
		scanTable->validate(scanid, scaninfo, writetonodemap);
		return NO_ERROR;
	}
	else
		return -1;
}



/**
* Access Method
* Get the information about a scan, given the dynamic file id and scan id.
*
* @param dynamicid The dynamic file id of a file
* @param scanid The scanid of the scan
* @returns A ScanTableItem, which contains information about the scan. 
*/

ScanTableItem* DynamicFileTable::getScan(const FileIDType dynamicid, 
									 const ScanIDType scanid)
{
	if (this->valid[dynamicid])
	{
		ScanTable* ScanTable = this->itemList[dynamicid].getScanTable();
		return ScanTable->getScan(scanid);
	}
	else 
	{
          globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"DynamicFileTable",__FILE__,"The dynamicic does not exist.");
		return NULL;
	}
}

/**
* Process Method
* Check whether a scan with given scanid is still valid .
*
* @param dynamicid The dynamic file id of a file.
* @param scanid The scanid of the scan.
* @returns A boolean value which indicate whether the scan is still valid.
*/
bool DynamicFileTable::checkScanValid(const FileIDType dynamicid, 
									const ScanIDType scanid)
{
	if (this->valid[dynamicid])
	{
		// get the scan table
		ScanTable* ScanTable = this->itemList[dynamicid].getScanTable();
		// check whether the scan is valid.
		return ScanTable->checkValid(scanid);
	}
	else 
	{
          globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"DynamicFileTable",__FILE__,"The dynamicic does not exist.");
		return false;
	}
}

/**
* Process Method
* Invalidate a scan, with the given dynamic file id and scan id
* @param dynamicid The dynamic file id of a file
* @param scanid The scanid of the scan.
* @returns Error code. 
*/
int	DynamicFileTable::invalidateScan(const FileIDType dynamicid, 
							  const ScanIDType scanid)
{
	if (this->valid[dynamicid])
	{
		ScanTable* ScanTable = this->itemList[dynamicid].getScanTable();
		ScanTable->invalidate(scanid);
		return NO_ERROR;
	}
	else 
	{
          globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"DynamicFileTable",__FILE__,"The dynamicic does not exist.");
		return -1;
	}
}


/**
* Debug Method
* Print information of each of the items in the DynamicFileTable
*/
void DynamicFileTable::printValue()
{
          globalErrorInfo.insertProblem(ERR_TYPE_NOTE,__LINE__,"DynamicFileTable",__FILE__,"Dynamic file map.");

	for (int i=0; i<DYNAMICFILETABLE_LIST_SIZE; i++)
	{
          //globalErrorInfo.insertProblem(ERR_TYPE_NOTE,__LINE__,"DynamicFileTable",__FILE__,this->valid[i]);
		if (this->valid[i])
                  globalErrorInfo.insertProblem(ERR_TYPE_NOTE,__LINE__,"DynamicFileTable",__FILE__,this->itemList[i].getFileName());
                this->itemList[i].getFileName();
	}
	
}


