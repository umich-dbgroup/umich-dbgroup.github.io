// $Id: gist_rrtree.h,v 1.3 1998/12/24 00:38:09 aoki Exp $

#ifndef GIST_RRTREE_H
#define GIST_RRTREE_H

#ifdef __GNUG__
#pragma interface "gist_rrtree.h"
#endif

#endif // GIST_RRTREE_H

