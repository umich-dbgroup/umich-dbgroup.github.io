
#ifdef COMPILE_ME

#include "NREList.hpp"

namespace Timber
{

	NREList::NREList()
	{
	}

	NREList::~NREList()
	{
	}

	int
	NREList::getSize()
	{
		return 1 ;
	}

	void 
	NREList::copy(NREList &toCopy)
	{
		//
		// Check to see if toCopy contains any entries
		// to copy from.
		//
		if (toCopy.getSize())
		{
			// This is a destructive in the sense that
			// toCopy replaces what we currently have.

			// Clear out current list
			nreList.clear() ;

			// Copy new entries in
			for (int index = 0 ; index < toCopy.getSize() ; index++)
			{
				nreList[index].push_back(toCopy.getEntryByNRE(index)) ;
			}
		}
	}

	NRE *
	NREList::getEntryByNRE(NREType nre)
	{
		nreIterator = nreList.find(nre) ;
		if (nreIterator == nreList.end())
		{
			return NULL ;
		}
		else
		{
			return (*nreIterator).second ;
		}
	}

	void 
	NREList::addOffsetToRangeOfNodes(int startValue, int endValue, int offset)
	{
		for (int i = 0 ; i < nreList.size() ; i++)
		{
			if (nreList[i].second.isEmpty())
			{
				continue ;
			}
			else
			{
				nreList[i].second->addOffsetToRangeAny(startValue, endValue, offset) ;
			}
		}
	}

	int 
	NREList::getFirstIndex(NREType nre)
	{
		NRE *node ;
		if (nreList.empty())
		{
			return -1 ;
		}
		else
		{
			node = getEntryByNRE(nre) ;
			if (node == NULL)
			{
				return -1 ;
			}
			else
			{
				return node->getFirstIndex(nre) ;
			}
		}
	}

	void 
	NREList::appendIndex(NREType nre, int index)
	{
		nreIterator = nreList.find(nre) ;
		if (nreIterator == nreList.end())
		{
			// No entry in list for this nre
			nreList[nre] = new NRE(nre) ;
			numUsedEntries++ ;
		}
		nreList[nre].appendIndex(index) ;
	}

	void 
	NREList::deleteIndex(NREType nre, int index)
	{
		nreIterator = nreList.find(nre) ;

		if (nreIterator == nreList.end())
		{
			return ;
		}

		(*nreIterator).second.deleteIndex(index) ;
		if ((*nreIterator).second.getSize() == 0)
		{
			numUsedEntries-- ;
		}
	}

	void 
	NREList::insertIndex(NREType nre, int index)
	{
		nreIterator = nreList.find(nre) ;
		if (nreIterator == nreList.end())
		{
			// No entry in list for this nre
			nreList[nre] = new NRE(nre) ;
			numUsedEntries++ ;
		}
		nreList[nre].insertIndex(index) ;
	}

	int 
	NREList::getNumUsedEntries()
	{
		return numUsedEntries ;
	}

	void 
	NREList::startScanningNRE(NREType nre)
	{
	}

	int
	NREList::getNextIndex() //?? Needed?
	{
	}

	void 
	NREList::startScanningAllTable()
	{
	}

	int 
	NREList::getNextSAT()
	{
	}

	bool 
	NREList::moreThanOneMatch(NREType nre)
	{
		nreIterator = nreList.find(nre) ;

		if (nreIterator == nreList.end())
		{
			return false ;
		}
		else
		{
			return (*nreIterator).second.moreThanOneMatch() ;
		}
	}

	bool 
	NREList::isEmpty()
	{
		return false ;
	}

} // namespace Timber

#endif

