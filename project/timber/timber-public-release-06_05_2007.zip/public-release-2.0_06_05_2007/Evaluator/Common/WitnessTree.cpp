/*
COPYRIGHT  � 2000-2004 
THE REGENTS OF THE UNIVERSITY OF MICHIGAN
ALL RIGHTS RESERVED

PERMISSION IS GRANTED TO USE, COPY, CREATE DERIVATIVE WORKS AND REDISTRIBUTE THIS SOFTWARE AND SUCH DERIVATIVE WORKS FOR 
NONCOMMERCIAL EDUCATION AND RESEARCH PURPOSES, SO LONG AS NO FEE IS CHARGED, AND SO LONG AS THE COPYRIGHT NOTICE ABOVE, 
THIS GRANT OF PERMISSION, AND THE DISCLAIMER BELOW APPEAR IN ALL COPIES MADE; AND SO LONG AS THE NAME OF THE UNIVERSITY 
OF MICHIGAN IS NOT USED IN ANY ADVERTISING OR PUBLICITY PERTAINING TO THE USE OR DISTRIBUTION OF THIS SOFTWARE WITHOUT 
SPECIFIC, WRITTEN PRIOR AUTHORIZATION.

THIS SOFTWARE IS PROVIDED AS IS, WITHOUT REPRESENTATION FROM THE UNIVERSITY OF MICHIGAN AS TO ITS FITNESS FOR ANY PURPOSE, 
AND WITHOUT WARRANTY BY THE UNIVERSITY OF MICHIGAN OF ANY KIND, EITHER EXPRESS OR IMPLIED, INCLUDING WITHOUT LIMITATION THE 
IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE. THE REGENTS OF THE UNIVERSITY OF MICHIGAN SHALL 
NOT BE LIABLE FOR ANY DAMAGES, INCLUDING SPECIAL, INDIRECT, INCIDENTAL, OR CONSEQUENTIAL DAMAGES, WITH RESPECT TO ANY CLAIM 
ARISING OUT OF OR IN CONNECTION WITH THE USE OF THE SOFTWARE, EVEN IF IT HAS BEEN OR IS HEREAFTER ADVISED OF THE POSSIBILITY 
OF SUCH DAMAGES.
*/


#include "WitnessTree.h"

WitnessTree::WitnessTree(int which, DataMng *dataMng) 
{
    bufSize = gSettings->getIntegerValue("INITIAL_TREE_SIZE",INITIAL_TREE_SIZE_DEFAULT); 
    deleteBuffersOnDestruct = true;
    bufSimple = NULL;
    bufComplex = NULL;
   
    this->dataMng = dataMng;
    if (which == LIST_NODE)
        bufSimple = new ListNode[bufSize]; 
    else
    {
        bufComplex = new ComplexListNode[bufSize];
        this->assignDataMng(dataMng);
    }
    score = -1;
    scanCursor = 0;
    nreTable = new NRETable;
    this->initialize();
};

WitnessTree::~WitnessTree() 
{
    if (deleteBuffersOnDestruct)
    {
        if (bufSimple) 
            delete [] bufSimple;
        if (bufComplex)
            delete [] bufComplex;
	delete nreTable;
    }
	
};

void WitnessTree::assignDataMng(DataMng *dataMng)
{
    for (int i=0; i<bufSize; i++)
        bufComplex[i].setDataMng(dataMng);
}

void WitnessTree::dumpBuffer(FILE* stream, bool printNRETable)
{
    fprintf(stream, "Score = %f\n",this->score);
    if (bufSimple)
    {
        for (int i=0; i<used; i++)
        {
            fprintf(stream, "%d- start pos = %f, end pos = %f, level = %d\n, offset = %d, nre = %d\n",i,
                   bufSimple[i].GetStartPos().toDouble(),bufSimple[i].GetEndPos().toDouble(),
				   bufSimple[i].GetLevel(),bufSimple[i].GetOffset(),(int) bufSimple[i].getNRE());
        }
    }
    else
    {
        for (int i=0; i<used; i++)
        {
            if (bufComplex[i].IsDummy())
                fprintf(stream, "%d- Dummy node. Content: %s. localLev = %d. nre = %d. id = %4.1f\n",i,
				bufComplex[i].GetDummyName(),bufComplex[i].GetLocalLevel(),(int)bufComplex[i].getNRE(),bufComplex[i].GetStartPos().toDouble());
            else
            {
                fprintf(stream, "%d- start pos = %f, end pos = %f, level = %d\n, offset = %d, locLev = %d, nre = %d\n",i,
                       bufComplex[i].GetStartPos().toDouble(),bufComplex[i].GetEndPos().toDouble(),
                       bufComplex[i].GetLevel(),bufComplex[i].GetOffset(),bufComplex[i].GetLocalLevel(),
					   (int)bufComplex[i].getNRE());
                
                if (bufComplex[i].GetData())
                {
                    switch (bufComplex[i].GetData()->getFlag())
                    {
                    case ELEMENT_NODE:
						fprintf(stream, "\tELEMENT NODE: data tag = %s\n",dataMng->getPhysicalDataMng()->getXMLNameTable()->getNameByCode(bufComplex[i].GetData()->getTag()));
                        break;
                    case ATTRIBUTE_NODE:
                    {
                        fprintf(stream, "\tATTRIBUTE NODE: number of attributes = %d\n",
                               ((DM_AttributeNode *)(bufComplex[i].GetData()))->getAttributeNumber());
                        for (short j=0;j<((DM_AttributeNode *)(bufComplex[i].GetData()))->getAttributeNumber(); j++)
                        {
                            //char attrName[40];
							char* attrName;
                            Value *attrVal;
                            attrVal =  ((DM_AttributeNode *)(bufComplex[i].GetData()))->getAttr(j,attrName);
                            fprintf(stream, "\t\tattr name = %s,",attrName);
                            switch (attrVal->getValueType())
                            {
                            case INT_VALUE: fprintf(stream, "attr is integer, value = %d\n",attrVal->getIntValue());
                                break;
                            case STRING_VALUE: fprintf(stream, "attr is string, value = %s\n",attrVal->getStrValue());
                                break;
                            case REAL_VALUE: fprintf(stream, "attr is real, value = %f\n",attrVal->getRealValue());
                                break;
                            }
							delete attrName;
                        }
                    }
                    break;
                    case TEXT_NODE:
                        fprintf(stream, "\tTEXT NODE: text = %s\n",
                            ((DM_CharNode *)(bufComplex[i].GetData()))->getCharValue());
                        break;
                    }
                }
                else
                    fprintf(stream, "No data.\n");
            }
        }
    }
    fprintf(stream, "\n");
	if (printNRETable)
		this->nreTable->printTable(stream);
}

void *WitnessTree::findNode(int index, bool override) 
{ 
    int actualIndex = index;//this->getActualIndex(index, override);

    if (index >= this->used && !override)
	return NULL;

    if (index >= this->bufSize)
	return NULL;

    if (actualIndex == -1)
        return NULL;

    if (bufSimple)
        return &bufSimple[actualIndex];
    else
        return &bufComplex[actualIndex];
};

DataMng *WitnessTree::getDataMng()
{
    return this->dataMng;
}

void *WitnessTree::getNodeByIndex(int index, bool override) 
{ 
    int limit = (override? bufSize : used);

    if (index >= limit)
        return NULL;
   
    if (bufSimple)
        return &bufSimple[index];
    else
        return &bufComplex[index];
}

void WitnessTree::appendList(ListNode *listToAppend,int size, bool alterNRETable)
{
    int i;

    if (bufSize <= used+size) 
        accomodate(size);

    if (bufSimple)
    {
		if (alterNRETable)
		{
			for (i=0; i < size; i++) 
			{
				bufSimple[used+i] = listToAppend[i]; 
				nreTable->appendIndex(listToAppend[i].getNRE(),used+i);
			}
		}
		else
		{
			for (i=0; i < size; i++) 
				bufSimple[used+i] = listToAppend[i]; 
		}
        used += size;
    }
    else
    {
		if (alterNRETable)
		{
			for (i=0; i < size; i++) 
			{
				bufComplex[used+i].initialize();
				bufComplex[used+i].setListNode(&listToAppend[i]);
				bufComplex[used+i].setDataMng(dataMng);
				nreTable->appendIndex(listToAppend[i].getNRE(),used+i);
			}
		}
		else
		{
			for (i=0; i < size; i++) 
			{
				bufComplex[used+i].initialize();
				bufComplex[used+i].setListNode(&listToAppend[i]);
				bufComplex[used+i].setDataMng(dataMng);
			}
		}
        used += size;
    }
}

void WitnessTree::appendList(ComplexListNode *listToAppend,DataMng *dataMng,int size, bool alterNRETable)
{
    switchToComplex(dataMng);
    int i;
    if (bufSize <= used+size) 
        accomodate(size);
   
	if (alterNRETable)
	{
		for (i=0; i < size; i++) 
		{
			bufComplex[used+i] = listToAppend[i];
			bufComplex[used+i].setDataMng(dataMng);
			nreTable->appendIndex(listToAppend[i].getNRE(),used+i);
		}
	}
	else
	{
		for (i=0; i < size; i++) 
		{
			bufComplex[used+i] = listToAppend[i];
			bufComplex[used+i].setDataMng(dataMng);
		}
	}
   
    used += size;
}


void *WitnessTree::getBuffer()
{
    if (bufSimple)
        return bufSimple;
    else
        return bufComplex;
}

void WitnessTree::initialize() 
{
    used = 0;
	this->nreTable->initialize();
}

int WitnessTree::length() 
{
    return used;
}

int WitnessTree::GetAncs(int index,int levelsUp)
{
    if (index >= used)
        return -1;
    int count = 0;
    KeyType endKey;
    if (bufComplex)
    {
        endKey = bufComplex[index].GetEndPos();
        for (int i=index-1; i>=0; i--)
        {
            if (bufComplex[i].GetEndPos() > endKey)
            {
                count++;
                if (count == levelsUp)
                    return i;
            }
        }
    }
    else
    {
        endKey = bufSimple[index].GetEndPos();
        for (int i=index-1; i>=0; i--)
        {
            if (bufSimple[i].GetEndPos() > endKey)
            {
                count++;
                if (count == levelsUp)
                    return i;
            }
        }
    }
    return -1;
}

int WitnessTree::GetChild(int index, int childNum, bool desc)
{
    if (index >= used)
        return -1;
   
    KeyType startKey , endKey;
    int level;
    if (childNum != -1)
    {
        int count = 0;
        if (bufComplex)
        {
            startKey = bufComplex[index].GetStartPos();
            endKey = bufComplex[index].GetEndPos();
            level = bufComplex[index].GetLevel();
            level++;
            for (int i=index+1; i<used; i++)
            {
                if (bufComplex[i].GetStartPos() > endKey || bufComplex[i].GetEndPos() < startKey)
                    return -1;
                else if (desc)
                    count++;
                else if (bufComplex[i].GetLevel() == level)
                    count++;
                if (count == childNum)
                    return i;
            }
        }
        else
        {
            startKey = bufSimple[index].GetStartPos();
            endKey = bufSimple[index].GetEndPos();
            level = bufSimple[index].GetLevel();
            level++;
            for (int i=index+1; i<used; i++)
            {
                if (bufSimple[i].GetStartPos() > endKey || bufSimple[i].GetEndPos() < startKey)
                    return -1;
                else if (desc)
                    count++;
                else if (bufSimple[i].GetLevel() == level)
                    count++;
                if (count == childNum)
                    return i;
            }
        }
    }
    else
    {
        int lastChild = -1;
        if (bufComplex)
        {
            startKey = bufComplex[index].GetStartPos();
            endKey = bufComplex[index].GetEndPos();
            level = bufComplex[index].GetLevel();
            level++;
            for (int i=index+1; i<used; i++)
            {
                if (bufComplex[i].GetStartPos() > endKey || bufComplex[i].GetEndPos() < startKey)
                    return lastChild;
                else if (desc)
                    lastChild = i;
                else if (bufComplex[i].GetLevel() == level)
                    lastChild = i;
            }
        }
        else
        {
            startKey = bufSimple[index].GetStartPos();
            endKey = bufSimple[index].GetEndPos();
            level = bufSimple[index].GetLevel();
            level++;
            for (int i=index+1; i<used; i++)
            {
                if (bufSimple[i].GetStartPos() > endKey || bufSimple[i].GetEndPos() < startKey)
                    return lastChild;
                else if (desc)
                    lastChild = i;
                else if (bufSimple[i].GetLevel() == level)
                    lastChild = i;
            }
        }
        return lastChild;
    }
   
    return -1;
}

int WitnessTree::getNumChildren(int index)
{
    if (index >= used)
        return -1;

    int num = 0;

    KeyType endKey;
    int level;

    if (bufSimple)
    {
        endKey = bufSimple[index].GetEndPos();
        level = bufSimple[index].GetLevel();
        level++;
        for (int i=index+1; i<used; i++)
        {
            if (bufSimple[i].GetStartPos() < endKey && bufSimple[i].GetLevel() == level)
                num++;
            else if (bufSimple[i].GetStartPos() > endKey )
                return num;
        }
    }
    else
    {
        endKey = bufComplex[index].GetEndPos();
        level = bufComplex[index].GetLevel();
        level++;
        for (int i=index+1; i<used; i++)
        {
            if (bufComplex[i].GetStartPos() < endKey && bufComplex[i].GetLevel() == level)
                num++;
            else if (bufComplex[i].GetStartPos() > endKey )
                return num;
        }
    }

	return num;
}

int WitnessTree::getSubTreeDepth(int index)
{
    if (index >= used)
        return -1;

    int numChildren = getNumChildren(index);
    if (numChildren == 0)
        return 0;
    int maxDepth = -1;
    int depth;
    for (int i=1; i<=numChildren; i++)
    {
        depth = getSubTreeDepth(GetChild(index,i));
        if (depth > maxDepth)
            maxDepth = depth;
    }
    return maxDepth+1;
}

int WitnessTree::GetLocalAncs(int index,int levelsUp)
{
    if (index >= used)
        return -1;
   
    if (bufSimple)
        return GetAncs(index,levelsUp);

    if (bufComplex[index].GetLocalLevel() == -1)
        return GetAncs(index,levelsUp);

    int count = 0;
    int level = bufComplex[index].GetLocalLevel();
    for (int i=index-1; i>=0; i--)
    {
        if (bufComplex[i].GetLocalLevel() < level)
        {
            count++;
            if (count == levelsUp)
                return i;
            level = bufComplex[i].GetLocalLevel();
        }
    }

    return -1;
}

int WitnessTree::GetLocalChild(int index, int childNum, bool desc)
{
    if (index >= used)
        return -1;

    if (bufSimple)
        return GetChild(index,childNum,desc);

    if (bufComplex[index].GetLocalLevel() == -1)
        return GetChild(index,childNum,desc);
   
    int level = bufComplex[index].GetLocalLevel();
    if (childNum != -1)
    {
        int count = 0;
        for (int i=index+1; i<used; i++)
        {
            if (bufComplex[i].GetLocalLevel() <= level)
                return -1;
            else if (desc)
                count++;
            else if (bufComplex[i].GetLocalLevel() == (level+1))
                count++;
            if (count == childNum)
                return i;
        }
    }
    else
    {
        int lastChild = -1;
        for (int i=index+1; i<used; i++)
        {
            if (bufComplex[i].GetLocalLevel() <= level)
                return lastChild;
            else if (desc)
                lastChild = i;
            else if (bufComplex[i].GetLocalLevel() == (level+1))
                lastChild = i;
        }
        return lastChild;
    }
   
    return -1;
}

int WitnessTree::getLocalNumChildren(int index)
{
    if (index >= used)
        return -1;

    if (bufSimple)
        return getNumChildren(index);

    if (bufComplex[index].GetLocalLevel() == -1)
        return getNumChildren(index);
    int num = 0;

    int level = bufComplex[index].GetLocalLevel();

    for (int i=index+1; i<used; i++)
    {
        if (bufComplex[i].GetLocalLevel() == (level+1))
            num++;
        else if (bufComplex[i].GetLocalLevel() <= level)
            return num;
    }

    return num;
}

int WitnessTree::getLocalSubTreeDepth(int index)
{
    if (index >= used)
        return -1;
   
    if (bufSimple)
        return getSubTreeDepth(index);

    if (bufComplex[index].GetLocalLevel() == -1)
        return getSubTreeDepth(index);

    int numChildren = getLocalNumChildren(index);
    if (numChildren == 0)
        return 0;
    int maxDepth = -1;
    int depth;
    for (int i=1; i<=numChildren; i++)
    {
        depth = getLocalSubTreeDepth(GetLocalChild(index,i));
        if (depth > maxDepth)
            maxDepth = depth;
    }
    return maxDepth+1;
}

bool WitnessTree::isSimple()
{
    return (bufSimple != NULL);
}

int WitnessTree::GetNextSibling(int index, bool desc)
{
    if (index >= used)
        return -1;
   
    int level;

    if (bufComplex)
    {
        level = bufComplex[index].GetLevel();
        KeyType ek = bufComplex[index].GetEndPos();
        KeyType sk = bufComplex[index].GetStartPos();
        for (int i=index+1; i<used; i++)
        {
            if (!desc)
            {
                if (bufComplex[i].GetLevel() < level)
                    return -1;
                else if (bufComplex[i].GetLevel() == level)
                    return i;
            }
            else
            {
                if (bufComplex[i].GetEndPos() < ek && 
                    bufComplex[i].GetStartPos() > sk)
                    continue;
                else
                    return i;
            }
        }
    }
    else
    {
        level = bufSimple[index].GetLevel();
        KeyType ek = bufSimple[index].GetEndPos();
        KeyType sk = bufSimple[index].GetStartPos();
        for (int i=index+1; i<used; i++)
        {
            if (!desc)
            {
                if (bufSimple[i].GetLevel() < level)
                    return -1;
                else if (bufSimple[i].GetLevel() == level)
                    return i;
            }
            else
            {
                if (bufSimple[i].GetEndPos() < ek &&
                    bufSimple[i].GetStartPos() > sk)
                    continue;
                else
                    return i;
            }
        }
    }

    return -1;
}

int WitnessTree::GetNextLocalSibling(int index, bool desc)
{
    if (index >= used)
        return -1;
   
    if (bufSimple)
        return GetNextSibling(index,desc);

    if (bufComplex[index].GetLocalLevel() == -1)
        return GetNextSibling(index,desc);

    int level = bufComplex[index].GetLocalLevel();

    for (int i=index+1; i<used; i++)
    {
        if (bufComplex[i].GetLocalLevel() < level)
            return -1;
        else if (bufComplex[i].GetLocalLevel() == level)
            return i;
    }
   
    return -1;
}

void WitnessTree::accomodate (int size)
{
    if (bufSimple) 
    {
        ListNode* temp = bufSimple;
        bufSize *= 2;
        if ((bufSize - used) < size) 
            bufSize = size+used;
	//cout << "accomodate bufSimple, bufSize = " << bufSize << endl ;
        bufSimple = new ListNode[bufSize];
        memcpy (bufSimple, temp, used*sizeof(ListNode));
        delete [] temp;
    }
    else
    {
        ComplexListNode* temp = bufComplex;
        bufSize *= 2;
        if ((bufSize - used) < size) 
            bufSize = size+used;
	//cout << "accomodate bufComplex, bufSize = " << bufSize << endl ;
        bufComplex = new ComplexListNode[bufSize];
        this->assignDataMng(dataMng);
        memcpy (bufComplex, temp, used*sizeof(ComplexListNode));
        delete [] temp;
    }
}

int compareSimple(const void *elem1,const void *elem2)
{
    if (((ListNode *)elem1)->GetStartPos() < ((ListNode *)elem2)->GetStartPos())
        return -1;
    else
        return 1;
}   

int compareComplex(const void *elem1,const void *elem2)
{
    if (((ComplexListNode *)elem1)->GetStartPos() 
        < ((ComplexListNode *)elem2)->GetStartPos())
        return -1;
    else
        return 1;
}

void WitnessTree::sortList()
{
    // sorts the list quick sort
    if (bufSimple)
        qsort(bufSimple,used,sizeof(ListNode),compareSimple);
    else
        qsort(bufComplex,used,sizeof(ComplexListNode),compareComplex);
	this->reconstructNRETable();
}

void WitnessTree::SetUsed(int newUsed)
{
    if (newUsed >= bufSize)
        accomodate(newUsed-used);
    used = newUsed;
}

void WitnessTree::overrideConstructor(int which,DataMng *dataMng)
{
    if (bufSimple)
        delete [] bufSimple;

	which = which;
    bufSimple = NULL;

    bufComplex = new ComplexListNode[bufSize];
    this->assignDataMng(dataMng);
}

void WitnessTree::switchToComplex(DataMng *dataMng)
{
    if (bufComplex)
        return;

    this->dataMng = dataMng;
    bufComplex = new ComplexListNode[bufSize];
    this->assignDataMng(dataMng);
    for (int i=0; i<used; i++)
        bufComplex[i].setListNode(&bufSimple[i]);

    delete [] bufSimple;
    bufSimple = NULL;
}

int WitnessTree::deleteNode(int index)
{
    if (index >= used)
        return FAILURE;

    if (bufSimple)
    {
		nreTable->deleteIndex(bufSimple[index].getNRE(),index);
        for (int i=index; i<used-1; i++)
            bufSimple[i] = bufSimple[i+1];
        bufSimple[used-1].initialize();
    }
    else
    {
		nreTable->deleteIndex(bufComplex[index].getNRE(),index);
        for (int i=index; i<used-1; i++)
            bufComplex[i] = bufComplex[i+1];
        bufComplex[used-1].initialize();
    }
	nreTable->addOffsetToRangeOfNodes(index+1,used-1,-1);
    used--;
    return SUCCESS;
}

int WitnessTree::deleteNodeAndDescendants(KeyType rootStartKey, KeyType rootEndKey)
{
	int numNodesDeleted = 0;

	//this is used for isDescOf that is called below... we don't need level for descendant comparisons:
	ListNode rootNode;
	rootNode.SetStartPos(rootStartKey);
	rootNode.SetEndPos(rootEndKey);

	//go backwards so that the deletions from the array don't affect the traversal:
	for (int i = used-1; i >= 0; i--) {
		if (bufSimple) {
			if (bufSimple[i].isDescOf(&rootNode)) {
				deleteNode(i);
				numNodesDeleted++;
			}
		}
		else {
			if (bufComplex[i].GetListNode()->isDescOf(&rootNode)) {
				deleteNode(i);
				numNodesDeleted++;
			}
		}
	}

	return numNodesDeleted;
}

int WitnessTree::insertNode(int index, ListNode *nodeToInsert)
{
    if (index > used)
        return FAILURE;

    if (bufSize <= used+1) 
        accomodate(1);

	nreTable->addOffsetToRangeOfNodes(index,used-1,1);
	nreTable->insertIndex(nodeToInsert->getNRE(),index);
    if (bufComplex)
    {	
        for (int i=used; i>index; i--)
            bufComplex[i] = bufComplex[i-1];
     
        bufComplex[index].setListNode(nodeToInsert);
        bufComplex[index].SetDummy(false);
        //bufComplex[index].SetData(NULL,false);
    }
    else
    {
        for (int i=used; i>index; i--)
            bufSimple[i] = bufSimple[i-1];
        bufSimple[index].initialize();
        bufSimple[index] = *nodeToInsert;
    }
    used++;
    return SUCCESS;
}
   
int WitnessTree::insertNode(int index, ComplexListNode *nodeToInsert, DataMng *dataMng)
{
    if (index > used)
        return FAILURE;
    this->dataMng = dataMng;
    if (bufSimple)
        switchToComplex(dataMng);

    if (bufSize <= used+1) 
        accomodate(1);

	nreTable->addOffsetToRangeOfNodes(index,used-1,1);
	nreTable->insertIndex(nodeToInsert->getNRE(),index);
    for (int i=used; i>index; i--)
        bufComplex[i] = bufComplex[i-1];
   
    bufComplex[index] = *nodeToInsert;
    bufComplex[index].setDataMng( dataMng);
    used++;
    return SUCCESS;
}

int WitnessTree::sortedInsertNode(ListNode *nodeToInsert, int startHint)
{
    if (bufSize <= used+1) 
        accomodate(1);

    int index;
    if (bufComplex)
    {
	int i = 0;
        for (i=startHint; i<used; i++)
        {
            if (bufComplex[i].GetStartPos() >= nodeToInsert->GetStartPos() ||
                bufComplex[i].GetLevel() < nodeToInsert->GetLevel())
                break;
        }
        index = i;
        if (bufComplex[i].GetStartPos() == nodeToInsert->GetStartPos())
            return index;
      
		nreTable->addOffsetToRangeOfNodes(index,used-1,1);
		nreTable->insertIndex(nodeToInsert->getNRE(),index);
        for (i=used; i>index; i--)
            bufComplex[i] = bufComplex[i-1];
		bufComplex[index].initialize();
        bufComplex[index].setListNode(nodeToInsert);
   //     bufComplex[index].SetDummy(false);
//        bufComplex[index].setSkipNode(false);
        bufComplex[index].setDataMng(dataMng);
    }
    else
    {
	int i = 0;
        for (i=startHint; i<used; i++)
        {
            if (bufSimple[i].GetStartPos() >= nodeToInsert->GetStartPos()||
                bufSimple[i].GetLevel() < nodeToInsert->GetLevel())
                break;
        }
        index = i;
        if (bufSimple[i].GetStartPos() == nodeToInsert->GetStartPos())
        {

            return index;
        }
		nreTable->addOffsetToRangeOfNodes(index,used-1,1);
		nreTable->insertIndex(nodeToInsert->getNRE(),index);
        for (i=used; i>index; i--)
            bufSimple[i] = bufSimple[i-1];
        bufSimple[index] = *nodeToInsert;
    }
    used++;
    return index;
}

int WitnessTree::sortedInsertNode(ComplexListNode *nodeToInsert,  DataMng *dataMng, int startHint)
{
    if (bufSize <= used+1) 
        accomodate(1);

    int index;

    this->dataMng = dataMng;
    if (bufSimple)
        this->switchToComplex(dataMng);
   
    int i = 0;
    for (i=startHint; i<used; i++)
    {
        if (bufComplex[i].GetStartPos() >= nodeToInsert->GetStartPos()||
            bufComplex[i].GetLevel() < nodeToInsert->GetLevel())
            break;
    }
    index = i;
    if (i < used)
    {
        if (bufComplex[i].GetStartPos() == nodeToInsert->GetStartPos())
        {
            bufComplex[i].setDataMng(dataMng);
//            bufComplex[i].setSkipNode(nodeToInsert->skipNode());
            return index;
        }
        for (i=used; i>index; i--)
            bufComplex[i] = bufComplex[i-1];
    }
    bufComplex[index] = *nodeToInsert;
    bufComplex[index].setDataMng(dataMng);

	nreTable->addOffsetToRangeOfNodes(index,used-1,1);
	nreTable->insertIndex(nodeToInsert->getNRE(),index);
    used++;
    return index;
}

void WitnessTree::setSimpleBuf(ListNode *newBuf, bool deleteOldBuf)
{

    if (bufSimple)
    {
        if (deleteOldBuf)
            delete [] bufSimple;
    }

    bufSimple = newBuf;

}

void WitnessTree::setComplexBuf(ComplexListNode *newBuf, bool deleteOldBuf)
{

    if (bufComplex)
    {
        if (deleteOldBuf)
            delete [] bufComplex;
    }

    bufComplex = newBuf;

}

void WitnessTree::setDeleteBuffers(bool deleteBuffersOnDestruct)
{
    this->deleteBuffersOnDestruct = deleteBuffersOnDestruct;
}

bool WitnessTree::getDeleteBuffers()
{
    return this->deleteBuffersOnDestruct;
}

void WitnessTree::setScore(double score)
{
    this->score = score;
}

double WitnessTree::getScore()
{
    return score;
}

void WitnessTree::startScan()
{
    scanCursor = 0;
}

void *WitnessTree::getNext()
{
    if (scanCursor >= used)
        return NULL;

    scanCursor++;
    if (bufSimple)
        return &bufSimple[scanCursor-1];
    else
        return &bufComplex[scanCursor-1];
}

void WitnessTree::copyTree(WitnessTree *tree)
{
	this->initialize();
	if (tree->isSimple())
		this->appendList((ListNode *)tree->getBuffer(),
														tree->length(),false);
	else
		this->appendList((ComplexListNode *)tree->getBuffer(),tree->getDataMng(),
														tree->length(),false);
	this->setScore(tree->getScore());
	this->nreTable->copyTable(tree->getNRETable());
}

void *WitnessTree::findNodeNRE(int nre)
{
	int ind = nreTable->getFirstIndex(nre);
	if (ind == FAILURE)
	{
		return NULL;
	}
	if (this->bufSimple)
		return &bufSimple[ind];
	else
		return &bufComplex[ind];
}

void WitnessTree::startFindNodesNRE(int nre)
{
	nreTable->startScanningNRE(nre);
}

void *WitnessTree::getNextNodeNRE()
{
	int ind = nreTable->getNextIndex();
	if (ind == FAILURE)
		return NULL;
	if (this->bufSimple)
		return &bufSimple[ind];
	else
		return &bufComplex[ind];

}

int WitnessTree::getNextIndexNRE()
{
	return nreTable->getNextIndex();
}

NRETable *WitnessTree::getNRETable()
{
	return this->nreTable;
}

int WitnessTree::getIndexOfNRE(NREType nre)
{
	return nreTable->getFirstIndex(nre);
}

void WitnessTree::reconstructNRETable()
{
	nreTable->initialize();
	if (bufSimple)
	{
		for (int i=0; i<used; i++)
			nreTable->appendIndex(bufSimple[i].getNRE(),i);
	}
	else
	{
		for (int i=0; i<used; i++)
			nreTable->appendIndex(bufComplex[i].getNRE(),i);
	}
}

bool WitnessTree::equalTree(WitnessTree *toBeCompared)
{
	if (used != toBeCompared->length())
		return false;

	for (int i=0; i<used; i++)
	{
		KeyType sk1 = (bufSimple? bufSimple[i].GetStartPos(): bufComplex[i].GetStartPos());
		KeyType sk2 = (toBeCompared->isSimple()?((ListNode *)toBeCompared->getNodeByIndex(i))->GetStartPos() :
						((ComplexListNode *)toBeCompared->getNodeByIndex(i))->GetStartPos());
		if (sk1 != sk2)
			return false;
	}
	return true;
}

bool WitnessTree::equalTree(WitnessTree *toBeCompared, int &index, int length)
{

	int len = 0;
	if (length == -1)
		len = (this->length() < toBeCompared->length())? this->length():toBeCompared->length();
	else 
	{
		len = length;
		if (length > this->length() || length > toBeCompared->length())
		{
			index = 0;
			return false;
		}
	}

	for (int i=0; i<len; i++)
	{
		if (this->isSimple())
		{
			if (((ListNode *)(this->getNodeByIndex(i)))->GetStartPos() 
				!= ((ListNode *)(toBeCompared->getNodeByIndex(i)))->GetStartPos())
			{
				index = i;
				return false;
			}
		}
		else
		{
			if (((ComplexListNode *)(this->getNodeByIndex(i)))->IsDummy())
			{
				if (!(((ComplexListNode *)(toBeCompared->getNodeByIndex(i)))->IsDummy()))
				{
					index = i;
					return false;
				}
				if (strcmp(((ComplexListNode *)(this->getNodeByIndex(i)))->GetDummyName(),
					((ComplexListNode *)(toBeCompared->getNodeByIndex(i)))->GetDummyName()) != 0)
				{
					index = i;
					return false;
				}
			}
			else
			{
				if (((ComplexListNode *)(toBeCompared->getNodeByIndex(i)))->IsDummy())
				{
					index = i;
					return false;
				}
				if (((ComplexListNode *)(this->getNodeByIndex(i)))->GetStartPos() 
					!= ((ComplexListNode *)(toBeCompared->getNodeByIndex(i)))->GetStartPos())
				{
					index = i;
					return false;
				}
			}
		}
	}
	return true; 
}

// Yunyao: added 02/21/2005, to calculate P/R for NaLIX
bool WitnessTree::overlapTree(WitnessTree *toBeCompared, int &overlap)
{
	if (used != toBeCompared->length())
		return false;
	
	overlap = 0;
	bool haveOverlap = false;
	

	for (int i=0; i<used; i++)
	{
		KeyType sk1 = (bufSimple? bufSimple[i].GetStartPos(): bufComplex[i].GetStartPos());

		for (int j = 0; j< toBeCompared->length(); j++)
		{
			KeyType sk2 = (toBeCompared->isSimple()?((ListNode *)toBeCompared->getNodeByIndex(j))->GetStartPos() :
						((ComplexListNode *)toBeCompared->getNodeByIndex(j))->GetStartPos());
			
			if (sk1 == sk2)
			{
				overlap++;
				haveOverlap = true;
				j++;
				break;
			}
		}
	}

	return haveOverlap;
}

bool WitnessTree::moreThanOneMatch(NREType nre)
{
	return nreTable->moreThanOneMatch(nre);
}

/**
Yunyao - 09-07-04 - Need to delete all the nodes in the buffer
**/
void WitnessTree::deleteAllNodes()
{
	// reset nreTable
	nreTable->initialize();

	if (bufSimple)
		bufSimple->initialize(); 
	else
		bufComplex->initialize(); 

	used = 0;
}

/**
Yunyao - 12-15-03 - Need to replace a node at designed position
**/
bool WitnessTree::replaceNode(ListNode * nodeToInsert, int index)
{
	if (index > used)
        return (bool)FAILURE;

    if (bufComplex)
    {           
        bufComplex[index].setListNode(nodeToInsert);
        bufComplex[index].SetDummy(false);
    }
    else
    {       
        bufSimple[index].initialize();
        bufSimple[index] = *nodeToInsert;
    }
    return (bool)SUCCESS;
}

/**
Yunyao - 12-15-03 - Need to replace a node at designed position
**/
bool WitnessTree::replaceNode(ComplexListNode * nodeToInsert, int index, DataMng *dataMng)
{
	if (index > used)
        return (bool)FAILURE;
    this->dataMng = dataMng;
    if (bufSimple)
        switchToComplex(dataMng);

    bufComplex[index] = *nodeToInsert;
    bufComplex[index].setDataMng( dataMng);

    return (bool)SUCCESS;
}

void WitnessTree::setNREByIndex(int index, NREType nre)
{
	nreTable->appendIndex(nre,index);
}

