
#ifdef COMPILE_ME

#ifndef __NRE_include_
#define __NRE_include_

#include "..\..\IndexMng\Common\IndexMng_definitions.h"
#include <vector>
using namespace std ;

namespace Timber {

class NRE {

public:
	NRE(NREType n) ;
	~NRE() ;

	void startScan() ;
	int getNextIndex() ;

	void copy(NRE &toCopy) ;

	bool isEmpty() ;

	void addOffsetToRangeAny(int startValue, int endValue, int offset) ;
	
	NREType getNRE() ;
	int getSize() ;

	void appendIndex(int index) ;
	void deleteIndex(int index) ;
	void insertIndex(int index) ;

	bool moreThanOneMatch() ;

private:

	int getNode(int index) ;

	typedef std::vector<int> IndexListTable ;
	typedef std::vector<int>::iterator IndexListTableIterator ;

	int size ;
	NREType	nre ;

	IndexListTable indexList ;
	IndexListTableIterator indexListIterator ;
	

} ; // class NRE

} ; // namespace Timber

#endif // __NRE_include_

#endif
