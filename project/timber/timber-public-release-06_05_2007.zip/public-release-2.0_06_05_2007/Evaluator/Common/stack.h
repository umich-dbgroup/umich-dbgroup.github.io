/*
COPYRIGHT  � 2000-2004 
THE REGENTS OF THE UNIVERSITY OF MICHIGAN
ALL RIGHTS RESERVED

PERMISSION IS GRANTED TO USE, COPY, CREATE DERIVATIVE WORKS AND REDISTRIBUTE THIS SOFTWARE AND SUCH DERIVATIVE WORKS FOR 
NONCOMMERCIAL EDUCATION AND RESEARCH PURPOSES, SO LONG AS NO FEE IS CHARGED, AND SO LONG AS THE COPYRIGHT NOTICE ABOVE, 
THIS GRANT OF PERMISSION, AND THE DISCLAIMER BELOW APPEAR IN ALL COPIES MADE; AND SO LONG AS THE NAME OF THE UNIVERSITY 
OF MICHIGAN IS NOT USED IN ANY ADVERTISING OR PUBLICITY PERTAINING TO THE USE OR DISTRIBUTION OF THIS SOFTWARE WITHOUT 
SPECIFIC, WRITTEN PRIOR AUTHORIZATION.

THIS SOFTWARE IS PROVIDED AS IS, WITHOUT REPRESENTATION FROM THE UNIVERSITY OF MICHIGAN AS TO ITS FITNESS FOR ANY PURPOSE, 
AND WITHOUT WARRANTY BY THE UNIVERSITY OF MICHIGAN OF ANY KIND, EITHER EXPRESS OR IMPLIED, INCLUDING WITHOUT LIMITATION THE 
IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE. THE REGENTS OF THE UNIVERSITY OF MICHIGAN SHALL 
NOT BE LIABLE FOR ANY DAMAGES, INCLUDING SPECIAL, INDIRECT, INCIDENTAL, OR CONSEQUENTIAL DAMAGES, WITH RESPECT TO ANY CLAIM 
ARISING OUT OF OR IN CONNECTION WITH THE USE OF THE SOFTWARE, EVEN IF IT HAS BEEN OR IS HEREAFTER ADVISED OF THE POSSIBILITY 
OF SUCH DAMAGES.
*/

#ifndef __stack_h
#define __stack_h
#include <timber-compat.h>

#define INITIAL_STACK_SIZE_DEFAULT 25

#include "WitnessTree.h"

/**
* A template stack class that is used in evaluating StackBased joins.
* @see StackBasedDesc
* @see StackBasedAncs
* @see StackBasedChainAncs
* @see StackBasedTwigAncs
* @see StackBasedSpecialAncs
* @author Shurug Al-Khalifa 
* @version 1.0
*/

template <class Temp> class stack
{
public:
	/**
	Constructor.
	@param stackSize is the maximum number of nodes stacked at the same time.
	**/
	stack(int stackSize = -1) 
	{
		if (stackSize <= 0)
			maxSize = gSettings->getIntegerValue("INITIAL_STACK_SIZE",INITIAL_STACK_SIZE_DEFAULT);
		else
			maxSize = stackSize;
		stk = new Temp[maxSize];
		
		top=-1;
	};
	
	/**
	Destructor.
	releases memory used by the stack.
	**/
	~stack() 
	{ 
		delete [] stk; 
	};
	
	/**
	Process Method.
	initializes the stack.
	**/
	void Initialize()
	{
		top = -1;
	}

	/**
	Access Method.
	@returns true if the stack is empty. returns false otherwise.
	**/
	bool IsEmpty()
	{
		return (top+1==0?true:false);
	}
	
	/**
	Access Method.
	@returns the number of nodes in the stack.
	**/
	int Size() 
	{
		return top+1;
	};
	
	/**
	Process Method.
	pushes a node into the stack.
	@param inNode is the node that is to be pushed in the stack.
	**/
	void push(Temp *inNode)
	{
		if (top == maxSize-1)
		{
			maxSize *=2;
			Temp *tmp = stk;
			stk = new Temp[maxSize];
			memcpy(stk,tmp,this->Size()*sizeof(Temp));
			for (int i=0; i< this->Size(); i++)
				stk[i].prepareToCopyDelete();
			delete [] tmp;
		}
		top++;
		stk[top].initialize();

		if (inNode->isSimple())
			stk[top].SetActualAncs(inNode->GetActualAncs());
		else
			stk[top].SetActualAncsComplex(inNode->GetActualAncsComplex());
		
	}
	
	void Push(Temp *node)
	{
		if (top == maxSize-1)
		{
		/*	cout<<"Error: Cannot push into the stack anymore. maxSize exceeded. in stack class."<<endl;
			return FAILURE;*/
			maxSize *=2;
			Temp *tmp = stk;
			stk = new Temp[maxSize];
			memcpy(stk,tmp,this->Size()*sizeof(Temp));
			for (int i=0; i< this->Size(); i++)
				stk[i].prepareToCopyDelete();
			delete [] tmp;
		}
		top++;
		stk[top] = *node;
	}

	/**
	Process Method.
	pushes a node into the stack.
	@param inNode is the node that is to be pushed in the stack.
	**/
	void Push(ListNode *inNode)
	{
		if (top == maxSize-1)
		{
		/*	cout<<"Error: Cannot push into the stack anymore. maxSize exceeded. in stack class."<<endl;
			return FAILURE;*/
			maxSize *=2;
			Temp *tmp = stk;
			stk = new Temp[maxSize];
			memcpy(stk,tmp,this->Size()*sizeof(Temp));
			for (int i=0; i< this->Size(); i++)
				stk[i].prepareToCopyDelete();
			delete [] tmp;
		}
		top++;
		stk[top].initialize();
	
		stk[top].SetActualAncs(inNode);
	}

	/**
	Process Method.
	pushes a node into the stack.
	@param inNode is the node that is to be pushed in the stack.
	**/
	void Push(ComplexListNode *inNode)
	{
		if (top == maxSize-1)
		{
			maxSize *=2;
			Temp *tmp = stk;
			stk = new Temp[maxSize];
			memcpy(stk,tmp,this->Size()*sizeof(Temp));
			for (int i=0; i< this->Size(); i++)
				stk[i].prepareToCopyDelete();
			delete [] tmp;
		}
		top++;
		stk[top].initialize();
	
		stk[top].SetActualAncsComplex(inNode);
	}

	void Push(WitnessTree *inTree)
	{
		if (top == maxSize-1)
		{
		/*	cout<<"Error: Cannot push into the stack anymore. maxSize exceeded. in stack class."<<endl;
			return FAILURE;*/
			maxSize *=2;
			Temp *tmp = stk;
			stk = new Temp[maxSize];
			memcpy(stk,tmp,this->Size()*sizeof(Temp));
			for (int i=0; i< this->Size(); i++)
				stk[i].prepareToCopyDelete();
			delete [] tmp;
		}
		top++;
		stk[top].initialize();
	
		stk[top].setTree(inTree);;
	}


	
	/**
	Process Method.
	pops out the top element in the stack.
	@returns the popped element.
	**/
	Temp *Pop() 
	{
        if (top < 0)
            return NULL;

		top--; 
		return &stk[top+1];
	};

	/**
	Access Method.
	gets the ith node in the stack starting from the bottom.
	@param index is the index of the node in the stack (bottom is zero).
	@returns the indexth node in the stack.
	**/
	Temp *GetByIndex(int index) 
	{
		if (index > top)
			return NULL;
		return &stk[index];
	}

	/**
	Access Method.
	gets the top node in the stack.
	@returns the top node in the stack.
	**/
	Temp *GetTop() 
	{
		if (IsEmpty())
			return NULL;
		else
			return &stk[top]; 
	}

	/**
	Access Method.
	gets the bottom node in the stack.
	@returns the bottom node in the stack.
	**/
	Temp *GetBottom() 
	{
		if (IsEmpty())
			return NULL;
		else
			return &stk[0];
	}

	/**
	Access Method.
	gets the maximum number of nodes the stack can accomodate.
	@returns the maximum number of nodes.
	**/
	int GetMaxSize()
	{
		return maxSize;
	}

/*	void insert(ComplexListNode *inNode, int index)
	{
		if (top == maxSize-1)
		{
			maxSize *=2;
			Temp *tmp = stk;
			stk = new Temp[maxSize];
			memcpy(stk,tmp,this->Size()*sizeof(Temp));
			delete [] tmp;
		}
		if (index >= maxSize-1)
		{
			maxSize = index+5;
			Temp *tmp = stk;
			stk = new Temp[maxSize];
			memcpy(stk,tmp,this->Size()*sizeof(Temp));
			delete [] tmp;
		}
		if (index > top)
		{
			startEmpty = top+1;
			endEmpty = index-1;
			top = index;
			stk[top].initialize();
	
			stk[top].SetActualAncsComplex(inNode);
		}
		else
		{

		}
	}*/
private:
	/**
	the stack itself.
	**/
	Temp *stk;

	/**
	index of top element.
	**/
	int top;

	/**
	maximum number of nodes the stack can accomodate.
	**/
	int maxSize;

/*	int numEmpty;
	int startEmpty;
	int endEmpty;*/
};



#endif

