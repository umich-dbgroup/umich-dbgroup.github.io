/*
COPYRIGHT  � 2000-2004 
THE REGENTS OF THE UNIVERSITY OF MICHIGAN
ALL RIGHTS RESERVED

PERMISSION IS GRANTED TO USE, COPY, CREATE DERIVATIVE WORKS AND REDISTRIBUTE THIS SOFTWARE AND SUCH DERIVATIVE WORKS FOR 
NONCOMMERCIAL EDUCATION AND RESEARCH PURPOSES, SO LONG AS NO FEE IS CHARGED, AND SO LONG AS THE COPYRIGHT NOTICE ABOVE, 
THIS GRANT OF PERMISSION, AND THE DISCLAIMER BELOW APPEAR IN ALL COPIES MADE; AND SO LONG AS THE NAME OF THE UNIVERSITY 
OF MICHIGAN IS NOT USED IN ANY ADVERTISING OR PUBLICITY PERTAINING TO THE USE OR DISTRIBUTION OF THIS SOFTWARE WITHOUT 
SPECIFIC, WRITTEN PRIOR AUTHORIZATION.

THIS SOFTWARE IS PROVIDED AS IS, WITHOUT REPRESENTATION FROM THE UNIVERSITY OF MICHIGAN AS TO ITS FITNESS FOR ANY PURPOSE, 
AND WITHOUT WARRANTY BY THE UNIVERSITY OF MICHIGAN OF ANY KIND, EITHER EXPRESS OR IMPLIED, INCLUDING WITHOUT LIMITATION THE 
IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE. THE REGENTS OF THE UNIVERSITY OF MICHIGAN SHALL 
NOT BE LIABLE FOR ANY DAMAGES, INCLUDING SPECIAL, INDIRECT, INCIDENTAL, OR CONSEQUENTIAL DAMAGES, WITH RESPECT TO ANY CLAIM 
ARISING OUT OF OR IN CONNECTION WITH THE USE OF THE SOFTWARE, EVEN IF IT HAS BEEN OR IS HEREAFTER ADVISED OF THE POSSIBILITY 
OF SUCH DAMAGES.
*/

#ifndef __NRETable_h 
#define __NRETable_h
#include <timber-compat.h>

#include "../../IndexMng/Common/IndexMng_definitions.h"
#define NRE_TABLE_ENTRY_INIT_CAPACITY	10

extern int globalNRETableCapacity;

class NRETableEntry
{
public:
	NRETableEntry();
	~NRETableEntry();

	void initialize();

	void startScan();

	int getNextIndex();

	int getFirstIndex();

	int getSize();

	void mergeEntry(NRETableEntry *toMerge);
	void copyEntry(NRETableEntry *toCopy);

	int *getList();

	void addOffset(int offset);

	bool isEmpty();

	void addOffsetToSpecNode(int indexValue, int offset);
	void addOffsetToRangeOfNodes(int startValue, int endValue, int offset);
	void addOffsetToRangeOfNodesAny(int startValue, int endValue, int offset);

	int findNodeWithSpecIndex(int index);

	void appendIndex(int index);
	void deleteIndex(int index);
	void insertIndex(int index);

	void printList(FILE* stream = stdout);

	bool moreThanOneMatch();
private:
	int size;
	int capacity;
	int *list;
	int cursor;
};

class NRETable
{
public:
	NRETable();
	~NRETable();

	void initialize();



	void mergeTable(NRETable *toMerge);

	void copyTable(NRETable *toCopy);
	NRETableEntry *getEntryByNRE(NREType nre);

	void startScanningNRE(NREType nre);
	int getNextIndex();
	void addOffsetToSpecNode(NREType nre, int indexValue, int offset);
	void addOffsetToRangeOfNodesWithNRE(NREType nre, int startValue, int endValue, int offset);
	void addOffsetToRangeOfNodes(int startValue, int endValue, int offset);

	int getFirstIndex(NREType nre);

	void appendIndex(NREType nre, int index);
	void deleteIndex(NREType nre, int index);
	void insertIndex(NREType nre, int index);

	void printTable(FILE* stream = stdout);

	int getNumUsedEntries();

	void startScanningAllTable();
	int getNextSAT();

	int getCapacity();

	bool moreThanOneMatch(NREType nre);

private:
	NRETableEntry *table;
	int capacity;
	NREType currNRE;
	int numUsedEntries;
};

#endif
