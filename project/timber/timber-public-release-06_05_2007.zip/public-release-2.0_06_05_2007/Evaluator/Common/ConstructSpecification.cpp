/*
COPYRIGHT  � 2000-2004 
THE REGENTS OF THE UNIVERSITY OF MICHIGAN
ALL RIGHTS RESERVED

PERMISSION IS GRANTED TO USE, COPY, CREATE DERIVATIVE WORKS AND REDISTRIBUTE THIS SOFTWARE AND SUCH DERIVATIVE WORKS FOR 
NONCOMMERCIAL EDUCATION AND RESEARCH PURPOSES, SO LONG AS NO FEE IS CHARGED, AND SO LONG AS THE COPYRIGHT NOTICE ABOVE, 
THIS GRANT OF PERMISSION, AND THE DISCLAIMER BELOW APPEAR IN ALL COPIES MADE; AND SO LONG AS THE NAME OF THE UNIVERSITY 
OF MICHIGAN IS NOT USED IN ANY ADVERTISING OR PUBLICITY PERTAINING TO THE USE OR DISTRIBUTION OF THIS SOFTWARE WITHOUT 
SPECIFIC, WRITTEN PRIOR AUTHORIZATION.

THIS SOFTWARE IS PROVIDED AS IS, WITHOUT REPRESENTATION FROM THE UNIVERSITY OF MICHIGAN AS TO ITS FITNESS FOR ANY PURPOSE, 
AND WITHOUT WARRANTY BY THE UNIVERSITY OF MICHIGAN OF ANY KIND, EITHER EXPRESS OR IMPLIED, INCLUDING WITHOUT LIMITATION THE 
IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE. THE REGENTS OF THE UNIVERSITY OF MICHIGAN SHALL 
NOT BE LIABLE FOR ANY DAMAGES, INCLUDING SPECIAL, INDIRECT, INCIDENTAL, OR CONSEQUENTIAL DAMAGES, WITH RESPECT TO ANY CLAIM 
ARISING OUT OF OR IN CONNECTION WITH THE USE OF THE SOFTWARE, EVEN IF IT HAS BEEN OR IS HEREAFTER ADVISED OF THE POSSIBILITY 
OF SUCH DAMAGES.
*/

#include "ConstructSpecification.h"


SingleConstructSpec::SingleConstructSpec()
{
	str1 = NULL;
	str2 = NULL;
	pattern = NULL;
	relation = NULL;
	getWhat = NULL;
	attrNames = NULL;
	level  = -1;
	patternRootNRE = NULL_NRE;
	rootAttrName = NULL;
	tagNames = NULL;
	assignedNRE = DEFAULT_NODES_NRE;
}


SingleConstructSpec::SingleConstructSpec(int type, int source, char *str1, char *str2, NREType patternRootNRE, ExecArrayType *pattern,
		int *relation, int *getWhat, char **attrNames, int level, NREType assignedNRE)
{
	this->type = type;
	this->source = source;
	this->str1 = str1;
	this->str2 = str2;
	this->level = level;
	this->patternRootNRE = patternRootNRE;
	this->pattern = pattern;
	this->relation = relation;
	this->getWhat = getWhat;
	this->attrNames = attrNames;
	this->rootGetWhat = CPM_GET_ITSELF;
	this->rootAttrName = NULL;
	this->nodeSource = CPM_NODE_SRC_INDEX;
	this->assignedNRE = assignedNRE;
	this->tagNames = NULL;
}

SingleConstructSpec::~SingleConstructSpec()
{
	if (str1)
		delete [] str1;
	if (str2)
		delete [] str2;
	if (attrNames)
	{
		for (int i=0; i<pattern->GetSize(); i++)
		{
			if (attrNames[i])
				delete [] attrNames[i];
		}
		delete [] attrNames;
	}
	if (tagNames)
		delete [] tagNames;
	
	if (pattern)
		delete pattern;
	if (relation)
		delete [] relation;
	if (getWhat)
		delete [] getWhat;
	if (rootAttrName)
		delete [] rootAttrName;
}

int SingleConstructSpec::getType()
{
	return type;
}

int SingleConstructSpec::getSource()
{
	return source;
}

int *SingleConstructSpec::getRelation()
{
	return relation;
}

ExecArrayType *SingleConstructSpec::getPattern()
{
	return this->pattern;
}

void SingleConstructSpec::setPattern(ExecArrayType *pattern, bool deleteOld)
{
	if (this->pattern && deleteOld)
		delete this->pattern;
	this->pattern = pattern;
}

NREType SingleConstructSpec::getPatternRootNRE()
{
	return this->patternRootNRE;
}

NREType SingleConstructSpec::getAssignedNRE()
{
	return this->assignedNRE;
}


int *SingleConstructSpec::getGetWhat()
{
	return getWhat;
}

int SingleConstructSpec::getLevel()
{
	return level;
}

char *SingleConstructSpec::getStr1()
{
	return str1;
}

char *SingleConstructSpec::getStr2()
{
	return str2;
}

char **SingleConstructSpec::getAttrNames()
{
	return this->attrNames;
}
int *SingleConstructSpec::getTagNames()
{
	return this->tagNames;
}
int SingleConstructSpec::getRootGetWhat()
{
	return this->rootGetWhat;
}


void SingleConstructSpec::setNodeSource(int nodeSource)
{
	this->nodeSource = nodeSource;
}

int SingleConstructSpec::getNodeSource()
{
	return this->nodeSource;
}

void SingleConstructSpec::setRootGetWhat(int rootGetWhat)
{
	this->rootGetWhat = rootGetWhat;
}

void SingleConstructSpec::setType(int type)
{
	this->type = type;
}

void SingleConstructSpec::setSource(int source)
{
	this->source = source;
}

void SingleConstructSpec::setRelation(int *relation, bool deleteOld)
{
	if (this->relation && deleteOld)
		delete [] this->relation;
	this->relation = relation;
}

void SingleConstructSpec::setGetWhat(int *getWhat, bool deleteOld)
{
	if (this->getWhat && deleteOld)
		delete [] this->getWhat;
	this->getWhat = getWhat;
}

void SingleConstructSpec::setAttrNames(char **attrNames, bool deleteOld)
{
	if (this->attrNames && deleteOld)
	{
		for (int i=0; i<pattern->GetSize(); i++)
		{
			if (this->attrNames[i])
				delete [] this->attrNames[i];
		}
		delete [] this->attrNames;
	}
	this->attrNames = attrNames;
}
void SingleConstructSpec::setTagNames(int *tagNames, bool deleteOld)
{
	if (this->tagNames && deleteOld)
		delete [] this->tagNames;
	this->tagNames = tagNames;
}

void SingleConstructSpec::setLevel(int level)
{
	this->level = level;
}

void SingleConstructSpec::setPatternRootNRE(NREType patternRootNRE)
{
	this->patternRootNRE = patternRootNRE;
}

void SingleConstructSpec::setAssignedNRE(NREType assignedNRE)
{
	this->assignedNRE = assignedNRE;
}

void SingleConstructSpec::setStr1(char *str1, bool deleteOld)
{
	if (this->str1 && deleteOld)
		delete [] this->str1;
	this->str1 = str1;
}

void SingleConstructSpec::setStr2(char *str2, bool deleteOld)
{
	if (this->str2 && deleteOld)
		delete [] this->str2;
	this->str2 = str2;
}

char *SingleConstructSpec::getRootAttrName()
{
	return this->rootAttrName;
}
	
void SingleConstructSpec::setRootAttrName(char *rootAttrName, bool deleteOld)
{
	if (this->rootAttrName && deleteOld)
		delete [] this->rootAttrName;
	this->rootAttrName = rootAttrName;
}

ConstructSpecification::ConstructSpecification(int maxSize)
{
	size = 0;
	this->maxSize = maxSize;
	this->specArray = new SingleConstructSpec[maxSize];
}

ConstructSpecification::~ConstructSpecification()
{
	delete [] specArray;
}

int ConstructSpecification::insertSpec(SingleConstructSpec *spec,int index)
{
	if (index >= maxSize)
	{
		globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"Evaluator",__FILE__,"Cannot insert in the given index. It exceeds the array size.");
		return FAILURE;
	}

	if (index > size)
	{
		globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"Evaluator",__FILE__,"Cannot insert in the given index. We will have empty garbage entries between it and size.");
		return FAILURE;
	}

	if (size == maxSize)
	{
		globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"Evaluator",__FILE__,"Cannot insert anymore. You've exceeded the array size.");
		return FAILURE;
	}

	for (int i=size; i>index; i--)
		specArray[i] = specArray[i-1];

	specArray[index] = *spec;
	size++;
	return SUCCESS;
}


int ConstructSpecification::appendSpec(SingleConstructSpec *spec)
{
	if (size == maxSize)
	{
		globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"Evaluator",__FILE__,"Cannot append to array. It exceeds the array size.");
		return FAILURE;
	}

	specArray[size] = *spec;

	size++;
	return SUCCESS;
}


SingleConstructSpec *ConstructSpecification::getSpecByIndex(int index)
{
	if (index >= size)
	{
		globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"Evaluator",__FILE__,"Cannot get spec. index exceeds array size.");
		return NULL;
	}

	return &specArray[index];
}


SingleConstructSpec *ConstructSpecification::getRoot()
{
	if (size == 0)
		return NULL;

	return &specArray[0];
}

int ConstructSpecification::getSize()
{
	return size;
}

SingleConstructSpec *ConstructSpecification::getAncs(int index, int levelsUp)
{
	if (index >= size)
	{
		globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"Evaluator",__FILE__,"Index exceeds array size.");
		return NULL;
	}
	int levels = 0;
	int lastLevel = specArray[index].getLevel();
	for (int i=index-1; i>=0; i--)
	{
		if (specArray[i].getLevel() < lastLevel)
		{
			levels++;
			if (levels == levelsUp)
				return &specArray[i];
			lastLevel = specArray[i].getLevel();
		}
	}
	return NULL;
}

SingleConstructSpec *ConstructSpecification::getChild(int index, int childNum)
{
	if (index >= size)
	{
		globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"Evaluator",__FILE__,"Index exceeds array size.");
		return NULL;
	}
	
	if (childNum != -1)
	{
		int children = 0;
		for (int i=index+1; i<size; i++)
		{
			if (specArray[i].getLevel() <= specArray[index].getLevel())
				return NULL;
			else if (specArray[i].getLevel() == (specArray[index].getLevel()+1))
			{
				children++;
				if (children == childNum)
					return &specArray[i];
			}
		}
	}
	else
	{
		SingleConstructSpec *lastChild = NULL;
		for (int i=index+1; i<size; i++)
		{
			if (specArray[i].getLevel() <= specArray[index].getLevel())
				return lastChild;
			else if (specArray[i].getLevel() == (specArray[index].getLevel()+1))
			{
				lastChild = &specArray[i];
			}
		}
	}
	return NULL;
}

SingleConstructSpec *ConstructSpecification::getSibling(int index)
{
	if (index >= size)
	{
		globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"Evaluator",__FILE__,"Index exceeds array size.");
		return NULL;
	}

	for (int i=index+1; i<size; i++)
	{
		if (specArray[i].getLevel() < specArray[index].getLevel())
			return NULL;
		else if (specArray[i].getLevel() == specArray[index].getLevel())
			return &specArray[i];
	}
	return NULL;
}

int ConstructSpecification::getAncsIndex(int index, int levelsUp)
{
	if (index >= size)
	{
		globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"Evaluator",__FILE__,"Index exceeds array size.");
		return FAILURE;
	}
	int levels = 0;
	int lastLevel = specArray[index].getLevel();
	for (int i=index-1; i>=0; i--)
	{
		if (specArray[i].getLevel() < lastLevel)
		{
			levels++;
			if (levels == levelsUp)
				return i;
			lastLevel = specArray[i].getLevel();
		}
	}
	return FAILURE;
}

int ConstructSpecification::getChildIndex(int index, int childNum)
{
	if (index >= size)
	{
		globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"Evaluator",__FILE__,"Index exceeds array size.");
		return FAILURE;
	}
	if (childNum != -1)
	{
		int children = 0;
		for (int i=index+1; i<size; i++)
		{
			if (specArray[i].getLevel() <= specArray[index].getLevel())
				return FAILURE;
			else if (specArray[i].getLevel() == (specArray[index].getLevel()+1))
			{
				children++;
				if (children == childNum)
					return i;
			}
		}
	}
	else
	{
		int lastChild = FAILURE;
		for (int i=index+1; i<size; i++)
		{
			if (specArray[i].getLevel() <= specArray[index].getLevel())
				return lastChild;
			else if (specArray[i].getLevel() == (specArray[index].getLevel()+1))
			{
				lastChild = i;
			}
		}
	}
	return FAILURE;
}

int ConstructSpecification::getSiblingIndex(int index)
{
	if (index >= size)
	{
		globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"Evaluator",__FILE__,"Index exceeds array size.");
		return FAILURE;
	}
	for (int i=index+1; i<size; i++)
	{
		if (specArray[i].getLevel() < specArray[index].getLevel())
			return FAILURE;
		else if (specArray[i].getLevel() == specArray[index].getLevel())
			return i;
	}
	return FAILURE;
}
