
#ifndef __CONTAINER_INCLUDE_
#define __CONTAINER_INCLUDE_

#include <iostream>
#include <string>
using std::istream ;
using std::ostream ;
using namespace std ;

namespace Timber {

class Container {

public:
	explicit Container(int size) ;
	explicit Container(int size, char *data) ;

	~Container() ;

	friend ostream & operator << (ostream &, const Container &) ;
	friend istream & operator >> (istream &, Container &) ;

	char *getBytes() ;
	char *getBytes(int offset) ;

	bool setBytes(int length, char *d) ;
	bool setBytes(int offset, char *d, int length) ;

	int getSize() ;
	bool setSize(int newsize) ;
	void write(string name) ;

	int getAmountUsed() ;

	void reset() ;

private:
	Container() {} ; // not available

	//char *data ;
	char data[8000] ;
	int size ;
	int amountUsed ;
	
} ;

} ;

#endif // __CONTAINER_INCLUDE_
