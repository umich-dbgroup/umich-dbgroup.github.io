/*
COPYRIGHT  � 2000-2004 
THE REGENTS OF THE UNIVERSITY OF MICHIGAN
ALL RIGHTS RESERVED

PERMISSION IS GRANTED TO USE, COPY, CREATE DERIVATIVE WORKS AND REDISTRIBUTE THIS SOFTWARE AND SUCH DERIVATIVE WORKS FOR 
NONCOMMERCIAL EDUCATION AND RESEARCH PURPOSES, SO LONG AS NO FEE IS CHARGED, AND SO LONG AS THE COPYRIGHT NOTICE ABOVE, 
THIS GRANT OF PERMISSION, AND THE DISCLAIMER BELOW APPEAR IN ALL COPIES MADE; AND SO LONG AS THE NAME OF THE UNIVERSITY 
OF MICHIGAN IS NOT USED IN ANY ADVERTISING OR PUBLICITY PERTAINING TO THE USE OR DISTRIBUTION OF THIS SOFTWARE WITHOUT 
SPECIFIC, WRITTEN PRIOR AUTHORIZATION.

THIS SOFTWARE IS PROVIDED AS IS, WITHOUT REPRESENTATION FROM THE UNIVERSITY OF MICHIGAN AS TO ITS FITNESS FOR ANY PURPOSE, 
AND WITHOUT WARRANTY BY THE UNIVERSITY OF MICHIGAN OF ANY KIND, EITHER EXPRESS OR IMPLIED, INCLUDING WITHOUT LIMITATION THE 
IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE. THE REGENTS OF THE UNIVERSITY OF MICHIGAN SHALL 
NOT BE LIABLE FOR ANY DAMAGES, INCLUDING SPECIAL, INDIRECT, INCIDENTAL, OR CONSEQUENTIAL DAMAGES, WITH RESPECT TO ANY CLAIM 
ARISING OUT OF OR IN CONNECTION WITH THE USE OF THE SOFTWARE, EVEN IF IT HAS BEEN OR IS HEREAFTER ADVISED OF THE POSSIBILITY 
OF SUCH DAMAGES.
*/

#include "ExecArrayType.h"
#include <iostream>

ExecArrayTupleType::ExecArrayTupleType()
{
	iterator = NULL;
	queryEvalNode = NULL;
	type = -1;
	index = -1;
}

ExecArrayTupleType::~ExecArrayTupleType()
{
	if (iterator)
		delete iterator;
	if (queryEvalNode)
		delete queryEvalNode;
}

void ExecArrayTupleType::SetType(int type)
{
	this->type = type;
}

int ExecArrayTupleType::GetType()
{
	return type;
}

void ExecArrayTupleType::SetLevel(int level)
{
	this->level = level;
}

int ExecArrayTupleType::GetLevel()
{
	return level;
}

void ExecArrayTupleType::setIndex(int index)
{
	this->index = index;
}

int ExecArrayTupleType::getIndex()
{
	return index;
}


void ExecArrayTupleType::SetQueryEvalNode(QueryEvaluationTreeNode *queryEvalNode)
{
	if (this->queryEvalNode)
		delete this->queryEvalNode;
	this->queryEvalNode = queryEvalNode;
}

QueryEvaluationTreeNode *ExecArrayTupleType::GetQueryEvalNode()
{
	return this->queryEvalNode;
}

void ExecArrayTupleType::SetIterator(IteratorClass *iterator)
{
	if (this->iterator)
		delete this->iterator;
	this->iterator = iterator;
}

IteratorClass *ExecArrayTupleType::GetIterator()
{
	return iterator;
}

ExecArrayType::ExecArrayType()
{
	size = 0;
}

ExecArrayType::~ExecArrayType()
{
}

void ExecArrayType::initialize()
{
	for (int i=0; i<size; i++)
	{
		execArray[i].SetIterator(NULL);  //this deletes it if it existed
		execArray[i].SetQueryEvalNode(NULL);
	}
	size = 0;
}

ExecArrayTupleType *ExecArrayType::GetEntryByIndex(int index)
{
	return &execArray[index];
}

int ExecArrayType::GetSize()
{
	return size;
}

int ExecArrayType::InsertIterInArray(IteratorClass *iter,int lev,int typ, int index)
{
	if ((size+1) == MAX_EXECUTION_NODES)
	{
		cout<<"Error: Exceeded MAX_EXECUTION_NODES. Insertion in ExecArrayType failed."<<endl;
		return FAILURE;
	}
	execArray[size].SetType(typ);
	execArray[size].SetIterator(iter);
	execArray[size].SetLevel(lev);
	execArray[size].setIndex(index);

	size++;
	return SUCCESS;
}

int ExecArrayType::InsertNodeInArray(QueryEvaluationTreeNode *queryEvalNode,int lev)
{
	if ((size+1) == MAX_EXECUTION_NODES)
	{
		cout<<"Error: Exceeded MAX_EXECUTION_NODES. Insertion in ExecArrayType failed."<<endl;
		return FAILURE;
	}
	execArray[size].SetQueryEvalNode(queryEvalNode);
	execArray[size].SetLevel(lev);

	size++;
	return SUCCESS;
}

int ExecArrayType::getParentIndex(int index)
{
	if (index == 0)
		return -1;

	for (int i=index-1; i>=0; i--)
	{
		if (execArray[i].GetLevel() < execArray[index].GetLevel())
			return i;
	}
	return -1;
}


int ExecArrayType::getChildIndex(int index)
{
	if (index == size-1)
		return -1;

	if (execArray[index+1].GetLevel() == (execArray[index].GetLevel()+1))
		return index+1;

	return -1;
}


int ExecArrayType::getSiblingIndex(int index)
{
	if (index == size-1)
		return -1;

	for (int i=index+1; i<size; i++)
	{
		if (execArray[i].GetLevel() < execArray[index].GetLevel())
			return -1;
		if (execArray[i].GetLevel() == execArray[index].GetLevel())
			return i;
	}

	return -1;
}

ExecArrayTupleType *ExecArrayType::getParent(int index)
{
	if (index == 0)
		return NULL;

	for (int i=index-1; i>=0; i--)
	{
		if (execArray[i].GetLevel() < execArray[index].GetLevel())
			return &(execArray[i]);
	}
	return NULL;
}


ExecArrayTupleType *ExecArrayType::getChild(int index)
{
	if (index == size-1)
		return NULL;

	if (execArray[index+1].GetLevel() == (execArray[index].GetLevel()+1))
		return &(execArray[index+1]);

	return NULL;
}


ExecArrayTupleType *ExecArrayType::getSibling(int index)
{
	if (index == size-1)
		return NULL;

	for (int i=index+1; i<size; i++)
	{
		if (execArray[i].GetLevel() < execArray[index].GetLevel())
			return NULL;
		if (execArray[i].GetLevel() == execArray[index].GetLevel())
			return &(execArray[i]);
	}

	return NULL;
}
