/*
COPYRIGHT  � 2000-2004 
THE REGENTS OF THE UNIVERSITY OF MICHIGAN
ALL RIGHTS RESERVED

PERMISSION IS GRANTED TO USE, COPY, CREATE DERIVATIVE WORKS AND REDISTRIBUTE THIS SOFTWARE AND SUCH DERIVATIVE WORKS FOR 
NONCOMMERCIAL EDUCATION AND RESEARCH PURPOSES, SO LONG AS NO FEE IS CHARGED, AND SO LONG AS THE COPYRIGHT NOTICE ABOVE, 
THIS GRANT OF PERMISSION, AND THE DISCLAIMER BELOW APPEAR IN ALL COPIES MADE; AND SO LONG AS THE NAME OF THE UNIVERSITY 
OF MICHIGAN IS NOT USED IN ANY ADVERTISING OR PUBLICITY PERTAINING TO THE USE OR DISTRIBUTION OF THIS SOFTWARE WITHOUT 
SPECIFIC, WRITTEN PRIOR AUTHORIZATION.

THIS SOFTWARE IS PROVIDED AS IS, WITHOUT REPRESENTATION FROM THE UNIVERSITY OF MICHIGAN AS TO ITS FITNESS FOR ANY PURPOSE, 
AND WITHOUT WARRANTY BY THE UNIVERSITY OF MICHIGAN OF ANY KIND, EITHER EXPRESS OR IMPLIED, INCLUDING WITHOUT LIMITATION THE 
IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE. THE REGENTS OF THE UNIVERSITY OF MICHIGAN SHALL 
NOT BE LIABLE FOR ANY DAMAGES, INCLUDING SPECIAL, INDIRECT, INCIDENTAL, OR CONSEQUENTIAL DAMAGES, WITH RESPECT TO ANY CLAIM 
ARISING OUT OF OR IN CONNECTION WITH THE USE OF THE SOFTWARE, EVEN IF IT HAS BEEN OR IS HEREAFTER ADVISED OF THE POSSIBILITY 
OF SUCH DAMAGES.
*/

#ifndef __ComplexListNode_h
#define __ComplexListNode_h
#include <timber-compat.h>

#include "../../IndexMng/Common/ListNode.h"
#include "../../DataMng/DataMng.h"

using std::string;


#define MAX_DUMMY_NAME 100
/**
 * a complex tree node. part of WitnessTree.
 * @see ListNode
 * @see WitnessTree 
 * @author Shurug Al-Khalifa 
 * @version 1.0
 */
class ComplexListNode 
{
public:
    /**
     * Constructor
     * Initialize the variables.
	 * @param dataMng an instancs of teh data manager.
     */
    ComplexListNode(DataMng *dataMng = NULL);

    /**
     * Destructor
     * deletes data if it is there.
     */
    ~ComplexListNode();

    /**
     * Initialization
     * Initialize the variables. called by constructor.
     */
    void initialize();

    /**
     * Process Method
     * Sets the start key.
     *@param newStartPos is the new start key to be assigned.
     */
    void SetStartPos(KeyType newStartPos);
	
    /**
     * Access Method
     * Gets the start key of the node.
     *@returns the start key.
     */
    KeyType GetStartPos();

    /**
     * Process Method
     * Sets the end key.
     *@param newEndPos is the new end key to be assigned.
     */
    void SetEndPos(KeyType newEndPos);

    /**
     * Access Method
     * Gets the end key of the node.
     *@returns the end key.
     */
    KeyType GetEndPos();

    /**
     * Process Method
     * Sets the level.
     *@param newLevel is the new level to be assigned.
     */
    void SetLevel(short newLevel);

    /**
     * Access Method
     * Gets the level of the node.
     *@returns the level.
     */
    short GetLevel();

    /**
       Process Method.
       sets the offset data member to the new value
       @param offset is the new value to be assigned to level data member.
    **/
    void SetOffset(short newOffset);

    /**
       Access Method.
       gets the value of offset data member.
       @returns offset data member.
    **/
    short GetOffset();

	NREType getNRE();
	void setNRE(NREType nre);
    /**
     * Access Method
     * Gets the actual data of the node.
     *@returns the data.
     */
    DM_DataNode *GetData();

    /**
     * Process Method
     * Sets the dummy name, which is a string. It has meaningful things only if dummy flag is set to true.
     *@param newName is the new dummy name to be assigned.
     */
    void SetDummyName(char *newName);

    /**
     * Access Method
     * Gets the dummy name of the node.
     *@returns the dummy name.
     */
    const char *GetDummyName();

    /**
     * Access Method
     * Gets the value of the flag dummy.
     *@returns the flag dummy.
     */
    bool IsDummy();

    /**
     * Process Method
     * Sets the dummy flag, which says that this node is just a dummy node.
     *@param newDummy is the new value of dummy to be assigned.
     */
    void SetDummy(bool newDummy);
	
    /**
     * Access Method
     * Gets the list node(start-end-level) in this complexlistnode.
     *@param listNode a structure to get list node in. list node is copied to it.
     */
    void GetListNode(ListNode *listNode);

    /**
     * Access Method
     * Gets the list node(start-end-level) in this complexlistnode.
     *@returns a pointer to the list node in this complexlistnode.
     */
    ListNode *GetListNode();

    /**
     * Process Method
     * Sets the local level.
     *@param newLevel is the new level to be assigned.
     */
    void SetLocalLevel(short newLevel);

    /**
     * Access Method
     * Gets the local level of the node.
     *@returns the local level.
     */
    short GetLocalLevel();

	 /**
     * Process Method
     * Sets the list node(start-end-level) in this complexlistnode.
     *@param listNode is the list node to be copied to this complex list node's list node.
     */
    void setListNode(ListNode *listNode);

	/**
	* Access Method
	* @returns true if this node is skippable. returns false otherwise.
	**/
 //  bool skipNode();

	/**
	* Process Method
	* sets the skip flag in the node.
	* @param skip is the new value to be assigned to teh flag skip.
	**/
  //  void setSkipNode(bool skip);

	/**
	* Access Method
	* @returns index of the file in the open files array where this node came from.
	**/
    char getFileIndex();

	/**
	* Process Method
	* sets the index of the file in the open files array where this node came from.
	* @param fileIndex index of the file in the open files array where this node came from.
	**/
    void setFileIndex(char fileIndex);


	/**
	* Access Method
	* returns true if this node is an ancestor of potentialDesc node.
	* @param potentialDesc is a node that we will be checking to see if it is a desc of this node.
	* @returns true if this node is an ancestor of potentialDesc node.
	**/
    bool isAncsOf(ComplexListNode *potentialDesc);

	/**
	* Access Method
	* returns true if this node is a descendant of potentialAncs node.
	* @param potentialAncs is a node that we will be checking to see if it is an ancs of this node.
	* @returns true if this node is a descendant of potentialAncs node.
	**/
    bool isDescOf(ComplexListNode *potentialAncs);

	/**
	* Access Method
	* returns true if this node's start-end interval is not contained in the interval of someNode.
	* @param someNode is a node that we will be checking to make sure that this node is not contained in.
	* @returns true if this node is not contained in someNode.
	**/
    bool isNotContainedIn(ComplexListNode *someNode);

	/**
	* Access Method
	* returns true if this node is a parent of potentialChild node.
	* @param potentialChild is a node that we will be checking to see if it is a child of this node.
	* @returns true if this node is a parent of potentialChild node.
	**/
    bool isParentOf(ComplexListNode *potentialChild);

	/**
	* Access Method
	* returns true if this node is a child of potentialParent node.
	* @param potentialParent is a node that we will be checking to see if it is a parent of this node.
	* @returns true if this node is a child of potentialParent node.
	**/
    bool isChildOf(ComplexListNode *potentialParent);

	/**
	* Process Method
	* sets the pointer to the data manager.
	* @param dataMng is a pointer to the data manager to be assigned to this node's data manager.
	**/
    void setDataMng(DataMng *dataMng);

	/**
	* Access Method
	* @returns a pointer to the data manager.
	**/
    DataMng *getDataMng();

private:
    /**
     *a start key, end key, and level triplet.
     */
    ListNode listNode;

    /**
     *a flag that indicates whether or not this node is a dummy node that
     * doesn't correspond to a real node in the database.
     */
    bool dummy;

    /**
     *if this node is a dummy node, this variable holds a string that can hold anything
     */
    string dummyName ;

    /**
     *a level used when the nodes are reordered.
     */
    short localLevel;
  //  bool skip;
    DataMng *dataMng;
};

#endif

