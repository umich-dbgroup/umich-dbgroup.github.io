/*
COPYRIGHT  � 2000-2004 
THE REGENTS OF THE UNIVERSITY OF MICHIGAN
ALL RIGHTS RESERVED

PERMISSION IS GRANTED TO USE, COPY, CREATE DERIVATIVE WORKS AND REDISTRIBUTE THIS SOFTWARE AND SUCH DERIVATIVE WORKS FOR 
NONCOMMERCIAL EDUCATION AND RESEARCH PURPOSES, SO LONG AS NO FEE IS CHARGED, AND SO LONG AS THE COPYRIGHT NOTICE ABOVE, 
THIS GRANT OF PERMISSION, AND THE DISCLAIMER BELOW APPEAR IN ALL COPIES MADE; AND SO LONG AS THE NAME OF THE UNIVERSITY 
OF MICHIGAN IS NOT USED IN ANY ADVERTISING OR PUBLICITY PERTAINING TO THE USE OR DISTRIBUTION OF THIS SOFTWARE WITHOUT 
SPECIFIC, WRITTEN PRIOR AUTHORIZATION.

THIS SOFTWARE IS PROVIDED AS IS, WITHOUT REPRESENTATION FROM THE UNIVERSITY OF MICHIGAN AS TO ITS FITNESS FOR ANY PURPOSE, 
AND WITHOUT WARRANTY BY THE UNIVERSITY OF MICHIGAN OF ANY KIND, EITHER EXPRESS OR IMPLIED, INCLUDING WITHOUT LIMITATION THE 
IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE. THE REGENTS OF THE UNIVERSITY OF MICHIGAN SHALL 
NOT BE LIABLE FOR ANY DAMAGES, INCLUDING SPECIAL, INDIRECT, INCIDENTAL, OR CONSEQUENTIAL DAMAGES, WITH RESPECT TO ANY CLAIM 
ARISING OUT OF OR IN CONNECTION WITH THE USE OF THE SOFTWARE, EVEN IF IT HAS BEEN OR IS HEREAFTER ADVISED OF THE POSSIBILITY 
OF SUCH DAMAGES.
*/

#include "OnDiskList.hpp"
#include UNISTD_IO_H
#include <timber-compat.h>
#include <string>
#include <fstream>
#include <iostream>
#ifdef HAVE_PROCESS_H
#include <process.h>
#endif
#include "../Utilities/Settings.h"
#include <sstream>
#include  <stdio.h>
#include  <stdlib.h>

#include "../../Utilities/RemoveFiles.hpp"

// #define GETPID() _getpid()

extern Settings *gSettings ;

#define GETONDISKDIR() gSettings->getStringValue("ONDISKDIR", "c:/timbertemp")
//#define GETONDISKDIR() "/tmp"

using namespace std ;

namespace Timber 
{
int OnDiskList::ppid ;
string OnDiskList::fileName = "" ;
bool OnDiskList::fileNameSet = false ;

string
OnDiskList::getStringPid()
{
	ppid = GETPID() ;

	std::stringstream ss ;
	std::string spid ;
	ss << ppid ;
	ss >> spid ;

	return spid ;
}

string
OnDiskList::setFileName()
{
	ppid = GETPID() ;
	string tempDir = GETONDISKDIR() ;

	string spid = getStringPid() ;

	string t  = tempDir + "/" + spid ;

	return t ;
}

/*
** Constructor.
*/
OnDiskList::OnDiskList()
{
}

string
OnDiskList::makeRecName(int record)
{

	if (! fileNameSet)
	{
		fileName = setFileName() ;
		fileNameSet = true ;
	}

	std::stringstream ss ;
	std::string srec ;
	ss << record ;
	ss >> srec ;
	return fileName + "_" + srec ;
}



/*
** Destructor.
*/
OnDiskList::~OnDiskList()
{
}

bool 
OnDiskList::createRecord(int record, ContainerClass *c)
{
	fstream f ;

	string fileRecord = makeRecName(record) ;

	f.open(fileRecord.c_str(), ios::out | ios::binary) ;

	if (! f.is_open())
	{
		//cout << "open failed" << endl ;
		return false ;
	}

	f << (*c) ;
	f.close() ;

	return true ;
}

/*
** Update an existing record.
*/
bool 
OnDiskList::updateRecord(int record, int offset, ContainerClass &c)
{
	fstream f ;

	string fileRecord = makeRecName(record) ;
	f.open(fileRecord.c_str(), ios::app | ios::binary) ;

	if (! f.is_open())
	{
		return false ;
	}

	f << c ;

	f.close() ;

	return true ;
}

bool
OnDiskList::getRecord(int record, ContainerClass *c)
{
	fstream f ;

	string fileRecord = makeRecName(record) ;
	f.open(fileRecord.c_str(), ios::in | ios::binary) ;

	if (! f.is_open())
	{
		return false ;
	}

	f >> (*c) ;

	f.close() ;

	return true ;
}

/*
** Setup temporary directory.
*/
bool 
OnDiskList::checkOnDiskDir()
{
	string dir = GETONDISKDIR() ;

#define F_OK 0

        int rc = _access( dir.c_str(), F_OK) ;

        if (0 == rc) {
                return true ;
        }

        return false ;
}

/*
** Cleanup temporary directory.
*/
bool 
OnDiskList::cleanupTempFiles()
{
	string files = getStringPid() + "_*" ;
	return removeFiles(GETONDISKDIR(), files) ;
}


} // namespace Timber
