
#ifdef COMPILE_ME 

#ifndef __NREList_include_
#define __NREList_include_

#include <map>
#include "NRE.hpp"

using namespace std ;
namespace Timber
{

class NREList
{

public:

	NREList() ;
	~NREList() ;

	void copy(NREList &list) ;
	NRE *getEntryByNRE(NREType nre) ;
	int getSize() ;
	bool isEmpty() ;
	void addOffsetToRangeOfNodes(int startValue, int endValue, int offset) ;

	int getFirstIndex(NREType nre) ;

	void appendIndex(NREType nre, int index) ;
	void deleteIndex(NREType nre, int index) ;
	void insertIndex(NREType nre, int index) ;

	int getNumUsedEntries() ;

	void startScanningNRE(NREType nre) ;
	int getNextIndex() ; //?? Needed?

	void startScanningAllTable() ;
	int getNextSAT() ;

	bool moreThanOneMatch(NREType nre) ;

private:

	typedef std::map<NREType, NRE *> NREListType ;
	typedef std::map<NREType, NRE *>::iterator NREListIterator ;

	NREListType nreList ;
	NREListIterator nreIterator ;

	int numUsedEntries ;

} ; // class NREList

} // namespace Timber

#endif // __NREList_include_

#endif
