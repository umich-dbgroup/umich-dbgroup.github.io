/*
COPYRIGHT  � 2000-2004 
THE REGENTS OF THE UNIVERSITY OF MICHIGAN
ALL RIGHTS RESERVED

PERMISSION IS GRANTED TO USE, COPY, CREATE DERIVATIVE WORKS AND REDISTRIBUTE THIS SOFTWARE AND SUCH DERIVATIVE WORKS FOR 
NONCOMMERCIAL EDUCATION AND RESEARCH PURPOSES, SO LONG AS NO FEE IS CHARGED, AND SO LONG AS THE COPYRIGHT NOTICE ABOVE, 
THIS GRANT OF PERMISSION, AND THE DISCLAIMER BELOW APPEAR IN ALL COPIES MADE; AND SO LONG AS THE NAME OF THE UNIVERSITY 
OF MICHIGAN IS NOT USED IN ANY ADVERTISING OR PUBLICITY PERTAINING TO THE USE OR DISTRIBUTION OF THIS SOFTWARE WITHOUT 
SPECIFIC, WRITTEN PRIOR AUTHORIZATION.

THIS SOFTWARE IS PROVIDED AS IS, WITHOUT REPRESENTATION FROM THE UNIVERSITY OF MICHIGAN AS TO ITS FITNESS FOR ANY PURPOSE, 
AND WITHOUT WARRANTY BY THE UNIVERSITY OF MICHIGAN OF ANY KIND, EITHER EXPRESS OR IMPLIED, INCLUDING WITHOUT LIMITATION THE 
IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE. THE REGENTS OF THE UNIVERSITY OF MICHIGAN SHALL 
NOT BE LIABLE FOR ANY DAMAGES, INCLUDING SPECIAL, INDIRECT, INCIDENTAL, OR CONSEQUENTIAL DAMAGES, WITH RESPECT TO ANY CLAIM 
ARISING OUT OF OR IN CONNECTION WITH THE USE OF THE SOFTWARE, EVEN IF IT HAS BEEN OR IS HEREAFTER ADVISED OF THE POSSIBILITY 
OF SUCH DAMAGES.
*/

#ifndef __EvaluatorClass_h
#define __EvaluatorClass_h
#include <timber-compat.h>
#include "ltdl.h"

#define LAST_ADDED_START_TAG		1
#define LAST_ADDED_TEXT				2
#define LAST_ADDED_ATTR				3
#define LAST_ADDED_END_TAG			4
#define LAST_ADDED_FIRST_START_TAG	5

//extern int *gNumUpdatesArray;
//extern int gNumUpdates;

//#define USE_TEXTFILE 0
#include <stdio.h>
//#include <fstream.h>
#include <stdlib.h>
#include <string>

//#ifdef WIN32
//#include <fstream>
//using namespace std;
//#else
//#include <sstream>
//using namespace std;
//#endif

#ifdef HAVE_DLOPEN
#include <dlfcn.h>
#include <glob.h>
#endif

#include "Evaluator_definitions.h"
#include "IndexMng/IndexMng/IndexMng.h"
#include "DataMng/DataMng.h"
#include "QueryEvaluationTree/QueryEvaluationTree.h"
#include "Common/ExecArrayType.h"


//consts used by the index auto-setter
#define ANCS_SORTED 0
#define DESC_SORTED 1
#define DONT_KNOW	2

//using namespace std;

// Function pointer types for dynamically loaded iterators
typedef void (*parsefuncptr_t)(EvaluatorClass*, char*, void*, QueryEvaluationTreeNode*&);
typedef char (*idfuncptr_t)(void);
typedef map<char,parsefuncptr_t> fcn_map_t;


/**
 * Test Classes: deprecated
 */
//class LoadTestObj;
//class QueryTestObj;
//class TestObj;

/**
 * This class is the Timber's query evaluator. Currently, this class reads its query plan tree from 
 * a text file. 
 * @see DataMng
 * @see IndexMng
 * @author Shurug Al-Khalifa	
 * @version 1.0
 */
class EvaluatorClass
{
public:
    /**
     * Constructor
     *
     * Initialize the evaluator.
     * @param dataMng is an instance of the data manager of Timber.
	 * @param indexMng is an instance of the index manager of Timber.
     */
    EvaluatorClass(DataMng *dataMng, IndexMng *indexMng);


    /**
     * Destructor
     *
     * frees memory used by some vars.
     */
    ~EvaluatorClass();


	/**
	* Access Method
	* returns the index manager pointer kept by evaluator.
	*/
    IndexMng *getIndexMng();

    /**
     * Static access methods.
     *
     * These methods are used by the evaluator access methods such as ValueJoin to get
     * data from the database or to perform general tree operations. 
     * Some of these methods call the corresponding data manager methods.
     */

    /**
     * Tree level method.
     *
     * This method returns the index of the node with the tag findWhat.
     * @param in is the tree to be searched.
     * @param findWhat is the element tag to be found.
     * @param dataMng is an instance of the data manager.
     * @returns index of node in the tree with the tag name findWhat. 
     * If this node is not found, it returns FAILURE. 
     */
    static int findNode(WitnessTree *in, int tag, DataMng *dataMng);

    /**
     * Tree level method.
     *
     * This method returns the text of an element node in the tree.
     * @param in is the tree to be searched.
     * @param index is the index of the element node that we need to return its text.
     * @param dataMng is an instance of the data manager.
     * @param fid is the file id of the file in the volume that the node belongs to.
     * @returns text of the index node if found. otherwise, returns NULL.
     */
   // static char *findText(WitnessTree *in, int index, int &newInd, DataMng *dataMng, FileIDType fid);
    static char *returnText(WitnessTree *in, int index, DataMng *dataMng, FileIDType fid, bool desc = false);


    /**
     * Database Access method.
     *
     * This method gets the children of a tree node and their data.
     * @param in is the input tree.
     * @param index is the index of the node in the input tree that we need to get its children.
     * @param dataMng is an instance of the data manager.
     * @param fid is the file id of the file in the volume.
     * @param skipChildren if true, the children accessed will be skippable.
     * @returns FAILURE if children were not found. Otherwise, returns index of first child inserted.
     */
    static int GetChildren(WitnessTree *in, int index, DataMng *dataMng, FileIDType fid,  NREType nre = SUPPLEMENTARY_NODES_NRE);

    /**
     * Database Access method.
     *
     * This method gets the children of a tree node and their data.
     * @param in is the input tree.
     * @param index is the index of the node in the input tree that we need to get its children.
     * @param dataMng is an instance of the data manager.
     * @param fid is the file id of the file in the volume.
     * @param skipChildren if true, the children accessed will be skippable.
     * @returns FAILURE if children were not found. Otherwise, returns index of first child inserted.
     */
    static int GetProvChildren(WitnessTree *in, int index, DataMng *dataMng, FileIDType fid, NREType nre);

	/**
     * Database Access method.
     *
     * This method gets the children text nodes of a tree node.
     * @param in is the input tree.
     * @param index is the index of the node in the input tree that we need to get its children.
     * @param dataMng is an instance of the data manager.
     * @param fid is the file id of the file in the volume.
     * @param skipChildren if true, the children accessed will be skippable.
     * @returns FAILURE if children were not found. Otherwise, returns index of first child inserted.
     */
    static int GetChildrenText(WitnessTree *in, int index, DataMng *dataMng, FileIDType fid,  NREType nre = SUPPLEMENTARY_NODES_NRE);

    /**
     * Database Access method.
     *
     * This method gets all the descendants of a tree node and their data.
     * @param in is the input tree.
     * @param index is the index of the node in the input tree that we need to get its descendants.
     * @param getThis is the name of a tag name if you want to get all descendants up to this
     * specific desc. If getThis==NULL, all descendants are retrieved.
     * @param dataMng is an instance of the data manager.
     * @param fid is the file id of the file in the volume.
	 * @param skipDesc if true, the children accessed will be skippable.
	 * @param localLevel is the local level to be set for the desc.
     */
    static void GetAllDesc(WitnessTree *in, int &index, DataMng *dataMng, FileIDType fid,short localLevel = -1, NREType nre = SUPPLEMENTARY_NODES_NRE);

	 /**
     * Database Access method.
     *
     * This method gets all the text descendants of a tree node.
     * @param in is the input tree.
     * @param index is the index of the node in the input tree that we need to get its descendants.
     * @param dataMng is an instance of the data manager.
     * @param fid is the file id of the file in the volume.
	 * @param skipDesc if true, the children accessed will be skippable.
	 * @param localLevel is the local level to be set for the desc.
     */
    static void GetAllDescText(WitnessTree *in, int &index, DataMng *dataMng, FileIDType fid, short localLevel = -1, NREType nre = SUPPLEMENTARY_NODES_NRE);

    /**
     * Database Access method.
     *
     * This method gets a specific child a tree node and its data.
     * @param in is the input tree.
     * @param index is the index of the node in the input tree that we need to get its child.
     * @param childIndex is the number of the child. i.e. 1 is first child, 2 is second and so on.
     * @param dataMng is an instance of the data manager.
     * @param fid is the file id of the file in the volume.
     * @returns FAILURE if the child was not found. Otherwise, returns index of child inserted.
     */
    static int GetChild(WitnessTree *in, int index, int childIndex, DataMng *dataMng, FileIDType fid, NREType nre = SUPPLEMENTARY_NODES_NRE);

    /**
     * Database Access method.
     *
     * This method gets the number of children of a tree node.
     * @param in is the input tree.
     * @param index is the index of the node in the input tree that we need to get its number of children.
     * @param dataMng is an instance of the data manager.
     * @param fid is the file id of the file in the volume.
     */
    static int GetNumChildren(WitnessTree *in, int index, DataMng *dataMng, FileIDType fid);

    /**
     * Database Access method.
     *
     * This method gets the depth of the subtree rooted at a node of the input tree.
     * @param in is the input tree.
     * @param index is the index of the node in the input tree that we need to get its depth.
     * @param dataMng is an instance of the data manager.
     * @param fid is the file id of the file in the volume.
     * @returns the depth of the subtree rooted at indexed node in the input tree.
     */
    static int GetSubtreeDepth(WitnessTree *in, int index, DataMng *dataMng, FileIDType fid);

    /**
     * Database Access method.
     *
     * This method gets the attributes of a specific node in the input tree.
     * @param in is the input tree.
     * @param index is the index of the node in the input tree that we need to get its attributes.
     * @param dataMng is an instance of the data manager.
     * @param fid is the file id of the file in the volume.
	 * @param skipAttr if true, the attr accessed will be skippable.
	 * @param localLevel is the local level to be set for the attr node.
     * @returns SUCCESS if the attributes were added to tree, returns FAILURE if they were not.
     */
    static int GetAttributes(WitnessTree *in, int index, DataMng *dataMng, FileIDType fid,short localLevel = -1, NREType nre = SUPPLEMENTARY_NODES_NRE);

    /**
     * Database Access method.
     *
     * This method gets the text of a specific node in the input tree.
     * @param in is the input tree.
     * @param index is the index of the node in the input tree that we need to get its text.
     * @param dataMng is an instance of the data manager.
     * @param fid is the file id of the file in the volume.
     * @param localLevel is the local level to be set for the attr node.
     * @returns FAILURE if text was not found. Otherwise, it returns the index of the first text added to the tree.
     */
    static int GetText(WitnessTree *in, int index, DataMng *dataMng, FileIDType fid, short localLevel = -1, NREType nre = SUPPLEMENTARY_NODES_NRE);

	
    /**
     * Database Access method.
     *
     * This method gets the ancs of a specific node in the input tree and its data.
     * @param in is the input tree.
     * @param index is the index of the node in the input tree that we need to get its parent.
     * @param levelsUp is the number of levels the ancs is higher than the given node. 1 is immidiate parent.
     * @param dataMng is an instance of the data manager.
     * @param fid is the file id of the file in the volume.
     * @returns FAILURE if parent was not found. otherwise it returns index of inserted parent in the tree.
     */
    static int getAncs(WitnessTree *in, int index, int levelsUp, DataMng *dataMng, FileIDType fid, NREType nre = SUPPLEMENTARY_NODES_NRE);

    /**
     * Query Evaluator Method.
     *
     * This method evaluates a query. It reads a query from a file and builds an execution plan. 
     * Then, it runs the plan.
     */
    double runQuery(char *query, int *count);

	void evaluateBatchQuery(char *option);
    void evaluateInteractiveQuery();
	void evaluateNLQuery(char *option); /* Yunyao */
	void getNamesByValue(char * filename, char * value, char names[][100], int *num, bool stem = true); /* Yunyao*/
	void runQueryNL(char * filename, char term[][100], int &count, bool printOutput = false); /* Yunyao */
	void runQueryPR(char * filename, int &precision, int &recall); /* Yunyao */
    void evaluateQueryStelios(); /* Stelios */
    void evaluateQueryNuwee (); /* Nuwee */
    bool evaluateQueryMelanie(char* xmlfilename, char* planfilename, FILE* fpOutput,  int repeates, char* outputPrefix,
                              int cpChoice, int cp, int rpChoice, float rpRate); /* Melanie */


    void setConstructOutput(bool constructOutput);
    bool getConstructOutput();

    /**
     * Query Evaluator Method.
     *
     * This method takes in a witness tree and produces an XML string output.
     * it is a recursive function.
     * @param in is the input tree.
     * @param XMLout is a pre-allocated buffer that will hold the output XML.
     * @param index is the index of the node to start with. Don't pass it.
     * @param numTabs is the number of tabs to be inserted in front of a tag. Don't pass it.
     * @returns SUCCESS if everything went fine. returns FAILURE otherwise.
     */
    int INEXoutputXML(WitnessTree *in, char *XMLout, int index = 0, int numTabs = 0);
    char *getXMLoutput();

    /**
     * File related stuff
     */
   // void testAutoPositionSetter();
    void setFileID(FileIDType fid);
    static FileIDType getFileID(int fileIndex);
	
    // static int openFile(char *fileName, DataMng *dataMng);
    // medified by Melanie
    static int openFile(char *fileName, DataMng *dataMng,
                        int cpChoice = -1, int cp = -1, int rpChoice = -1, float rpRate = -1);
	
    static char *getOpenFileName(int openFileIndex);

    /**
     * Query Evaluation.
     *
     * This method returns a pointer to the execution plan tree.
     * @param evalTree is a pointer to the evaluation tree returned by getQueryEvalTree.
     * @returns a pointer to an array containing the execution plan. Calling the last 
     * iterator in the array will evaluate the query.
     */
 
	IteratorClass *getExecTree(QueryEvaluationTree *evalTree);
	serial_t *fileIDsArray;
	int fileIDsArraySize;
	int fileIDsArrayPtr;
	int createRecID(serial_t &recID);
	NREType maxNRE;

    /**
     * Recursive function.
     *
     * This method returns an iterator that matches teh query plan node.
     * @param node is a node in teh query evaluation tree.
     * @param execArray is an array that holds the list of iterators in the execution plan.
     * @param dontInsert if this is true, no execArray is ignored. Otherwise, any newed iterator is
     *			inserted into execArray.
     * @returns a pointer to the iterator that corresponds to the query evaluation node.
     */
    IteratorClass *processQueryEvalNode(QueryEvaluationTreeNode *node);

    /**
     * Recursive function.
     *
     * This method returns a query evaluation node from a file line. It is called recursively by
     * getQueryEvalTree.
     * @param line is a line in the queryFile that we want to return the query node that
     * corresponds to it.
     * @param queryInput is a text file or a string containing the encoding of the query plan.
     * @returns a pointer to the query evaluation node that corresponds to the text line.
     */
    QueryEvaluationTreeNode *getQueryEvalNode(char *line, void *queryFile);

    /**
     * @returns a pointer to the data manager.
     */
    inline DataMng* getDataManager(void) { return dataMng; }


    /**
    * TranformString()
    *
    * Make a string lower case if INDEX_CASE_INSENSITIVE is set.
    *
    */
    void TransformString(char *str) ;

private:

    /*  
     *  Support for dynamically loaded iterator plugins
     */
    static bool plugins_loaded;

#ifdef WIN32
	static void iteratorLoad() ;
#else
    static void loadPlugins();
    static int EvaluatorClass::loadPlugin(const char* filename, lt_ptr data);
#endif
    static fcn_map_t iterator_parsers;

    /**
     * Query Evaluation.
     *
     * This method returns a query evaluation tree given a text file. It reads the text file and 
     * generates a query evaluation tree.
     * @param queryInput is text file or string that has an encoded query evaluation tree. 
     * @returns a pointer to a query evaluation tree.
     */
    QueryEvaluationTree *getQueryEvalTree(void *queryInput);
    QueryEvaluationTree *getTreeFromFile(char *fullPathFileName);
    QueryEvaluationTree *getTreeFromString(char *query);

    /**
     * 
     */
    serial_t indexID;

    /**
     * An instance of the index manager
     */
    IndexMng *indexMng;

    /**
     * An instance of the data manager
     */
    DataMng *dataMng;

    /**
     * A buffer to hold the results of the query one at a time
     */
    WitnessTree *resultBuffer;

    /**
     * A pointer to the node id map. 
     */
    NodeIDMap* nodemap;

    /**
     * id of the file to run query on.
     */
    FileIDType fileid;

    /**
     * Info of the current file.
     */
    FileInfoType *fileInfo;

    /**
     *
     */
    bool constructOutput;
    
    /**
     *
     */
//    void figureOutJoinLocations(QueryEvaluationTreeNode *pattern, int &ancs, int &desc, int &joinType,int &outLen); 

  
    /**
     * Output XML functions
     */
    char *xmlOutput;
    int xmlOutputBufferSz;
	//char *xmlOutputPtr;
	int curXmlSize;
    void accomodate(int howMany);
    void doubleXMLoutputBuffer();
    void increaseSizeOfXMLoutputBuffer(int by);
	int appendTreeToResult(WitnessTree *in, int index, int numTabs, int &length, int &lastAdded);
    int appendWitnessTreeToBufferCong(WitnessTree *in, int index, int numTabs);
	
	void copyToXMLOutput(const char *str, int howMany = -1);
	void removeLastChars(int howMany);
    // static void closeFiles(DataMng *dataMng);
    // medified by Melanie
    static void closeFiles(DataMng *dataMng, int* size = NULL, int* rpTimes = NULL);

    /**
     * File Related Methods
     */
    static int openFilesCount;
    static FileIDType openFiles[MAX_FILENUMER];
    static char openFilesNames[MAX_FILE_NAME_LENGTH][MAX_FILENUMER];

    // the following variables are added by Melanie to gain control on the node buffer size
    // bool bufParaSet;
public:
    int capacityChoice;
    int capacity;
    int	replacementChoice;
    float replacementPercentage;
private:
    int bufSizeRequired;
    int bufReplacementTimes;

	int createShoreFiles();

	char ltStr[5];
	char gtStr[5];

    void setBufPara(int cpChoice, int cp, int rpChoice, float rpRate);
    // int openFileWithPara(char *fileName, DataMng *dataMng);
    // int closeFileWIthPara(char *fileName, DataMng *dataMng);

	/**
	* Tree level method.
	*
	* This method returns the text of an element node in the tree.
	* @param in is the tree to be searched.
	* @param index is the index of the element node that we need to find 
	its text.
	* @param dataMng is an instance of the data manager.
	* @param fid is the file id of the file in the volume.
	* @returns text of the index node if found. otherwise, returns NULL.
	*/
	static char *findText(WitnessTree *in, int index, int &newInd);

public:
	int updatesCursor;

};
#endif

