
#ifdef __GroupByPlanParser_include_
#define __GroupByPlanParser_include_

#include "iPlanParser.hpp"

namespace Timber
{

class GroupByPlanParser : public iPlanParser
{
public:
	GroupByPlanParser() ;
	~GroupByPlanParser() ;
	QueryEvaluationTreeNode *parseline(char *line) ;

private:
	void cleanupState() ;
	void initState() ;
	void error(int line, char *msg) ;

	int *operation;
	int *onWhat;
	NREType *nre;
	char **attrName;
	NREType *operationNRE;
	char *groupbyAttrName ;


} ; // class GroupByPlanParser

} ; // namespace Timber

#endif // __GroupByPlanParser_include_
