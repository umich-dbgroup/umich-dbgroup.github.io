/*
COPYRIGHT  � 2000-2004 
THE REGENTS OF THE UNIVERSITY OF MICHIGAN
ALL RIGHTS RESERVED

PERMISSION IS GRANTED TO USE, COPY, CREATE DERIVATIVE WORKS AND REDISTRIBUTE THIS SOFTWARE AND SUCH DERIVATIVE WORKS FOR 
NONCOMMERCIAL EDUCATION AND RESEARCH PURPOSES, SO LONG AS NO FEE IS CHARGED, AND SO LONG AS THE COPYRIGHT NOTICE ABOVE, 
THIS GRANT OF PERMISSION, AND THE DISCLAIMER BELOW APPEAR IN ALL COPIES MADE; AND SO LONG AS THE NAME OF THE UNIVERSITY 
OF MICHIGAN IS NOT USED IN ANY ADVERTISING OR PUBLICITY PERTAINING TO THE USE OR DISTRIBUTION OF THIS SOFTWARE WITHOUT 
SPECIFIC, WRITTEN PRIOR AUTHORIZATION.

THIS SOFTWARE IS PROVIDED AS IS, WITHOUT REPRESENTATION FROM THE UNIVERSITY OF MICHIGAN AS TO ITS FITNESS FOR ANY PURPOSE, 
AND WITHOUT WARRANTY BY THE UNIVERSITY OF MICHIGAN OF ANY KIND, EITHER EXPRESS OR IMPLIED, INCLUDING WITHOUT LIMITATION THE 
IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE. THE REGENTS OF THE UNIVERSITY OF MICHIGAN SHALL 
NOT BE LIABLE FOR ANY DAMAGES, INCLUDING SPECIAL, INDIRECT, INCIDENTAL, OR CONSEQUENTIAL DAMAGES, WITH RESPECT TO ANY CLAIM 
ARISING OUT OF OR IN CONNECTION WITH THE USE OF THE SOFTWARE, EVEN IF IT HAS BEEN OR IS HEREAFTER ADVISED OF THE POSSIBILITY 
OF SUCH DAMAGES.
*/

#include "TreeLevelFunctionIterator.h"
#include <float.h>
TreeLevelFunctionIterator::TreeLevelFunctionIterator(IteratorClass *input,int length, int *operations, int *onWhat, NREType *nre, 
								  char **attrName, NREType *assignedNRE,
		DataMng *dataMng)
{
	this->input = input;
	
	this->length = length;
	this->operations = operations;
	this->onWhat = onWhat;
	this->nre = nre;
	this->attrName = attrName;
	this->assignedNRE = assignedNRE;

	this->dataMng = dataMng;

	if (operations && length > 0)
	{
		valueNum = new double[this->length];
		floatFound = new bool[this->length];
		counter = new int[this->length];
		memset(floatFound,0,length*sizeof(bool));
	}
	else
	{
		valueNum = NULL;
		floatFound = NULL;
		counter = NULL;
	}
	resultBuffer = new WitnessTree(LIST_NODE_WITH_DATA,dataMng);
}


TreeLevelFunctionIterator::~TreeLevelFunctionIterator()
{
	delete resultBuffer;
	delete input;
	if (operations)
		delete [] operations;
	if (onWhat)
		delete [] onWhat;
	if (nre)
		delete [] nre;
	if (assignedNRE)
		delete [] assignedNRE;
	if (attrName)
	{
		for (int i=0; i<length; i++)
			if (attrName[i])
				delete [] attrName[i];
		delete [] attrName;
	}
	if (valueNum)
		delete [] valueNum;
	if (floatFound)
		delete [] floatFound;
	if (counter)
		delete [] counter;
}


void TreeLevelFunctionIterator::next(WitnessTree *&node)
{
#ifdef EVAL_TIME_OUT
	clock_t currTime = clock();
	double queryDuration = (double)(currTime - gQueryStartTime) / CLOCKS_PER_SEC;
	if (queryDuration >= gTimeOutAfter)
	{
		globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"Evaluator",__FILE__,"Query Timed Out.");
		node = NULL;
		return;
	}
#endif
	if (operations == NULL)
	{
		node = NULL;
		return;
	}


	input->next(inTuple);

	//if we have no inputs, then we are done
	if (!inTuple)
	{
		node = NULL;
		return;
	}

	if (this->initializeValueHolder() == FAILURE)
	{
		node = NULL;
		return;
	}

	inTuple->switchToComplex(dataMng);

	resultBuffer->initialize();

	resultBuffer->copyTree(inTuple);


	float Xnum;
	//for each of the functions we are performing, calculate the values
	for (int i=0; i<length; i++)
	{
		inTuple->startFindNodesNRE(nre[i]);
		int index = inTuple->getNextIndexNRE();

		while (index != FAILURE)
		{
			
			if (operations[i] == OP_COUNT)
			{ //if the operation is count, then just increment the counter
				valueNum[i]++;
				index = inTuple->getNextIndexNRE();
				continue;
			}


			int res;
			//get the number value and put it in Xnum
			if (this->onWhat[i] == ON_ATTRIBUTE_NUM)
				res = getAttributeValueNum(index,i,Xnum);
			else if (onWhat[i] == ON_TEXT_NUM)
				res = getTextValueNum(index,i,Xnum);
			else if (onWhat[i] == ON_FANOUT_ACTUAL)
				res = getFanOutValue(index,Xnum);
			else if (onWhat[i] == ON_FANOUT_LOCAL)
				res = getLocalFanOutValue(index,Xnum);
			else if (onWhat[i] == ON_DEPTH_ACTUAL)
				res = getDepthValue(index,Xnum);
			else if (onWhat[i] == ON_TEXT_LOCAL_NUM)
				res = getLocalTextValueNum(index,i,Xnum);
			else if (onWhat[i] == ON_ATTR_LOCAL_NUM)
				res = getLocalAttrValueNum(index,i,Xnum);
			else if (onWhat[i] == ON_DEPTH_LOCAL)
				res = getLocalDepthValue(index,Xnum);
			else if (onWhat[i] == ON_VALUE_NUM)
				res = getValueNum(index,i,Xnum);
			else
			{
				globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"Evaluator",__FILE__,"Undefined operation passed to iterator.");
				node = NULL;
				return;
			}


			//if we are summing or averaging, we sum only (the avg will be calculated later)
			if (res == SUCCESS)
			{
				counter[i]++;
				switch (operations[i])
				{
				case OP_SUM: 
				case OP_AVG: valueNum[i] += Xnum; 
					break;
				case OP_MIN: if (Xnum < valueNum[i]) valueNum[i] = Xnum;
					break;
				case OP_MAX: if (Xnum > valueNum[i]) valueNum[i] = Xnum;
					break;
				default:
					globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"Evaluator",__FILE__,"Undefined operation passed to iterator.");
					node = NULL;
					return;
				}
			}
			else if (globalErrorInfo.doWeHaveAProblem())
			{
				node = NULL;
				return;
			}
			
			index = inTuple->getNextIndexNRE();
		}
		ComplexListNode n;
		n.SetDummy(true);

		char tmp[40];
		n.setNRE(DEFAULT_NODES_NRE);
		switch (operations[i])
		{
		case OP_SUM: 
			n.SetDummyName("<sum>");
			resultBuffer->appendList(&n,dataMng,1);
			if (counter[i] == 0)
				tmp[0] = '\0';
			else if (floatFound[i])
				this->formatFloat(valueNum[i],tmp);
			else
				sprintf(tmp,"%d",(int)floor(valueNum[i]));
			n.SetDummyName(tmp);
			break;
		case OP_COUNT: 		
			n.SetDummyName("<count>");
			resultBuffer->appendList(&n,dataMng,1);
			n.SetDummyName(itoa((int)valueNum[i],tmp,10));
			break;
		case OP_AVG: 
			n.SetDummyName("<avg>");
			resultBuffer->appendList(&n,dataMng,1);
			if (counter[i] == 0)
				tmp[0] = '\0';
			else if (floatFound[i])
				this->formatFloat((double)(valueNum[i]/counter[i]),tmp);
			else
				sprintf(tmp,"%d",(int)floor(valueNum[i]/counter[i]));
			n.SetDummyName(tmp);
			break;
		case OP_MIN: 
			n.SetDummyName("<min>");
			resultBuffer->appendList(&n,dataMng,1);
			if (counter[i] == 0)
				tmp[0] = '\0';
			else if (floatFound[i])
				this->formatFloat(valueNum[i],tmp);
			else
				sprintf(tmp,"%d",(int)floor(valueNum[i]));
				
			n.SetDummyName(tmp);
			break;
		case OP_MAX: 
			n.SetDummyName("<max>");
			resultBuffer->appendList(&n,dataMng,1);
			if (counter[i] == 0)
				tmp[0] = '\0';
			else if (floatFound[i])
				this->formatFloat(valueNum[i],tmp);
			else
				sprintf(tmp,"%d",(int)floor(valueNum[i]));
			n.SetDummyName(tmp);
			break;
		}
		n.setNRE(assignedNRE[i]);
		resultBuffer->appendList(&n,dataMng,1);
	}
	node = resultBuffer;
}

int TreeLevelFunctionIterator::initializeValueHolder()
{
	for (int i=0; i<this->length; i++)
	{
		switch (operations[i])
		{
		case OP_AVG:
		case OP_SUM: 
		case OP_COUNT: valueNum[i] = 0;  break;
		case OP_MIN: valueNum[i] = DBL_MAX;  break;
		case OP_MAX: valueNum[i] = DBL_MIN; break;
		default:
			globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"Evaluator",__FILE__,"Undefined operation passed to iterator.");
			return FAILURE;
		}
		counter[i] = 0;
	}
	return SUCCESS;
}

int TreeLevelFunctionIterator::getTextValueNum(int index, int which, float &num)
{
	//this method gets a number that is in a text node
	//getting curr file id
	FileIDType fileid;
	if (inTuple->isSimple())
		fileid = EvaluatorClass::getFileID(((ListNode *)inTuple->getNodeByIndex(index))->getFileIndex());
	else
		fileid = EvaluatorClass::getFileID(((ComplexListNode *)inTuple->getNodeByIndex(index))->getFileIndex());
	if (fileid == -1)
	{
		globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"Evaluator",__FILE__,"File is unloaded in Timber.");
		return FAILURE;
	}

	//getting the text node from DB
	char *txt = EvaluatorClass::returnText(inTuple,index,dataMng,fileid);
	if (txt == NULL)
		return FAILURE;

	if (strchr(txt,'.') != NULL)
		floatFound[which] = true;

	num =(float) atof(txt);
	delete [] txt;
	return SUCCESS;
}


int TreeLevelFunctionIterator::getLocalTextValueNum(int index, int which, float &num)
{
	int childIndex = inTuple->GetLocalChild(index);
	char *txt = NULL;
	
	while (childIndex != -1)
	{
		if (((ComplexListNode *)inTuple->getNodeByIndex(childIndex))->IsDummy())
		{
			if (strchr(((ComplexListNode *)inTuple->getNodeByIndex(childIndex))->GetDummyName(),'<') == NULL &&
				strchr(((ComplexListNode *)inTuple->getNodeByIndex(childIndex))->GetDummyName(),'@') == NULL)
			{
				if (((ComplexListNode *)inTuple->getNodeByIndex(childIndex))->GetDummyName()[0] != '\0')
				{
					if (!txt)
					{
						txt = new char[strlen(((ComplexListNode *)inTuple->getNodeByIndex(childIndex))->GetDummyName())+1];
						txt[0] = '\0';
					}
					else
					{
						char *tmp = new char[strlen(txt)+strlen(((ComplexListNode *)inTuple->getNodeByIndex(childIndex))->GetDummyName())+1];
						strcpy(tmp,txt);
						delete [] txt;
						txt = tmp;
					}
					strcat(txt,((ComplexListNode *)inTuple->getNodeByIndex(childIndex))->GetDummyName());
					//break;
				}
			}
		}
		else
		{
			if (((ComplexListNode *)inTuple->getNodeByIndex(childIndex))->GetData()->getFlag() == TEXT_NODE)
			{
				if (!txt)
				{
					txt = new char[strlen(((DM_CharNode *)((ComplexListNode *)(inTuple->getNodeByIndex(childIndex)))->GetData())->getCharValue())+1];
					txt[0] = '\0';
				}
				else
				{
					char *tmp = new char[strlen(txt)+strlen(((DM_CharNode *)((ComplexListNode *)(inTuple->getNodeByIndex(childIndex)))->GetData())->getCharValue())+1];
					strcpy(tmp,txt);
					delete [] txt;
					txt = tmp;
				}
				strcat(txt,((DM_CharNode *)((ComplexListNode *)(inTuple->getNodeByIndex(childIndex)))->GetData())->getCharValue());
				//break;
				//txt = ((DM_CharNode *)((ComplexListNode *)(inTuple->getNodeByIndex(childIndex)))->GetData())->getCharValue();
			//	break;
			}

		}
		childIndex = inTuple->GetNextSibling(childIndex);
	}
	if (txt == NULL)
		return FAILURE;
	if (strchr(txt,'.') != NULL)
		floatFound[which] = true;
	num = (float) atof(txt);
	delete [] txt;
	return SUCCESS;	
}

int TreeLevelFunctionIterator::getLocalAttrValueNum(int index, int which, float &num)
{
	int childIndex = inTuple->GetLocalChild(index);
	char *txt = NULL;
	if (childIndex == -1)
		return FAILURE;

	if (((ComplexListNode *)inTuple->getNodeByIndex(childIndex))->IsDummy())
	{
		if (strchr(((ComplexListNode *)inTuple->getNodeByIndex(childIndex))->GetDummyName(),'@') != NULL)
		{
			char *tmp = strchr(((ComplexListNode *)inTuple->getNodeByIndex(childIndex))->GetDummyName(),'=');
			tmp++;
			txt = tmp;
		}
	}
	else
	{
		if (((ComplexListNode *)inTuple->getNodeByIndex(childIndex))->GetData()->getFlag() == ATTRIBUTE_NODE)
		{
			//getting the attribute value
			Value *val = ((DM_AttributeNode *)(((ComplexListNode *) inTuple->getNodeByIndex(childIndex))->GetData()))->getAttr(attrName[which]);
			if (!val)
				return -1;
			txt = val->getStrValue();
		}
	}

	if (txt == NULL)
		return FAILURE;
	if (strchr(txt,'.') != NULL)
		floatFound[which] = true;
	num = (float) atof(txt);
	return SUCCESS;
}

int TreeLevelFunctionIterator::getDepthValue(int index, float &num)
{
	//this method gets a number that is the depth of a node
	
	//getting current fileID
	FileIDType fileid;
	if (inTuple->isSimple())
		fileid = EvaluatorClass::getFileID(((ListNode *)inTuple->getNodeByIndex(index))->getFileIndex());
	else
		fileid = EvaluatorClass::getFileID(((ComplexListNode *)inTuple->getNodeByIndex(index))->getFileIndex());
	if (fileid == -1)
	{
		globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"Evaluator",__FILE__,"File is unloaded in Timber.");
		return FAILURE;
	}

	//gettting the depth of the subtree rooted at node at index "which"
	num = (float)EvaluatorClass::GetSubtreeDepth(inTuple,index,dataMng,fileid);

	return SUCCESS;
}

int TreeLevelFunctionIterator::getLocalDepthValue(int index, float &num)
{
	//this method gets a number that is the depth of a node in the witness tree
	
	num = (float)inTuple->getSubTreeDepth(index);
	return SUCCESS;
}


int TreeLevelFunctionIterator::getFanOutValue(int index, float &num)
{
	//this method gets a number that is the fan out of a node in the DB
	
	//getting current file id
	FileIDType fileid;
	if (inTuple->isSimple())
		fileid = EvaluatorClass::getFileID(((ListNode *)inTuple->getNodeByIndex(index))->getFileIndex());
	else
		fileid = EvaluatorClass::getFileID(((ComplexListNode *)inTuple->getNodeByIndex(index))->getFileIndex());
	if (fileid == -1)
	{
		globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"Evaluator",__FILE__,"File is unloaded in Timber.");
		return FAILURE;
	}

	//gettting the actual number of children in DB of node with index "which"
	num = (float)EvaluatorClass::GetNumChildren(inTuple,index,dataMng,fileid);

	return SUCCESS;
}

int TreeLevelFunctionIterator::getLocalFanOutValue(int index, float &num)
{
	//this method gets a number that is the fan out of a node in a witness tree

	num = (float)inTuple->getNumChildren(index);
	return SUCCESS;
}

int TreeLevelFunctionIterator::getAttributeValueNum(int index, int which, float &num)
{
	//this method gets a number that is in an attribute node

	//getting the current file id
	FileIDType fileid;
	if (inTuple->isSimple())
		fileid = EvaluatorClass::getFileID(((ListNode *)inTuple->getNodeByIndex(index))->getFileIndex());
	else
		fileid = EvaluatorClass::getFileID(((ComplexListNode *)inTuple->getNodeByIndex(index))->getFileIndex());
	if (fileid == -1)
	{
		globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"Evaluator",__FILE__,"File is unloaded in Timber.");
		return FAILURE;
	}

	//getting the attribute node from the DB
	int res = EvaluatorClass::GetAttributes(inTuple,index,dataMng,fileid);

	if (res == FAILURE)
		return FAILURE;

	//getting the attribute value
	Value *val = ((DM_AttributeNode *)(((ComplexListNode *) inTuple->getNodeByIndex(index+1))->GetData()))->getAttr(attrName[which]);
	if (!val)
		return FAILURE;
	char *txt = val->getStrValue();
	if (txt == NULL)
		return FAILURE;
	if (strchr(txt,'.') != NULL)
		floatFound[which] = true;
	num = (float) atof(txt);
	return SUCCESS;	
}

int TreeLevelFunctionIterator::getValueNum(int index, int which, float &num)
{

	ComplexListNode *n = (ComplexListNode *)inTuple->getNodeByIndex(index);
	if (!n)
		return FAILURE;
	char *txt = this->getStrOfNode(n,this->attrName[which]);
	if (txt == NULL)
		return FAILURE;

	if (strchr(txt,'.') != NULL)
		floatFound[which] = true;
	num = (float) atof(txt);
	return  SUCCESS;
}


char *TreeLevelFunctionIterator::getStrOfNode(ComplexListNode *node, char *attrName)
{
	DM_DataNode *n = node->GetData();
	if (!n)
		return NULL;
	switch (n->getFlag())
	{
	case ELEMENT_NODE:
		//if it is an element node, return its tag
		return (dataMng->getPhysicalDataMng()->getXMLNameTable()->getNameByCode(n->getTag()));
	case DOCUMENT_NODE:
		//if document node, return the xml file name
		return (((DM_DocumentNode *)n)->getXMLFileName());
	case ATTRIBUTE_NODE:
		//if attribute node, return the value of attribute "attrName"
		if (((DM_AttributeNode *)n)->getAttr(attrName) != NULL)
			return ((DM_AttributeNode *)n)->getAttr(attrName)->getStrValue();
		else
			return NULL;
	case TEXT_NODE:
		//if text node, return the text value
		return (((DM_CharNode *)n)->getCharValue());
	}
	return NULL;
}


void TreeLevelFunctionIterator::formatFloat(double num, char *str)
{
	sprintf(str,"%.13f",num);
	for (int j=strlen(str)-1; j>0; j--)
	{
		if (str[j] != '0')
			break;
		if (str[j-1] == '.')
		{
			str[j] = '0';
			str[j+1] = '\0';
			break;
		}
		if (str[j] == '0')
			str[j] = '\0';
	}
}
