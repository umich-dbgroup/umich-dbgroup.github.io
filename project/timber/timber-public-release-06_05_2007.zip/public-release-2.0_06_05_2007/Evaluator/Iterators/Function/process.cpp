#include "../../Evaluator/EvaluatorClass.h"

#include "QueryEvaluationTreeFunctionNode.h"

#include "TreeLevelFunctionIterator.h"
#include "FunctionIterator.h"
#include "extra.h"

void QueryEvaluationTreeFunctionNode::processQueryEvalNode(EvaluatorClass* evaluator, IteratorClass*& curr)
	    {
		IteratorClass *opr = evaluator->processQueryEvalNode(getOperand());
		if (opr == NULL)
		{
		    globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"Evaluator",__FILE__, "operand returned is NULL. function process eval node..." );
		    curr=NULL; return;
		}
		if (getTreeLevel())
		    curr = new TreeLevelFunctionIterator(opr,getNum(),getOperation(),getOnWhat(),
			    getNRE(),
			    getAttrName(),getAssignedNRE(),evaluator->getDataManager());
		else
		    curr = new FunctionIterator(opr,getNum(),getOperation(),getOnWhat(),
			    getNRE(),
			    getAttrName(),getAssignedNRE(),evaluator->getDataManager());
		setOperation(NULL);
		setOnWhat(NULL);
		setNRE(NULL);
		setAttrName(NULL);
	    }

