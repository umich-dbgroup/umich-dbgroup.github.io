
#include "parse.hpp"

char QueryEvaluationTreeFunctionNode::getIdentifier(void) { return 'F'; }

char FunctionPlanParser::getIteratorIdentifier(void) { return 'F'; }

void 
FunctionPlanParser::getQueryEvalNode(EvaluatorClass* evaluator, char* line, void* queryInput, QueryEvaluationTreeNode*& curr)
	    {
		char *token = strtok(line+2,",");                    
		if (token == NULL)
		{
		    globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"Evaluator",__FILE__,"Error input from file... expecting num of operations... function line...");
		    curr=NULL; return;
		}
		int num = atoi(token);

		int *operation;
		int *onWhat;
		NREType *nre;
		char **attrNames;
		NREType *assignedNRE;

		if (num > 0)
		{
		    operation = new int[num];
		    onWhat = new int[num];
		    attrNames = new char *[num];
		    for (int i=0; i<num; i++)
			attrNames[i] = NULL;
		    nre = new NREType[num];
		    assignedNRE = new NREType[num];
		}
		else
		{
		    operation = NULL;
		    onWhat = NULL;
		    attrNames = NULL;
		    nre = NULL;
		    assignedNRE = NULL;
		    globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"Evaluator",__FILE__,"Error input from file... num of operations should be positive... function line...");
		    curr=NULL; return;
		}

		for (int i=0; i<num; i++)
		{
		    token = strtok(NULL,",");
		    if (token == NULL)
		    {
			globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"Evaluator",__FILE__,"Error input from file... expecting operation type... function line...");
			delete [] operation;
			delete [] onWhat;
			for (int j=0; j<i; j++)
			    if (attrNames[j]) delete [] attrNames[j];
			delete [] attrNames;

			delete [] nre;
			delete [] assignedNRE;     
			curr=NULL; return;
		    }

		    if (strcmp(token,"C") == 0)
			operation[i] = OP_COUNT;
		    else if (strcmp(token,"A") == 0)
			operation[i] = OP_AVG;
		    else if (strcmp(token,"S") == 0)
			operation[i] = OP_SUM;
		    else if (strcmp(token,"M") == 0)
			operation[i] = OP_MAX;
		    else if (strcmp(token,"m") == 0)
			operation[i] = OP_MIN;
		    else
		    {
			globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"Evaluator",__FILE__,"Error input from file... unrecognized operation type... function line...");
			delete [] operation;
			delete [] onWhat;
			for (int j=0; j<i; j++)
			    if (attrNames[j]) delete [] attrNames[j];
			delete [] attrNames;

			delete [] nre;
			delete [] assignedNRE;     
			curr=NULL; return;
		    }

		    token = strtok(NULL,",");
		    if (token == NULL)
		    {
			globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"Evaluator",__FILE__,"Error input from file... expecting oper on what... function line...");
			delete [] operation;
			delete [] onWhat;
			for (int j=0; j<i; j++)
			    if (attrNames[j]) delete [] attrNames[j];
			delete [] attrNames;

			delete [] nre;
			delete [] assignedNRE;   
			curr=NULL; return;
		    }

		    if (strcmp(token,"A") == 0)
			onWhat[i] = ON_ATTRIBUTE_NUM;
		    else if (strcmp(token,"LA") == 0)
			onWhat[i] = ON_ATTR_LOCAL_NUM;
		    else if (strcmp(token,"T") == 0)
			onWhat[i] = ON_TEXT_NUM;
		    else if (strcmp(token,"LT") == 0)
			onWhat[i] = ON_TEXT_LOCAL_NUM;
		    else if (strcmp(token,"LF") == 0)
			onWhat[i] = ON_FANOUT_LOCAL;
		    else if (strcmp(token,"AF") == 0)
			onWhat[i] = ON_FANOUT_ACTUAL;
		    else if (strcmp(token,"LD") == 0)
			onWhat[i] = ON_DEPTH_LOCAL;
		    else if (strcmp(token,"AD") == 0)
			onWhat[i] = ON_DEPTH_ACTUAL;
		    else if (strcmp(token,"V") == 0)
			onWhat[i] = ON_VALUE_NUM;
		    else
		    {
			globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"Evaluator",__FILE__,"Error input from file... unrecognized operation on what... function line...");
			delete [] operation;
			delete [] onWhat;
			for (int j=0; j<i; j++)
			    if (attrNames[j]) delete [] attrNames[j];
			delete [] attrNames;

			delete [] nre;
			delete [] assignedNRE;   
			curr=NULL; return;
		    }

		    token = strtok(NULL,",");
		    if (token == NULL)
		    {
			globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"Evaluator",__FILE__,"Error input from file... expecting attrName... function line...");
			delete [] operation;
			delete [] onWhat;
			for (int j=0; j<i; j++)
			    if (attrNames[j]) delete [] attrNames[j];
			delete [] attrNames;

			delete [] nre;
			delete [] assignedNRE;                  
			curr=NULL; return;
		    }
		    /*   if (strcmp(token,"NULL") == 0)
			 attrNames[i] = NULL;
			 else
			 {*/
		    attrNames[i] = new char[strlen(token)+1];
		    strcpy(attrNames[i],token);
		    //}

		    token = strtok(NULL,",");
		    if (token == NULL)
		    {
			globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"Evaluator",__FILE__,"Error input from file... expecting nre... function line...");
			delete [] operation;
			delete [] onWhat;
			for (int j=0; j<=i; j++)
			    if (attrNames[j]) delete [] attrNames[j];
			delete [] attrNames;

			delete [] nre;
			delete [] assignedNRE;                  
			curr=NULL; return;
		    }

		    nre[i] = (NREType) atoi(token);
		    if (nre[i] < 1)
		    {
			globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"Evaluator",__FILE__,"NRE should be positive.");
			delete [] operation;
			delete [] onWhat;
			for (int j=0; j<=i; j++)
			    if (attrNames[j]) delete [] attrNames[j];
			delete [] attrNames;

			delete [] nre;
			delete [] assignedNRE;    
			curr=NULL; return;
		    }
		    if (nre[i] > evaluator->maxNRE)
			evaluator->maxNRE = nre[i];

		    token = strtok(NULL,",");
		    if (token == NULL)
		    {
			globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"Evaluator",__FILE__,"Error input from file... expecting assigned nre... function line...");
			delete [] operation;
			delete [] onWhat;
			for (int j=0; j<=i; j++)
			    if (attrNames[j]) delete [] attrNames[j];
			delete [] attrNames;

			delete [] nre;
			delete [] assignedNRE;                   
			curr=NULL; return;
		    }

		    assignedNRE[i] = (NREType) atoi(token);
		    if (assignedNRE[i] < 1)
		    {
			globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"Evaluator",__FILE__,"NRE should be positive.");
			delete [] operation;
			delete [] onWhat;
			for (int j=0; j<=i; j++)
			    if (attrNames[j]) delete [] attrNames[j];
			delete [] attrNames;

			delete [] nre;
			delete [] assignedNRE;    
			curr=NULL; return;
		    }
		    if (assignedNRE[i] > evaluator->maxNRE)
			evaluator->maxNRE = assignedNRE[i];
		}

		token = strtok(NULL,",");
		if (token == NULL)
		{
		    globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"Evaluator",__FILE__,"Error input from file... expecting treeLevel bool... function line...");
		    delete [] operation;
		    delete [] onWhat;
		    for (int j=0; j<num; j++)
			if (attrNames[j]) delete [] attrNames[j];
		    delete [] attrNames;

		    delete [] nre;
		    delete [] assignedNRE;              
		    curr=NULL; return;
		}
		if (atoi(token) != 0 && atoi(token) != 1)
		{
		    globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"Evaluator",__FILE__,"Error input from file... Tree level should be 0 or 1... group by line...");
		    delete [] operation;
		    delete [] onWhat;
		    for (int j=0; j<num; j++)
			if (attrNames[j]) delete [] attrNames[j];
		    delete [] attrNames;

		    delete [] nre;
		    delete [] assignedNRE;    
		    curr=NULL; return;
		}
		bool treeLevel = (bool) atoi(token);

		char newLine[MAX_FILE_INTERFACE_LINE_SIZE];
		if (((std::iostream *)queryInput)->eof() == 0)
		    ((std::iostream *)queryInput)->getline(newLine,MAX_FILE_INTERFACE_LINE_SIZE);
		else
		{
		    globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"Evaluator",__FILE__,"Unexpected end of file... function line...");
		    delete [] operation;
		    delete [] onWhat;
		    for (int j=0; j<num; j++)
			if (attrNames[j]) delete [] attrNames[j];
		    delete [] attrNames;

		    delete [] nre;
		    delete [] assignedNRE;               
		    curr=NULL; return;
		}
		QueryEvaluationTreeNode *oper = evaluator->getQueryEvalNode(newLine,queryInput);
		if (oper == NULL)
		{
		    globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"Evaluator",__FILE__,"Unexpected operand returned... function line...");
		    delete [] operation;
		    delete [] onWhat;
		    for (int j=0; j<num; j++)
			if (attrNames[j]) delete [] attrNames[j];
		    delete [] attrNames;

		    delete [] nre;
		    delete [] assignedNRE;    
		    curr=NULL; return;
		}
		curr = new QueryEvaluationTreeFunctionNode(oper,assignedNRE,num,operation,onWhat,nre,attrNames,treeLevel);
	    }

