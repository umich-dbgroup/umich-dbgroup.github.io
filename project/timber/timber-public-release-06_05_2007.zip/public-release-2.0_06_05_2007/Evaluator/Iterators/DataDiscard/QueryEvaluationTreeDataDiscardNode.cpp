#include "QueryEvaluationTreeDataDiscardNode.h"

QueryEvaluationTreeDataDiscardNode
::QueryEvaluationTreeDataDiscardNode(
	QueryEvaluationTreeNode* operand,
	int nodeindex,
	DataInstantiationSpecification* dispec): QueryEvaluationTreeNode()
{
	this->operand = operand;
	this->nodeIndexInWitnessTree = nodeindex;
	this->diSpecification = dispec;
}

QueryEvaluationTreeDataDiscardNode::~QueryEvaluationTreeDataDiscardNode(void)
{
}

QueryEvaluationTreeNode* QueryEvaluationTreeDataDiscardNode
::getOperand()
{
	return this->operand;
}

int QueryEvaluationTreeDataDiscardNode
::getNodeIndexInWitnessTree()
{
	return this->nodeIndexInWitnessTree;
}

DataInstantiationSpecification* QueryEvaluationTreeDataDiscardNode
::getDISpecification()
{
	return this->diSpecification;
}

void QueryEvaluationTreeDataDiscardNode::deleteStructures()
{
	if (this->diSpecification)
		delete this->diSpecification;

	operand->deleteStructures();
}
