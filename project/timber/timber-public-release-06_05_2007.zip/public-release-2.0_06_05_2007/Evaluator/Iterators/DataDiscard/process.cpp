#include "../../Evaluator/EvaluatorClass.h"

#include "QueryEvaluationTreeDataDiscardNode.h"

#include "DataDiscardIterator.h"
#include "extra.h"

void QueryEvaluationTreeDataDiscardNode::processQueryEvalNode(EvaluatorClass* evaluator, IteratorClass*& curr)
	    {
		IteratorClass *opr = evaluator->processQueryEvalNode(getOperand());
		if (opr == NULL)
		    curr=NULL; return;
		curr = new DataDiscardIterator(opr,getNodeIndexInWitnessTree(),getDISpecification(),evaluator->getDataManager());
	    }

