#ifndef __DataDiscardIterator_h

#define __DataDiscardIterator_h
#include <timber-compat.h>



#include "../../Evaluator/EvaluatorClass.h"



class DataDiscardIterator : public IteratorClass
{

public:
	
	DataDiscardIterator(
IteratorClass *input,int index,DataInstantiationSpecification* diSpec,DataMng *dataMng);
	
	~DataDiscardIterator();

	void next(WitnessTree *&node);

private:
	IteratorClass *input;
	int index;
	DataInstantiationSpecification* diSpec;
	
	DataMng *dataMng;
	WitnessTree *resultBuffer;
	WitnessTree *inTuple;
};
#endif

