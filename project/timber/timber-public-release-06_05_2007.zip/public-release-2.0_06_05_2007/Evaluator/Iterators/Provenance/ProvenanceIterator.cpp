/*
  COPYRIGHT  (c) 2000-2004 
  THE REGENTS OF THE UNIVERSITY OF MICHIGAN
  ALL RIGHTS RESERVED

  PERMISSION IS GRANTED TO USE, COPY, CREATE DERIVATIVE WORKS AND
  REDISTRIBUTE THIS SOFTWARE AND SUCH DERIVATIVE WORKS FOR NONCOMMERCIAL
  EDUCATION AND RESEARCH PURPOSES, SO LONG AS NO FEE IS CHARGED, AND SO LONG
  AS THE COPYRIGHT NOTICE ABOVE, THIS GRANT OF PERMISSION, AND THE
  DISCLAIMER BELOW APPEAR IN ALL COPIES MADE; AND SO LONG AS THE NAME OF THE
  UNIVERSITY OF MICHIGAN IS NOT USED IN ANY ADVERTISING OR PUBLICITY
  PERTAINING TO THE USE OR DISTRIBUTION OF THIS SOFTWARE WITHOUT SPECIFIC,
  WRITTEN PRIOR AUTHORIZATION.

  THIS SOFTWARE IS PROVIDED AS IS, WITHOUT REPRESENTATION FROM THE
  UNIVERSITY OF MICHIGAN AS TO ITS FITNESS FOR ANY PURPOSE, AND WITHOUT
  WARRANTY BY THE UNIVERSITY OF MICHIGAN OF ANY KIND, EITHER EXPRESS OR
  IMPLIED, INCLUDING WITHOUT LIMITATION THE IMPLIED WARRANTIES OF
  MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE. THE REGENTS OF THE
  UNIVERSITY OF MICHIGAN SHALL NOT BE LIABLE FOR ANY DAMAGES, INCLUDING
  SPECIAL, INDIRECT, INCIDENTAL, OR CONSEQUENTIAL DAMAGES, WITH RESPECT TO
  ANY CLAIM ARISING OUT OF OR IN CONNECTION WITH THE USE OF THE SOFTWARE,
  EVEN IF IT HAS BEEN OR IS HEREAFTER ADVISED OF THE POSSIBILITY OF SUCH
  DAMAGES.
*/

#include "ProvenanceIterator.h"

using namespace std;

/**
 * An access method that takes the input trees from several sources and find out the 
 * meaningful closest common ancestor structures for the sets of nodes
 * @see IteratorClass
 * @see EvaluatorClass
 * @see WitnessTree
 * @author age
 */
ProvenanceIterator :: ProvenanceIterator(IteratorClass *input, NREType nre, NREType actonnre, DataMng *dataMng){
  // initialize the private variables
  this->input = input;
  this->dataMng = dataMng;	
  this->volumeID = dataMng->getVolumeID();
  this->nre = nre;
  this->actonnre = actonnre;
  
    input->next(inTuple);
  
  if (inTuple) {
    resultBuffer = inTuple->isSimple()? new WitnessTree : new WitnessTree(LIST_NODE_WITH_DATA,dataMng);
  } else {
    resultBuffer = NULL;
  }
  
}

/**
   Destructor
   frees the output buffer and so.
**/
ProvenanceIterator :: ~ProvenanceIterator(){
  if (resultBuffer){
    delete resultBuffer;
  }  
  if (inTuple){
    delete [] inTuple;
  }

  delete input;
  
}

/**
   Access Method
   gets the next output tree from this iterator.
   @param node is a pointer that well be set to the output buffer or NULL (indicating that
   there are no more results).
**/
void ProvenanceIterator :: next(WitnessTree *&node) {
  
  if (!inTuple) {	
    node = NULL;
    return;
  }

#ifdef EVAL_TIME_OUT
  clock_t currTime = clock();
  double queryDuration = (double)(currTime - gQueryStartTime) / CLOCKS_PER_SEC;
  if (queryDuration >= gTimeOutAfter) {
    globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"Evaluator",__FILE__,"Query Timed Out.");
    node = NULL;
    return;
  }
#endif

  if (inTuple) {	
    FileIDType fileid;
    if (inTuple->isSimple())
      fileid = EvaluatorClass::getFileID(((ListNode *)inTuple->getNodeByIndex(0))->getFileIndex());
    else
      fileid = EvaluatorClass::getFileID(((ComplexListNode *)inTuple->getNodeByIndex(0))->getFileIndex());
    
    int origindex = inTuple->getIndexOfNRE(actonnre);
    int newindex =  EvaluatorClass::GetProvChildren(inTuple, origindex, this->dataMng, fileid, nre);
    
    // if it doesn't have a provenance node, 
    // go up, change the working node in input array
    if (newindex == -1) {
      int i=0;
      WitnessTree * inputArray;
      inputArray = new WitnessTree(LIST_NODE_WITH_DATA,dataMng);
	  if (inTuple->isSimple()) {
		  ListNode *me = (ListNode *)inTuple->findNode( inTuple->getIndexOfNRE(actonnre));
		  inputArray->insertNode(0, me);
	  } else {
		  ComplexListNode *me = (ComplexListNode *)inTuple->findNode( inTuple->getIndexOfNRE(actonnre));
		  inputArray->insertNode(0, me, dataMng);
	  }
      int newnre = nre+1;
      while( newindex == -1 ) {
        // set up a dummy witness tree with the node we're working on. 
        // look for prov kids with that.
        i++;
        int ancindex = EvaluatorClass::getAncs(inputArray, 0, i,dataMng,fileid,newnre); 
        newindex =  EvaluatorClass::GetProvChildren(inputArray, ancindex, this->dataMng, fileid,this->nre);
      } 
      // if it's there, copy the prov node into the inTuple and into the ResultBuffer
      
	  inTuple->sortedInsertNode( ((ComplexListNode *)inputArray->getNodeByIndex(newindex)), dataMng, origindex+1);

      delete inputArray;      
    }
    
    resultBuffer->copyTree(inTuple);
    node = resultBuffer;
    this->input->next(inTuple);
    return;
  } else {
    node = NULL;
    return;
  }
}



/**
   get the parent node of an input node
**/
void ProvenanceIterator :: GetParentNode(ComplexListNode * child, ComplexListNode *& parent){
  WitnessTree * inputArray;
  inputArray = new WitnessTree(LIST_NODE_WITH_DATA,dataMng);
  inputArray->insertNode(0, child, dataMng);
  char fileIndex = ((ComplexListNode *)inputArray->getNodeByIndex(0))->getFileIndex();	
  int r = EvaluatorClass::getAncs(inputArray,0,1,dataMng,EvaluatorClass::getFileID(fileIndex));
  memcpy(parent,inputArray->getNodeByIndex(r),sizeof(ComplexListNode));
  delete inputArray;
}

/**
   get the parent node of an input node
**/
void ProvenanceIterator :: GetParentNode(ListNode * child, ListNode * parent){
  WitnessTree * inputArray;
  inputArray = new WitnessTree;
  inputArray->insertNode(0, child);
  char fileIndex = ((ListNode *)inputArray->getNodeByIndex(0))->getFileIndex();	
  int r = EvaluatorClass::getAncs(inputArray,0,1,dataMng,EvaluatorClass::getFileID(fileIndex));
  memcpy(parent,inputArray->getNodeByIndex(r),sizeof(ListNode));
  delete inputArray;
}    

