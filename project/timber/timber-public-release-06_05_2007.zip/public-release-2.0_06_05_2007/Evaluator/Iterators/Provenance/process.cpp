#include "../../Evaluator/EvaluatorClass.h"

#include "QueryEvaluationTreeProvenanceNode.h"

#include "ProvenanceIterator.h"
#include "extra.h"

void QueryEvaluationTreeProvenanceNode::processQueryEvalNode(EvaluatorClass* evaluator, IteratorClass*& curr)
	    {
		IteratorClass *opr = evaluator->processQueryEvalNode(getOperand());
		if (opr == NULL)
		{
		    globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"Evaluator",__FILE__, "operand returned is NULL. provenance process eval node..." );
		    curr=NULL; return;
		}
		curr = new ProvenanceIterator(opr,getNRE(),getActOnNRE(),evaluator->getDataManager());
	    }

