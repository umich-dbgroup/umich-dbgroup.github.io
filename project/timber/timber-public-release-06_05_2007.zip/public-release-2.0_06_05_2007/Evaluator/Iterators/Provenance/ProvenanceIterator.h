/*
COPYRIGHT  (c) 2000-2004 
THE REGENTS OF THE UNIVERSITY OF MICHIGAN
ALL RIGHTS RESERVED

PERMISSION IS GRANTED TO USE, COPY, CREATE DERIVATIVE WORKS AND
REDISTRIBUTE THIS SOFTWARE AND SUCH DERIVATIVE WORKS FOR NONCOMMERCIAL
EDUCATION AND RESEARCH PURPOSES, SO LONG AS NO FEE IS CHARGED, AND SO LONG
AS THE COPYRIGHT NOTICE ABOVE, THIS GRANT OF PERMISSION, AND THE
DISCLAIMER BELOW APPEAR IN ALL COPIES MADE; AND SO LONG AS THE NAME OF THE
UNIVERSITY OF MICHIGAN IS NOT USED IN ANY ADVERTISING OR PUBLICITY
PERTAINING TO THE USE OR DISTRIBUTION OF THIS SOFTWARE WITHOUT SPECIFIC,
WRITTEN PRIOR AUTHORIZATION.

THIS SOFTWARE IS PROVIDED AS IS, WITHOUT REPRESENTATION FROM THE
UNIVERSITY OF MICHIGAN AS TO ITS FITNESS FOR ANY PURPOSE, AND WITHOUT
WARRANTY BY THE UNIVERSITY OF MICHIGAN OF ANY KIND, EITHER EXPRESS OR
IMPLIED, INCLUDING WITHOUT LIMITATION THE IMPLIED WARRANTIES OF
MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE. THE REGENTS OF THE
UNIVERSITY OF MICHIGAN SHALL NOT BE LIABLE FOR ANY DAMAGES, INCLUDING
SPECIAL, INDIRECT, INCIDENTAL, OR CONSEQUENTIAL DAMAGES, WITH RESPECT TO
ANY CLAIM ARISING OUT OF OR IN CONNECTION WITH THE USE OF THE SOFTWARE,
EVEN IF IT HAS BEEN OR IS HEREAFTER ADVISED OF THE POSSIBILITY OF SUCH
DAMAGES.
*/

#ifndef __ProvenanceIterator_h
#define __ProvenanceIterator_h
#include <timber-compat.h>


#include "../../Evaluator/Evaluator_definitions.h"
#include "../../Evaluator/EvaluatorClass.h"

//Global settings class
#include "../../Utilities/Settings.h"
extern Settings* gSettings;

//Global error handling class
#include "../../Utilities/ErrorInfoClass.h"
extern ErrorInfoClass globalErrorInfo;

/**
* An access method that takes the input trees from several sources and find out the 
* meaningful closest common ancestor structures for the sets of nodes
* @see IteratorClass
* @see EvaluatorClass
* @see WitnessTree
* @author age
*/

class ProvenanceIterator : public IteratorClass
{
public:
	/**
	Constructor
	initializes the variables. 
	@param inputs is an array of input iterators.
	@param numInputs is the number of input iterators
	@param nre is the pointer to an array of nre values of input nodes
	@param assignedNre is the nre value assigned to the root 
	@param dataMng an instance of the data manager.
	**/
	ProvenanceIterator(IteratorClass *input, NREType nre, NREType actonnre, DataMng *dataMng);

	/**
	Destructor
	releases memory used by array and result buffer.
	**/
	~ProvenanceIterator();
	
	/**
	Access Method
	gets the next output tree from this iterator.
	@param node is a pointer that well be set to the output buffer or NULL (indicating that
	there are no more results).
	**/
	void next(WitnessTree *&node);
private:
	/**
	get the parent node of an input node
	**/
	void GetParentNode(ListNode * child, ListNode * parent);
	
	/**
	get the parent node of an  input node of ComplexListNode type
	**/
	void GetParentNode(ComplexListNode * child, ComplexListNode *& parent);

        /** get the provenance child of an input node of ComplexListNode type
         **/
        void GetProvChildNode(WitnessTree *in, int currNRE, int parNRE, int myindex );

	/**
	an IteratorClass that produces input for this iterator.
	**/
	IteratorClass *input;
	
	/**
	DataManager
	**/
	DataMng *dataMng;

	/**
	Inputs array inTuples
	**/
	WitnessTree *inTuple;

	/**
	A buffer that holds the output tree.
	**/
	WitnessTree *resultBuffer;

	NREType nre;
	NREType actonnre;

	lvid_t volumeID;
	serial_t fileID;

	int ListNodeSize;
	int ComplexListNodeSize;

};

#endif

