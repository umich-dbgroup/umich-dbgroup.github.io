/*
COPYRIGHT  � 2000-2004 
THE REGENTS OF THE UNIVERSITY OF MICHIGAN
ALL RIGHTS RESERVED

PERMISSION IS GRANTED TO USE, COPY, CREATE DERIVATIVE WORKS AND REDISTRIBUTE THIS SOFTWARE AND SUCH DERIVATIVE WORKS FOR 
NONCOMMERCIAL EDUCATION AND RESEARCH PURPOSES, SO LONG AS NO FEE IS CHARGED, AND SO LONG AS THE COPYRIGHT NOTICE ABOVE, 
THIS GRANT OF PERMISSION, AND THE DISCLAIMER BELOW APPEAR IN ALL COPIES MADE; AND SO LONG AS THE NAME OF THE UNIVERSITY 
OF MICHIGAN IS NOT USED IN ANY ADVERTISING OR PUBLICITY PERTAINING TO THE USE OR DISTRIBUTION OF THIS SOFTWARE WITHOUT 
SPECIFIC, WRITTEN PRIOR AUTHORIZATION.

THIS SOFTWARE IS PROVIDED AS IS, WITHOUT REPRESENTATION FROM THE UNIVERSITY OF MICHIGAN AS TO ITS FITNESS FOR ANY PURPOSE, 
AND WITHOUT WARRANTY BY THE UNIVERSITY OF MICHIGAN OF ANY KIND, EITHER EXPRESS OR IMPLIED, INCLUDING WITHOUT LIMITATION THE 
IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE. THE REGENTS OF THE UNIVERSITY OF MICHIGAN SHALL 
NOT BE LIABLE FOR ANY DAMAGES, INCLUDING SPECIAL, INDIRECT, INCIDENTAL, OR CONSEQUENTIAL DAMAGES, WITH RESPECT TO ANY CLAIM 
ARISING OUT OF OR IN CONNECTION WITH THE USE OF THE SOFTWARE, EVEN IF IT HAS BEEN OR IS HEREAFTER ADVISED OF THE POSSIBILITY 
OF SUCH DAMAGES.
*/

#include "StackBasedTermJoin.h"

#define CONG_DBG 0

StackBasedTermJoin::StackBasedTermJoin(char *phrase, char *indexName,  char openFileIndex,
                                       double ( *scoreFunction)(char *elementsInXML, int keywordSet),
                                       int ( *ancsDepthThresholdFunction)(KeyType sk, int level, int keywordSet), 
                                       bool ( *ancsQualifies)(double score, int keywordSet),
                                       int expectedDepth, char *parentIndexName, int bufPoolSize, NREType assignedNRE,
                                       DataMng *dataMng, bool simpleScore, int keywordSet)
{	
	this->phrase = phrase;
	this->indexName = indexName;
	this->inTuple = NULL;
	this->indices = NULL;
	this->scoreFunction = scoreFunction;
	this->ancsDepthThresholdFunction = ancsDepthThresholdFunction;
	this->ancsQualifies = ancsQualifies;
	this->simpleScore = simpleScore;
	this->expectedDepth = expectedDepth;
	this->dataMng = dataMng;
	this->keywordSet = keywordSet;
	this->assignedNRE = assignedNRE;
	numWrites = 0;
	this->tempArray = NULL;
	this->tempActualSize = 0;
	this->pushed = false;
	errorFound = false;
	fileCreated = false;
	this->openFileIndex = openFileIndex;
	this->parentIndexName = parentIndexName;
	if (this->parentIndexName)
		parentIndex = new HashIndexAccess(parentIndexName,DOUBLE_INDEX,bufPoolSize,assignedNRE);
	else
		parentIndex  = NULL;
	this->xmlBuffer = NULL;
	resultBuffer = new WitnessTree;
	if (!phrase)
	{
		errorFound = true;
		globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"Evaluator",__FILE__,"Phrase is NULL.");
		return;
	}
	
	if (!indexName)
	{
		errorFound = true;
		globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"Evaluator",__FILE__,"No index name passed.");
		return;
	}

	wordNum = PhraseFinderIterator::wordCount(phrase);
	if (wordNum == 0)
	{
		errorFound = true;
		globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"Evaluator",__FILE__,"We have 0 words.");
		return;
	}


	this->indices = new GistIndexAccess *[wordNum];

	inTuple = new WitnessTree *[wordNum];
    // CONG: added to prevent UMR
	for (int i=0; i<wordNum; i++)
	    inTuple[i] = NULL;

	PhraseFinderIterator::extractWords(phrase, indices, NULL, indexName, openFileIndex,DEFAULT_NODES_NRE);

	

	if (simpleScore)
	{
		ancsStack = new stack<SBTermJoinStackNode>(expectedDepth);
		complexAncsStack = NULL;
		xmlBuffer = new char[INITIAL_XML_BUFFER_SIZE];
		xmlBufferSize = INITIAL_XML_BUFFER_SIZE;
		readBuffer = NULL;
	}
	else
	{
		volumeID = dataMng->getVolumeID();
		ancsStack = NULL;
		complexAncsStack = new stack<SBTermJoinComplexStackNode>(expectedDepth);
		xmlBuffer = new char[INITIAL_XML_BUFFER_SIZE_COMPLEX];
		xmlBufferSize = INITIAL_XML_BUFFER_SIZE_COMPLEX;
		readBuffer = new ContainerClass;
		rc = ss_m::create_file(volumeID, fileID,ss_m::t_regular);
		if (rc) 
		{
			stringstream msg;
			msg<<rc<<'\0';
			globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"Evaluator",__FILE__,msg.rdbuf()->str().c_str());
			errorFound = true;
			return;				
		}	
		fileCreated = true;
		int maxIDs = gSettings->getIntegerValue("MAX_ID_PER_FILE_STRUCTURAL_JOINS",10000);
		rc = ss_m::create_id(volumeID,maxIDs,startID);
		if (rc) 
		{
			stringstream msg;
			msg<<rc<<'\0';
			globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"Evaluator",__FILE__,msg.rdbuf()->str().c_str());
			errorFound = true;
			return;				
		}	
		numWrites = maxIDs;
	}
	
	tempArray = new ComplexListNode[expectedDepth];
	this->tempSize = expectedDepth;
	outputtingStack = false;

	res = getInputs();
	first = -1;
	if (res == SUCCESS)
	{
		first = this->whoseFirst();
		lastSK = ((ListNode *)inTuple[first]->findNode(0))->GetStartPos();
		this->GetAndStackAncs(((ListNode *)inTuple[first]->findNode(0))->GetStartPos(),
			     ((ListNode *)inTuple[first]->findNode(0))->getFileIndex(),
			     ((ListNode *)inTuple[first]->findNode(0))->GetLevel());
		incrementTopCounters(first,1);
		if (addNodeToTop(first) == FAILURE)
			errorFound = true;
	} 
}

StackBasedTermJoin::~StackBasedTermJoin()
{
	if (ancsStack)
		delete ancsStack;
	else
		delete complexAncsStack;
	delete resultBuffer;
	if (phrase) delete [] phrase;
	if (indexName) delete [] indexName;
	if (indices)
	{
		for (int i=0; i<wordNum; i++)
			delete indices[i];
		delete [] indices;
	}

	if (parentIndexName)
		delete [] parentIndexName;
	if (inTuple)
		delete [] inTuple;
	if (this->tempArray)
		delete [] tempArray;
	if (this->xmlBuffer)
		delete [] xmlBuffer;
	if (readBuffer)
		delete readBuffer;
	if (parentIndex)
		delete parentIndex;
	if (fileCreated)
	{
		rc = ss_m::destroy_file(volumeID, fileID,true, numWrites);
		if (rc) 
		{
			stringstream msg;
			msg<<rc<<'\0';
			globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"Evaluator",__FILE__,msg.rdbuf()->str().c_str());
			return;				
		}
	}
}

void StackBasedTermJoin::next(WitnessTree *&node)
{
	if (errorFound)
	{
		node = NULL;
		return;
	}
#ifdef EVAL_TIME_OUT
	clock_t currTime = clock();
	double queryDuration = (double)(currTime - gQueryStartTime) / CLOCKS_PER_SEC;
	if (queryDuration >= gTimeOutAfter)
	{
		globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"Evaluator",__FILE__,"Query Timed Out.");
		node = NULL;
		return;
	}
#endif
	//if we are in the process of outputting a stack node. This is never true when
	//you first come here.
	if (outputtingStack)
	{
		//res == FAILURE means we ran out of inputs, so just pop the stack.
		if (res == FAILURE)
		{
			//if popping the stack resulted in outputting something, then return
			if (popStackIfNeeded() == SUCCESS)
			{
				node = resultBuffer;
				return;
			}
			node = NULL;
			return;
		}
		else
		{
			// if we still have inputs, then check if the one with the smallest start key pops anything in the
			//stack.
			int r = popStackIfNeeded(((ListNode *)inTuple[first]->findNode(0))->GetStartPos());
			if (r == SUCCESS)
			{
				node = resultBuffer;
				return;
			}
			else if (r == EV_ERROR)
			{
				node = NULL;
				return;
			}
		}
		outputtingStack = false;

		//get the current start key (smallest start key among inputs.
		KeyType currSK = ((ListNode *)inTuple[first]->findNode(0))->GetStartPos();

		//if it is different from last one, we need to add its ancestors to stack
		if (currSK != lastSK)
		{
			lastSK = currSK;
			GetAndStackAncs(currSK,((ListNode *)inTuple[first]->findNode(0))->getFileIndex(),
				((ListNode *)inTuple[first]->findNode(0))->GetLevel());
		}

		//we need to increment the counters of word occurances in the top element of the stack
		incrementTopCounters(first);

		//we need to add this node to the top of the stack in case of the complex scoring.
		if (addNodeToTop(first) == FAILURE)
		{
			node = NULL;
			return;
		}
	}
	
	//get s set of inputs (a word occurance from the inverted index)
	//the first time we come here, we will get an occurance of each word. subsequent times
	// will get another occurance of exactly one word (the one that has the smallest start key).
	res = getInputs(first);
	while (res == SUCCESS)
	{
		//as long as we still have inputs.

		//decide which occurance comes first based on start key and offset
		first = this->whoseFirst();

		//see if the word we are handling now (first) pops any ancestors from stack
		int r = popStackIfNeeded(((ListNode *)inTuple[first]->findNode(0))->GetStartPos());
		if (r == SUCCESS)
		{
			//if it does, then the popped elements are output.
			outputtingStack = true;
			node = resultBuffer;
			return;
		}
		else if (r == EV_ERROR)
		{
			node = NULL;
			return;
		}

		//get current start key
		KeyType currSK = ((ListNode *)inTuple[first]->findNode(0))->GetStartPos();

		//if it is a new node, then get its ancestors and stack them
		if (currSK != lastSK)
		{
			lastSK = currSK;
			GetAndStackAncs(currSK,((ListNode *)inTuple[first]->findNode(0))->getFileIndex(),
				((ListNode *)inTuple[first]->findNode(0))->GetLevel());
		}
			//we need to increment the counters of word occurances in the top element of the stack
		incrementTopCounters(first);

		//we need to add this node to the top of the stack in case of the complex scoring.
		if (addNodeToTop(first) == FAILURE)
		{
			node = NULL;
			return;
		}

		//get the next occurance of the word that we just processed (first)
		res = getInputs(first);
#ifdef EVAL_TIME_OUT
	clock_t currTime = clock();
	double queryDuration = (double)(currTime - gQueryStartTime) / CLOCKS_PER_SEC;
	if (queryDuration >= gTimeOutAfter)
	{
		globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"Evaluator",__FILE__,"Query Timed Out.");
		node = NULL;
		return;
	}
#endif
	}

	//if we have no more inputs, pop the whole stack
	if (popStackIfNeeded() == SUCCESS)
	{
		outputtingStack = true;
		node = resultBuffer;
		return;
	}
	node = NULL;
}

int StackBasedTermJoin::getInputs(int which)
{
	//this method gets next occurance of words based on which.
	//if which is -1, get next occurance of everything. else, get 
	//the next occurance of the word number "which"
	bool allNull = true;

	//if which==-1, get next occurance of all words.
	if (which == -1)
	{
		for (int i=0; i<wordNum; i++)
			if (indices[i]) // CONG: bug-fix change inTuple[i] to indices[i]
			{
				indices[i]->next(inTuple[i]);
				if (inTuple[i])
				{
					allNull = false;
			    }
			}
	}
	else
	{
		//if there is a specific word that we are intereseted in getting next
		//occurance of.

		//if we still have input on this word, then just get next
		if (inTuple[which])
		{
			indices[which]->next(inTuple[which]);

			//if we have still inputs
			if (inTuple[which])
				allNull = false;
			else
			{
				//if we ran out of occurances of this word, just make sure that the
				//rest of the words still have occurances.
				for (int i=0; i<wordNum; i++)
					if (inTuple[i])
					{
						allNull = false;
						break;
					}
			}
		}
		else
		{
			//if we ran out of input on this word, just make sure we still have
			//inputs from rest of the words.
			for (int i=0; i<wordNum; i++)
				if (inTuple[i])
				{
					allNull = false;
					break;
				}
		}
	}

	//if all the inputs are nulls, return failure
	if (allNull)
		return FAILURE;
	else
		return SUCCESS;
}

void StackBasedTermJoin::GetAndStackAncs(KeyType startKey, char fileIndex,int level)
{
	//in this method, we get ancstors of node with start key sstartKey and push
	// these ancestors into the stack.

	//get the limit on the levels from the function pointer.
	int levelsUp = ancsDepthThresholdFunction(startKey,level,keywordSet);

	//if levelsUp == -1, reach the root of teh document.
	if (levelsUp == -1)
		levelsUp = INT_MAX;
	int currLevUp = 0;

	//get teh level of the top element in the stack (to make sure we don't read the 
	//ancs that is on stack again)
	int stackTopLevel = getStackTopLevel();
	
	//as long as we haven't reached the level where we are supposed to stop
	while (currLevUp < levelsUp)
	{
		ComplexListNode n;
		//get the parent of node startKey
		int r = getAncs(startKey,fileIndex,n); 
		if (r == FAILURE)
			break;
		currLevUp++;

		//if we reach teh stack top level, stop to avoid redundant access of ancestors
		if (stackTopLevel != -1 && n.GetLevel() == stackTopLevel)
			break;
		if (tempActualSize == tempSize)
			doubleArray();

		//we are wrinting to an array instead of pushing into stack because we are going
		//backwards for pushing
		memcpy(&tempArray[tempActualSize],&n, sizeof(ComplexListNode));
		tempActualSize++;
		if (stackTopLevel != -1 && n.GetLevel() == stackTopLevel +1)
			break;	

		//startkey becomes the start key of the parent
		startKey = n.GetStartPos();
	}

	//perfomr the actual pushing into the stack
	actualPush();
	tempActualSize = 0;
}

KeyType StackBasedTermJoin::getStackTopSK()
{
	//this method returns the start key of the top element on stack
	if (stackIsEmpty())
		return -1;
	return (simpleScore? ancsStack->GetTop()->GetActualAncs()->GetStartPos()
		: complexAncsStack->GetTop()->GetActualAncs()->GetStartPos());
}

KeyType StackBasedTermJoin::getStackTopEK()
{
	//this method returns the end key of the top element on stack

	if (stackIsEmpty())
		return -1;
	return (simpleScore? ancsStack->GetTop()->GetActualAncs()->GetEndPos()
		: complexAncsStack->GetTop()->GetActualAncs()->GetEndPos());
}

int StackBasedTermJoin::getStackTopOffset()
{
	//this method returns the offset of the top element on stack

	if (stackIsEmpty())
		return -1;
	return (simpleScore? ancsStack->GetTop()->GetActualAncs()->GetOffset()
		: complexAncsStack->GetTop()->GetActualAncs()->GetOffset());
}

int StackBasedTermJoin::getStackTopLevel()
{
		//this method returns the level of the top element on stack

	if (stackIsEmpty())
		return -1;
	return (simpleScore? ancsStack->GetTop()->GetActualAncs()->GetLevel()
		: complexAncsStack->GetTop()->GetActualAncs()->GetLevel());
}

int StackBasedTermJoin::popStackIfNeeded(KeyType sk)
{
	//in this method, the stack is popped if needed based on the start key sk.

	//if stack is empty, no popping.
	if (stackIsEmpty())
		return FAILURE;

	//as long as the sk pops the stack, pop it
	while (getStackTopEK() < sk)
	{
		if (simpleScore)
		{
			//if we are dealing with the simple scoring method.

			//pop top element
			SBTermJoinStackNode *p = ancsStack->Pop();

		
			if (!p->areAllCountersZeros())
			{		//if the popped element actually has occurances of words
				if (!stackIsEmpty())
				{
					//if we have still element on stack, make sure you update the
					//counters on top of stack with counters of popped element.
					for (int i=0; i<wordNum; i++)
						incrementTopCounters(i,p->getCounterAt(i));
				}

				//take the popped element and convert its info into an XML format in order to
				//obtain the score
				convertToXML(p,xmlBuffer,xmlBufferSize, wordNum,volumeID, fileID);

				//get the score of this popped ancs.
				double score = scoreFunction(xmlBuffer, keywordSet); 
				
				//if the score is high enough, output this ancs
				if (ancsQualifies(score, keywordSet))
				{
			        resultBuffer->initialize();
					resultBuffer->appendList((ListNode *)p->GetActualAncs(),1);
					resultBuffer->setScore(score);
					return SUCCESS;
				}
			}
		}
		else
		{
			//if we are dealing with the complex scoring method.

			//pop top element
			SBTermJoinComplexStackNode *p = complexAncsStack->Pop();
			if (!p->areAllCountersZeros())
			{
				//if the popped element actually has occurances of words
				if (!stackIsEmpty())
				{
						//if we have still element on stack, make sure you update the
					//counters on top of stack with counters of popped element.
					for (int i=0; i<wordNum; i++)
						incrementTopCounters(i,p->getCounterAt(i));

					//also, the data connected with the occurances should be copied to top of
					//stack
					if (copyDataToTop(p) == FAILURE)
						return EV_ERROR;
				}
				
				//take the popped element and convert its info into an XML format in order to
				//obtain the score
				convertToXMLComplex(p,xmlBuffer,xmlBufferSize, wordNum,volumeID, fileID);

				//get the score of this popped ancs.
				double score = scoreFunction(xmlBuffer, keywordSet); 
				
				//if the score is high enough, output this ancs
				if (ancsQualifies(score, keywordSet))
				{
					resultBuffer->initialize();
					resultBuffer->appendList((ListNode *)p->GetActualAncs(),1);
					resultBuffer->setScore(score);
					return SUCCESS;
				}
			}	
		}
		if (stackIsEmpty())
			return FAILURE;
	}
	return FAILURE;
}


int StackBasedTermJoin::copyDataToTop(SBTermJoinComplexStackNode *sn)
{
	//in this method, data associated with occurances of words in stack node sn
	//is copied to the top element of the stack

	//get stack top
	SBTermJoinComplexStackNode *top = complexAncsStack->GetTop();
	

	if (!(sn->EmptyListOfBuffers(sn->GetListOfBuffers())))
	{
		//if the source of the data has a list of buffers

		int strSize = 2* sizeof(serial_t) + sizeof(int);
		char str[100];
		int sz = 2*sizeof(serial_t);

		//copy the head and tail of the list
		memcpy(str,&sz,sizeof(int));
		serial_t h = sn->GetListOfBuffers()->GetHead();
		serial_t t = sn->GetListOfBuffers()->GetTail();
		memcpy(str+sizeof(int),&h,sizeof(serial_t));

		memcpy(str+sizeof(int)+sizeof(serial_t),&t,sizeof(serial_t));

		if (top->AddToBuffer(top->GetBuffer(),str,strSize) == FAILURE)
		{
			if (WriteBufferToItsList(top->GetBuffer(),top->GetListOfBuffers()) == FAILURE)
				return FAILURE;

			//add the head and tail to the buffer
			top->AddToBuffer(top->GetBuffer(),str,strSize);
		}	
	}

	if (!(sn->GetBuffer()->IsEmpty()))
	{
		//if teh source of data has buffer, then we want to write this buffer to the top of the stack's buffer
		if (top->AddToBuffer(top->GetBuffer(),sn->GetBuffer()->GetContainer(),
			sn->GetBuffer()->GetAddCursor()) == FAILURE)
		{
			//if the top of the stack has not enough space to accomodate the buffer, write top's buffer
			//to list
			if (WriteBufferToItsList(top->GetBuffer(),top->GetListOfBuffers()) == FAILURE)
				return FAILURE;
			// add the buffer of sn to the new buffer of top of the stack
			top->AddToBuffer(top->GetBuffer(),sn->GetBuffer()->GetContainer(),
					sn->GetBuffer()->GetAddCursor());
		}	
	}
	return SUCCESS;
}

void StackBasedTermJoin::PushNode(ComplexListNode *pushedNode)
{
	//in this method, pushedNode is pushed into the stack and initialized
	if (simpleScore)
	{
		ancsStack->Push(pushedNode);
		if (ancsStack->GetTop()->getCounterAt(0) == -1)
			ancsStack->GetTop()->setSize(wordNum);
	}
	else
	{
		complexAncsStack->Push(pushedNode);
		if (complexAncsStack->GetTop()->getCounterAt(0) == -1)
			complexAncsStack->GetTop()->setSize(wordNum);
		complexAncsStack->GetTop()->SetListsVolumeAndFileIDs(volumeID,fileID);
	}
}

void StackBasedTermJoin::actualPush()
{
	//in this method, we read the ancestors in teh array and push them into stack
	for (int i=tempActualSize-1; i>= 0; i--)
		PushNode(&tempArray[i]);
}

void StackBasedTermJoin::doubleArray()
{
	//in this method, we are doubling the size of tempArray
	ComplexListNode *tmp = tempArray;
	tempSize *= 2;
	tempArray = new ComplexListNode[tempSize];
	memcpy(tempArray,tmp,sizeof(ComplexListNode)*tempActualSize);
	delete [] tmp;
}

void StackBasedTermJoin::doubleXMLBuffer(char *&xmlBuffer, int &xmlBufferSize)
{
	//in this method, we are doubling the size ofthe xml buffer used to hold data
	//needed for scoring.
	char *tmp = xmlBuffer;
	xmlBufferSize *= 2;
	xmlBuffer = new char[xmlBufferSize];
	memcpy(xmlBuffer,tmp,strlen(tmp)+1);
	delete [] tmp;
}

int StackBasedTermJoin::whoseFirst()
{
	//in this method, it is decided which occurance of the words comes first
	KeyType minSK = DBL_MAX;
	int minOffset = INT_MAX;
	int minIndex = -1;
	for (int i=0; i<wordNum; i++)
	{
		//for each word, compare the start key and offset and find the one with the min
		if (inTuple[i])
		{
			if (((ListNode *)inTuple[i]->findNode(0))->GetStartPos() < minSK)
			{
				minSK = ((ListNode *)inTuple[i]->findNode(0))->GetStartPos();
				minOffset = ((ListNode *)inTuple[i]->findNode(0))->GetOffset();
				minIndex = i;
			}
			else if (((ListNode *)inTuple[i]->findNode(0))->GetStartPos() == minSK)
			{
				if (((ListNode *)inTuple[i]->findNode(0))->GetOffset() < minOffset)
				{
					minOffset = ((ListNode *)inTuple[i]->findNode(0))->GetOffset();
					minIndex = i;
				}
			}
		}
	}
	return minIndex;
}

void StackBasedTermJoin::incrementTopCounters(int which, int by)
{
	//in this method, counter "which" at the top of the stack is incremented by "by"
	if (stackIsEmpty())
		return;

	if (simpleScore)
		ancsStack->GetTop()->incrementCounterAt(which,by);
	else
		complexAncsStack->GetTop()->incrementCounterAt(which,by);
}

bool StackBasedTermJoin::stackIsEmpty()
{
	//returns true if the stack is empty
	return (simpleScore? ancsStack->IsEmpty() : complexAncsStack->IsEmpty());
}

void StackBasedTermJoin::convertToXML(SBTermJoinStackNode *sn, char *&xmlBuffer,
	int &xmlBufferSize, int wordNum, lvid_t volumeID,
	serial_t fileID)
{
	//in this method, information with stack node sn is converted into xml format
	//the info is mainly counters of occurances of different words under sn because
	//we are dealing wiht the simple scoring method.
	char tmp[500];
	xmlBuffer[0] = '\0';
	fileID = fileID;
	volumeID = volumeID;

	//write root to buffer
	strcpy(tmp,"<root>\n");
	accomodate(tmp,xmlBuffer,xmlBufferSize);
	strcat(xmlBuffer,tmp);

	//write the information of the ancestor itself
	if (sn->GetActualAncsComplex()->GetData())
		sprintf(tmp,"<ancsData sk=\"%.2f\" ek=\"%.2f\" level=\"%d\" tag=\"%d\" numOfChildren=\"%d\" />\n",
		sn->GetActualAncsComplex()->GetStartPos().toDouble(),
		sn->GetActualAncsComplex()->GetEndPos().toDouble(),
		sn->GetActualAncsComplex()->GetLevel(),
		((DM_ElementNode *)sn->GetActualAncsComplex()->GetData())->getTag(),
		sn->GetActualAncsComplex()->GetData()->getChildNumber());
	else
		sprintf(tmp,"<ancsData sk=\"%.2f\" ek=\"%.2f\" level=\"%d\" tag=\"%s\" numOfChildren=\"%d\" />\n",
		sn->GetActualAncsComplex()->GetStartPos().toDouble(),
		sn->GetActualAncsComplex()->GetEndPos().toDouble(),
		sn->GetActualAncsComplex()->GetLevel(),
		"Later",
		sn->GetActualAncsComplex()->GetOffset());
	accomodate(tmp,xmlBuffer,xmlBufferSize);
	strcat(xmlBuffer,tmp);

	//write the general stats of the words.
	sprintf(tmp,"<termStatistics numberOfTerms=\"%d\" scoringType=\"simple\">\n",wordNum);
	accomodate(tmp,xmlBuffer,xmlBufferSize);
	strcat(xmlBuffer,tmp);

	//write the counters of each of teh words.
	for (int i=0; i<wordNum; i++)
	{
		sprintf(tmp,"<term id=\"%d\" count=\"%d\" />\n",i,sn->getCounterAt(i));
		accomodate(tmp,xmlBuffer,xmlBufferSize);
		strcat(xmlBuffer,tmp);
	}

	//close tags.
	strcpy(tmp,"</termStatistics>\n");
	accomodate(tmp,xmlBuffer,xmlBufferSize);
	strcat(xmlBuffer,tmp);

	strcpy(tmp,"</root>\n");
	accomodate(tmp,xmlBuffer,xmlBufferSize);
	strcat(xmlBuffer,tmp);
}

void StackBasedTermJoin::accomodate(char *str, char *&xmlBuffer,
	int &xmlBufferSize)
{
	// this method makes sure the buffer has enough space for str
	int size = strlen(str) + strlen(xmlBuffer);
	size++;
	while (size >= xmlBufferSize)
		doubleXMLBuffer(xmlBuffer,xmlBufferSize);
}

void StackBasedTermJoin::convertToXMLComplex(SBTermJoinComplexStackNode *sn, char *&xmlBuffer,
	int &xmlBufferSize, int wordNum, lvid_t volumeID,
	serial_t fileID)
{
	//in this method, information with stack node sn is converted into xml format
	//the info is mainly counters of occurances of different words under sn  and
	// their locations in the original xml document.
	//we are dealing wiht the complex scoring method.
	char tmp[500];
	xmlBuffer[0] = '\0';

	//write root to buffer
	strcpy(tmp,"<root>\n");
	accomodate(tmp,xmlBuffer,xmlBufferSize);
	strcat(xmlBuffer,tmp);

	//write the information of the ancestor itself
	if (sn->GetActualAncsComplex()->GetData())
		sprintf(tmp,"<ancsData sk=\"%.2f\" ek=\"%.2f\" level=\"%d\" tag=\"%d\" numOfChildren=\"%d\" />\n",
		sn->GetActualAncsComplex()->GetStartPos().toDouble(),
		sn->GetActualAncsComplex()->GetEndPos().toDouble(),
		sn->GetActualAncsComplex()->GetLevel(),
		((DM_ElementNode *)sn->GetActualAncsComplex()->GetData())->getTag(),
		sn->GetActualAncsComplex()->GetData()->getChildNumber());
	else
		sprintf(tmp,"<ancsData sk=\"%.2f\" ek=\"%.2f\" level=\"%d\" tag=\"%s\" numOfChildren=\"%d\" />\n",
		sn->GetActualAncsComplex()->GetStartPos().toDouble(),
		sn->GetActualAncsComplex()->GetEndPos().toDouble(),
		sn->GetActualAncsComplex()->GetLevel(),
		"Later",
		sn->GetActualAncsComplex()->GetOffset());
	accomodate(tmp,xmlBuffer,xmlBufferSize);
	strcat(xmlBuffer,tmp);

	//write the general stats of the words.
	sprintf(tmp,"<termStatistics numberOfTerms=\"%d\" scoringType=\"complex\">\n",wordNum);
	accomodate(tmp,xmlBuffer,xmlBufferSize);
	strcat(xmlBuffer,tmp);


	//write the counters of each of teh words.
	for (int i=0; i<wordNum; i++)
	{
		sprintf(tmp,"<term id=\"%d\" count=\"%d\" />\n",i,sn->getCounterAt(i));
		accomodate(tmp,xmlBuffer,xmlBufferSize);
		strcat(xmlBuffer,tmp);
	}

	//close tag.
	strcpy(tmp,"</termStatistics>\n");
	accomodate(tmp,xmlBuffer,xmlBufferSize);
	strcat(xmlBuffer,tmp);


	//we are dealing with complex scoring, write the details of each of teh terms.
	strcpy(tmp,"<termDetails>\n");
	accomodate(tmp,xmlBuffer,xmlBufferSize);
	strcat(xmlBuffer,tmp);


	//read term info from list of sn if it has one and write to xml buffer
	if (!(sn->EmptyListOfBuffers(sn->GetListOfBuffers())))
		readFromList(sn->GetListOfBuffers()->GetHead(),sn->GetListOfBuffers()->GetTail(),xmlBuffer,xmlBufferSize,volumeID, fileID);

	//read term info from buffer of sn if it has one and write to xml buffer
	if (!(sn->GetBuffer()->IsEmpty()))
		readFromBuffer(sn->GetBuffer(),xmlBuffer,xmlBufferSize,volumeID, fileID);

	//close tags.
	strcpy(tmp,"</termDetails>\n");
	accomodate(tmp,xmlBuffer,xmlBufferSize);
	strcat(xmlBuffer,tmp);


	strcpy(tmp,"</root>\n");
	accomodate(tmp,xmlBuffer,xmlBufferSize);
	strcat(xmlBuffer,tmp);
}

int StackBasedTermJoin::getAncs(KeyType sk, char fileIndex,ComplexListNode &ancs)
{
	// in this method, parent of node with start key sk is read from somewhere
	// (DB or hash index) and put into var ancs

	if (this->parentIndexName)
	{
		//if we have a hash index for the parents, then get teh parent from there
		parentIndex->setKey(&sk);
		WitnessTree *ancsTree;
		parentIndex->next(ancsTree);
		if (!ancsTree)
			return FAILURE;
		ancs.setListNode((ListNode *)ancsTree->findNode(0));
	/*	ancs.SetStartPos(((ComplexListNode *)ancsTree->findNode(0))->GetStartPos());
		ancs.SetEndPos(((ComplexListNode *)ancsTree->findNode(0))->GetEndPos());
		ancs.SetLevel(((ComplexListNode *)ancsTree->findNode(0))->GetLevel());
		ancs.SetOffset(((ComplexListNode *)ancsTree->findNode(0))->GetOffset());
		ancs.setFileIndex(((ComplexListNode *)ancsTree->findNode(0))->getFileIndex());*/
	}
	else
	{
		//if we don't have a hash index for parents, read parent form DB
		WitnessTree t(LIST_NODE_WITH_DATA,dataMng);
		ComplexListNode nd;
		nd.SetStartPos(sk);
		nd.setFileIndex(fileIndex);
		t.appendList(&nd,dataMng,1);
		FileIDType fileid = EvaluatorClass::getFileID((int)fileIndex);
		if (fileid == -1)
			return FAILURE;

		//getting the parent
		int r = EvaluatorClass::getAncs(&t,0,1,dataMng,fileid);
		if (r == FAILURE)
			return FAILURE;

		//make sure it is an element node.
		if (((ComplexListNode *)t.getNodeByIndex(r))->GetData()->getFlag() != ELEMENT_NODE)
			return FAILURE;
		ancs = *((ComplexListNode *)t.getNodeByIndex(r));
		ancs.setNRE(assignedNRE);
	}
	return SUCCESS;
}

void StackBasedTermJoin::readFromList(serial_t head, serial_t tail, char *&xmlBuffer,
	int &xmlBufferSize, lvid_t volumeID,
	serial_t fileID)
{
	//in this method, a list with head and tail is read for the next buffer. 
	ShoreList sl;
	sl.SetVolumeID(volumeID);
	sl.SetFileID(fileID);
	sl.SetHead(head);
	sl.SetTail(tail);
	sl.StartScan();

	ContainerClass c;
	while (sl.GetNext(&c) == SUCCESS)
		readFromBuffer(&c,xmlBuffer,xmlBufferSize,volumeID, fileID);
}

void StackBasedTermJoin::readFromBuffer(ContainerClass *c, char *&xmlBuffer,
	int &xmlBufferSize, lvid_t volumeID,
	serial_t fileID)
{
	//in this method, a buffer is read for info about words
	int size;
	while (c->GetNext(sizeof(int),(char *)&size) == SUCCESS)
	{
		if (size == 2*sizeof(serial_t))
		{
			//if we are reading the buffer and found a list, read from the list
			serial_t h;
			c->GetNext(sizeof(serial_t),(char *)&h);
			
			serial_t t;
			c->GetNext(sizeof(serial_t),(char *)&t);
			
			readFromList(h,t,xmlBuffer,xmlBufferSize,volumeID, fileID);
		}
		else
		{
			//if we found actual data, then write it into the xml buffer
			int index;
			c->GetNext(sizeof(int),(char *)&index);
			char tmp[100];
			
			ListNode info;
			c->GetNext(sizeof(ListNode),(char *)&info);
			sprintf(tmp,"<term id=\"%d\" sk=\"%.2f\" ek=\"%.2f\" level=\"%d\" offset=\"%d\" />\n",
				index,info.GetStartPos().toDouble(),info.GetEndPos().toDouble(),info.GetLevel(),info.GetOffset());
			accomodate(tmp,xmlBuffer,xmlBufferSize);
			strcat(xmlBuffer,tmp);
		}
	}
}

int StackBasedTermJoin::addNodeToTop(int index)
{
	//in this method, current occurance of word "index" is added to the buffer of
	//the top of the stack.

	if (simpleScore)
		return SUCCESS;

	if (stackIsEmpty())
		return SUCCESS;

	//get top of stack
	SBTermJoinComplexStackNode *top = complexAncsStack->GetTop();

	//figure  out the size of the written word
	int strSize = sizeof(ListNode)+sizeof(int)+sizeof(int);
	char str[100];
	int sz = sizeof(ListNode)+sizeof(int);
	//write the size
	memcpy(str,&sz,sizeof(int));
	int i = index;
	//write the index of the word
	memcpy(str+sizeof(int),&i,sizeof(int));
	//write the info of the node
	memcpy(str+sizeof(int)+sizeof(int),inTuple[index]->findNode(0),sizeof(ListNode));

	//add to the buffer of the top
	if (top->AddToBuffer(top->GetBuffer(),str,strSize) == FAILURE)
	{
		//if there is no space left in the buffer of the top of the stack, write this buffer to 
		//the list
		if (WriteBufferToItsList(top->GetBuffer(),top->GetListOfBuffers()) == FAILURE)
				return FAILURE;
		top->AddToBuffer(top->GetBuffer(),str,strSize);
	}
	return SUCCESS;
}

int StackBasedTermJoin::WriteBufferToItsList(ContainerClass *cont, ShoreList *list)
{
	if (cont->IsEmpty())
		return SUCCESS;

	if (list->IsEmpty())
	{
		serial_t currRecID = startID;
		if (startID.increment(1) == true)
			//overflow of shore logical ids
		{
			globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"Evaluator",__FILE__,"Shore Logical ID overflow.");
			return FAILURE;
		}
		if (SBJoinAncsStackNode::WriteBufferToList(cont,list,fileID,volumeID,currRecID,startID) == FAILURE)
			return FAILURE;
		if (startID.increment(1) == true)
			//overflow of shore logical ids
		{
			globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"Evaluator",__FILE__,"Shore Logical ID overflow.");
			return FAILURE;
		}
	}
	else
	{
		if (SBJoinAncsStackNode::WriteBufferToList(cont,list,startID) == FAILURE)
			return FAILURE;
		if (startID.increment(1) == true)
			//overflow of shore logical ids
		{
			globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"Evaluator",__FILE__,"Shore Logical ID overflow.");
			return FAILURE;
		}
	}
	cont->Initialize();
	return SUCCESS;
}

