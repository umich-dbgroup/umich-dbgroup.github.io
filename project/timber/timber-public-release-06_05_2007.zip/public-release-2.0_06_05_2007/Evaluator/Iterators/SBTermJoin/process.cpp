#include "../../Evaluator/EvaluatorClass.h"

#include "QueryEvaluationTreeSBTermJoinNode.h"

#include "MeetIterator.h"
#include "StackBasedTermJoin.h"
#include "extra.h"

double nullScoreFunction(char *xmlDoc, int keywordSet)
{
        keywordSet = keywordSet;
	    xmlDoc = xmlDoc;
	        return -1;
}
bool nullAncsQual(double score, int keywordSet)
{
        score = score;
	    keywordSet = keywordSet;
	        return true;
}
int nullAncsLevel(KeyType sk, int level, int keywordSet)
{
        sk = sk;
	    level = level;
	        keywordSet = keywordSet;
		    return -1;
}

void QueryEvaluationTreeSBTermJoinNode::processQueryEvalNode(EvaluatorClass* evaluator, IteratorClass*& curr)
	    {
		double (*f1)(char *xmlDoc, int keywordSet);
		int (*f2)(KeyType sk, int lev, int keywordSet);
		bool (*f3)(double score, int keywordSet);
		switch (getFunctionNum1())
		{
		    case 1:
			f1 = scoreFunction1;
			break;
		    case 2:
			f1 = scoreFunction2;
			break;
		    case 3:
			f1 = nullScoreFunction;
			break;
		    default: 
			globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"Evaluator",__FILE__, "unrecognized function number 1. term join process eval node..." );
			curr=NULL; return;
		}
		switch (getFunctionNum2())
		{
		    case 1:
			f2 = ancsLevel1;
			break;
		    case 3:
			f2 = nullAncsLevel;
			break;
		    default:  
			globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"Evaluator",__FILE__, "unrecognized function number 2. term join process eval node..." );
			curr=NULL; return;
		}
		switch (getFunctionNum3())
		{
		    case 1:
			f3 = ancsQual1;
			break;
		    case 3:
			f3 = nullAncsQual;
			break;
		    default:
			globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"Evaluator",__FILE__, "unrecognized function number 3. term join process eval node..." );
			curr=NULL; return;
		}
		int openFileIndex = evaluator->openFile(getFileName(),evaluator->getDataManager());
		if (openFileIndex == -1)
		{
		    globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"Evaluator",__FILE__,"File is unloaded in Timber.");
		    curr=NULL; return;
		}
		if (getMeetAlg())
		    curr = new MeetIterator(getPhrase(),getIndexName(),(char)openFileIndex,
			    f1,f2,f3,getParentIndexName(),
			    getBufPoolSize(), getKeywordSet(),getAssignedNRE(),evaluator->getDataManager(),getSimpleScore());
		else
		    curr = new StackBasedTermJoin(getPhrase(), getIndexName(), (char)openFileIndex,
			    f1, f2, f3, getDepth(), getParentIndexName(), 
			    getBufPoolSize(), getAssignedNRE(), evaluator->getDataManager(), getSimpleScore(), 
			    getKeywordSet());
		setIndexName(NULL);
		setParentIndexName(NULL);
		setPhrase(NULL);
	    }

