/*
COPYRIGHT  � 2000-2004 
THE REGENTS OF THE UNIVERSITY OF MICHIGAN
ALL RIGHTS RESERVED

PERMISSION IS GRANTED TO USE, COPY, CREATE DERIVATIVE WORKS AND REDISTRIBUTE THIS SOFTWARE AND SUCH DERIVATIVE WORKS FOR 
NONCOMMERCIAL EDUCATION AND RESEARCH PURPOSES, SO LONG AS NO FEE IS CHARGED, AND SO LONG AS THE COPYRIGHT NOTICE ABOVE, 
THIS GRANT OF PERMISSION, AND THE DISCLAIMER BELOW APPEAR IN ALL COPIES MADE; AND SO LONG AS THE NAME OF THE UNIVERSITY 
OF MICHIGAN IS NOT USED IN ANY ADVERTISING OR PUBLICITY PERTAINING TO THE USE OR DISTRIBUTION OF THIS SOFTWARE WITHOUT 
SPECIFIC, WRITTEN PRIOR AUTHORIZATION.

THIS SOFTWARE IS PROVIDED AS IS, WITHOUT REPRESENTATION FROM THE UNIVERSITY OF MICHIGAN AS TO ITS FITNESS FOR ANY PURPOSE, 
AND WITHOUT WARRANTY BY THE UNIVERSITY OF MICHIGAN OF ANY KIND, EITHER EXPRESS OR IMPLIED, INCLUDING WITHOUT LIMITATION THE 
IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE. THE REGENTS OF THE UNIVERSITY OF MICHIGAN SHALL 
NOT BE LIABLE FOR ANY DAMAGES, INCLUDING SPECIAL, INDIRECT, INCIDENTAL, OR CONSEQUENTIAL DAMAGES, WITH RESPECT TO ANY CLAIM 
ARISING OUT OF OR IN CONNECTION WITH THE USE OF THE SOFTWARE, EVEN IF IT HAS BEEN OR IS HEREAFTER ADVISED OF THE POSSIBILITY 
OF SUCH DAMAGES.
*/

#include "QueryEvaluationTreeSBTermJoinNode.h"

QueryEvaluationTreeSBTermJoinNode::QueryEvaluationTreeSBTermJoinNode(NREType assignedNRE,char* indexName,char* fileName,char *phrase, 
											int functionNum1, int functionNum2, int functionNum3, 
                                            int depth, bool simpleScore, int keywordSet,
                                            bool meetAlg, char *parentIndexName, int bufPoolSize)
: QueryEvaluationTreeNode()
{
	this->assignedNRE = assignedNRE;
	this->indexName = indexName;
	this->fileName = fileName;
	this->phrase = phrase;

    this->functionNum1 = functionNum1;
	this->functionNum2 = functionNum2;
	this->functionNum3 = functionNum3;

    this->depth = depth;
	this->simpleScore = simpleScore;
    this->keywordSet = keywordSet;

    this->meetAlg = meetAlg;
	this->parentIndexName = parentIndexName;
	this->bufPoolSize = bufPoolSize;
}

QueryEvaluationTreeSBTermJoinNode::~QueryEvaluationTreeSBTermJoinNode()
{
	delete [] fileName;
}

NREType QueryEvaluationTreeSBTermJoinNode::getAssignedNRE()
{
	return this->assignedNRE;
}

void QueryEvaluationTreeSBTermJoinNode::setAssignedNRE(NREType assignedNRE)
{
	this->assignedNRE = assignedNRE;
}


void QueryEvaluationTreeSBTermJoinNode::setFileName(char *fileName)
{
	this->fileName = fileName;
}

char *QueryEvaluationTreeSBTermJoinNode::getFileName()
{
	return this->fileName;
}

void QueryEvaluationTreeSBTermJoinNode::setIndexName(char* indexname)
{
	this->indexName = indexname;
}

char* QueryEvaluationTreeSBTermJoinNode::getIndexName()
{
	return this->indexName;
}

void QueryEvaluationTreeSBTermJoinNode::setPhrase(char* phrase)
{
	this->phrase = phrase;
}

char* QueryEvaluationTreeSBTermJoinNode::getPhrase()
{
	return this->phrase;
}

void QueryEvaluationTreeSBTermJoinNode::setFunctionNum1(int functionNum1)
{
	this->functionNum1 = functionNum1;
}

void QueryEvaluationTreeSBTermJoinNode::setFunctionNum2(int functionNum2)
{
	this->functionNum2 = functionNum2;
}

void QueryEvaluationTreeSBTermJoinNode::setFunctionNum3(int functionNum3)
{
	this->functionNum3 = functionNum3;
}

int QueryEvaluationTreeSBTermJoinNode::getFunctionNum1()
{
	return functionNum1;
}

int QueryEvaluationTreeSBTermJoinNode::getFunctionNum2()
{
	return functionNum2;
}

int QueryEvaluationTreeSBTermJoinNode::getFunctionNum3()
{
	return functionNum3;
}

void QueryEvaluationTreeSBTermJoinNode::setDepth(int depth)
{
	this->depth = depth;
}

int QueryEvaluationTreeSBTermJoinNode::getDepth()
{
	return depth;
}

void QueryEvaluationTreeSBTermJoinNode::setSimpleScore(bool simpleScore)
{
	this->simpleScore = simpleScore;
}

bool QueryEvaluationTreeSBTermJoinNode::getSimpleScore()
{
	return simpleScore;
}

void QueryEvaluationTreeSBTermJoinNode::setKeywordSet(int keywordSet)
{
    this->keywordSet = keywordSet;
}

int QueryEvaluationTreeSBTermJoinNode::getKeywordSet()
{
	return keywordSet;
}

// deprecated methods
void QueryEvaluationTreeSBTermJoinNode::setMeetAlg(bool meetAlg)
{
	this->meetAlg = meetAlg;
}

bool QueryEvaluationTreeSBTermJoinNode::getMeetAlg()
{
	return this->meetAlg;
}

void QueryEvaluationTreeSBTermJoinNode::setParentIndexName(char* parentIndexName)
{
	this->parentIndexName = parentIndexName;
}

char* QueryEvaluationTreeSBTermJoinNode::getParentIndexName()
{
	return this->parentIndexName;
}

void QueryEvaluationTreeSBTermJoinNode::setBufPoolSize(int bufPoolSize)
{
	this->bufPoolSize = bufPoolSize;
}

int QueryEvaluationTreeSBTermJoinNode::getBufPoolSize()
{
	return this->bufPoolSize;
}

void QueryEvaluationTreeSBTermJoinNode::deleteStructures()
{
	if (indexName) delete [] indexName;
	if (parentIndexName) delete [] parentIndexName;
	if (phrase) delete [] phrase;
}
