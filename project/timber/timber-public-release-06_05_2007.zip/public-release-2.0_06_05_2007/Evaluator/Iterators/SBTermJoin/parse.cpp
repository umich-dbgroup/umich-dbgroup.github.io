
#include "parse.hpp"

char QueryEvaluationTreeSBTermJoinNode::getIdentifier(void) { return 't'; }

char SBTermJoinPlanParser::getIteratorIdentifier(void) { return 't'; }

void 
SBTermJoinPlanParser::getQueryEvalNode(EvaluatorClass* evaluator, char* line, void* queryInput, QueryEvaluationTreeNode*& curr)
	    {
		// index name
		char *token = strtok(line+2,",");
		if (token == NULL)
		{
		    globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"Evaluator",__FILE__,"Error input from file... expecting assigned NRE... Index Access line...");
		    curr=NULL; return;
		}
		NREType assignedNRE = (NREType)atoi(token);
		if (assignedNRE < 1)
		{
		    globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"Evaluator",__FILE__,"NRE should be positive.");   
		    curr=NULL; return;
		}
		if (assignedNRE > evaluator->maxNRE)
		    evaluator->maxNRE = assignedNRE;

		token = strtok(NULL,",");
		char *indexName;
		if (token == NULL)
		{
		    globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"Evaluator",__FILE__,"Error input from file... expecting index name... term join line...");
		    curr=NULL; return;
		}
		indexName = new char[strlen(token)+1];
		strcpy(indexName,token);

		// index file name
		token = strtok(NULL,",");
		char *fileName;
		if (token == NULL)
		{
		    globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"Evaluator",__FILE__,"Error input from file... expecting xml fileName... term join line...");
		    delete [] indexName;
		    curr=NULL; return;
		}
		fileName = new char[strlen(token)+1];
		strcpy(fileName,token);

		// phrases
		token = strtok(NULL,",");
		if (token == NULL)
		{
		    globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"Evaluator",__FILE__,"Error input from file... expecting phrase... term join line...");
		    delete [] indexName;
		    delete [] fileName;
		    curr=NULL; return;
		}
		char *phrase = new char[strlen(token)+1];
		strcpy(phrase,token);

		// score function
		token = strtok(NULL,",");
		if (token == NULL)
		{
		    globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"Evaluator",__FILE__,"Error input from file... expecting function 1 number... term join line...");
		    delete [] phrase;
		    delete [] indexName;
		    delete [] fileName;
		    curr=NULL; return;
		}
		int f1 = atoi(token);

		// ancestor depth function
		token = strtok(NULL,",");
		if (token == NULL)
		{
		    globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"Evaluator",__FILE__,"Error input from file... expecting function 2 number... term join line...");
		    delete [] phrase; 
		    delete [] indexName;
		    delete [] fileName;
		    curr=NULL; return;
		}
		int f2 = atoi(token);

		// ancetor qualifcations function
		token = strtok(NULL,",");
		if (token == NULL)
		{
		    globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"Evaluator",__FILE__,"Error input from file... expecting function 3 number... term join line...");
		    delete [] phrase; 
		    delete [] indexName;
		    delete [] fileName;
		    curr=NULL; return;
		}
		int f3 = atoi(token);

		// expected depth of the document
		token = strtok(NULL,",");
		if (token == NULL)
		{
		    globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"Evaluator",__FILE__,"Error input from file... expecting depth... term join line...");
		    delete [] phrase;  
		    delete [] indexName;
		    delete [] fileName;
		    curr=NULL; return;
		}
		int depth = atoi(token);

		// score type
		token = strtok(NULL,",");
		if (token == NULL)
		{
		    globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"Evaluator",__FILE__,"Error input from file... expecting simple score or not... term join line...");
		    delete [] phrase;  
		    delete [] indexName;
		    delete [] fileName;
		    curr=NULL; return;
		}
		if (atoi(token) != 0 && atoi(token) != 1)
		{
		    globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"Evaluator",__FILE__,"Error input from file... expecting simple score should be 0 or 1... term join line...");
		    delete [] phrase;  
		    delete [] indexName;
		    delete [] fileName;
		    curr=NULL; return;
		}
		bool simpleScore = (bool)atoi(token);

		// identifier for keyword set
		// it there is further argument, it must be present
		token = strtok(NULL,",");
		if (token == NULL)
		{
		    globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"Evaluator",__FILE__,"Error input from file... expecting id for keyword set ... term join line...");
		    delete [] phrase; 
		    delete [] indexName;
		    delete [] fileName;
		    curr=NULL; return;
		}
		int keywordSet = atoi(token);

		//// algorithm type: meet or termjoin

		token = strtok(NULL,",");
		if (token == NULL)
		{
		    globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"Evaluator",__FILE__,"Error input from file... expecting using meet alg or not... term join line...");
		    delete [] indexName;
		    delete [] fileName;
		    delete [] phrase;
		    curr=NULL; return;
		}
		if (atoi(token) != 0 && atoi(token) != 1)
		{
		    globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"Evaluator",__FILE__,"Error input from file... meet algorithm should be 0 or 1... term join line...");
		    delete [] phrase; 
		    delete [] indexName;
		    delete [] fileName;
		    curr=NULL; return;
		}
		bool meetAlg = (bool)atoi(token);

		//// index access the parent
		token = strtok(NULL,",");
		char *parentIndexName = NULL;
		int bufPoolSize = 10;
		if (token != NULL)
		{
		    parentIndexName = new char[strlen(token)+1];
		    strcpy(parentIndexName,token);
		    token = strtok(NULL,",");
		    if (token != NULL)
			bufPoolSize = atoi(token);
		}

		curr  = new QueryEvaluationTreeSBTermJoinNode(assignedNRE,indexName, fileName, phrase, f1,f2,f3,
			depth, simpleScore, keywordSet,
			meetAlg, parentIndexName, bufPoolSize);
	    }

