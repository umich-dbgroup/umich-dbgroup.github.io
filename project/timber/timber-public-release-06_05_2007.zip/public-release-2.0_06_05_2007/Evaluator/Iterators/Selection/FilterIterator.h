/*
COPYRIGHT  � 2000-2004 
THE REGENTS OF THE UNIVERSITY OF MICHIGAN
ALL RIGHTS RESERVED

PERMISSION IS GRANTED TO USE, COPY, CREATE DERIVATIVE WORKS AND REDISTRIBUTE THIS SOFTWARE AND SUCH DERIVATIVE WORKS FOR 
NONCOMMERCIAL EDUCATION AND RESEARCH PURPOSES, SO LONG AS NO FEE IS CHARGED, AND SO LONG AS THE COPYRIGHT NOTICE ABOVE, 
THIS GRANT OF PERMISSION, AND THE DISCLAIMER BELOW APPEAR IN ALL COPIES MADE; AND SO LONG AS THE NAME OF THE UNIVERSITY 
OF MICHIGAN IS NOT USED IN ANY ADVERTISING OR PUBLICITY PERTAINING TO THE USE OR DISTRIBUTION OF THIS SOFTWARE WITHOUT 
SPECIFIC, WRITTEN PRIOR AUTHORIZATION.

THIS SOFTWARE IS PROVIDED AS IS, WITHOUT REPRESENTATION FROM THE UNIVERSITY OF MICHIGAN AS TO ITS FITNESS FOR ANY PURPOSE, 
AND WITHOUT WARRANTY BY THE UNIVERSITY OF MICHIGAN OF ANY KIND, EITHER EXPRESS OR IMPLIED, INCLUDING WITHOUT LIMITATION THE 
IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE. THE REGENTS OF THE UNIVERSITY OF MICHIGAN SHALL 
NOT BE LIABLE FOR ANY DAMAGES, INCLUDING SPECIAL, INDIRECT, INCIDENTAL, OR CONSEQUENTIAL DAMAGES, WITH RESPECT TO ANY CLAIM 
ARISING OUT OF OR IN CONNECTION WITH THE USE OF THE SOFTWARE, EVEN IF IT HAS BEEN OR IS HEREAFTER ADVISED OF THE POSSIBILITY 
OF SUCH DAMAGES.
*/

#ifndef __Filteriterator_h
#define __Filteriterator_h
#include <timber-compat.h>

#include "FilterCondition.h"
#include "../../Evaluator/EvaluatorClass.h"
#include "../IndexAccess/GistIndexAccess.h"

/**
* An access method that filters trees and passes only the ones that satisfy a given
* criteria.
* @see WitnessTree
* @see FilterCondition
* @see DataMng
* @see IteratorClass
* @author Shurug Al-Khalifa 
* @version 1.0
*/

class FilterIterator : public IteratorClass
{
public:
	/**
	Constructor.
	@param input is the source of the input trees to this iterator.
	@param num is the number of 
	@param condition an array of conditions where you want at least one of them to be true 
			each entry in the array has a bunch of predicates separated by "and".
			nodes that satisfy these conditions are passed.
	@param data_mng an instance of the data manager.
	**/
	FilterIterator(IteratorClass *input,int num, FilterCondition *condition,
		  DataMng *dataMng);

	/**
	Destructor
	releases the space used by output buffer.
	**/
	~FilterIterator();

	/**
	Access Method
	gets the next output from this iterator.
	@param node is a pointer that well be set to the output buffer or NULL (indicating that
	there are no more results).
	**/
	void next(WitnessTree *&node);
private:
	/**
	Access Method
	returns true if input tree in satisfies the condition. Otherwise, it returns false.
	@param in is a tree that we need to verify whether or not it satisfies the condition.
	@returns true if in satisfies condition. otherwise, it returns false.
	**/
	bool satisfiesCondition(WitnessTree *in);
	

	bool satisfiesOneOr(WitnessTree *in, FilterCondition *cond);
	bool satisfiesOneAnd(WitnessTree *in, FilterPredicate *cond);

	int getNum(WitnessTree *in,int type,double num,int index, char *str, double &valReturned);
	int getStr(WitnessTree *in,int type,double num,int index, char *str, char *&valReturned);


	int getVal(DM_DataNode *n, char *str, char *&value);
	bool getMatchesFromIndex(int leftIndex, int rightIndex, char *indexName, char openFileIndex);

	/**
	source of the input trees to this iterator.
	**/
	IteratorClass *input;

	/**
	the condition that we need to check input trees against.
	**/
	FilterCondition *condition;
	 

	/**
	instance of the data manager.
	**/
	DataMng *dataMng;

	/**
	Buffer that holds the output tree. 
	**/
	WitnessTree *resultBuffer;

	/**
	Pointer to the input tree read from input.
	**/
	WitnessTree *inTuple;

	/**
	number of conditions in the conditions array.
	**/
	int num;

	KeyType lastSK;
	int offset;
	KeyType currSK;

	void deleteLeftStr(char *&leftStr, FilterPredicate *cond);
	void deleteRightStr(char *&rightStr, FilterPredicate *cond);

};

#endif
