#include "../../Evaluator/EvaluatorClass.h"

#include "QueryEvaluationTreeSelectionNode.h"

#include "FilterIterator.h"
#include "extra.h"

void QueryEvaluationTreeSelectionNode::processQueryEvalNode(EvaluatorClass* evaluator, IteratorClass*& curr)
	    {
		for (int i=0; i<getNum(); i++)
		{
		    for (int j=0; j<getSelectionCondition()[i].getNum(); j++)
		    {
			if (getSelectionCondition()[i].getCondAt(j)->getFileName())
			{
			    int openFileIndex = evaluator->openFile(getSelectionCondition()[i].getCondAt(j)->getFileName(),evaluator->getDataManager(),
				    evaluator->capacityChoice, evaluator->capacity, evaluator->replacementChoice, evaluator->replacementPercentage);
			    if (openFileIndex == -1)
			    {
				globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"Evaluator",__FILE__,"File is unloaded in Timber.");
				curr=NULL; return;
			    } 

			    getSelectionCondition()[i].getCondAt(j)->setOpenFileIndex(openFileIndex);
			}
		    }
		}

		IteratorClass *opr = evaluator->processQueryEvalNode(getOperand());
		if (opr == NULL)
		{
		    globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"Evaluator",__FILE__, "operand returned is NULL. filter process eval node..." );
		    curr=NULL; return;
		}

		curr = new FilterIterator(opr,getNum(),getSelectionCondition(),evaluator->getDataManager());
		setSelectionCondition(NULL);    
	    }

