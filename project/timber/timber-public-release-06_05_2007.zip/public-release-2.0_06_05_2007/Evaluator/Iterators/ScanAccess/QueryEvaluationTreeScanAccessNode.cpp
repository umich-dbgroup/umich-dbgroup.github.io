/*
COPYRIGHT  � 2000-2004 
THE REGENTS OF THE UNIVERSITY OF MICHIGAN
ALL RIGHTS RESERVED

PERMISSION IS GRANTED TO USE, COPY, CREATE DERIVATIVE WORKS AND REDISTRIBUTE THIS SOFTWARE AND SUCH DERIVATIVE WORKS FOR 
NONCOMMERCIAL EDUCATION AND RESEARCH PURPOSES, SO LONG AS NO FEE IS CHARGED, AND SO LONG AS THE COPYRIGHT NOTICE ABOVE, 
THIS GRANT OF PERMISSION, AND THE DISCLAIMER BELOW APPEAR IN ALL COPIES MADE; AND SO LONG AS THE NAME OF THE UNIVERSITY 
OF MICHIGAN IS NOT USED IN ANY ADVERTISING OR PUBLICITY PERTAINING TO THE USE OR DISTRIBUTION OF THIS SOFTWARE WITHOUT 
SPECIFIC, WRITTEN PRIOR AUTHORIZATION.

THIS SOFTWARE IS PROVIDED AS IS, WITHOUT REPRESENTATION FROM THE UNIVERSITY OF MICHIGAN AS TO ITS FITNESS FOR ANY PURPOSE, 
AND WITHOUT WARRANTY BY THE UNIVERSITY OF MICHIGAN OF ANY KIND, EITHER EXPRESS OR IMPLIED, INCLUDING WITHOUT LIMITATION THE 
IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE. THE REGENTS OF THE UNIVERSITY OF MICHIGAN SHALL 
NOT BE LIABLE FOR ANY DAMAGES, INCLUDING SPECIAL, INDIRECT, INCIDENTAL, OR CONSEQUENTIAL DAMAGES, WITH RESPECT TO ANY CLAIM 
ARISING OUT OF OR IN CONNECTION WITH THE USE OF THE SOFTWARE, EVEN IF IT HAS BEEN OR IS HEREAFTER ADVISED OF THE POSSIBILITY 
OF SUCH DAMAGES.
*/

#include "QueryEvaluationTreeScanAccessNode.h"

QueryEvaluationTreeScanAccessNode::QueryEvaluationTreeScanAccessNode(char* filename, NREType nre,
		KeyType scanRoot, 
		SelectionCondition* scancond,
		ScanRange* scanrange)
: QueryEvaluationTreeNode()
{
	strcpy(this->xmlFileName, filename);
	this->nre = nre;
	this->scanRoot = scanRoot;
	this->scanCondition = scancond;
	this->scanRange = scanrange;
	
}

QueryEvaluationTreeScanAccessNode::~QueryEvaluationTreeScanAccessNode()
{
}

char* QueryEvaluationTreeScanAccessNode::getFileName()
{
	return this->xmlFileName;
}

KeyType QueryEvaluationTreeScanAccessNode::getScanRoot()
{
	return this->scanRoot;
}

SelectionCondition* QueryEvaluationTreeScanAccessNode::getScanCondition()
{
	return this->scanCondition;
}

ScanRange* QueryEvaluationTreeScanAccessNode::getScanRange()
{
	return this->scanRange;
}

void QueryEvaluationTreeScanAccessNode::setFileName(char* filename)
{
	strcpy(this->xmlFileName, filename);
}

void QueryEvaluationTreeScanAccessNode::setScanRoot(KeyType rootkey)
{
	this->scanRoot = rootkey;
}

void QueryEvaluationTreeScanAccessNode::setScanCondition(SelectionCondition* scancond)
{
	this->scanCondition = scancond;
}

void QueryEvaluationTreeScanAccessNode::setScanRange(ScanRange* scanrange)
{
	this->scanRange = scanrange;
}

NREType QueryEvaluationTreeScanAccessNode::getNRE()
{
	return nre;
}

void QueryEvaluationTreeScanAccessNode::setNRE(NREType nre)
{
	this->nre = nre;
}

/*void QueryEvaluationTreeScanAccessNode::printQueryEvaluationTreeNode(bool recursive, int depth)
{
	char prefix[50] = "";
	for (int i=0; i<depth; i++);
	{
		strcpy(prefix+i*4, "    ");
	}

	printf("%sThis is a Scan Access Node\n", prefix);
	printf("%s  xmlfilename = %s\n", prefix, this->xmlFileName);
	printf("%s  scan root key = %f\n", prefix, this->scanRoot);
}*/

void QueryEvaluationTreeScanAccessNode::deleteStructures()
{
	if (this->scanCondition) delete this->scanCondition;
	if (this->scanRange) delete this->scanRange;
}
