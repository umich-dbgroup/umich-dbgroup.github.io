#include "../../Evaluator/EvaluatorClass.h"

#include "extra.h"

class FileReaderPlanParser
{
public:

	static char getIteratorIdentifier(void) ;

	static void getQueryEvalNode(EvaluatorClass* evaluator, char* line, 
			void* queryInput, QueryEvaluationTreeNode*& curr) ;
} ;

#ifndef WIN32

extern "C" char getIteratorIdentifier(void) 
{ 
	return FileReaderPlanParser::getIteratorIdentifier() ;
} ;

extern "C" void getQueryEvalNode(EvaluatorClass* evaluator, char* line, 
			void* queryInput, QueryEvaluationTreeNode*& curr)
{
	return FileReaderPlanParser::getQueryEvalNode(evaluator, line, queryInput, curr) ;
} ;

#endif
