/*
COPYRIGHT  � 2000-2004 
THE REGENTS OF THE UNIVERSITY OF MICHIGAN
ALL RIGHTS RESERVED

PERMISSION IS GRANTED TO USE, COPY, CREATE DERIVATIVE WORKS AND REDISTRIBUTE THIS SOFTWARE AND SUCH DERIVATIVE WORKS FOR 
NONCOMMERCIAL EDUCATION AND RESEARCH PURPOSES, SO LONG AS NO FEE IS CHARGED, AND SO LONG AS THE COPYRIGHT NOTICE ABOVE, 
THIS GRANT OF PERMISSION, AND THE DISCLAIMER BELOW APPEAR IN ALL COPIES MADE; AND SO LONG AS THE NAME OF THE UNIVERSITY 
OF MICHIGAN IS NOT USED IN ANY ADVERTISING OR PUBLICITY PERTAINING TO THE USE OR DISTRIBUTION OF THIS SOFTWARE WITHOUT 
SPECIFIC, WRITTEN PRIOR AUTHORIZATION.

THIS SOFTWARE IS PROVIDED AS IS, WITHOUT REPRESENTATION FROM THE UNIVERSITY OF MICHIGAN AS TO ITS FITNESS FOR ANY PURPOSE, 
AND WITHOUT WARRANTY BY THE UNIVERSITY OF MICHIGAN OF ANY KIND, EITHER EXPRESS OR IMPLIED, INCLUDING WITHOUT LIMITATION THE 
IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE. THE REGENTS OF THE UNIVERSITY OF MICHIGAN SHALL 
NOT BE LIABLE FOR ANY DAMAGES, INCLUDING SPECIAL, INDIRECT, INCIDENTAL, OR CONSEQUENTIAL DAMAGES, WITH RESPECT TO ANY CLAIM 
ARISING OUT OF OR IN CONNECTION WITH THE USE OF THE SOFTWARE, EVEN IF IT HAS BEEN OR IS HEREAFTER ADVISED OF THE POSSIBILITY 
OF SUCH DAMAGES.
*/

#include "QueryEvaluationTreePickNode.h"

QueryEvaluationTreePickNode::QueryEvaluationTreePickNode(QueryEvaluationTreeNode* operand,  
											int functionNum1, int functionNum2, bool sort)
: QueryEvaluationTreeNode()
{
	this->functionNum1 = functionNum1;
	this->functionNum2 = functionNum2;
	this->operand = operand;
	this->sort = sort;
}

QueryEvaluationTreePickNode::~QueryEvaluationTreePickNode()
{
	if (operand)
		delete operand;
}


QueryEvaluationTreeNode* QueryEvaluationTreePickNode::getOperand()
{
	return operand;
}

void QueryEvaluationTreePickNode::setOperand(QueryEvaluationTreeNode *operand)
{
	this->operand = operand;
}


int QueryEvaluationTreePickNode::getFunctionNum1()
{
	return functionNum1;
}

void QueryEvaluationTreePickNode::setFunctionNum1(int functionNum1)
{
	this->functionNum1 = functionNum1;
}

int QueryEvaluationTreePickNode::getFunctionNum2()
{
	return functionNum2;
}

void QueryEvaluationTreePickNode::setFunctionNum2(int functionNum2)
{
	this->functionNum2 = functionNum2;
}


bool QueryEvaluationTreePickNode::getSort()
{
	return this->sort;
}

void QueryEvaluationTreePickNode::setSort(bool sort)
{
	this->sort = sort;
}

void QueryEvaluationTreePickNode::deleteStructures()
{
	operand->deleteStructures();
}
