#include "../../Evaluator/EvaluatorClass.h"

#include "extra.h"

class PickPlanParser
{
public:

	static char getIteratorIdentifier(void) ;

	static void getQueryEvalNode(EvaluatorClass* evaluator, char* line, void* queryInput, QueryEvaluationTreeNode*& curr) ;

} ;

#ifndef WIN32

extern "C" char getIteratorIdentifier(void)
{
	return PickPlanParser::getIteratorIdentifier() ;
} ;

extern "C" void getQueryEvalNode(EvaluatorClass* evaluator, char* line, void* queryInput, QueryEvaluationTreeNode*& curr)
{
	return PickPlanParser::getQueryEvalNode(evaluator, line, queryInput, curr) ;
}

#endif
