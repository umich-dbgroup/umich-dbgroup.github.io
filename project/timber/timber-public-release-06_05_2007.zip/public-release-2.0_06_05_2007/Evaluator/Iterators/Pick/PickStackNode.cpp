/*
COPYRIGHT  � 2000-2004 
THE REGENTS OF THE UNIVERSITY OF MICHIGAN
ALL RIGHTS RESERVED

PERMISSION IS GRANTED TO USE, COPY, CREATE DERIVATIVE WORKS AND REDISTRIBUTE THIS SOFTWARE AND SUCH DERIVATIVE WORKS FOR 
NONCOMMERCIAL EDUCATION AND RESEARCH PURPOSES, SO LONG AS NO FEE IS CHARGED, AND SO LONG AS THE COPYRIGHT NOTICE ABOVE, 
THIS GRANT OF PERMISSION, AND THE DISCLAIMER BELOW APPEAR IN ALL COPIES MADE; AND SO LONG AS THE NAME OF THE UNIVERSITY 
OF MICHIGAN IS NOT USED IN ANY ADVERTISING OR PUBLICITY PERTAINING TO THE USE OR DISTRIBUTION OF THIS SOFTWARE WITHOUT 
SPECIFIC, WRITTEN PRIOR AUTHORIZATION.

THIS SOFTWARE IS PROVIDED AS IS, WITHOUT REPRESENTATION FROM THE UNIVERSITY OF MICHIGAN AS TO ITS FITNESS FOR ANY PURPOSE, 
AND WITHOUT WARRANTY BY THE UNIVERSITY OF MICHIGAN OF ANY KIND, EITHER EXPRESS OR IMPLIED, INCLUDING WITHOUT LIMITATION THE 
IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE. THE REGENTS OF THE UNIVERSITY OF MICHIGAN SHALL 
NOT BE LIABLE FOR ANY DAMAGES, INCLUDING SPECIAL, INDIRECT, INCIDENTAL, OR CONSEQUENTIAL DAMAGES, WITH RESPECT TO ANY CLAIM 
ARISING OUT OF OR IN CONNECTION WITH THE USE OF THE SOFTWARE, EVEN IF IT HAS BEEN OR IS HEREAFTER ADVISED OF THE POSSIBILITY 
OF SUCH DAMAGES.
*/


#include "PickStackNode.h"

PickStackNode::PickStackNode()
{
    SBJoinDescStackNode::SBJoinDescStackNode();
    initialize();
}

PickStackNode::~PickStackNode()
{
	if (miscInformation) delete [] miscInformation;
}

void PickStackNode::initialize()
{
    SBJoinDescStackNode::initialize();
    numberOfChildrenTotal = 0;
    numberOfChildrenWorthy = 0;
    miscInformation = NULL;
    /*numberOfChildrenOutput = 0;*/
}


int PickStackNode::getNumberOfChildrenTotal()
{
    return this->numberOfChildrenTotal;
}
void PickStackNode::setNumberOfChildrenTotal(int numberOfChildrenTotal)
{
    this->numberOfChildrenTotal = numberOfChildrenTotal;
}
void PickStackNode::incrementNumberOfChildrenTotal(int by)
{
    this->numberOfChildrenTotal += by;
}


int PickStackNode::getNumberOfChildrenWorthy()
{
    return this->numberOfChildrenWorthy;
}
void PickStackNode::setNumberOfChildrenWorthy(int numberOfChildrenWorthy)
{
    this->numberOfChildrenWorthy = numberOfChildrenWorthy;
}
void PickStackNode::incrementNumberOfChildrenWorthy(int by)
{
    this->numberOfChildrenWorthy += by;
}


char * PickStackNode::getMiscInformation()
{
    return this->miscInformation;
}
void PickStackNode::setMiscInformation(char *input, int len)
{
    this->miscInformation = new char[len+1];
    memcpy(this->miscInformation, input, len);
    this->miscInformation[len] = '\0';
}


//int PickStackNode::getNumberOfChildrenOutput()
//{
//    return this->numberOfChildrenOutput;
//}
//
//void PickStackNode::setNumberOfChildrenOutput(int numberOfChildrenOutput)
//{
//    this->numberOfChildrenOutput = numberOfChildrenOutput;
//}
//
//void PickStackNode::incrementNumberOfChildrenOutput(int by)
//{
//    this->numberOfChildrenOutput += by;
//}


void PickStackNode::setTree(WitnessTree *tree)
{
    this->tree.initialize();
    if (tree->isSimple())
        this->tree.appendList((ListNode *)tree->getBuffer(),tree->length());
    else
        this->tree.appendList((ComplexListNode *)tree->getBuffer(),tree->getDataMng(),tree->length());
    this->tree.setScore(tree->getScore());
}
WitnessTree *PickStackNode::getTree()
{
    return &tree;
}

//ListNode *PickStackNode::GetActualAncs()
//{
//    if (this->tree.length() == 0)
//        return NULL;
//    if (tree.isSimple())
//        return (ListNode *)tree.findNode(0);
//    return ((ComplexListNode *)tree.findNode(0))->GetListNode();
//}

void PickStackNode::prepareToCopyDelete()
{
	SBJoinDescStackNode::prepareToCopyDelete();
	this->miscInformation = NULL;
}
