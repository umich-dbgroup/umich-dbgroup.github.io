#include "PickStackNode.h"

extern bool Select(PickStackNode *node, ListNode *standard, char *lastTag = NULL);
extern bool Qualify(WitnessTree *tree, char *tag = NULL);
#include "QueryEvaluationTreePickNode.h"
