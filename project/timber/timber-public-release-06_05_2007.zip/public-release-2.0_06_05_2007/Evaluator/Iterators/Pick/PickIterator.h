/*
COPYRIGHT  � 2000-2004 
THE REGENTS OF THE UNIVERSITY OF MICHIGAN
ALL RIGHTS RESERVED

PERMISSION IS GRANTED TO USE, COPY, CREATE DERIVATIVE WORKS AND REDISTRIBUTE THIS SOFTWARE AND SUCH DERIVATIVE WORKS FOR 
NONCOMMERCIAL EDUCATION AND RESEARCH PURPOSES, SO LONG AS NO FEE IS CHARGED, AND SO LONG AS THE COPYRIGHT NOTICE ABOVE, 
THIS GRANT OF PERMISSION, AND THE DISCLAIMER BELOW APPEAR IN ALL COPIES MADE; AND SO LONG AS THE NAME OF THE UNIVERSITY 
OF MICHIGAN IS NOT USED IN ANY ADVERTISING OR PUBLICITY PERTAINING TO THE USE OR DISTRIBUTION OF THIS SOFTWARE WITHOUT 
SPECIFIC, WRITTEN PRIOR AUTHORIZATION.

THIS SOFTWARE IS PROVIDED AS IS, WITHOUT REPRESENTATION FROM THE UNIVERSITY OF MICHIGAN AS TO ITS FITNESS FOR ANY PURPOSE, 
AND WITHOUT WARRANTY BY THE UNIVERSITY OF MICHIGAN OF ANY KIND, EITHER EXPRESS OR IMPLIED, INCLUDING WITHOUT LIMITATION THE 
IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE. THE REGENTS OF THE UNIVERSITY OF MICHIGAN SHALL 
NOT BE LIABLE FOR ANY DAMAGES, INCLUDING SPECIAL, INDIRECT, INCIDENTAL, OR CONSEQUENTIAL DAMAGES, WITH RESPECT TO ANY CLAIM 
ARISING OUT OF OR IN CONNECTION WITH THE USE OF THE SOFTWARE, EVEN IF IT HAS BEEN OR IS HEREAFTER ADVISED OF THE POSSIBILITY 
OF SUCH DAMAGES.
*/

#ifndef __pickiterator_h
#define __pickiterator_h
#include <timber-compat.h>

#include "../../Common/IteratorClass.h"
#include "../../Common/stack.h"
#include "../Pick/PickStackNode.h"
#include "../../Evaluator/Evaluator_definitions.h"
#include "../../Evaluator/EvaluatorClass.h"

class PickIterator : public IteratorClass
{
public:
    PickIterator(IteratorClass *input, bool (*selectFunction1)(PickStackNode *node, ListNode *standard, char *lastTag), 
                 bool (*qualifyFunction1)(WitnessTree *tree, char *tag), DataMng *dataMng, bool sort = false);
    ~PickIterator();
    void next(WitnessTree *&node);

private:

    // the input stream
    IteratorClass *input; // the input stream
    WitnessTree *inTuple; // the next input tuple
    WitnessTree *resultBuffer; // storage for the input tuple

    int nodeSize; // the node size of the input tuple
    int nodeType; // the node type of the input tuple
    int listLength; // the length of the input witness tree

    // the output facility
    bool stillInput(); // whether the input stream is still open
    void getNext(); // ask input stream for the next tuple
    WitnessTree *currentTree(); // return the current input tuple

    // utility members
    ListNode lastAncestor; /* the information about last discarded ancestor
                            * that started this current output event */
    char lastAnsTag[20];   /* tagname of last discarded ancestor */

    //ListNode ansTop; /* the information about top of the ansStack, 
    //                  * top of mainStack is constantly changing and 
    //                  * is therefore not introduced here */

    // select functions
    bool (*selectFunction1)(PickStackNode *node, ListNode *standard, char *lastTag); /* select function */
    bool (*qualifyFunction1)(WitnessTree *tree, char *tag); /* qualify nodes based on score */

    // data structure
    stack<PickStackNode> *mainStack;
    stack<PickStackNode> *ansStack;
    PickStackNode * popStack(stack<PickStackNode> *inStack);
    void pushIntoStack(stack<PickStackNode> *inStack, WitnessTree *pushed);

    // information about the database
    DataMng *dataMng;
    FileIDType fid;

    //// What are those for?

    //lvid_t volumeID;
    //serial_t startID;
    //serial_t fileID;
    //rc_t rc;

    //void addToBuffer(PickStackNode *addTo, PickStackNode *added);
    //int readFromBuffer(ContainerClass *buf);
    //int readFromList(ShoreList *list);

    //ContainerClass readBuffer;
    //ContainerClass *childBuffer;
    //ShoreList *childList;

    // Misc. Information
    bool sort; /* indicates whether the input should be re-sorted. only sorted
                * are currently supported */
    bool isSimple; /* whether the input stream uses simple list node or complex list node */

};

#endif

