
#include "parse.hpp"

char QueryEvaluationTreeValueJoinNode::getIdentifier(void) { return 'j'; }

char ValueJoinPlanParser::getIteratorIdentifier(void) { return 'j'; }

void 
ValueJoinPlanParser::getQueryEvalNode(EvaluatorClass* evaluator, char* line, void* queryInput, QueryEvaluationTreeNode*& curr)
	    {
		char *token = strtok(line+2,",");  
		if (token == NULL)
		{
		    globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"Evaluator",__FILE__,"Error input from file... expecting root NRE... Value join line...");
		    curr=NULL; return;
		}
		NREType rootNRE = (NREType)atoi(token);
		if (rootNRE < 1)
		{
		    globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"Evaluator",__FILE__,"NRE should be positive.");   
		    curr=NULL; return;
		}
		if (rootNRE > evaluator->maxNRE)
		    evaluator->maxNRE = rootNRE;

		token = strtok(NULL,",");
		if (token == NULL)
		{
		    globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"Evaluator",__FILE__,"Error input from file... expecting left nre... join line...");
		    curr=NULL; return;
		}
		NREType  leftNRE;
		if (atoi(token) < 0)
		    leftNRE = NULL_NRE;
		else
		{
		    leftNRE = (NREType)atoi(token);
		    if (leftNRE > evaluator->maxNRE)
			evaluator->maxNRE = leftNRE;
		}

		token = strtok(NULL,",");
		if (token == NULL)
		{
		    globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"Evaluator",__FILE__,"Error input from file... expecting left tag... join line...");
		    curr=NULL; return;
		}
		int leftTag;
		if (strcmp(token,"NULL") == 0)
		    leftTag = -1;
		else
		    leftTag = evaluator->getDataManager()->getPhysicalDataMng()->getXMLNameTable()->getCodeByName(token);
		token = strtok(NULL,",");
		if (token == NULL)
		{
		    globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"Evaluator",__FILE__,"Error input from file... expecting right nre... join line...");
		    curr=NULL; return;
		}
		NREType  rightNRE;
		if (atoi(token) < 0)
		    rightNRE = NULL_NRE;
		else
		{
		    rightNRE = (NREType)atoi(token);
		    if (rightNRE > evaluator->maxNRE)
			evaluator->maxNRE = rightNRE;
		}

		token = strtok(NULL,",");
		if (token == NULL)
		{
		    globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"Evaluator",__FILE__,"Error input from file... expecting right tag... join line...");
		    curr=NULL; return;
		}
		int rightTag;
		if (strcmp(token,"NULL") == 0)
		    rightTag = -1;
		else
		    rightTag = evaluator->getDataManager()->getPhysicalDataMng()->getXMLNameTable()->getCodeByName(token);


		token = strtok(NULL,",");
		if (token == NULL)
		{
		    globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"Evaluator",__FILE__,"Error input from file... expecting size... join line...");
		    curr=NULL; return;
		}
		int size = atoi(token);
		token = strtok(NULL,",");
		if (token == NULL)
		{
		    globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"Evaluator",__FILE__,"Error input from file... expecting left attribute Name... join line...");
		    curr=NULL; return;
		}
		char *attrNameLeft;

		/*     if (strcmp(token,"NULL") == 0)
		       attrNameLeft = NULL;
		       else
		       {*/
		attrNameLeft = new char[strlen(token)+1];
		strcpy(attrNameLeft,token);
		// }

		token = strtok(NULL,",");
		if (token == NULL)
		{
		    globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"Evaluator",__FILE__,"Error input from file... expecting right attribute Name... join line...");
		    if (attrNameLeft) delete [] attrNameLeft;
		    curr=NULL; return;
		}
		char *attrNameRight;

		/*      if (strcmp(token,"NULL") == 0)
			attrNameRight = NULL;
			else
			{*/
		attrNameRight = new char[strlen(token)+1];
		strcpy(attrNameRight,token);
		//   }


		token = strtok(NULL,",");
		if (token == NULL)
		{
		    globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"Evaluator",__FILE__,"Error input from file... expecting operation... value join line...");

		    if (attrNameLeft) delete [] attrNameLeft;
		    if (attrNameRight) delete [] attrNameRight;
		    curr=NULL; return;
		}

		int opr;

		if (strcmp(token,"EQN") == 0)
		    opr = JOINOP_EQ_NUM;
		else if (strcmp(token,"NEN") == 0)
		    opr = JOINOP_NE_NUM;
		else if (strcmp(token,"LEN") == 0)
		    opr = JOINOP_LE_NUM;
		else if (strcmp(token,"LTN") == 0)
		    opr = JOINOP_LT_NUM;
		else if (strcmp(token,"GEN") == 0)
		    opr = JOINOP_GE_NUM;
		else if (strcmp(token,"GTN") == 0)
		    opr = JOINOP_GT_NUM;
		else if (strcmp(token,"EQS") == 0)
		    opr = JOINOP_EQ_STR;
		else if (strcmp(token,"NES") == 0)
		    opr = JOINOP_NE_STR;
		else if (strcmp(token,"LES") == 0)
		    opr = JOINOP_LE_STR;
		else if (strcmp(token,"LTS") == 0)
		    opr = JOINOP_LT_STR;
		else if (strcmp(token,"GES") == 0)
		    opr = JOINOP_GE_STR;
		else if (strcmp(token,"GTS") == 0)
		    opr = JOINOP_GT_STR;
		else if (strcmp(token,"C") == 0)
		    opr = JOINOP_CONTAINS;
		else if (strcmp(token,"CB") == 0)
		    opr = JOINOP_CONTAINED_BY;
		else
		{
		    globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"Evaluator",__FILE__,"Error input from file... unrecognized operation... value join line...");

		    if (attrNameLeft) delete [] attrNameLeft;
		    if (attrNameRight) delete [] attrNameRight;
		    curr=NULL; return;
		}

		token = strtok(NULL,",");
		if (token == NULL)
		{
		    globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"Evaluator",__FILE__,"Error input from file... expecting joinByWhat left... value join line...");

		    if (attrNameLeft) delete [] attrNameLeft;
		    if (attrNameRight) delete [] attrNameRight;            
		    curr=NULL; return;
		}

		int joinByWhatLeft;
		if (strcmp(token,"A") == 0)
		    joinByWhatLeft = JOINBY_ATTRIBUTE;
		else if (strcmp(token,"T") == 0)
		    joinByWhatLeft = JOINBY_TEXT;
		else if (strcmp(token,"DT") == 0)
		    joinByWhatLeft = JOINBY_DESC_TEXT;
		else if (strcmp(token,"S") == 0)
		    joinByWhatLeft = JOINBY_STARTKEY;
		else if (strcmp(token,"E") == 0)
		    joinByWhatLeft = JOINBY_ENDKEY;
		else if (strcmp(token,"L") == 0)
		    joinByWhatLeft = JOINBY_LEVEL;
		else if (strcmp(token,"N") == 0)
		    joinByWhatLeft = JOINBY_NOTHING;
		else if (strcmp(token,"TR") == 0)
		    joinByWhatLeft = JOINBY_TREE;
		else if (strcmp(token,"TNR") == 0)
		    joinByWhatLeft = JOINBY_TREE_WITHOUT_ROOT;
		else if (strcmp(token,"V") == 0)
		    joinByWhatLeft = JOINBY_VALUE;
		else if (strcmp(token,"AS") == 0)
		    joinByWhatLeft = JOINBY_ATTR_SK;
		else
		{
		    globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"Evaluator",__FILE__,"Error input from file... unrecognized left join by what... value join line...");

		    if (attrNameLeft) delete [] attrNameLeft;
		    if (attrNameRight) delete [] attrNameRight;
		    curr=NULL; return;
		}


		token = strtok(NULL,",");
		if (token == NULL)
		{
		    globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"Evaluator",__FILE__,"Error input from file... expecting joinByWhatRight... value join line...");

		    if (attrNameLeft) delete [] attrNameLeft;
		    if (attrNameRight) delete [] attrNameRight;        
		    curr=NULL; return;
		}

		int joinByWhatRight;
		if (strcmp(token,"A") == 0)
		    joinByWhatRight = JOINBY_ATTRIBUTE;
		else if (strcmp(token,"T") == 0)
		    joinByWhatRight = JOINBY_TEXT;
		else if (strcmp(token,"DT") == 0)
		    joinByWhatRight = JOINBY_DESC_TEXT;
		else if (strcmp(token,"S") == 0)
		    joinByWhatRight = JOINBY_STARTKEY;
		else if (strcmp(token,"L") == 0)
		    joinByWhatRight = JOINBY_LEVEL;
		else if (strcmp(token,"N") == 0)
		    joinByWhatRight = JOINBY_NOTHING;
		else if (strcmp(token,"TR") == 0)
		    joinByWhatRight = JOINBY_TREE;
		else if (strcmp(token,"TNR") == 0)
		    joinByWhatRight = JOINBY_TREE_WITHOUT_ROOT;
		else if (strcmp(token,"V") == 0)
		    joinByWhatRight = JOINBY_VALUE;
		else if (strcmp(token,"AS") == 0)
		    joinByWhatRight = JOINBY_ATTR_SK;
		else
		{
		    globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"Evaluator",__FILE__,"Error input from file... unrecognized right join by what... value join line...");

		    if (attrNameLeft) delete [] attrNameLeft;
		    if (attrNameRight) delete [] attrNameRight;
		    curr=NULL; return;
		}
		token = strtok(NULL,",");
		if (token == NULL)
		{
		    globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"Evaluator",__FILE__,"Error input from file... expecting sorted input... value join line...");

		    if (attrNameLeft) delete [] attrNameLeft;
		    if (attrNameRight) delete [] attrNameRight;      
		    curr=NULL; return;
		}

		if (atoi(token) != 0 && atoi(token) != 1)
		{
		    globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"Evaluator",__FILE__,"Error input from file... sorted input should be 0 or 1... value join line...");

		    if (attrNameLeft) delete [] attrNameLeft;
		    if (attrNameRight) delete [] attrNameRight;      
		    curr=NULL; return;
		}
		bool sortedInput = (bool)atoi(token);

		char *indexName = NULL;
		char *fileName = NULL;
		token = strtok(NULL,",");
		if (token == NULL)
		{
		    globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"Evaluator",__FILE__,"Error input from file... expecting index name... value join line...");

		    if (attrNameLeft) delete [] attrNameLeft;
		    if (attrNameRight) delete [] attrNameRight;      
		    curr=NULL; return;
		}

		if (strcmp(token,"NULL") != 0)
		{
		    if (sortedInput)
		    {
			//	globalErrorInfo.insertProblem(ERR_TYPE_WARNING,__LINE__,"Evaluator",__FILE__,"Cannot use value join index with sort-merge join. switching to nested-loops join... value join line...");
			sortedInput = false;
		    }
		    indexName = new char[strlen(token)+1];
		    strcpy(indexName,token);	
		}

		token = strtok(NULL,",");
		if (token == NULL)
		{
		    globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"Evaluator",__FILE__,"Error input from file... expecting xml file name... value join line...");

		    if (attrNameLeft) delete [] attrNameLeft;
		    if (attrNameRight) delete [] attrNameRight;      
		    if (indexName) delete [] indexName;
		    curr=NULL; return;
		}

		if (strcmp(token,"NULL") != 0)
		{
		    fileName = new char[strlen(token)+1];
		    strcpy(fileName,token);
		}
		else if (indexName != NULL)
		{
		    globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"Evaluator",__FILE__,"Error input from file... you either pass values for both indexName and fileName or you pass NULL for both... value join line...");

		    if (attrNameLeft) delete [] attrNameLeft;
		    if (attrNameRight) delete [] attrNameRight;      
		    if (indexName) delete [] indexName;
		    curr=NULL; return;
		}

		bool nest = false;
		bool outer = false;
		bool atLeastOne = false;
		token = strtok(NULL,",");
		if (token != NULL)
		{
		    if (strcmp(token,"N") == 0)
		    {
			nest = true;
			token = strtok(NULL,",");
			if (token != NULL)
			{
			    if (strcmp(token,"O") == 0)
			    {
				outer = true;
				token = strtok(NULL,",");
				if (token != NULL)
				{
				    if (strcmp(token,"A") == 0)
				    {
					atLeastOne = true;
					if (sortedInput)
					{
					    globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"Evaluator",__FILE__,"Error input from file... sorted input is not supported with at least one... value join line...");

					    if (attrNameLeft) delete [] attrNameLeft;
					    if (attrNameRight) delete [] attrNameRight;   
					    if (indexName) delete [] indexName;
					    if (fileName) delete [] fileName;
					    curr=NULL; return;
					}
				    }
				    else
				    {
					globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"Evaluator",__FILE__,"Error input from file... unrecognized optional parameter... value join line...");

					if (attrNameLeft) delete [] attrNameLeft;
					if (attrNameRight) delete [] attrNameRight;    
					if (indexName) delete [] indexName;
					if (fileName) delete [] fileName;
					curr=NULL; return;
				    }
				}
			    }
			    else if (strcmp(token,"A") == 0)
			    {
				atLeastOne = true;
				if (sortedInput)
				{
				    globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"Evaluator",__FILE__,"Error input from file... sorted input is not supported with at least one... value join line...");

				    if (attrNameLeft) delete [] attrNameLeft;
				    if (attrNameRight) delete [] attrNameRight;  
				    if (indexName) delete [] indexName;
				    if (fileName) delete [] fileName;
				    curr=NULL; return;
				}
			    }
			    else
			    {
				globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"Evaluator",__FILE__,"Error input from file... unrecognized optional parameter... value join line...");

				if (attrNameLeft) delete [] attrNameLeft;
				if (attrNameRight) delete [] attrNameRight;  
				if (indexName) delete [] indexName;
				if (fileName) delete [] fileName;
				curr=NULL; return;
			    }
			}
		    }
		    else if (strcmp(token,"O") == 0)
		    {
			outer = true;
			token = strtok(NULL,",");
			if (token != NULL)
			{
			    if (strcmp(token,"A") == 0)
			    {
				atLeastOne = true;
				if (sortedInput)
				{
				    globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"Evaluator",__FILE__,"Error input from file... sorted input is not supported with at least one... value join line...");

				    if (attrNameLeft) delete [] attrNameLeft;
				    if (attrNameRight) delete [] attrNameRight;  
				    if (indexName) delete [] indexName;
				    if (fileName) delete [] fileName;
				    curr=NULL; return;
				}
			    }
			    else
			    {
				globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"Evaluator",__FILE__,"Error input from file... unrecognized optional parameter... value join line...");

				if (attrNameLeft) delete [] attrNameLeft;
				if (attrNameRight) delete [] attrNameRight;  
				if (indexName) delete [] indexName;
				if (fileName) delete [] fileName;
				curr=NULL; return;
			    }
			}
		    }
		    else if (strcmp(token,"A") == 0)
		    {
			atLeastOne = true;
			if (sortedInput)
			{
			    globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"Evaluator",__FILE__,"Error input from file... sorted input is not supported with at least one... value join line...");

			    if (attrNameLeft) delete [] attrNameLeft;
			    if (attrNameRight) delete [] attrNameRight;   
			    if (indexName) delete [] indexName;
			    if (fileName) delete [] fileName;
			    curr=NULL; return;
			}
		    }
		    else
		    {
			globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"Evaluator",__FILE__,"Error input from file... unrecognized optional parameter... value join line...");

			if (attrNameLeft) delete [] attrNameLeft;
			if (attrNameRight) delete [] attrNameRight;  
			if (indexName) delete [] indexName;
			if (fileName) delete [] fileName;
			curr=NULL; return;
		    }
		}

		char newLine[MAX_FILE_INTERFACE_LINE_SIZE];
		if (((std::iostream *)queryInput)->eof() == 0)
		    ((std::iostream *)queryInput)->getline(newLine,MAX_FILE_INTERFACE_LINE_SIZE);
		else
		{
		    globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"Evaluator",__FILE__,"Unexpected end of file... val join line...");

		    if (attrNameLeft) delete [] attrNameLeft;
		    if (attrNameRight) delete [] attrNameRight;
		    if (indexName) delete [] indexName;
		    if (fileName) delete [] fileName;
		    curr=NULL; return;
		}
		QueryEvaluationTreeNode *oper1 = evaluator->getQueryEvalNode(newLine,queryInput);
		if (oper1 == NULL)
		{
		    globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"Evaluator",__FILE__,"Unexpected operand1 returned... val join line...");

		    if (attrNameLeft) delete [] attrNameLeft;
		    if (attrNameRight) delete [] attrNameRight;
		    if (indexName) delete [] indexName;
		    if (fileName) delete [] fileName;
		    curr=NULL; return;
		}
		if (((std::iostream *)queryInput)->eof() == 0)
		    ((std::iostream *)queryInput)->getline(newLine,MAX_FILE_INTERFACE_LINE_SIZE);
		else
		{
		    globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"Evaluator",__FILE__,"Unexpected end of file... val join line...");

		    if (attrNameLeft) delete [] attrNameLeft;
		    if (attrNameRight) delete [] attrNameRight;
		    if (indexName) delete [] indexName;
		    if (fileName) delete [] fileName;
		    delete oper1;
		    curr=NULL; return;
		}
		QueryEvaluationTreeNode *oper2 = evaluator->getQueryEvalNode(newLine,queryInput);
		if (oper2 == NULL)
		{
		    globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"Evaluator",__FILE__,"Unexpected operand2 returned... val join line...");

		    if (attrNameLeft) delete [] attrNameLeft;
		    if (attrNameRight) delete [] attrNameRight; 
		    if (indexName) delete [] indexName;
		    if (fileName) delete [] fileName;
		    delete oper1;
		    curr=NULL; return;
		}
		curr = new QueryEvaluationTreeValueJoinNode(oper1,oper2,rootNRE,leftNRE,rightNRE,leftTag,rightTag,size,attrNameLeft,
			attrNameRight,opr,joinByWhatLeft,joinByWhatRight,sortedInput,nest,outer,indexName,fileName
			,atLeastOne);
	    }

