#include "../../Evaluator/EvaluatorClass.h"

#include "QueryEvaluationTreeDuplicateEliminatorNode.h"

#include "DuplicateEliminatorIterator.h"
#include "extra.h"

void QueryEvaluationTreeDuplicateEliminatorNode::processQueryEvalNode(EvaluatorClass* evaluator, IteratorClass*& curr)
	    {
		serial_t fileID = 0;
		serial_t recID = 0;
		int numWrites = 0;
		if (getSort() && getExternalSort())
		{
		    fileID = evaluator->fileIDsArray[evaluator->fileIDsArrayPtr];
		    evaluator->fileIDsArrayPtr++;
		    numWrites = evaluator->createRecID(recID);
		    if (numWrites == FAILURE)
		    {
			globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"Evaluator",__FILE__, "operand returned is NULL. duplicate elminator process eval node..." );
			curr=NULL; return;
		    }
		}
		IteratorClass *opr = evaluator->processQueryEvalNode(getOperand());
		if (opr == NULL)
		{
		    globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"Evaluator",__FILE__, "operand returned is NULL. duplicate elimination process eval node..." );
		    curr=NULL; return;
		}
		curr = new DuplicateEliminatorIterator(opr,getElimByWhat(), getNRE(), getAttrName()
			,evaluator->getDataManager(),getSort(),getExpectedSize(),fileID,recID,numWrites,getExternalSort());
		setAttrName(NULL);
	    }

