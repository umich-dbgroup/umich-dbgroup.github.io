/*
COPYRIGHT  � 2000-2004 
THE REGENTS OF THE UNIVERSITY OF MICHIGAN
ALL RIGHTS RESERVED

PERMISSION IS GRANTED TO USE, COPY, CREATE DERIVATIVE WORKS AND REDISTRIBUTE THIS SOFTWARE AND SUCH DERIVATIVE WORKS FOR 
NONCOMMERCIAL EDUCATION AND RESEARCH PURPOSES, SO LONG AS NO FEE IS CHARGED, AND SO LONG AS THE COPYRIGHT NOTICE ABOVE, 
THIS GRANT OF PERMISSION, AND THE DISCLAIMER BELOW APPEAR IN ALL COPIES MADE; AND SO LONG AS THE NAME OF THE UNIVERSITY 
OF MICHIGAN IS NOT USED IN ANY ADVERTISING OR PUBLICITY PERTAINING TO THE USE OR DISTRIBUTION OF THIS SOFTWARE WITHOUT 
SPECIFIC, WRITTEN PRIOR AUTHORIZATION.

THIS SOFTWARE IS PROVIDED AS IS, WITHOUT REPRESENTATION FROM THE UNIVERSITY OF MICHIGAN AS TO ITS FITNESS FOR ANY PURPOSE, 
AND WITHOUT WARRANTY BY THE UNIVERSITY OF MICHIGAN OF ANY KIND, EITHER EXPRESS OR IMPLIED, INCLUDING WITHOUT LIMITATION THE 
IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE. THE REGENTS OF THE UNIVERSITY OF MICHIGAN SHALL 
NOT BE LIABLE FOR ANY DAMAGES, INCLUDING SPECIAL, INDIRECT, INCIDENTAL, OR CONSEQUENTIAL DAMAGES, WITH RESPECT TO ANY CLAIM 
ARISING OUT OF OR IN CONNECTION WITH THE USE OF THE SOFTWARE, EVEN IF IT HAS BEEN OR IS HEREAFTER ADVISED OF THE POSSIBILITY 
OF SUCH DAMAGES.
*/

#include "DuplicateEliminatorIterator.h"

DuplicateEliminatorIterator::DuplicateEliminatorIterator(IteratorClass *input, int eliminateByWhat, NREType nre, 
		char *attrName,
		DataMng *dataMng, bool sort,int numExpected, serial_t fileID, serial_t startID, int numWrites, bool externalSort)
{
	this->dataMng = dataMng;
	
	
	this->eliminateByWhat = eliminateByWhat;
	this->nre = nre;
	this->attrName = attrName;
	prevTag = -1;
	prevValue = NULL;
	prevValSize = 0;
	resultBuffer = NULL;
	prevTuple = NULL;
	this->sort = sort;
	if (sort)
	{
		if (externalSort)
		{
			int *sortOrder = new int[1];
			sortOrder[0] = ASCENDING;
			if (eliminateByWhat == ELIMINATE_DUPLICATES_TREE)
				this->input  = new ExternalSortIterator(input,0,NULL,sortOrder,dataMng,NULL,fileID,startID,numWrites);
			else
			{
				NREType *sortNRE = new NREType[1];
				int *whereEmptyGoes = new int[1];
				sortNRE[0] = nre;
				whereEmptyGoes[0]  = EMPTY_AT_BEGINNING;

				if (eliminateByWhat == ELIMINATE_DUPLICATES_STARTKEY)	
					this->input  = new ExternalSortIterator(input,1, sortNRE, sortOrder,dataMng,whereEmptyGoes,fileID,startID,numWrites);
				else 
				{
					int *sortBy = new int[1];
					if (eliminateByWhat == ELIMINATE_DUPLICATES_TEXT_NUM || eliminateByWhat == ELIMINATE_DUPLICATES_TEXT_STR)
					{
						sortBy[0] = (eliminateByWhat == ELIMINATE_DUPLICATES_TEXT_NUM? SORTBY_TEXT_NUM:SORTBY_TEXT_STR);
						this->input = new ExternalValueSortIterator(input,1,sortBy,sortNRE,NULL,sortOrder,dataMng,whereEmptyGoes,fileID,startID,numWrites);
					}
					else if (eliminateByWhat == ELIMINATE_DUPLICATES_ATTR_NUM || eliminateByWhat == ELIMINATE_DUPLICATES_ATTR_STR)
					{
						char **sortAttrName = NULL;
						if (attrName)
						{
							sortAttrName = new char *[1];
							sortAttrName[0] = new char[strlen(attrName)+1];
							strcpy(sortAttrName[0],attrName);
						}
						sortBy[0] = (eliminateByWhat == ELIMINATE_DUPLICATES_ATTR_NUM? SORTBY_ATTRIBUTE_NUM:SORTBY_ATTRIBUTE_STR);
						this->input = new ExternalValueSortIterator(input,1,sortBy,sortNRE,sortAttrName,sortOrder,dataMng,whereEmptyGoes,fileID,startID,numWrites);
					}
					else
					{
						char **sortAttrName = NULL;
						if (attrName)
						{
							sortAttrName = new char *[1];
							sortAttrName[0] = new char[strlen(attrName)+1];
							strcpy(sortAttrName[0],attrName);
						}
						sortBy[0] = (eliminateByWhat == ELIMINATE_DUPLICATES_VAL_NUM? SORTBY_VALUE_NUM:SORTBY_VALUE_STR);
						this->input = new ExternalValueSortIterator(input,1,sortBy,sortNRE,sortAttrName,sortOrder,dataMng,whereEmptyGoes,fileID,startID,numWrites);
					}
				}
			}
		}
		else
		{
			int *sortOrder = new int[1];
			sortOrder[0] = ASCENDING;
			if (eliminateByWhat == ELIMINATE_DUPLICATES_TREE)
				this->input  = new SortIterator(input,numExpected,0,NULL,sortOrder,dataMng,NULL);
			else
			{
				NREType *sortNRE = new NREType[1];
				int *whereEmptyGoes = new int[1];
				sortNRE[0] = nre;
				whereEmptyGoes[0]  = EMPTY_AT_BEGINNING;

				if (eliminateByWhat == ELIMINATE_DUPLICATES_STARTKEY)	
					this->input  = new SortIterator(input,numExpected,1, sortNRE, sortOrder,dataMng,whereEmptyGoes);
				else 
				{
					int *sortBy = new int[1];
					if (eliminateByWhat == ELIMINATE_DUPLICATES_TEXT_NUM || eliminateByWhat == ELIMINATE_DUPLICATES_TEXT_STR)
					{
						sortBy[0] = (eliminateByWhat == ELIMINATE_DUPLICATES_TEXT_NUM? SORTBY_TEXT_NUM:SORTBY_TEXT_STR);
						this->input = new ValueSortIterator(input,numExpected,1,sortBy,sortNRE,NULL,sortOrder,dataMng,whereEmptyGoes);
					}
					else if (eliminateByWhat == ELIMINATE_DUPLICATES_ATTR_NUM || eliminateByWhat == ELIMINATE_DUPLICATES_ATTR_STR)
					{
						char **sortAttrName = NULL;
						if (attrName)
						{
							sortAttrName = new char *[1];
							sortAttrName[0] = new char[strlen(attrName)+1];
							strcpy(sortAttrName[0],attrName);
						}
						sortBy[0] = (eliminateByWhat == ELIMINATE_DUPLICATES_ATTR_NUM? SORTBY_ATTRIBUTE_NUM:SORTBY_ATTRIBUTE_STR);
						this->input = new ValueSortIterator(input,numExpected,1,sortBy,sortNRE,sortAttrName,sortOrder,dataMng,whereEmptyGoes);
					}
					else
					{
						char **sortAttrName = NULL;
						if (attrName)
						{
							sortAttrName = new char *[1];
							sortAttrName[0] = new char[strlen(attrName)+1];
							strcpy(sortAttrName[0],attrName);
						}
						sortBy[0] = (eliminateByWhat == ELIMINATE_DUPLICATES_VAL_NUM? SORTBY_VALUE_NUM:SORTBY_VALUE_STR);
						this->input = new ValueSortIterator(input,numExpected,1,sortBy,sortNRE,sortAttrName,sortOrder,dataMng,whereEmptyGoes);
					}
				}
			}
		}
	}
	else
	{
		this->input = input;
	}


	if (globalErrorInfo.doWeHaveAProblem() == true)
	{
		inTuple = NULL;
		return;
	}
	this->input->next(inTuple);
	if (inTuple && !(inTuple->isSimple()))
	{
		resultBuffer = new WitnessTree(LIST_NODE_WITH_DATA,dataMng);
		prevTuple = new WitnessTree(LIST_NODE_WITH_DATA,dataMng);
	}
	else
	{
		resultBuffer = new WitnessTree;
		prevTuple = new WitnessTree;
	}
}


DuplicateEliminatorIterator::~DuplicateEliminatorIterator()
{
	if (resultBuffer) delete resultBuffer;
	if (prevTuple) delete prevTuple;
	if (attrName) delete [] attrName;
	delete input;
	if (prevValue) delete [] prevValue;
}


void DuplicateEliminatorIterator::next(WitnessTree *&node)
{
	//if no more input --> done
	if (!inTuple)
	{
		node = NULL;
		return;
	}

#ifdef EVAL_TIME_OUT
	clock_t currTime = clock();
	double queryDuration = (double)(currTime - gQueryStartTime) / CLOCKS_PER_SEC;
	if (queryDuration >= gTimeOutAfter)
	{
		globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"Evaluator",__FILE__,"Query Timed Out.");
		node = NULL;
		return;
	}
#endif
	bool errorFound;
	while (sameAsPrev(prevTuple,inTuple,&prevValue,errorFound))
	{
		if (errorFound)
		{
			node = NULL;
			return;
		}
		input->next(inTuple);
		if (!inTuple)
		{
			node = NULL;
			return;
		}
#ifdef EVAL_TIME_OUT
		clock_t currTime = clock();
		double queryDuration = (double)(currTime - gQueryStartTime) / CLOCKS_PER_SEC;
		if (queryDuration >= gTimeOutAfter)
		{
			globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"Evaluator",__FILE__,"Query Timed Out.");
			node = NULL;
			return;
		}
#endif
	}
	resultBuffer->copyTree(inTuple);
	input->next(inTuple);
	node = resultBuffer;
}

bool DuplicateEliminatorIterator::sameAsPrev(WitnessTree *prevTuple, WitnessTree *currTuple, char **prevValue, bool &errorFound)
{
	errorFound = false;
	if (eliminateByWhat == ELIMINATE_DUPLICATES_TREE)
	{
		if (prevTuple->length() == 0)
		{
			prevTuple->copyTree(inTuple);
			return false;
		}
		bool res = currTuple->equalTree(prevTuple);
		if (res == false)
			prevTuple->copyTree(inTuple);
		return res;
	}

	if (eliminateByWhat == ELIMINATE_DUPLICATES_STARTKEY)
	{
		if (prevTuple->length() == 0)
		{
			prevTuple->copyTree(inTuple);
			return false;
		}
		KeyType sk1,sk2;
		if (prevTuple->isSimple())
		{
			ListNode *n = (ListNode *)prevTuple->findNodeNRE(nre);
			if (n == NULL)
			{
				globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"Evaluator",__FILE__,"Could not find node to match NRE.");
				errorFound  = true;
				return false;
			}
			sk1 = n->GetStartPos();
		}
		else
		{
			ComplexListNode *n = (ComplexListNode *)prevTuple->findNodeNRE(nre);
			if (n == NULL)
			{
				globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"Evaluator",__FILE__,"Could not find node to match NRE.");
				errorFound  = true;
				return false;
			}
			sk1 = n->GetStartPos();
		}
		if (currTuple->isSimple())
		{
			ListNode *n = (ListNode *)currTuple->findNodeNRE(nre);
			if (n == NULL)
			{
				globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"Evaluator",__FILE__,"Could not find node to match NRE.");
				errorFound  = true;
				return false;
			}
			sk2 = n->GetStartPos();
		}
		else
		{
			ComplexListNode *n = (ComplexListNode *)currTuple->findNodeNRE(nre);
			if (n == NULL)
			{
				globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"Evaluator",__FILE__,"Could not find node to match NRE.");
				errorFound  = true;
				return false;
			}
			sk2 = n->GetStartPos();
		}
		bool res = (sk1 == sk2);
		if (res == false)
			prevTuple->copyTree(inTuple);
		return res;
	}
	
	int index = currTuple->getIndexOfNRE(nre);
	if (index == FAILURE)
	{
		globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"Evaluator",__FILE__,"Could not find node to match NRE.");
		errorFound  = true;
		return false;
	}
	FileIDType fileid;
	if (currTuple->isSimple())
		fileid = EvaluatorClass::getFileID(((ListNode *)currTuple->getNodeByIndex(index))->getFileIndex());
	else
		fileid = EvaluatorClass::getFileID(((ComplexListNode *)currTuple->getNodeByIndex(index))->getFileIndex());
	if (fileid == -1)
	{
		globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"Evaluator",__FILE__,"Trying to access nodes from an unloaded file.");
		errorFound  = true;
		return false;
	}

	if (eliminateByWhat == ELIMINATE_DUPLICATES_TEXT_NUM
		|| eliminateByWhat == ELIMINATE_DUPLICATES_TEXT_STR)
	{
		//getting the text node itself
		int res = EvaluatorClass::GetText(currTuple,index,dataMng,fileid);
		if (res == FAILURE || res == 0)
		{
			return false;
		}
		ComplexListNode *n = ((ComplexListNode *)currTuple->getNodeByIndex(res));
		DM_CharNode *dn = (DM_CharNode *)n->GetData();

		if (!dn)
		{
			globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"Evaluator",__FILE__,"Could not get data from DB.");
			errorFound  = true;
			return false;
		}

		if (!*prevValue)
		{
			prevValSize = strlen(dn->getCharValue());
			*prevValue = new char[prevValSize+1];
			strcpy(*prevValue,dn->getCharValue());
			return false;
		}
		else
		{
			bool eq = (eliminateByWhat == ELIMINATE_DUPLICATES_TEXT_NUM? atof(*prevValue) == atof(dn->getCharValue()) : strcmp(*prevValue,dn->getCharValue())==0);

			if (eq)
				return true;

			if (prevValSize < (int)strlen(dn->getCharValue()))
			{
				prevValSize = strlen(dn->getCharValue());
				delete [] *prevValue;
				*prevValue = new char[prevValSize+1];
			}
			strcpy(*prevValue,dn->getCharValue());
			return false;
		}
	}
	else if (eliminateByWhat == ELIMINATE_DUPLICATES_ATTR_NUM
		|| eliminateByWhat == ELIMINATE_DUPLICATES_ATTR_STR)
	{
		//if we are eliminating duplicates in attr value
		int res = EvaluatorClass::GetAttributes(currTuple,index,dataMng,fileid);
		if (res == FAILURE)
			return false;
		ComplexListNode *n = ((ComplexListNode *)currTuple->getNodeByIndex(res+1));
		DM_AttributeNode *dn = (DM_AttributeNode *)n->GetData();
		if (!dn)
		{
			globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"Evaluator",__FILE__,"Could not get data from DB.");
			errorFound  = true;
			return false;
		}
		Value *val = dn->getAttr(attrName);
		if (!val)
			return false;
		if (!*prevValue)
		{
			prevValSize = strlen(val->getStrValue());
			*prevValue = new char[prevValSize+1];
			strcpy(*prevValue,val->getStrValue());
			return false;
		}
		else
		{
			bool eq = (eliminateByWhat == ELIMINATE_DUPLICATES_ATTR_NUM? atof(*prevValue) == atof(val->getStrValue()) : strcmp(*prevValue,val->getStrValue())==0);
			if (eq)
				return true;

			if (prevValSize < (int)strlen(val->getStrValue()))
			{
				prevValSize = strlen(val->getStrValue());
				delete [] *prevValue;
				*prevValue = new char[prevValSize+1];
			}
			strcpy(*prevValue,val->getStrValue());
			return false;
		}
	}
	else if (eliminateByWhat == ELIMINATE_DUPLICATES_VAL_NUM
		|| eliminateByWhat == ELIMINATE_DUPLICATES_VAL_STR)
	{
		int tagCode = -1;
		char *txt = this->getValue(currTuple,index,attrName, tagCode);
		if (!txt && tagCode == -1)
			return false;

		if (tagCode != -1)
		{
			if (prevTag == -1)
			{
				prevTag = tagCode;
				return false;
			}
			else
			{
				if (prevTag == tagCode)
					return true;

				prevTag = tagCode;
					
				return false;
			}
		}
		else
		{
			if (!*prevValue)
			{
				*prevValue = txt;
				return false;
			}
			else
			{
				bool eq = (eliminateByWhat == ELIMINATE_DUPLICATES_VAL_NUM? atof(*prevValue) == atof(txt) : strcmp(*prevValue,txt)==0);
				if (eq)
				{
					delete [] txt;
					return true;
				}

				prevValSize = strlen(txt);
				delete [] *prevValue;
				*prevValue = txt;
					
				return false;
			}
		}
	}
	else
	{
		globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"Evaluator",__FILE__,"Unrecognized eliminate duplicates by what.");
		errorFound  = true;
		return false;
	}
}

char *DuplicateEliminatorIterator::getValue(WitnessTree *in, int index, char *attrName, int &tag)
{
	Value *val;
	char *txt = NULL;
	tag  = -1;
	DM_DataNode *n = ((ComplexListNode *)in->getNodeByIndex(index))->GetData();
	switch (n->getFlag())
	{
	case ELEMENT_NODE:
		//if it is an element node, return its tag
		tag = n->getTag();
		break;
	case DOCUMENT_NODE:
		//if document node, return the xml file name
		if (((DM_DocumentNode *)n)->getXMLFileName())
		{
			txt = new char[strlen(((DM_DocumentNode *)n)->getXMLFileName())+1];
			strcpy(txt,((DM_DocumentNode *)n)->getXMLFileName());
		}
		break;
	case ATTRIBUTE_NODE:
		//if attribute node, return the value of attribute "attrName"
		val = ((DM_AttributeNode *)n)->getAttr(attrName);
		if (val != NULL)
		{
			if (val->getStrValue() != NULL && strlen(val->getStrValue()) != 0)
			{
				txt = new char[strlen(val->getStrValue())+1];
				strcpy(txt,val->getStrValue());
			}
		}
		break;
	case TEXT_NODE:
		//if text node, return the text value
		if (((DM_CharNode *)n)->getCharValue())
		{
			txt = new char[strlen(((DM_CharNode *)n)->getCharValue())+1];
			strcpy(txt,((DM_CharNode *)n)->getCharValue());
		}
		break;
	}
	return txt;
}

