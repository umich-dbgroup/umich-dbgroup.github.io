/*
COPYRIGHT  � 2000-2004 
THE REGENTS OF THE UNIVERSITY OF MICHIGAN
ALL RIGHTS RESERVED

PERMISSION IS GRANTED TO USE, COPY, CREATE DERIVATIVE WORKS AND REDISTRIBUTE THIS SOFTWARE AND SUCH DERIVATIVE WORKS FOR 
NONCOMMERCIAL EDUCATION AND RESEARCH PURPOSES, SO LONG AS NO FEE IS CHARGED, AND SO LONG AS THE COPYRIGHT NOTICE ABOVE, 
THIS GRANT OF PERMISSION, AND THE DISCLAIMER BELOW APPEAR IN ALL COPIES MADE; AND SO LONG AS THE NAME OF THE UNIVERSITY 
OF MICHIGAN IS NOT USED IN ANY ADVERTISING OR PUBLICITY PERTAINING TO THE USE OR DISTRIBUTION OF THIS SOFTWARE WITHOUT 
SPECIFIC, WRITTEN PRIOR AUTHORIZATION.

THIS SOFTWARE IS PROVIDED AS IS, WITHOUT REPRESENTATION FROM THE UNIVERSITY OF MICHIGAN AS TO ITS FITNESS FOR ANY PURPOSE, 
AND WITHOUT WARRANTY BY THE UNIVERSITY OF MICHIGAN OF ANY KIND, EITHER EXPRESS OR IMPLIED, INCLUDING WITHOUT LIMITATION THE 
IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE. THE REGENTS OF THE UNIVERSITY OF MICHIGAN SHALL 
NOT BE LIABLE FOR ANY DAMAGES, INCLUDING SPECIAL, INDIRECT, INCIDENTAL, OR CONSEQUENTIAL DAMAGES, WITH RESPECT TO ANY CLAIM 
ARISING OUT OF OR IN CONNECTION WITH THE USE OF THE SOFTWARE, EVEN IF IT HAS BEEN OR IS HEREAFTER ADVISED OF THE POSSIBILITY 
OF SUCH DAMAGES.
*/

#ifndef __duplicateeliminatoriterator_h
#define __duplicateeliminatoriterator_h
#include <timber-compat.h>

//#include <sstream>
//using namespace std;
#include "../ValueSort/ExternalValueSortIterator.h"
#include "QueryEvaluationTreeDuplicateEliminatorNode.h"

/**
* An iterator that eliminates duplicates from an input. It performs equality on startKey or
* tag names.
* @see IteratorClass
* @see WitnessTree 
* @see EvaluatorClass
* @see SortIterator
* @see ValueSortIterator
* @author Shurug Al-Khalifa 
* @version 1.0
*/
class DuplicateEliminatorIterator : public IteratorClass
{
public:
	/**
	Constructor
	@param input is where the inputs trees are read.
	@param eliminateByWhat is one of 5 values ELIMINATE_DUPLICATES_STARTKEY,
	ELIMINATE_DUPLICATES_TEXT_STR, ELIMINATE_DUPLICATES_TEXT_NUM, ELIMINATE_DUPLICATES_ATTRIBUTE_STR,
	or ELIMINATE_DUPLICATES_ATTRIBUTE_NUM. The first value eliminates trees that have the
	same start key. The second and third elimiante trees with the same text. The 4th and 5th eliminate trees with the same 
	attribute value. NUM or STR indicate whether number comparison should be used. Else, str comparison is used. 
	@param intVal is an integer value used in the following manner
			if ELIMINATE_DUPLICATES_STARTKEY is chosen, intVal will carry the length of the tree to be compared.
				if it is -1 then deep equality is used.
			if ELIMINATE_DUPLICATES_TEXT_* is chosen, intVal is ignored.
			if ELIMINATE_DUPLICATES_ATTRIBUTE_* is chosen, then there are two options: 
				if elements is Null, then intVal will be used as an index to the node in the tree that we need to
								to check its attribute.
				if elements has a value, then intVal is ignored.
	@param length is the length of elements array.
	@param elements is an array of strings. 
			if ELIMINATE_DUPLICATES_STARTKEY is chosen, elements is ignored.
			if ELIMINATE_DUPLICATES_TEXT is chosen, elements holds the tag names of elements that you want their
				text to be considered when eliminating duplicates. Example. author, book will eliminiate trees that
				are equal in author text value and book text value.
			if ELIMINATE_DUPLICATES_ATTRIBUTE is chosen, then there are two options: 
				if elements is Null, then intVal should hold an index of a node in the tree. Its attributes
					are retrieved and the value of attribute strVal is used to decide whether or not trees 
					are equal.
				if elements has strings, then these hold the tag names of elements that you want to compare
					an attribute strVal (similar to ELIMINATE_DUPLICATES_TEXT case except that it is with attr
					instead of text and the attribute name is in strVal).
	@param expectedInputSize is the expected input size. used to pass to the sort. used only if sort=true
	@param strVal is a sring which is the name of the attribute in the case of ELIMINATE_DUPLICATES_ATTRIBUTE. 
			otherwise, it is ignored.
	@param data_mng an instance of the data manager.
	@param sort is true if sort is needed. If values are already sorted, pass false to avoid extra work.
	**/
	DuplicateEliminatorIterator(IteratorClass *input, int eliminateByWhat, NREType nre, 
		char *attrName,
		DataMng *dataMng, bool sort,int numExpected, serial_t fileID, serial_t startID, int numWrites, bool externalSort);

	/**
	Destructor
	releases the space used by output buffer and arrays.
	**/
	~DuplicateEliminatorIterator();

	/**
	Access Method
	gets the next output from this iterator.
	@param node is a pointer that well be set to the output buffer or NULL (indicating that
	there are no more results).
	**/
	void next(WitnessTree *&node);
private:
	/**
	Process Method
	checks to see if the array and the tree have the same set of values.
	@param prevElements array used to hold the previous values of previous trees.
	@param in is the tree that we are checking if it matches the array.
	@param same is a pointer to a boolean value that will carry the result of the comparision.
	@returns SUCCESS if everything went fine. FAILURE if some value couldn't be found in the DB.
	**/
	bool sameAsPrev(WitnessTree *prevTuple,WitnessTree *currTuple, char **prevValue, bool &errorFound);

	char *getValue(WitnessTree *in, int index, char *attrName, int &tag);
	/**
	A buffer that holds the output tree.
	**/
	WitnessTree *resultBuffer;

	/**
	an IteratorClass that produces input for this iterator.
	**/
	IteratorClass *input; 
	

	/**
	an instance of the data manager
	**/
	DataMng *dataMng;

	/**
	is one of three values ELIMINATE_DUPLICATES_STARTKEY,
	ELIMINATE_DUPLICATES_TEXT, or ELIMINATE_DUPLICATES_ATTRIBUTE. see above for mor explaining
	**/
	int eliminateByWhat;

	/**
	a previous version of the input tree
	**/
	WitnessTree *prevTuple;

	/**
	input tree
	**/
	WitnessTree *inTuple;


	/**
	true if sorting is needed. false otherwise.
	**/
	bool sort;
	char *attrName;
	NREType nre;
	char *prevValue;
	int prevValSize;
	int prevTag;
};

#endif
