#include "../../Evaluator/EvaluatorClass.h"

#include "QueryEvaluationTreeIndexAccessNode.h"

#include "GistIndexAccess.h"
#include "HashIndexAccess.h"
#include "extra.h"

void QueryEvaluationTreeIndexAccessNode::processQueryEvalNode(EvaluatorClass* evaluator, IteratorClass*& curr)
	    {
		if (isFromFile())
		    curr = NULL;//new ShoreFile(&(evaluator->getDataManager()->getVolumeID()),&(getFid()));
		else
		{

		    if (getShoreOrGist() == SHORE_INDEX)
		    {
			curr = NULL;//indexMng->openIndex(getIndexName(),getValue());
		    }
		    else if (getShoreOrGist() == GIST_INDEX)
		    {
			int openFileIndex = evaluator->openFile(getFileName(),evaluator->getDataManager(),
				evaluator->capacityChoice, evaluator->capacity, evaluator->replacementChoice, evaluator->replacementPercentage);
			if (openFileIndex == -1)
			{
			    globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"Evaluator",__FILE__,"File is unloaded in Timber.");
			    curr=NULL; return;
			} 
			// memcpy(&val,getValue(),sizeof(int));
			bt_query_t *pred;

			if (getIndexType() == INT_INDEX)
			{
			    int val;
			    val = atoi((char *)getValue());
			    if (getValue2() != NULL)
			    {
				int val2 = atoi((char *)getValue2());
				pred = new bt_query_t(bt_query_t::bt_betw, new int(val), new int(val2));
			    }
			    else
				pred = new bt_query_t(bt_query_t::bt_eq, new int(val), NULL);
			}
			else if (getIndexType() == FLOAT_INDEX)
			{
			    float val;
			    val = (float) atof((char *)getValue());
			    if (getValue2() != NULL)
			    {
				float val2 = (float) atof((char *)getValue2());
				pred = new bt_query_t(bt_query_t::bt_betw, new float(val), new float(val2));
			    }
			    else
				pred = new bt_query_t(bt_query_t::bt_eq, new float(val), NULL);
			}
			else if (getIndexType() == DOUBLE_INDEX)
			{
			    double val;
			    val = (double) atof((char *)getValue());
			    if (getValue2() != NULL)
			    {
				double val2 = (double) atof((char *)getValue2());
				pred = new bt_query_t(bt_query_t::bt_betw, new double(val), new double(val2));
			    }
			    else
				pred = new bt_query_t(bt_query_t::bt_eq, new double(val), NULL);
			}
			else
			{
			    char *val = new char[strlen((char *)getValue())+1];
			    strcpy(val,(char *)getValue());
			    if (getValue2() != NULL)
			    {
				char *val2 = new char[strlen((char *)getValue2())+1];
				strcpy(val2,(char *)getValue2());

				if (tagIdIndex)
				    // create equality query that will find a single node (given its tag,id pair)
				    pred = TagNameAndNodeIdIndex::getTagNameAndNodeIdQuery(val, atof(val2));
				else
				    pred = new bt_query_t(bt_query_t::bt_betw, val, val2);

				//     delete [] val2; // Cong: memory leak fix 05/28/2004
			    }
			    else {
				if (tagIdIndex)
				    // return all of the nodes with a name=val
				    // (implemented as a range query for evaluator <name,ID> index)
				    pred = TagNameAndNodeIdIndex::getTagNameQuery(val);
				else
				    pred = new bt_query_t(bt_query_t::bt_eq, val, NULL);
			    }
			    //  delete [] val; // Cong: memory leak fix 05/28/2004
			}


			curr = new GistIndexAccess(getIndexName(),pred,getIndexType(),(char)openFileIndex,getNRE(),evaluator->getDataManager());

		    }
		    else
		    {
			int openFileIndex = evaluator->openFile(getFileName(),evaluator->getDataManager());
			if (openFileIndex == -1)
			{
			    globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"Evaluator",__FILE__,"File is unloaded in Timber.");
			    curr=NULL; return;
			}
			curr = new HashIndexAccess(getIndexName(),(char)openFileIndex,getIndexType(),getNRE());
		    }
		}
		setIndexName(NULL);
	    }

