/*
COPYRIGHT  � 2000-2004 
THE REGENTS OF THE UNIVERSITY OF MICHIGAN
ALL RIGHTS RESERVED

PERMISSION IS GRANTED TO USE, COPY, CREATE DERIVATIVE WORKS AND REDISTRIBUTE THIS SOFTWARE AND SUCH DERIVATIVE WORKS FOR 
NONCOMMERCIAL EDUCATION AND RESEARCH PURPOSES, SO LONG AS NO FEE IS CHARGED, AND SO LONG AS THE COPYRIGHT NOTICE ABOVE, 
THIS GRANT OF PERMISSION, AND THE DISCLAIMER BELOW APPEAR IN ALL COPIES MADE; AND SO LONG AS THE NAME OF THE UNIVERSITY 
OF MICHIGAN IS NOT USED IN ANY ADVERTISING OR PUBLICITY PERTAINING TO THE USE OR DISTRIBUTION OF THIS SOFTWARE WITHOUT 
SPECIFIC, WRITTEN PRIOR AUTHORIZATION.

THIS SOFTWARE IS PROVIDED AS IS, WITHOUT REPRESENTATION FROM THE UNIVERSITY OF MICHIGAN AS TO ITS FITNESS FOR ANY PURPOSE, 
AND WITHOUT WARRANTY BY THE UNIVERSITY OF MICHIGAN OF ANY KIND, EITHER EXPRESS OR IMPLIED, INCLUDING WITHOUT LIMITATION THE 
IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE. THE REGENTS OF THE UNIVERSITY OF MICHIGAN SHALL 
NOT BE LIABLE FOR ANY DAMAGES, INCLUDING SPECIAL, INDIRECT, INCIDENTAL, OR CONSEQUENTIAL DAMAGES, WITH RESPECT TO ANY CLAIM 
ARISING OUT OF OR IN CONNECTION WITH THE USE OF THE SOFTWARE, EVEN IF IT HAS BEEN OR IS HEREAFTER ADVISED OF THE POSSIBILITY 
OF SUCH DAMAGES.
*/

#ifndef __HashIndexAccess_h
#define __HashIndexAccess_h
#include <timber-compat.h>

#include "../../Common/IteratorClass.h"
#include "../../IndexMng/Common/ContainerClass.h"
//#include "HashIndexUpdate.h"
class IteratorClass;

/**
* HashIndexAccess
* 
* This class is a hash index retrieval iterator
* It is inherited from IteratorClass
* 
* @version 1.0
*/
class HashIndexAccess : public IteratorClass
{
public:

	/**
	* Constructor
	* 
	* Initialize all properties of the index
	* 
	* @param indexName The name of the index (atually a physical filename)
	* @param openFileIndex The index in the open file table
	* @param indexType The index type (string, integer...)
	* @param assignedNRE NRE assigned to this index access
	* @param bufPoolSize Size of the buffer pool
	*/
	HashIndexAccess(char *indexName, char openFileIndex,int indexType, NREType assignedNRE, int bufPoolSize = 5);

	/*
	* Destructor
	*/
	~HashIndexAccess();


	/*
	* Iterator Method
	*
	* Get next key/data entry from the index
	* @param node A witness tree node that will be filled in by the data 
	*/
	void next(WitnessTree *&node);

	/*
	* Process Method
	*
	* Set the current key
	* @param key The index key
	*/
	void setKey(void *key);

private:

	/*
	* Internal Method
	*
	* Read the ranges from a file to buffer array
	* @param rangesFile The file contains the ranges
	*/
	void readRangesIntoArray(FILE *rangesFile);

	/*
	* Internal Method
	*
	* Get the range from the index file
	* @param keyRange The range of the key
	* @returns Whether it succeed
	*/
	int getRangeFromFile(int keyRange);

	/*
	* Internal Method
	*
	* Find Nodes in current range
	* @returns Whether it succeed
	*/
	int findNodeInCurrRange();

	/*
	* Internal Method
	*
	* Find the matched range, just call the binary search
	* @returns The data position search found
	*/
	int findRange();

	/*
	* Internal Method
	*
	* Mark the hit range in buffer pool
	* @param range
	* @returns whether it is successful, then the index that hits
	*/
	int rangeInBufPool(int range);

	/*
	* Internal Method
	*
	* Find the oldest container according to time
	* @returns The oldest container index
	*/
	int findOldestContainer();

	/*
	* Internal Method
	*
	* Generic binary search
	* @returns The data position search found
	*/
	int binSearch();

	ContainerClass *bufPool;

	int *timeStamps;

	int *rangeNumber;

	int bufPoolSize;

	int *intRanges;
	float *fltRanges;
	double *dblRanges;
	int numRanges;

	FILE *indexFile;

	int indexType;

	WitnessTree *resultBuffer;

	char *indexName;

	int numRead;

	int keySize;
	int dataSize;
	int recSize;

	int currRangeIndex;

	int intKey;
	float fltKey;
	double dblKey;

	int timeStampCount;

	int numHits;

	char openFileIndex;

	NREType assignedNRE;
};

#endif

