#include "../../QueryEvaluationTree/QueryEvaluationTreeNode.h"

#ifndef QueryEvaluationTreeIndexAccessNode_H
#define QueryEvaluationTreeIndexAccessNode_H

#include "../../PhysicalDataMng/ScanInfo/SelectionCondition.h"
#include "../../IndexMng/Common/IndexMng_definitions.h"


class QueryEvaluationTreeIndexAccessNode: public QueryEvaluationTreeNode
{
public: 
	void processQueryEvalNode(EvaluatorClass* evaluator, IteratorClass*& curr);
	char getIdentifier();
	QueryEvaluationTreeIndexAccessNode(char* indexname,NREType nre,
		char* filename, 
		int indextype, 
		int indexServerType, 
		Value* minval,
		Value* maxval);
	~QueryEvaluationTreeIndexAccessNode();

//	void printQueryEvaluationTreeNode(bool recursive, int depth);

//	char* toString();






	QueryEvaluationTreeIndexAccessNode(char* indexname, NREType nre,char *fileName,
		//SelectionCondition* selectcond, 
		void *value, void *value2);

	char* getIndexName();
	//SelectionCondition* getIndexCondition();

	void setIndexName(char* indexname);
	//void setIndexCondition(SelectionCondition* indexcond);

	char *getFileName();
	void setFileName(char *fileName);
	void *getValue();
	void setValue(void *value);

	void *getValue2();
	void setValue2(void *value2);

	serial_t getFid();
	void setFid(serial_t fid);

	void setFromFile(bool fromFile);
	bool isFromFile();

	void setShoreOrGist(int shoreOrGist);
	int getShoreOrGist();

	void setIndexType(int indexType);
	int getIndexType();

	void setNRE(NREType nre);
	NREType getNRE();
	
	bool tagIdIndex;
	void deleteStructures();

private:
	char *indexName;
	char *fileName;
	Value* minIndexValue;
	Value* maxIndexValue;
	int indexType;
	int indexServerType;

	NREType nre;

	//SelectionCondition* indexCondition;
	void *value;
	void *value2;
	//char *fileName;
	serial_t fid;
	//int indexType;
	bool fromFile;
	int shoreOrGist;
};


#endif



