/*
COPYRIGHT  � 2000-2004 
THE REGENTS OF THE UNIVERSITY OF MICHIGAN
ALL RIGHTS RESERVED

PERMISSION IS GRANTED TO USE, COPY, CREATE DERIVATIVE WORKS AND REDISTRIBUTE THIS SOFTWARE AND SUCH DERIVATIVE WORKS FOR 
NONCOMMERCIAL EDUCATION AND RESEARCH PURPOSES, SO LONG AS NO FEE IS CHARGED, AND SO LONG AS THE COPYRIGHT NOTICE ABOVE, 
THIS GRANT OF PERMISSION, AND THE DISCLAIMER BELOW APPEAR IN ALL COPIES MADE; AND SO LONG AS THE NAME OF THE UNIVERSITY 
OF MICHIGAN IS NOT USED IN ANY ADVERTISING OR PUBLICITY PERTAINING TO THE USE OR DISTRIBUTION OF THIS SOFTWARE WITHOUT 
SPECIFIC, WRITTEN PRIOR AUTHORIZATION.

THIS SOFTWARE IS PROVIDED AS IS, WITHOUT REPRESENTATION FROM THE UNIVERSITY OF MICHIGAN AS TO ITS FITNESS FOR ANY PURPOSE, 
AND WITHOUT WARRANTY BY THE UNIVERSITY OF MICHIGAN OF ANY KIND, EITHER EXPRESS OR IMPLIED, INCLUDING WITHOUT LIMITATION THE 
IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE. THE REGENTS OF THE UNIVERSITY OF MICHIGAN SHALL 
NOT BE LIABLE FOR ANY DAMAGES, INCLUDING SPECIAL, INDIRECT, INCIDENTAL, OR CONSEQUENTIAL DAMAGES, WITH RESPECT TO ANY CLAIM 
ARISING OUT OF OR IN CONNECTION WITH THE USE OF THE SOFTWARE, EVEN IF IT HAS BEEN OR IS HEREAFTER ADVISED OF THE POSSIBILITY 
OF SUCH DAMAGES.
*/

#include "HashIndexAccess.h"

/**
* HashIndexAccess
* 
* This class is a hash index retrieval iterator
* It is inherited from IteratorClass
* 
* @version 1.0
*/


/**
* Constructor
* 
* Initialize all properties of the index
* 
* @param indexName The name of the index (atually a physical filename)
* @param openFileIndex The index in the open file table
* @param indexType The index type (string, integer...)
* @param assignedNRE NRE assigned to this index access
* @param bufPoolSize Size of the buffer pool
*/
HashIndexAccess::HashIndexAccess(char *indexName,char openFileIndex, int indexType, NREType assignedNRE, int bufPoolSize)
{

	//initialize all properties
	this->indexName = indexName;
	this->indexType = indexType;
	this->bufPoolSize = bufPoolSize;
	this->assignedNRE = assignedNRE;
	bufPool = new ContainerClass[bufPoolSize];
	timeStamps = new int[bufPoolSize];
	rangeNumber = new int[bufPoolSize];
	timeStampCount = 0;
	for (int i=0; i<bufPoolSize; i++)
		timeStamps[i] = rangeNumber[i] = -1;
	intRanges = NULL;
	fltRanges = NULL;
	dblRanges = NULL;
	intKey = -1;
	fltKey = -1;
	dblKey = -1;
	numHits = 0;
	this->openFileIndex = openFileIndex;
	char *tableFileName = new char[strlen(indexName) + 5];
	strcpy(tableFileName,indexName);
	strcat(tableFileName,".tab");
	resultBuffer = new WitnessTree;
	FILE *rangeTableFile = fopen(tableFileName,"rb");
	if (!rangeTableFile)
	{
		//printf("error opening table file %s in construct of HashIndexAccess..\n",tableFileName);
		globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"HashIndexAccess::HashIndexAccess",__FILE__,"Opening table file in constructor failed");
		return;
	}
	if (fread(&numRanges,1,sizeof(int),rangeTableFile) < sizeof(int))
	{
		//printf("error reading numRanges from file in construct of HashIndexAccess..\n");
		globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"HashIndexAccess::HashIndexAccess",__FILE__,"Reading numRanges from file in constructor failed");
		return;
	}
	delete [] tableFileName;

	// Set key size and ranges
	if (indexType == INT_INDEX)
	{
		this->keySize = sizeof(int);
		intRanges = new int[numRanges];
	}
	else if (indexType == FLOAT_INDEX)
	{
		this->keySize = sizeof(float);
		fltRanges = new float[numRanges];
	}
	else
	{
		this->keySize = sizeof(double);
		dblRanges = new double[numRanges];
	}
	readRangesIntoArray(rangeTableFile);
	fclose(rangeTableFile);

	this->dataSize = sizeof(double) + sizeof(double) + sizeof(int) +sizeof(int);
	this->recSize = this->keySize + this->dataSize;
	currRangeIndex = -1;
	
	//open an index file
	indexFile = fopen(indexName,"rb");
	if (!indexFile)
	{
		//printf("error opening index file %s in construct of HashIndexAccess..\n",indexName);
		globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"HashIndexAccess::HashIndexAccess",__FILE__,"Opening index file in constructor failed");
		return;
	}
}

/*
* Destructor
*/
HashIndexAccess::~HashIndexAccess()
{
//	printf("num Hits = %d\n",numHits);
	fclose(indexFile);
	delete resultBuffer;
	if (intRanges)
		delete [] intRanges;
	if (fltRanges)
		delete [] fltRanges;
	if (dblRanges)
		delete [] dblRanges;
	delete [] bufPool;
	delete [] timeStamps;
	delete [] rangeNumber;
}

/*
* Iterator Method
*
* Get next key/data entry from the index
* @param node A witness tree node that will be filled in by the data 
*/
void HashIndexAccess::next(WitnessTree *&node)
{
	if (indexType == INT_INDEX)
	{
		if (intKey == -1)
		{
			node = NULL;
			return;
		}
	}
	else if (indexType == FLOAT_INDEX)
	{
		if (fltKey == -1)
		{
			node = NULL;
			return;
		}
	}
	else
	{
		if (dblKey == -1)
		{
			node = NULL;
			return;
		}
	}

	int keyRange = findRange();

	currRangeIndex = rangeInBufPool(keyRange);
	if (currRangeIndex == -1)
	{
		if (getRangeFromFile(keyRange) == FAILURE)
		{
			node = NULL;
			return;
		}
	}
	if (findNodeInCurrRange() == FAILURE)
		node = NULL;
	else
		node = resultBuffer;
}

/*
* Internal Method
*
* Read the ranges from a file to buffer array
* @param rangesFile The file contains the ranges
*/
void HashIndexAccess::readRangesIntoArray(FILE *rangesFile)
{
	if (indexType == INT_INDEX)
	{
		for (int i=0; i<numRanges; i++)
			fread(&intRanges[i],1,sizeof(int),rangesFile);
	}
	else if (indexType == FLOAT_INDEX)
	{
		for (int i=0; i<numRanges; i++)
			fread(&fltRanges[i],1,sizeof(float),rangesFile);
	}
	else
	{
		for (int i=0; i<numRanges; i++)
			fread(&dblRanges[i],1,sizeof(double),rangesFile);
	} 
}

/*
* Process Method
*
* Set the current key
* @param key The index key
*/
void HashIndexAccess::setKey(void *key)
{
	if (indexType == INT_INDEX)
		intKey = *((int *)key);
	else if (indexType == FLOAT_INDEX)
		fltKey =  *((float *)key);
	else
		dblKey = *((double *)key);
}

/*
* Internal Method
*
* Get the range from the index file
* @param keyRange The range of the key
* @returns Whether it succeed
*/
int HashIndexAccess::getRangeFromFile(int keyRange)
{
	int oldCont = findOldestContainer();
	long offset = keyRange*(sizeof(int)+bufPool[oldCont].GetSize());
	if (fseek(indexFile,offset,0) != 0)
	{
		//printf("error seeking indexfile in getRangeFromFile method of HashIndexAccess...\n");
		globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"HashIndexAccess::getRangeFromFile",__FILE__,"Seeking indexfile failed.");
		return FAILURE;
	}
	bufPool[oldCont].Initialize();
	int addCursor;
	if (fread(&addCursor,1,sizeof(int),indexFile) != sizeof(int))
	{
		//printf("error reading indexfile for addCursor in getRangeFromFile method of HashIndexAccess...\n");
		globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"HashIndexAccess::getRangeFromFile",__FILE__,"Reading indexfile for addCursor failed.");
		return FAILURE;
	}
	bufPool[oldCont].SetAddCursor(addCursor);
	if ((int)fread(bufPool[oldCont].GetContainer(),1,bufPool[oldCont].GetSize(),indexFile) != bufPool[oldCont].GetSize())
	{
		//printf("error reading indexfile for container in getRangeFromFile method of HashIndexAccess...\n");
		globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"HashIndexAccess::getRangeFromFile",__FILE__,"Reading indexfile for container failed.");
		return FAILURE;
	}
	currRangeIndex = oldCont; //keyRange;
	rangeNumber[oldCont] = keyRange;
	timeStamps[oldCont] = timeStampCount;
	timeStampCount++;
	return SUCCESS;
}

/*
* Internal Method
*
* Find Nodes in current range
* @returns Whether it succeed
*/
int HashIndexAccess::findNodeInCurrRange()
{
	int cursor = 0;
	ListNode listNode;
	if (indexType == INT_INDEX)
	{
		int intBuffer;
		while (bufPool[currRangeIndex].GetData(cursor,keySize,(char *)&intBuffer) == SUCCESS)
		{
			if (intBuffer == intKey)
			{
				if (bufPool[currRangeIndex].GetData(cursor+keySize,dataSize,(char *)&listNode) == FAILURE)
					return FAILURE;
				resultBuffer->initialize();
				listNode.setFileIndex(openFileIndex);
				listNode.setNRE(assignedNRE);
				resultBuffer->appendList((ListNode *)&listNode,1);
				return SUCCESS;
			}
			cursor += keySize+dataSize;
		}
	}
	else if (indexType == FLOAT_INDEX)
	{
		float fltBuffer;
		while (bufPool[currRangeIndex].GetData(cursor,keySize,(char *)&fltBuffer) == SUCCESS)
		{
			if (fltBuffer == fltKey)
			{
				if (bufPool[currRangeIndex].GetData(cursor+keySize,dataSize,(char *)&listNode) == FAILURE)
					return FAILURE;
				resultBuffer->initialize();
				listNode.setFileIndex(openFileIndex);
				listNode.setNRE(assignedNRE);
				resultBuffer->appendList((ListNode *)&listNode,1);
				return SUCCESS;
			}
			cursor += keySize+dataSize;
		}
	}
	else
	{
		double dblBuffer;
		while (bufPool[currRangeIndex].GetData(cursor,keySize,(char *)&dblBuffer) == SUCCESS)
		{
			if (dblBuffer == dblKey)
			{
				if (bufPool[currRangeIndex].GetData(cursor+keySize,dataSize,(char *)&listNode) == FAILURE)
					return FAILURE;
				resultBuffer->initialize();
				listNode.setFileIndex(openFileIndex);
				listNode.setNRE(assignedNRE);
				resultBuffer->appendList((ListNode *)&listNode,1);
				return SUCCESS;
			}
			cursor += keySize+dataSize;
		}
	}
	return FAILURE;
}

/*
* Internal Method
*
* Find the matched range, just call the binary search
* @returns The data position search found
*/
int HashIndexAccess::findRange()
{	
	//change to binary search
	/*if (indexType == INT_INDEX)
	{
		for (int i=0; i<numRanges; i++)
			if (intKey < intRanges[i])
				return i;
	}
	else if (indexType == FLOAT_INDEX)
	{
		for (int i=0; i<numRanges; i++)
			if (fltKey < fltRanges[i])
				return i;
	}
	else
	{
		for (int i=0; i<numRanges; i++)
			if (dblKey < dblRanges[i])
				return i;
	}*/
	return binSearch();
}

/*
* Internal Method
*
* Mark the hit range in buffer pool
* @param range
* @returns whether it is successful, then the index that hits
*/
int HashIndexAccess::rangeInBufPool(int range)
{
	for (int i=0; i<bufPoolSize; i++)
		if (range == rangeNumber[i])
		{
			numHits++;
			timeStamps[i] = timeStampCount;
			timeStampCount++;
			return i;
		}
	return -1;
}

/*
* Internal Method
*
* Find the oldest container according to time
* @returns The oldest container index
*/
int HashIndexAccess::findOldestContainer()
{
	int minTimeStamp = INT_MAX;
	int minIndex = -1;
	for (int i=0; i<bufPoolSize; i++)
		if (timeStamps[i] < minTimeStamp)
		{
			minTimeStamp = timeStamps[i];
			minIndex = i;
		}

	return minIndex;
}

/*
* Internal Method
*
* Generic binary search
* @returns The data position search found
*/
int HashIndexAccess::binSearch()
{
	int low = 0;
	int high = numRanges - 1;
	if (indexType == INT_INDEX)
	{
		while (low <= high) 
		{
			int mid = (int) ((low + high) / 2);
			if (mid == 0)
			{
				if (intKey < intRanges[mid])
					return mid;
				else if (intKey >= intRanges[mid] && intKey < intRanges[mid+1])
					return mid+1;
			}
			if (mid == numRanges-1)
			{
				if (intKey < intRanges[mid])
					return mid; 
				else
					return mid+1;
			}
			if (intKey >= intRanges[mid] && intKey < intRanges[mid+1])
				return mid+1;
			if (intKey < intRanges[mid]) 
				high = mid - 1;
			else if (intKey > intRanges[mid]) 
				low = mid + 1;
		}
	}
	else if (indexType == FLOAT_INDEX)
	{
		while (low <= high) 
		{
			int mid = (int) ((low + high) / 2);
			if (mid == 0)
			{
				if (fltKey < fltRanges[mid])
					return mid;
				else if (fltKey >= fltRanges[mid] && fltKey < fltRanges[mid+1])
					return mid+1;
			}
			if (mid == numRanges-1)
			{
				if (fltKey < fltRanges[mid])
					return mid; 
				else
					return mid+1;
			}
			if (fltKey >= fltRanges[mid] && fltKey < fltRanges[mid+1])
				return mid+1;
			if (fltKey < fltRanges[mid]) 
				high = mid - 1;
			else if (fltKey > fltRanges[mid]) 
				low = mid + 1;
		}
	}
	else
	{
		while (low <= high) 
		{
			int mid = (int) ((low + high) / 2);
			if (mid == 0)
			{
				if (dblKey < dblRanges[mid])
					return mid;
				else if (dblKey >= dblRanges[mid] && dblKey < dblRanges[mid+1])
					return mid+1;
			}
			if (mid == numRanges-1)
			{
				if (dblKey < dblRanges[mid])
					return mid; 
				else
					return mid+1;
			}
			if (dblKey >= dblRanges[mid] && dblKey < dblRanges[mid+1])
				return mid+1;
			if (dblKey < dblRanges[mid]) 
				high = mid - 1;
			else if (dblKey > dblRanges[mid]) 
				low = mid + 1;
		}
	}
    return 0; // never reached
}
