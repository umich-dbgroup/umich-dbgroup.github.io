
#include "parse.hpp"

char QueryEvaluationTreeSortStopKNode::getIdentifier(void) { return 'k'; }

char SortStopKPlanParser::getIteratorIdentifier(void) { return 'k'; }

void 
SortStopKPlanParser::getQueryEvalNode(EvaluatorClass* evaluator, char* line, void* queryInput, QueryEvaluationTreeNode*& curr)
	    {
		char *token = strtok(line+2,",");
		if (token == NULL)
		{
		    globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"Evaluator",__FILE__,"Error input from file... expecting k... sort-stop k line...");
		    curr=NULL; return;
		}
		int k = atoi(token);
		token = strtok(NULL,",");
		if (token == NULL)
		{
		    globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"Evaluator",__FILE__,"Error input from file... expecting inSize... sort-stop k line...");
		    curr=NULL; return;
		}
		int inSize = atoi(token);

		char newLine[MAX_FILE_INTERFACE_LINE_SIZE];
		if (((std::iostream *)queryInput)->eof() == 0)
		    ((std::iostream *)queryInput)->getline(newLine,MAX_FILE_INTERFACE_LINE_SIZE);
		else
		{
		    globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"Evaluator",__FILE__,"Unexpected end of file... sort-stop k line...");
		    curr=NULL; return;
		}
		QueryEvaluationTreeNode *oper = evaluator->getQueryEvalNode(newLine,queryInput);
		if (oper == NULL)
		{
		    globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"Evaluator",__FILE__,"Unexpected operand returned... sort-stop k line...");
		    curr=NULL; return;
		}

		curr = new QueryEvaluationTreeSortStopKNode(oper,k,inSize);

	    }

