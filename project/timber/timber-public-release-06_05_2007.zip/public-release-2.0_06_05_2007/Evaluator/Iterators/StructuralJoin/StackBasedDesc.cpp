/*
COPYRIGHT  � 2000-2004 
THE REGENTS OF THE UNIVERSITY OF MICHIGAN
ALL RIGHTS RESERVED

PERMISSION IS GRANTED TO USE, COPY, CREATE DERIVATIVE WORKS AND REDISTRIBUTE THIS SOFTWARE AND SUCH DERIVATIVE WORKS FOR 
NONCOMMERCIAL EDUCATION AND RESEARCH PURPOSES, SO LONG AS NO FEE IS CHARGED, AND SO LONG AS THE COPYRIGHT NOTICE ABOVE, 
THIS GRANT OF PERMISSION, AND THE DISCLAIMER BELOW APPEAR IN ALL COPIES MADE; AND SO LONG AS THE NAME OF THE UNIVERSITY 
OF MICHIGAN IS NOT USED IN ANY ADVERTISING OR PUBLICITY PERTAINING TO THE USE OR DISTRIBUTION OF THIS SOFTWARE WITHOUT 
SPECIFIC, WRITTEN PRIOR AUTHORIZATION.

THIS SOFTWARE IS PROVIDED AS IS, WITHOUT REPRESENTATION FROM THE UNIVERSITY OF MICHIGAN AS TO ITS FITNESS FOR ANY PURPOSE, 
AND WITHOUT WARRANTY BY THE UNIVERSITY OF MICHIGAN OF ANY KIND, EITHER EXPRESS OR IMPLIED, INCLUDING WITHOUT LIMITATION THE 
IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE. THE REGENTS OF THE UNIVERSITY OF MICHIGAN SHALL 
NOT BE LIABLE FOR ANY DAMAGES, INCLUDING SPECIAL, INDIRECT, INCIDENTAL, OR CONSEQUENTIAL DAMAGES, WITH RESPECT TO ANY CLAIM 
ARISING OUT OF OR IN CONNECTION WITH THE USE OF THE SOFTWARE, EVEN IF IT HAS BEEN OR IS HEREAFTER ADVISED OF THE POSSIBILITY 
OF SUCH DAMAGES.
*/

#include "StackBasedDesc.h"

StackBasedDesc::StackBasedDesc(IteratorClass *ancs,IteratorClass *desc,int relation,
							   NREType ancsNRE,	NREType descNRE, NREType leftSiblingNRE, NREType rightSiblingNRE, 
							   int projectWhich, 
							   int expectedDepth,
							   DataMng *dataMng, serial_t fileID)
{
	this->ancs = ancs;
	this->desc = desc;
	this->relation = relation;
	this->dataMng = dataMng;
	this->ancsNRE = ancsNRE;
	this->descNRE = descNRE;
	this->leftSiblingNRE = leftSiblingNRE;
	this->rightSiblingNRE = rightSiblingNRE;
	this->projectWhich = projectWhich;
	this->volumeID = dataMng->getVolumeID();
	this->expectedDepth = expectedDepth;

	
	index = 0;
	numWrites = 0;
	ancsStack = new stack<SBJoinDescStackNode>(expectedDepth);

		fileCreated = true;
	this->fileID = fileID;
	resultBuffer = NULL;
	readContainer = NULL;

	ancs->next(ancsTuple);

	if (ancsTuple)
	{
		if (ancsTuple->isSimple() ) 
		{
			this->ancsNodeType = LIST_NODE;
			this->listNodeSize = sizeof(ListNode);
		}
		else
		{
			this->ancsNodeType = LIST_NODE_WITH_DATA;
			this->listNodeSize = sizeof(ComplexListNode);
		}
		
		readContainer = new ContainerClass;
		/*
		rc = ss_m::create_file(volumeID, fileID,ss_m::t_regular);
		if (rc) 
		{
			stringstream msg;
			msg<<rc<<'\0';
			globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"Evaluator",__FILE__,msg.rdbuf()->str().c_str());
			ancsTuple = NULL;
			descTuple = NULL;
			return;				
		}
		fileCreated = true;*/
		int maxIDs = gSettings->getIntegerValue("MAX_ID_PER_FILE_STRUCTURAL_JOINS",10000);
		rc = ss_m::create_id(volumeID,maxIDs,startID);

		if (rc) 
		{
			stringstream msg;
			msg<<rc<<'\0';
			globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"Evaluator",__FILE__,msg.rdbuf()->str().c_str());
			ancsTuple = NULL;
			descTuple = NULL;			
			return;				
		}	
	
		numWrites = maxIDs;
	}
	else
	{
		if (globalErrorInfo.doWeHaveAProblem())
		{
			descTuple = NULL;
			return;
		}
		ancsNodeType = LIST_NODE;
	}


	desc->next(descTuple);
	if (descTuple)
	{
		if (descTuple->isSimple())
			this->descNodeType = LIST_NODE;
		else
			this->descNodeType = LIST_NODE_WITH_DATA;
	}
	else
	{
		if (globalErrorInfo.doWeHaveAProblem())
		{
			ancsTuple = NULL;
			return;
		}
		descNodeType = LIST_NODE;
	}
	
	
	if (ancsNodeType == LIST_NODE_WITH_DATA || descNodeType == LIST_NODE_WITH_DATA)
		resultBuffer = new WitnessTree(LIST_NODE_WITH_DATA,dataMng);
	else
		resultBuffer = new WitnessTree;
}

StackBasedDesc::~StackBasedDesc()
{
	delete ancsStack;
	if (resultBuffer) delete resultBuffer;

	if (readContainer)
		delete readContainer;

	if (fileCreated)
	{
		rc = ss_m::destroy_file(volumeID, fileID, true, numWrites);
		if (rc) 
		{
			stringstream msg;
			msg<<rc<<'\0';
			globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"Evaluator",__FILE__,msg.rdbuf()->str().c_str());		
		}
	}
	
	delete desc;
	delete ancs;
}


void StackBasedDesc::next(WitnessTree *&node)
{
#ifdef EVAL_TIME_OUT
	clock_t currTime = clock();
	double queryDuration = (double)(currTime - gQueryStartTime) / CLOCKS_PER_SEC;
	if (queryDuration >= gTimeOutAfter)
	{
		globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"Evaluator",__FILE__,"Query Timed Out.");
		node = NULL;
		return;
	}
#endif
	while (ancsTuple && descTuple)
	{
		int r = isAncsFirst();
		if (r == FAILURE)
		{
			globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"Evaluator",__FILE__,"Method isAncsFirst returned FAILURE.");
			node = NULL;
			return;
		}
		if (r)
		{
			if (HandleAncs() == FAILURE)
			{
				node = NULL;
				return;
			}
			ancs->next(ancsTuple);
		}
		else
		{
			if (HandleDesc() == SUCCESS)
			{
				node = resultBuffer;
				return;
			}
			else
				desc->next(descTuple);
		}
#ifdef EVAL_TIME_OUT
	clock_t currTime = clock();
	double queryDuration = (double)(currTime - gQueryStartTime) / CLOCKS_PER_SEC;
	if (queryDuration >= gTimeOutAfter)
	{
		globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"Evaluator",__FILE__,"Query Timed Out.");
		node = NULL;
		return;
	}
#endif
	}

	// if no more descendants, we are done
	if (!descTuple)
	{
		node = NULL;
		return;
	}

	// if we reach this point, we have desc but no more ancestors 
	// coming (we may have some in stack)
	// so, check stack
	if (ancsStack->IsEmpty())
	{
		node = NULL;
		return;
	}

	// now we need to finish desc
	while (descTuple)
	{
		KeyType descStartKey = getStartKeyOf(descTuple,descNRE,"descendant.");

		if (descStartKey == FAILURE)
		{
			globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"Evaluator",__FILE__,"Unable to get key of descendant.");
			node = NULL;
			return;
		}
		if (HandleDesc() == SUCCESS)
		{
			node = resultBuffer;
			return;
		}
		else
		{
			// if handleDesc returned FAILURE, this might mean that the stack
			// is empty. If it is, we are done
			if (ancsStack->IsEmpty())
			{
				node = NULL;
				return;
			}
			else
				desc->next(descTuple);
		}
	}
	node = NULL;
}

KeyType StackBasedDesc::getStartKeyOf(WitnessTree *tree, NREType nre, char *str)
{
	KeyType sk = FAILURE;
	if (tree->moreThanOneMatch(nre))
	{
		char tmp[200];
		strcpy(tmp,"More than one node matched NRE of ");
		strcat(tmp,str);
		globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"Evaluator",__FILE__,tmp);
		return FAILURE;
	}
	if (tree->isSimple())
	{
		ListNode *n = (ListNode *)(tree->findNodeNRE(nre));
		if (!n)
		{
			char tmp[200];
			strcpy(tmp,"No node matched NRE of ");
			strcat(tmp,str);
			globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"Evaluator",__FILE__,tmp);
			return FAILURE;
		}
		sk = n->GetStartPos();
	}
	else
	{
		ComplexListNode *n = (ComplexListNode *)(tree->findNodeNRE(nre));
		if (!n)
		{
			char tmp[200];
			strcpy(tmp,"No node matched NRE of ");
			strcat(tmp,str);
			globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"Evaluator",__FILE__,tmp);
			return FAILURE;
		}
		sk = n->GetStartPos();
	}
	return sk;
}

int StackBasedDesc::isAncsFirst()
{
	KeyType ancsStartKey;
	KeyType descStartKey;

	//get start key of ancestor
	ancsStartKey = getStartKeyOf(ancsTuple,ancsNRE,"ancestor.");

	if (ancsStartKey == FAILURE)
	{
		globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"Evaluator",__FILE__,"Unable to get key of ancestor.");
		return FAILURE;
	}

	//get start key of descendant
	descStartKey = getStartKeyOf(descTuple,descNRE,"descendant.");
	
	if (descStartKey == FAILURE)
	{
		globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"Evaluator",__FILE__,"Unable to get key of descendant.");
		return FAILURE;
	}


	// does the ancs come first?
	return (int)(ancsStartKey < descStartKey);
}

int StackBasedDesc::HandleAncs()
{
	//does the ancs pop the stack?
	if (ancsNodeType == LIST_NODE)
		PopStackIfNeeded(((ListNode *)(ancsTuple->findNodeNRE(ancsNRE)))->GetStartPos());
	else
		PopStackIfNeeded(((ComplexListNode *)(ancsTuple->findNodeNRE(ancsNRE)))->GetStartPos());


	if (ancsStack->IsEmpty())
	{
		if (PushAncs() == FAILURE)
			return FAILURE;
		return SUCCESS;
	}

	SBJoinDescStackNode *topOfStack = ancsStack->GetTop();

	// so, we found out that A1 is common between the newcomer and the top of the stack
	// we need to add Bs and Cs to the buffer of the top of the stack
	bool sameAncs;
	if (ancsNodeType == LIST_NODE)
		sameAncs = (((ListNode *)(ancsTuple->findNodeNRE(ancsNRE)))->GetStartPos() 
													== topOfStack->GetActualAncs()->GetStartPos());
	else
		sameAncs = (((ComplexListNode *)(ancsTuple->findNodeNRE(ancsNRE)))->GetStartPos() 
													== topOfStack->GetActualAncs()->GetStartPos());
	if (sameAncs)
	{
		if (AddToTopOfStack() == FAILURE)
			return FAILURE;
	}
	else
		if (PushAncs() == FAILURE) return FAILURE;
	return SUCCESS;
}


int StackBasedDesc::HandleDesc()
{
//does the desc pop the stack?
	if (descNodeType == LIST_NODE)
		PopStackIfNeeded(((ListNode *)(descTuple->findNodeNRE(descNRE)))->GetStartPos());
	else
		PopStackIfNeeded(((ComplexListNode *)(descTuple->findNodeNRE(descNRE)))->GetStartPos());

	if (ancsStack->IsEmpty())
		return FAILURE; 

	int res;
	if (relation == PARENT_CHILD) 
		res = JoinWithTopOnly();
	else
	{
		if (projectWhich == DESCENDANT)
			res = JoinWithTopOnly();
		else
			res = JoinWithAllStack();
	}

	return res;
}


int StackBasedDesc::PushAncs()
{
	// here we push the ancs into stack
	if (ancsNodeType == LIST_NODE)
		ancsStack->Push((ListNode *)(ancsTuple->findNodeNRE(ancsNRE)));
	else
		ancsStack->Push((ComplexListNode *)(ancsTuple->findNodeNRE(ancsNRE)));

	ancsStack->GetTop()->SetListsVolumeAndFileIDs(volumeID,fileID);
	ancsStack->GetTop()->GetListOfBuffers()->StartScan();

	if (this->writeAncsTreeToBuffer(ancsStack->GetTop()->GetBuffer(),ancsTuple) == FAILURE)
	{
		stringstream msg;
			int maxSz = 0;
		while (ancsTuple)
		{
			int currSz = calculateSizeOfAncsTree(ancsTuple);
			if (currSz > maxSz)
				maxSz = currSz;
			ancs->next(ancsTuple);
		}
		maxSz++;
		msg<<"A container cannot accomodate 1 witness tree... increase CONTAINER_SIZE parameter in settings file "<<
			"to at least "<<maxSz<<"..."<<'\0';
		globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"Evaluator",__FILE__,msg.rdbuf()->str().c_str());
		return FAILURE; 
	}
	return SUCCESS;
}


int StackBasedDesc::AddToTopOfStack()
{
	SBJoinDescStackNode *topOfStack = ancsStack->GetTop();

	// if the buffer has not enough space to carry more data, write it to shore
	if (!(topOfStack->EnoughSpace(topOfStack->GetBuffer(),this->calculateSizeOfAncsTree(ancsTuple))))    
			// in buffer
	{
		if (WriteBufferToItsList(topOfStack->GetBuffer(),topOfStack->GetListOfBuffers()) == FAILURE)
			return FAILURE;
	}

	if (writeAncsTreeToBuffer(topOfStack->GetBuffer(),ancsTuple) == FAILURE)
	{
		stringstream msg;
			int maxSz = 0;
		while (ancsTuple)
		{
			int currSz = calculateSizeOfAncsTree(ancsTuple);
			if (currSz > maxSz)
				maxSz = currSz;
			ancs->next(ancsTuple);
		}
		maxSz++;
		msg<<"A container cannot accomodate 1 witness tree... increase CONTAINER_SIZE parameter in settings file "<<
			"to at least "<<maxSz<<"..."<<'\0';
		globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"Evaluator",__FILE__,msg.rdbuf()->str().c_str());
		return FAILURE; 
	}
	return SUCCESS;
}



int StackBasedDesc::JoinWithAllStack()
{
	// we already reached top of stack, initialize the index and then we are done with this 
	// desc
	if (index == ancsStack->Size())
	{
		index = 0;
		return FAILURE;
	}

	int res;

	// put in resultBuffer the ancs in stack with index and desc tuple
	res = MergeNodes(ancsStack->GetByIndex(index),descTuple);

	switch (res)
	{
		case SINGLE_RESULT: ancsStack->GetByIndex(index)->GetListOfBuffers()->StartScan(); index++; break;
		case MULTI_RESULT: break;
		case FAILURE: /*index = 0;*/ return FAILURE;
	}
	return SUCCESS;
}

int StackBasedDesc::JoinWithTopOnly()
{
	//here, we are joining with top element in the stack. first, we check if the levels are one apart.
	if (relation == PARENT_CHILD)
	{
		int descLevel;
		if (descNodeType == LIST_NODE)
			descLevel = ((ListNode *)(descTuple->findNodeNRE(descNRE)))->GetLevel()-1;
		else
			descLevel = ((ComplexListNode *)(descTuple->findNodeNRE(descNRE)))->GetLevel()-1;
		if (ancsStack->GetTop()->GetActualAncs()->GetLevel() == descLevel)
		{
			switch (MergeNodes(ancsStack->GetTop(),descTuple))
			{
			case FAILURE: return FAILURE;
			case SINGLE_RESULT: ancsStack->GetTop()->GetListOfBuffers()->StartScan();
				desc->next(descTuple); return SUCCESS;
			case MULTI_RESULT: return SUCCESS;
			}
			return SUCCESS;  // default
		}
		else
			return FAILURE;
	}
	else   // we are joining with top only because desc is to be projected
		// we also know that there are no lists with ancs
	{
		if (MergeNodes(ancsStack->GetTop(),descTuple) == FAILURE)
			return FAILURE;
		else
		{
			desc->next(descTuple);
			return SUCCESS;
		}
	}

}

int StackBasedDesc::MergeNodes(SBJoinDescStackNode *node1, WitnessTree *node2)
{
/*if (node1->GetBuffer()->IsEmpty())
	{
		resultBuffer->initialize();

		//adding ancs and co. to result
		if (projectWhich == BOTH || projectWhich == ANCESTOR)
		{
			if (ancsNodeType == LIST_NODE)
				resultBuffer->appendList(node1->GetActualAncs(),1);
			else
				resultBuffer->appendList(node1->GetActualAncsComplex(),dataMng,1);
		}

		//adding desc and co. to result
		if (projectWhich == BOTH || projectWhich == DESCENDANT)
		{
			if (descNodeType == LIST_NODE)
				resultBuffer->appendList((ListNode *)(node2->getBuffer()),node2->length());
			else
				resultBuffer->appendList((ComplexListNode *)(node2->getBuffer()),dataMng,node2->length());
		}
		resultBuffer->setScore(resScore(node1->getScore(),node2->getScore()));
		return SINGLE_RESULT;
	}*/

	if (node1->EmptyListOfBuffers(node1->GetListOfBuffers()))
		return ReadFromBuffer(node1,node2);
	else
	{
		int res = 0;
		// here we have to retreive data from file and output
		if (readContainer->IsEmpty())
			res = GetDataFromShoreList(node1,node2);
		else
		{  // we are in the middle of reading and outputting a buffer
		//	int res;
			double scr;
			res = readContainer->GetNext(sizeof(double),(char *)&scr);
			
			if (res == SUCCESS)
			{// we got something from the container
				int treeSz;
				res = readContainer->GetNext(sizeof(int),(char *)&treeSz);
				CopyNodes(node1,treeSz,node2,readContainer);

				resultBuffer->setScore(resScore(scr,node2->getScore()));
				res = MULTI_RESULT;
			}
			else
				//the we reached the end of the container, get the next one from the list.
				res = GetDataFromShoreList(node1,node2);
		}
		if (res == FAILURE)
		{// initialize for the next time we need to output node1
			node1->GetListOfBuffers()->StartScan();
			node1->GetBuffer()->SetScanCursor(0);
		}
		return res;
	}
}


int StackBasedDesc::GetDataFromShoreList(SBJoinDescStackNode *node1, WitnessTree *node2)
{
	//node1 is the stack node: the ancs. node2 is the desc
	// we are getting the next container fromt eh ancs list
	node1->SetListsVolumeAndFileIDs(volumeID,fileID);
	readContainer->Initialize();
	if (node1->ReadFromList(node1->GetListOfBuffers(),readContainer) == SUCCESS)
		// copy to resultBuffer, the ancs, its list and the desc.
		return CopyToResult(readContainer,node1,node2);
	else
		// if we reached the end of the list, we need to consider the buffer of node1
		return ReadFromBuffer(node1,node2);
}


int StackBasedDesc::ReadFromBuffer(SBJoinDescStackNode *node1, WitnessTree *node2)
{
	// if the buffer exists and has data in it, then we want to copy to result buffer
	// otherwise, we are done with this desc.
	if (node1->BufferExistsAndNotEmpty(node1->GetBuffer()))
		return CopyToResult(node1->GetBuffer(),node1,node2);
	else
		return FAILURE;
}

int StackBasedDesc::CopyToResult(ContainerClass *buf, SBJoinDescStackNode *node1, WitnessTree *node2)
{
	int res;

	// we are getting the next entry in the buffer.
	double scr;
	res = buf->GetNext(sizeof(double),(char *)&scr);
	

	if (res == SUCCESS)
	{ // if we got something from the buffer, we copy stuff to resultBuffer.
		int treeSz;
		res = buf->GetNext(sizeof(int),(char *)&treeSz);
		CopyNodes(node1,treeSz,node2,buf);
		resultBuffer->setScore(resScore(scr,node2->getScore()));
		if (buf->ExceedBoundry(sizeof(double)+sizeof(int))) 
		{
			//this means next time we come, we will get failure even with a new desc
			buf->SetScanCursor(0);
			return SINGLE_RESULT;
		}
		return MULTI_RESULT;
	}
	else
		return FAILURE;
}

void StackBasedDesc::CopyNodes(SBJoinDescStackNode *source1,int source1Sz, WitnessTree *source2,ContainerClass *buf)	
{
	// in this method, we are copying the ancs (source1) and its list (readBuffeSimple/Complex) and the desc
	// to resultBuffer while maintaining order
	resultBuffer->initialize();
	if (source1Sz == 0)
	{
		if (projectWhich == BOTH)
		{
			if (ancsNodeType == LIST_NODE)
				resultBuffer->appendList(source1->GetActualAncs(),1);
			else
				resultBuffer->appendList(source1->GetActualAncsComplex(),dataMng,1);
		}

		//adding desc and co. to result
		
		if (descNodeType == LIST_NODE)
			resultBuffer->appendList((ListNode *)(source2->getBuffer()),source2->length());
		else
			resultBuffer->appendList((ComplexListNode *)(source2->getBuffer()),dataMng,source2->length());
		
		return;
	}

	// adding ancs
	if (projectWhich == BOTH)
	{
		int ancsIndex;
		buf->GetNext(sizeof(int),(char *)&ancsIndex);

		if (ancsNodeType == LIST_NODE)
		{
			resultBuffer->appendList((ListNode *)buf->GetNextPtr(ancsIndex*listNodeSize),ancsIndex);
			resultBuffer->appendList(source1->GetActualAncs(),1);
			resultBuffer->appendList((ListNode *)buf->GetNextPtr((source1Sz-ancsIndex)*listNodeSize),
				source1Sz-ancsIndex);
		}
		else
		{
			resultBuffer->appendList((ComplexListNode *)buf->GetNextPtr(ancsIndex*listNodeSize),dataMng,ancsIndex);
			resultBuffer->appendList(source1->GetActualAncsComplex(),dataMng,1);
			resultBuffer->appendList((ComplexListNode *)buf->GetNextPtr((source1Sz-ancsIndex)*listNodeSize),
				dataMng,source1Sz-ancsIndex);
		}
	}
	else
	{ 
		if (ancsNodeType == LIST_NODE)
			resultBuffer->appendList((ListNode *)buf->GetNextPtr(source1Sz*listNodeSize),source1Sz);
		else
			resultBuffer->appendList((ComplexListNode *)buf->GetNextPtr(source1Sz*listNodeSize),dataMng,source1Sz);
	}

	//adding desc
	if (descNodeType == LIST_NODE)
		resultBuffer->appendList((ListNode *)source2->getBuffer(),source2->length());
	else
		resultBuffer->appendList((ComplexListNode *)source2->getBuffer(),dataMng,source2->length());
}

void StackBasedDesc::PopStackIfNeeded(KeyType startPosition)
{
	if (ancsStack->IsEmpty())
		return;
	while (startPosition > ancsStack->GetTop()->GetActualAncs()->GetEndPos())
	{
		ancsStack->Pop();
		if (ancsStack->IsEmpty())
			return;
	}
}
double StackBasedDesc::resScore(double ancsScore, double descScore)
{
	if (ancsScore == -1 && descScore == -1)
		return -1;
	if (ancsScore == -1)
		return descScore;
	if (descScore == -1)
		return ancsScore;
	return ancsScore+descScore;
}

int StackBasedDesc::writeAncsTreeToBuffer(ContainerClass *buf, WitnessTree *tree)
{
	// a single tree in the buffer should look like:
	// score treeSize ancsIndex tree nreTableNumOfEntries nre nreEntrySz index1 index2 ... nre nreEntrySz index1...
	if (this->calculateSizeOfAncsTree(tree) >= buf->GetSize())
		return FAILURE;
	//adding score
	double sc = tree->getScore();
	buf->AddData((char *)&sc,sizeof(double));

	//adding the tree size
	int treeSz = tree->length() - 1;
	buf->AddData((char *)&treeSz,sizeof(int));

	// if the ancs has a list associated with it, add the list to the buffer.
	if (treeSz > 0)
	{
		int ancsIndex = tree->getIndexOfNRE(ancsNRE);
		buf->AddData((char *)&ancsIndex,sizeof(int));
		for (int i =0; i < ancsIndex; i++)
			buf->AddData((char *)tree->getNodeByIndex(i),listNodeSize);
		
		for (int i = ancsIndex+1; i < ancsTuple->length(); i++)
			buf->AddData((char *)tree->getNodeByIndex(i),listNodeSize);
	}

	//adding nre table
	//WriteNRETableToBuffer(buf),tree->getNRETable());	
	return SUCCESS;
}


int StackBasedDesc::calculateSizeOfAncsTree(WitnessTree *tree)
{
	int size = 0;

	//score
	size += sizeof(double);

	//tree size
	size += sizeof(int);

	if (tree->length() > 1)
	{
		//ancs index
		size += sizeof(int);

		//tree itself
		size += (tree->length()-1)*listNodeSize;
	}

//	size += calculateSizeOfNRETable(tree->getNRETable());

	return size;
}

int StackBasedDesc::WriteBufferToItsList(ContainerClass *cont, ShoreList *list)
{
	if (cont->IsEmpty())
		return SUCCESS;

	if (list->IsEmpty())
	{
		serial_t currRecID = startID;
		if (startID.increment(1) == true)
			//overflow of shore logical ids
		{
			globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"Evaluator",__FILE__,"Shore Logical ID overflow.");
			return FAILURE;
		}
		if (SBJoinAncsStackNode::WriteBufferToList(cont,list,fileID,volumeID,currRecID,startID) == FAILURE)
			return FAILURE;
		if (startID.increment(1) == true)
			//overflow of shore logical ids
		{
			globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"Evaluator",__FILE__,"Shore Logical ID overflow.");
			return FAILURE;
		}
	}
	else
	{
		if (SBJoinAncsStackNode::WriteBufferToList(cont,list,startID) == FAILURE)
			return FAILURE;
		if (startID.increment(1) == true)
			//overflow of shore logical ids
		{
			globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"Evaluator",__FILE__,"Shore Logical ID overflow.");
			return FAILURE;
		}
	}
	cont->Initialize();
	return SUCCESS;
}


