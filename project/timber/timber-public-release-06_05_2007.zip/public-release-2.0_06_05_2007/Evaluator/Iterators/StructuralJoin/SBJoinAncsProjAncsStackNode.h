/*
COPYRIGHT  � 2000-2004 
THE REGENTS OF THE UNIVERSITY OF MICHIGAN
ALL RIGHTS RESERVED

PERMISSION IS GRANTED TO USE, COPY, CREATE DERIVATIVE WORKS AND REDISTRIBUTE THIS SOFTWARE AND SUCH DERIVATIVE WORKS FOR 
NONCOMMERCIAL EDUCATION AND RESEARCH PURPOSES, SO LONG AS NO FEE IS CHARGED, AND SO LONG AS THE COPYRIGHT NOTICE ABOVE, 
THIS GRANT OF PERMISSION, AND THE DISCLAIMER BELOW APPEAR IN ALL COPIES MADE; AND SO LONG AS THE NAME OF THE UNIVERSITY 
OF MICHIGAN IS NOT USED IN ANY ADVERTISING OR PUBLICITY PERTAINING TO THE USE OR DISTRIBUTION OF THIS SOFTWARE WITHOUT 
SPECIFIC, WRITTEN PRIOR AUTHORIZATION.

THIS SOFTWARE IS PROVIDED AS IS, WITHOUT REPRESENTATION FROM THE UNIVERSITY OF MICHIGAN AS TO ITS FITNESS FOR ANY PURPOSE, 
AND WITHOUT WARRANTY BY THE UNIVERSITY OF MICHIGAN OF ANY KIND, EITHER EXPRESS OR IMPLIED, INCLUDING WITHOUT LIMITATION THE 
IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE. THE REGENTS OF THE UNIVERSITY OF MICHIGAN SHALL 
NOT BE LIABLE FOR ANY DAMAGES, INCLUDING SPECIAL, INDIRECT, INCIDENTAL, OR CONSEQUENTIAL DAMAGES, WITH RESPECT TO ANY CLAIM 
ARISING OUT OF OR IN CONNECTION WITH THE USE OF THE SOFTWARE, EVEN IF IT HAS BEEN OR IS HEREAFTER ADVISED OF THE POSSIBILITY 
OF SUCH DAMAGES.
*/

#ifndef __SBJoinAncsProjAncsStackNode_h
#define __SBJoinAncsProjAncsStackNode_h
#include <timber-compat.h>

#include "SimpleStackNode.h"
#include "../../Common/ShoreList.h"
/**
* A stack node used in StackBasedAncsProjAncs Class. Derived from SimpleStackNode class.
* Contains a memory buffer and a disk list.
* @see ContainerClass 
* @see ShoreList
* @see SimpleStackNode
* @see stack
* @see StackBasedAncsProjAncs
* @author Shurug Al-Khalifa 
* @version 1.0
*/
class SBJoinAncsProjAncsStackNode : public SimpleStackNode
{
public:
	/**
	Constructor.
	Initializes data members.
	**/
	SBJoinAncsProjAncsStackNode();

	/**
	Destructor.
	**/
	virtual ~SBJoinAncsProjAncsStackNode();

	/**
	Process Method.
	initializes the buffer data member.
	**/
	void NewBuffer();

	/**
	Process Method.
	adds data to a memory buffer.
	@param buf is the buffer that you want to write data to.
	@param data is the data you want to add to the buffer.
	@param length is the size (bytes) of data that you want written to buf.
	@returns FAILURE if the buffer is full. otherwise, it returns SUCCESS.
	**/
	static int AddToBuffer(ContainerClass *buf, char *data, int length);

	/**
	Access Method.
	gets data from a memory buffer.
	@param buf is the buffer that you want to get data from.
	@param start is the location to start reading from.
	@param length is the size (bytes) of data that you want to read.
	@param data is an allocated memory that you want to read to.
	@returns FAILURE if the buffer is empty or you exceeded boundries. 
		otherwise, it returns SUCCESS.
	**/
	int GetFromBuffer(ContainerClass *buf, int start, int length, char *data); 

	/**
	Access Method.
	gets data from a memory buffer starting from the buffer's scan cursor.
	@param buf is the buffer that you want to get data from.
	@param length is the size (bytes) of data that you want to read.
	@param data is an allocated memory that you want to read to.
	@returns FAILURE if the buffer is empty or you exceeded boundries. 
		otherwise, it returns SUCCESS.
	**/
	int GetFromBuffer(ContainerClass *buf, int length, char *data);	
	
	/**
	Access Method.
	@returns a pointer to the data member buffer.
	**/
	ContainerClass *GetBuffer();
	
	/**
	Access Method.
	@returns a pointer to descendant buffer.
	**/
	ContainerClass *GetDescBuffer();

	/**
	Access Method.
	@returns a pointer to descendant list.
	**/
	ShoreList *GetDescList();

	/**
	Access Method.
	checks for enough space in a buffer.
	@param buf is the buffer you want to check.
	@param size is the size (in bytes) that you want to fit in buf.
	@returns true if there is enough space. Otherwise, returns false.
	**/
	bool EnoughSpace(ContainerClass *buf, int size);

	/**
	Access Method.
	checks if the buffer has data in it.
	@param buf is the buffer you want to check.
	@returns true if the buffer contains data. Otherwise, returns false.
	**/
	bool BufferExistsAndNotEmpty(ContainerClass *buf);

	/**
	Process Method.
	initializes the data members.
	**/
	void initialize();

	/**
	Process Method.
	writes a given buffer to a given list. (write data from memory to disk)
	@param buf is the memory buffer to be written.
	@param list is the disk list to write the buffer to.
	@param nextRecID is the rid of the next buffer to be written. (a list is sort of a queue)
	**/
	static int WriteBufferToList(ContainerClass *buf, ShoreList *list, serial_t nextRecID);  
	
	/**
	Process Method.
	writes a given buffer to a given list. (write data from memory to disk).
	This method is used only the first time you write a buffer to this list.
	@param buf is the memory buffer to be written.
	@param list is the disk list to write the buffer to.
	@param fileID is the id of the file to write the list.
	@param volumeID is the id of the current volume.
	@param currRecID is the record id of the file to be written.
	@param nextRecID is the rid of the next buffer to be written. (a list is sort of a queue)
	**/
	static int WriteBufferToList(ContainerClass *buf, ShoreList *list, serial_t fileID, 
				lvid_t volumeID, serial_t currRecID, serial_t nextRecID);

	/**
	Access Method.
	reads a buffer from the disk list. (from disk to memory)
	@param list is the list you want to read from.
	@param buf is a memory area that you read the list into.
	@returns FAILURE if the list is empty or has been fully scanned. SUCCESS otherwise.
	**/
	int ReadFromList(ShoreList *list, ContainerClass *cont);

	/**
	Access Method.
	checks a disk list for records.
	@param list is the list you want to check.
	@returns true if the list has records in it. Otherwise, returns false.
	**/
	bool EmptyListOfBuffers(ShoreList *list);

	/**
	Process Method.
	Sets the value of the volume id and the file id used in shore lists.
	@param volumeID is the volume id.
	@param fileID is the current file id.
	**/
	void SetListsVolumeAndFileIDs(lvid_t volumeID,serial_t fileID);

	/**
	Access Method.
	@returns a pointer to the disk list, listOfBuffers.
	**/
	ShoreList *GetListOfBuffers();

	void mergeBuffersAndLists(ContainerClass *buffer, ShoreList *listOfBuffers, serial_t &id, serial_t fileID,
		lvid_t volumeID);


	bool isMarkedForOutput();
	void setMarkedForOutput(bool markedForOutput);

	double getScore();
	void setScore(double score);
	void prepareToCopyDelete();

private:
	ContainerClass buffer;
	ShoreList listOfBuffers;
	
	ContainerClass descBuffer;
	ShoreList descList;

	bool markedForOutput;
	double score;
};

#endif
