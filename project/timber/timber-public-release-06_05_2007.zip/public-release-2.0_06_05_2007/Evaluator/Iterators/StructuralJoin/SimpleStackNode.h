/*
COPYRIGHT  � 2000-2004 
THE REGENTS OF THE UNIVERSITY OF MICHIGAN
ALL RIGHTS RESERVED

PERMISSION IS GRANTED TO USE, COPY, CREATE DERIVATIVE WORKS AND REDISTRIBUTE THIS SOFTWARE AND SUCH DERIVATIVE WORKS FOR 
NONCOMMERCIAL EDUCATION AND RESEARCH PURPOSES, SO LONG AS NO FEE IS CHARGED, AND SO LONG AS THE COPYRIGHT NOTICE ABOVE, 
THIS GRANT OF PERMISSION, AND THE DISCLAIMER BELOW APPEAR IN ALL COPIES MADE; AND SO LONG AS THE NAME OF THE UNIVERSITY 
OF MICHIGAN IS NOT USED IN ANY ADVERTISING OR PUBLICITY PERTAINING TO THE USE OR DISTRIBUTION OF THIS SOFTWARE WITHOUT 
SPECIFIC, WRITTEN PRIOR AUTHORIZATION.

THIS SOFTWARE IS PROVIDED AS IS, WITHOUT REPRESENTATION FROM THE UNIVERSITY OF MICHIGAN AS TO ITS FITNESS FOR ANY PURPOSE, 
AND WITHOUT WARRANTY BY THE UNIVERSITY OF MICHIGAN OF ANY KIND, EITHER EXPRESS OR IMPLIED, INCLUDING WITHOUT LIMITATION THE 
IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE. THE REGENTS OF THE UNIVERSITY OF MICHIGAN SHALL 
NOT BE LIABLE FOR ANY DAMAGES, INCLUDING SPECIAL, INDIRECT, INCIDENTAL, OR CONSEQUENTIAL DAMAGES, WITH RESPECT TO ANY CLAIM 
ARISING OUT OF OR IN CONNECTION WITH THE USE OF THE SOFTWARE, EVEN IF IT HAS BEEN OR IS HEREAFTER ADVISED OF THE POSSIBILITY 
OF SUCH DAMAGES.
*/

#ifndef __SimpleStackNode_h
#define __SimpleStackNode_h
#include <timber-compat.h>

#include "../../Common/ComplexListNode.h"

/**
* the base class for nodes used in the join algorithms to be kept in the stack.
* @see ComplexListNode
* @see stack
* @see ListNode
* @see SBJoinDescStackNode
* @author Shurug Al-Khalifa 
* @version 1.0
*/

class SimpleStackNode
{
public:
	/**
	Constructor.
	**/
	SimpleStackNode();

	/**
	Destructor.
	**/
	virtual ~SimpleStackNode();

	/**
	Process Method.
	Initializes the stack node.
	**/
	void initialize();

	/**
	Access Method.
	@returns the list node in the stack (start-end-level)
	**/
	ListNode *GetActualAncs();

	/**
	Access Method.
	@returns the complex list node in the stack (start-end-level + data)
	**/
	ComplexListNode *GetActualAncsComplex();

	/**
	Process Method.
	sets the value of the actual stack node (start-end-level)
	@param actualAncs is the new value of the stack node.
	**/
	void SetActualAncs(ListNode *actualAncs);

	/**
	Process Method.
	sets the value of the actual stack node (start-end-level + data)
	@param actualAncs is the new value of the stack node.
	**/
	void SetActualAncsComplex(ComplexListNode *actualAncs);

	/**
	Access Method.
	@returns true if the stack node has only start-end-level. returns false otherwise.
	**/
	bool isSimple();

	bool hasBeenJoined();
	void setBeenJoined(bool beenJoined);

	void prepareToCopyDelete();
private:
	/**
	actual node stacked info.
	**/
	ComplexListNode actualAncs;		
	bool simple;
	bool beenJoined;
};
#endif
