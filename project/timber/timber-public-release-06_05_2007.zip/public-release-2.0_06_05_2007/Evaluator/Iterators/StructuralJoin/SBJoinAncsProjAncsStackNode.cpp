/*
COPYRIGHT  � 2000-2004 
THE REGENTS OF THE UNIVERSITY OF MICHIGAN
ALL RIGHTS RESERVED

PERMISSION IS GRANTED TO USE, COPY, CREATE DERIVATIVE WORKS AND REDISTRIBUTE THIS SOFTWARE AND SUCH DERIVATIVE WORKS FOR 
NONCOMMERCIAL EDUCATION AND RESEARCH PURPOSES, SO LONG AS NO FEE IS CHARGED, AND SO LONG AS THE COPYRIGHT NOTICE ABOVE, 
THIS GRANT OF PERMISSION, AND THE DISCLAIMER BELOW APPEAR IN ALL COPIES MADE; AND SO LONG AS THE NAME OF THE UNIVERSITY 
OF MICHIGAN IS NOT USED IN ANY ADVERTISING OR PUBLICITY PERTAINING TO THE USE OR DISTRIBUTION OF THIS SOFTWARE WITHOUT 
SPECIFIC, WRITTEN PRIOR AUTHORIZATION.

THIS SOFTWARE IS PROVIDED AS IS, WITHOUT REPRESENTATION FROM THE UNIVERSITY OF MICHIGAN AS TO ITS FITNESS FOR ANY PURPOSE, 
AND WITHOUT WARRANTY BY THE UNIVERSITY OF MICHIGAN OF ANY KIND, EITHER EXPRESS OR IMPLIED, INCLUDING WITHOUT LIMITATION THE 
IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE. THE REGENTS OF THE UNIVERSITY OF MICHIGAN SHALL 
NOT BE LIABLE FOR ANY DAMAGES, INCLUDING SPECIAL, INDIRECT, INCIDENTAL, OR CONSEQUENTIAL DAMAGES, WITH RESPECT TO ANY CLAIM 
ARISING OUT OF OR IN CONNECTION WITH THE USE OF THE SOFTWARE, EVEN IF IT HAS BEEN OR IS HEREAFTER ADVISED OF THE POSSIBILITY 
OF SUCH DAMAGES.
*/

#include "SBJoinAncsProjAncsStackNode.h"

SBJoinAncsProjAncsStackNode::SBJoinAncsProjAncsStackNode()
{
	SimpleStackNode::SimpleStackNode();
	this->initialize();
}

SBJoinAncsProjAncsStackNode::~SBJoinAncsProjAncsStackNode()
{
}


void SBJoinAncsProjAncsStackNode::initialize()
{
	SimpleStackNode::initialize();
	buffer.Initialize();
	listOfBuffers.Initialize();
	descBuffer.Initialize();
	descList.Initialize();
	markedForOutput = false;
}

void SBJoinAncsProjAncsStackNode::NewBuffer()
{
	buffer.Initialize();
}

int SBJoinAncsProjAncsStackNode::AddToBuffer(ContainerClass *buf, char *data, int length)
{
	if (buf->EnoughSpace(length))
	{
		buf->AddData(data,length);
		return SUCCESS;
	}
	else
		return FAILURE;
}

int SBJoinAncsProjAncsStackNode::GetFromBuffer(ContainerClass *buf, int start, int length, char *data)
{
	return buf->GetData(start,length, data);
}

int SBJoinAncsProjAncsStackNode::GetFromBuffer(ContainerClass *buf, int length,char *data)
{
	return buf->GetNext(length, data);
}

ContainerClass *SBJoinAncsProjAncsStackNode::GetBuffer()
{
	return &buffer;
}


ShoreList *SBJoinAncsProjAncsStackNode::GetListOfBuffers()
{
	return &listOfBuffers;
}

ContainerClass *SBJoinAncsProjAncsStackNode::GetDescBuffer()
{
	return &descBuffer;
}

ShoreList *SBJoinAncsProjAncsStackNode::GetDescList()
{
	return &descList;
}

bool SBJoinAncsProjAncsStackNode::BufferExistsAndNotEmpty(ContainerClass *buf)
{
	return !(buf->IsEmpty());
}


bool SBJoinAncsProjAncsStackNode::EnoughSpace(ContainerClass *buf, int size)
{
	return buf->EnoughSpace(size);
}

bool SBJoinAncsProjAncsStackNode::EmptyListOfBuffers(ShoreList *list)
{
	return list->IsEmpty();
}

int SBJoinAncsProjAncsStackNode::WriteBufferToList(ContainerClass *buf, ShoreList *list, serial_t nextRecID)
{
	return list->AddToList(buf,nextRecID);
}

// called only the first time the list is used (empty)
int SBJoinAncsProjAncsStackNode::WriteBufferToList(ContainerClass *buf, ShoreList *list, serial_t fileID, lvid_t volumeID, serial_t currRecID, serial_t nextRecID)
{
	list->SetCurrRecID(currRecID);
	list->SetFileID(fileID);
	list->SetVolumeID(volumeID);

	return list->AddToList(buf,nextRecID);
}

int SBJoinAncsProjAncsStackNode::ReadFromList(ShoreList *list, ContainerClass *cont)
{
	return list->GetNext(cont);
}

void SBJoinAncsProjAncsStackNode::SetListsVolumeAndFileIDs(lvid_t volumeID,serial_t fileID)
{
	listOfBuffers.SetVolumeID(volumeID);
	listOfBuffers.SetFileID(fileID);
}

bool SBJoinAncsProjAncsStackNode::isMarkedForOutput()
{
	return this->markedForOutput;
}

void SBJoinAncsProjAncsStackNode::setMarkedForOutput(bool markedForOutput)
{
	this->markedForOutput = markedForOutput;
}


void SBJoinAncsProjAncsStackNode::mergeBuffersAndLists(ContainerClass *buffer, ShoreList *listOfBuffers, serial_t &id, serial_t fileID,
		lvid_t volumeID)
{
	if (!(listOfBuffers->IsEmpty()))
	{
		int strSize = 2* sizeof(serial_t) + sizeof(int);
		char str[100];
		int sz = 2*sizeof(serial_t);
		memcpy(str,&sz,sizeof(int));
		serial_t h = listOfBuffers->GetHead();
		serial_t t = listOfBuffers->GetTail();
		memcpy(str+sizeof(int),&h,sizeof(serial_t));
		memcpy(str+sizeof(int)+sizeof(serial_t),&t,sizeof(serial_t));
		if (this->AddToBuffer(&this->buffer,str,strSize) == FAILURE)
		{
			if (this->listOfBuffers.IsEmpty())
			{
				serial_t currRecID = id;
				id.increment(1);
				this->WriteBufferToList(&this->buffer,
					&this->listOfBuffers,fileID,volumeID,currRecID,id);
				id.increment(1);
				this->listOfBuffers.StartScan();
			}
			else
			{
				this->WriteBufferToList(&this->buffer,
					&this->listOfBuffers,id);
				id.increment(1);
			}
			this->NewBuffer();
			this->AddToBuffer(&this->buffer,str,strSize);
		}	
	}

	if (!(buffer->IsEmpty()))
	{
		if (this->AddToBuffer(&this->buffer,buffer->GetContainer(),
			buffer->GetAddCursor()) == FAILURE)
		{
			if (this->listOfBuffers.IsEmpty())
			{
				serial_t currRecID = id;
				id.increment(1);
				this->WriteBufferToList(&this->buffer,
					&this->listOfBuffers,fileID,volumeID,currRecID,id);
				id.increment(1);
				this->listOfBuffers.StartScan();
			}
			else
			{
				this->WriteBufferToList(&this->buffer,
					&this->listOfBuffers,id);
				id.increment(1);
			}
			this->NewBuffer();
			this->AddToBuffer(&this->buffer,buffer->GetContainer(),
					buffer->GetAddCursor());
		}	
	}
}

double SBJoinAncsProjAncsStackNode::getScore()
{
	return score;
}


void SBJoinAncsProjAncsStackNode::setScore(double score)
{
	this->score = score;
}

void SBJoinAncsProjAncsStackNode::prepareToCopyDelete()
{
	SimpleStackNode::prepareToCopyDelete();
	buffer.nullifyContainer();
	descBuffer.nullifyContainer();
}
