/*
COPYRIGHT  � 2000-2004 
THE REGENTS OF THE UNIVERSITY OF MICHIGAN
ALL RIGHTS RESERVED

PERMISSION IS GRANTED TO USE, COPY, CREATE DERIVATIVE WORKS AND REDISTRIBUTE THIS SOFTWARE AND SUCH DERIVATIVE WORKS FOR 
NONCOMMERCIAL EDUCATION AND RESEARCH PURPOSES, SO LONG AS NO FEE IS CHARGED, AND SO LONG AS THE COPYRIGHT NOTICE ABOVE, 
THIS GRANT OF PERMISSION, AND THE DISCLAIMER BELOW APPEAR IN ALL COPIES MADE; AND SO LONG AS THE NAME OF THE UNIVERSITY 
OF MICHIGAN IS NOT USED IN ANY ADVERTISING OR PUBLICITY PERTAINING TO THE USE OR DISTRIBUTION OF THIS SOFTWARE WITHOUT 
SPECIFIC, WRITTEN PRIOR AUTHORIZATION.

THIS SOFTWARE IS PROVIDED AS IS, WITHOUT REPRESENTATION FROM THE UNIVERSITY OF MICHIGAN AS TO ITS FITNESS FOR ANY PURPOSE, 
AND WITHOUT WARRANTY BY THE UNIVERSITY OF MICHIGAN OF ANY KIND, EITHER EXPRESS OR IMPLIED, INCLUDING WITHOUT LIMITATION THE 
IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE. THE REGENTS OF THE UNIVERSITY OF MICHIGAN SHALL 
NOT BE LIABLE FOR ANY DAMAGES, INCLUDING SPECIAL, INDIRECT, INCIDENTAL, OR CONSEQUENTIAL DAMAGES, WITH RESPECT TO ANY CLAIM 
ARISING OUT OF OR IN CONNECTION WITH THE USE OF THE SOFTWARE, EVEN IF IT HAS BEEN OR IS HEREAFTER ADVISED OF THE POSSIBILITY 
OF SUCH DAMAGES.
*/

#include "../../QueryEvaluationTree/QueryEvaluationTreeNode.h"

#ifndef QueryEvaluationTreeStructuralJoinNode_H
#define QueryEvaluationTreeStructuralJoinNode_H
#define JOIN_ALGORITHM_STACK_ANCS		1
#define JOIN_ALGORITHM_STACK_DESC		2
#define JOIN_ALGORITHM_STACK_NEGATIVE	3
#define JOIN_ALGORITHM_STACK_OUTERANCS	4
#define JOIN_ALGORITHM_STACK_OUTERDESC	5

#define JOIN_NODE_RELATION_CHILD		1
#define JOIN_NODE_RELATION_DESCENDANT   2

#define JOIN_PROJECTION_ANCESTOR			0
#define JOIN_PROJECTION_DESCENDANT			1
#define JOIN_PROJECTION_NONE				2
#define JOIN_PROJECTION_BOTH				3

class QueryEvaluationTreeStructuralJoinNode: public QueryEvaluationTreeNode
{
public: 
	void processQueryEvalNode(EvaluatorClass* evaluator, IteratorClass*& curr);
	char getIdentifier();
	QueryEvaluationTreeStructuralJoinNode();
	
	QueryEvaluationTreeStructuralJoinNode(QueryEvaluationTreeNode* ancestor,
		QueryEvaluationTreeNode* descendant,
		int relationship,
		NREType ancsNRE,
		NREType descNRE,
		int algorithmChoice,
		int projectionChoice);

	~QueryEvaluationTreeStructuralJoinNode();

	int			getRelationship();
	NREType			getAncsNRE();
	NREType			getDescNRE();
	QueryEvaluationTreeNode*	getAncestor();
	QueryEvaluationTreeNode*	getDescendant();
	int			getAlgorithmChoice();
	bool		getOrderingSemantics();
	NREType			getLeftNRE();
	NREType			getRightNRE();
	int			getEstimatedDepth();
	int			getProjectWhich();
	bool		getNest();

	void		setRelationship(int relation);
	void		setAncsNRE(NREType ancsNRE);
	void		setDescNRE(NREType descNRE);
	void		setAncestor(QueryEvaluationTreeNode* ancestor);
	void		setDescendant(QueryEvaluationTreeNode* descendant);
	void		setAlgorithmChoice(int algorithm);
	void		setOrderingSemantics(bool ordering);
	void		setLeftNRE(NREType leftNRE);
	void		setRightNRE(NREType rightNRE);
	void		setEstimatedDepth(int depth);
	void		setProjectWhich(int projectWhich);
	void		setNest(bool nest);

	void		printQueryEvaluationTreeNode(bool recursive, int depth);

	char*		toString();
	void deleteStructures();

private:
	// the following are used for evaluation to carry out the join
	int relationship;
	NREType ancsNRE;
	NREType descNRE;
	QueryEvaluationTreeNode* ancestor;
	QueryEvaluationTreeNode* descendant;
	int algorithmChoice;
	bool orderingSemantics;
	NREType leftNRE;
	NREType rightNRE;
	int estimatedDepth;
	int projectionChoice;
	bool nest;

};

#endif
