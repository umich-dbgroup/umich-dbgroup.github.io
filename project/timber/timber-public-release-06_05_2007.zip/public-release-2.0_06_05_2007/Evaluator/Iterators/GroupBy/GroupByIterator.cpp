/*
COPYRIGHT  � 2000-2004 
THE REGENTS OF THE UNIVERSITY OF MICHIGAN
ALL RIGHTS RESERVED

PERMISSION IS GRANTED TO USE, COPY, CREATE DERIVATIVE WORKS AND REDISTRIBUTE THIS SOFTWARE AND SUCH DERIVATIVE WORKS FOR 
NONCOMMERCIAL EDUCATION AND RESEARCH PURPOSES, SO LONG AS NO FEE IS CHARGED, AND SO LONG AS THE COPYRIGHT NOTICE ABOVE, 
THIS GRANT OF PERMISSION, AND THE DISCLAIMER BELOW APPEAR IN ALL COPIES MADE; AND SO LONG AS THE NAME OF THE UNIVERSITY 
OF MICHIGAN IS NOT USED IN ANY ADVERTISING OR PUBLICITY PERTAINING TO THE USE OR DISTRIBUTION OF THIS SOFTWARE WITHOUT 
SPECIFIC, WRITTEN PRIOR AUTHORIZATION.

THIS SOFTWARE IS PROVIDED AS IS, WITHOUT REPRESENTATION FROM THE UNIVERSITY OF MICHIGAN AS TO ITS FITNESS FOR ANY PURPOSE, 
AND WITHOUT WARRANTY BY THE UNIVERSITY OF MICHIGAN OF ANY KIND, EITHER EXPRESS OR IMPLIED, INCLUDING WITHOUT LIMITATION THE 
IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE. THE REGENTS OF THE UNIVERSITY OF MICHIGAN SHALL 
NOT BE LIABLE FOR ANY DAMAGES, INCLUDING SPECIAL, INDIRECT, INCIDENTAL, OR CONSEQUENTIAL DAMAGES, WITH RESPECT TO ANY CLAIM 
ARISING OUT OF OR IN CONNECTION WITH THE USE OF THE SOFTWARE, EVEN IF IT HAS BEEN OR IS HEREAFTER ADVISED OF THE POSSIBILITY 
OF SUCH DAMAGES.
*/

#include "GroupByIterator.h"
#include <float.h>
GroupByIterator::GroupByIterator(IteratorClass *input, int numExpected, int groupByWhat, NREType groupbyNRE, char *groupbyAttrName,
		 bool keepTrees, int length, int *operations, 
		int *operationOnWhat, char **attrName, NREType *nre,NREType rootNRE, NREType valueNRE, NREType *operationNRE,
		DataMng *dataMng,
		bool sort)
{
	
	this->length = length;
	this->groupbyAttrName = groupbyAttrName;
	this->groupbyNRE = groupbyNRE;
	this->operationOnWhat = operationOnWhat;
	this->operations = operations;
	this->attrName = attrName;
	this->groupByWhat = groupByWhat;
	this->nre = nre;
	this->rootNRE = rootNRE;
	this->valueNRE = valueNRE;
	this->operationNRE = operationNRE;
	this->sort = sort;
	this->dataMng = dataMng;
	if (sort)
	{
		int *sortOrder = new int[1];
		sortOrder[0] = ASCENDING;
		NREType *sortNRE = new NREType[1];
		sortNRE[0] = groupbyNRE;
		int *whereEmptyGoes = new int[1];
		whereEmptyGoes[0] = EMPTY_AT_BEGINNING;
		if (groupByWhat == GROUPBY_STARTKEY)
			this->input = new SortIterator(input,numExpected,1, sortNRE, sortOrder,dataMng,whereEmptyGoes);
		else
		{
			int *sortByWhat = new int[1];
			char **sortAttrName = NULL;
			if (groupByWhat == GROUPBY_TEXT_NUM)
				sortByWhat[0] = SORTBY_TEXT_NUM;
			else if (groupByWhat == GROUPBY_TEXT_STR)
				sortByWhat[0] = SORTBY_TEXT_STR;
			else if (groupByWhat == GROUPBY_ATTRIBUTE_NUM)
			{
				sortByWhat[0] = SORTBY_ATTRIBUTE_NUM;
				sortAttrName = new char *[1];
				sortAttrName[0] = new char[strlen(groupbyAttrName)+1];
				strcpy(sortAttrName[0],groupbyAttrName);
			}
			else if (groupByWhat == GROUPBY_ATTRIBUTE_STR)
			{
				sortByWhat[0] = SORTBY_ATTRIBUTE_STR;
				sortAttrName = new char *[1];
				sortAttrName[0] = new char[strlen(groupbyAttrName)+1];
				strcpy(sortAttrName[0],groupbyAttrName);
			}
			this->input = new ValueSortIterator(input,numExpected,1,sortByWhat,sortNRE,sortAttrName,sortOrder,dataMng,whereEmptyGoes);
		}
	}
	else
		this->input = input;
	this->input->next(inTuple);
	if (inTuple)
		inTuple->switchToComplex(dataMng);
	
	this->keepTrees = keepTrees;

	prevValueStr= NULL;
	prevValueStrSize = 0;
	prevValueNum = NULL;
	txt = NULL;
	txtSize =0;

	counter = 0;
	
	resultBuffer = new WitnessTree(LIST_NODE_WITH_DATA,dataMng);
	if (length > 0)
	{
		valueNum = new double[this->length];
		floatFound = new bool[this->length];
		memset(floatFound,0,length*sizeof(bool));
		counter = new int[this->length];
		for (int i=0; i<this->length; i++)
		{
			counter[i] = 0;
			switch (operations[i])
			{
			case OP_AVG:
			case OP_SUM: 
			case OP_COUNT: valueNum[i] = 0;  break;
			case OP_MIN: valueNum[i] = DBL_MAX; break;
			case OP_MAX: valueNum[i] = DBL_MIN;  break;
			default:
					globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"Evaluator",__FILE__,"Undefined operation passed to iterator.");
					inTuple = NULL;
					return;
			}
		}
	}
	else
	{
		valueNum = NULL;
		floatFound = NULL;
		counter = 0;
	}
}

GroupByIterator::~GroupByIterator()
{
	delete resultBuffer;
	
	if (prevValueNum)
		delete prevValueNum;

	if (txt)
		delete [] txt;

	if (prevValueStr)
		delete [] prevValueStr;
	
	delete input;
	if (valueNum) delete [] valueNum;
	if (operations)
		delete [] operations;
	if (operationOnWhat)
		delete [] operationOnWhat;
	if (nre)
		delete [] nre;
	if (attrName)
	{
		for (int i=0; i<length; i++)
			if (attrName[i])
				delete [] attrName[i];
		delete [] attrName;
	}
	if (this->groupbyAttrName) delete [] groupbyAttrName;
	if (floatFound) delete [] floatFound;
	if (counter)
		delete [] counter;
}

void GroupByIterator::next(WitnessTree *&node)
{

	//once we run out of input, we are done
	if (!inTuple)
	{
		node = NULL;
		return;
	}
#ifdef EVAL_TIME_OUT
	clock_t currTime = clock();
	double queryDuration = (double)(currTime - gQueryStartTime) / CLOCKS_PER_SEC;
	if (queryDuration >= gTimeOutAfter)
	{
		globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"Evaluator",__FILE__,"Query Timed Out.");
		node = NULL;
		return;
	}
#endif
	if (groupByWhat == GROUPBY_ATTRIBUTE_STR || groupByWhat == GROUPBY_TEXT_STR)
	{
		//if we are doing string grouping and we don't have a value for prevValueStr (first time in),
		//get the current string
		if (prevValueStr == NULL)
		{
			if (getGroupByText(true) == FAILURE)
			{
				node = NULL;
				return;
			}
		}
	}
	else
	{
		//if we are doing num grouping and we don't have a value for prevValueNum (first time in),
		//get the current number
		if (prevValueNum == NULL)
		{
			prevValueNum = new KeyType;
			if (getGroupByText(true) == FAILURE)
			{
				node = NULL;
				return;
			}
		}
	}
	short locLev =0;
	resultBuffer->initialize();

	//write teh bogus root to resultBuffer
	ComplexListNode dummy;
	dummy.SetDummy(true);
	dummy.SetDummyName("<root>");
	dummy.SetLocalLevel(locLev);
	dummy.setNRE(rootNRE);
	resultBuffer->appendList(&dummy,dataMng,1);
	locLev++;
	
	//the groupBy value is in txt, write it resultBuffer
	if (groupByWhat == GROUPBY_ATTRIBUTE_STR || groupByWhat == GROUPBY_TEXT_STR)
		dummy.SetDummyName(txt);
	else
	{
		char tmp[50];
		sprintf(tmp,"%5.3lf",num.toDouble());
		dummy.SetDummyName(tmp);
	}

	dummy.SetLocalLevel(locLev);
	dummy.setNRE(valueNRE);
	resultBuffer->appendList(&dummy,dataMng,1);

	if (operations)
		//reserving nodes in the result for operations.
		resultBuffer->SetUsed(resultBuffer->length()+(2*length));

	//compare is true if the prev value is equal to current value --> the current inTuple belongs to
	//this group --> no output yet
	bool compare = (groupByWhat == GROUPBY_ATTRIBUTE_STR || groupByWhat == GROUPBY_TEXT_STR ? 
		strcmp(prevValueStr,txt) == 0 : *prevValueNum == num);		
	while (compare)
	{
		

		//if we have operations to be performed on the group
		if (operations)
		{
			float Xnum;

			//for each of the operations, calc the appropriate values
			for (int i=0; i<length; i++)
			{
				
				if (operations[i] == OP_COUNT)
				{
					valueNum[i]++;
					continue;
				}

				int res;
				//get the number value and put it in Xnum
				if (operationOnWhat[i] == ON_ATTRIBUTE_NUM)
					res = getAttributeValueNum(i,Xnum);
				else if (operationOnWhat[i] == ON_ATTR_LOCAL_NUM)
					res = getLocalAttrValueNum(i,Xnum);
				else if (operationOnWhat[i] == ON_TEXT_NUM)
					res = getTextValueNum(i,Xnum);
				else if (operationOnWhat[i] == ON_TEXT_LOCAL_NUM)
					res = getLocalTextValueNum(i,Xnum);
				else if (operationOnWhat[i] == ON_FANOUT_ACTUAL)
					res = getFanOutValue(i,Xnum);
				else if (operationOnWhat[i] == ON_FANOUT_LOCAL)
					res = getLocalFanOutValue(i,Xnum);
				else if (operationOnWhat[i] == ON_DEPTH_ACTUAL)
					res = getDepthValue(i,Xnum);
				else if (operationOnWhat[i] == ON_DEPTH_LOCAL)
					res = getLocalDepthValue(i,Xnum);
				else if (operationOnWhat[i] == ON_VALUE_NUM)
					res = getValueNum(i,Xnum);
				else
				{
					globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"Evaluator",__FILE__,"Undefined operation passed to iterator.");
					node = NULL;
					return;
				}

				if (res == SUCCESS)
				{
					counter[i]++;
					//if we are summing or averaging, we sum only (the avg will be calculated later)
					switch (operations[i])
					{
					case OP_SUM: 
					case OP_AVG: valueNum[i] += Xnum; 
						break;
					case OP_MIN: if (Xnum < valueNum[i]) valueNum[i] = Xnum;
						break;
					case OP_MAX: if (Xnum > valueNum[i]) valueNum[i] = Xnum;
						break;
					default:
						globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"Evaluator",__FILE__,"Undefined operation passed to iterator.");
						node = NULL;
						return;
					}
				}
				else if (globalErrorInfo.doWeHaveAProblem())
				{
					node = NULL;
					return;
				}
			}
		}

		//if we are keeping the grouped by trees, then write them to resultBuffer.
		if (keepTrees)
		{
			if (inTuple->isSimple())
				resultBuffer->appendList((ListNode *)(inTuple->getBuffer()),inTuple->length());
			else
				resultBuffer->appendList((ComplexListNode *)(inTuple->getBuffer()),dataMng,inTuple->length());
		}

		input->next(inTuple);
#ifdef EVAL_TIME_OUT
	clock_t currTime = clock();
	double queryDuration = (double)(currTime - gQueryStartTime) / CLOCKS_PER_SEC;
	if (queryDuration >= gTimeOutAfter)
	{
		globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"Evaluator",__FILE__,"Query Timed Out.");
		node = NULL;
		return;
	}
#endif
		if (!inTuple)
		{
			if (globalErrorInfo.doWeHaveAProblem())
			{
				node = NULL;
				return;
			}
			//if we are done, then write the operations to resultBuffer and exit.
			if (resultBuffer->length() > 0)
			{
				if (operations)
					writeOperationsToResult();
				node = resultBuffer;
				return;
			}
			node = NULL;
			return;
		}
		else
			inTuple->switchToComplex(dataMng);
		if (getGroupByText(false) == FAILURE)
		{
			node = NULL;
			return;
		}
		compare = (groupByWhat == GROUPBY_ATTRIBUTE_STR || groupByWhat == GROUPBY_TEXT_STR ? 
					strcmp(prevValueStr,txt) == 0 : *prevValueNum == num);
	}

	if (operations)
		writeOperationsToResult();
	node = resultBuffer;
	if (groupByWhat == GROUPBY_ATTRIBUTE_STR || groupByWhat == GROUPBY_TEXT_STR )
	{
		increaseTextSize(prevValueStr,prevValueStrSize,strlen(txt));
		strcpy(prevValueStr,txt);
	}
	else
		*prevValueNum = num;
	return;
}

int GroupByIterator::getTextValueNum(int which, float &num)
{
	//this method gets a number that is in a text node

	int actualIndex = inTuple->getIndexOfNRE(nre[which]);//inTuple->getActualIndex(index[which]);
	if (actualIndex == FAILURE)
		return FAILURE;

	//getting curr file id
	FileIDType fileid;
	if (inTuple->isSimple())
		fileid = EvaluatorClass::getFileID(((ListNode *)inTuple->getNodeByIndex(actualIndex))->getFileIndex());
	else
		fileid = EvaluatorClass::getFileID(((ComplexListNode *)inTuple->getNodeByIndex(actualIndex))->getFileIndex());
	if (fileid == -1)
	{
		globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"Evaluator",__FILE__,"File is unloaded in Timber.");
		return FAILURE;
	}

	//getting the text node from DB
	char *txt = EvaluatorClass::returnText(inTuple,actualIndex,dataMng,fileid);
	if (txt == NULL)
		return FAILURE;

	if (strchr(txt,'.') != NULL)
		floatFound[which] = true;
	num =  (float) atof(txt);
	delete [] txt;
	return SUCCESS;
}



int GroupByIterator::getLocalTextValueNum(int which, float &num)
{
	int index = inTuple->getIndexOfNRE(nre[which]);//inTuple->getActualIndex(index[which]);
	if (index == FAILURE)
		return FAILURE;
	int childIndex = inTuple->GetLocalChild(index);
	char *txt = NULL;
	while (childIndex != -1)
	{
		if (((ComplexListNode *)inTuple->getNodeByIndex(childIndex))->IsDummy())
		{
			if (strchr(((ComplexListNode *)inTuple->getNodeByIndex(childIndex))->GetDummyName(),'<') == NULL &&
				strchr(((ComplexListNode *)inTuple->getNodeByIndex(childIndex))->GetDummyName(),'@') == NULL)
			{
				if (((ComplexListNode *)inTuple->getNodeByIndex(childIndex))->GetDummyName()[0] != '\0')
				{
					if (!txt)
					{
						txt = new char[strlen(((ComplexListNode *)inTuple->getNodeByIndex(childIndex))->GetDummyName())+1];
						txt[0] = '\0';
					}
					else
					{
						char *tmp = new char[strlen(txt)+strlen(((ComplexListNode *)inTuple->getNodeByIndex(childIndex))->GetDummyName())+1];
						strcpy(tmp,txt);
						delete [] txt;
						txt = tmp;
					}
					strcat(txt,((ComplexListNode *)inTuple->getNodeByIndex(childIndex))->GetDummyName());
					//break;
				}
			}
		}
		else
		{
			if (((ComplexListNode *)inTuple->getNodeByIndex(childIndex))->GetData()->getFlag() == TEXT_NODE)
			{
				if (!txt)
				{
					txt = new char[strlen(((DM_CharNode *)((ComplexListNode *)(inTuple->getNodeByIndex(childIndex)))->GetData())->getCharValue())+1];
					txt[0] = '\0';
				}
				else
				{
					char *tmp = new char[strlen(txt)+strlen(((DM_CharNode *)((ComplexListNode *)(inTuple->getNodeByIndex(childIndex)))->GetData())->getCharValue())+1];
					strcpy(tmp,txt);
					delete [] txt;
					txt = tmp;
				}
				strcat(txt,((DM_CharNode *)((ComplexListNode *)(inTuple->getNodeByIndex(childIndex)))->GetData())->getCharValue());
				//break;
				//txt = ((DM_CharNode *)((ComplexListNode *)(inTuple->getNodeByIndex(childIndex)))->GetData())->getCharValue();
			//	break;
			}

		}
		childIndex = inTuple->GetNextSibling(childIndex);
	}
	if (txt == NULL)
		return FAILURE;
	if (strchr(txt,'.') != NULL)
		floatFound[which] = true;
	num = (float) atof(txt);
	delete [] txt;
	return SUCCESS;	
}


int GroupByIterator::getLocalAttrValueNum(int which, float &num)
{
	int index = inTuple->getIndexOfNRE(nre[which]);//inTuple->getActualIndex(index[which]);
	if (index == FAILURE)
		return FAILURE;
	int childIndex = inTuple->GetLocalChild(index);
	char *txt = NULL;
	if (childIndex == -1)
		return FAILURE;

	if (((ComplexListNode *)inTuple->getNodeByIndex(childIndex))->IsDummy())
	{
		if (strchr(((ComplexListNode *)inTuple->getNodeByIndex(childIndex))->GetDummyName(),'@') != NULL)
		{
			char *tmp = strchr(((ComplexListNode *)inTuple->getNodeByIndex(childIndex))->GetDummyName(),'=');
			tmp++;
			txt = tmp;
		}
	}
	else
	{
		if (((ComplexListNode *)inTuple->getNodeByIndex(childIndex))->GetData()->getFlag() == ATTRIBUTE_NODE)
		{
			//getting the attribute value
			Value *val = ((DM_AttributeNode *)(((ComplexListNode *) inTuple->getNodeByIndex(childIndex))->GetData()))->getAttr(attrName[which]);
			if (!val)
				return FAILURE;
			txt = val->getStrValue();
		}
	}
	if (txt == NULL)
		return FAILURE;
	if (strchr(txt,'.') != NULL)
		floatFound[which] = true;
	num = (float) atof(txt);
	return SUCCESS;
}

int GroupByIterator::getDepthValue(int which, float &num)
{
	//this method gets a number that is the depth of a node
	
	int actualIndex = inTuple->getIndexOfNRE(nre[which]);//inTuple->getActualIndex(index[which]);
	if (actualIndex == FAILURE)
		return FAILURE;

	//getting current fileID
	FileIDType fileid;
	if (inTuple->isSimple())
		fileid = EvaluatorClass::getFileID(((ListNode *)inTuple->getNodeByIndex(actualIndex))->getFileIndex());
	else
		fileid = EvaluatorClass::getFileID(((ComplexListNode *)inTuple->getNodeByIndex(actualIndex))->getFileIndex());
	if (fileid == -1)
	{
		globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"Evaluator",__FILE__,"File is unloaded in Timber.");
		return FAILURE;
	}

	//gettting the depth of the subtree rooted at node at index "which"
	num = (float) EvaluatorClass::GetSubtreeDepth(inTuple,actualIndex,dataMng,fileid);

	return SUCCESS;
}

int GroupByIterator::getLocalDepthValue(int which, float &num)
{
	//this method gets a number that is the depth of a node in the witness tree
	
	int actualIndex = inTuple->getIndexOfNRE(nre[which]);// inTuple->getActualIndex(index[which]);
	if (actualIndex == FAILURE)
		return FAILURE;
	num = (float)inTuple->getSubTreeDepth(actualIndex);
	return SUCCESS;
}


int GroupByIterator::getFanOutValue(int which, float &num)
{
	//this method gets a number that is the fan out of a node in the DB
	
	int actualIndex = inTuple->getIndexOfNRE(nre[which]);//inTuple->getActualIndex(index[which]);
	if (actualIndex == FAILURE)
		return FAILURE;

	//getting current file id
	FileIDType fileid;
	if (inTuple->isSimple())
		fileid = EvaluatorClass::getFileID(((ListNode *)inTuple->getNodeByIndex(actualIndex))->getFileIndex());
	else
		fileid = EvaluatorClass::getFileID(((ComplexListNode *)inTuple->getNodeByIndex(actualIndex))->getFileIndex());
	if (fileid == -1)
	{
		globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"Evaluator",__FILE__,"File is unloaded in Timber.");
		return FAILURE;
	}

	//gettting the actual number of children in DB of node with index "which"
	num = (float)EvaluatorClass::GetNumChildren(inTuple,actualIndex,dataMng,fileid);

	return SUCCESS;
}

int GroupByIterator::getLocalFanOutValue(int which, float &num)
{
	//this method gets a number that is the fan out of a node in a witness tree
	
	int actualIndex = inTuple->getIndexOfNRE(nre[which]);//inTuple->getActualIndex(index[which]);
	if (actualIndex == FAILURE)
		return FAILURE;
	num = (float)inTuple->getNumChildren(actualIndex);
	return SUCCESS;
}

int GroupByIterator::getAttributeValueNum(int which, float &num)
{
	//this method gets a number that is in an attribute node
	
	int actualIndex = inTuple->getIndexOfNRE(nre[which]);//inTuple->getActualIndex(index[which]);
	if (actualIndex == FAILURE)
		return FAILURE;

	//getting the current file id
	FileIDType fileid;
	if (inTuple->isSimple())
		fileid = EvaluatorClass::getFileID(((ListNode *)inTuple->getNodeByIndex(actualIndex))->getFileIndex());
	else
		fileid = EvaluatorClass::getFileID(((ComplexListNode *)inTuple->getNodeByIndex(actualIndex))->getFileIndex());
	if (fileid == -1)
	{
		globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"Evaluator",__FILE__,"File is unloaded in Timber.");
		return FAILURE;
	}

	//getting the attribute node from the DB
	int res = EvaluatorClass::GetAttributes(inTuple,actualIndex,dataMng,fileid);

	if (res == FAILURE)
		return FAILURE;

	//getting the attribute value
	Value *val = ((DM_AttributeNode *)(((ComplexListNode *) inTuple->getNodeByIndex(actualIndex+1))->GetData()))->getAttr(attrName[which]);
	if (!val)
		return FAILURE;
	char *txt = val->getStrValue();
	if (txt == NULL)
		return FAILURE;
	if (strchr(txt,'.') != NULL)
		floatFound[which] = true;
	num = (float) atof(txt);
	return  SUCCESS;
}

int GroupByIterator::getValueNum(int which, float &num)
{
	int actualIndex = inTuple->getIndexOfNRE(nre[which]);//inTuple->getActualIndex(index[which]);
	if (actualIndex == FAILURE)
		return FAILURE;

	ComplexListNode *n = (ComplexListNode *)inTuple->getNodeByIndex(actualIndex);
	if (!n)
		return FAILURE;
	char *txt = this->getStrOfNode(n,this->attrName[which]);
	if (txt == NULL)
		return FAILURE;

	if (strchr(txt,'.') != NULL)
		floatFound[which] = true;
	num = (float) atof(txt);
	return  SUCCESS;
}


char *GroupByIterator::getStrOfNode(ComplexListNode *node, char *attrName)
{
	DM_DataNode *n = node->GetData();
	if (!n)
		return NULL;
	switch (n->getFlag())
	{
	case ELEMENT_NODE:
		//if it is an element node, return its tag
		return (dataMng->getPhysicalDataMng()->getXMLNameTable()->getNameByCode(n->getTag()));
	case DOCUMENT_NODE:
		//if document node, return the xml file name
		return (((DM_DocumentNode *)n)->getXMLFileName());
	case ATTRIBUTE_NODE:
		//if attribute node, return the value of attribute "attrName"
		if (((DM_AttributeNode *)n)->getAttr(attrName) != NULL)
			return ((DM_AttributeNode *)n)->getAttr(attrName)->getStrValue();
		else
			return NULL;
	case TEXT_NODE:
		//if text node, return the text value
		return (((DM_CharNode *)n)->getCharValue());
	}
	return NULL;
}

int GroupByIterator::getGroupByText(bool copyToPrevValue)
{
	int actualIndex = inTuple->getIndexOfNRE(groupbyNRE);
	if (actualIndex == -1)
	{
		globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"Evaluator",__FILE__,"Could not find node with groupBy NRE.");
		return FAILURE;
	}

	if (groupByWhat == GROUPBY_STARTKEY)
	{
		num = inTuple->isSimple()? ((ListNode *)inTuple->getNodeByIndex(actualIndex))->GetStartPos():
									((ComplexListNode *)inTuple->getNodeByIndex(actualIndex))->GetStartPos();
		if (copyToPrevValue)
			*prevValueNum = num;
		return SUCCESS;
	}
	inTuple->switchToComplex(dataMng);
	if (groupByWhat == GROUPBY_VALUE_NUM || groupByWhat == GROUPBY_VALUE_STR)
	{
		ComplexListNode *n = (ComplexListNode *)inTuple->getNodeByIndex(actualIndex);
		if (!n)
		{
			globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"Evaluator",__FILE__,"Could not find node with index returned from submitting groupBy NRE.");
			return FAILURE;
		}
		char *tmp = this->getStrOfNode(n,groupbyAttrName);
		if (!tmp)
		{
			globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"Evaluator",__FILE__,"Could not get groupBy value.");
			return FAILURE;
		}
		if (groupByWhat == GROUPBY_VALUE_STR)
		{
			increaseTextSize(txt,txtSize,strlen(tmp));
			strcpy(txt,tmp);
			if (copyToPrevValue)
			{
				increaseTextSize(prevValueStr,prevValueStrSize,strlen(txt));
				strcpy(prevValueStr,txt);
			}
		}
		else
		{
			//if we are doing number grouping, copy number to num
			num = atof(tmp);
			if (copyToPrevValue)
				*prevValueNum = num;
		}
		return SUCCESS;
	}

	FileIDType fileid;
	if (inTuple->isSimple())
		fileid = EvaluatorClass::getFileID(((ListNode *)inTuple->getNodeByIndex(actualIndex))->getFileIndex());
	else
		fileid = EvaluatorClass::getFileID(((ComplexListNode *)inTuple->getNodeByIndex(actualIndex))->getFileIndex());
	if (fileid == -1)
	{
		globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"Evaluator",__FILE__,"File is unloaded in Timber.");
		return FAILURE;
	}
	//this method puts the grouped by value in teh var txt
	if (groupByWhat == GROUPBY_TEXT_NUM || groupByWhat == GROUPBY_TEXT_STR)
	{
	//get the actual text node from DB
		int res = EvaluatorClass::GetText(inTuple,actualIndex,dataMng,fileid);
		if (res == FAILURE || res == 0)
		{
			globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"Evaluator",__FILE__,"Could not get groupBy text.");
			return FAILURE;
		}

		//tmp will hold the text value
		char *tmp = ((DM_CharNode *)((ComplexListNode *)(inTuple->getNodeByIndex(res)))->GetData())->getCharValue();

		if (tmp == NULL)
		{
			globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"Evaluator",__FILE__,"GroupBy text value is NULL.");
			return FAILURE;
		}
		if (groupByWhat == GROUPBY_TEXT_STR)
		{
			//if we are doing string grouping, copy the char value to txt
			increaseTextSize(txt,txtSize,strlen(tmp));
			strcpy(txt,tmp);
			if (copyToPrevValue)
			{
				increaseTextSize(prevValueStr,prevValueStrSize,strlen(txt));
				strcpy(prevValueStr,txt);
			}
		}
		else
		{
			//if we are doing number grouping, copy number to num
			num = atof(tmp);
			if (copyToPrevValue)
				*prevValueNum = num;
		}
	} 
	else if (groupByWhat == GROUPBY_ATTRIBUTE_NUM || groupByWhat == GROUPBY_ATTRIBUTE_STR)
	{
		//get attr node from DB
		int res = EvaluatorClass::GetAttributes(inTuple,actualIndex,dataMng,fileid);
		if (res == FAILURE)
		{
			globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"Evaluator",__FILE__,"Could not get group by attributes.");
			return FAILURE;
		}

		//get the value from the attr node... attr name is in strValGroup
		Value *val = ((DM_AttributeNode *)((ComplexListNode *)inTuple->getNodeByIndex(actualIndex+1))->GetData())->getAttr(groupbyAttrName);
		if (!val)
		{
			globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"Evaluator",__FILE__,"Could not get groupBy attribute value.");
			return FAILURE;
		}
		if (val->getStrValue() == NULL)
		{
			globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"Evaluator",__FILE__,"GroupBy attribute value is NULL.");
			return FAILURE;
		}
		if (groupByWhat == GROUPBY_ATTRIBUTE_STR)
		{
			//if we are doing string grouping, then write it to txt
			increaseTextSize(txt,txtSize,strlen(val->getStrValue()));
			strcpy(txt,val->getStrValue());
			if (copyToPrevValue)
			{
				increaseTextSize(prevValueStr,prevValueStrSize,strlen(txt));
				strcpy(prevValueStr,txt);
			}
		}
		else
		{
			//if we are doing number grouping, then write it to num
			num = atof(val->getStrValue());
			if (copyToPrevValue)
				*prevValueNum = num;
		}
	}
	
	return SUCCESS;
}

void GroupByIterator::writeOperationsToResult()
{
	// in this method, we are writing the operations performed on grouped trees to the resultBuffer.
	//rememeber, we reserved some nodes 
	for (int i=0; i<length; i++)
	{
		ComplexListNode *oprName = (ComplexListNode *)resultBuffer->getNodeByIndex(2 + i*2); 
		ComplexListNode *oprValue = (ComplexListNode *)resultBuffer->getNodeByIndex(2 + i*2 + 1);
		oprName->SetDummy(true);
		oprName->SetLocalLevel(1);
		oprName->setNRE(DEFAULT_NODES_NRE);
		resultBuffer->getNRETable()->insertIndex(DEFAULT_NODES_NRE,2 + i*2);
		oprValue->SetDummy(true);
		oprValue->SetLocalLevel(2);
		oprValue->setNRE(this->operationNRE[i]);
		resultBuffer->getNRETable()->insertIndex(this->operationNRE[i],2 + i*2 +1);
				
		char tmp[40];
		switch (operations[i])
		{
		case OP_SUM: 
			oprName->SetDummyName("<sum>");
			if (counter[i] == 0)
				tmp[0] = '\0';
			else if (floatFound[i])
				this->formatFloat(valueNum[i],tmp);
			else
				sprintf(tmp,"%d",(int)floor(valueNum[i]));
			oprValue->SetDummyName(tmp);
			valueNum[i] = 0; 
			break;
		case OP_COUNT: 		
			oprName->SetDummyName("<count>");
			sprintf(tmp,"%d",(int)valueNum[i]);
			oprValue->SetDummyName(tmp);
			valueNum[i] = 0;  
			break;
		case OP_AVG: 
			oprName->SetDummyName("<avg>");
			if (counter[i] == 0)
				tmp[0] = '\0';
			else if (floatFound[i])
				this->formatFloat((double)(valueNum[i]/counter[i]),tmp);
			else
				sprintf(tmp,"%d",(int)floor(valueNum[i]/counter[i]));
			oprValue->SetDummyName(tmp);
			valueNum[i] = 0; 
			break;
		case OP_MIN: 
			oprName->SetDummyName("<min>");
			if (counter[i] == 0)
				tmp[0] = '\0';
			else if (floatFound[i])
				this->formatFloat(valueNum[i],tmp);
			else
				sprintf(tmp,"%d",(int)floor(valueNum[i]));
			oprValue->SetDummyName(tmp);
			valueNum[i] = DBL_MAX; 
			break;
		case OP_MAX: 
			oprName->SetDummyName("<max>");
			if (counter[i] == 0)
				tmp[0] = '\0';
			else if (floatFound[i])
				this->formatFloat(valueNum[i],tmp);
			else
				sprintf(tmp,"%d",(int)floor(valueNum[i]));
			oprValue->SetDummyName(tmp);
			valueNum[i] = DBL_MIN; 
			break;
		}
		counter[i] = 0;
	}
}

void GroupByIterator::increaseTextSize(char *&text,int &textSize,int newSize)
{
	if (newSize > textSize)
	{
		textSize = newSize;
		if (text)
			delete [] text;
		text = new char[textSize+1];
	}
}



void GroupByIterator::formatFloat(double num, char *str)
{
	sprintf(str,"%.13f",num);
	for (int j=strlen(str)-1; j>0; j--)
	{
		if (str[j] != '0')
			break;
		if (str[j-1] == '.')
		{
			str[j] = '0';
			str[j+1] = '\0';
			break;
		}
		if (str[j] == '0')
			str[j] = '\0';
	}
}
