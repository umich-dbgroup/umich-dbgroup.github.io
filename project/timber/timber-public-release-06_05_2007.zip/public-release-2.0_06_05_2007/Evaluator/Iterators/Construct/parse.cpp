
#include "parse.hpp"

char QueryEvaluationTreeConstructNode::getIdentifier(void) { return 's'; }

char
ConstructPlanParser::getIteratorIdentifier(void) { return 's'; }

void 
ConstructPlanParser::getQueryEvalNode(EvaluatorClass* evaluator, char* line, void* queryInput, QueryEvaluationTreeNode*& curr)
	    {
		char *token = strtok(line+2,",");
		if (token == NULL)
		{
		    globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"Evaluator",__FILE__,"Expecting number of construct specifications in Construct Line.");
		    curr=NULL; return;
		}
		int num = atoi(token);
		ConstructSpecification *spec;
		if (num > 0)
		    spec = new ConstructSpecification(num);
		else
		{
		    spec = NULL;
		    globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"Evaluator",__FILE__,"You should have at least one construct specification.");
		    curr=NULL; return;
		}

		for (int i=0; i<num; i++)
		{
		    SingleConstructSpec ss;
		    token = strtok(NULL,",");
		    if (token == NULL)
		    {
			globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"Evaluator",__FILE__,"Expecting level of construct spec in Construct Line.");
			delete spec;
			curr=NULL; return;
		    }
		    int level = atoi(token);
		    if (level < 0)
		    {
			globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"Evaluator",__FILE__,"Level should be positive or 0 in Construct Line.");
			delete spec;
			curr=NULL; return;
		    }
		    ss.setLevel(level);
		    //type
		    token = strtok(NULL,",");
		    if (token == NULL)
		    {
			globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"Evaluator",__FILE__,"Expecting type of construct spec in Construct Line.");
			delete spec;
			curr=NULL; return;
		    }
		    int type;
		    if (strcmp(token,"E") == 0)
			type = CONSTRUCT_TYPE_ELEMENT;
		    else if (strcmp(token,"A") == 0)
			type = CONSTRUCT_TYPE_ATTRIBUTE;
		    else if (strcmp(token,"OA") == 0)
			type = CONSTRUCT_TYPE_OPTIONAL_ATTR;
		    else if (strcmp(token,"C") == 0)
			type = CONSTRUCT_TYPE_CONTENT;
		    else
		    {
			globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"Evaluator",__FILE__,"Unrecognizable construct type.");
			delete spec;
			curr=NULL; return;
		    }
		    ss.setType(type);

		    //source
		    token = strtok(NULL,",");
		    if (token == NULL)
		    {
			globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"Evaluator",__FILE__,"Expecting source of construct spec in Construct Line.");
			delete spec;
			curr=NULL; return;
		    }
		    int source;
		    if (strcmp(token,"C") == 0)
			source = CONSTRUCT_SRC_CONST;
		    else if (strcmp(token,"R") == 0)
			source = CONSTRUCT_SRC_REFERENCE;
		    else
		    {
			globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"Evaluator",__FILE__,"Unrecognizable construct source.");
			delete spec;
			curr=NULL; return;
		    }

		    ss.setSource(source);

		    token = strtok(NULL,",");
		    if (token == NULL)
		    {
			globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"Evaluator",__FILE__,"Expecting assigned NRE in Construct Line.");
			delete spec;
			curr=NULL; return;
		    }
		    NREType assignedNRE = (NREType)atoi(token);
		    if (assignedNRE < 1)
		    {
			globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"Evaluator",__FILE__,"NRE should be positive.");
			delete spec;
			curr=NULL; return;
		    }
		    ss.setAssignedNRE(assignedNRE);
		    if (assignedNRE > evaluator->maxNRE)
			evaluator->maxNRE = assignedNRE;
		    if (source == CONSTRUCT_SRC_CONST)
		    {//constant source

			if (type == CONSTRUCT_TYPE_ELEMENT)
			{
			    token = strtok(NULL,",");
			    if (token == NULL)
			    {
				globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"Evaluator",__FILE__,"Expecting constant element name in Construct Line.");
				delete spec;                       
				curr=NULL; return;
			    }
			    char *str = new char[strlen(token)+1];
			    strcpy(str,token);
			    ss.setStr1(str);
			}
			else if (type == CONSTRUCT_TYPE_ATTRIBUTE || type == CONSTRUCT_TYPE_OPTIONAL_ATTR)
			{
			    token = strtok(NULL,",");
			    if (token == NULL)
			    {
				globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"Evaluator",__FILE__,"Expecting constant attribute name in Construct Line.");
				delete spec;
				curr=NULL; return;
			    }
			    char *str1 = new char[strlen(token)+1];
			    strcpy(str1,token);
			    ss.setStr1(str1);

			    token = strtok(NULL,",");
			    if (token == NULL)
			    {
				globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"Evaluator",__FILE__,"Expecting constant attribute value in Construct Line.");
				delete spec;
				curr=NULL; return;
			    }
			    char *str2 = new char[strlen(token)+1];
			    strcpy(str2,token);
			    ss.setStr2(str2);
			}
			else
			{
			    token = strtok(NULL,",");
			    if (token == NULL)
			    {
				globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"Evaluator",__FILE__,"Expecting constant content in Construct Line.");
				delete spec;
				curr=NULL; return;
			    }
			    char *str = new char[strlen(token)+1];
			    strcpy(str,token);
			    ss.setStr1(str);
			}
		    }
		    else
		    { //reference source
			if (type == CONSTRUCT_TYPE_ATTRIBUTE || type == CONSTRUCT_TYPE_OPTIONAL_ATTR)
			{
			    token = strtok(NULL,",");
			    if (token == NULL)
			    {
				globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"Evaluator",__FILE__,"Expecting constant attribute name in Construct Line.");
				delete spec;
				curr=NULL; return;
			    }
			    char *str1 = new char[strlen(token)+1];
			    strcpy(str1,token);
			    ss.setStr1(str1);
			}
			token = strtok(NULL,",");
			if (token == NULL)
			{
			    globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"Evaluator",__FILE__,"Expecting root NRE in Construct Line.");
			    delete spec;                   
			    curr=NULL; return;
			}
			NREType rootNRE = (NREType)atoi(token);
			if (rootNRE < 1)
			{
			    globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"Evaluator",__FILE__,"NRE should be positive.");
			    delete spec;
			    curr=NULL; return;
			}
			if (rootNRE > evaluator->maxNRE)
			    evaluator->maxNRE = rootNRE;
			ss.setPatternRootNRE(rootNRE);
			token = strtok(NULL,",");
			if (token == NULL)
			{
			    globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"Evaluator",__FILE__,"Expecting number of nodes in pattern in Construct Line.");
			    delete spec;
			    curr=NULL; return;
			}
			int num1 = atoi(token);

			int *relation;
			ExecArrayType *pattern;
			int lev;
			int *getWhat;
			char **attrNames;
			int *tagNames;
			if (num1 > 1)
			{
			    pattern = new ExecArrayType;
			    relation = new int[num1];
			    getWhat = new int[num1];
			    attrNames = new char *[num1];
			    token = strtok(NULL,",");
			    if (token == NULL)
			    {
				globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"Evaluator",__FILE__,"Expecting source of nodes in pattern in Construct Line.");
				delete spec;
				delete [] pattern;
				delete [] relation;
				delete [] getWhat;
				delete [] attrNames;
				curr=NULL; return;
			    }
			    int nodeSource;
			    if (strcmp(token,"W") == 0)
				nodeSource = CPM_NODE_SRC_WITNESS;
			    else if (strcmp(token,"I") == 0)
				nodeSource = CPM_NODE_SRC_INDEX;
			    else
			    {
				globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"Evaluator",__FILE__,"Unrecognizable node source in construct.");
				delete spec;
				delete [] pattern;
				delete [] relation;
				delete [] getWhat;
				delete [] attrNames;
				curr=NULL; return;
			    }
			    ss.setNodeSource(nodeSource);
			    if (nodeSource == CPM_NODE_SRC_WITNESS)
				tagNames = new int[num1];
			    else
				tagNames = NULL;
			}
			else
			{
			    num1 = 0;
			    pattern = NULL;
			    relation = NULL;
			    getWhat = NULL;
			    attrNames = NULL;
			    tagNames = NULL;
			    token = strtok(NULL,",");
			    if (token == NULL)
			    {
				globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"Evaluator",__FILE__,"Expecting getWhat of root in Construct Line.");
				delete spec;                       
				curr=NULL; return;
			    }
			    int rootGetWhat;
			    if (strcmp(token, "S") == 0)
				rootGetWhat = CPM_GET_SUBTREE;
			    else if (strcmp(token,"A") == 0)
				rootGetWhat = CPM_GET_ATTR;
			    else if (strcmp(token,"I") == 0)
				rootGetWhat = CPM_GET_ITSELF;
			    else if (strcmp(token,"L") == 0)
				rootGetWhat = CPM_GET_LOCAL_SUBTREE;
			    else if (strcmp(token,"V") == 0)
				rootGetWhat = CPM_GET_VALUE;
			    else if (strcmp(token,"T") == 0)
				rootGetWhat = CPM_GET_TEXT;
			    else
			    {
				globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"Evaluator",__FILE__,"Unrecognizable rootGetWhat in construct.");
				delete spec;
				curr=NULL; return;
			    }
			    ss.setRootGetWhat(rootGetWhat);
			    ss.setNodeSource(CPM_NODE_SRC_INDEX);
			    if (rootGetWhat == CPM_GET_ATTR || rootGetWhat == CPM_GET_VALUE)
			    {
				token = strtok(NULL,",");
				if (token == NULL)
				{
				    globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"Evaluator",__FILE__,"Expecting attribute name of root in Construct Line.");
				    delete spec; 
				    curr=NULL; return;
				}
				char *attrName = new char[strlen(token) +1];
				strcpy(attrName,token);
				ss.setRootAttrName(attrName);
			    }
			}

			for (int j=0; j<num1; j++)
			{
			    if (j!=0)
			    {
				token = strtok(NULL,",");
				if (token == NULL)
				{
				    globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"Evaluator",__FILE__,"Expecting level of pattern node in Construct Line.");
				    if (ss.getNodeSource() == CPM_NODE_SRC_WITNESS)
					delete [] tagNames;

				    delete spec;
				    delete [] pattern;
				    delete [] relation;
				    delete [] getWhat;
				    for (int l=0; l<j; l++)
					if (attrNames[l]) delete [] attrNames[l];
				    delete [] attrNames;
				    curr=NULL; return;
				}
				lev = atoi(token);
				if (lev < 0)
				{
				    globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"Evaluator",__FILE__,"Level should be positive or 0 in Construct Line.");
				    if (ss.getNodeSource() == CPM_NODE_SRC_WITNESS)
					delete [] tagNames;

				    delete spec;
				    delete [] pattern;
				    delete [] relation;
				    delete [] getWhat;
				    for (int l=0; l<j; l++)
					if (attrNames[l]) delete [] attrNames[l];
				    delete [] attrNames;
				    curr=NULL; return;
				}
				pattern->InsertNodeInArray(NULL,lev);

				if (ss.getNodeSource() == CPM_NODE_SRC_WITNESS)
				{
				    token = strtok(NULL,",");
				    if (token == NULL)
				    {
					globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"Evaluator",__FILE__,"Expecting tag name in pattern in Construct Line.");

					delete [] tagNames;

					delete spec;
					delete [] pattern;
					delete [] relation;
					delete [] getWhat;
					for (int l=0; l<j; l++)
					    if (attrNames[l]) delete [] attrNames[l];
					delete [] attrNames;
					curr=NULL; return;
				    }

				    tagNames[j] = evaluator->getDataManager()->getPhysicalDataMng()->getXMLNameTable()->getCodeByName(token);
				}

				token = strtok(NULL,",");
				if (token == NULL)
				{
				    globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"Evaluator",__FILE__,"Expecting relation in pattern in Construct Line.");
				    if (ss.getNodeSource() == CPM_NODE_SRC_WITNESS)
					delete [] tagNames;

				    delete spec;
				    delete [] pattern;
				    delete [] relation;
				    delete [] getWhat;
				    for (int l=0; l<j; l++)
					if (attrNames[l]) delete [] attrNames[l];
				    delete [] attrNames;
				    curr=NULL; return;
				}
				if (strcmp(token,"A") == 0) 
				    relation[j] = ANCS_DESC;
				else if (strcmp(token,"P") == 0)
				    relation[j] = PARENT_CHILD;
				else
				{
				    globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"Evaluator",__FILE__,"Expecting relation in pattern in Construct Line.");
				    if (ss.getNodeSource() == CPM_NODE_SRC_WITNESS)
					delete [] tagNames;

				    delete spec;
				    delete [] pattern;
				    delete [] relation;
				    delete [] getWhat;
				    for (int l=0; l<j; l++)
					if (attrNames[l]) delete [] attrNames[l];
				    delete [] attrNames;
				    curr=NULL; return;
				}
				token = strtok(NULL,",");
				if (token == NULL)
				{
				    globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"Evaluator",__FILE__,"Expecting getWhat of pattern node in Construct Line.");
				    if (ss.getNodeSource() == CPM_NODE_SRC_WITNESS)
					delete [] tagNames;

				    delete spec;
				    delete [] pattern;
				    delete [] relation;
				    delete [] getWhat;
				    for (int l=0; l<j; l++)
					if (attrNames[l]) delete [] attrNames[l];
				    delete [] attrNames;
				    curr=NULL; return;
				}
				if (strcmp(token, "S") == 0)
				    getWhat[j] = CPM_GET_SUBTREE;
				else if (strcmp(token,"A") == 0)
				    getWhat[j] = CPM_GET_ATTR;
				else if (strcmp(token,"I") == 0)
				    getWhat[j] = CPM_GET_ITSELF;
				else if (strcmp(token,"L") == 0)
				    getWhat[j] = CPM_GET_LOCAL_SUBTREE;
				else if (strcmp(token,"T") == 0)
				    getWhat[j] = CPM_GET_TEXT;
				else
				{
				    globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"Evaluator",__FILE__,"Unrecognized getWhat of pattern node in Construct Line.");
				    if (ss.getNodeSource() == CPM_NODE_SRC_WITNESS)
					delete [] tagNames;

				    delete spec;
				    delete [] pattern;
				    delete [] relation;
				    delete [] getWhat;
				    for (int l=0; l<j; l++)
					if (attrNames[l]) delete [] attrNames[l];
				    delete [] attrNames;
				    curr=NULL; return;
				}

				if (getWhat[j] == CPM_GET_ATTR || getWhat[j] == CPM_GET_VALUE)
				{
				    token = strtok(NULL,",");
				    if (token == NULL)
				    {
					globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"Evaluator",__FILE__,"Expecting attribute name in pattern in Construct Line.");
					if (ss.getNodeSource() == CPM_NODE_SRC_WITNESS)
					    delete [] tagNames;

					delete spec;
					delete [] pattern;
					delete [] relation;
					delete [] getWhat;
					for (int l=0; l<j; l++)
					    if (attrNames[l]) delete [] attrNames[l];
					delete [] attrNames;
					curr=NULL; return;
				    }
				    attrNames[j] = new char[strlen(token) +1];
				    strcpy(attrNames[j],token);
				}
				else
				    attrNames[j] = NULL;
			    }
			    else
			    {
				attrNames[j] = NULL;
				if (ss.getNodeSource() == CPM_NODE_SRC_WITNESS)
				    tagNames[j] = -1;
				pattern->InsertNodeInArray(NULL,0);
			    }
			}
			ss.setPattern(pattern);
			ss.setRelation(relation);
			ss.setGetWhat(getWhat);
			ss.setAttrNames(attrNames);
			ss.setTagNames(tagNames);

		    }
		    spec->appendSpec(&ss);
		    ss.setPattern(NULL,false);
		    ss.setRelation(NULL,false);
		    ss.setGetWhat(NULL,false);
		    ss.setAttrNames(NULL,false);
		    ss.setTagNames(NULL,false);
		    ss.setStr1(NULL,false);
		    ss.setStr2(NULL,false);
		    ss.setRootAttrName(NULL,false);
		}

		for (int i=0; i<num; i++)
		{
		    if (spec->getSpecByIndex(i)->getPattern())
		    {
			if (spec->getSpecByIndex(i)->getNodeSource() == CPM_NODE_SRC_INDEX)
			{
			    for (int j=0; j<spec->getSpecByIndex(i)->getPattern()->GetSize(); j++)
			    {
				if (j!=0)
				{
				    char newLine[MAX_FILE_INTERFACE_LINE_SIZE];
				    if (((std::iostream *)queryInput)->eof() == 0)
					((std::iostream *)queryInput)->getline(newLine,MAX_FILE_INTERFACE_LINE_SIZE);
				    else
				    {
					globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"Evaluator",__FILE__,"Unexpected end of file while trying to read index accesses following Construct Line.");
					delete spec;
					curr=NULL; return;
				    }
				    // evaluator should return 1 index access/scan node.
				    spec->getSpecByIndex(i)->getPattern()->GetEntryByIndex(j)->SetQueryEvalNode(evaluator->getQueryEvalNode(newLine,queryInput));
				}
			    }
			}
		    }
		}
		char newLine[MAX_FILE_INTERFACE_LINE_SIZE];
		if (((std::iostream *)queryInput)->eof() == 0)
		    ((std::iostream *)queryInput)->getline(newLine,MAX_FILE_INTERFACE_LINE_SIZE);
		else
		{
		    globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"Evaluator",__FILE__,"Unexpected end of file in Construct Line.");
		    delete spec;
		    curr=NULL; return;
		}
		QueryEvaluationTreeNode *oper = evaluator->getQueryEvalNode(newLine,queryInput);
		if (oper == NULL)
		{
		    globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"Evaluator",__FILE__,"Unexpected operand returned (NULL) for Construct Line.");
		    delete spec;
		    curr=NULL; return;
		}
		curr = new QueryEvaluationTreeConstructNode(oper,spec);
	    }

