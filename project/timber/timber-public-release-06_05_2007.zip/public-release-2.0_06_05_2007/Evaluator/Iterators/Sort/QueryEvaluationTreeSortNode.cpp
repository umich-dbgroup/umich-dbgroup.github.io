/*
COPYRIGHT  � 2000-2004 
THE REGENTS OF THE UNIVERSITY OF MICHIGAN
ALL RIGHTS RESERVED

PERMISSION IS GRANTED TO USE, COPY, CREATE DERIVATIVE WORKS AND REDISTRIBUTE THIS SOFTWARE AND SUCH DERIVATIVE WORKS FOR 
NONCOMMERCIAL EDUCATION AND RESEARCH PURPOSES, SO LONG AS NO FEE IS CHARGED, AND SO LONG AS THE COPYRIGHT NOTICE ABOVE, 
THIS GRANT OF PERMISSION, AND THE DISCLAIMER BELOW APPEAR IN ALL COPIES MADE; AND SO LONG AS THE NAME OF THE UNIVERSITY 
OF MICHIGAN IS NOT USED IN ANY ADVERTISING OR PUBLICITY PERTAINING TO THE USE OR DISTRIBUTION OF THIS SOFTWARE WITHOUT 
SPECIFIC, WRITTEN PRIOR AUTHORIZATION.

THIS SOFTWARE IS PROVIDED AS IS, WITHOUT REPRESENTATION FROM THE UNIVERSITY OF MICHIGAN AS TO ITS FITNESS FOR ANY PURPOSE, 
AND WITHOUT WARRANTY BY THE UNIVERSITY OF MICHIGAN OF ANY KIND, EITHER EXPRESS OR IMPLIED, INCLUDING WITHOUT LIMITATION THE 
IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE. THE REGENTS OF THE UNIVERSITY OF MICHIGAN SHALL 
NOT BE LIABLE FOR ANY DAMAGES, INCLUDING SPECIAL, INDIRECT, INCIDENTAL, OR CONSEQUENTIAL DAMAGES, WITH RESPECT TO ANY CLAIM 
ARISING OUT OF OR IN CONNECTION WITH THE USE OF THE SOFTWARE, EVEN IF IT HAS BEEN OR IS HEREAFTER ADVISED OF THE POSSIBILITY 
OF SUCH DAMAGES.
*/

#include "QueryEvaluationTreeSortNode.h"
#include <stdio.h>
QueryEvaluationTreeSortNode::QueryEvaluationTreeSortNode(QueryEvaluationTreeNode *tosort,
														 int sortnum,NREType *nre, int *order, int expectedSize, int sortByWhat, int *whereEmptyGoes,bool ext)
: QueryEvaluationTreeNode()
{
	this->operand = tosort;
	this->sortNum = sortnum;
	this->nre = nre;
	this->order = order;
	this->expectedSize = expectedSize;
	this->sortByWhat = sortByWhat;
	this->whereEmptyGoes = whereEmptyGoes;
	this->ext = ext;
}

QueryEvaluationTreeSortNode::~QueryEvaluationTreeSortNode()
{
	if (operand)
		delete operand;
}

int QueryEvaluationTreeSortNode::getSortNum()
{
	return this->sortNum;
}

void QueryEvaluationTreeSortNode::setSortNum(int sortNum)
{
	this->sortNum = sortNum;
}

NREType *QueryEvaluationTreeSortNode::getNRE()
{
	return this->nre;
}

void QueryEvaluationTreeSortNode::setNRE(NREType *nre)
{
	this->nre = nre;
}

int QueryEvaluationTreeSortNode::getSortByWhat()
{
	return this->sortByWhat;
}

void QueryEvaluationTreeSortNode::setSortByWhat(int sortByWhat)
{
	this->sortByWhat = sortByWhat;
}

int *QueryEvaluationTreeSortNode::getOrder()
{
	return this->order;
}

void QueryEvaluationTreeSortNode::setOrder(int *order)
{
	this->order = order;
}


QueryEvaluationTreeNode *QueryEvaluationTreeSortNode::getOperand()
{
	return operand;
}

void QueryEvaluationTreeSortNode::setExpectedSize(int size)
{
	expectedSize = size;
}

int QueryEvaluationTreeSortNode::getExpectedSize()
{
	return expectedSize;
}

void QueryEvaluationTreeSortNode::setWhereEmptyGoes(int *whereEmptyGoes)
{
	this->whereEmptyGoes = whereEmptyGoes;
}

int *QueryEvaluationTreeSortNode::getWhereEmptyGoes()
{
	return this->whereEmptyGoes;
}


void QueryEvaluationTreeSortNode::setExt(bool ext)
{
	this->ext = ext;
}

bool QueryEvaluationTreeSortNode::getExt()
{
	return ext;
}

void QueryEvaluationTreeSortNode::deleteStructures()
{
	if (nre) delete [] nre;
	if (whereEmptyGoes) delete [] whereEmptyGoes;
	if (order) delete [] order;
	this->operand->deleteStructures();
}
