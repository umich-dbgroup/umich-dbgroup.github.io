
#include "parse.hpp"

char QueryEvaluationTreeSortNode::getIdentifier(void) { return 'R'; }

char SortPlanParser::getIteratorIdentifier(void) { return 'R'; }

void 
SortPlanParser::getQueryEvalNode(EvaluatorClass* evaluator, char* line, void* queryInput, QueryEvaluationTreeNode*& curr)
	    {
		// expected size
		char *token = strtok(line+2,",");                    
		if (token == NULL)
		{
		    globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"Evaluator",__FILE__,"Error input from file... expecting expected size... Sort line...");
		    curr=NULL; return;
		}
		int exSize = atoi(token);

		// sort type: by startkey or by score
		token = strtok(NULL,",");
		if (token == NULL)
		{
		    globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"Evaluator",__FILE__,"Error input from file... expecting sortBy what... Sort line...");
		    curr=NULL; return;
		}
		int sortByWhat;
		if (strcmp(token,"K") == 0)
		    sortByWhat = SORT_BY_START_KEY;
		else if (strcmp(token,"T") == 0)
		    sortByWhat = SORT_BY_TREE;
		else if (strcmp(token,"S") == 0)
		    sortByWhat = SORT_BY_SCORE;
		else
		{
		    globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"Evaluator",__FILE__,"Error input from file... unrecognized sortBy what... Sort line...");
		    curr=NULL; return;
		}
		// instantiate sort conditions
		int num;
		NREType *sortBy;
		int *order;
		int *whereEmptyGoes ;
		if (sortByWhat == SORT_BY_START_KEY)
		{
		    // number of nodes to sort
		    token = strtok(NULL,",");
		    if (token == NULL)
		    {
			globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"Evaluator",__FILE__,"Error input from file... expecting size of sort array... Sort line...");
			curr=NULL; return;
		    }
		    num = atoi(token);

		    if (num > 0)
		    {
			sortBy = new NREType[num];
			order = new int[num];
			whereEmptyGoes = new int[num];
		    }
		    else
		    {
			sortBy = NULL;
			order = NULL;
			whereEmptyGoes = NULL;
			globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"Evaluator",__FILE__,"Error input from file... num should be at least 1... Sort line...");
			curr=NULL; return;
		    }

		    for (int i=0; i<num; i++)
		    {
			token = strtok(NULL,",");
			if (token == NULL)
			{
			    globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"Evaluator",__FILE__,"Error input from file... expecting nre... Sort line...");
			    delete [] sortBy;
			    delete [] order;
			    delete [] whereEmptyGoes;
			    curr=NULL; return;
			}
			sortBy[i] = (NREType)atoi(token);
			if (sortBy[i] < 1)
			{
			    globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"Evaluator",__FILE__,"NRE should be positive.");
			    delete [] sortBy;
			    delete [] order;
			    delete [] whereEmptyGoes;
			    curr=NULL; return;
			}
			if (sortBy[i] > evaluator->maxNRE)
			    evaluator->maxNRE = sortBy[i];
			token = strtok(NULL,",");
			if (token == NULL)
			{
			    globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"Evaluator",__FILE__,"Error input from file... expecting A or D... Sort line...");
			    delete [] sortBy;
			    delete [] order;
			    delete [] whereEmptyGoes;
			    curr=NULL; return;
			}
			if (strcmp(token,"A") == 0)
			    order[i] = ASCENDING;
			else if (strcmp(token,"D") == 0)
			    order[i] = DESCENDING;
			else
			{
			    globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"Evaluator",__FILE__,"Error input from file... unrecognized order... Sort line...");
			    delete [] sortBy;
			    delete [] order;
			    delete [] whereEmptyGoes;
			    curr=NULL; return;
			}
			token = strtok(NULL,",");
			if (token == NULL)
			{
			    globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"Evaluator",__FILE__,"Error input from file... expecting whereEmptyGoes... Sort line...");
			    delete [] sortBy;
			    delete [] order;
			    delete [] whereEmptyGoes;					
			    curr=NULL; return;
			}
			if (strcmp(token,"B") == 0)
			    whereEmptyGoes[i] = EMPTY_AT_BEGINNING;
			else if (strcmp(token,"E") == 0)
			    whereEmptyGoes[i] = EMPTY_AT_END;
			else
			{
			    //FIX THIS after talking to Melanie. she outputs L instead of E for end.
			    //currently, we will accept it
			    whereEmptyGoes[i] = EMPTY_AT_END;
			    /*	globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"Evaluator",__FILE__,"Error input from file... unrecognized where empty goes... Sort line...");
				delete [] sortBy;
				delete [] order;
				delete [] whereEmptyGoes;		
				curr=NULL; return;*/
			}
		    }

		}
		else // sort by score or tree
		{
		    sortBy = NULL;
		    order = NULL;
		    whereEmptyGoes = NULL;

		    // ascending or descending
		    token = strtok(NULL,",");
		    if (token == NULL)
		    {
			globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"Evaluator",__FILE__,"Error input from file... expecting A or D... Sort line...");
			curr=NULL; return;
		    }

		    if (strcmp(token,"A") == 0)
			num = ASCENDING;
		    else if (strcmp(token,"D") == 0)
			num = DESCENDING;
		    else
		    {
			globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"Evaluator",__FILE__,"Error input from file... unrecognized order... Sort line...");
			curr=NULL; return;
		    }
		}

		bool ext = false;
		token = strtok(NULL,",");
		if (token != NULL)
		{
		    if (strcmp(token,"X") == 0)
			ext = true;
		}


		char newLine[MAX_FILE_INTERFACE_LINE_SIZE];
		if (((std::iostream *)queryInput)->eof() == 0)
		    ((std::iostream *)queryInput)->getline(newLine,MAX_FILE_INTERFACE_LINE_SIZE);
		else
		{
		    globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"Evaluator",__FILE__,"Unexpected end of file... Sort line...");
		    if (sortBy) delete [] sortBy;
		    if (order) delete [] order;
		    if (whereEmptyGoes) delete [] whereEmptyGoes;		            
		    curr=NULL; return;
		}
		QueryEvaluationTreeNode *oper = evaluator->getQueryEvalNode(newLine,queryInput);
		if (oper == NULL)
		{
		    globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"Evaluator",__FILE__,"Unexpected operand returned... Sort line...");
		    if (sortBy) delete [] sortBy;
		    if (order) delete [] order;
		    if (whereEmptyGoes) delete [] whereEmptyGoes;	 
		    curr=NULL; return;
		}
		curr = new QueryEvaluationTreeSortNode(oper,num,sortBy,order, exSize, sortByWhat,whereEmptyGoes ,ext);
		if (ext)
		    evaluator->fileIDsArraySize++;
	    }

