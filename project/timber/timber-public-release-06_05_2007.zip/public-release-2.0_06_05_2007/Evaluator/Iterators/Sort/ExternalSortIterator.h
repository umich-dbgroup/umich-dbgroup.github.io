/*
COPYRIGHT  � 2000-2004 
THE REGENTS OF THE UNIVERSITY OF MICHIGAN
ALL RIGHTS RESERVED

PERMISSION IS GRANTED TO USE, COPY, CREATE DERIVATIVE WORKS AND REDISTRIBUTE THIS SOFTWARE AND SUCH DERIVATIVE WORKS FOR 
NONCOMMERCIAL EDUCATION AND RESEARCH PURPOSES, SO LONG AS NO FEE IS CHARGED, AND SO LONG AS THE COPYRIGHT NOTICE ABOVE, 
THIS GRANT OF PERMISSION, AND THE DISCLAIMER BELOW APPEAR IN ALL COPIES MADE; AND SO LONG AS THE NAME OF THE UNIVERSITY 
OF MICHIGAN IS NOT USED IN ANY ADVERTISING OR PUBLICITY PERTAINING TO THE USE OR DISTRIBUTION OF THIS SOFTWARE WITHOUT 
SPECIFIC, WRITTEN PRIOR AUTHORIZATION.

THIS SOFTWARE IS PROVIDED AS IS, WITHOUT REPRESENTATION FROM THE UNIVERSITY OF MICHIGAN AS TO ITS FITNESS FOR ANY PURPOSE, 
AND WITHOUT WARRANTY BY THE UNIVERSITY OF MICHIGAN OF ANY KIND, EITHER EXPRESS OR IMPLIED, INCLUDING WITHOUT LIMITATION THE 
IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE. THE REGENTS OF THE UNIVERSITY OF MICHIGAN SHALL 
NOT BE LIABLE FOR ANY DAMAGES, INCLUDING SPECIAL, INDIRECT, INCIDENTAL, OR CONSEQUENTIAL DAMAGES, WITH RESPECT TO ANY CLAIM 
ARISING OUT OF OR IN CONNECTION WITH THE USE OF THE SOFTWARE, EVEN IF IT HAS BEEN OR IS HEREAFTER ADVISED OF THE POSSIBILITY 
OF SUCH DAMAGES.
*/

#ifndef __ExternalSortIterator_h
#define __ExternalSortIterator_h
#include <timber-compat.h>

#include "SortIterator.h"
#include "../../Common/ShoreList.h"

#define EX_SORT_DEFAULT_NUM_CONT	2
/**
* An access method that performs an external sort by start key or by score on a list of trees. Uses ANSI qsort
* for in memory sort.
* @see ShoreList
* @see ContainerClass
* @see SortIterator
* @see WitnessTree
* @see IteratorClass
* @author Shurug Al-Khalifa 
* @version 1.0
*/

class ExternalSortIterator : public IteratorClass
{
public:
	/**
	Constructor. 
	sorts by start key.
	@param input is where this iterator gets its input trees.
	@param num is the number of entries in the index and order arrays.
	@param index is an array of indices of nodes in input trees that you want output to be sorted
	              by. It will sort by first entry, if two are equal, then by second and so on.
    @param order each entry in this array is either ASCENDING or DESCENDING. order[i] is the 
	              sorting order of index[i].
    @param dataMng an instance of the data manager.
	**/
	ExternalSortIterator(IteratorClass *input, int num, NREType *nre, int *order, DataMng *dataMng, int *whereEmptyGoes, serial_t fileID, serial_t startID
		,int numWrites);//startkey

	/**
	Constructor.
	sorts by score.
	@param input is where this iterator gets its input trees.
    @param order it is either ASCENDING or DESCENDING. 
	@param dataMng an instance of the data manager.
	**/
	ExternalSortIterator(IteratorClass *input, int order, DataMng *dataMng, serial_t fileID, serial_t startID, int numWrites);//score

	/**
	Destructor.
	releases the memory used by output buffer and sort array.
	**/
	~ExternalSortIterator();

	/**
	Access Method
	gets the next output from this iterator.
	@param node is a pointer that well be set to the output buffer or NULL (indicating that
	there are no more results).
	**/
	void next(WitnessTree *&node);

private:
	int readInputIntoLists();
	int sortTheLists();
	int sortTheArray(int numEntries);
	int mergeContainers();
	int mergeAndOutputContainers();
	int mergeLists(int which);
	int writeWitnessTreeIntoContainer(WitnessTree *tree, ContainerClass *cont);
	int readWitnessTreeFromContainer(WitnessTree *tree, ContainerClass *cont);

	int writeContainerToList(ContainerClass *cont, ShoreList *list);

	int createFileAndID();

	void buildSortArray();

	void writeArrayIntoContainer(ContainerClass *cont, int numEntries);

	int treeSize(WitnessTree *tree);
	
	int currSortList;
	int nextEmptySortList;

	bool readTreesFromContainers();
	/**
	number of input trees.
	**/
	int numCont;
	//int resLeft, resRight;
	int *res;
	WitnessTree *inTree;
//	WitnessTree leftTree;
//	WitnessTree rightTree;
	
	bool inMemSort;

	int sortListsCap;
	int sortListsNum;
	serial_t startID;
	lvid_t volumeID;
	serial_t fileID;
	rc_t rc;
	DataMng *dataMng;
	

	int whoseFirst();
	bool atLeastOneSuccess();
	int *whereEmptyGoes;
	int treeNodeSz;
	/**
	a buffer that holds each of the results of the sort
	**/
	WitnessTree *resultBuffer;

	IteratorClass *input;
	/**
	an input tree.
	**/
	WitnessTree *inTuple;

	int sortByWhat;

//	ContainerClass cont1, cont2, cont3;

	ContainerClass *cont;
	int numContIn;
	ContainerClass outCont;
	
	
	ShoreList *sortLists;

	bool fileCreated;
	int orderSc;
	int *orderSK;
	NREType *nre;
	int num;
	WitnessTree *sortArray;
	int numWrites;
	bool allNull;
};


#endif
