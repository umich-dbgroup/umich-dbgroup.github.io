/*
COPYRIGHT  � 2000-2004 
THE REGENTS OF THE UNIVERSITY OF MICHIGAN
ALL RIGHTS RESERVED

PERMISSION IS GRANTED TO USE, COPY, CREATE DERIVATIVE WORKS AND REDISTRIBUTE THIS SOFTWARE AND SUCH DERIVATIVE WORKS FOR 
NONCOMMERCIAL EDUCATION AND RESEARCH PURPOSES, SO LONG AS NO FEE IS CHARGED, AND SO LONG AS THE COPYRIGHT NOTICE ABOVE, 
THIS GRANT OF PERMISSION, AND THE DISCLAIMER BELOW APPEAR IN ALL COPIES MADE; AND SO LONG AS THE NAME OF THE UNIVERSITY 
OF MICHIGAN IS NOT USED IN ANY ADVERTISING OR PUBLICITY PERTAINING TO THE USE OR DISTRIBUTION OF THIS SOFTWARE WITHOUT 
SPECIFIC, WRITTEN PRIOR AUTHORIZATION.

THIS SOFTWARE IS PROVIDED AS IS, WITHOUT REPRESENTATION FROM THE UNIVERSITY OF MICHIGAN AS TO ITS FITNESS FOR ANY PURPOSE, 
AND WITHOUT WARRANTY BY THE UNIVERSITY OF MICHIGAN OF ANY KIND, EITHER EXPRESS OR IMPLIED, INCLUDING WITHOUT LIMITATION THE 
IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE. THE REGENTS OF THE UNIVERSITY OF MICHIGAN SHALL 
NOT BE LIABLE FOR ANY DAMAGES, INCLUDING SPECIAL, INDIRECT, INCIDENTAL, OR CONSEQUENTIAL DAMAGES, WITH RESPECT TO ANY CLAIM 
ARISING OUT OF OR IN CONNECTION WITH THE USE OF THE SOFTWARE, EVEN IF IT HAS BEEN OR IS HEREAFTER ADVISED OF THE POSSIBILITY 
OF SUCH DAMAGES.
*/

#include "SortIterator.h"
NREType *gNRES;
int *gOrderS;
int gNumS;
int *gWhereEmptyGoes;
// function used in ANSI qsort. it has to be global
int compareSimpleNodes(const void *elem1,const void *elem2)
{
	if (gNRES) 
	{
		for (int i=0; i<gNumS; i++)
		{
			ListNode *n1 = (ListNode *)((WitnessTree *)elem1)->findNodeNRE(gNRES[i]);
			ListNode *n2 = (ListNode *)((WitnessTree *)elem2)->findNodeNRE(gNRES[i]);
			if (!n1 && !n2)
				continue;
			if (!n1)
				return -1*gWhereEmptyGoes[i];

			if (!n2)
				return gWhereEmptyGoes[i];

			if (n1->GetStartPos() == n2->GetStartPos())
				continue;
			else
			{
				if (n1->GetStartPos() < n2->GetStartPos())
					return (-1*gOrderS[i]);
				else
					return (gOrderS[i]);
			}
		}
	}

	//sorting by tree
	int n = ((WitnessTree *)elem1)->length() < ((WitnessTree *)elem2)->length()?
		((WitnessTree *)elem1)->length() : ((WitnessTree *)elem2)->length();
	for (int i=0; i<n; i++)
	{
		if (((ListNode *)((WitnessTree *)elem1)->findNode(i))->GetStartPos() ==
			((ListNode *)((WitnessTree *)elem2)->findNode(i))->GetStartPos())
			continue;
		else
		{
			if (gNRES)
			{
				if (((ListNode *)((WitnessTree *)elem1)->findNode(i))->GetStartPos() <
					((ListNode *)((WitnessTree *)elem2)->findNode(i))->GetStartPos())
					return -1;
				else
					return 1;
			}
			else
			{
				if (((ListNode *)((WitnessTree *)elem1)->findNode(i))->GetStartPos() <
					((ListNode *)((WitnessTree *)elem2)->findNode(i))->GetStartPos())
					return (-1*gNumS);
				else
					return (1*gNumS);
			}
		}
	}
	if (gNRES)
	{
		if (((WitnessTree *)elem1)->length() < ((WitnessTree *)elem2)->length())
			return -1;
		else if (((WitnessTree *)elem1)->length() > ((WitnessTree *)elem2)->length())
			return 1;
	}
	else
	{
		if (((WitnessTree *)elem1)->length() < ((WitnessTree *)elem2)->length())
			return -1*gNumS;
		else if (((WitnessTree *)elem1)->length() > ((WitnessTree *)elem2)->length())
			return 1*gNumS;
	}
	return 0;
}

int compareComplexNodes(const void *elem1,const void *elem2)
{
	if (gNRES) 
	{
		for (int i=0; i<gNumS; i++)
		{
			ComplexListNode *n1 = (ComplexListNode *)((WitnessTree *)elem1)->findNodeNRE(gNRES[i]);
			ComplexListNode *n2 = (ComplexListNode *)((WitnessTree *)elem2)->findNodeNRE(gNRES[i]);
			if (!n1 && !n2)
				continue;
			if (!n1)
				return -1*gWhereEmptyGoes[i];

			if (!n2)
				return gWhereEmptyGoes[i];

			if (n1->GetStartPos() == n2->GetStartPos())
				continue;
			else
			{
				if (n1->GetStartPos() < n2->GetStartPos())
					return (-1*gOrderS[i]);
				else
					return (gOrderS[i]);
			}
		}
	}

	//sorting by tree
	int n = ((WitnessTree *)elem1)->length() < ((WitnessTree *)elem2)->length()?
		((WitnessTree *)elem1)->length() : ((WitnessTree *)elem2)->length();
	for (int i=0; i<n; i++)
	{
		if (((ComplexListNode *)((WitnessTree *)elem1)->findNode(i))->GetStartPos() ==
			((ComplexListNode *)((WitnessTree *)elem2)->findNode(i))->GetStartPos())
			continue;
		else
		{
			if (gNRES)
			{
				if (((ComplexListNode *)((WitnessTree *)elem1)->findNode(i))->GetStartPos() <
					((ComplexListNode *)((WitnessTree *)elem2)->findNode(i))->GetStartPos())
					return -1;
				else
					return 1;
			}
			else
			{
				if (((ComplexListNode *)((WitnessTree *)elem1)->findNode(i))->GetStartPos() <
					((ComplexListNode *)((WitnessTree *)elem2)->findNode(i))->GetStartPos())
					return (-1*gNumS);
				else
					return (1*gNumS);
			}
		}
	}
	if (gNRES)
	{
		if (((WitnessTree *)elem1)->length() < ((WitnessTree *)elem2)->length())
			return -1;
		else if (((WitnessTree *)elem1)->length() > ((WitnessTree *)elem2)->length())
			return 1;
	}
	else
	{
		if (((WitnessTree *)elem1)->length() < ((WitnessTree *)elem2)->length())
			return -1*gNumS;
		else if (((WitnessTree *)elem1)->length() > ((WitnessTree *)elem2)->length())
			return 1*gNumS;
	}
	
	return 0;
}

int compareScore(const void *elem1,const void *elem2)
{
	if (((WitnessTree *)elem1)->getScore() < ((WitnessTree *)elem2)->getScore())
		return (-1*gNumS);
	else if (((WitnessTree *)elem1)->getScore() > ((WitnessTree *)elem2)->getScore())
		return (gNumS);
	else
		return 0;
}

int compareSKScan(const void *elem1,const void *elem2)
{
	if (((ListNode *)((WitnessTree *)elem1)->getNodeByIndex(0))->GetStartPos() < 
		((ListNode *)((WitnessTree *)elem2)->getNodeByIndex(0))->GetStartPos())
		return -1;
	else if (((ListNode *)((WitnessTree *)elem1)->getNodeByIndex(0))->GetStartPos() > 
		((ListNode *)((WitnessTree *)elem2)->getNodeByIndex(0))->GetStartPos())
		return 1;
	else
		return 0;
}

SortIterator::SortIterator(IteratorClass *input, int numExpected, int num, NREType *nre, int *order, DataMng *dataMng, int *whereEmptyGoes)
{	
	size = 0;
	i=0;
	this->input = input;
	this->dataMng = dataMng;
	input->next(inTuple);
	if (numExpected <= 0)
		numExpected = gSettings->getIntegerValue("INITIAL_DEFAULT_SORT_ARRAY_SIZE",INITIAL_SORT_ARRAY_SIZE_DEFAULT);
	if (inTuple)
	{
		sortArray = new WitnessTree[numExpected];
		if (inTuple->isSimple())
			resultBuffer  = new WitnessTree;
		else
			resultBuffer = new WitnessTree(LIST_NODE_WITH_DATA,dataMng);
		
		bool simple = false;
		while (inTuple)
		{
			if (size >= numExpected)
			{
				//doubling array size.
				WitnessTree *tmp = sortArray;
				numExpected *= 2;
				sortArray = new WitnessTree[numExpected];
				memcpy(sortArray, tmp, size * sizeof(WitnessTree));
				delete [] tmp;
			}
			//writing into the array
			if (inTuple->isSimple())
				simple = true;
			sortArray[size].copyTree(inTuple);
			sortArray[size].setDeleteBuffers(false);
			size++;
			input->next(inTuple);
		}
		delete this->input;
		this->input = NULL;
		if (globalErrorInfo.doWeHaveAProblem())
		{
			if (order)
				delete [] order;
			if (nre)
				delete [] nre;
			if (whereEmptyGoes)
				delete [] whereEmptyGoes;
			size = 0;
			return;
		}
		gOrderS = order;
		gNRES = nre;
		gNumS = num;
		gWhereEmptyGoes = whereEmptyGoes;

		if (num == 0)
		{
			gNumS = order[0];
			gNRES = NULL;
		}


		//sorting the array
	/*	if (simple)
			qsort(sortArray,size,sizeof(WitnessTree),compareSimpleNodes);
		else
			qsort(sortArray,size,sizeof(WitnessTree),compareComplexNodes);
*/
		EvalQuickSort s;
		int res;
		if (simple)
			res = s.quickSort(sortArray,0,size-1,compareSimpleNodes);
		else
			res = s.quickSort(sortArray,0,size-1,compareComplexNodes);
		if (res == FAILURE)
			size = 0;
	}
	else
		resultBuffer = NULL;
	if (order)
		delete [] order;
	if (nre)
		delete [] nre;
	if (whereEmptyGoes)
		delete [] whereEmptyGoes;
	if (this->input) delete this->input;
	this->input = NULL;
}


SortIterator::SortIterator(IteratorClass *input, int numExpected, int order, DataMng *dataMng)
{	
	size = 0;
	i=0;
	this->input = input;
	this->dataMng = dataMng;
	input->next(inTuple);
	if (numExpected <= 0)
		numExpected = gSettings->getIntegerValue("INITIAL_DEFAULT_SORT_ARRAY_SIZE",INITIAL_SORT_ARRAY_SIZE_DEFAULT);
	if (inTuple)
	{
		sortArray = new WitnessTree[numExpected];
		resultBuffer  = new WitnessTree(inTuple->isSimple()? LIST_NODE : LIST_NODE_WITH_DATA);
		
		bool simple = false;
		while (inTuple)
		{
			if (size >= numExpected)
			{
				//doubling array size.
				WitnessTree *tmp = sortArray;
				numExpected *= 2;
				sortArray = new WitnessTree[numExpected];
				memcpy(sortArray, tmp, size * sizeof(WitnessTree));
				delete [] tmp;
			}

			//writing into the array
			if (inTuple->isSimple())
				simple = true;
			sortArray[size].copyTree(inTuple);
			sortArray[size].setDeleteBuffers(false);
			size++;
			input->next(inTuple);
		}
		delete this->input;
		this->input = NULL;

		if (globalErrorInfo.doWeHaveAProblem())
		{
			size = 0;
			return;
		}
		//sorting the array by score
		gNumS = order;
		gNRES = NULL;
		EvalQuickSort s;
		if (s.quickSort(sortArray,0, size-1, compareScore) == FAILURE)
			size = 0;
		//qsort(sortArray,size,sizeof(WitnessTree),compareScore);
	}
	else
		resultBuffer = NULL;
	if (this->input) delete this->input;
	this->input = NULL;
}

SortIterator::SortIterator(ScanIDType inputSID, FileIDType fid, int numExpected, DataMng *dataMng)
{	
	size = 0;
	i=0;
	input = NULL;
	this->dataMng = dataMng;
	DM_DataNode *inTuple = dataMng->scanFetchNext(fid,inputSID);
	if (numExpected <= 0)
		numExpected = gSettings->getIntegerValue("INITIAL_DEFAULT_SORT_ARRAY_SIZE",INITIAL_SORT_ARRAY_SIZE_DEFAULT);
	if (inTuple)
	{
		sortArray = new WitnessTree[numExpected];
		resultBuffer  = new WitnessTree;
		
		while (inTuple)
		{
			if (size >= numExpected)
			{
				//doubling array size.
				WitnessTree *tmp = sortArray;
				numExpected *= 2;
				sortArray = new WitnessTree[numExpected];
				memcpy(sortArray, tmp, size * sizeof(WitnessTree));
				delete [] tmp;
			}
			sortArray[size].initialize();
			ListNode n;
			n.SetStartPos(inTuple->getKey());
			n.SetEndPos(inTuple->getEndKey());
			n.SetLevel(inTuple->getLevel());
			sortArray[size].appendList(&n,1);
			sortArray[size].setDeleteBuffers(false);
			size++;
			inTuple = dataMng->scanFetchNext(fid,inputSID);
		}
		if (globalErrorInfo.doWeHaveAProblem())
		{
			size = 0;
			return;
		}
		//sorting the array by sk
		gNRES = NULL;
		EvalQuickSort s;
		if (s.quickSort(sortArray,0, size-1, compareSKScan) == FAILURE)
			size = 0;
	}
	else
		resultBuffer = NULL;
}

SortIterator::~SortIterator()
{
	if (resultBuffer)
	{
		delete resultBuffer;
		delete [] sortArray;
	}
	if (input) delete input;
}


void SortIterator::next(WitnessTree *&node)
{	
#ifdef EVAL_TIME_OUT
	clock_t currTime = clock();
	double queryDuration = (double)(currTime - gQueryStartTime) / CLOCKS_PER_SEC;
	if (queryDuration >= gTimeOutAfter)
	{
		globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"Evaluator",__FILE__,"Query Timed Out.");
		node = NULL;
		return;
	}
#endif
	//reading the sorted array one by one and outputtting the results
	while (i < size)
	{
		//writing the array entry into resultBuffer
		resultBuffer->copyTree(&sortArray[i]);
		sortArray[i].setDeleteBuffers(true);
		node = resultBuffer;
		i++;
		return;
	}
	node = NULL;
	return;
}

