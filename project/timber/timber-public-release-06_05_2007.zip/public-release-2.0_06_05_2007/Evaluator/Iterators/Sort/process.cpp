#include "../../Evaluator/EvaluatorClass.h"

#include "QueryEvaluationTreeSortNode.h"

#include "ExternalSortIterator.h"
#include "ExternalSortIterator.h"
#include "ExternalSortIterator.h"
#include "SortIterator.h"
#include "SortIterator.h"
#include "SortIterator.h"
#include "extra.h"

void QueryEvaluationTreeSortNode::processQueryEvalNode(EvaluatorClass* evaluator, IteratorClass*& curr)
	    {
		serial_t fileID = 0;
		serial_t recID = 0;
		int numWrites = 0;
		if (getExt())
		{
		    fileID = evaluator->fileIDsArray[evaluator->fileIDsArrayPtr];
		    evaluator->fileIDsArrayPtr++;
		    numWrites = evaluator->createRecID(recID);
		    if (numWrites == FAILURE)
		    {
			globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"Evaluator",__FILE__, "operand returned is NULL. sort process eval node..." );
			curr=NULL; return;
		    }
		}
		IteratorClass *opr = evaluator->processQueryEvalNode(getOperand());
		if (opr == NULL)
		{
		    globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"Evaluator",__FILE__, "operand returned is NULL. sort process eval node..." );
		    curr=NULL; return;
		}
		if (getExt())
		{	
		    if (getSortByWhat() == SORT_BY_START_KEY)
			curr = new ExternalSortIterator(opr,getSortNum(),getNRE(),getOrder(),evaluator->getDataManager(),getWhereEmptyGoes()
				,fileID,recID,numWrites);
		    else if (getSortByWhat() == SORT_BY_TREE)
		    {
			int *sortOrder = new int[1];
			sortOrder[0] = getSortNum();
			curr = new ExternalSortIterator(opr,0,NULL,sortOrder,evaluator->getDataManager(),NULL,fileID,recID,numWrites);
		    }
		    else if (getSortByWhat() == SORT_BY_SCORE)
			curr = new ExternalSortIterator(opr,getSortNum(),evaluator->getDataManager(),fileID,recID,numWrites);
		    else
		    {
			globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"Evaluator",__FILE__, "unrecognized sort by value. sort process eval node..." );
			curr=NULL; return;
		    }
		}
		else
		{
		    if (getSortByWhat() == SORT_BY_START_KEY)
			curr = new SortIterator(opr,getExpectedSize(),getSortNum(),getNRE(),getOrder(),evaluator->getDataManager(),getWhereEmptyGoes());
		    else if (getSortByWhat() == SORT_BY_TREE)
		    {
			int *sortOrder = new int[1];
			sortOrder[0] = getSortNum();
			curr = new SortIterator(opr,getExpectedSize(),0,NULL,sortOrder,evaluator->getDataManager(),NULL);
		    }
		    else if (getSortByWhat() == SORT_BY_SCORE)
			curr = new SortIterator(opr,getExpectedSize(),getSortNum(),evaluator->getDataManager());
		    else
		    {
			globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"Evaluator",__FILE__, "unrecognized sort by value. sort process eval node..." );
			curr=NULL; return;
		    }
		}
		setNRE(NULL);
		setWhereEmptyGoes(NULL);
		setOrder(NULL);
	    }

