#include "../../Evaluator/EvaluatorClass.h"

#include "QueryEvaluationTreeNavigationalGetRelativeNode.h"

#include "NavigationalGetRelative.h"
#include "NavigationalGetRelative.h"
#include "extra.h"

void QueryEvaluationTreeNavigationalGetRelativeNode::processQueryEvalNode(EvaluatorClass* evaluator, IteratorClass*& curr)
	    {
		IteratorClass *opr = evaluator->processQueryEvalNode(getOperand());
		if (opr == NULL)
		{
		    globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"Evaluator",__FILE__, "operand returned is NULL. navigational get relative process eval node..." );
		    curr=NULL; return;
		}
		curr = new NavigationalGetRelative(opr,getNRE(),getRelation(),getNum(),getAssignedNRE()
			,evaluator->getDataManager());
	    }

