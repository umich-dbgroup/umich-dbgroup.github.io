#include "../../Evaluator/EvaluatorClass.h"

#include "QueryEvaluationTreePhraseFinderNode.h"

#include "PhraseFinderIterator.h"
#include "extra.h"

void QueryEvaluationTreePhraseFinderNode::processQueryEvalNode(EvaluatorClass* evaluator, IteratorClass*& curr)
	    {
		int openFileIndex = evaluator->openFile(getFileName(),evaluator->getDataManager());
		if (openFileIndex == -1)
		{
		    globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"Evaluator",__FILE__,"File is unloaded in Timber.");
		    curr=NULL; return;
		}
		curr = new PhraseFinderIterator(getPhrase(), getIndexName(), (char)openFileIndex,getAssignedNRE());
		setIndexName(NULL);
		setPhrase(NULL);
	    }

