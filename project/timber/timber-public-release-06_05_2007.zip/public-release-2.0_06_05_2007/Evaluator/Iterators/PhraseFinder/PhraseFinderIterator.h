/*
COPYRIGHT  � 2000-2004 
THE REGENTS OF THE UNIVERSITY OF MICHIGAN
ALL RIGHTS RESERVED

PERMISSION IS GRANTED TO USE, COPY, CREATE DERIVATIVE WORKS AND REDISTRIBUTE THIS SOFTWARE AND SUCH DERIVATIVE WORKS FOR 
NONCOMMERCIAL EDUCATION AND RESEARCH PURPOSES, SO LONG AS NO FEE IS CHARGED, AND SO LONG AS THE COPYRIGHT NOTICE ABOVE, 
THIS GRANT OF PERMISSION, AND THE DISCLAIMER BELOW APPEAR IN ALL COPIES MADE; AND SO LONG AS THE NAME OF THE UNIVERSITY 
OF MICHIGAN IS NOT USED IN ANY ADVERTISING OR PUBLICITY PERTAINING TO THE USE OR DISTRIBUTION OF THIS SOFTWARE WITHOUT 
SPECIFIC, WRITTEN PRIOR AUTHORIZATION.

THIS SOFTWARE IS PROVIDED AS IS, WITHOUT REPRESENTATION FROM THE UNIVERSITY OF MICHIGAN AS TO ITS FITNESS FOR ANY PURPOSE, 
AND WITHOUT WARRANTY BY THE UNIVERSITY OF MICHIGAN OF ANY KIND, EITHER EXPRESS OR IMPLIED, INCLUDING WITHOUT LIMITATION THE 
IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE. THE REGENTS OF THE UNIVERSITY OF MICHIGAN SHALL 
NOT BE LIABLE FOR ANY DAMAGES, INCLUDING SPECIAL, INDIRECT, INCIDENTAL, OR CONSEQUENTIAL DAMAGES, WITH RESPECT TO ANY CLAIM 
ARISING OUT OF OR IN CONNECTION WITH THE USE OF THE SOFTWARE, EVEN IF IT HAS BEEN OR IS HEREAFTER ADVISED OF THE POSSIBILITY 
OF SUCH DAMAGES.
*/

#ifndef __phrasefinderiterator_h
#define __phrasefinderiterator_h
#include <timber-compat.h>
// #include "TextFileReader.h"
#include "../../Evaluator/EvaluatorClass.h"
#include "../IndexAccess/GistIndexAccess.h"
#include "../IndexAccess/HashIndexAccess.h"

/**
* An access method that outputs the occurances of a phrase in
* an xml document
* @see IndexAccess
* @see IteratorClass
* @see EvaluatorClass
* @see WitnessTree
* @author Shurug Al-Khalifa 
* @version 1.0
*/
class PhraseFinderIterator : public IteratorClass
{

public:
	/**
	Constructor
	initializes the variables. 
	@param phrase is the phrase to be found in the document. this is expected to
		be newed somewhere. it will be deleted here.
	@param indexName is the name of the inverted index that will be searched. 
		this is expected to be newed somewhere. it will be deleted here.
	@param openFileIndex is the index in thenopen files array of the file to read data from.
	**/
	PhraseFinderIterator(char *phrase, char *indexName, char openFileIndex, NREType assignedNRE);

	/**
	Destructor
	frees the output buffer.
	**/
	~PhraseFinderIterator();

	/**
	Access Method
	gets the next output tree from this iterator.
	@param node is a pointer that well be set to the output buffer or NULL (indicating that
	there are no more results).
	**/
	void next(WitnessTree *&node);
	static int wordCount(char *str);
	static void extractWords(char *str, GistIndexAccess **indices, 
                                                   int *offsets, char *indexName, char openFileIndex, NREType assignedNRE);

private:
	/**
	phrase to found in XML document
	**/
	char *phrase;

	/**
	inverted index name
	**/
	char *indexName;
	char openFileIndex;
	/**
	buffer used to hold the output
	**/
	WitnessTree *resultBuffer;

	/**
	number of words in the phrase
	**/
	int wordNum;

	int *offsets;

	NREType assignedNRE;
	WitnessTree **inTuple;
	GistIndexAccess **indices;
	void getInputs(int which = -1);
	int getSameNodes(int index, KeyType startKey, int offset, bool &finished);
};

#endif

