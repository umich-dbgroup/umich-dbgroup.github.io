#include "../../Evaluator/EvaluatorClass.h"

#include "QueryEvaluationTreeMCCASNode.h"

#include "extra.h"

void QueryEvaluationTreeMCCASNode::processQueryEvalNode(EvaluatorClass* evaluator, IteratorClass*& curr)
	    {
		if (getNumInputs() == 0)
		    curr=NULL; return;
		IteratorClass **opr = new IteratorClass *[getNumInputs()];
		for (int i=0; i<getNumInputs(); i++)
		{
		    opr[i] = evaluator->processQueryEvalNode(getOperands()[i]);
		    if (opr[i] == NULL)
		    {	
			for (int j=0;j<i;j++)
			    delete opr[j];
			delete [] opr;
			curr=NULL; return;
		    }
		}
		serial_t fileID = evaluator->fileIDsArray[evaluator->fileIDsArrayPtr];
		evaluator->fileIDsArrayPtr++;
		curr = new MeaningfulClosestCommonAncestorStructureIterator(
			opr,getNumInputs(), getNRE(), getASpec(), getAssignedNRE(), getExpectedInputSize(),evaluator->getDataManager(), getExpectedDepth(),fileID);
	    }

