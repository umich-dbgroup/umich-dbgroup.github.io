#include "QueryEvaluationTreeMCCASNode.h"

QueryEvaluationTreeMCCASNode:: QueryEvaluationTreeMCCASNode(
		QueryEvaluationTreeNode** operands,
		int numInputs,
		NREType *nre,
		//bool *isOptional,
		// Yunyao: updated 11-20-04 to support annotated MLCAS
		char *aSpec,
		NREType assignedNre,
		int expectedInputSize, 
		int expectedDepth)
: QueryEvaluationTreeNode()
{
	this->operands = operands;
	this->numInputs = numInputs;
	this->nre = nre;
	//this->isOptional = isOptional;
	this->aSpec = aSpec;
	this->assignedNre = assignedNre;
    this->expectedInputSize = expectedInputSize;
	this->expectedDepth = expectedDepth;
}

QueryEvaluationTreeMCCASNode::~QueryEvaluationTreeMCCASNode()
{
	if (operands)
	{
		for (int i=0; i<this->numInputs; i++)
			if (operands[i])
				delete operands[i];
		delete [] operands;
	}

	/*if (nre)
		delete [] nre;

	if(aSpec)
		delete [] aSpec;*/
}

int QueryEvaluationTreeMCCASNode::getNumInputs()
{
	return this->numInputs;
}

void QueryEvaluationTreeMCCASNode::setNumInputs(int numInputs)
{
	this->numInputs= numInputs;
}

int QueryEvaluationTreeMCCASNode::getExpectedInputSize()
{
	return this->expectedInputSize;
}

void QueryEvaluationTreeMCCASNode::setExpectedInputSize(int expectedInputSize)
{
	this->expectedInputSize = expectedInputSize;
}

int QueryEvaluationTreeMCCASNode::getExpectedDepth()
{
	return this->expectedDepth;
}

void QueryEvaluationTreeMCCASNode::setExpectedDepth(int expectedDepth)
{
	this->expectedDepth = expectedDepth;
}

/* may be useful for optimization?
void QueryEvaluationTreeMCCASNode::setParentIndexName(char* parentIndexName)
{
	this->parentIndexName = parentIndexName;
}

char* QueryEvaluationTreeMCCASNode::getParentIndexName()
{
	return this->parentIndexName;
}*/

QueryEvaluationTreeNode **QueryEvaluationTreeMCCASNode::getOperands()
{
	return this->operands;
}

void QueryEvaluationTreeMCCASNode::setOperands(QueryEvaluationTreeNode **operands)
{
	this->operands = operands;
}

NREType *QueryEvaluationTreeMCCASNode::getNRE()
{
	return nre;
}

void QueryEvaluationTreeMCCASNode::setNRE(NREType *nre)
{
	this->nre = nre;
}

NREType QueryEvaluationTreeMCCASNode::getAssignedNRE()
{
	return this->assignedNre;
}

void QueryEvaluationTreeMCCASNode::setAssignedNRE(NREType nre)
{
	this->assignedNre = nre;
}

/*
bool *QueryEvaluationTreeMCCASNode::getIsOptional()
{
	return this->isOptional;
}

void QueryEvaluationTreeMCCASNode::setIsOptional(bool *isOptional)
{
	this->isOptional = isOptional;
}*/


char *QueryEvaluationTreeMCCASNode::getASpec()
{
	return this->aSpec;
}

void QueryEvaluationTreeMCCASNode::setASpec(char * aSpec)
{
	this->aSpec = aSpec;
}


void QueryEvaluationTreeMCCASNode::deleteStructures()
{
	for (int i=0; i<this->numInputs; i++)
		if (operands[i])
			operands[i]->deleteStructures();
}
