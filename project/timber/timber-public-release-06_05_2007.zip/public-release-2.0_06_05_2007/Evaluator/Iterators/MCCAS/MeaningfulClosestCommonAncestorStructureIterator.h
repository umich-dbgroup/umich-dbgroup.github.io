/*
COPYRIGHT  (c) 2000-2004 
THE REGENTS OF THE UNIVERSITY OF MICHIGAN
ALL RIGHTS RESERVED

PERMISSION IS GRANTED TO USE, COPY, CREATE DERIVATIVE WORKS AND
REDISTRIBUTE THIS SOFTWARE AND SUCH DERIVATIVE WORKS FOR NONCOMMERCIAL
EDUCATION AND RESEARCH PURPOSES, SO LONG AS NO FEE IS CHARGED, AND SO LONG
AS THE COPYRIGHT NOTICE ABOVE, THIS GRANT OF PERMISSION, AND THE
DISCLAIMER BELOW APPEAR IN ALL COPIES MADE; AND SO LONG AS THE NAME OF THE
UNIVERSITY OF MICHIGAN IS NOT USED IN ANY ADVERTISING OR PUBLICITY
PERTAINING TO THE USE OR DISTRIBUTION OF THIS SOFTWARE WITHOUT SPECIFIC,
WRITTEN PRIOR AUTHORIZATION.

THIS SOFTWARE IS PROVIDED AS IS, WITHOUT REPRESENTATION FROM THE
UNIVERSITY OF MICHIGAN AS TO ITS FITNESS FOR ANY PURPOSE, AND WITHOUT
WARRANTY BY THE UNIVERSITY OF MICHIGAN OF ANY KIND, EITHER EXPRESS OR
IMPLIED, INCLUDING WITHOUT LIMITATION THE IMPLIED WARRANTIES OF
MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE. THE REGENTS OF THE
UNIVERSITY OF MICHIGAN SHALL NOT BE LIABLE FOR ANY DAMAGES, INCLUDING
SPECIAL, INDIRECT, INCIDENTAL, OR CONSEQUENTIAL DAMAGES, WITH RESPECT TO
ANY CLAIM ARISING OUT OF OR IN CONNECTION WITH THE USE OF THE SOFTWARE,
EVEN IF IT HAS BEEN OR IS HEREAFTER ADVISED OF THE POSSIBILITY OF SUCH
DAMAGES.
*/

#ifndef __MeaningfulClosestCommonAncestorStructureIterator_h
#define __MeaningfulClosestCommonAncestorStructureIterator_h
#include <timber-compat.h>
#include <sstream>
using std::stringstream;


#include "../../Common/stack.h"
#include "../../Evaluator/Evaluator_definitions.h"
#include "../../Evaluator/EvaluatorClass.h"
#include "MCCASStackNode.h"

//Global settings class
#include "../../Utilities/Settings.h"
extern Settings* gSettings;

//Global error handling class
#include "../../Utilities/ErrorInfoClass.h"
extern ErrorInfoClass globalErrorInfo;

#define MLCA_MAX (1.7976931348623157e+308)
#define TARGET_IMMATERIAL 1
#define SOURCE_IMMATERIAL 2
#define ALL_MATERIAL 0

/**
* An access method that takes the input trees from several sources and find out the 
* meaningful closest common ancestor structures for the sets of nodes
* @see IteratorClass
* @see EvaluatorClass
* @see WitnessTree
* @see MCCASStackNode
* @author Yunyao Li
*/

class MeaningfulClosestCommonAncestorStructureIterator : public IteratorClass
{
public:
	/**
	Constructor
	initializes the variables. 
	@param inputs is an array of input iterators.
	@param numInputs is the number of input iterators
	@param nre is the pointer to an array of nre values of input nodes
	@param assignedNre is the nre value assigned to the root of MLCAS
	@param dataMng an instance of the data manager.
	**/
	MeaningfulClosestCommonAncestorStructureIterator(IteratorClass **inputs,int numInputs, NREType *nre, char *aSpec, NREType assignedNre, int expectedInputSize, DataMng *dataMng, int expectedDepth, serial_t fileID);

	/**
	Destructor
	releases memory used by array and result buffer.
	**/
	~MeaningfulClosestCommonAncestorStructureIterator();
	
	/**
	Access Method
	gets the next output tree from this iterator.
	@param node is a pointer that well be set to the output buffer or NULL (indicating that
	there are no more results).
	**/
	void next(WitnessTree *&node);
private:
	/**
	get the parent node of an input node
	**/
	void GetParentNode(ListNode * child, ListNode * parent);
	
	/**
	get the parent node of an  input node of ComplexListNode type
	**/
	void GetParentNode(ComplexListNode * child, ComplexListNode *& parent);

	/**
	find all the MCCAS with the same root
	**/
	bool FindMCCAS();
    
	/**
	expand a input node into a new stacknode and push it into stack2
	**/
	void PushInputAsNewStackNode(int setNum);

	/**
	Pop results from stack2
	**/
	int popStack(KeyType startPosition);

    /**
	find the node with minStartKey from unprocessed input nodes
	**/
	void findInput(int &setNum);

	/**
	write the nodes in buffer to its Shore list
	**/
	int WriteBufferToItsList(ContainerClass *cont, ShoreList *list);

	/**
	insert a stack node into another stack node
	**/
	int InsertStackNode(MCCASStackNode * source, MCCASStackNode * target);

	/**
	push an input node onto tempStack
	**/	
	void PushInput(int setNum);

	/**
	 Replace the node with its parent node
	**/
	int ReplaceWithParentNode(MCCASStackNode * childNode);

	/**
	 copy the list from a stack node into anoter stack node
	 **/
	int CopyList(MCCASStackNode * source, MCCASStackNode * target);

	/**
	write buffer or list record
	**/
	int WriteBufferOrListRid(ContainerClass *cont1, ShoreList *list1, ContainerClass *cont2);

	/**
	write record in ShoreList to buffer
	**/
	int WriteListRidToBuffer(ContainerClass *cont1, ShoreList *list1, ContainerClass *cont2);

	/**
	write records in container to buffer
	**/
	void WriteContainerToBuffer(ContainerClass *cont1,ContainerClass *cont2);

	/**
	construct MCCAS sub-structure
	if reset = true, then start from the beginning of buffer & list
	**/
	void ConstructSubMCCASByIndex(MCCASStackNode * node, int index, bool reset);

	/**
	set the scanCursor of a buffer
	**/
	void BackwardScan(ContainerClass * cont, int length);

	/**
	Merge sub-MCCAS associated with the given index
	**/
	bool MergeSubMCCAS(MCCASStackNode * node, int index);

	/**
	First time scan lists of a stack node asssociated to structure sign[index]
	**/
	void FirstTimeScan(MCCASStackNode * node, int index);

	/**
	Start scan when marge sub-MCCAS for record for newID
	**/
	void StartScanForNewID(MCCASStackNode * node, int index, int curList);

	/**
	Restart scan
	**/
	int RestartScan(MCCASStackNode * node, int index, int curList);

	/**
	current min ID from the array curMinIDs within the same structure as specified the signature
	**/
	int OverallMinID(bitset<MAX_NUM_VARIABLE> signature);

	/**
	write the data into buffer
	**/
	int WriteNodeIntoItsBuffer(MCCASStackNode * node);

	/**
	Yunyao: added for supporting optional MLCAS. Write null data (only IDs and length) into buffer.
	**/
	int WriteNullDataIntoBuffer(MCCASStackNode * node, bitset<MAX_NUM_VARIABLE> signature);

	/**
	Yunyao: added for supporting optional MLCAS. Judge the types of material difference between two signature;
	if the difference signature is material, but is contained by target, then it's target immaterial. Similarly,
	if it's contained by source, it's source immaterial; otherwise, it's material for both target and source
	**/
	int TypeOfMaterialDifference(bitset<MAX_NUM_VARIABLE> targetSign, bitset<MAX_NUM_VARIABLE> sourceSign);

	/**
	Added for supporting optional MLCAS
	Push an output candidate into the temp output stack before we can determine if it is a output
	Return SUCCESS if the output is added to the output stack successfully;
	Return FAILURE otherwise.
	**/
	int pushOutputCandidate(MCCASStackNode * output);

	/**
	Added for supporting optional MLCAS
	Output a node from the temp output stack 
	**/
	int outputCandidate();

	/**
	Calculate Record (list and buffer) Size of given index in node1
	**/
	int CalculateRecordSize(MCCASStackNode *node1, int index);

	/**
	Calculate entry size in list and buffer of  given index in cont
	**/
	int CalculateSubRecordSize(ContainerClass *cont, ShoreList *list);

	/**
	determine whether one of the input tree is NULL
	If one of the inputs is NULL, then no MCCAS can be found, stop calculation
	**/
	bool haveNullInput;

	/**
	an IteratorClass that produces input for this iterator.
	**/
	IteratorClass **inputs;
	
	/**
	DataManager
	**/
	DataMng *dataMng;

	/**
	Inputs array inTuples
	**/
	WitnessTree **inTuple;

	/**
	number of used nodes in outputArray
	**/
	int used;

	/**
	The size of outputArray
	**/
	int bufSize;

	/**
	Array that hold output in sortedOrder of startKS
	**/
	WitnessTree * outputArray;

	/**
	Array that hold output
	**/
	WitnessTree ** outputArrayOfWitnessTree;

	/**
	number of variables involved in the query
	**/
	int numInputs;

	/**
	estimated number of nodes for each input
	**/
	int expectedInputSize;

	/**
	A buffer that holds the output tree.
	**/
	WitnessTree *resultBuffer;

	int expectedDepth;

	/**
	There are complexListNodes in the input
	**/
	bool haveComplexInput;

	/**
	temporary stacks holding intermediate results
	**/
	stack<MCCASStackNode> * tempStack;

	/**
	temporary stacks holding output candidates, but is used as a queue at the time of output
	**/
	stack<MCCASStackNode> * tempOutputStack;

	/**
	minimum level of unprocessed input nodes
	**/
	KeyType minStartPos0;

	/**
	the position of scan cursor
	**/
	int pos;

	/**
	stop or not, set stop to true, when no more MCCAS can be generated
	**/
	bool stop;

	/**---------------------------------------------**/
	/** varibles for the new algorithm - start      **/
	/**---------------------------------------------**/
	serial_t startID;
	lvid_t volumeID;
	serial_t fileID;
	rc_t rc;

	bool fileCreated;
	ContainerClass ** readContainer;
	int ListNodeSize;
	int ComplexListNodeSize;

	/**
	copy of the latest output stack node without the buffer & list
	**/
	MCCASStackNode * copyOfLatestMCCAS;

	/**
	copy of the endPos of latest input that has been rejected
	**/
	KeyType copyOfLatestInvalidInputEndPos;

	/**
	first time scan the list
	**/
	bitset<MAX_NUM_VARIABLE> startScan;

	/**
	finished scan the list
	**/
	bitset<MAX_NUM_VARIABLE> finishScan;

	/**
	different element in the tempOutputStack
	**/
	bitset<MAX_NUM_VARIABLE> elementList;

	/**
	empty optioanl input
	**/
	bitset<MAX_NUM_VARIABLE> emptyElementList;

	/**
	start output candidatesin the tempOutputStack
	**/
	bool startOutput;

	/**
	the cursor for temp output stack
	**/
	int outputCursor;

	/**
	id of the record where current scan cursor each list is
	**/
	int curMaxIDs[MAX_NUM_VARIABLE];

	/**
	id of the record where current scan cursor each list is
	**/
	int curMinIDs[MAX_NUM_VARIABLE];

	/**
	id of the record where current scan cursor each list is
	**/
	int newMaxIDs[MAX_NUM_VARIABLE];

	/**
	id of the record where current scan cursor each list is
	**/
	int newMinIDs[MAX_NUM_VARIABLE];

	/**
	current minimux MaxID of the structure
	**/
	int curMinMaxID[MAX_NUM_VARIABLE];

	/**
	startPos of the next scan of container
	**/
	int curBufScanCursor[MAX_NUM_VARIABLE];

	/**
	startPos of the next scan of container
	**/
	serial_t curListScanCursor[MAX_NUM_VARIABLE];

	/**
	startPos of the next scan of container
	**/
	int newBufScanCursor[MAX_NUM_VARIABLE];

	/**
	startPos of the next scan of container
	**/
	serial_t newListScanCursor[MAX_NUM_VARIABLE];

	/**
	nre values
	**/
	NREType *nre;

	/**
	Marking which node(s) in the MLCAS is optional
	If isOptional[i] = true, then the corresponding node represented by nre[i] is optional;
	otherwise, it is mandatory
	**/
	bool *isOptional;
	/**
	annotation specification
	**/
	int *aSpecNum;

	NREType rootNRE;
	char *tmpStr;
	int numWrites;
};

#endif
