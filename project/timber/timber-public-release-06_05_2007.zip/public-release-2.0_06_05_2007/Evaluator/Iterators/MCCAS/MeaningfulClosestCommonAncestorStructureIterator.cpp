/*
COPYRIGHT  (c) 2000-2004 
THE REGENTS OF THE UNIVERSITY OF MICHIGAN
ALL RIGHTS RESERVED

PERMISSION IS GRANTED TO USE, COPY, CREATE DERIVATIVE WORKS AND
REDISTRIBUTE THIS SOFTWARE AND SUCH DERIVATIVE WORKS FOR NONCOMMERCIAL
EDUCATION AND RESEARCH PURPOSES, SO LONG AS NO FEE IS CHARGED, AND SO LONG
AS THE COPYRIGHT NOTICE ABOVE, THIS GRANT OF PERMISSION, AND THE
DISCLAIMER BELOW APPEAR IN ALL COPIES MADE; AND SO LONG AS THE NAME OF THE
UNIVERSITY OF MICHIGAN IS NOT USED IN ANY ADVERTISING OR PUBLICITY
PERTAINING TO THE USE OR DISTRIBUTION OF THIS SOFTWARE WITHOUT SPECIFIC,
WRITTEN PRIOR AUTHORIZATION.

THIS SOFTWARE IS PROVIDED AS IS, WITHOUT REPRESENTATION FROM THE
UNIVERSITY OF MICHIGAN AS TO ITS FITNESS FOR ANY PURPOSE, AND WITHOUT
WARRANTY BY THE UNIVERSITY OF MICHIGAN OF ANY KIND, EITHER EXPRESS OR
IMPLIED, INCLUDING WITHOUT LIMITATION THE IMPLIED WARRANTIES OF
MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE. THE REGENTS OF THE
UNIVERSITY OF MICHIGAN SHALL NOT BE LIABLE FOR ANY DAMAGES, INCLUDING
SPECIAL, INDIRECT, INCIDENTAL, OR CONSEQUENTIAL DAMAGES, WITH RESPECT TO
ANY CLAIM ARISING OUT OF OR IN CONNECTION WITH THE USE OF THE SOFTWARE,
EVEN IF IT HAS BEEN OR IS HEREAFTER ADVISED OF THE POSSIBILITY OF SUCH
DAMAGES.
*/

#include "MeaningfulClosestCommonAncestorStructureIterator.h"
//#include "../../textMng/TermExpansion/TermExpansion.h"

//using namespace std;

/**
* An access method that takes the input trees from several sources and find out the 
* meaningful closest common ancestor structures for the sets of nodes
* @see IteratorClass
* @see EvaluatorClass
* @see WitnessTree
* @see MCCASStackNode
* @author Yunyao Li
*/

//MeaningfulClosestCommonAncestorStructureIterator :: MeaningfulClosestCommonAncestorStructureIterator(IteratorClass **inputs,int numInputs, NREType *nre, bool *isOptional, NREType assignedNre, int expectedInputSize, DataMng *dataMng, int expectedDepth, serial_t fileID)
MeaningfulClosestCommonAncestorStructureIterator :: MeaningfulClosestCommonAncestorStructureIterator(IteratorClass **inputs,int numInputs, NREType *nre, char *aSpec, NREType assignedNre, int expectedInputSize, DataMng *dataMng, int expectedDepth, serial_t fileID)
{	
	// initialize the private variables
    this->inputs = inputs;
	this->numInputs = numInputs;
	numWrites = 0;
	fileCreated = true;
	this->fileID = fileID;
	if (expectedInputSize > 0)
		this->expectedInputSize = expectedInputSize;
	else
		this->expectedInputSize = gSettings->getIntegerValue("INITIAL_DEFAULT_DEPTH",16);
	
	if (expectedDepth > 0)
		this->expectedDepth = expectedDepth;
	else
		this->expectedDepth = gSettings->getIntegerValue("INITIAL_DEFAULT_DEPTH",16);

	this->isOptional = new bool[this->numInputs];
	this->aSpecNum = new int[this->numInputs];

	for (int i = 0; i < this->numInputs; i++)
	{
		switch(aSpec[i])
		{
		case '-':
			this->isOptional[i] = false;
			this->aSpecNum[i] = 0;
			break;
		case '?':
			this->isOptional[i] = true;
			this->aSpecNum[i] = 1;
			break;
		case '+':
			this->isOptional[i] = false;
			this->aSpecNum[i] = 2;
			break;
		case '*':
			this->isOptional[i] = true;
			this->aSpecNum[i] = 3;
			break;
		default:
			globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"MeaningfulClosestCommonAncestor",__FILE__,"Error input from file... expecting Annotation Specification (-,?,+,*)... MeaningfulClosestCommonAncestorStructure line...");
			return;
		}
	}

	//this->isOptional = isOptional;

	this->dataMng = dataMng;	
	this->volumeID = dataMng->getVolumeID();
	this->haveNullInput = false;
	this->haveComplexInput = false;
	this->minStartPos0 = MLCA_MAX;
	this->used = 0;
	this->bufSize = this->expectedInputSize;
	this->pos = 0;
	this->stop = false;
	this->copyOfLatestMCCAS = new MCCASStackNode;
	this->copyOfLatestMCCAS->SetListsVolumeAndFileIDs(volumeID, fileID,numInputs);
	this->copyOfLatestInvalidInputEndPos = -1;
	this->startScan.reset();
	this->finishScan.reset();
	this->elementList.reset();
	this->startOutput = false;
	this->emptyElementList.reset();
	this->outputCursor = 0;
	this->outputArray = new WitnessTree;
	this->outputArray->SetUsed(this->numInputs + 1);
	this->nre = nre;
	this->rootNRE = assignedNre;

	this->inTuple = new WitnessTree * [numInputs];
	this->tempStack = new stack<MCCASStackNode>(this->expectedInputSize);
	this->tempOutputStack = new stack<MCCASStackNode>(this->expectedInputSize);

	tmpStr = new char[gSettings->getIntegerValue("CONTAINER_SIZE",CONTAINER_SIZE_DEFAULT)];
	readContainer = NULL;

	for (int i = 0; i < this->numInputs; i++)
	{
		inputs[i]->next(inTuple[i]);

		// if one of the mandatory input is empty
		if (!this->inTuple[i])
		{
			if (!this->isOptional[i])
			{
				this->haveNullInput = true;
				break;
			}
			else
			{
				emptyElementList.set(i);
			}
		}

		// if one of the input is complexListNode
		if (this->inTuple[i] && !this->inTuple[i]->isSimple())
		{
			this->haveComplexInput = true;
		}	

		this->curMaxIDs[i] = -1;
		this->curMinIDs[i] = -1;
		this->curMinMaxID[i] = 10000;
	}

	// set up NRE table for the output witnessTree, 
	// this table will remain the same for all the output
	// therefore is only set up once
	this->outputArrayOfWitnessTree = new WitnessTree * [numInputs + 1];


    for (int i = 0; i < this->numInputs + 1; i++)
	{
		this->outputArrayOfWitnessTree[i] = new WitnessTree(LIST_NODE_WITH_DATA,dataMng);
	}

	this->ListNodeSize = sizeof(ListNode);
	this->ComplexListNodeSize = sizeof(ComplexListNode);

	resultBuffer = new WitnessTree(LIST_NODE_WITH_DATA,dataMng);

	if (!this->haveNullInput)
	{
		readContainer = new ContainerClass * [this->numInputs];

		for (int i = 0; i < this->numInputs; i++)
		{
			readContainer[i] = new ContainerClass;
		}

		fileCreated = true;
		int maxIDs = gSettings->getIntegerValue("MAX_ID_PER_FILE_STRUCTURAL_JOINS",10000);
		rc = ss_m::create_id(volumeID,maxIDs,startID);
		
		if (rc) 
		{
			// error of creating id
			stringstream msg;
			msg<<rc<<'\0';
			globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"Evaluator",__FILE__,msg.rdbuf()->str().c_str());
			this->haveNullInput = true;
			return;				
		}	
		numWrites = maxIDs;
	}
}

/**
Destructor
frees the output buffer and so.
**/
MeaningfulClosestCommonAncestorStructureIterator :: ~MeaningfulClosestCommonAncestorStructureIterator()
{
	if (resultBuffer)
	{
		delete resultBuffer;

		if (outputArray)
			delete outputArray;
	}

	if (tmpStr) delete [] tmpStr;

	if (copyOfLatestMCCAS)
		delete copyOfLatestMCCAS;

	if (this->tempStack)
	{		
		delete this->tempStack;
	}

	/*if (this->tempOutputStack)
	{		
		delete this->tempOutputStack;
	}*/

	if (this->outputArrayOfWitnessTree)
	{
	    for (int i = 0; i < this->numInputs + 1; i++)
			delete this->outputArrayOfWitnessTree[i];

		delete [] outputArrayOfWitnessTree;
	}

	if (this->readContainer)
	{	
		/* for (int i = 0; i < this->numInputs; i++)
			if (this->readContainer[i]) 
				delete this->readContainer[i];*/
		delete [] readContainer;
	}

	if (inTuple)
	{
		delete [] inTuple;
	}
		// destroy the file, if any has been created	
	if (fileCreated)
	{
		rc = ss_m::destroy_file(volumeID, fileID,true,numWrites);
		
		if (rc) 
		{
			// error when destroying file
			stringstream msg;
			msg<<rc<<'\0';
			globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"Evaluator",__FILE__,msg.rdbuf()->str().c_str());
			return;				
		}
	}

	if (inputs)
	{
		for (int i=0; i<numInputs; i++)
			if (inputs[i]) delete inputs[i];
	
		delete [] inputs;
	}

	if (isOptional)
		delete [] isOptional;

	if (aSpecNum)
		delete [] aSpecNum;
}
	
/**
Access Method
gets the next output tree from this iterator.
@param node is a pointer that well be set to the output buffer or NULL (indicating that
there are no more results).
**/
void MeaningfulClosestCommonAncestorStructureIterator :: next(WitnessTree *&node)
{
#ifdef EVAL_TIME_OUT
	clock_t currTime = clock();
	double queryDuration = (double)(currTime - gQueryStartTime) / CLOCKS_PER_SEC;
	if (queryDuration >= gTimeOutAfter)
	{
		globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"Evaluator",__FILE__,"Query Timed Out.");
		node = NULL;
		return;
	}
#endif
	bool merged = true;
	ComplexListNode * complexTempRoot;
	ListNode * tempRoot;
	int i;

	// empty the buffer
	this->resultBuffer->initialize();

	if (this->haveNullInput && this->copyOfLatestMCCAS->IsEmpty())
	{	
		node = NULL;
		return;	
	}
	else
	{		
		// if a copy of LatestMCCAS exists
		// a copy of latest MCCAS is a rootedTree which contains all the MLCAS with the same root
		if (!this->copyOfLatestMCCAS->IsEmpty())
		{	
			// construct MLCAS from the copy first
			// scan each list from start to end
			// there are multiple level of internal loops here
			for (i = 0; i < this->copyOfLatestMCCAS->GetNumOfStructure(); i++)
			{	
				if(!this->MergeSubMCCAS(this->copyOfLatestMCCAS, i))
				{	
					if (i < this->copyOfLatestMCCAS->GetNumOfStructure() - 1)
					{
						if (this->RestartScan(this->copyOfLatestMCCAS, i, this->numInputs) == FAILURE)
						{
							node = NULL;
							return;
						}					
					}
					else
					{
						merged = false;	
						break;
					}
				}
				else
				{
					break;
				}
			}
			
			// output the merged MLCAS
			if (merged)
			{							
				// copy the root of MLCAS
				this->resultBuffer->appendList((ComplexListNode *)this->outputArrayOfWitnessTree[numInputs]->getBuffer(), this->dataMng, this->outputArrayOfWitnessTree[numInputs]->length(), true);

				// copy the output array of witness trees to the output buffer
				for (i = 0; i < this->numInputs; i++)
				{
					this->resultBuffer->appendList((ComplexListNode *)this->outputArrayOfWitnessTree[i]->getBuffer(), this->dataMng, this->outputArrayOfWitnessTree[i]->length(), true);				
				}

				node = this->resultBuffer;

				// if all the MLCAS contained in the copy have been constructed
				// delete the copys
				if (this->finishScan.count() == (unsigned)this->numInputs)
				{
					this->copyOfLatestMCCAS->ResetEmpty();					
				}

				return;
			}
		} 

		// if no copy exists, find one
		if (this->FindMCCAS())
		{		
			for (i = 0; i < this->numInputs; i++)
			{
				this->outputArrayOfWitnessTree[i]->deleteAllNodes();
			}

			for (i = 0; i < this->copyOfLatestMCCAS->GetNumOfStructure(); i++)
			{
				this->MergeSubMCCAS(this->copyOfLatestMCCAS, i);
			}

			// initialize the buffer
			this->outputArrayOfWitnessTree[this->numInputs]->SetUsed(0);

			// copy the root node of MLCAS
			if (this->copyOfLatestMCCAS->isSimple())
			{		
				tempRoot = this->copyOfLatestMCCAS->GetActualAncs();
				tempRoot->setNRE(this->rootNRE);
				this->outputArrayOfWitnessTree[this->numInputs]->appendList(tempRoot,1, false);
				this->resultBuffer->appendList(tempRoot, 1, true);
			}
			else
			{				
				complexTempRoot = this->copyOfLatestMCCAS->GetActualAncsComplex();
				complexTempRoot->setNRE(this->rootNRE);
				this->outputArrayOfWitnessTree[this->numInputs]->appendList(complexTempRoot, this->dataMng, 1, false);
				this->resultBuffer->appendList(complexTempRoot, this->dataMng, 1, true);
			}
			
			// copy the output array of witnesstrees to the output buffer
			for (i = 0; i < this->numInputs; i++)
			{
				this->resultBuffer->appendList((ComplexListNode *)this->outputArrayOfWitnessTree[i]->getBuffer(), this->dataMng, this->outputArrayOfWitnessTree[i]->length(), true);				
			}
		
			node = this->resultBuffer;

			//this->resultBuffer->dumpBuffer(stdout,false)

			return;
		}          
		else
		{
			node = NULL;
			return;
		}	
	}
}

/**
get the parent node of an input node
**/
void MeaningfulClosestCommonAncestorStructureIterator :: GetParentNode(ComplexListNode * child, ComplexListNode *& parent)
{
	WitnessTree * inputArray;
	inputArray = new WitnessTree(LIST_NODE_WITH_DATA,dataMng);
	inputArray->insertNode(0, child, dataMng);
	char fileIndex = ((ComplexListNode *)inputArray->getNodeByIndex(0))->getFileIndex();	
	int r = EvaluatorClass::getAncs(inputArray,0,1,dataMng,EvaluatorClass::getFileID(fileIndex));
	memcpy(parent,inputArray->getNodeByIndex(r),sizeof(ComplexListNode));
	delete inputArray;
}

/**
get the parent node of an input node
**/
void MeaningfulClosestCommonAncestorStructureIterator :: GetParentNode(ListNode * child, ListNode * parent)
{
	WitnessTree * inputArray;
	inputArray = new WitnessTree;
	inputArray->insertNode(0, child);
	char fileIndex = ((ListNode *)inputArray->getNodeByIndex(0))->getFileIndex();	
	int r = EvaluatorClass::getAncs(inputArray,0,1,dataMng,EvaluatorClass::getFileID(fileIndex));
	memcpy(parent,inputArray->getNodeByIndex(r),sizeof(ListNode));
	delete inputArray;
}    


/**
expand a input node into a new stacknode and push it into stack2
**/
void MeaningfulClosestCommonAncestorStructureIterator :: PushInputAsNewStackNode(int setNum)
{
	int curMaxID = 0;
	bitset<MAX_NUM_VARIABLE> newSignature, resultSign;
	newSignature.reset();
	newSignature.set(setNum);
	bool isMaterial = false;
	int index = -1;
	
	if (this->tempStack->IsEmpty())
	{
		curMaxID = 0;		
	}
	else
	{
		MCCASStackNode * stackTop;
		stackTop = this->tempStack->GetTop();

		switch (stackTop->TypeOfRelationship(newSignature, this->isOptional, isMaterial, index, false))
		{
			// one of structures already contains the same keyword
			case SUBSUMED_BY:			
				for (int i = 0; i < stackTop->GetNumOfStructure(); i++)
				{
					resultSign = stackTop->GetSignByIndex(i) & newSignature;
					
					if (resultSign.any())
					{
						curMaxID = stackTop->GetGlobalMax();
						curMaxID++;
						break;
					}
				}
				break;
			// one of the structure is the same as the one contained by the stack top
			case EQUAL:	
				for (int i = 0; i < stackTop->GetNumOfStructure(); i++)
				{
					resultSign = stackTop->GetSignByIndex(i) & newSignature;
					
					if (resultSign.any())
					{
						curMaxID = stackTop->GetMaxByIndex(setNum);
						break;
					}
				}
				break;
			// the stack top does not contain the new keyword
			case NO_OVERLAP:
				curMaxID = stackTop->GetGlobalMin();
				break;
		}
	}
		
	if (!this->inTuple[setNum]->isSimple())
		this->tempStack->Push((ComplexListNode *)this->inTuple[setNum]->findNodeNRE(nre[setNum]));
	else
		this->tempStack->Push((ListNode *)this->inTuple[setNum]->findNodeNRE(nre[setNum]));

	//  copy the input witnessTree
	this->tempStack->GetTop()->SetActualAncsWithSubtree(this->inTuple[setNum]);

	// set up global maxID so far
	this->tempStack->GetTop()->SetGlobalMin(curMaxID);
	this->tempStack->GetTop()->SetGlobalMax(curMaxID);
	this->tempStack->GetTop()->SetMaxByIndex(setNum, curMaxID);
	this->tempStack->GetTop()->SetMinByIndex(setNum, curMaxID);
    
	// set volume & fileID info
	this->tempStack->GetTop()->SetListsVolumeAndFileIDs(volumeID, fileID,numInputs);
	
	// initialize the buffers & link lists
	for (int i = 0; i < this->numInputs; i++)
	{
		this->tempStack->GetTop()->SetBufferByIndex(i);
		this->tempStack->GetTop()->SetListByIndex(i);
	}	

	// add the input node into the corresponding keyword buffer
	this->tempStack->GetTop()->SetSignByIndex(0, newSignature);
	this->tempStack->GetTop()->SetNumOfStructure(1);
    this->tempStack->GetTop()->SetSignature(newSignature);
	this->tempStack->GetTop()->SetKey();
	this->tempStack->GetTop()->SetKeyValue(setNum);
}

void MeaningfulClosestCommonAncestorStructureIterator :: PushInput(int setNum)
{
	if (this->tempStack->IsEmpty())
	{
		this->PushInputAsNewStackNode(setNum);
		return;
	}
	
	int curLevel, newLevel;
	
	MCCASStackNode * stackTop;	

	// if there is a node being rejected before the current input
	if (this->copyOfLatestInvalidInputEndPos != -1)
	{
		// reject all the nodes that are descendant of it
		if (this->inTuple[setNum]->isSimple())
		{
			if (this->copyOfLatestInvalidInputEndPos > ((ListNode *)this->inTuple[setNum]->findNodeNRE(nre[setNum]))->GetEndPos())
			{
				return;
			}
		}
		else
		{
			if (this->copyOfLatestInvalidInputEndPos > ((ComplexListNode *)this->inTuple[setNum]->findNodeNRE(nre[setNum]))->GetEndPos())
			{
				return;
			}
		}			
	}

	this->copyOfLatestInvalidInputEndPos = -1; 

	if (this->inTuple[setNum]->isSimple())
	{
		// if popStack
		if(popStack(((ListNode *)this->inTuple[setNum]->findNodeNRE(nre[setNum]))->GetStartPos()) == SUCCESS)
		{   
			this->PushInputAsNewStackNode(setNum);
			return;
		}
		else
		{		
			stackTop = this->tempStack->GetTop();

			if (stackTop->isSimple())
				curLevel = stackTop->GetActualAncs()->GetLevel();
			else
				curLevel = stackTop->GetActualAncsComplex()->GetLevel();

			newLevel = ((ListNode *)this->inTuple[setNum]->findNodeNRE(nre[setNum]))->GetLevel();

			this->PushInputAsNewStackNode(setNum);
			return;
		}
	}
	else
	{
		// if popStack
		if(popStack(((ComplexListNode *)this->inTuple[setNum]->findNodeNRE(nre[setNum]))->GetStartPos()) == SUCCESS)
		{
			this->PushInputAsNewStackNode(setNum);
			return;
		}
		else
		{	
			stackTop = this->tempStack->GetTop();

			if (stackTop->isSimple())
				curLevel = stackTop->GetActualAncs()->GetLevel();
			else
				curLevel = stackTop->GetActualAncsComplex()->GetLevel();

			newLevel = ((ComplexListNode *)this->inTuple[setNum]->findNodeNRE(nre[setNum]))->GetLevel();

			this->PushInputAsNewStackNode(setNum);
			return;
		}
	}
}

int MeaningfulClosestCommonAncestorStructureIterator :: CopyList(MCCASStackNode * source, MCCASStackNode * target)
{
	target->SetSignature(target->GetSignature() | source->GetSignature());

	for (int i = 0; i < this->numInputs; i++)
	{
		if ( source->BufferExistsAndNotEmpty(source->GetBufferByIndex(i))
			|| !(source->EmptyListOfBuffers(source->GetListByIndex(i))))
		{	
			// we are writing a list head and tail
			if (!source->GetListByIndex(i)->IsEmpty())
			{
				source->GetListByIndex(i)->StartScan();

				// write buffer of target into its list
				if (target->BufferExistsAndNotEmpty(target->GetBufferByIndex(i)))
				{
					if (WriteBufferToItsList(target->GetBufferByIndex(i),target->GetListByIndex(i)) == FAILURE)
						return FAILURE;
				}

				target->GetListByIndex(i)->AppendToList(source->GetListByIndex(i));

				// write container of source into target
				if (source->BufferExistsAndNotEmpty(source->GetBufferByIndex(i)))
				{
					if (WriteBufferToItsList(source->GetBufferByIndex(i),target->GetListByIndex(i)) == FAILURE)
						return FAILURE;
				}

				target->GetListByIndex(i)->StartScan();
				target->GetBufferByIndex(i)->Initialize();
			}
			else
			{
				int recSize;          
				recSize = CalculateRecordSize(source, i);

				if (!(target->GetBufferByIndex(i)->EnoughSpace(recSize)))
				{
					// write buffer of target into its list
					if (WriteBufferToItsList(target->GetBufferByIndex(i),target->GetListByIndex(i)) == FAILURE)
						return FAILURE;

					// copy container
					target->GetBufferByIndex(i)->CopyContainer(source->GetBufferByIndex(i));
				}
				else
				{									
					WriteContainerToBuffer(source->GetBufferByIndex(i),target->GetBufferByIndex(i));
				}
			}
		}
	}

	return SUCCESS;
}


/*int StackBasedAncsProjAncs::CopyLists(SBJoinAncsProjAncsStackNode *source, SBJoinAncsProjAncsStackNode *target)
{
	int recSize;

		recSize = CalculateSubRecordSize(source->GetDescBuffer(),source->GetDescList());
	if (recSize != 0)
	{
		
		}
		else
		{
			if (!(target->EnoughSpace(target->GetDescBuffer(),recSize)))
			{
				if (WriteBufferToItsList(target->GetDescBuffer(),target->GetDescList()) == FAILURE)
					return FAILURE;
			}
		}

		if (WriteBufferOrListRid(source->GetDescBuffer(),source->GetDescList(),
								target->GetDescBuffer(),target->GetDescList()) == FAILURE)
								return FAILURE;
	}
	return SUCCESS;
}*/

int MeaningfulClosestCommonAncestorStructureIterator::CalculateRecordSize(MCCASStackNode *node1, int idx)
{
	int recSize = 0;

	//recSize += sizeof(*(node1->GetActualAncsWithSubtree())) ; 
	recSize += CalculateSubRecordSize(node1->GetBufferByIndex(idx), node1->GetListByIndex(idx));
	//recSize += sizeof(int);   // the size itself	
	return recSize; 
}

int MeaningfulClosestCommonAncestorStructureIterator::CalculateSubRecordSize(ContainerClass *cont, ShoreList *list)
{
	int recSize = 0;

	if (list->IsEmpty())
		recSize += (cont->GetAddCursor());
	else
		recSize += (2*sizeof(serial_t));

	return recSize;
}

int MeaningfulClosestCommonAncestorStructureIterator::WriteBufferOrListRid(ContainerClass *cont1, ShoreList *list1, 
										  ContainerClass *cont2)
{
	if (!(list1->IsEmpty()))
	{
		return WriteListRidToBuffer(cont1,list1,cont2);
	}
	else
	{
		WriteContainerToBuffer(cont1,cont2);		
		return SUCCESS;
	}
}


int MeaningfulClosestCommonAncestorStructureIterator::WriteListRidToBuffer(ContainerClass *cont1, ShoreList *list,
											  ContainerClass *cont2)
{
	if (WriteBufferToItsList(cont1,list) == FAILURE)
		return FAILURE;

	serial_t h = list->GetHead();
	serial_t t = list->GetTail();
	MCCASStackNode::AddToBuffer(cont2,(char *) (&(h)),sizeof(list->GetHead()));
	MCCASStackNode::AddToBuffer(cont2,(char *) (&(t)),sizeof(list->GetTail()));
	return SUCCESS;
}

void MeaningfulClosestCommonAncestorStructureIterator::WriteContainerToBuffer(ContainerClass *cont1,
											  ContainerClass *cont2)
{
	if (cont1->IsEmpty())
		return;

	int length = cont1->GetAddCursor();
//	char tmpStr[PAGESIZE];
	cont1->GetData(0,length,tmpStr);
	MCCASStackNode::AddToBuffer(cont2,tmpStr,length);
	cont1->Initialize();
}

int MeaningfulClosestCommonAncestorStructureIterator::pushOutputCandidate(MCCASStackNode * output)
{
	MCCASStackNode * stackTop, * output1;

	// if the stack is initially empty
	if (tempOutputStack->IsEmpty())
	{
		// push the output candidate onto the stack
		this->tempOutputStack->Push(output);

		stackTop = tempOutputStack->GetTop();

		if (stackTop->IsKey())
		{	
			if (this->WriteNodeIntoItsBuffer(stackTop) == FAILURE)
				return FAILURE;
		}

		elementList |= output->GetSignature();
		return SUCCESS;
	}

	stackTop = tempOutputStack->GetTop();
	output1 = this->tempOutputStack->GetByIndex(tempOutputStack->Size() - 2);

	// the new output candidate has additional optional node information that doesn't contained by any stack node yet
	if ((this->elementList ^ output->GetSignature()).any())
	{
		// discard all the output candidates that are descendant of the new output candidate		
		while (output->GetActualAncs()->isAncsOf(stackTop->GetActualAncs()))
		{
			this->tempOutputStack->Pop();

			if (tempOutputStack->Size() > 0)
				stackTop = tempOutputStack->GetTop();
			else
				break;
		}

		// push the output candidate onto the stack
		this->tempOutputStack->Push(output);

		stackTop = tempOutputStack->GetTop();
		output1 = this->tempOutputStack->GetByIndex(tempOutputStack->Size() - 1);

		if (stackTop->IsKey())
		{	
			if (this->WriteNodeIntoItsBuffer(stackTop) == FAILURE)
				return FAILURE;
		}

		elementList |= output->GetSignature();
		return SUCCESS;
	}
	else
	{
		// record the elements in the stack node whose head is a descendant of incoming candidate
		bitset<MAX_NUM_VARIABLE> descendantElementList;
		descendantElementList.reset();

		int i = tempOutputStack->Size() - 1;

		while(i >= 0)
		{
			if (output->GetActualAncs()->isAncsOf(tempOutputStack->GetByIndex(i)->GetActualAncs()))
			{
				descendantElementList |= tempOutputStack->GetByIndex(i)->GetSignature();
				i--;
			}
			else
				break;
		}

     	// the new output candidate has additional optional node information that doesn't contained by any stack node yet
		if ((descendantElementList ^ output->GetSignature()).any())
		{
			// discard all the output candidates that are descendant of the new output candidate		
			while (output->GetActualAncs()->isAncsOf(stackTop->GetActualAncs()))
			{
				this->tempOutputStack->Pop();
				stackTop = tempOutputStack->GetTop();
			}

			// push the output candidate onto the stack
			this->tempOutputStack->Push(output);

			stackTop = tempOutputStack->GetTop();
			output1 = this->tempOutputStack->GetByIndex(tempOutputStack->Size() - 2);

			if (stackTop->IsKey())
			{	
				if (this->WriteNodeIntoItsBuffer(stackTop) == FAILURE)
					return FAILURE;
			}

			elementList |= output->GetSignature();
			return SUCCESS;		
		}
		else
			return FAILURE;
	}
}

int MeaningfulClosestCommonAncestorStructureIterator :: outputCandidate()
{
	MCCASStackNode * output, * popped;

	// all the nodes in the stack have been output, empty the stack

	if (outputCursor == tempOutputStack->Size())
	{
		tempOutputStack->Initialize();
		elementList.reset();
		this->outputCursor = 0;
		this->startOutput = false;
		return FAILURE;
	}
	// the stack is empty
	else if (tempOutputStack->IsEmpty())
	{
		return FAILURE;
	}
	else
	{
		this->copyOfLatestMCCAS->ResetEmpty();
		this->copyOfLatestMCCAS->initialize();

		this->startScan.reset();
		this->finishScan.reset();

		output = this->tempOutputStack->GetByIndex(this->outputCursor);
		this->copyOfLatestMCCAS->CopyStackNode(output);

		if (this->CopyList(output, this->copyOfLatestMCCAS) == FAILURE)
			return FAILURE;

		this->copyOfLatestMCCAS->SetEmpty();	

		// update the output cursor
		this->outputCursor++;

		// can stop computing & start to output now
		this->stop = true;
							
		return SUCCESS;
	}	
}

/**
 Pop stack
 **/
int MeaningfulClosestCommonAncestorStructureIterator :: popStack(KeyType startPosition)
{
	MCCASStackNode * stackTop, * copyStackTop;
	MCCASStackNode * nextStackNode; // the node right below stack top

	if (this->tempStack->IsEmpty())
		return FAILURE;

	if (startPosition == -1)
		// this means POP all
		startPosition = MLCA_MAX;

	stackTop = this->tempStack->GetTop();

	while ((startPosition > this->tempStack->GetTop()->GetActualAncs()->GetEndPos()||startPosition == -1) && !this->tempStack->IsEmpty())
	{
		// pop top element in the stack
		stackTop = this->tempStack->GetTop();

		if (stackTop->IsMCCAS(this->numInputs, this->isOptional))
		{
			//TODO: clearn up: it seems we can ignore the condition this->copyOfLatestMCCAS->IsEmpty() here
			// there is no MCCAS found so far
			/*if (this->copyOfLatestMCCAS->IsEmpty())
			{
				// added for supporting optional MLCAS
				// if the stackTop already contains all the mandatory elements and non-empty optional element
				bitset<MAX_NUM_VARIABLE> resultOR = stackTop->GetSignature() | emptyElementList;
				
				for (int i = 0; i < this->numInputs; i++)
					resultOR.flip(i);
				
				if (resultOR.none())
				{
					// todo: consider the situation where tempOuptutStack is empty
					// push the current top onto the temp output stack
					pushOutputCandidate(this->tempStack->Pop());

					this->startOutput = true;

					// reset global max
					while(!this->tempStack->IsEmpty())
						this->tempStack->Pop();

					// and start output
					return outputCandidate();
				}
				else
				{
					// push the current top onto the temp output stack
					// current top is a output candidate and is successfully added to the temp output stack
					pushOutputCandidate(stackTop);
				}
			}
			else
			{*/
				if (stackTop->GetActualAncs()->isAncsOf(this->copyOfLatestMCCAS->GetActualAncs()))
				{
					this->stop = false;
				}
				else
				{					
					/*if (stackTop->IsKey())
					{						
						if (this->WriteNodeIntoItsBuffer(stackTop) == FAILURE)
							return FAILURE;
					}*/

					// added for supporting optional MLCAS
					// if the stackTop already contains all the mandatory elements and non-empty optional element
					bitset<MAX_NUM_VARIABLE> resultOR = stackTop->GetSignature() | emptyElementList;
					
					//for (int i = 0; i < this->numInputs; i++)
					//	resultOR.flip(i);
					
					//if (resultOR.none())
					if (resultOR.count() == (unsigned)this->numInputs)
					{
						// push the current top onto the temp output stack
						pushOutputCandidate(this->tempStack->Pop());

						this->startOutput = true;

						// reset global max
						while(!this->tempStack->IsEmpty())
							this->tempStack->Pop();
						stackTop->SetGlobalMax(0);

						// and start output
						return outputCandidate();
					}
					else
					{
						// there are more than 1 node on the stack
						if (this->tempStack->Size() == 1)
						{
							// if the current stack top is not an output candidate
							// no output candidate can be constructed any more
							copyStackTop = new MCCASStackNode;
							copyStackTop->CopyStackNode(stackTop);
							CopyList(stackTop, copyStackTop);
							if (pushOutputCandidate(copyStackTop) != SUCCESS)
							{
								delete copyStackTop;

								// empty the stack
								this->startOutput = true;

								// reset global max
								while(!this->tempStack->IsEmpty())
									this->tempStack->Pop();
								stackTop->SetGlobalMax(0);

								// and start output
								return outputCandidate();
							}
						}
						else
						{
							nextStackNode = this->tempStack->GetByIndex(this->tempStack->Size() - 2);
							
							bool isMaterial;
							isMaterial = false;
							bool optionalCount;
							optionalCount = true;
							int typeOfRelationship;
							int index;
							
							typeOfRelationship = nextStackNode->TypeOfRelationship(stackTop->GetSignature(), this->isOptional, isMaterial,index,optionalCount);
							// if non optional nodes are the same
							if (typeOfRelationship != NO_OVERLAP && !isMaterial)
							{						
								if (nextStackNode->GetNumOfStructure() == 1 &&
									nextStackNode->GetActualAncs()->isParentOf(stackTop->GetActualAncs()))
								{
									// combination of the two nodes contains all input node
									// no more new MLCAS can be constructed
									bitset<MAX_NUM_VARIABLE> resultOR = stackTop->GetSignature() | nextStackNode->GetSignature() | emptyElementList;
									if (resultOR.count() == (unsigned)this->numInputs)
									{    
										// push the current top onto the temp output stack
										pushOutputCandidate(this->tempStack->Pop());

										this->startOutput = true;

										// reset global max
										while(!this->tempStack->IsEmpty())
											this->tempStack->Pop();
										stackTop->SetGlobalMax(0);

										// and start output
										return outputCandidate();
									}
									else
									{
										// push the current top onto the temp output stack
										copyStackTop = new MCCASStackNode;
										copyStackTop->CopyStackNode(stackTop);
										CopyList(stackTop, copyStackTop);
										if (pushOutputCandidate(copyStackTop) != SUCCESS)
										{
											delete copyStackTop;
											// empty the stack
											this->startOutput = true;

											// reset global max
											while(!this->tempStack->IsEmpty())
												this->tempStack->Pop();
											stackTop->SetGlobalMax(0);

											// and start output
											return outputCandidate();
										}
									}
								}							
								// if nextStackNode contains some non-optional node not contained by the stackNode in seperate structure
								// such node should be combined with structures in stackNode to form MLCAS
								// thus don't put stackTop as outputCandidate	
							}
							else if (typeOfRelationship != NO_OVERLAP && isMaterial)
							{
								// push the current top onto the temp output stack
								copyStackTop = new MCCASStackNode;
								copyStackTop->CopyStackNode(stackTop);
								CopyList(stackTop, copyStackTop);
								if (pushOutputCandidate(copyStackTop) != SUCCESS)
								{
									delete copyStackTop;

									// empty the stack
									this->startOutput = true;

									// reset global max
									while(!this->tempStack->IsEmpty())
										this->tempStack->Pop();
									stackTop->SetGlobalMax(0);

									// and start output
									return outputCandidate();
								}
							}
						}
					}
				}
			//}
		}
		// there is no other element in the stack
		// or the next element in the stack is not a parent node of the current stack top
		// and the node is not the root of the XML document yet
		if (this->tempStack->GetTop()->GetActualAncs()->GetLevel() > 1 &&
			(this->tempStack->Size() == 1 ||
			!this->tempStack->GetByIndex(this->tempStack->Size()-2)->GetActualAncs()->isParentOf(this->tempStack->GetTop()->GetActualAncs())))
		{
			// replace the node with its parent node
			stackTop = this->tempStack->GetTop();
			if (this->ReplaceWithParentNode(stackTop) == FAILURE)
				return FAILURE;
			this->tempStack->GetTop()->ResetKey();
		}
		else if (this->tempStack->Size() > 1)
		{
			MCCASStackNode * poped;
			poped = NULL;
			poped = this->tempStack->Pop();
			stackTop = this->tempStack->GetTop();

			if (this->InsertStackNode(poped, stackTop) == FAILURE)
				return FAILURE;
		}
		else
		{
			if (this->tempStack->Size() > 0)
			{
				this->tempStack->Pop();
				break;
			}
			else
				break;
		}
	}

	return FAILURE;
}

/**
find the node with maxLevel and minStartKey from unprocessed input nodes
**/
void MeaningfulClosestCommonAncestorStructureIterator :: findInput(int &setNum)
{
	int i;
	KeyType minTempStartPos = MLCA_MAX;
	ListNode * temp;
	ComplexListNode * complexTemp;

	setNum = -1;

	this->haveNullInput = true;

	for (i = 0; i < this->numInputs; i++)
	{			
		// if tempStack is empty, we are computing new MLCASs
		// if we have already processed all input nodes of inTuple[i]
		//   and inTuple[i] is mandatory for all the inputs, i.e. annotation is "-" or "+"
		// we can guaranttee that no new MLCASs can be computated
		// therefore, we can stop computation now to reduce computational cost
		if (!this->inTuple[i])
		{
			if ((this->aSpecNum[i] == 0 || this->aSpecNum[i] == 2) && this->tempStack->IsEmpty())
			{
				this->haveNullInput = true;
				setNum = -1;
				return;
			}
			else
				continue;
		}
		else
		{
			if (this->inTuple[i]->isSimple())
			{				
				temp = (ListNode *)this->inTuple[i]->findNodeNRE(nre[i]);
	            			
				this->haveNullInput = false;

				if (temp->GetStartPos() < minTempStartPos)
				{
					minTempStartPos = temp->GetStartPos();
					setNum = i;										
				}
			}
			else
			{						
				complexTemp = (ComplexListNode *)this->inTuple[i]->findNodeNRE(nre[i]);
	            
				this->haveNullInput = false;

				if (complexTemp->GetStartPos() < minTempStartPos)
				{
						minTempStartPos = complexTemp->GetStartPos();
						setNum = i;	
				}
			}	
		}  
	}

	// no input node could be found
	if (setNum == -1)
	{
		return;
	}
	
	this->minStartPos0 = minTempStartPos;    
}

int MeaningfulClosestCommonAncestorStructureIterator::WriteBufferToItsList(ContainerClass *cont, ShoreList *list)
{
	if (cont->IsEmpty())
		return SUCCESS;

	if (list->IsEmpty())
	{
		serial_t currRecID = startID;

		if (startID.increment(1) == true)
			//overflow of shore logical ids
		{
			globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"Evaluator",__FILE__,"Shore Logical ID overflow.");
			return FAILURE;
		}

		if (MCCASStackNode::WriteBufferToList(cont,list,fileID,volumeID,currRecID,startID) == FAILURE)
			return FAILURE;

		if (startID.increment(1) == true)
			//overflow of shore logical ids
		{
			globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"Evaluator",__FILE__,"Shore Logical ID overflow.");
			return FAILURE;
		}
	}
	else
	{
		if (MCCASStackNode::WriteBufferToList(cont,list,startID) == FAILURE)
			return FAILURE;
		
		if (startID.increment(1) == true)
			//overflow of shore logical ids
		{
			globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"Evaluator",__FILE__,"Shore Logical ID overflow.");
			return FAILURE;
		}
	}
	cont->Initialize();
	return SUCCESS;
}

int MeaningfulClosestCommonAncestorStructureIterator::ReplaceWithParentNode(MCCASStackNode * child)
{	
	bitset<MAX_NUM_VARIABLE> signature;
	signature.reset();

	if (this->WriteNodeIntoItsBuffer(child) == FAILURE)
		return FAILURE;
	
	if (child->isSimple())
	{
		ListNode * parent;
		parent = new ListNode;
		this->GetParentNode((ListNode *)child->GetActualAncs(), parent);
		
		if (child->IsKey())
		{
			child->ResetKey();
		}
		
		child->SetActualAncs(parent);

		delete parent;
	}
	else
	{
		ComplexListNode * parent;
		parent = new ComplexListNode;
		this->GetParentNode((ComplexListNode *)child->GetActualAncsComplex(), parent);
		
		if (child->IsKey())
		{
			child->ResetKey();
		}

		child->SetActualAncsComplex(parent);

		delete parent;
	}

	return SUCCESS;
}

int  MeaningfulClosestCommonAncestorStructureIterator:: WriteNodeIntoItsBuffer(MCCASStackNode * node)
{
	bitset<MAX_NUM_VARIABLE> signature;
	WitnessTree * tempTree;
	WitnessTree * tempComplexTree;
	
	int length;

	if (node->IsKey())
	{
		node->ResetKey();

		tempComplexTree = new WitnessTree(LIST_NODE_WITH_DATA,dataMng);
		int setNum = node->GetKeyValue();
		int minID = node->GetGlobalMin();
		int maxID = node->GetGlobalMax();

		if (!(node->GetBufferByIndex(setNum)->EnoughSpace(3 * sizeof(int) + ComplexListNodeSize)))
		{
			if (this->WriteBufferToItsList(node->GetBufferByIndex(setNum), node->GetListByIndex(setNum)) == FAILURE)
				return FAILURE;
		}

		// record the minID associated with this node
		node->AddToBuffer(node->GetBufferByIndex(setNum),(char *)&minID,sizeof(int));
		
		// recode the maxID associated with this node
		node->AddToBuffer(node->GetBufferByIndex(setNum),(char *)&maxID,sizeof(int));

		tempTree = node->GetActualAncsWithSubtree();

		if (node->isSimple())
		{	
			tempComplexTree->appendList((ListNode *)tempTree->getBuffer(),tempTree->length(), false);
		}
		else
		{
			if (((ComplexListNode *)tempTree->findNode(0))->IsDummy() &&
			strcmp("<root>", ((ComplexListNode *)tempTree->getNodeByIndex(0))->GetDummyName()) == 0)
			{
				tempComplexTree->appendList((ComplexListNode *)tempTree->getBuffer() + 1, this->dataMng, tempTree->length() - 1, false);
			}
			else
			{
				tempComplexTree->appendList((ComplexListNode *)tempTree->getBuffer(), this->dataMng, tempTree->length(), false);
			}
		}

		length = tempComplexTree->length();

		// record the length of subtree of this node, which is a list node along with it's subtree
		node->AddToBuffer(node->GetBufferByIndex(setNum), (char *)&length, sizeof(int));
		
		// copy the subtree into the buffer
		node->AddToBuffer(node->GetBufferByIndex(setNum),(char *)tempComplexTree->getBuffer(),length * ComplexListNodeSize);		   

		delete tempComplexTree;
	}

	for(int i = node->GetNumOfStructure() - 1; i > -1 ; i--)
	{
		if (node->GetSignByIndex(i).count() == 1)
		{
			signature |= node->GetSignByIndex(i);
			node->DeleteSignByIndex(i);
		}
	}

	if (signature.any())
	{
		node->SetSignByIndex(node->GetNumOfStructure(), signature);
		node->SetNumOfStructure(node->GetNumOfStructure() + 1);
	}

	return SUCCESS;
}

int MeaningfulClosestCommonAncestorStructureIterator::WriteNullDataIntoBuffer(MCCASStackNode * node, bitset<MAX_NUM_VARIABLE> signature)
{
	int length = 0, minID, maxID, total = signature.count(), counter = 0;
	for (int i = 0; i < MAX_NUM_VARIABLE; i++)
	{
		if (counter == total)
			break;

		if (signature.test(i))
		{
			counter++;
			minID = node->GetGlobalMin();
			maxID = node->GetGlobalMax();

			// data is empty, only write IDs and length
			if (!node->GetBufferByIndex(i)->EnoughSpace(3 * sizeof(int)))
			{
				if (this->WriteBufferToItsList(node->GetBufferByIndex(i), node->GetListByIndex(i)) == FAILURE)
					return FAILURE;
			}

			// record the minID associated with this node
			node->AddToBuffer(node->GetBufferByIndex(i),(char *)&minID,sizeof(int));
			
			// recode the maxID associated with this node
			node->AddToBuffer(node->GetBufferByIndex(i),(char *)&maxID,sizeof(int));
            
			// record the length of subtree of this node, which is a list node along with it's subtree
			node->AddToBuffer(node->GetBufferByIndex(i), (char *)&length, sizeof(int));
		}
	}

	return SUCCESS;
}

int MeaningfulClosestCommonAncestorStructureIterator::InsertStackNode(MCCASStackNode * source, MCCASStackNode * target)
{
	bitset<MAX_NUM_VARIABLE> signature;
	signature.reset();
	bool isMaterial = false;
	int index = -1;

	if (this->WriteNodeIntoItsBuffer(source) == FAILURE)
		return FAILURE;
	
	for(int i = 1; i < source->GetNumOfStructure(); i++)
	{
		if (source->GetSignByIndex(i).count() == 1)
		{
			signature |= source->GetSignByIndex(i);
			source->DeleteSignByIndex(i);
		}
	}

	if (signature.any())
	{
		source->SetSignByIndex(source->GetNumOfStructure(), signature);
		source->SetNumOfStructure(source->GetNumOfStructure() + 1);
	}

	switch (target->TypeOfRelationship(source->GetSignature(), this->isOptional, isMaterial, index, true))
	{
		case SUBSUMED_BY:
			// add the input node if the difference is immaterial
			if (!isMaterial)
			{				
				// record the missing optional structure
				this->WriteNullDataIntoBuffer(source, target->GetSignByIndex(index) ^ source->GetSignature());

				for (int i = 0; i < this->numInputs; i++)
				{
					if (source->GetSignature().test(i))
					{
						target->SetMaxByIndex(i, source->GetMaxByIndex(i));
					}
				}
                
				return this->CopyList(source, target);	
			}
			else
			{
				//delete buffers and lists of source stack node
				for (int k = 0; k < this->numInputs; k++)
				{
				    // FIXME: What should i be referring to here? The i that was used is on line 1431 but it is not right
				    if (source->GetSignByIndex(source->GetNumOfStructure()).test(k)) 
					// if (source->GetSignByIndex(i).test(k))
					{
						source->SetBufferByIndex(k);
						source->SetListByIndex(k);
						source->SetMaxByIndex(k, -1);
						source->SetMinByIndex(k, -1);
					}
				}
				//todo: try the following code
				// delete source;
			}

			break;
		case EQUAL:
			for (int i = 0; i < this->numInputs; i++)
			{
				if (source->GetSignature().test(i))
				{
					target->SetMaxByIndex(i, source->GetMaxByIndex(i));
				}
			}

			return this->CopyList(source,target);
		case NO_OVERLAP: 
			for (int i = 0; i < this->numInputs; i++)
			{
				if (source->GetSignature().test(i))
				{
					target->SetMaxByIndex(i, source->GetMaxByIndex(i));
					target->SetMinByIndex(i, source->GetMinByIndex(i));
				}
			}
         
			// set signature for the node
			target->SetSignature(target->GetSignature() | source->GetSignature());
			
			// set signature for individual structure
			target->SetSignByIndex(target->GetNumOfStructure(), source->GetSignature());
			target->SetNumOfStructure(target->GetNumOfStructure() + 1);

			return this->CopyList(source, target);	
		case CONSUMED_BY:	
    		// if the source structure is contained by the target struture, and the difference is material
			if (target->IsKey())
			{
				WriteNodeIntoItsBuffer(target);
			}

			if (isMaterial)
			{				
				for (int i = 0; i < this->numInputs; i++)
				{
					if (source->GetSignature().test(i))
					{
						target->SetMaxByIndex(i, source->GetMaxByIndex(i));
						target->SetMinByIndex(i, source->GetMinByIndex(i));
					}
				}

				for (int i = 0; i < target->GetNumOfStructure(); i++)
				{
					if (source->GetSignature() == (source->GetSignature() | target->GetSignByIndex(i)))
					{
						// delete the corresponding original lists and copy the new ones
						for (int j = 0; j < this->numInputs; j++)
						{
							if (target->GetSignByIndex(i).test(j))
							{
								target->SetBufferByIndex(j);
								target->SetListByIndex(j);
							}
						}
						
						target->DeleteSignByIndex(i);
					}
				}

				// set signature for the node
				target->SetSignature(target->GetSignature() | source->GetSignature());

				target->SetSignByIndex(target->GetNumOfStructure(), source->GetSignature());
				target->SetNumOfStructure(target->GetNumOfStructure() + 1);
			}
			else
			{
				// record the missing optional structure
				this->WriteNullDataIntoBuffer(target, source->GetSignature() ^ target->GetSignByIndex(index));


				for (int i = 0; i < this->numInputs; i++)
				{
					if (source->GetSignature().test(i))
					{
						target->SetMaxByIndex(i, source->GetMaxByIndex(i));
						
						if (!target->GetSignature().test(i) && source->GetSignature().test(i))
						{
							target->SetMinByIndex(i, source->GetMinByIndex(i));
						}
					}
				}

				// set signature for the node
				target->SetSignature(target->GetSignature() | source->GetSignature());

				target->SetSignByIndex(index, source->GetSignature());
			}
			
			return this->CopyList(source, target);	
		case HAVE_OVERLAP:
			// if the difference between the structures is material
			if (isMaterial)
			{
				bool all_source_immaterial = true;

				for (int i = 0; i < target->GetNumOfStructure(); i++)
				{
					if ((target->GetSignByIndex(i) & source->GetSignature()).any())
					{
						int materialType = TypeOfMaterialDifference( target->GetSignByIndex(i), source->GetSignature());
						
						if (materialType != TARGET_IMMATERIAL)
						{
							int k = 0;
							// delete the corresponding original lists
							for (k = 0; k < this->numInputs; k++)
							{
								if (target->GetSignByIndex(i).test(k))
								{
									target->SetBufferByIndex(k);
									target->SetListByIndex(k);
									target->SetMaxByIndex(k, -1);
									target->SetMinByIndex(k, -1);
								}
							}

							if (materialType != SOURCE_IMMATERIAL)
							{	
								target->SetNumOfStructure(target->GetNumOfStructure()- 1);
							}

							target->SetSignature(target->GetSignature() ^ target->GetSignByIndex(k));
						}

						if (materialType != SOURCE_IMMATERIAL)
							all_source_immaterial = false;	

						if (materialType == SOURCE_IMMATERIAL)
						{										
							//update the individual signatures for optional structures
							target->SetSignByIndex(i, source->GetSignature());
						}
					}
				}
				
				if (all_source_immaterial)
				{
					//todo: check the following code
					for (int i = 0; i < this->numInputs; i++)
					{
						if (source->GetSignature().test(i))
						{
							target->SetMaxByIndex(i, source->GetMaxByIndex(i));
							target->SetMinByIndex(i, source->GetMinByIndex(i));
						}
					}

					target->SetSignature(target->GetSignature() | source->GetSignature());
					return this->CopyList(source, target);	
				}
				else						
					return SUCCESS;
			}
			else
			{
				// record the missing optional structure
				this->WriteNullDataIntoBuffer(target, source->GetSignature() ^ (target->GetSignByIndex(index) & source->GetSignature()));
				this->WriteNullDataIntoBuffer(source, target->GetSignByIndex(index) ^ (target->GetSignByIndex(index) & source->GetSignature()));

				for (int i = 0; i < this->numInputs; i++)
				{
					if (source->GetSignature().test(i))
					{
						target->SetMaxByIndex(i, source->GetMaxByIndex(i));

						// if part of the structure is an optional one not contained by the target node
						if (!(target->GetSignature().test(i)))
							target->SetMinByIndex(i, source->GetMinByIndex(i));
					}
				}

				target->SetSignature(target->GetSignature() | source->GetSignature());

				//update the individual signatures for optional structures
				target->SetSignByIndex(index, source->GetSignature()|target->GetSignByIndex(index));

				return this->CopyList(source, target);
			}
	}
	return SUCCESS;
}

int MeaningfulClosestCommonAncestorStructureIterator :: TypeOfMaterialDifference(bitset<MAX_NUM_VARIABLE> targetSign, bitset<MAX_NUM_VARIABLE> sourceSign)
{
	bitset<MAX_NUM_VARIABLE> resultXOR = targetSign ^ sourceSign;
	unsigned int tCounter = 0, sCounter = 0;

	//check if the difference between the corresponding signature in source and target is material
	// if should take whether an element is optional into consideration
	for (int i = 0; i < MAX_NUM_VARIABLE; i++)
	{
		if (resultXOR.test(i))
		{
			if (targetSign.test(i) || this->isOptional[i])
			{
				tCounter++;
			}

			if (sourceSign.test(i) || this->isOptional[i])
			{
				sCounter++;
			}
		}
	}

	// target structure is acceptable, if considering optional nodes
	if (tCounter == resultXOR.count())
		return TARGET_IMMATERIAL;
	// source structure is acceptable, if considering optional nodes
	else if (sCounter == resultXOR.count())
		return SOURCE_IMMATERIAL;
	// neither acceptable
	else 
		return ALL_MATERIAL;	
}

/**
construct MCCAS sub-structure
**/
void MeaningfulClosestCommonAncestorStructureIterator :: ConstructSubMCCASByIndex(MCCASStackNode * node, int index, bool reset)
{
	int i;
	bitset<MAX_NUM_VARIABLE> signature;
	signature = node->GetSignByIndex(index);
		
	ShoreList * list;

	// if there is only one buffer/list associated with the structure
	// simply scan the buffer/list
	if (signature.count() == 1)
	{
		for (i = 0; i < this->numInputs; i++)
		{
			if (signature.test(i))
			{
				break;
			}
		}
		
		// if restart scan
		if (reset)
		{
			list = node->GetListByIndex(i);
			list->StartScan();
		}
	}	
}

/**
find MCCAS structures
**/
bool MeaningfulClosestCommonAncestorStructureIterator :: FindMCCAS()
{
	int setNum = -1;
	
	this->finishScan.reset();
	this->startScan.reset();

	// initialize the copy
	for (int i = 0; i < this->numInputs; i++)
	{
		this->copyOfLatestMCCAS->SetBufferByIndex(i);
		this->copyOfLatestMCCAS->SetListByIndex(i);
		this->copyOfLatestMCCAS->SetMinByIndex(i,-1);
		this->copyOfLatestMCCAS->SetMaxByIndex(i,-1);
	}	

	do
	{
		if (this->startOutput && outputCandidate() == SUCCESS)
			return true;		
		else
			this->stop = false;

		findInput(setNum);	
		
		// read in input
		if (setNum != -1)
		{	
			this->PushInput(setNum);
			inputs[setNum]->next(inTuple[setNum]);
		}
	} while (setNum != -1 && this->stop == false);	

	//pop all the nodes in the stack
	if (setNum == -1)
	{
		this->popStack(-1);

		// not output any candidate in temp output stack
		if (!this->startOutput && !this->tempOutputStack->IsEmpty())
		{
			outputCandidate();
		}
	}

	if (this->stop == true)
	{
		this->stop = false;
		return true;
	}
	else
	{		
		return false;
	}
}

void MeaningfulClosestCommonAncestorStructureIterator :: BackwardScan(ContainerClass * cont, int length)
{
	cont->SetScanCursor(cont->GetScanCursor() - length);
	return;
}

void MeaningfulClosestCommonAncestorStructureIterator :: FirstTimeScan(MCCASStackNode * node, int index)
{
	ShoreList * list = NULL;
	int newMaxID, newMinID = -1, minID = 10000, maxID = 0, length = 0;
	int i;

	for (i = 0; i < this->numInputs; i++)
	{
		if (node->GetSignByIndex(index).test(i))
		{
			list = node->GetListByIndex(i);

			// mark the list to be scanned
			this->startScan.set(i);				
			list->StartScan();
			this->curListScanCursor[i] = list->GetHead();
			this->curBufScanCursor[i] = 0;
			this->newBufScanCursor[i] = 0;
			this->newListScanCursor[i] = list->GetHead();
			list->SetScanCursor(this->curListScanCursor[i]);

			if (list->IsEmpty())
			{
				this->readContainer[i] = node->GetBufferByIndex(i);				
			}
			else
			{
				if (!node->GetBufferByIndex(i)->IsEmpty())
					if (this->WriteBufferToItsList(node->GetBufferByIndex(i), node->GetListByIndex(i)) == FAILURE)
						return;
				if (list->GetNext(this->readContainer[i]) == FAILURE)
					return;
			}

			// get IDs and number of nodes in the WitnessTree
			this->readContainer[i]->GetNext(sizeof(int),(char *)&newMinID);
			this->readContainer[i]->GetNext(sizeof(int),(char *)&newMaxID);
			this->readContainer[i]->GetNext(sizeof(int),(char *)&length);

			if (newMinID < minID)
			{
				minID = newMinID;
			}

			// do we need to get maxID? - yes.
			if (newMaxID > maxID)
			{
				maxID = newMaxID;
			}

			// the minID of nodes in the list scanned so far
			this->curMinIDs[i] = newMinID;
			this->newMinIDs[i] = newMinID;

			// the maxID of nodes in the list scanned so far
			this->curMaxIDs[i] = newMaxID;
			this->newMaxIDs[i] = newMaxID;

			// update minmaxid for the substructure
			if (newMaxID < this->curMinMaxID[index])
			{
				this->curMinMaxID[index] = newMaxID;
			}

			// read in the data node, if the data node is not null
			if (length > 0)
			{
				this->outputArrayOfWitnessTree[i]->appendList((ComplexListNode *)this->readContainer[i]->GetNextPtr(length * ComplexListNodeSize,false,true), this->dataMng, length);
			
				if (this->aSpecNum[i] == 2 || this->aSpecNum[i] == 3)
				{
					while (newMinID <= this->curMaxIDs[i])
					{
						if (this->readContainer[i]->GetNext(sizeof(int),(char *)&newMinID) == FAILURE)
							if (list->IsEmpty() || (list->GetNext(this->readContainer[i])) == FAILURE)
							{
								break;
							}
							else 
							{this->readContainer[i]->GetNext(sizeof(int),(char *)&newMinID);}


						this->readContainer[i]->GetNext(sizeof(int),(char *)&newMaxID);

						//read in node with incompatible id, discard the node
						if (newMinID > this->curMaxIDs[i])
						{
							this->newMaxIDs[i] = newMaxID;
							this->newMinIDs[i] = newMinID;
							this->newBufScanCursor[i] = this->readContainer[i]->GetScanCursor()- 2 * sizeof(int);	
							this->newListScanCursor[i] = node->GetListByIndex(i)->GetScanCursor();	
			
							// reset scan cursor
							this->readContainer[i]->SetScanCursor(this->newBufScanCursor[i]);
							list->SetScanCursor(this->newListScanCursor[i]);

							break;
						}
						// append the nodes with compatible id
						else
						{
							this->readContainer[i]->GetNext(sizeof(int),(char *)&length);
							this->outputArrayOfWitnessTree[i]->appendList((ComplexListNode *)this->readContainer[i]->GetNextPtr(length * ComplexListNodeSize,false,true), this->dataMng, length);
						}
					}
				}
			}
		}							
	}	
}



bool MeaningfulClosestCommonAncestorStructureIterator :: MergeSubMCCAS(MCCASStackNode * node, int index)
{
	ShoreList * list;
	int newMaxID, newMinID = 0;
	int length;
	unsigned int counter = 0;
	ContainerClass * oldReadContainer;

	for (int i = 0; i < this->numInputs; i++)
	{
		if (node->GetSignByIndex(index).test(i))
		{
			counter++;

			list = this->copyOfLatestMCCAS->GetListByIndex(i);
			
			// the first time to scan list[i]
			if (!this->startScan.test(i))
			{
				this->FirstTimeScan(node, index);				
			}	
			// all the nodes with curMinID & curMaxID in the structure already merged with each other
			// move on to merge the remaining nodes
			else if ((this->finishScan & node->GetSignByIndex(index)).count() == counter - 1)
			{	
				// read in another record
				if (this->readContainer[i]->GetNext(sizeof(int),(char *)&newMinID) == SUCCESS)
				{
					this->readContainer[i]->GetNext(sizeof(int),(char *)&newMaxID);	
					
					// read in a record with another id
					// discard it and rescan current list
					if (newMinID > this->curMaxIDs[i])
					{
						this->newMaxIDs[i] = newMaxID;
						this->newMinIDs[i] = newMinID;

						this->newBufScanCursor[i] = this->readContainer[i]->GetScanCursor()- 2 * sizeof(int);						
						this->newListScanCursor[i] = node->GetListByIndex(i)->GetScanCursor();

						if (counter < node->GetSignByIndex(index).count())
						{								
							this->finishScan.set(i);
						}
						else
						{
							this->StartScanForNewID(node, index, counter);
							if (RestartScan(node, index, i + 1) == FAILURE)
								return false;
						}
					}
					else
					{	
						// continue read in data in current buffer readContainer[i]
						this->readContainer[i]->GetNext(sizeof(int),(char *)&length);
												
						this->outputArrayOfWitnessTree[i]->SetUsed(0);
						this->outputArrayOfWitnessTree[i]->appendList((ComplexListNode *)this->readContainer[i]->GetNextPtr(length * ComplexListNodeSize,false,true), this->dataMng, length);

						// continue reading in compatible nodes, if annotation is clustering
						if (this->aSpecNum[i] == 2 || this->aSpecNum[i] == 3)
						{
							while (newMinID <= this->curMaxIDs[i])
							{
								if (this->readContainer[i]->GetNext(sizeof(int),(char *)&newMinID) == FAILURE)
									if (list->IsEmpty() || (list->GetNext(this->readContainer[i])) == FAILURE)
									{
										break;
									}
									else 
									{this->readContainer[i]->GetNext(sizeof(int),(char *)&newMinID);}

								this->readContainer[i]->GetNext(sizeof(int),(char *)&newMaxID);

								//read in node with incompatible id, discard the node
								if (newMinID > this->curMaxIDs[i])
								{
									this->newMaxIDs[i] = newMaxID;
									this->newMinIDs[i] = newMinID;
									this->newBufScanCursor[i] = this->readContainer[i]->GetScanCursor()- 2 * sizeof(int);						
									this->newListScanCursor[i] = node->GetListByIndex(i)->GetScanCursor();				
									
									// reset scan cursor
									this->readContainer[i]->SetScanCursor(this->newBufScanCursor[i]);
									list->SetScanCursor(this->newListScanCursor[i]);
									break;
								}
								// append the nodes with compatible id
								else
								{
									this->readContainer[i]->GetNext(sizeof(int),(char *)&length);
									this->outputArrayOfWitnessTree[i]->appendList((ComplexListNode *)this->readContainer[i]->GetNextPtr(length * ComplexListNodeSize,false,true), this->dataMng, length);
								}
							}
						}
					}
				}
				// if all the records in the lists have been scanned
				else 
				{
					oldReadContainer = new ContainerClass;
					serial_t oldListScanCursor = list->GetScanCursor();
					oldReadContainer->CopyContainer(this->readContainer[i]);
					
				if (list->IsEmpty() || (list->GetNext(this->readContainer[i]) == FAILURE))
				{
					delete oldReadContainer;

					if (counter < node->GetSignByIndex(index).count())
					{
						this->finishScan.set(i);
					}
					else
					{
						if (this->curMaxIDs[i] > this->curMinMaxID[index])
						{
							// continue scan for new ID in other lists
							this->StartScanForNewID(node, index, counter - 1);
							if (RestartScan(node, index, i) == FAILURE)
								return false;
						}
						else
						{	
							this->finishScan.set(i);
							return false;
						}
					}
				}
				else
				{
					//if (this->RestartScan(node, index, counter - 1) == FAILURE)
					//	return false;
					this->readContainer[i]->GetNext(sizeof(int),(char *)&newMinID);
					this->readContainer[i]->GetNext(sizeof(int),(char *)&newMaxID);
					this->readContainer[i]->GetNext(sizeof(int),(char *)&length);

					if (this->curMinIDs[i] == -1)
					{
						this->curMinIDs[i] = newMinID;
					}

					if (this->curMaxIDs[i] == -1)
					{
						this->curMaxIDs[i] = newMaxID;
					}

					// read in a record with another id
					// discard it and rescan current list
					if (newMinID > this->curMinIDs[i])
					{
						this->newBufScanCursor[i] = this->readContainer[i]->GetScanCursor()- 3 * sizeof(int);
						this->newListScanCursor[i] = node->GetListByIndex(i)->GetScanCursor();
						this->newMaxIDs[i] = newMaxID;
						this->newMinIDs[i] = newMinID;

						if (counter < node->GetSignByIndex(index).count())
						{	
							//this->readContainer[i]->CopyContainer(oldReadContainer);
							//node->GetListByIndex(i)->SetScanCursor(oldListScanCursor);
							delete oldReadContainer;
							this->finishScan.set(i);
						}
						else
						{
							delete oldReadContainer;
							this->StartScanForNewID(node, index, counter);
							if (RestartScan(node, index, i + 1) == FAILURE)
							{
								return false;
							}
						}
					}
					else
					{	
						delete oldReadContainer;

						this->curMinIDs[i] = newMinID;
						this->curMaxIDs[i] = newMaxID;

						// update minmaxid for the substructure
						if (curMaxIDs[i] < this->curMinMaxID[index] || curMinIDs[i] > this->curMinMaxID[index])
						{
							this->curMinMaxID[index] = curMaxIDs[i];
						}

						this->outputArrayOfWitnessTree[i]->SetUsed(0);
						this->outputArrayOfWitnessTree[i]->appendList((ComplexListNode *)this->readContainer[i]->GetNextPtr(length * ComplexListNodeSize,false,true), this->dataMng, length);

						// continue reading in compatible nodes, if annotation is clustering
						if (this->aSpecNum[i] == 2 || this->aSpecNum[i] == 3)
						{
							while (newMinID <= this->curMaxIDs[i])
							{
								if (this->readContainer[i]->GetNext(sizeof(int),(char *)&newMinID) == FAILURE)
									if (list->IsEmpty() || (list->GetNext(this->readContainer[i])) == FAILURE)
									{
										break;
									}
									else 
									{this->readContainer[i]->GetNext(sizeof(int),(char *)&newMinID);}

								this->readContainer[i]->GetNext(sizeof(int),(char *)&newMaxID);

								//read in node with incompatible id, discard the node
								if (newMinID > this->curMaxIDs[i])
								{
									this->newMaxIDs[i] = newMaxID;
									this->newMinIDs[i] = newMinID;
									this->newBufScanCursor[i] = this->readContainer[i]->GetScanCursor()- 2 * sizeof(int);						
									this->newListScanCursor[i] = node->GetListByIndex(i)->GetScanCursor();										
									
									// reset cursor
									this->readContainer[i]->SetScanCursor(this->newBufScanCursor[i]);
									list->SetScanCursor(this->newListScanCursor[i]);
									break;
								}
								// append the nodes with compatible id
								else
								{
									this->readContainer[i]->GetNext(sizeof(int),(char *)&length);
									this->outputArrayOfWitnessTree[i]->appendList((ComplexListNode *)this->readContainer[i]->GetNextPtr(length * ComplexListNodeSize,false,true), this->dataMng, length);
								}
							}
						}

						this->finishScan.reset();
					}
				}
				}
			}				
		}		
	}

	return true;
}

void MeaningfulClosestCommonAncestorStructureIterator :: StartScanForNewID(MCCASStackNode * node, int index, int curList)
{
	int min;

	min = this->OverallMinID(node->GetSignByIndex(index));

	for (int i = 0; i < this->numInputs; i++)
	{
		if (node->GetSignByIndex(index).test(i) && i <= curList)
		{	
			this->finishScan.reset(i);
			if (this->newMinIDs[i] == min || i == curList)
			{				
				this->curBufScanCursor[i] = this->newBufScanCursor[i];
				this->curListScanCursor[i] = this->newListScanCursor[i];
				this->curMinIDs[i] = this->newMinIDs[i];
				this->curMaxIDs[i] = this->newMaxIDs[i];

				// update minmaxid for the substructure
				if (this->curMaxIDs[i] < this->curMinMaxID[index] || this->curMinIDs[i] >  this->curMinMaxID[index])
				{
					this->curMinMaxID[index] = this->curMaxIDs[i];
				}
			}
		}
	}
}

/**
Restart scan
**/
int MeaningfulClosestCommonAncestorStructureIterator :: RestartScan(MCCASStackNode * node, int index, int curList)
{
	ShoreList * list;
	int newMinID, newMaxID = 0;
	int length;
	//todo: double check
	ContainerClass * oldReadContainer = NULL;
	serial_t oldListScanCursor;
	int isSuccess = FAILURE;

	for (int i = 0; i < curList; i++)
	{
		if (node->GetSignByIndex(index).test(i))
		{
			isSuccess = SUCCESS;
			this->finishScan.reset(i);

			list = node->GetListByIndex(i);
			list->SetScanCursor(this->curListScanCursor[i]);

			this->readContainer[i]->SetScanCursor(this->curBufScanCursor[i]);

			if (list->IsEmpty())
			{
				this->readContainer[i] = this->copyOfLatestMCCAS->GetBufferByIndex(i);
				this->readContainer[i]->GetNext(sizeof(int),(char *)&newMinID);
			}
			else
			{				
				list->GetNext(this->readContainer[i]);
				this->readContainer[i]->SetScanCursor(this->curBufScanCursor[i]);
				this->readContainer[i]->GetNext(sizeof(int),(char *)&newMinID);
			}

			this->readContainer[i]->GetNext(sizeof(int),(char *)&newMaxID);														this->readContainer[i]->GetNext(sizeof(int),(char *)&length);
			this->outputArrayOfWitnessTree[i]->SetUsed(0);

			if (length > 0)
			{
				this->curMinIDs[i] = newMinID;
				this->curMaxIDs[i] = newMaxID;

				// update minmaxid for the substructure
				if (this->curMaxIDs[i] < this->curMinMaxID[index] || this->curMinIDs[i] >  this->curMinMaxID[index])
				{
					this->curMinMaxID[index] = this->curMaxIDs[i];
				}
				
				this->outputArrayOfWitnessTree[i]->appendList((ComplexListNode *)this->readContainer[i]->GetNextPtr(length * ComplexListNodeSize,false,true), this->dataMng, length);

				// continue reading in compatible nodes, if annotation is clustering
				if (this->aSpecNum[i] == 2 || this->aSpecNum[i] == 3)
				{
					while (newMinID <= this->curMaxIDs[i])
					{
						if (this->readContainer[i]->GetNext(sizeof(int),(char *)&newMinID) == FAILURE)
						{
							oldReadContainer = new ContainerClass;
							oldReadContainer->CopyContainer(this->readContainer[i]);
							oldReadContainer->SetScanCursor(this->readContainer[i]->GetScanCursor());
							oldListScanCursor =  node->GetListByIndex(i)->GetScanCursor();

							if (list->IsEmpty() || (list->GetNext(this->readContainer[i])) == FAILURE)
							{
								delete oldReadContainer;
								oldReadContainer = NULL;
								break;
							}
							else 	
							{
								this->readContainer[i]->GetNext(sizeof(int),(char *)&newMinID);
							}
						}

						this->readContainer[i]->GetNext(sizeof(int),(char *)&newMaxID);

						//read in node with incompatible id, discard the node
						if (newMinID > this->curMaxIDs[i])
						{
							this->newMaxIDs[i] = newMaxID;
							this->newMinIDs[i] = newMinID;
							
							if (oldReadContainer)
							{
								this->readContainer[i]->CopyContainer(oldReadContainer);
								this->newBufScanCursor[i] = oldReadContainer->GetScanCursor();
								this->newListScanCursor[i] = oldListScanCursor;
								delete oldReadContainer;
								oldReadContainer = NULL;
							}		
							else
							{
								this->newBufScanCursor[i] = this->readContainer[i]->GetScanCursor()- 2 * sizeof(int);
                                this->newListScanCursor[i] = node->GetListByIndex(i)->GetScanCursor();	
							}

							// reset scan cursor
							this->readContainer[i]->SetScanCursor(this->newBufScanCursor[i]);
							list->SetScanCursor(this->newListScanCursor[i]);								
							
							break;
						}
						// append the nodes with compatible id
						else
						{
							this->readContainer[i]->GetNext(sizeof(int),(char *)&length);
							this->outputArrayOfWitnessTree[i]->appendList((ComplexListNode *)this->readContainer[i]->GetNextPtr(length * ComplexListNodeSize,false,true), this->dataMng, length);

							if (oldReadContainer)
							{
								delete oldReadContainer;
								oldReadContainer = NULL;
							}		

						}
					}
				}
			}
		}
	}

	return isSuccess;
}

int MeaningfulClosestCommonAncestorStructureIterator :: OverallMinID(bitset<MAX_NUM_VARIABLE> signature)
{
	int min = -1;

	for (int i = 0; i < this->numInputs; i++)
	{
		if (signature.test(i))
		{
			if (this->newMinIDs[i] < min || min == -1)
			{
				min = this->newMinIDs[i];
			}
		}
	}

	return min;
}
