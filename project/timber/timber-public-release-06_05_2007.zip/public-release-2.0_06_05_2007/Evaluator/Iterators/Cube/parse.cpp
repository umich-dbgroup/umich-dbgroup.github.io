
#include "parse.hpp"

char QueryEvaluationTreeCubeNode::getIdentifier(void) { return 'C'; }

char 
CubePlanParser::getIteratorIdentifier(void) { return 'C'; }

void 
CubePlanParser::getQueryEvalNode(EvaluatorClass* evaluator, char* line, void* queryInput, QueryEvaluationTreeNode*& curr)
	    {
		char *token = strtok(line+2,",");                    
		if (token == NULL)
		{
		    globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"Evaluator",__FILE__,"Error input from file... expecting algorithm type... Cube line...");
		    curr=NULL; return;
		}

		int cubeBy = CUBE_ALGORITHM_1;
		if (strcmp(token,"1") == 0)
		    cubeBy = CUBE_ALGORITHM_1;
		else if (strcmp(token,"2") == 0)
		    cubeBy = CUBE_ALGORITHM_2;
		else if (strcmp(token,"3") == 0)
		    cubeBy = CUBE_ALGORITHM_3;

		token = strtok(NULL,",");
		if (token == NULL)
		{
		    globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"Evaluator",__FILE__,"Error input from file... expecting size... Cube line...");
		    curr=NULL; return;
		}
		int exSize = atoi(token);

		token = strtok(NULL,",");
		if (token == NULL)
		{
		    globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"Evaluator",__FILE__,"Error input from file... expecting fact nre... Cube line...");
		    curr=NULL; return;
		}
		NREType factNRE = (NREType)atoi(token);

		token = strtok(NULL,",");
		if (token == NULL)
		{
		    globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"Evaluator",__FILE__,"Error input from file... expecting groupby what... group by line...");
		    curr=NULL; return;
		}
		int factByWhat;
		if (strcmp(token,"AN") == 0)
		    factByWhat = GROUPBY_ATTRIBUTE_NUM;
		else if (strcmp(token,"AS") == 0)
		    factByWhat = GROUPBY_ATTRIBUTE_STR;
		else if (strcmp(token,"TN") == 0)
		    factByWhat = GROUPBY_TEXT_NUM;
		else if (strcmp(token,"TS") == 0)
		    factByWhat = GROUPBY_TEXT_STR;
		else if (strcmp(token,"SK") == 0)
		    factByWhat = GROUPBY_STARTKEY;
		else if (strcmp(token,"VN") == 0)
		    factByWhat = GROUPBY_VALUE_NUM;
		else if (strcmp(token,"VS") == 0)
		    factByWhat = GROUPBY_VALUE_STR;
		else
		{
		    globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"Evaluator",__FILE__,"Error input from file... unrecognized fact by what... cube line...");
		    curr=NULL; return;
		}


		token = strtok(NULL,",");
		if (token == NULL)
		{
		    globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"Evaluator",__FILE__,"Error input from file... expecting cube fact attr name... cube line...");
		    curr=NULL; return;
		}
		char *factByAttrName;
		factByAttrName = new char[strlen(token)+1];
		strcpy(factByAttrName,token);

		token = strtok(NULL,",");
		if (token == NULL)
		{
		    delete [] factByAttrName;
		    globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"Evaluator",__FILE__,"Error input from file... expecting aggregate function... Cube line...");
		    curr=NULL; return;
		}
		int factOperation;
		if (strcmp(token,"C") == 0)
		    factOperation = OP_COUNT;
		else if (strcmp(token,"A") == 0)
		    factOperation = OP_AVG;
		else if (strcmp(token,"S") == 0)
		    factOperation = OP_SUM;
		else if (strcmp(token,"M") == 0)
		    factOperation = OP_MAX;
		else if (strcmp(token,"m") == 0)
		    factOperation = OP_MIN;
		else factOperation = OP_NONE;

		token = strtok(NULL,",");
		if (token == NULL)
		{
		    delete [] factByAttrName;
		    globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"Evaluator",__FILE__,"Error input from file... expecting fact op nre... Cube line...");
		    curr=NULL; return;
		}
		NREType factOpNRE = (NREType)atoi(token);

		token = strtok(NULL,",");
		if (token == NULL)
		{
		    delete [] factByAttrName;
		    globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"Evaluator",__FILE__,"Error input from file... expecting oper on what... cube line...");             
		    curr=NULL; return;
		}
		int factOpOnWhat;

		if (strcmp(token,"A") == 0)
		    factOpOnWhat = ON_ATTRIBUTE_NUM;
		else if (strcmp(token,"LA") == 0)
		    factOpOnWhat = ON_ATTR_LOCAL_NUM;
		else if (strcmp(token,"T") == 0)
		    factOpOnWhat = ON_TEXT_NUM;
		else if (strcmp(token,"LT") == 0)
		    factOpOnWhat = ON_TEXT_LOCAL_NUM;
		else if (strcmp(token,"LF") == 0)
		    factOpOnWhat = ON_FANOUT_LOCAL;
		else if (strcmp(token,"AF") == 0)
		    factOpOnWhat = ON_FANOUT_ACTUAL;
		else if (strcmp(token,"LD") == 0)
		    factOpOnWhat = ON_DEPTH_LOCAL;
		else if (strcmp(token,"AD") == 0)
		    factOpOnWhat = ON_DEPTH_ACTUAL;
		else if (strcmp(token,"V") == 0)
		    factOpOnWhat = ON_VALUE_NUM;
		else
		    factOpOnWhat = ON_VALUE_NUM; //if count, we don't care

		token = strtok(NULL,",");
		if (token == NULL)
		{
		    delete [] factByAttrName;
		    globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"Evaluator",__FILE__,"Error input from file... expecting fact operation attrName... cube line...");
		    curr=NULL; return;
		}
		char* factOpOnWhatAttrName = new char[strlen(token)+1];
		strcpy(factOpOnWhatAttrName,token);

		token = strtok(NULL,",");
		if (token == NULL)
		{
		    delete [] factByAttrName;
		    delete [] factOpOnWhatAttrName;
		    globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"Evaluator",__FILE__,"Error input from file... expecting dimension number... Cube line...");
		    curr=NULL; return;
		}
		int dimnum = atoi(token);


		NREType *nre;
		int* groupByWhat;
		char** groupByAttrname;
		bool** groupByRelaxType;
		NREType *subtreeParent;
		if (dimnum > 0)
		{
		    nre = new NREType[dimnum];
		    groupByWhat = new int[dimnum];
		    groupByAttrname = new char *[dimnum];
		    groupByRelaxType = new bool *[dimnum];
		    subtreeParent = new NREType[dimnum];
		}
		else
		{
		    nre = NULL;
		    groupByWhat = NULL;
		    groupByAttrname = NULL;
		    groupByRelaxType = NULL;
		    subtreeParent = NULL;
		    delete [] factByAttrName;
		    delete [] factOpOnWhatAttrName;
		    globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"Evaluator",__FILE__,"Error input from file... dimension number needs to be at least 1... Cube line...");
		    curr=NULL; return;
		}
		for (int i=0; i<dimnum; i++)
		{
		    token = strtok(NULL,",");
		    if (token == NULL)
		    {
			delete [] nre;
			delete [] factByAttrName;
			delete [] factOpOnWhatAttrName;
			delete [] groupByWhat;
			delete [] subtreeParent;
			for (int j=0; j<dimnum; j++)
			    if (groupByAttrname[j]) delete [] groupByAttrname[j];
			for (int j =0; j<i;j++) {
			    delete [] groupByRelaxType[j];
			}
			delete [] groupByRelaxType;
			globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"Evaluator",__FILE__,"Error input from file... expecting dimension nre... Cube line...");
			curr=NULL; return;
		    }
		    nre[i] = (NREType)atoi(token);

		    if (nre[i] < 1)
		    {
			delete [] factByAttrName;
			delete [] factOpOnWhatAttrName;
			delete [] groupByWhat;
			delete [] subtreeParent;
			for (int j=0; j<dimnum; j++)
			    if (groupByAttrname[j]) delete [] groupByAttrname[j];
			for (int j =0; j<i;j++) {
			    delete [] groupByRelaxType[j];
			}
			delete [] groupByRelaxType;
			globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"Evaluator",__FILE__,"NRE should be positive. Cube line...");
			delete [] nre;	
			curr=NULL; return;
		    }

		    if (nre[i] > evaluator->maxNRE)
			evaluator->maxNRE = nre[i];

		    token = strtok(NULL,",");
		    if (token == NULL)
		    {
			delete [] nre;
			delete [] factByAttrName;
			delete [] factOpOnWhatAttrName;
			delete [] groupByWhat;
			delete [] subtreeParent;
			for (int j =0; j<i;j++) {
			    delete [] groupByRelaxType[j];
			}
			delete [] groupByRelaxType;
			for (int j=0; j<dimnum; j++)
			    if (groupByAttrname[j]) delete [] groupByAttrname[j];
			globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"Evaluator",__FILE__,"Error input from file... expecting dimension nre... Cube line...");
			curr=NULL; return;
		    }
		    //explode into array
		    groupByRelaxType[i] = new bool[4];
		    for (int j = 0 ; j < 4 ; j++){
			if (token[j] == '0') groupByRelaxType[i][j] = false;
			else if (token[j] == '1') groupByRelaxType[i][j] = true;
		    }

		    token = strtok(NULL,",");
		    if (token == NULL)
		    {
			delete [] nre;
			delete [] factByAttrName;
			delete [] factOpOnWhatAttrName;
			delete [] groupByWhat;
			delete [] subtreeParent;
			for (int j=0; j<dimnum; j++)
			    if (groupByAttrname[j]) delete [] groupByAttrname[j];
			for (int j =0; j<i;j++) {
			    delete [] groupByRelaxType[j];
			}
			delete [] groupByRelaxType;
			globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"Evaluator",__FILE__,"Error input from file... expecting dimension nre... Cube line...");
			curr=NULL; return;
		    }
		    subtreeParent[i] = (NREType)atoi(token);

		    token = strtok(NULL,",");
		    if (token == NULL)
		    {
			delete [] nre;
			delete [] factByAttrName;
			delete [] factOpOnWhatAttrName;
			delete [] groupByWhat;
			delete [] subtreeParent;
			for (int j=0; j<dimnum; j++)
			    if (groupByAttrname[j]) delete [] groupByAttrname[j];
			for (int j =0; j<i;j++) {
			    delete [] groupByRelaxType[j];
			}
			delete [] groupByRelaxType;
			globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"Evaluator",__FILE__,"Error input from file... expecting dimension nre... Cube line...");
			curr=NULL; return;
		    }
		    if (strcmp(token,"AN") == 0)
			groupByWhat[i] = GROUPBY_ATTRIBUTE_NUM;
		    else if (strcmp(token,"AS") == 0)
			groupByWhat[i] = GROUPBY_ATTRIBUTE_STR;
		    else if (strcmp(token,"TN") == 0)
			groupByWhat[i] = GROUPBY_TEXT_NUM;
		    else if (strcmp(token,"TS") == 0)
			groupByWhat[i] = GROUPBY_TEXT_STR;
		    else if (strcmp(token,"SK") == 0)
			groupByWhat[i] = GROUPBY_STARTKEY;
		    else if (strcmp(token,"VN") == 0)
			groupByWhat[i] = GROUPBY_VALUE_NUM;
		    else if (strcmp(token,"VS") == 0)
			groupByWhat[i] = GROUPBY_VALUE_STR;
		    else
		    {
			delete [] nre;
			delete [] factByAttrName;
			delete [] factOpOnWhatAttrName;
			delete [] groupByWhat;
			delete [] subtreeParent;
			for (int j=0; j<dimnum; j++)
			    if (groupByAttrname[j]) delete [] groupByAttrname[j];
			for (int j =0; j<i;j++) {
			    delete [] groupByRelaxType[j];
			}
			delete [] groupByRelaxType;
			globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"Evaluator",__FILE__,"Error input from file... unrecognized group by what... cube line...");
			curr=NULL; return;
		    }

		    token = strtok(NULL,",");
		    if (token == NULL)
		    {
			delete [] nre;
			delete [] factByAttrName;
			delete [] factOpOnWhatAttrName;
			delete [] groupByWhat;
			delete [] subtreeParent;
			for (int j=0; j<dimnum; j++)
			    if (groupByAttrname[j]) delete [] groupByAttrname[j];
			for (int j =0; j<i;j++) {
			    delete [] groupByRelaxType[j];
			}
			delete [] groupByRelaxType;
			globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"Evaluator",__FILE__,"Error input from file... expecting dimension nre... Cube line...");
			curr=NULL; return;
		    }
		    groupByAttrname[i] = new char[strlen(token)+1];
		    strcpy(groupByAttrname[i],token);

		}

		token = strtok(NULL,",");
		if (token == NULL)
		{
		    delete [] nre;
		    delete [] factByAttrName;
		    delete [] factOpOnWhatAttrName;
		    delete [] groupByWhat;
		    delete [] subtreeParent;
		    for (int j=0; j<dimnum; j++)
			if (groupByAttrname[j]) delete [] groupByAttrname[j];
		    for (int j =0; j<dimnum;j++) {
			delete [] groupByRelaxType[j];
		    }
		    delete [] groupByRelaxType;
		    globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"Evaluator",__FILE__,"Error input from file... expecting dimension number... Cube line...");
		    curr=NULL; return;
		}
		bool useExternalSort = false;
		int isExternalSort = atoi(token);
		if (isExternalSort == 1) {
		    useExternalSort = true;
		}

		token = strtok(NULL,",");
		if (token == NULL)
		{
		    delete [] nre;
		    delete [] factByAttrName;
		    delete [] factOpOnWhatAttrName;
		    delete [] groupByWhat;
		    delete [] subtreeParent;
		    for (int j=0; j<dimnum; j++)
			if (groupByAttrname[j]) delete [] groupByAttrname[j];
		    for (int j =0; j<dimnum;j++) {
			delete [] groupByRelaxType[j];
		    }
		    delete [] groupByRelaxType;
		    globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"Evaluator",__FILE__,"Error input from file... expecting filename... Cube line...");
		    curr=NULL; return;
		}
		char *fileName;
		fileName = new char[strlen(token)+1];
		strcpy(fileName,token);

		token = strtok(NULL,",");
		char *sortorderfileName = NULL;
		if (token != NULL && cubeBy == CUBE_ALGORITHM_3)
		{
		    sortorderfileName = new char[strlen(token)+1];
		    strcpy(sortorderfileName,token);
		}


		token = strtok(NULL,",");
		NREType assignedDummyNRE1 = (NREType)atoi(token);
		if (assignedDummyNRE1 < 1)
		{
		    delete [] nre;
		    delete [] factByAttrName;
		    delete [] factOpOnWhatAttrName;
		    delete [] groupByWhat;
		    delete [] subtreeParent;
		    for (int j=0; j<dimnum; j++)
			if (groupByAttrname[j]) delete [] groupByAttrname[j];
		    for (int j =0; j<dimnum;j++) {
			delete [] groupByRelaxType[j];
		    }
		    delete [] groupByRelaxType;
		    if (sortorderfileName) delete [] sortorderfileName;
		    delete [] fileName;
		    globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"Evaluator",__FILE__,"NRE should be positive.");
		    curr=NULL; return;
		}
		if (assignedDummyNRE1 > evaluator->maxNRE)
		    evaluator->maxNRE = assignedDummyNRE1;

		token = strtok(NULL,",");
		NREType assignedDummyNRE2 = (NREType)atoi(token);
		if (assignedDummyNRE2 < 1)
		{
		    delete [] nre;
		    delete [] factByAttrName;
		    delete [] factOpOnWhatAttrName;
		    delete [] groupByWhat;
		    delete [] subtreeParent;
		    for (int j=0; j<dimnum; j++)
			if (groupByAttrname[j]) delete [] groupByAttrname[j];
		    for (int j =0; j<dimnum;j++) {
			delete [] groupByRelaxType[j];
		    }
		    delete [] groupByRelaxType;
		    if (sortorderfileName) delete [] sortorderfileName;
		    delete [] fileName;
		    globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"Evaluator",__FILE__,"NRE should be positive.");
		    curr=NULL; return;
		}
		if (assignedDummyNRE2 > evaluator->maxNRE)
		    evaluator->maxNRE = assignedDummyNRE2;

		char newLine[MAX_FILE_INTERFACE_LINE_SIZE];
		if (((std::iostream *)queryInput)->eof() == 0)
		    ((std::iostream *)queryInput)->getline(newLine,MAX_FILE_INTERFACE_LINE_SIZE);
		else
		{
		    globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"Evaluator",__FILE__,"Unexpected end of file... Cube line...");
		    delete [] nre;
		    delete [] factByAttrName;
		    delete [] factOpOnWhatAttrName;
		    delete [] groupByWhat;
		    delete [] subtreeParent;
		    for (int j=0; j<dimnum; j++)
			if (groupByAttrname[j]) delete [] groupByAttrname[j];
		    for (int j =0; j<dimnum;j++) {
			delete [] groupByRelaxType[j];
		    }
		    delete [] groupByRelaxType;
		    delete [] fileName;
		    if (sortorderfileName) delete [] sortorderfileName;
		    curr=NULL; return;
		}

		QueryEvaluationTreeNode *oper = evaluator->getQueryEvalNode(newLine,queryInput);
		if (oper == NULL)
		{
		    globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"Evaluator",__FILE__,"Unexpected operand returned... Cube line...");
		    delete [] nre;
		    delete [] factByAttrName;
		    delete [] factOpOnWhatAttrName;
		    delete [] groupByWhat;
		    delete [] subtreeParent;
		    for (int j=0; j<dimnum; j++)
			if (groupByAttrname[j]) delete [] groupByAttrname[j];
		    for (int j =0; j<dimnum;j++) {
			delete [] groupByRelaxType[j];
		    }
		    delete [] groupByRelaxType;
		    delete [] fileName;
		    if (sortorderfileName) delete [] sortorderfileName;
		    curr=NULL; return;
		}
		curr = new QueryEvaluationTreeCubeNode(exSize, cubeBy, factNRE, factByWhat, factByAttrName,
			factOperation, factOpNRE, factOpOnWhat, factOpOnWhatAttrName,
			dimnum , nre, groupByRelaxType, subtreeParent, groupByWhat, 
			groupByAttrname, useExternalSort, fileName, sortorderfileName, assignedDummyNRE1,assignedDummyNRE2,oper);
		if (useExternalSort)
		{	if ((cubeBy == 2) ||(cubeBy == 3))
		    evaluator->fileIDsArraySize = evaluator->fileIDsArraySize + dimnum;
		}
	    }

