/*
COPYRIGHT  ?2000-2004 
THE REGENTS OF THE UNIVERSITY OF MICHIGAN
ALL RIGHTS RESERVED

PERMISSION IS GRANTED TO USE, COPY, CREATE DERIVATIVE WORKS AND REDISTRIBUTE THIS SOFTWARE AND SUCH DERIVATIVE WORKS FOR 
NONCOMMERCIAL EDUCATION AND RESEARCH PURPOSES, SO LONG AS NO FEE IS CHARGED, AND SO LONG AS THE COPYRIGHT NOTICE ABOVE, 
THIS GRANT OF PERMISSION, AND THE DISCLAIMER BELOW APPEAR IN ALL COPIES MADE; AND SO LONG AS THE NAME OF THE UNIVERSITY 
OF MICHIGAN IS NOT USED IN ANY ADVERTISING OR PUBLICITY PERTAINING TO THE USE OR DISTRIBUTION OF THIS SOFTWARE WITHOUT 
SPECIFIC, WRITTEN PRIOR AUTHORIZATION.

THIS SOFTWARE IS PROVIDED AS IS, WITHOUT REPRESENTATION FROM THE UNIVERSITY OF MICHIGAN AS TO ITS FITNESS FOR ANY PURPOSE, 
AND WITHOUT WARRANTY BY THE UNIVERSITY OF MICHIGAN OF ANY KIND, EITHER EXPRESS OR IMPLIED, INCLUDING WITHOUT LIMITATION THE 
IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE. THE REGENTS OF THE UNIVERSITY OF MICHIGAN SHALL 
NOT BE LIABLE FOR ANY DAMAGES, INCLUDING SPECIAL, INDIRECT, INCIDENTAL, OR CONSEQUENTIAL DAMAGES, WITH RESPECT TO ANY CLAIM 
ARISING OUT OF OR IN CONNECTION WITH THE USE OF THE SOFTWARE, EVEN IF IT HAS BEEN OR IS HEREAFTER ADVISED OF THE POSSIBILITY 
OF SUCH DAMAGES.
*/

#ifndef __CubeCounterBasedIterator_h
#define __CubeCounterBasedIterator_h
#include <timber-compat.h>

#include "../../Evaluator/EvaluatorClass.h"
#include "../../Evaluator/Evaluator_definitions.h"
#include <math.h>
#include <map>
#include <vector>

#include "../ValueSort/ValueSortIterator.h"
#include "../ValueSort/ExternalValueSortIterator.h"

typedef vector<char*> Cuboid; //Cuboid key value, A[PC,AD][ANCNRE], AB, ABC
typedef vector<double> CuboidValue; //Aggregate value for each cuboid, multiple if it is AVG(keep COUNT&SUM)
struct CuboidKeyCompare
{
  bool operator()(const Cuboid* s1, const Cuboid* s2) const
  {
	  size_t s1_size = s1->size();
	  size_t s2_size = s2->size();
	  for (unsigned int i=0; i < (s1_size>=s2_size?s1_size:s2_size); i++){
		  if ((strcmp("ALL",(char*)s1->at(i)) == 0) && (strcmp("ALL",(char*)s2->at(i)) != 0))
			  return false;
		  if ((strcmp("ALL",(char*)s2->at(i)) == 0) && (strcmp("ALL",(char*)s1->at(i)) != 0))
			  return true;
		  int cmp = strcmp((char*)s1->at(i),(char*)s2->at(i));
		  if (cmp < 0)
			  return true;
		  else if (cmp > 0)
			  return false;
	  }
	  return false;
  }
};


typedef map< Cuboid*, CuboidValue*, CuboidKeyCompare > Map_Cuboid_To_Value;

/**
* An access method that performs a cube operation. There are 3 algorithms to choose.
* @see IteratorClass
* @see EvaluatorClass
* @see WitnessTree
* @author Nuwee Wiwatwattana 
* @version 1.0
*/
class CubeCounterBasedIterator : public IteratorClass
{
public:
	/**
	Constructor.
	@param input is where this iterator gets its input trees.
	@param sizeExpected is the number of trees this iterator expects to get from the input iterator.
	@param cubeBy is one of the following:
			
	@param data_mng an instance of the data manager.
	**/
	CubeCounterBasedIterator(IteratorClass *input, int sizeExpected, int cubeBy, int dimnum, NREType factNRE,
									int factByWhat, char* factByAttrName, int factByOperation,
									NREType factOpNRE, int factOpOnWhat, char* factOpOnWhatAttrName,
									NREType *nre, bool** groupByRelaxType,NREType* subtreeParent, 
									int* groupByWhat, char** groupByAttrName,
									bool isAlreadySorted,
									DataMng *dataMng, char* fileName, EvaluatorClass* evalClass);

	/**
	Destructor.
	Releases memory used by output buffer and sort array.
	**/
	~CubeCounterBasedIterator();

	/**
	Access Method
	gets the next output from this iterator.
	@param node is a pointer that well be set to the output buffer or NULL (indicating that
	there are no more results).
	**/
	void next(WitnessTree *&node);

	void writeOutput();

private:
	/**
	@param doubleValue (return value)
	@param charValue (return value)
	**/
	int getNodeValue(WitnessTree* elem1, NREType nre,char* attrName, int nodeGroupByType, char*& charValue);
	int getNodeValue(WitnessTree* elem1, NREType factOpNRE,int factOpOnWhat, char* factOpAttrName, double* retValue);

	void CubePartition(WitnessTree* input, int start, int end, int current_dim, int old_dim);

	void constructAndInsertCuboid(WitnessTree* treeInput);
	
	void computeAllCuboid(WitnessTree* treeInput);

	int moveRelevantToFront(int start, int end, int dim, int relationship, NREType ancNRE);

	int cubeBy;
	int size;
	int dimnum;

	bool** groupByRelaxType;
	int* groupByWhat;
	NREType* subtreeParent;
	int factByOperation;

	NREType factNRE;
	NREType factOpNRE;
	int factOpOnWhat;
	char* factOpOnWhatAttrName;

	IteratorClass *input;
	WitnessTree *sortArray;
	WitnessTree *inTuple;
	
	char* fileName;
	FILE *output;
	DataMng *dataMng;

	Map_Cuboid_To_Value cubeResult;
	Map_Cuboid_To_Value::iterator cubeIter;

	CuboidValue* allCuboidValue;
};


#endif
