/*
COPYRIGHT  ?2000-2004 
THE REGENTS OF THE UNIVERSITY OF MICHIGAN
ALL RIGHTS RESERVED

PERMISSION IS GRANTED TO USE, COPY, CREATE DERIVATIVE WORKS AND REDISTRIBUTE THIS SOFTWARE AND SUCH DERIVATIVE WORKS FOR 
NONCOMMERCIAL EDUCATION AND RESEARCH PURPOSES, SO LONG AS NO FEE IS CHARGED, AND SO LONG AS THE COPYRIGHT NOTICE ABOVE, 
THIS GRANT OF PERMISSION, AND THE DISCLAIMER BELOW APPEAR IN ALL COPIES MADE; AND SO LONG AS THE NAME OF THE UNIVERSITY 
OF MICHIGAN IS NOT USED IN ANY ADVERTISING OR PUBLICITY PERTAINING TO THE USE OR DISTRIBUTION OF THIS SOFTWARE WITHOUT 
SPECIFIC, WRITTEN PRIOR AUTHORIZATION.

THIS SOFTWARE IS PROVIDED AS IS, WITHOUT REPRESENTATION FROM THE UNIVERSITY OF MICHIGAN AS TO ITS FITNESS FOR ANY PURPOSE, 
AND WITHOUT WARRANTY BY THE UNIVERSITY OF MICHIGAN OF ANY KIND, EITHER EXPRESS OR IMPLIED, INCLUDING WITHOUT LIMITATION THE 
IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE. THE REGENTS OF THE UNIVERSITY OF MICHIGAN SHALL 
NOT BE LIABLE FOR ANY DAMAGES, INCLUDING SPECIAL, INDIRECT, INCIDENTAL, OR CONSEQUENTIAL DAMAGES, WITH RESPECT TO ANY CLAIM 
ARISING OUT OF OR IN CONNECTION WITH THE USE OF THE SOFTWARE, EVEN IF IT HAS BEEN OR IS HEREAFTER ADVISED OF THE POSSIBILITY 
OF SUCH DAMAGES.
*/

#include "CubeBottomUpIterator.h"
#include <float.h>
#include <assert.h>
#include <map>
using std::map;
using std::pair;

int gCurrentDim1;
int gDimNumBUC;
NREType* gNREDim1;
int* gWhereEmptyGoesDim1;
int* gOrderDim1;
char** gAttrNameDim1;
int* gSortByDim1;
OutputTreeRec* outputRec;
int gRelationship;
NREType gFactNRE;

DataMng *gdataMngCube1;
int numCube;

int compareCubeNodesValSort1(const void *elem1,const void *elem2)
{
	for (int i=gCurrentDim1; i<gDimNumBUC; i++)
	{
		int index1 = ((WitnessTree *)elem1)->getIndexOfNRE(gNREDim1[i]);
		int index2 = ((WitnessTree *)elem2)->getIndexOfNRE(gNREDim1[i]);
		if (index1 == FAILURE && index2 == FAILURE)
			continue;
		if (index1 == FAILURE)
			return (-1*gWhereEmptyGoesDim1[i]);
		if (index2 == FAILURE)
			return (gWhereEmptyGoesDim1[i]);

		FileIDType fileid1 = EvaluatorClass::getFileID(((ComplexListNode *)((WitnessTree *)elem1)->getNodeByIndex(index1))->getFileIndex());
		if (fileid1 == -1)
			return -1;
		FileIDType fileid2 = EvaluatorClass::getFileID(((ComplexListNode *)((WitnessTree *)elem2)->getNodeByIndex(index2))->getFileIndex());
		if (fileid2 == -1)
			return -1;

		switch (gSortByDim1[i])
		{
		case SORTBY_TEXT_NUM:
		case SORTBY_TEXT_STR:
			{
				int res1 = EvaluatorClass::GetText((WitnessTree *)elem1,index1,gdataMngCube1,fileid1);
				int res2 = EvaluatorClass::GetText((WitnessTree *)elem2,index2,gdataMngCube1,fileid2);
				if ((res1 == FAILURE  || res1 == 0) && (res2 == FAILURE  || res2 == 0))
					continue;
				if (res1 == FAILURE  || res1 == 0)
					return (-1*gWhereEmptyGoesDim1[i]);

				if (res2 == FAILURE  || res2 == 0)
					return (gWhereEmptyGoesDim1[i]);
				char *txt1 = ((DM_CharNode *)((ComplexListNode *)((WitnessTree *)elem1)->getNodeByIndex(res1))->GetData())->getCharValue();
				char *txt2 = ((DM_CharNode *)((ComplexListNode *)((WitnessTree *)elem2)->getNodeByIndex(res2))->GetData())->getCharValue();

				if (gSortByDim1[i] == SORTBY_TEXT_NUM)
				{
					double num1 = atof(txt1);
					double num2 = atof(txt2);
					if (num1 == num2)
						continue;
					else
						return (int)(gOrderDim1[i]* ceil(num1 - num2));
				}
				else
				{
					int r = strcmp(txt1,txt2);
					if (r == 0)
						continue;
					else
						return gOrderDim1[i]*r;
				}
			}
			break;
		case SORTBY_ATTRIBUTE_NUM:
		case SORTBY_ATTRIBUTE_STR:
			{
				int res1 = EvaluatorClass::GetAttributes((WitnessTree *)elem1,index1,gdataMngCube1,fileid1);
				int res2 = EvaluatorClass::GetAttributes((WitnessTree *)elem2,index2,gdataMngCube1,fileid2);
				if (res1 == FAILURE && res2 == FAILURE)
					continue;
				if (res1 == FAILURE)
					return (-1*gWhereEmptyGoesDim1[i]);

				if (res2 == FAILURE)
					return (gWhereEmptyGoesDim1[i]);

				Value *val1 = ((DM_AttributeNode *)((ComplexListNode *)((WitnessTree *)elem1)->getNodeByIndex(index1+1))->GetData())->getAttr(gAttrNameDim1[i]);
				Value *val2 = ((DM_AttributeNode *)((ComplexListNode *)((WitnessTree *)elem2)->getNodeByIndex(index2+1))->GetData())->getAttr(gAttrNameDim1[i]);

				if (!val1 && !val2) 
					continue;

				if (!val1)
					return (-1*gWhereEmptyGoesDim1[i]);
				if (!val2)
					return (gWhereEmptyGoesDim1[i]);

				char *txt1 = val1->getStrValue();
				char *txt2 = val2->getStrValue();
				if (gSortByDim1[i] == SORTBY_ATTRIBUTE_NUM)
				{
					double num1 = atof(txt1);
					double num2 = atof(txt2);
					if (num1 == num2)
						continue;
					else
						return (int)(gOrderDim1[i]* ceil(num1 - num2));
				}
				else
				{
					int r = strcmp(txt1,txt2);
					if (r == 0)
						continue;
					else
						return gOrderDim1[i]*r;
				}
			}
			break;
		case SORTBY_TAGNAME:
			{
				ComplexListNode *n1 = (ComplexListNode *)((WitnessTree *)elem1)->getNodeByIndex(index1);
				ComplexListNode *n2 = (ComplexListNode *)((WitnessTree *)elem2)->getNodeByIndex(index2);
				DM_DataNode *dn1 = n1->GetData();
				DM_DataNode *dn2 = n2->GetData();
				if (dn1 == NULL && dn2 == NULL)
					continue;
				if (dn1 == NULL)
					return -1*gWhereEmptyGoesDim1[i];

				if (dn2 == NULL)
					return gWhereEmptyGoesDim1[i];

				if (dn1->getFlag() != ELEMENT_NODE && dn2->getFlag() != ELEMENT_NODE)
					continue;

				if (dn1->getFlag() != ELEMENT_NODE)
					return (-1*gWhereEmptyGoesDim1[i]);

				if (dn2->getFlag() != ELEMENT_NODE)
					return (gWhereEmptyGoesDim1[i]);
				if (((DM_ElementNode *)dn1)->getTag() == ((DM_ElementNode *)dn2)->getTag())
					continue;

				char *tag1 = gdataMngCube1->getPhysicalDataMng()->getXMLNameTable()->getNameByCode(((DM_ElementNode *)dn1)->getTag());
				char *tag2 = gdataMngCube1->getPhysicalDataMng()->getXMLNameTable()->getNameByCode(((DM_ElementNode *)dn2)->getTag());
				int r = strcmp(tag1, tag2);
				if (r == 0)
					continue;
				else
					return gOrderDim1[i] * r;
			}
			break;
		case SORTBY_VALUE_NUM:
		case SORTBY_VALUE_STR:
			{
				DM_DataNode *dn1 = ((ComplexListNode *)((WitnessTree *)elem1)->getNodeByIndex(index1))->GetData();
				DM_DataNode *dn2 = ((ComplexListNode *)((WitnessTree *)elem2)->getNodeByIndex(index2))->GetData();
				if (dn1 == NULL && dn2 == NULL)
					continue;
				if (dn1 == NULL)
					return -1*gWhereEmptyGoesDim1[i];

				if (dn2 == NULL)
					return gWhereEmptyGoesDim1[i];

				char *txt1;
				char *txt2;
				Value *val1;
				Value *val2;
				if (dn1->getFlag() == ELEMENT_NODE)
					txt1 = gdataMngCube1->getPhysicalDataMng()->getXMLNameTable()->getNameByCode(((DM_ElementNode *)dn1)->getTag());

				else if (dn1->getFlag() == DOCUMENT_NODE)
				{
					if (((DM_DocumentNode *)dn1)->getXMLFileName())
						txt1 = ((DM_DocumentNode *)dn1)->getXMLFileName();
					else
						txt1 = NULL;
				}
				else if (dn1->getFlag() == ATTRIBUTE_NODE)
				{
					//if attribute node, return the value of attribute "attrName"

					val1 = ((DM_AttributeNode *)dn1)->getAttr(gAttrNameDim1[i]);
					if (val1 != NULL)
					{
						if (val1->getStrValue() != NULL && strlen(val1->getStrValue()) != 0)
							txt1 = val1->getStrValue();
						else
							txt1 = NULL;
					}
					else
						txt1 = NULL;
				} 
				else
				{
					//if text node, return the text value
					if (((DM_CharNode *)dn1)->getCharValue())
						txt1 = ((DM_CharNode *)dn1)->getCharValue();
					else
						txt1 = NULL;
				}

				//getting second vLUES
				if (dn2->getFlag() == ELEMENT_NODE)
					txt2 = gdataMngCube1->getPhysicalDataMng()->getXMLNameTable()->getNameByCode(((DM_ElementNode *)dn2)->getTag());

				else if (dn2->getFlag() == DOCUMENT_NODE)
				{
					if (((DM_DocumentNode *)dn2)->getXMLFileName())
						txt2 = ((DM_DocumentNode *)dn2)->getXMLFileName();
					else
						txt2 = NULL;
				}
				else if (dn2->getFlag() == ATTRIBUTE_NODE)
				{
					//if attribute node, return the value of attribute "attrName"

					val2 = ((DM_AttributeNode *)dn2)->getAttr(gAttrNameDim1[i]);
					if (val2 != NULL)
					{
						if (val2->getStrValue() != NULL && strlen(val2->getStrValue()) != 0)
							txt2 = val2->getStrValue();
						else
							txt2 = NULL;
					}
					else
						txt2 = NULL;
				} 
				else
				{
					//if text node, return the text value
					if (((DM_CharNode *)dn2)->getCharValue())
						txt2 = ((DM_CharNode *)dn2)->getCharValue();
					else
						txt2 = NULL;
				}
				if (!txt1 && !txt2) 
					continue;

				if (!txt1)
					return (-1*gWhereEmptyGoesDim1[i]);
				if (!txt2)
					return (gWhereEmptyGoesDim1[i]);

				if (gSortByDim1[i] == SORTBY_VALUE_NUM)
				{
					double num1 = atof(txt1);
					double num2 = atof(txt2);
					if (num1 == num2)
						continue;
					else
						return (int)(gOrderDim1[i]* ceil(num1 - num2));
				}
				else
				{
					int r = strcmp(txt1,txt2);
					if (r == 0)
						continue;
					else
						return gOrderDim1[i]*r;
				}

			}
			break;
		case SORT_BY_START_KEY:
			{
				KeyType sk1 = ((ComplexListNode *)((WitnessTree *)elem1)->getNodeByIndex(index1))->GetStartPos();
				KeyType sk2 = ((ComplexListNode *)((WitnessTree *)elem2)->getNodeByIndex(index2))->GetStartPos();
				if (sk1 == sk2)
					continue;
				else
				{
					if (sk1 < sk2)
						return (-1*gOrderDim1[i]);
					else
						return (gOrderDim1[i]);
				}
			}
			break;
		}
	}
	int n = ((WitnessTree *)elem1)->length() < ((WitnessTree *)elem2)->length()?
		((WitnessTree *)elem1)->length() : ((WitnessTree *)elem2)->length();
	for (int i=0; i<n; i++)
	{
		if (((ComplexListNode *)((WitnessTree *)elem1)->findNode(i))->GetStartPos() ==
			((ComplexListNode *)((WitnessTree *)elem2)->findNode(i))->GetStartPos())
			continue;
		else
		{
			if (((ComplexListNode *)((WitnessTree *)elem1)->findNode(i))->GetStartPos() <
				((ComplexListNode *)((WitnessTree *)elem2)->findNode(i))->GetStartPos())
				return -1;
			else
				return 1;
		}
	}
	if (((WitnessTree *)elem1)->length() < ((WitnessTree *)elem2)->length())
		return -1;
	else if (((WitnessTree *)elem1)->length() > ((WitnessTree *)elem2)->length())
		return 1;
	return 0;
}

CubeBottomUpIterator::CubeBottomUpIterator(IteratorClass *input, int sizeExpected, int cubeBy, int dimnum, NREType factNRE,
										   int factByWhat, char* factByAttrName, int factByOperation,
										   NREType factOpNRE, int factOpOnWhat, char* factOpOnWhatAttrName,
										   NREType *nre, bool** groupByRelaxType, NREType* subtreeParent,
										   int* groupByWhat, char** groupByAttrName, bool useExternalSort,
										   DataMng *dataMng, char* fileName, EvaluatorClass* evalClass)
{
	at = 0;
	this->cubeBy = cubeBy;
	this->evalClass = evalClass;
	this->dataMng = dataMng;
	this->fileName = fileName;
	gdataMngCube1 = dataMng;
	this->dimnum = dimnum;
	gDimNumBUC = dimnum;
	this->nre = nre;
	this->groupByAttrName = groupByAttrName;
	this->groupByWhat = groupByWhat;
	this->groupByRelaxType = groupByRelaxType;
	this->subtreeParent = subtreeParent;
	this->factNRE = factNRE;
	gFactNRE = factNRE;
	this->factByWhat = factByWhat;
	this->factByAttrName = factByAttrName;
	this->factByOperation = factByOperation;
	this->factOpNRE = factOpNRE;
	this->factOpOnWhat = factOpOnWhat;
	this->factOpOnWhatAttrName = factOpOnWhatAttrName;
	this->useExternalSort = useExternalSort;

	this->no_overlap = gSettings->getBooleanValue("NO_OVERLAP",false);

	numCube = 0;

	//for global sort by, for later in-memory quicksort operation
	gNREDim1 =  this->nre;
	gAttrNameDim1 = this->groupByAttrName;
		
	gSortByDim1 = new int[dimnum];
	int hereByWhat;
	for (int i=0 ; i < this->dimnum ; i++)
	{
		hereByWhat = groupByWhat[i];

		if (hereByWhat == GROUPBY_ATTRIBUTE_NUM) gSortByDim1[i] = SORTBY_ATTRIBUTE_NUM;
		else if (hereByWhat == GROUPBY_ATTRIBUTE_STR) gSortByDim1[i] = SORTBY_ATTRIBUTE_STR;
		else if (hereByWhat == GROUPBY_TEXT_NUM) gSortByDim1[i] = SORTBY_TEXT_NUM;
		else if (hereByWhat == GROUPBY_TEXT_STR) gSortByDim1[i] = SORTBY_TEXT_STR;
		else if (hereByWhat == GROUPBY_STARTKEY) gSortByDim1[i] = SORT_BY_START_KEY;
		else if (hereByWhat == GROUPBY_VALUE_NUM) gSortByDim1[i] = SORTBY_VALUE_NUM;
		else if (hereByWhat == GROUPBY_VALUE_STR) gSortByDim1[i] = SORTBY_VALUE_STR;
	}

	gOrderDim1 = new int[dimnum];
	for (int i=0 ; i < dimnum ; i++)
	{
		gOrderDim1[i] = ASCENDING;
	}

	gWhereEmptyGoesDim1 = new int[dimnum];
	for (int i=0 ; i < dimnum ; i++)
	{
		gWhereEmptyGoesDim1[i] = EMPTY_AT_END;
	}

	outputRec = new OutputTreeRec[this->dimnum];
	//set initial output tree
	for (int i = 0; i < this->dimnum ; i++){
		outputRec[i].anc = -1;
		outputRec[i].rel = -1;
		outputRec[i].value = NULL;
	}
	output = fopen(this->fileName,"w");

	this->input = input;

	size = 0;
	if (sizeExpected <= 0)
		sizeExpected = gSettings->getIntegerValue("INITIAL_DEFAULT_SORT_ARRAY_SIZE",INITIAL_SORT_ARRAY_SIZE_DEFAULT);
	sizeExpected++;
	treeArray = new WitnessTree*[sizeExpected];

	for (int i = 0 ; i < sizeExpected; i++) {
		treeArray[i] = NULL;
	}

	//TODO: With NoLND axis
	if (!useExternalSort){
		this->input->next(inTuple);
		while (inTuple)
		{
			inTuple->switchToComplex(dataMng);

			if (size >= sizeExpected)
			{
				//if sortArray size is not enough-->double it
				WitnessTree **tmp = treeArray;
				sizeExpected *= 2;
				treeArray = new WitnessTree*[sizeExpected];
				//memcpy(treeArray, tmp, size * sizeof(WitnessTree));
				//
				// Copy old witness trees into new array, and allow
				// old tree's to be deleted. This fixes a memory leak.
				//
				for (int j = 0 ; j < size ; j++)
				{
					treeArray[j] = tmp[j];
					tmp[j]->setDeleteBuffers(true) ;
				}
				//
				// Allow the old WitnessTrees to be deleted
				//
				delete [] tmp;
			}
			treeArray[size] = new WitnessTree;
			treeArray[size]->copyTree(inTuple);
			treeArray[size]->setDeleteBuffers(true);
			size++;

			inTuple->deleteAllNodes();

			this->input->next(inTuple);
		}
		delete this->input;	
	}

	//4. for each dimension
	double cubeduration;
	for (int d = 0 ; d < this->dimnum ; d++){
		//dblp schema optimization
		if(gSettings->getBooleanValue("DBLP",false) == true) {
			if (d ==0) this->no_overlap = true;
			else this->no_overlap = false;
		}

		//sort input by dim, and fact
		gCurrentDim1 = d;

		//memory optimization
		//if (d > gSettings->getIntegerValue("DIM_LIMIT")) return;

		//6. Partition, no optimization that will actually help if no overlap or no missing

		char* oldPartitionValue = NULL;
		char* thisPartitionValue = NULL;
		int partitionStartIndex = 0; //real index
		int partitionEndIndex;
		int k =0;

		clock_t starttime, finishtime; 
		double sortDuration;
		starttime = clock();
		if (useExternalSort) { //if use ext sort
			//cout << endl << "--Sort on dimension--" << d << " up" << endl << endl;
			serial_t fileID = 0;
			serial_t recID = 0;
			int numWrites = 0;
			fileID = evalClass->fileIDsArray[evalClass->fileIDsArrayPtr];
			evalClass->fileIDsArrayPtr++;
			numWrites = evalClass->createRecID(recID);
			if (numWrites == FAILURE)
			{
				globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"Evaluator",__FILE__, "operand returned is NULL. sort process eval node..." );
			}

			//construct info for external sorting, these will be destroyed by externalsort iterator

			NREType* nreDimExSort;
			nreDimExSort = new NREType[this->dimnum-d];
			for (int i=0 ; i < this->dimnum - d ; i++)
			{
				nreDimExSort[i] = this->nre[i+d];
			}

			char** attrNameDimExSort;
			attrNameDimExSort = new char*[this->dimnum-d];
			for (int i=0 ; i < this->dimnum - d ; i++)
			{
				attrNameDimExSort[i] = new char[strlen(this->groupByAttrName[i+d])+1];
				strcpy(attrNameDimExSort[i],this->groupByAttrName[i+d]);
			}

			int* sortByDimExSort;
			sortByDimExSort = new int[dimnum-d];
			//for global sort by, for later operation
			int hereByWhat;
			for (int i=0 ; i < this->dimnum - d ; i++)
			{
				hereByWhat = groupByWhat[i+d];

				if (hereByWhat == GROUPBY_ATTRIBUTE_NUM) sortByDimExSort[i] = SORTBY_ATTRIBUTE_NUM;
				else if (hereByWhat == GROUPBY_ATTRIBUTE_STR) sortByDimExSort[i] = SORTBY_ATTRIBUTE_STR;
				else if (hereByWhat == GROUPBY_TEXT_NUM) sortByDimExSort[i] = SORTBY_TEXT_NUM;
				else if (hereByWhat == GROUPBY_TEXT_STR) sortByDimExSort[i] = SORTBY_TEXT_STR;
				else if (hereByWhat == GROUPBY_STARTKEY) sortByDimExSort[i] = SORT_BY_START_KEY;
				else if (hereByWhat == GROUPBY_VALUE_NUM) sortByDimExSort[i] = SORTBY_VALUE_NUM;
				else if (hereByWhat == GROUPBY_VALUE_STR) sortByDimExSort[i] = SORTBY_VALUE_STR;
			}

			int* orderDimExSort;
			orderDimExSort = new int[dimnum-d];
			for (int i=0 ; i < dimnum-d ; i++)
			{
				orderDimExSort[i] = ASCENDING;
			}

			int* whereEmptyGoesDimExSort;
			whereEmptyGoesDimExSort = new int[dimnum-d];
			for (int i=0 ; i < dimnum-d ; i++)
			{
				whereEmptyGoesDimExSort[i] = EMPTY_AT_END;
			}

			if (d == 0) {
				//if it's the first dimension, get input from previous iterator
				this->input = new ExternalValueSortIterator(this->input,this->dimnum,sortByDimExSort,nreDimExSort,attrNameDimExSort,
					orderDimExSort,dataMng,whereEmptyGoesDimExSort,fileID,recID,numWrites);
			}
			else {

				this->input = new ExternalValueSortIterator(this,this->dimnum - d,sortByDimExSort,nreDimExSort,attrNameDimExSort,
					orderDimExSort,dataMng,whereEmptyGoesDimExSort,fileID,recID,numWrites,true);
			}
			finishtime = clock();
			sortDuration = (double)(finishtime - starttime) / CLOCKS_PER_SEC;
			cout << sortDuration << " seconds to sort" << endl;

			starttime = clock();

			size = 0;
			this->input->next(inTuple);
			while (inTuple)
			{
				k = size;
				inTuple->switchToComplex(dataMng);
				if (!treeArray[size]) treeArray[size] = new WitnessTree;
				treeArray[size]->copyTree(inTuple);
				treeArray[size]->setDeleteBuffers(true);
				size++;

				//inTuple->deleteAllNodes();

				partitionEndIndex = size - 1;

				//get the value of the current dimension value
				//if it start a new partition, stop and do the recursive function
				int success = this->getNodeValue(treeArray[k], this->nre[d], this->groupByAttrName[d], this->groupByWhat[d],thisPartitionValue);
				if (success == FAILURE) { //this maybe the missing dimension, so just ignore and cont
					//???? is this always true, what if the missing is not the last partition????
					//should not be, b/c we always sort, and let ALL as the last value
					//cout << "Found missing partition at" << k << endl;
					thisPartitionValue = NULL;
				}

				if (((thisPartitionValue == NULL) && (oldPartitionValue != NULL)) || 
					((oldPartitionValue != NULL) && (strcmp(oldPartitionValue,thisPartitionValue) !=0)))
				{
					//process old partition
					//cout << "Dim[" << d << "] " << oldPartitionValue << " from array " << partitionStartIndex << " to array " << k-1 << endl;	
					//for each relaxation
					partitionEndIndex = k-1;
					for (int g = 0 ; g < 4 ; g++)
					{
						if (this->groupByRelaxType[d][g] == true) //if relaxable
						{
							if (g == 0) //LND-AD 
							{
								//if d's value != EMPTY, which is always the case
								outputRec[d].value = oldPartitionValue;
								outputRec[d].rel = ANCS_DESC;
								outputRec[d].anc = -1;
								this->bottomUpCube(partitionStartIndex, k-1, d+1, d);
							}
							else if (g == 1) //LND-PC, PC-AD
							{
								//resort by PC of this axis, next axis up by value
								partitionEndIndex = this->moveRelevantToFront(partitionStartIndex, partitionEndIndex, d, PARENT_CHILD, this->factNRE);
								if (partitionEndIndex != -1) //if it's -1, means no trees satisfy this condition
								{

									outputRec[d].value = oldPartitionValue;
									outputRec[d].rel = PARENT_CHILD;
									outputRec[d].anc = -1;
									this->bottomUpCube(partitionStartIndex, partitionEndIndex, d+1, d);
								}
							}
							else if (g == 2) //SP-AD
							{		
								//resort by PC of this axis, next axis up by value
								partitionEndIndex = this->moveRelevantToFront(partitionStartIndex, partitionEndIndex, d, ANCS_DESC, this->subtreeParent[d]);
								if (partitionEndIndex != -1) //if it's -1, means no trees satisfy this condition
								{

									outputRec[d].value = oldPartitionValue;
									outputRec[d].rel = ANCS_DESC;
									outputRec[d].anc = this->subtreeParent[d];
									this->bottomUpCube(partitionStartIndex, partitionEndIndex, d+1, d);
								}
							}
							else if (g == 3) //SP-PC
							{
								partitionEndIndex = this->moveRelevantToFront(partitionStartIndex, partitionEndIndex, d, PARENT_CHILD, this->subtreeParent[d]);
								if (partitionEndIndex != -1) //if it's -1, means no trees satisfy this condition
								{

									outputRec[d].value = oldPartitionValue;
									outputRec[d].rel = PARENT_CHILD;
									outputRec[d].anc = this->subtreeParent[d];
									this->bottomUpCube(partitionStartIndex, partitionEndIndex, d+1, d);
								}
							}
						}

					}//for each relaxation
					//start new partition
					//cout << "--end computing cube of this partition" << endl;
					partitionStartIndex = k;
				}
				//if ((thisPartitionValue == NULL) && (oldPartitionValue != NULL))
				//	break; //do not need to break for Externalsort, otherwise we will miss the retrieval of last partition that is missing
				oldPartitionValue = thisPartitionValue;

				this->input->next(inTuple);
			}
			finishtime = clock();

			delete this->input;
			at = 0;
		}
		else if (!useExternalSort)
		{
			EvalQuickSort s;
			//cout << endl << "--Sort on dimension--" << d << " up" << endl << endl;
			if (s.quickSort(treeArray,0,size-1,compareCubeNodesValSort1) == FAILURE) {
				size = 0;
				return;
			}
			finishtime = clock();
			sortDuration = (double)(finishtime - starttime) / CLOCKS_PER_SEC;
			cout << sortDuration << " seconds to sort" << endl;

			
			starttime = clock();

			partitionEndIndex = size - 1;

			for (int k = 0 ; k < size ; k++) { //go through each tuple

				//get the value of the current dimension value
				//if it start a new partition, stop and do the recursive function
				int success = this->getNodeValue(treeArray[k], gNREDim1[d], gAttrNameDim1[d], this->groupByWhat[d],thisPartitionValue);
				if (success == FAILURE) { //this maybe the missing dimension, so just ignore and cont
					//???? is this always true, what if the missing is not the last partition????
					//should not be, b/c we always sort, and let ALL as the last value
					thisPartitionValue = NULL;
				}

				if (((thisPartitionValue == NULL) && (oldPartitionValue != NULL)) || 
					((oldPartitionValue != NULL) && (strcmp(oldPartitionValue,thisPartitionValue) !=0)))
				{
					//process old partition
					//cout << oldPartitionValue << " from array " << partitionStartIndex << " to array " << k-1 << endl;	
					//for each relaxation
					partitionEndIndex = k-1;
					for (int g = 0 ; g < 4 ; g++)
					{
						if (this->groupByRelaxType[d][g] == true) //if relaxable
						{
							if (g == 0) //LND-AD 
							{
								//if d's value != EMPTY, which is always the case
								outputRec[d].value = oldPartitionValue;
								outputRec[d].rel = ANCS_DESC;
								outputRec[d].anc = -1;
								this->bottomUpCube(partitionStartIndex, k-1, d+1, d);
							}
							else if (g == 1) //LND-PC, PC-AD
							{
								//resort by PC of this axis, next axis up by value
								partitionEndIndex = this->moveRelevantToFront(partitionStartIndex, partitionEndIndex, d, PARENT_CHILD, this->factNRE);
								if (partitionEndIndex != -1) //if it's -1, means no trees satisfy this condition
								{

									outputRec[d].value = oldPartitionValue;
									outputRec[d].rel = PARENT_CHILD;
									outputRec[d].anc = -1;
									this->bottomUpCube(partitionStartIndex, partitionEndIndex, d+1, d);
								}
							}
							else if (g == 2) //SP-AD
							{		
								//resort by PC of this axis, next axis up by value
								partitionEndIndex = this->moveRelevantToFront(partitionStartIndex, partitionEndIndex, d, ANCS_DESC, this->subtreeParent[d]);
								if (partitionEndIndex != -1) //if it's -1, means no trees satisfy this condition
								{

									outputRec[d].value = oldPartitionValue;
									outputRec[d].rel = ANCS_DESC;
									outputRec[d].anc = this->subtreeParent[d];
									this->bottomUpCube(partitionStartIndex, partitionEndIndex, d+1, d);
								}
							}
							else if (g == 3) //SP-PC
							{
								partitionEndIndex = this->moveRelevantToFront(partitionStartIndex, partitionEndIndex, d, PARENT_CHILD, this->subtreeParent[d]);
								if (partitionEndIndex != -1) //if it's -1, means no trees satisfy this condition
								{

									outputRec[d].value = oldPartitionValue;
									outputRec[d].rel = PARENT_CHILD;
									outputRec[d].anc = this->subtreeParent[d];
									this->bottomUpCube(partitionStartIndex, partitionEndIndex, d+1, d);
								}
							}
						}

					}//for each relaxation
					//start new partition
					partitionStartIndex = k;
				}
				if ((thisPartitionValue == NULL) && (oldPartitionValue != NULL))
					break;
				oldPartitionValue = thisPartitionValue;

			}

		}
		//process last partition that is not missing
		if (thisPartitionValue != NULL) {
			//cout << oldPartitionValue << " from array " << partitionStartIndex << " to array " << k-1 << endl;	
			partitionEndIndex = size-1;
			for (int g = 0 ; g < 4 ; g++)
			{
				if (this->groupByRelaxType[d][g] == true) //if relaxable
				{
					if (g == 0) //LND-AD 
					{
						//if d's value != EMPTY, which is always the case
						outputRec[d].value = oldPartitionValue;
						outputRec[d].rel = ANCS_DESC;
						outputRec[d].anc = -1;
						this->bottomUpCube(partitionStartIndex, partitionEndIndex, d+1, d);
					}
					else if (g == 1) //LND-PC, PC-AD
					{
						//resort by PC of this axis, next axis up by value
						partitionEndIndex = this->moveRelevantToFront(partitionStartIndex, partitionEndIndex, d, PARENT_CHILD, this->factNRE);
						if (partitionEndIndex != -1) //if it's -1, means no trees satisfy this condition
						{
							outputRec[d].value = oldPartitionValue;
							outputRec[d].rel = PARENT_CHILD;
							outputRec[d].anc = -1;
							this->bottomUpCube(partitionStartIndex, partitionEndIndex, d+1, d);
						}
					}
					else if (g == 2) //SP-AD
					{		
						//resort by PC of this axis, next axis up by value
						partitionEndIndex = this->moveRelevantToFront(partitionStartIndex, partitionEndIndex, d, ANCS_DESC, this->subtreeParent[d]);
						if (partitionEndIndex != -1) //if it's -1, means no trees satisfy this condition
						{
							outputRec[d].value = oldPartitionValue;
							outputRec[d].rel = ANCS_DESC;
							outputRec[d].anc = this->subtreeParent[d];
							this->bottomUpCube(partitionStartIndex, partitionEndIndex, d+1, d);
						}
					}
					else if (g == 3) //SP-PC
					{
						partitionEndIndex = this->moveRelevantToFront(partitionStartIndex, partitionEndIndex, d, PARENT_CHILD, this->subtreeParent[d]);
						if (partitionEndIndex != -1) //if it's -1, means no trees satisfy this condition
						{

							outputRec[d].value = oldPartitionValue;
							outputRec[d].rel = PARENT_CHILD;
							outputRec[d].anc = this->subtreeParent[d];
							this->bottomUpCube(partitionStartIndex, partitionEndIndex, d+1, d);
						}
					}
				}

			}//for each relaxation g
		}
		finishtime = clock();
		cubeduration = (double)(finishtime - starttime) / CLOCKS_PER_SEC;
		cout << cubeduration << " seconds to compute Cube" << endl;
		outputRec[d].rel = -1; //clear
	}//for each dim

	clock_t allstarttime, allfinishtime; 
	double allComputeDuration;
	allstarttime = clock();

	//for ALL
	for (int i = 0 ; i < this->dimnum ; i++) {
		char* newDimNull = new char[4];
		strcpy(newDimNull,"ALL");
		outputRec[i].value = (char*)newDimNull;
	}
	// Aggregate(input) and write output
	this->AggregateAndWriteOutput(0, size-1);

	for (int i = 0 ; i < this->dimnum ; i++) {
		delete [] outputRec[i].value;
	}
	allfinishtime = clock();
	allComputeDuration = (double)(allfinishtime - allstarttime) / CLOCKS_PER_SEC;
	cout << allComputeDuration << " seconds to compute ALL" << endl;

}//end constructor


CubeBottomUpIterator::~CubeBottomUpIterator()
{
	fclose(output);

	cout << "++++Total Cube = " << numCube << endl;
	if (nre) delete [] nre;
	if (groupByAttrName)
	{
		for (int i=0; i< dimnum; i++)
			if (groupByAttrName[i])
				delete [] groupByAttrName[i];
		delete [] groupByAttrName;
	} 
	if (groupByWhat) delete [] groupByWhat;
	if (groupByRelaxType) {
		for (int i=0; i< dimnum; i++)
			delete [] groupByRelaxType[i];
		delete [] groupByRelaxType;
	}
	if (subtreeParent) delete [] subtreeParent;
	if (factByAttrName) delete [] factByAttrName;
	if (factOpOnWhatAttrName) delete [] factOpOnWhatAttrName;

	delete [] gSortByDim1;
	delete [] gWhereEmptyGoesDim1;
	delete [] gOrderDim1;

	if (outputRec)
	{
		delete [] outputRec;
	} 

	for (int i = 0 ; i < size ; i++){
		if (treeArray[i]) delete treeArray[i];
	}
	delete [] treeArray;

	if (!useExternalSort) {
		delete [] gNREDim1;
		if (gAttrNameDim1)
		{
			for (int i=0; i< dimnum; i++)
				if (gAttrNameDim1[i])
					delete [] gAttrNameDim1[i];
			delete [] gAttrNameDim1;
		} 
		delete [] gSortByDim1;
		delete [] gWhereEmptyGoesDim1;
		delete [] gOrderDim1;
	}
	if (fileName) delete [] fileName;
}

void CubeBottomUpIterator::next(WitnessTree *&node)
{	

	if (at < size)
		node = treeArray[at];
	else
		node = NULL;
	at++;
	return;
}

/**
start is the index (real index start from 0) of the partition
end is the index
current_dim is the index of dimension (real index start from 0)
**/
void CubeBottomUpIterator::bottomUpCube(int start, int end, int current_dim, int old_dim)
{
#ifdef EVAL_TIME_OUT
	clock_t currTime = clock();
	double queryDuration = (double)(currTime - gQueryStartTime) / CLOCKS_PER_SEC;
	if (queryDuration >= gTimeOutAfter)
	{
		globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"Evaluator",__FILE__,"Query Timed Out. Cube");
		node = NULL;
		return;		
	}
#endif
	//1-3. Aggregate(input) and write output
	this->AggregateAndWriteOutput(start, end);

	//4. for each dimension

	for (int d = current_dim ; d < this->dimnum ; d++){
		//sort input by dim
		gCurrentDim1 = d;

		//6. Partition, no optimization that will actually help if no overlap or no missing
		if ((d != old_dim+1) && (start != end))   //optimize, sort only if not already in place
		{
			EvalQuickSort s;
			//cout << endl << "--Sort on dimension--" << d << " up" << endl << endl;
			if (s.quickSort(treeArray,start,end,compareCubeNodesValSort1) == FAILURE) {
				size = 0;
				return;
			}
		}

		char* oldPartitionValue = NULL;
		char* thisPartitionValue = NULL;
		int partitionStartIndex = start; //real index
		int partitionEndIndex = end;
		int k = 0;
		for (k = start ; k <= end ; k++) { //go through each tuple

			//get the value of the current dimension value
			//if it start a new partition, stop and do the recursive function
			int success = this->getNodeValue(treeArray[k], this->nre[d], this->groupByAttrName[d], this->groupByWhat[d],thisPartitionValue);
			if (success == FAILURE) { //this maybe the missing dimension, so just ignore and cont
				//???? is this always true, what if the missing is not the last partition????
				//should not be, b/c we always sort, and let ALL as the last value
				thisPartitionValue = NULL;
			}

			if (((thisPartitionValue == NULL) && (oldPartitionValue != NULL)) || 
				((oldPartitionValue != NULL) && (strcmp(oldPartitionValue,thisPartitionValue) !=0)))
			{
				//process old partition
				//cout << oldPartitionValue << " from array " << partitionStartIndex << " to array " << k-1 << endl;	
				partitionEndIndex = k-1;
				for (int g = 0 ; g < 4 ; g++)
				{
					if (this->groupByRelaxType[d][g] == true) //if relaxable
					{
						if (g == 0) //LND-AD 
						{
							//if d's value != EMPTY, which is always the case
							outputRec[d].value = oldPartitionValue;
							outputRec[d].rel = ANCS_DESC;
							outputRec[d].anc = -1;
							this->bottomUpCube(partitionStartIndex, k-1, d+1, d);
						}
						else if (g == 1) //LND-PC, PC-AD
						{
							//resort by PC of this axis, next axis up by value
							partitionEndIndex = this->moveRelevantToFront(partitionStartIndex, partitionEndIndex, d, PARENT_CHILD, this->factNRE);
							if (partitionEndIndex != -1) //if it's -1, means no trees satisfy this condition
							{

								outputRec[d].value = oldPartitionValue;
								outputRec[d].rel = PARENT_CHILD;
								outputRec[d].anc = -1;
								this->bottomUpCube(partitionStartIndex, partitionEndIndex, d+1, d);
							}
						}
						else if (g == 2) //SP-AD
						{		
							//resort by PC of this axis, next axis up by value
							partitionEndIndex = this->moveRelevantToFront(partitionStartIndex, partitionEndIndex, d, ANCS_DESC, this->subtreeParent[d]);
							if (partitionEndIndex != -1) //if it's -1, means no trees satisfy this condition
							{

								outputRec[d].value = oldPartitionValue;
								outputRec[d].rel = ANCS_DESC;
								outputRec[d].anc = this->subtreeParent[d];
								this->bottomUpCube(partitionStartIndex, partitionEndIndex, d+1, d);
							}
						}
						else if (g == 3) //SP-PC
						{
							partitionEndIndex = this->moveRelevantToFront(partitionStartIndex, partitionEndIndex, d, PARENT_CHILD, this->subtreeParent[d]);
							if (partitionEndIndex != -1) //if it's -1, means no trees satisfy this condition
							{

								outputRec[d].value = oldPartitionValue;
								outputRec[d].rel = PARENT_CHILD;
								outputRec[d].anc = this->subtreeParent[d];
								this->bottomUpCube(partitionStartIndex, partitionEndIndex, d+1, d);
							}
						}
					}

				}//for each relaxation
				//start new partition
				partitionStartIndex = k;
			}
			if ((thisPartitionValue == NULL) && (oldPartitionValue != NULL))
				break;
			oldPartitionValue = thisPartitionValue;


		}
		//process last partition that is not missing
		if (thisPartitionValue != NULL) {
			//cout << oldPartitionValue << " from array " << partitionStartIndex << " to array " << k-1 << endl;	
			partitionEndIndex = k-1;
			for (int g = 0 ; g < 4 ; g++)
			{
				if (this->groupByRelaxType[d][g] == true) //if relaxable
				{
					if (g == 0) //LND-AD 
					{
						//if d's value != EMPTY, which is always the case
						outputRec[d].value = oldPartitionValue;
						outputRec[d].rel = ANCS_DESC;
						outputRec[d].anc = -1;
						this->bottomUpCube(partitionStartIndex, k-1, d+1, d);
					}
					else if (g == 1) //LND-PC, PC-AD
					{
						//resort by PC of this axis, next axis up by value
						partitionEndIndex = this->moveRelevantToFront(partitionStartIndex, partitionEndIndex, d, PARENT_CHILD, this->factNRE);
						if (partitionEndIndex != -1) //if it's -1, means no trees satisfy this condition
						{

							outputRec[d].value = oldPartitionValue;
							outputRec[d].rel = PARENT_CHILD;
							outputRec[d].anc = -1;
							this->bottomUpCube(partitionStartIndex, partitionEndIndex, d+1, d);
						}
					}
					else if (g == 2) //SP-AD
					{		
						//resort by PC of this axis, next axis up by value
						partitionEndIndex = this->moveRelevantToFront(partitionStartIndex, partitionEndIndex, d, ANCS_DESC, this->subtreeParent[d]);
						if (partitionEndIndex != -1) //if it's -1, means no trees satisfy this condition
						{

							outputRec[d].value = oldPartitionValue;
							outputRec[d].rel = ANCS_DESC;
							outputRec[d].anc = this->subtreeParent[d];
							this->bottomUpCube(partitionStartIndex, partitionEndIndex, d+1, d);
						}
					}
					else if (g == 3) //SP-PC
					{
						partitionEndIndex = this->moveRelevantToFront(partitionStartIndex, partitionEndIndex, d, PARENT_CHILD, this->subtreeParent[d]);
						if (partitionEndIndex != -1) //if it's -1, means no trees satisfy this condition
						{

							outputRec[d].value = oldPartitionValue;
							outputRec[d].rel = PARENT_CHILD;
							outputRec[d].anc = this->subtreeParent[d];
							this->bottomUpCube(partitionStartIndex, partitionEndIndex, d+1, d);
						}
					}
				}

			}//for each relaxation
		}

		outputRec[d].rel = -1;
	}//for each dim

}


/* Aggregate and write out the cuboids*/
/* Also doing BUC original optimization*/
/* This conquer line 1 - 3 in the BUC paper*/
void CubeBottomUpIterator::AggregateAndWriteOutput(int start, int end)
{
	double aggrValue;
	double aggregatedValue1 = 0;
	int aggregatedValue2 = 0; //for OP_AVG, store COUNT
	bool first = true; //if the first iteration, to set value for OP_MIN,OP_MAX

	//1. Aggregate(Input)
	//check whether optimization possible
	if (this->no_overlap == false) {

		//duplicate elimination
		//use STL map
		map<char*, WitnessTree*, ltstr> Map_Fact_Tree;

		char* factValue = NULL;
		for (int i = start ; i <= end ; i++) {
			//insert all input into the map to eliminate the duplicates
			int ret = this->getNodeValue(treeArray[i],this->factNRE,this->factByAttrName,this->factByWhat,factValue);
			if (ret == FAILURE) { //fact id is missing? yes, for dblp
				factValue = new char[5];
				strcpy(factValue,"NULL");				
			}
			pair<char*,WitnessTree*> p1(factValue,treeArray[i]);
			Map_Fact_Tree.insert(p1);
		}

		map<char*, WitnessTree*, ltstr>::const_iterator cur;
		if (this->factByOperation != OP_COUNT) {
			cur = Map_Fact_Tree.begin();
			while (cur != Map_Fact_Tree.end()){
				//go through the map and perform aggregation
				switch (this->factByOperation)
				{
				case OP_SUM:
					{
						int ret = this->getNodeValue((*cur).second,this->factOpNRE,this->factOpOnWhat,this->factOpOnWhatAttrName,&aggrValue);
						if (ret == FAILURE) return;
						aggregatedValue1 = aggregatedValue1 + aggrValue;
					}
					break;
				case OP_AVG:
					{
						int ret = this->getNodeValue((*cur).second,this->factOpNRE,this->factOpOnWhat,this->factOpOnWhatAttrName,&aggrValue);
						if (ret == FAILURE) return;
						aggregatedValue1 = aggregatedValue1 + aggrValue;
						aggregatedValue2++;
					}
					break;
				case OP_MIN:
					{
						int ret = this->getNodeValue((*cur).second,this->factOpNRE,this->factOpOnWhat,this->factOpOnWhatAttrName,&aggrValue);
						if (ret == FAILURE) return;
						if (first) aggregatedValue1 = aggrValue;
						else {
							if (aggregatedValue1 > aggrValue)
								aggregatedValue1 = aggrValue;
						}
					}
					break;
				case OP_MAX:
					{
						int ret = this->getNodeValue((*cur).second,this->factOpNRE,this->factOpOnWhat,this->factOpOnWhatAttrName,&aggrValue);
						if (ret == FAILURE) return;
						if (first) aggregatedValue1 = aggrValue;
						else {
							if (aggregatedValue1 < aggrValue)
								aggregatedValue1 = aggrValue;
						}
					}
					break;
				default:
					globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"Evaluator",__FILE__,"Undefined aggregate operation passed to cube iterator.");
					return;
				}
				++cur;
				first = false;
			}
		}
		else aggregatedValue1 = Map_Fact_Tree.size();// for count, we don't even have to iterate

		//clear map's fact char, if the fact is SK
		if (this->factByWhat == GROUPBY_STARTKEY){
			cur = Map_Fact_Tree.begin();
			while (cur != Map_Fact_Tree.end()){
				delete [] (*cur).first;
				++cur;
			}
		}
	}
	else { //optimization, no overlap
		//just go through the array of trees
		if (this->factByOperation != OP_COUNT) {
			for (int i = start ; i <= end ; i++) {
				switch (this->factByOperation)
				{
				case OP_SUM:
					{
						int ret = this->getNodeValue(treeArray[i],this->factOpNRE,this->factOpOnWhat,this->factOpOnWhatAttrName,&aggrValue);
						if (ret == FAILURE) return;
						aggregatedValue1 = aggregatedValue1 + aggrValue;
					}
					break;
				case OP_AVG:
					{
						int ret = this->getNodeValue(treeArray[i],this->factOpNRE,this->factOpOnWhat,this->factOpOnWhatAttrName,&aggrValue);
						if (ret == FAILURE) return;
						aggregatedValue1 = aggregatedValue1 + aggrValue;
						aggregatedValue2++;
					}
					break;
				case OP_MIN:
					{
						int ret = this->getNodeValue(treeArray[i],this->factOpNRE,this->factOpOnWhat,this->factOpOnWhatAttrName,&aggrValue);
						if (ret == FAILURE) return;
						if (first) aggregatedValue1 = aggrValue;
						else {
							if (aggregatedValue1 > aggrValue)
								aggregatedValue1 = aggrValue;
						}
					}
					break;
				case OP_MAX:
					{
						int ret = this->getNodeValue(treeArray[i],this->factOpNRE,this->factOpOnWhat,this->factOpOnWhatAttrName,&aggrValue);
						if (ret == FAILURE) return;
						if (first) aggregatedValue1 = aggrValue;
						else {
							if (aggregatedValue1 < aggrValue)
								aggregatedValue1 = aggrValue;
						}
					}
					break;
				default:
					globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"Evaluator",__FILE__,"Undefined aggregate operation passed to cube iterator.");
					return;
				}
				first = false;
			} //for loop
		}
		else aggregatedValue1 = end - start + 1; // for count, we don't even have to iterate
	} //else optimization

	//2. original BUC optimization for input.count == 1, writeAncestors
	//not need to, because we will take care of later in the algo 
	//that we will not sort, and will recursively been taken care of
	//or is it better to code here???

	//3. write output

	numCube++;
	for (int i =0 ; i < this->dimnum ;i++){
		if (outputRec[i].rel != -1) //if it's not cleared (leaf deleted)
			fprintf(output,"%s %d %d\t",outputRec[i].value,outputRec[i].rel,outputRec[i].anc);
		else 
			fprintf(output,"ALL\t");
	}
	if (this->factByOperation == OP_AVG) {
		fprintf(output,"%lf/%d\n",aggregatedValue1,aggregatedValue2);
	}
	else {
		fprintf(output,"%lf\n",aggregatedValue1);
	}
}
int CubeBottomUpIterator::getNodeValue(WitnessTree* elem1, NREType nre, char* attrName, int nodeGroupByType, char*& charValue)
{
	int index1 = ((WitnessTree *)elem1)->getIndexOfNRE(nre);
	if (index1 == FAILURE)
		return FAILURE;

	FileIDType fileid1 = EvaluatorClass::getFileID(((ComplexListNode *)((WitnessTree *)elem1)->getNodeByIndex(index1))->getFileIndex());
	if (fileid1 == -1)
		return -1;

	switch (nodeGroupByType)
	{
	case GROUPBY_TEXT_NUM:
	case GROUPBY_TEXT_STR:
		{
			int res1 = EvaluatorClass::GetText((WitnessTree *)elem1,index1,this->dataMng,fileid1);
			if (res1 == FAILURE) return FAILURE;
			charValue = ((DM_CharNode *)((ComplexListNode *)((WitnessTree *)elem1)->getNodeByIndex(res1))->GetData())->getCharValue();


		}
		break;
	case GROUPBY_ATTRIBUTE_NUM:
	case GROUPBY_ATTRIBUTE_STR:
		{
			int res1 = EvaluatorClass::GetAttributes((WitnessTree *)elem1,index1,this->dataMng,fileid1);
			if (res1 == FAILURE) return FAILURE;

			Value *val1 = ((DM_AttributeNode *)((ComplexListNode *)((WitnessTree *)elem1)->getNodeByIndex(index1+1))->GetData())->getAttr(attrName);
			if (!val1) return FAILURE;

			charValue = val1->getStrValue();

		}
		break;
	case GROUPBY_VALUE_NUM:
	case GROUPBY_VALUE_STR:
		{
			DM_DataNode *dn1 = ((ComplexListNode *)((WitnessTree *)elem1)->getNodeByIndex(index1))->GetData();
			if (dn1 == NULL)
				return FAILURE;

			if (dn1->getFlag() == ELEMENT_NODE)
				charValue = this->dataMng->getPhysicalDataMng()->getXMLNameTable()->getNameByCode(((DM_ElementNode *)dn1)->getTag());

			else if (dn1->getFlag() == DOCUMENT_NODE)
			{
				if (((DM_DocumentNode *)dn1)->getXMLFileName())
					charValue = ((DM_DocumentNode *)dn1)->getXMLFileName();
				else {
					charValue = NULL;
					return FAILURE;
				}
			}
			else if (dn1->getFlag() == ATTRIBUTE_NODE)
			{
				//if attribute node, return the value of attribute "attrName"

				Value* val1 = ((DM_AttributeNode *)dn1)->getAttr(attrName);
				if (!val1) return FAILURE;

				charValue = val1->getStrValue();

			} 
			else
			{
				//if text node, return the text value
				charValue = ((DM_CharNode *)dn1)->getCharValue();
			}

		}
		break;
	case GROUPBY_STARTKEY:
		{
			charValue = ((ComplexListNode *)((WitnessTree *)elem1)->getNodeByIndex(index1))->GetStartPos().toString();
		}
		break;
	}//switch
	return SUCCESS;

}

int CubeBottomUpIterator::getNodeValue(WitnessTree* elem1, NREType factOpNRE, int factOpOnWhat, char* factOpAttrName, double* retValue)
{
	int index1 = ((WitnessTree *)elem1)->getIndexOfNRE(factOpNRE);
	if (index1 == FAILURE)
		return FAILURE;

	FileIDType fileid1 = EvaluatorClass::getFileID(((ComplexListNode *)((WitnessTree *)elem1)->getNodeByIndex(index1))->getFileIndex());
	if (fileid1 == -1)
		return FAILURE;

	switch (factOpOnWhat)
	{
	case ON_ATTRIBUTE_NUM:
		{
			int res1 = EvaluatorClass::GetAttributes((WitnessTree *)elem1,index1,this->dataMng,fileid1);
			if (res1 == FAILURE) return FAILURE;

			Value *val1 = ((DM_AttributeNode *)((ComplexListNode *)((WitnessTree *)elem1)->getNodeByIndex(index1+1))->GetData())->getAttr(factOpAttrName);
			if (!val1) return FAILURE;

			*retValue = val1->getRealValue();
		}
		break;
	case ON_TEXT_NUM:
		{
			int res1 = EvaluatorClass::GetText((WitnessTree *)elem1,index1,this->dataMng,fileid1);
			if (res1 == FAILURE) return FAILURE;
			*retValue = atof(((DM_CharNode *)((ComplexListNode *)((WitnessTree *)elem1)->getNodeByIndex(res1))->GetData())->getCharValue());
		}
		break;
	case ON_VALUE_NUM:
		{
			DM_DataNode *dn1 = ((ComplexListNode *)((WitnessTree *)elem1)->getNodeByIndex(index1))->GetData();
			if (dn1 == NULL)
				return FAILURE;

			if (dn1->getFlag() == ELEMENT_NODE)
				*retValue = (double)(((DM_ElementNode *)dn1)->getTag());

			else if (dn1->getFlag() == ATTRIBUTE_NODE)
			{
				//if attribute node, return the value of attribute "attrName"

				Value* val1 = ((DM_AttributeNode *)dn1)->getAttr(factOpAttrName);
				if (!val1) return FAILURE;

				*retValue = val1->getRealValue();

			} 
			else
			{
				//if text node, return the text value
				*retValue = atof(((DM_CharNode *)dn1)->getCharValue());
			}
		}
		break;
	}
	return SUCCESS;
}

//return the index of the last one that is relevant
int CubeBottomUpIterator::moveRelevantToFront(int start, int end, int dim, int relationship, NREType ancNRE)
{
	int first = -1; // is the first non-Inplace for the current order
	int lastRelevant = -1;
	WitnessTree* temp;

	for (int i= start ; i<= end ; i++)
	{
		int index1 = ((WitnessTree *)treeArray[i])->getIndexOfNRE(this->nre[dim]);
		int indexp1 = ((WitnessTree *)treeArray[i])->getIndexOfNRE(ancNRE);
		int levp1 = ((ComplexListNode *)((WitnessTree *)treeArray[i])->getNodeByIndex(indexp1))->GetLevel();
		int lev1 = ((ComplexListNode *)((WitnessTree *)treeArray[i])->getNodeByIndex(index1))->GetLevel();
		KeyType sp1 = ((ComplexListNode *)((WitnessTree *)treeArray[i])->getNodeByIndex(indexp1))->GetStartPos();
		KeyType ep1 = ((ComplexListNode *)((WitnessTree *)treeArray[i])->getNodeByIndex(indexp1))->GetEndPos();
		KeyType s1 = ((ComplexListNode *)((WitnessTree *)treeArray[i])->getNodeByIndex(index1))->GetStartPos();
		KeyType e1 = ((ComplexListNode *)((WitnessTree *)treeArray[i])->getNodeByIndex(index1))->GetEndPos();
		if (relationship == PARENT_CHILD){

			if (lev1 == levp1+1 && sp1 < s1 && ep1 > e1 && (first == -1 || first > i)) 
				lastRelevant = i;
			else if ((lev1 != levp1+1 || sp1 >= s1 || ep1 <= e1) && first == -1)
				first = i;
			else if (lev1 == levp1+1 && sp1 < s1 && ep1 > e1 && first != -1  && first < i){
				//swap
				temp = treeArray[i]; 
				treeArray[i] = treeArray[first];
				treeArray[first] = temp;
				i= first;
				lastRelevant = first;
				first = -1;
			}
		}
		else if (relationship == ANCS_DESC){

			if (sp1 < s1 && ep1 > e1 && (first == -1 || first > i)) 
				lastRelevant = i;
			else if ((sp1 >= s1 || ep1 <= e1) && first == -1)
				first = i;
			else if (sp1 < s1 && ep1 > e1 && first != -1  && first < i){
				//swap
				temp = treeArray[i]; 
				treeArray[i] = treeArray[first];
				treeArray[first] = temp;
				i= first;
				lastRelevant = first;
				first = -1;
			}
		}
	}
	return lastRelevant;
}
