#include "../../Evaluator/EvaluatorClass.h"

#include "QueryEvaluationTreeProjectionNode.h"

#include "ProjectionIterator.h"
#include "extra.h"

void QueryEvaluationTreeProjectionNode::processQueryEvalNode(EvaluatorClass* evaluator, IteratorClass*& curr)
	    {
		IteratorClass *opr = evaluator->processQueryEvalNode(getOperand());
		if (opr == NULL)
		{
		    globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"Evaluator",__FILE__, "operand returned is NULL. projection process eval node..." );
		    curr=NULL; return;
		}
		curr = new ProjectionIterator(opr, getNum(),getNRE(), getPreserveNodeOrder(),evaluator->getDataManager());
		setNRE(NULL);
	    }

