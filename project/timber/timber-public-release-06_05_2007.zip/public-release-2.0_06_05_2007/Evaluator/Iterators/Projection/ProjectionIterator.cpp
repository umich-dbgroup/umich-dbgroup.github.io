/*
COPYRIGHT  � 2000-2004 
THE REGENTS OF THE UNIVERSITY OF MICHIGAN
ALL RIGHTS RESERVED

PERMISSION IS GRANTED TO USE, COPY, CREATE DERIVATIVE WORKS AND REDISTRIBUTE THIS SOFTWARE AND SUCH DERIVATIVE WORKS FOR 
NONCOMMERCIAL EDUCATION AND RESEARCH PURPOSES, SO LONG AS NO FEE IS CHARGED, AND SO LONG AS THE COPYRIGHT NOTICE ABOVE, 
THIS GRANT OF PERMISSION, AND THE DISCLAIMER BELOW APPEAR IN ALL COPIES MADE; AND SO LONG AS THE NAME OF THE UNIVERSITY 
OF MICHIGAN IS NOT USED IN ANY ADVERTISING OR PUBLICITY PERTAINING TO THE USE OR DISTRIBUTION OF THIS SOFTWARE WITHOUT 
SPECIFIC, WRITTEN PRIOR AUTHORIZATION.

THIS SOFTWARE IS PROVIDED AS IS, WITHOUT REPRESENTATION FROM THE UNIVERSITY OF MICHIGAN AS TO ITS FITNESS FOR ANY PURPOSE, 
AND WITHOUT WARRANTY BY THE UNIVERSITY OF MICHIGAN OF ANY KIND, EITHER EXPRESS OR IMPLIED, INCLUDING WITHOUT LIMITATION THE 
IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE. THE REGENTS OF THE UNIVERSITY OF MICHIGAN SHALL 
NOT BE LIABLE FOR ANY DAMAGES, INCLUDING SPECIAL, INDIRECT, INCIDENTAL, OR CONSEQUENTIAL DAMAGES, WITH RESPECT TO ANY CLAIM 
ARISING OUT OF OR IN CONNECTION WITH THE USE OF THE SOFTWARE, EVEN IF IT HAS BEEN OR IS HEREAFTER ADVISED OF THE POSSIBILITY 
OF SUCH DAMAGES.
*/

#include "ProjectionIterator.h"



ProjectionIterator::ProjectionIterator(IteratorClass *input, int num, NREType *nre, bool preserveNodeOrder, DataMng *dataMng)
{
	this->input = input;
	this->nre = nre;
	this->num = num;
	this->preserveNodeOrder = preserveNodeOrder;
	this->dataMng = dataMng;

	input->next(inTuple);
	if (inTuple)
	{
		if (inTuple->isSimple())
			resultBuffer = new WitnessTree;
		else
			resultBuffer = new WitnessTree(LIST_NODE_WITH_DATA,dataMng);
	}
	else
		resultBuffer = NULL;
}

ProjectionIterator::~ProjectionIterator()
{
	if (resultBuffer) delete resultBuffer;
	if (nre)
		delete [] nre;
	delete input;
}


void ProjectionIterator::next(WitnessTree *&node)
{
	while (inTuple)
	{
		resultBuffer->initialize();
		if (preserveNodeOrder)
			this->projectInNodeOrder();
		else
			this->projectInNREOrder();
		resultBuffer->setScore(inTuple->getScore());
		input->next(inTuple);
		node = resultBuffer;
		return;
	}
	node = NULL;
	return;
}

void ProjectionIterator::projectInNodeOrder()
{
	if (inTuple->isSimple())
	{
		for (int i=0; i<inTuple->length(); i++)
		{
			ListNode *n = (ListNode *)inTuple->getNodeByIndex(i);
			if (keepThisNRE(n->getNRE()))
				resultBuffer->appendList(n,1);
		}
	}
	else
	{
		for (int i=0; i<inTuple->length(); i++)
		{
			ComplexListNode *n = (ComplexListNode *)inTuple->getNodeByIndex(i);
			if (keepThisNRE(n->getNRE()))
				resultBuffer->appendList(n,dataMng,1);
		}
	}

}

bool ProjectionIterator::keepThisNRE(NREType oneNRE)
{
	for (int i=0; i<num; i++)
		if (nre[i] == oneNRE)
			return true;
	return false;
}

void ProjectionIterator::projectInNREOrder()
{
	for (int i=0; i<num; i++)
		this->copyToResultOneNRE(nre[i]);
}

void ProjectionIterator::copyToResultOneNRE(NREType oneNRE)
{
	inTuple->startFindNodesNRE(oneNRE);

	if (inTuple->isSimple())
	{
		ListNode *n = (ListNode *)inTuple->getNextNodeNRE();
		while (n)
		{
			resultBuffer->appendList(n,1);
			n = (ListNode *)inTuple->getNextNodeNRE();
		}
	}
	else
	{
		ComplexListNode *n = (ComplexListNode *)inTuple->getNextNodeNRE();
		while (n)
		{
			resultBuffer->appendList(n,dataMng,1);
			n = (ComplexListNode *)inTuple->getNextNodeNRE();
		}
	}
}



