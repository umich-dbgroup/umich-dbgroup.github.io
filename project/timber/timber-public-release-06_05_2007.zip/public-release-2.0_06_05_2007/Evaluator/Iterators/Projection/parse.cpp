
#include "parse.hpp"

char QueryEvaluationTreeProjectionNode::getIdentifier(void) { return 'P'; }

char ProjectionPlanParser::getIteratorIdentifier(void) { return 'P'; }

void 
ProjectionPlanParser::getQueryEvalNode(EvaluatorClass* evaluator, char* line, void* queryInput, QueryEvaluationTreeNode*& curr)
	    {
		char *token = strtok(line+2,",");                    
		if (token == NULL)
		{
		    globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"Evaluator",__FILE__,"Error input from file... expecting list length... projection line...");
		    curr=NULL; return;
		}
		int num = atoi(token);    

		NREType *nre;
		if (num <= 0)
		{
		    nre = NULL;
		    globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"Evaluator",__FILE__,"Error input from file... list length should be positive... projection line...");
		    curr=NULL; return;
		}
		else
		    nre = new NREType[num];

		for (int i=0; i<num; i++)
		{
		    token = strtok(NULL,",");
		    if (token == NULL)
		    {
			globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"Evaluator",__FILE__,"Error input from file... expecting an nre... projection line...");
			delete [] nre;
			curr=NULL; return;
		    }
		    nre[i] = atoi(token);
		    if (nre[i] < 1)
		    {
			globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"Evaluator",__FILE__,"NRE should be positive.");
			curr=NULL; return;
		    }
		    if (nre[i] > evaluator->maxNRE)
			evaluator->maxNRE = nre[i];

		}
		token = strtok(NULL,",");
		if (token == NULL)
		{
		    globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"Evaluator",__FILE__,"Error input from file... expecting preserve node order bool... projection line...");
		    delete nre;
		    curr=NULL; return;
		}
		if (atoi(token) != 0 && atoi(token) != 1)
		{
		    globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"Evaluator",__FILE__,"Error input from file... preserve node order should be 0 or 1... projection line...");
		    delete nre;
		    curr=NULL; return;
		}
		bool preserveNodeOrder = (bool) atoi(token);

		char newLine[MAX_FILE_INTERFACE_LINE_SIZE];
		if (((std::iostream *)queryInput)->eof() == 0)
		    ((std::iostream *)queryInput)->getline(newLine,MAX_FILE_INTERFACE_LINE_SIZE);
		else
		{
		    globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"Evaluator",__FILE__,"Unexpected end of file... projection line...");
		    delete nre;
		    curr=NULL; return;
		}
		QueryEvaluationTreeNode *oper = evaluator->getQueryEvalNode(newLine,queryInput);
		if (oper == NULL)
		{
		    globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"Evaluator",__FILE__,"Unexpected operand returned... projection line...");
		    delete nre;
		    curr=NULL; return;
		}
		curr = new QueryEvaluationTreeProjectionNode(oper, num, nre, preserveNodeOrder);
	    }

