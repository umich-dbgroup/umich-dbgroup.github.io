/*
COPYRIGHT  � 2000-2004 
THE REGENTS OF THE UNIVERSITY OF MICHIGAN
ALL RIGHTS RESERVED

PERMISSION IS GRANTED TO USE, COPY, CREATE DERIVATIVE WORKS AND REDISTRIBUTE THIS SOFTWARE AND SUCH DERIVATIVE WORKS FOR 
NONCOMMERCIAL EDUCATION AND RESEARCH PURPOSES, SO LONG AS NO FEE IS CHARGED, AND SO LONG AS THE COPYRIGHT NOTICE ABOVE, 
THIS GRANT OF PERMISSION, AND THE DISCLAIMER BELOW APPEAR IN ALL COPIES MADE; AND SO LONG AS THE NAME OF THE UNIVERSITY 
OF MICHIGAN IS NOT USED IN ANY ADVERTISING OR PUBLICITY PERTAINING TO THE USE OR DISTRIBUTION OF THIS SOFTWARE WITHOUT 
SPECIFIC, WRITTEN PRIOR AUTHORIZATION.

THIS SOFTWARE IS PROVIDED AS IS, WITHOUT REPRESENTATION FROM THE UNIVERSITY OF MICHIGAN AS TO ITS FITNESS FOR ANY PURPOSE, 
AND WITHOUT WARRANTY BY THE UNIVERSITY OF MICHIGAN OF ANY KIND, EITHER EXPRESS OR IMPLIED, INCLUDING WITHOUT LIMITATION THE 
IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE. THE REGENTS OF THE UNIVERSITY OF MICHIGAN SHALL 
NOT BE LIABLE FOR ANY DAMAGES, INCLUDING SPECIAL, INDIRECT, INCIDENTAL, OR CONSEQUENTIAL DAMAGES, WITH RESPECT TO ANY CLAIM 
ARISING OUT OF OR IN CONNECTION WITH THE USE OF THE SOFTWARE, EVEN IF IT HAS BEEN OR IS HEREAFTER ADVISED OF THE POSSIBILITY 
OF SUCH DAMAGES.
*/

#include "IntersectionIterator.h"


IntersectionIterator::IntersectionIterator(IteratorClass *left, IteratorClass *right, DataMng *dataMng, int length)
{
	this->left = left;
	this->right = right;
	this->length = length;

	this->dataMng = dataMng;
	left->next(leftTuple);
	right->next(rightTuple);
	if ((leftTuple && !(leftTuple->isSimple())) || (rightTuple && !(rightTuple->isSimple())))
		resultBuffer = new WitnessTree(LIST_NODE_WITH_DATA,dataMng);
	else
		resultBuffer = new WitnessTree;
}


IntersectionIterator::~IntersectionIterator()
{
	delete resultBuffer;
	
	delete left;
	delete right;
}


void IntersectionIterator::next(WitnessTree *&node)
{
	//as long as we have inputs on both sides
#ifdef EVAL_TIME_OUT
	clock_t currTime = clock();
	double queryDuration = (double)(currTime - gQueryStartTime) / CLOCKS_PER_SEC;
	if (queryDuration >= gTimeOutAfter)
	{
		globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"Evaluator",__FILE__,"Query Timed Out.");
		node = NULL;
		return;
	}
#endif
	while (leftTuple && rightTuple)
	{

		if (leftTuple->equalTree(rightTuple,index,length))
		{
			resultBuffer->copyTree(leftTuple);
			left->next(leftTuple);
			right->next(rightTuple);
			node = resultBuffer;
			return;
		}

		//if we reach this point, the two inputs are different
		//index is where the 2 trees become different
		// we need to get a new input from the one that has the smaller start key
		KeyType leftStartKey = leftTuple->isSimple()? ((ListNode *)leftTuple->findNode(index))->GetStartPos()
			:((ComplexListNode *)leftTuple->findNode(index))->GetStartPos();
		KeyType rightStartKey = rightTuple->isSimple()? ((ListNode *)rightTuple->findNode(index))->GetStartPos()
			:((ComplexListNode *)rightTuple->findNode(index))->GetStartPos();

		if (leftStartKey < rightStartKey)
			left->next(leftTuple);
		else
			right->next(rightTuple);
#ifdef EVAL_TIME_OUT
	clock_t currTime = clock();
	double queryDuration = (double)(currTime - gQueryStartTime) / CLOCKS_PER_SEC;
	if (queryDuration >= gTimeOutAfter)
	{
		globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"Evaluator",__FILE__,"Query Timed Out.");
		node = NULL;
		return;
	}
#endif
	}
	node = NULL;
}

