/*
COPYRIGHT  � 2000-2004 
THE REGENTS OF THE UNIVERSITY OF MICHIGAN
ALL RIGHTS RESERVED

PERMISSION IS GRANTED TO USE, COPY, CREATE DERIVATIVE WORKS AND REDISTRIBUTE THIS SOFTWARE AND SUCH DERIVATIVE WORKS FOR 
NONCOMMERCIAL EDUCATION AND RESEARCH PURPOSES, SO LONG AS NO FEE IS CHARGED, AND SO LONG AS THE COPYRIGHT NOTICE ABOVE, 
THIS GRANT OF PERMISSION, AND THE DISCLAIMER BELOW APPEAR IN ALL COPIES MADE; AND SO LONG AS THE NAME OF THE UNIVERSITY 
OF MICHIGAN IS NOT USED IN ANY ADVERTISING OR PUBLICITY PERTAINING TO THE USE OR DISTRIBUTION OF THIS SOFTWARE WITHOUT 
SPECIFIC, WRITTEN PRIOR AUTHORIZATION.

THIS SOFTWARE IS PROVIDED AS IS, WITHOUT REPRESENTATION FROM THE UNIVERSITY OF MICHIGAN AS TO ITS FITNESS FOR ANY PURPOSE, 
AND WITHOUT WARRANTY BY THE UNIVERSITY OF MICHIGAN OF ANY KIND, EITHER EXPRESS OR IMPLIED, INCLUDING WITHOUT LIMITATION THE 
IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE. THE REGENTS OF THE UNIVERSITY OF MICHIGAN SHALL 
NOT BE LIABLE FOR ANY DAMAGES, INCLUDING SPECIAL, INDIRECT, INCIDENTAL, OR CONSEQUENTIAL DAMAGES, WITH RESPECT TO ANY CLAIM 
ARISING OUT OF OR IN CONNECTION WITH THE USE OF THE SOFTWARE, EVEN IF IT HAS BEEN OR IS HEREAFTER ADVISED OF THE POSSIBILITY 
OF SUCH DAMAGES.
*/

#include "UnionIterator.h"

UnionIterator::UnionIterator(IteratorClass *left, IteratorClass *right, DataMng *dataMng, int length)
{
	this->left = left;
	this->right = right;

	this->dataMng = dataMng;
	left->next(leftTuple);
	right->next(rightTuple);

	this->length = length;
	if (leftTuple)
	{
		if (rightTuple)
		{
			if (leftTuple->isSimple() && rightTuple->isSimple())
				resultBuffer = new WitnessTree;
			else
				resultBuffer = new WitnessTree(LIST_NODE_WITH_DATA,dataMng);
			if (leftTuple->isSimple() && !rightTuple->isSimple())
				leftTuple->switchToComplex(dataMng);
			else if (!leftTuple->isSimple() && rightTuple->isSimple())
				rightTuple->switchToComplex(dataMng);
		}
		else if (globalErrorInfo.doWeHaveAProblem())
		{
			resultBuffer = NULL;
			leftTuple = rightTuple = NULL;
		}
		else
		{
			if (leftTuple->isSimple())
				resultBuffer = new WitnessTree;
			else
				resultBuffer = new WitnessTree(LIST_NODE_WITH_DATA,dataMng);
		}
	}
	else if (globalErrorInfo.doWeHaveAProblem())
	{
		resultBuffer = NULL;
		leftTuple = rightTuple = NULL;
	}
	else if (rightTuple)
	{
		if (rightTuple->isSimple())
			resultBuffer = new WitnessTree;
		else
			resultBuffer = new WitnessTree(LIST_NODE_WITH_DATA,dataMng);
	}
	else 
		resultBuffer = NULL;
}


UnionIterator::~UnionIterator()
{
	if (resultBuffer) delete resultBuffer;
	
	delete left;
	delete right;
}


void UnionIterator::next(WitnessTree *&node)
{
#ifdef EVAL_TIME_OUT
	clock_t currTime = clock();
	double queryDuration = (double)(currTime - gQueryStartTime) / CLOCKS_PER_SEC;
	if (queryDuration >= gTimeOutAfter)
	{
		globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"Evaluator",__FILE__,"Query Timed Out.");
		node = NULL;
		return;
	}
#endif
	//as long as we have both inputs
	while (leftTuple && rightTuple)
	{
		if (leftTuple->equalTree(rightTuple,index,length))
		{
			//if they are equal, then pass left tree and get new inputs.
			resultBuffer->copyTree(leftTuple);
			left->next(leftTuple);
			right->next(rightTuple);
			node = resultBuffer;
			return;
		}
		// if they are not equal, we need to decide which to pass based on start key


		//get start keys
		KeyType leftSK,rightSK;
		if (leftTuple->isSimple())
		{
			leftSK = ((ListNode *)leftTuple->findNode(index))->GetStartPos();
			rightSK = ((ListNode *)rightTuple->findNode(index))->GetStartPos();
		}
		else
		{
			leftSK = ((ComplexListNode *)leftTuple->findNode(index))->GetStartPos();
			rightSK = ((ComplexListNode *)rightTuple->findNode(index))->GetStartPos();
		}
		if (leftSK < rightSK)
		{
			//if left input comes first, then output it and get a new left input
			resultBuffer->copyTree(leftTuple);
			left->next(leftTuple);
			node = resultBuffer;
			return;
		}
		else
		{
			//if right input comes first, then output it and get a new right input.
			resultBuffer->copyTree(rightTuple);
			right->next(rightTuple);
			node = resultBuffer;
			return;
		}
		
	}

	// if we still have left input, output it
	while (leftTuple)
	{
		resultBuffer->copyTree(leftTuple);
		left->next(leftTuple);
		node = resultBuffer;
		return;
	}

	//if we still have right input, output it
	while (rightTuple)
	{
		resultBuffer->copyTree(rightTuple);
		right->next(rightTuple);
		node = resultBuffer;
		return;
	}

	node = NULL;
}
