
#include "parse.hpp"

char QueryEvaluationTreeOneSidedValueJoinNode::getIdentifier(void) { return 'O'; }

char OneSidedValueJoinPlanParser::getIteratorIdentifier(void) { return 'O'; }

void 
OneSidedValueJoinPlanParser::getQueryEvalNode(EvaluatorClass* evaluator, char* line, void* queryInput, QueryEvaluationTreeNode*& curr)
	    {
		char *token = strtok(line+2,",");
		char *indexName;
		if (token == NULL)
		{
		    globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"Evaluator",__FILE__,"Error input from file... expecting join index name... one sided join line...");
		    curr=NULL; return;
		}
		indexName = new char[strlen(token)+1];
		strcpy(indexName,token);

		token = strtok(NULL,",");
		char *fileName;
		if (token == NULL)
		{
		    globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"Evaluator",__FILE__,"Error input from file... expecting file name... one sided join line...");
		    delete [] indexName;
		    curr=NULL; return;
		}
		fileName = new char[strlen(token)+1];
		strcpy(fileName,token);

		token = strtok(NULL,",");
		if (token == NULL)
		{
		    globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"Evaluator",__FILE__,"Error input from file... expecting left nre... join line...");
		    delete [] indexName;
		    delete [] fileName;
		    curr=NULL; return;
		}
		NREType  leftNRE;
		if (atoi(token) < 1)
		{
		    globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"Evaluator",__FILE__,"left NRE should be positive.");
		    delete [] indexName;
		    delete [] fileName;
		    curr=NULL; return;
		}
		else
		{
		    leftNRE = (NREType)atoi(token);
		    if (leftNRE > evaluator->maxNRE)
			evaluator->maxNRE = leftNRE;
		}

		token = strtok(NULL,",");
		if (token == NULL)
		{
		    globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"Evaluator",__FILE__,"Error input from file... expecting right nre... join line...");
		    delete [] indexName;
		    delete [] fileName;
		    curr=NULL; return;
		}
		NREType  rightNRE;
		if (atoi(token) < 1)
		{
		    globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"Evaluator",__FILE__,"right NRE should be positive.");
		    delete [] indexName;
		    delete [] fileName;
		    curr=NULL; return;
		}
		else
		{
		    rightNRE = (NREType)atoi(token);
		    if (rightNRE > evaluator->maxNRE)
			evaluator->maxNRE = rightNRE;
		}

		token = strtok(NULL,",");
		if (token == NULL)
		{
		    globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"Evaluator",__FILE__,"Error input from file... expecting root NRE... one sided join line...");
		    delete [] indexName;
		    delete [] fileName;
		    curr=NULL; return;
		}
		NREType rootNRE = (NREType)atoi(token);
		if (rootNRE < 1)
		{
		    globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"Evaluator",__FILE__,"NRE should be positive.");
		    delete [] indexName;
		    delete [] fileName;
		    curr=NULL; return;
		}
		if (rootNRE > evaluator->maxNRE)
		    evaluator->maxNRE = rootNRE;

		bool nest = false;
		bool outer = false;

		token = strtok(NULL,",");
		if (token != NULL)
		{
		    if (strcmp(token,"N") == 0)
		    {
			nest = true;
			token = strtok(NULL,",");
			if (token != NULL)
			{
			    if (strcmp(token,"O") == 0)
				outer = true;
			    else
			    {
				globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"Evaluator",__FILE__,"Error input from file... unrecognized optional parameter... one sided join line...");

				if (indexName) delete [] indexName;
				if (fileName) delete [] fileName;
				curr=NULL; return;	
			    }
			}
		    }
		    else
		    {
			if (strcmp(token,"O") == 0)
			    outer = true;
			else
			{
			    globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"Evaluator",__FILE__,"Error input from file... unrecognized optional parameter... one sided join line...");

			    if (indexName) delete [] indexName;
			    if (fileName) delete [] fileName;
			    curr=NULL; return;	
			}
		    }
		}


		char newLine[MAX_FILE_INTERFACE_LINE_SIZE];
		if (((std::iostream *)queryInput)->eof() == 0)
		    ((std::iostream *)queryInput)->getline(newLine,MAX_FILE_INTERFACE_LINE_SIZE);
		else
		{
		    globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"Evaluator",__FILE__,"Unexpected end of file... one sided join line...");
		    if (indexName) delete [] indexName;
		    if (fileName) delete [] fileName;           
		    curr=NULL; return;
		}
		QueryEvaluationTreeNode *oper = evaluator->getQueryEvalNode(newLine,queryInput);
		if (oper == NULL)
		{
		    globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"Evaluator",__FILE__,"Unexpected operand returned... one sided join line...");
		    if (indexName) delete [] indexName;
		    if (fileName) delete [] fileName;
		    curr=NULL; return;
		}

		curr  = new QueryEvaluationTreeOneSidedValueJoinNode(oper,indexName,fileName,leftNRE,rightNRE,rootNRE,nest,outer);
	    }

