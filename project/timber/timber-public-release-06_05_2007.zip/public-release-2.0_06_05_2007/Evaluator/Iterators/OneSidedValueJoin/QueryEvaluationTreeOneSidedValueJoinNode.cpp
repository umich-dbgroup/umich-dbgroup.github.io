/*
COPYRIGHT  � 2000-2004 
THE REGENTS OF THE UNIVERSITY OF MICHIGAN
ALL RIGHTS RESERVED

PERMISSION IS GRANTED TO USE, COPY, CREATE DERIVATIVE WORKS AND REDISTRIBUTE THIS SOFTWARE AND SUCH DERIVATIVE WORKS FOR 
NONCOMMERCIAL EDUCATION AND RESEARCH PURPOSES, SO LONG AS NO FEE IS CHARGED, AND SO LONG AS THE COPYRIGHT NOTICE ABOVE, 
THIS GRANT OF PERMISSION, AND THE DISCLAIMER BELOW APPEAR IN ALL COPIES MADE; AND SO LONG AS THE NAME OF THE UNIVERSITY 
OF MICHIGAN IS NOT USED IN ANY ADVERTISING OR PUBLICITY PERTAINING TO THE USE OR DISTRIBUTION OF THIS SOFTWARE WITHOUT 
SPECIFIC, WRITTEN PRIOR AUTHORIZATION.

THIS SOFTWARE IS PROVIDED AS IS, WITHOUT REPRESENTATION FROM THE UNIVERSITY OF MICHIGAN AS TO ITS FITNESS FOR ANY PURPOSE, 
AND WITHOUT WARRANTY BY THE UNIVERSITY OF MICHIGAN OF ANY KIND, EITHER EXPRESS OR IMPLIED, INCLUDING WITHOUT LIMITATION THE 
IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE. THE REGENTS OF THE UNIVERSITY OF MICHIGAN SHALL 
NOT BE LIABLE FOR ANY DAMAGES, INCLUDING SPECIAL, INDIRECT, INCIDENTAL, OR CONSEQUENTIAL DAMAGES, WITH RESPECT TO ANY CLAIM 
ARISING OUT OF OR IN CONNECTION WITH THE USE OF THE SOFTWARE, EVEN IF IT HAS BEEN OR IS HEREAFTER ADVISED OF THE POSSIBILITY 
OF SUCH DAMAGES.
*/

#include "QueryEvaluationTreeOneSidedValueJoinNode.h"
#include <string>

QueryEvaluationTreeOneSidedValueJoinNode::QueryEvaluationTreeOneSidedValueJoinNode(QueryEvaluationTreeNode* oper, 
												char *indexName,char *fileName,
		 NREType leftNRE, NREType rightNRE, NREType rootNRE, bool nest, bool outer)
: QueryEvaluationTreeNode()
{
	this->oper = oper;
	this->leftNRE = leftNRE;
	this->rightNRE = rightNRE;
	this->rootNRE = rootNRE;
	
	this->nest = nest;
	this->outer = outer;
	this->indexName = indexName;
	this->fileName = fileName;
}



QueryEvaluationTreeOneSidedValueJoinNode::~QueryEvaluationTreeOneSidedValueJoinNode()
{
	if (oper)
		delete oper;
	
	if (fileName) delete [] fileName;
}


void QueryEvaluationTreeOneSidedValueJoinNode::setOper(QueryEvaluationTreeNode *oper)
{
	this->oper = oper;
}

QueryEvaluationTreeNode *QueryEvaluationTreeOneSidedValueJoinNode::getOper()
{
	return this->oper;
}


void QueryEvaluationTreeOneSidedValueJoinNode::setLeftNRE(NREType leftNRE)
{
	this->leftNRE = leftNRE;
}

NREType QueryEvaluationTreeOneSidedValueJoinNode::getLeftNRE()
{
	return this->leftNRE;
}

void QueryEvaluationTreeOneSidedValueJoinNode::setRightNRE(NREType rightNRE)
{
	this->rightNRE = rightNRE;
}

NREType QueryEvaluationTreeOneSidedValueJoinNode::getRightNRE()
{
	return this->rightNRE;
}

void QueryEvaluationTreeOneSidedValueJoinNode::setRootNRE(NREType rootNRE)
{
	this->rootNRE = rootNRE;
}

NREType QueryEvaluationTreeOneSidedValueJoinNode::getRootNRE()
{
	return this->rootNRE;
}



void QueryEvaluationTreeOneSidedValueJoinNode::setNest(bool nest)
{
	this->nest = nest;
}

bool QueryEvaluationTreeOneSidedValueJoinNode::getNest()
{
	return this->nest;
}

void QueryEvaluationTreeOneSidedValueJoinNode::setOuter(bool outer)
{
	this->outer = outer;
}

bool QueryEvaluationTreeOneSidedValueJoinNode::getOuter()
{
	return this->outer;
}



void QueryEvaluationTreeOneSidedValueJoinNode::setIndexName(char *indexName)
{
	this->indexName = indexName;
}

char *QueryEvaluationTreeOneSidedValueJoinNode::getIndexName()
{
	return this->indexName;
}

void QueryEvaluationTreeOneSidedValueJoinNode::setFileName(char *fileName)
{
	this->fileName = fileName;
}

char *QueryEvaluationTreeOneSidedValueJoinNode::getFileName()
{
	return this->fileName;
}

void QueryEvaluationTreeOneSidedValueJoinNode::deleteStructures()
{
	if (indexName) delete [] indexName;
	oper->deleteStructures();
}
