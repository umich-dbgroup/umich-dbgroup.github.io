#include "parse.hpp"

char QueryEvaluationTreeChildChooserNode::getIdentifier(void) { return 'c'; }

char 
ChildChooserPlanParser::getIteratorIdentifier(void) { return 'c'; }

void 
ChildChooserPlanParser::getQueryEvalNode(EvaluatorClass* evaluator, char* line, void* queryInput, QueryEvaluationTreeNode*& curr)
	    {
		char *token = strtok(line+2,",");                    
		if (token == NULL)
		{
		    globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"Evaluator",__FILE__,"Error input from file... expecting whichChild... childChooser line...");
		    curr=NULL; return;
		}
		int whichChild = atoi(token);

		if (whichChild == 0 || whichChild < -1)
		{
		    globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"Evaluator",__FILE__,"Error input from file... whichChild should be positive or -1 (for last child)... childChooser line...");
		    curr=NULL; return;
		}
		token = strtok(NULL,",");
		if (token == NULL)
		{
		    globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"Evaluator",__FILE__,"Error input from file... expecting number... childChooser line...");
		    curr=NULL; return;
		}
		int num = atoi(token);

		if (num < 1)
		{
		    globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"Evaluator",__FILE__,"Error input from file... num of parents should be at least 1)... childChooser line...");
		    curr=NULL; return;
		}
		NREType *parentNRE;
		if (num > 0)
		    parentNRE = new NREType[num];
		else
		    parentNRE = NULL;
		for (int i=0; i<num; i++)
		{
		    token = strtok(NULL,",");
		    if (token == NULL)
		    {
			globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"Evaluator",__FILE__,"Error input from file... expecting parentNRE... childChooser line...");
			delete [] parentNRE;
			curr=NULL; return;
		    }
		    parentNRE[i] = (NREType)atoi(token);
		    if (parentNRE[i] < 1)
		    {
			globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"Evaluator",__FILE__,"NRE should be positive.");
			delete [] parentNRE;
			curr=NULL; return;
		    }
		    if (parentNRE[i] > evaluator->maxNRE)
			evaluator->maxNRE = parentNRE[i];
		}
		char newLine[MAX_FILE_INTERFACE_LINE_SIZE];
		if (((std::iostream *)queryInput)->eof() == 0)
		    ((std::iostream *)queryInput)->getline(newLine,MAX_FILE_INTERFACE_LINE_SIZE);
		else
		{
		    globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"Evaluator",__FILE__,"Unexpected end of file... childChooser line...");
		    if (parentNRE)
			delete [] parentNRE;
		    curr=NULL; return;
		}
		QueryEvaluationTreeNode *oper = evaluator->getQueryEvalNode(newLine,queryInput);
		if (oper == NULL)
		{
		    globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"Evaluator",__FILE__,"Unexpected operand returned... childChooser line...");
		    if (parentNRE)
			delete [] parentNRE;
		    curr=NULL; return;
		}
		curr = new QueryEvaluationTreeChildChooserNode(oper,whichChild,num,parentNRE);
	    }

