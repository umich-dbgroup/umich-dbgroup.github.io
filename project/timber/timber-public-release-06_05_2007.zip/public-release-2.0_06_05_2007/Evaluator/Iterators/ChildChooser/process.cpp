#include "../../Evaluator/EvaluatorClass.h"

#include "QueryEvaluationTreeChildChooserNode.h"

#include "ChildChooserIterator.h"
#include "extra.h"

void QueryEvaluationTreeChildChooserNode::processQueryEvalNode(EvaluatorClass* evaluator, IteratorClass*& curr)
	    {
		IteratorClass *opr = evaluator->processQueryEvalNode(getOperand());
		if (opr == NULL)
		{
		    globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"Evaluator",__FILE__, "operand returned is NULL. child chooser process eval node..." );
		    curr=NULL; return;
		}
		curr = new ChildChooserIterator(opr,getWhichChild(),getNum(),getParentNRE(),evaluator->getDataManager());
		setParentNRE(NULL);
	    }

