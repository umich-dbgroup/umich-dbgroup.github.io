/*
COPYRIGHT  � 2000-2004 
THE REGENTS OF THE UNIVERSITY OF MICHIGAN
ALL RIGHTS RESERVED

PERMISSION IS GRANTED TO USE, COPY, CREATE DERIVATIVE WORKS AND REDISTRIBUTE THIS SOFTWARE AND SUCH DERIVATIVE WORKS FOR 
NONCOMMERCIAL EDUCATION AND RESEARCH PURPOSES, SO LONG AS NO FEE IS CHARGED, AND SO LONG AS THE COPYRIGHT NOTICE ABOVE, 
THIS GRANT OF PERMISSION, AND THE DISCLAIMER BELOW APPEAR IN ALL COPIES MADE; AND SO LONG AS THE NAME OF THE UNIVERSITY 
OF MICHIGAN IS NOT USED IN ANY ADVERTISING OR PUBLICITY PERTAINING TO THE USE OR DISTRIBUTION OF THIS SOFTWARE WITHOUT 
SPECIFIC, WRITTEN PRIOR AUTHORIZATION.

THIS SOFTWARE IS PROVIDED AS IS, WITHOUT REPRESENTATION FROM THE UNIVERSITY OF MICHIGAN AS TO ITS FITNESS FOR ANY PURPOSE, 
AND WITHOUT WARRANTY BY THE UNIVERSITY OF MICHIGAN OF ANY KIND, EITHER EXPRESS OR IMPLIED, INCLUDING WITHOUT LIMITATION THE 
IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE. THE REGENTS OF THE UNIVERSITY OF MICHIGAN SHALL 
NOT BE LIABLE FOR ANY DAMAGES, INCLUDING SPECIAL, INDIRECT, INCIDENTAL, OR CONSEQUENTIAL DAMAGES, WITH RESPECT TO ANY CLAIM 
ARISING OUT OF OR IN CONNECTION WITH THE USE OF THE SOFTWARE, EVEN IF IT HAS BEEN OR IS HEREAFTER ADVISED OF THE POSSIBILITY 
OF SUCH DAMAGES.
*/

#include "ChildChooserIterator.h"

ChildChooserIterator::ChildChooserIterator(IteratorClass *input,
		int whichChild, int num, NREType *nreOfParent, DataMng *dataMng)
{
	this->input = input;
	this->whichChild = whichChild;
	this->nreOfParent = nreOfParent;
	this->num =  num;
	
	count = 0;

	this->dataMng = dataMng;

	input->next(inTuple);
	if (num > 0)
		prevStartKey = new KeyType[num];
	else
		prevStartKey = NULL;
	if (inTuple)
	{
		setPrevStartKey(inTuple);
		if (prevStartKey[0] == -1)
		{
			inTuple = NULL;
			prevTuple = NULL;
			resultBuffer = NULL;
		}
		else
		{
			resultBuffer = inTuple->isSimple()? new WitnessTree : new WitnessTree(LIST_NODE_WITH_DATA,dataMng);
			if (whichChild == -1)
				prevTuple = inTuple->isSimple()? new WitnessTree : new WitnessTree(LIST_NODE_WITH_DATA,dataMng);
			else
				prevTuple = NULL;
		}	
	}
	else
	{
		prevTuple = NULL;
		resultBuffer = NULL;
	}
}


ChildChooserIterator::~ChildChooserIterator()
{
	if (resultBuffer)
		delete resultBuffer;
	if (prevTuple)
		delete prevTuple;
	if (nreOfParent) delete [] nreOfParent;
	if (prevStartKey) delete [] prevStartKey;
	delete input;
}


void ChildChooserIterator::next(WitnessTree *&node)
{
	if (!inTuple)
	{	
		node = NULL;
		return;
	}

#ifdef EVAL_TIME_OUT
	clock_t currTime = clock();
	double queryDuration = (double)(currTime - gQueryStartTime) / CLOCKS_PER_SEC;
	if (queryDuration >= gTimeOutAfter)
	{
		globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"Evaluator",__FILE__,"Query Timed Out.");
		node = NULL;
		return;
	}
#endif

	bool cont = true;
	while (cont)
	{
		// while the current inTuple is the same as the previous one. i.e. the ancs is repeated
		while (sameNode(inTuple,prevStartKey))
		{
			count++;
			setPrevStartKey(inTuple);
			if (whichChild == -1)
			// if we are dealing with the last child, then the prevTuple becomes the current inTuple
				prevTuple->copyTree(inTuple);		

			if (count == whichChild)
			{
				// we found the child we want
				resultBuffer->copyTree(inTuple);
				getNextNewChild(prevStartKey);
				count = 0;
				node = resultBuffer;
				return;
			}
			input->next(inTuple);
			if (!inTuple)
			{
				if (whichChild == -1)
					break;
				node = NULL;
				return;
			}
		}
		
		if (whichChild == -1)
		{
			//we are looking for the last child
			resultBuffer->copyTree(prevTuple);
			if (inTuple)
				setPrevStartKey(inTuple);
			node = resultBuffer;
			return;
		}
		count = 0;
		setPrevStartKey(inTuple);
	}
}


void ChildChooserIterator::getNextNewChild(KeyType *startKey)
{
	// once we find our child, we need to get a new ancs
	while (sameNode(inTuple,startKey))
	{
		input->next(inTuple);
		if (!inTuple)
			return;
	}
	setPrevStartKey(inTuple);
}


bool ChildChooserIterator::sameNode(WitnessTree *in, KeyType *key)
{
	// returns true of the ancs in witness tree has the same start key passed
	for (int i=0; i<num; i++)
	{
		KeyType pk = getParentKey(in,nreOfParent[i]);
		if (pk != key[i])
			return false;
	}
	return true;
}

KeyType ChildChooserIterator::getParentKey(WitnessTree *tree, NREType nre)
{
	if (tree->isSimple())
	{
		ListNode *n = (ListNode *)tree->findNodeNRE(nre);
		if (n)
			return n->GetStartPos();
		else
			return -1;
	}
	else
	{
		ComplexListNode *n = (ComplexListNode *)tree->findNodeNRE(nre);
		if (n)
			return n->GetStartPos();
		else
			return -1;
	}
}

void ChildChooserIterator::setPrevStartKey(WitnessTree *tree)
{
	for (int i=0; i<num; i++)
		prevStartKey[i] = getParentKey(tree,nreOfParent[i]);
}
