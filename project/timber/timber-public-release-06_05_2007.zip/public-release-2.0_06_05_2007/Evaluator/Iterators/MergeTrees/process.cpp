#include "../../Evaluator/EvaluatorClass.h"

#include "QueryEvaluationTreeMergeTreesNode.h"

#include "MergeTreesIterator.h"
#include "extra.h"

void QueryEvaluationTreeMergeTreesNode::processQueryEvalNode(EvaluatorClass* evaluator, IteratorClass*& curr)
	    {
		if (getNumInputs() == 0)
		    curr=NULL; return;
		IteratorClass **opr = new IteratorClass *[getNumInputs()];
		for (int i=0; i<getNumInputs(); i++)
		{
		    opr[i] = evaluator->processQueryEvalNode(getOperands()[i]);
		    if (opr[i] == NULL)
			curr=NULL; return;
		}
		curr = new MergeTreesIterator(opr,getNumInputs(),  evaluator->getDataManager());
	    }

