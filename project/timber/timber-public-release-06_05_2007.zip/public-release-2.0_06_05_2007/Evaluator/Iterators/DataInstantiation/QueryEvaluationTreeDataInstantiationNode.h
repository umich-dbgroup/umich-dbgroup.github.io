#ifndef __QueryEvaluationTreeDataInstantiationNode_H
#define __QueryEvaluationTreeDataInstantiationNode_H
#include <timber-compat.h>


#include "../../QueryEvaluationTree/QueryEvaluationTreeNode.h"
#include "../../DataMng/DataMng.h"


class QueryEvaluationTreeDataInstantiationNode :
	public QueryEvaluationTreeNode
{
public: 
	void processQueryEvalNode(EvaluatorClass* evaluator, IteratorClass*& curr);
	char getIdentifier();
	QueryEvaluationTreeDataInstantiationNode(QueryEvaluationTreeNode* operand,
		int nodeindex,
		DataInstantiationSpecification* diSpecification);
	
	~QueryEvaluationTreeDataInstantiationNode(void);
	
	QueryEvaluationTreeNode* getOperand();
	int getNodeIndexInWitnessTree();
	DataInstantiationSpecification* getDISpecification();
	void deleteStructures();

private:
	QueryEvaluationTreeNode* operand;
	int nodeIndexInWitnessTree;
	DataInstantiationSpecification* diSpecification;
};

#endif
