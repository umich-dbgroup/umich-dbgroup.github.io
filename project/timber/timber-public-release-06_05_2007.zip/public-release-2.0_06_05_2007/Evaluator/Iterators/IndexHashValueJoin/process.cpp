#include "../../Evaluator/EvaluatorClass.h"

#include "QueryEvaluationTreeIndexHashValueJoinNode.h"

#include "IndexHashValueJoinIterator.h"
#include "extra.h"

void QueryEvaluationTreeIndexHashValueJoinNode::processQueryEvalNode(EvaluatorClass* evaluator, IteratorClass*& curr)
	    {
		int openFileIndex= evaluator->openFile(getFileName(),evaluator->getDataManager());
		if (openFileIndex == -1)
		{
		    globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"Evaluator",__FILE__,"File is unloaded in Timber.");
		    curr=NULL; return;
		}
		IteratorClass *opr1 = evaluator->processQueryEvalNode(getOper1());

		if (opr1 == NULL)
		{
		    globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"Evaluator",__FILE__, "operand 1 returned is NULL. index hash value join process eval node..." );
		    curr=NULL; return;
		}

		IteratorClass *opr2 = evaluator->processQueryEvalNode(getOper2());

		if (opr2 == NULL)
		{
		    globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"Evaluator",__FILE__, "operand 2 returned is NULL. index hash value join process eval node..." );
		    delete opr1;
		    curr=NULL; return;
		}

		curr = new IndexHashValueJoinIterator(opr1,opr2,getLeftNRE(),getRightNRE(),getSize(),evaluator->getDataManager(),
			getOuter(),getRootNRE(),getIndexName(),(char)openFileIndex,getAtLeastOne());
		setIndexName(NULL);
	    }

