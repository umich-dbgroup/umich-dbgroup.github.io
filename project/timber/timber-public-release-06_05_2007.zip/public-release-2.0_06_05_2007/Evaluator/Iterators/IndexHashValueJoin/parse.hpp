#include "../../Evaluator/EvaluatorClass.h"

#include "extra.h"

class IndexHashValueJoinPlanParser
{
public:

	static char getIteratorIdentifier(void) ;

	static void getQueryEvalNode(EvaluatorClass* evaluator, char* line, void* queryInput, QueryEvaluationTreeNode*& curr) ;

} ;

#ifndef WIN32

extern "C" char getIteratorIdentifier(void) 
{
	return IndexHashValueJoinPlanParser::getIteratorIdentifier() ;
} ;

extern "C" void getQueryEvalNode(EvaluatorClass* evaluator, char* line, void* queryInput, QueryEvaluationTreeNode*& curr)
{
	return IndexHashValueJoinPlanParser::getQueryEvalNode(evaluator, line, queryInput, curr) ;
} ;

#endif
