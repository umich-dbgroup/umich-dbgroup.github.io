#include "../../Evaluator/EvaluatorClass.h"

#include "QueryEvaluationTreeValueSortNode.h"

#include "ExternalValueSortIterator.h"
#include "ValueSortIterator.h"
#include "extra.h"

void QueryEvaluationTreeValueSortNode::processQueryEvalNode(EvaluatorClass* evaluator, IteratorClass*& curr)
	    {
		serial_t fileID = 0;
		serial_t recID = 0;
		int numWrites = 0;
		if (getExt())
		{
		    fileID = evaluator->fileIDsArray[evaluator->fileIDsArrayPtr];
		    evaluator->fileIDsArrayPtr++;
		    numWrites = evaluator->createRecID(recID);
		    if (numWrites == FAILURE)
		    {
			globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"Evaluator",__FILE__, "operand returned is NULL. sort process eval node..." );
			curr=NULL; return;
		    }
		}
		IteratorClass *opr = evaluator->processQueryEvalNode(getOperand());
		if (opr == NULL)
		{
		    globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"Evaluator",__FILE__, "operand returned is NULL. value sort process eval node..." );
		    curr=NULL; return;
		}
		if (getExt())
		    curr = new ExternalValueSortIterator(opr,getNum(),getSortBy(),getNRE(),
			    getAttrName(),getOrder(),evaluator->getDataManager(),getWhereEmptyGoes()
			    ,fileID,recID,numWrites);
		else
		    curr = new ValueSortIterator(opr,getNumExpected(),getNum(),getSortBy(),getNRE(),
			    getAttrName(),getOrder(),evaluator->getDataManager(),getWhereEmptyGoes());
		setNRE(NULL);
		setSortBy(NULL);
		setAttrName(NULL);
		setWhereEmptyGoes(NULL);
		setOrder(NULL);
	    }

