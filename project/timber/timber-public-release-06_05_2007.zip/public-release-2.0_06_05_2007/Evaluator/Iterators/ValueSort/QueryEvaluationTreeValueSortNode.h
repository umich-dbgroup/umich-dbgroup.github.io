/*
COPYRIGHT  � 2000-2004 
THE REGENTS OF THE UNIVERSITY OF MICHIGAN
ALL RIGHTS RESERVED

PERMISSION IS GRANTED TO USE, COPY, CREATE DERIVATIVE WORKS AND REDISTRIBUTE THIS SOFTWARE AND SUCH DERIVATIVE WORKS FOR 
NONCOMMERCIAL EDUCATION AND RESEARCH PURPOSES, SO LONG AS NO FEE IS CHARGED, AND SO LONG AS THE COPYRIGHT NOTICE ABOVE, 
THIS GRANT OF PERMISSION, AND THE DISCLAIMER BELOW APPEAR IN ALL COPIES MADE; AND SO LONG AS THE NAME OF THE UNIVERSITY 
OF MICHIGAN IS NOT USED IN ANY ADVERTISING OR PUBLICITY PERTAINING TO THE USE OR DISTRIBUTION OF THIS SOFTWARE WITHOUT 
SPECIFIC, WRITTEN PRIOR AUTHORIZATION.

THIS SOFTWARE IS PROVIDED AS IS, WITHOUT REPRESENTATION FROM THE UNIVERSITY OF MICHIGAN AS TO ITS FITNESS FOR ANY PURPOSE, 
AND WITHOUT WARRANTY BY THE UNIVERSITY OF MICHIGAN OF ANY KIND, EITHER EXPRESS OR IMPLIED, INCLUDING WITHOUT LIMITATION THE 
IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE. THE REGENTS OF THE UNIVERSITY OF MICHIGAN SHALL 
NOT BE LIABLE FOR ANY DAMAGES, INCLUDING SPECIAL, INDIRECT, INCIDENTAL, OR CONSEQUENTIAL DAMAGES, WITH RESPECT TO ANY CLAIM 
ARISING OUT OF OR IN CONNECTION WITH THE USE OF THE SOFTWARE, EVEN IF IT HAS BEEN OR IS HEREAFTER ADVISED OF THE POSSIBILITY 
OF SUCH DAMAGES.
*/

#include "../../QueryEvaluationTree/QueryEvaluationTreeNode.h"

#ifndef __QueryEvaluationTreeValueSortNode_H
#define __QueryEvaluationTreeValueSortNode_H
#include <timber-compat.h>

#define SORTBY_ATTRIBUTE_NUM	1
#define SORTBY_ATTRIBUTE_STR	2
#define SORTBY_TEXT_NUM			3
#define SORTBY_TEXT_STR			4
#define SORTBY_TAGNAME			5
#define SORTBY_VALUE_NUM		6
#define SORTBY_VALUE_STR		7
#define SORTBY_ATTRIBUTE_KEY	8

class QueryEvaluationTreeValueSortNode: public QueryEvaluationTreeNode
{
public: 
	void processQueryEvalNode(EvaluatorClass* evaluator, IteratorClass*& curr);
	char getIdentifier();
	QueryEvaluationTreeValueSortNode( 
		int numExpected, int num, int *sortBy,  
									NREType *nre, char **attrName, int *order,
		QueryEvaluationTreeNode* operand, int *whereEmptyGoes, bool ext = false);
	~QueryEvaluationTreeValueSortNode();


	int *getSortBy();

	int getNum();
	int getNumExpected();

	int *getOrder();

	char **getAttrName();
	void setAttrName(char **attrName);

	void setSortBy(int *sortBy);
	void setNum(int num);
	void setNumExpected(int numExpected);

	void setOrder(int *order);

	NREType *getNRE();
	void setNRE(NREType *nre);

	QueryEvaluationTreeNode* getOperand();
	void setOperand(QueryEvaluationTreeNode* operand);

	int *getWhereEmptyGoes();
	void setWhereEmptyGoes(int *whereEmptyGoes);

	bool getExt();
	void setExt(bool ext);
	void deleteStructures();

private:

	int numExpected;
	int num;
	int *sortBy;

	bool ext;
	NREType *nre; 
	char **attrName; 
	int *order;
	int *whereEmptyGoes;
	QueryEvaluationTreeNode* operand;
};


#endif


