/*
COPYRIGHT  � 2000-2004 
THE REGENTS OF THE UNIVERSITY OF MICHIGAN
ALL RIGHTS RESERVED

PERMISSION IS GRANTED TO USE, COPY, CREATE DERIVATIVE WORKS AND REDISTRIBUTE THIS SOFTWARE AND SUCH DERIVATIVE WORKS FOR 
NONCOMMERCIAL EDUCATION AND RESEARCH PURPOSES, SO LONG AS NO FEE IS CHARGED, AND SO LONG AS THE COPYRIGHT NOTICE ABOVE, 
THIS GRANT OF PERMISSION, AND THE DISCLAIMER BELOW APPEAR IN ALL COPIES MADE; AND SO LONG AS THE NAME OF THE UNIVERSITY 
OF MICHIGAN IS NOT USED IN ANY ADVERTISING OR PUBLICITY PERTAINING TO THE USE OR DISTRIBUTION OF THIS SOFTWARE WITHOUT 
SPECIFIC, WRITTEN PRIOR AUTHORIZATION.

THIS SOFTWARE IS PROVIDED AS IS, WITHOUT REPRESENTATION FROM THE UNIVERSITY OF MICHIGAN AS TO ITS FITNESS FOR ANY PURPOSE, 
AND WITHOUT WARRANTY BY THE UNIVERSITY OF MICHIGAN OF ANY KIND, EITHER EXPRESS OR IMPLIED, INCLUDING WITHOUT LIMITATION THE 
IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE. THE REGENTS OF THE UNIVERSITY OF MICHIGAN SHALL 
NOT BE LIABLE FOR ANY DAMAGES, INCLUDING SPECIAL, INDIRECT, INCIDENTAL, OR CONSEQUENTIAL DAMAGES, WITH RESPECT TO ANY CLAIM 
ARISING OUT OF OR IN CONNECTION WITH THE USE OF THE SOFTWARE, EVEN IF IT HAS BEEN OR IS HEREAFTER ADVISED OF THE POSSIBILITY 
OF SUCH DAMAGES.
*/

#include "QueryEvaluationTreeValueSortNode.h"


QueryEvaluationTreeValueSortNode::QueryEvaluationTreeValueSortNode( 
		int numExpected, int num, int *sortBy,  
									NREType *nre, char **attrName, int *order,
		QueryEvaluationTreeNode* operand, int *whereEmptyGoes, bool ext)
: QueryEvaluationTreeNode()
{

	this->numExpected = numExpected;
	this->num = num;
	this->sortBy = sortBy;
	this->nre = nre;
	this->attrName = attrName;
	this->order = order;
	this->whereEmptyGoes = whereEmptyGoes;
	this->operand = operand;
	this->ext = ext;
}

QueryEvaluationTreeValueSortNode::~QueryEvaluationTreeValueSortNode()
{
	if (operand)
		delete operand;
}


int *QueryEvaluationTreeValueSortNode::getSortBy()
{
	return this->sortBy;
}

char **QueryEvaluationTreeValueSortNode::getAttrName()
{
	return this->attrName;
}

int QueryEvaluationTreeValueSortNode::getNum()
{
	return num;
}

int *QueryEvaluationTreeValueSortNode::getOrder()
{
	return order;
}

int QueryEvaluationTreeValueSortNode::getNumExpected()
{
	return this->numExpected;
}

void QueryEvaluationTreeValueSortNode::setSortBy(int *sortBy)
{
	this->sortBy = sortBy;
}

void QueryEvaluationTreeValueSortNode::setAttrName(char **attrName)
{
	this->attrName = attrName;
}

void QueryEvaluationTreeValueSortNode::setNum(int num)
{
	this->num = num;
}

void QueryEvaluationTreeValueSortNode::setWhereEmptyGoes(int *whereEmptyGoes)
{
	this->whereEmptyGoes = whereEmptyGoes;
}

int *QueryEvaluationTreeValueSortNode::getWhereEmptyGoes()
{
	return this->whereEmptyGoes;
}

void QueryEvaluationTreeValueSortNode::setOrder(int *order)
{
	this->order = order;
}

void QueryEvaluationTreeValueSortNode::setNumExpected(int numExpected)
{
	this->numExpected = numExpected;
}

NREType *QueryEvaluationTreeValueSortNode::getNRE()
{
	return nre;
}

void QueryEvaluationTreeValueSortNode::setNRE(NREType *nre)
{
	this->nre = nre;
}


QueryEvaluationTreeNode* QueryEvaluationTreeValueSortNode::getOperand()
{
	return operand;
}

void QueryEvaluationTreeValueSortNode::setOperand(QueryEvaluationTreeNode *operand)
{
	this->operand = operand;
}

void QueryEvaluationTreeValueSortNode::setExt(bool ext)
{
	this->ext = ext;
}

bool QueryEvaluationTreeValueSortNode::getExt()
{
	return ext;
}

void QueryEvaluationTreeValueSortNode::deleteStructures()
{
	if (sortBy) delete [] sortBy;
	if (nre) delete [] nre;
	if (attrName)
	{
		for (int i=0; i<this->num; i++)
			if (attrName[i]) delete [] attrName[i];
		delete [] attrName;
	}
	if (order) delete [] order;
	if (whereEmptyGoes) delete [] whereEmptyGoes;
	operand->deleteStructures();
}
