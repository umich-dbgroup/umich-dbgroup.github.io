
#include "parse.hpp"

char QueryEvaluationTreeUpdatesNode::getIdentifier(void) { return 'U'; }

char UpdatesPlanParser::getIteratorIdentifier(void) { return 'U'; }

void 
UpdatesPlanParser::getQueryEvalNode(EvaluatorClass* evaluator, char* line, void* queryInput, QueryEvaluationTreeNode*& curr)
	    {
		//gNumUpdates++;

		//evaluator should be put in a helper function:
		char newLine[MAX_FILE_INTERFACE_LINE_SIZE];
		if (((std::iostream *)queryInput)->eof() == 0)
		    ((std::iostream *)queryInput)->getline(newLine,MAX_FILE_INTERFACE_LINE_SIZE);
		else
		{
		    globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"Evaluator",__FILE__,"Unexpected end of file... Updates line...");
		    curr=NULL; return;
		}
		QueryEvaluationTreeNode *oper = evaluator->getQueryEvalNode(newLine, queryInput);
		if (oper == NULL)
		{
		    globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"Evaluator",__FILE__,"Unexpected operand returned... Updates line...");
		    curr=NULL; return;
		}
		//

		if (strlen(line) <= 2) {
		    globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"Evaluator",__FILE__,"Input file formatting error... no parameters included after 'U'" );
		    curr=NULL; return;
		}

		char *updateOperation = strtok(line+2,",");
		if (updateOperation == NULL) {
		    globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"Evaluator",__FILE__,"Input file formatting error... expecting value for x in line -> 'U,x,...'");
		    curr=NULL; return;
		}

		NREType nre = (NREType)atoi(strtok(NULL,","));
		if (nre == 0) {
		    globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"Evaluator",__FILE__,"Input file formatting error... expecting an integer value for x in line -> 'U,UpdateOp,x,...'");
		    curr=NULL; return;
		}

		//char *indexToUpdate = strtok(NULL,",");
		//if (indexToUpdate == NULL) {
		//	globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"Evaluator",__FILE__,"Input file formatting error... expecting value for x in line -> 'U,UpdateOp,NRE,x,...'");
		//	curr=NULL; return;
		//}

		char *textValue1 = strtok(NULL,",");
		char *textValue2 = NULL;//strtok(NULL,",");
		char *textValue3 = NULL;//strtok(NULL,",");
		char *textValue4 = NULL;

		if (strcmp(updateOperation, "ModTNode") == 0) {

		    if (textValue1 == NULL) {
			globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"Evaluator",__FILE__,"Unexpected input in Updates line... expecting either CONST or REF for x in line -> 'U,ModTNode,NRE,x,...");
			curr=NULL; return;
		    }

		    //do not allow an empty value for textValue2.   Text Node deletions are performed with DelTNode, not ModTNode
		    textValue2 = strtok(NULL,",");
		    if (textValue2 == NULL) {
			if (strcmp(textValue1, "CONST") == 0)
			    globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"Evaluator",__FILE__,"Unexpected input in Updates line... expecting a constant value for x in line -> 'U,ModTNode,NRE,CONST,x");
			else if (strcmp(textValue1, "REF") == 0)
			    globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"Evaluator",__FILE__,"Unexpected input in Updates line... expecting a reference (an LCL) for x in line -> 'U,ModTNode,NRE,REF,x");
			else
			    globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"Evaluator",__FILE__,"Unexpected input in Updates line... expecting a value for x in line -> 'U,ModTNode,NRE,CONSTorREF,x");
			curr=NULL; return;
		    }

		    //if REF, check to make sure the ref (LCL) is actually an integer, and is > 0:
		    if (strcmp(textValue1, "REF") == 0) {
			errno = 0;
			char *suffixPtr;

			long tempResult = strtol(textValue2, &suffixPtr, 10);
			if (errno || tempResult < 0 || suffixPtr[0] != '\0') {
			    globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"Evaluator",__FILE__,"Unexpected input in Updates line... The input (LCL) should be a positive integer -> 'U,ModTNode,NRE,REF,LCL");
			    curr=NULL; return;
			}
		    }

		    //textValue3 is used if textValue1==REF, and the NRE in textValue2 is an attribute node:
		    textValue3 = strtok(NULL,",");

		    gUpdatesArray.push_back(pair<int, string>(0, "Text Node Modification"));
		    curr = new QueryEvaluationTreeUpdatesNode(oper,
			    QueryEvaluationTreeUpdatesNode::MODIFY_TEXT_NODE, nre,
			    textValue1, textValue2, textValue3, textValue4);
		}
		else if (strcmp(updateOperation, "DelTNode") == 0) {
		    gUpdatesArray.push_back(pair<int, string>(0, "Text Node Deletion"));
		    curr = new QueryEvaluationTreeUpdatesNode(oper,
			    QueryEvaluationTreeUpdatesNode::DELETE_TEXT_NODE, nre,
			    textValue1, textValue2, textValue3, textValue4);
		}
		else if (strcmp(updateOperation, "DelTree") == 0) {
		    gUpdatesArray.push_back(pair<int, string>(0, "Subtree Deletion"));
		    curr = new QueryEvaluationTreeUpdatesNode(oper,
			    QueryEvaluationTreeUpdatesNode::DELETE_TREE, nre,
			    textValue1, textValue2, textValue3, textValue4);
		}
		else if (strcmp(updateOperation, "DelAttr") == 0) {
		    if (textValue1 == NULL) {
			globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"Evaluator",__FILE__,"Unexpected input in Updates line... expecting an attributeName for x in line -> 'U,DelAttr,AttributeNRE,x");
			curr=NULL; return;
		    }

		    gUpdatesArray.push_back(pair<int, string>(0, "Attribute Deletion"));
		    curr = new QueryEvaluationTreeUpdatesNode(oper,
			    QueryEvaluationTreeUpdatesNode::DELETE_ATTRIBUTE, nre,
			    textValue1, textValue2, textValue3, textValue4);
		}
		else if (strcmp(updateOperation, "DelAttrValue") == 0) {
		    if (textValue1 == NULL) {
			globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"Evaluator",__FILE__,"Unexpected input in Updates line... expecting an attributeName for x in line -> 'U,DelAttrValue,AttributeNRE,x");
			curr=NULL; return;
		    }

		    gUpdatesArray.push_back(pair<int, string>(0, "Attribute Value Deletion"));
		    curr = new QueryEvaluationTreeUpdatesNode(oper,
			    QueryEvaluationTreeUpdatesNode::DELETE_ATTRIBUTE_VALUE, nre,
			    textValue1, textValue2, textValue3, textValue4);
		}
		//else if (strcmp(updateOperation, "InsAttr") == 0) {
		//}
		else if (strcmp(updateOperation, "ModANode") == 0) {
		    if (textValue1 == NULL) {
			globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"Evaluator",__FILE__,"Unexpected input in Updates line... expecting an attributeName for x in line -> 'U,ModANode,AttributeNRE,x");
			curr=NULL; return;
		    }

		    //textValue2 (CONST or REF) and textValue3 is required for ModANode
		    //(if the attribute value is to be deleted DelAttrValue will be used, not textValue3 = NULL)
		    textValue2 = strtok(NULL,",");
		    if (textValue2 == NULL) {
			globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"Evaluator",__FILE__,"Unexpected input in Updates line... expecting CONST or REF for x in line -> 'U,ModANode,AttributeNRE,AttributeName,x");
			curr=NULL; return;
		    }

		    textValue3 = strtok(NULL,",");
		    if (textValue3 == NULL) {
			globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"Evaluator",__FILE__,"Unexpected input in Updates line... expecting value for x in line -> 'U,ModANode,AttributeNRE,AttributeName,CONSTorREF,x");
			curr=NULL; return;
		    }

		    //if REF, check to make sure the ref (LCL) is actually an integer, and is > 0:
		    if (textValue2 != NULL && strcmp(textValue2, "REF") == 0) {
			errno = 0;
			char *suffixPtr;

			long tempResult = strtol(textValue3, &suffixPtr, 10);
			if (errno || tempResult < 0 || suffixPtr[0] != '\0') {
			    globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"Evaluator",__FILE__,"Unexpected input in Updates line... The input (LCL) should be a positive integer -> 'U,ModANode,AttributeNRE,AttributeName,REF,LCL,...");
			    curr=NULL; return;
			}
		    }

		    //textValue4 is used if textValue2==REF, and the NRE in textValue3 is an attribute node:
		    textValue4 = strtok(NULL,",");

		    gUpdatesArray.push_back(pair<int, string>(0, "Attribute Value Modification"));
		    curr = new QueryEvaluationTreeUpdatesNode(oper,
			    QueryEvaluationTreeUpdatesNode::MODIFY_ATTRIBUTE_VALUE, nre,
			    textValue1, textValue2, textValue3, textValue4);

		}
		else if (strcmp(updateOperation, "InsAttr") == 0) {
		    if (textValue1 == NULL) {
			globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"Evaluator",__FILE__,"Unexpected input in Updates line... expecting an attributeName for x in line -> 'U,InsAttr,AttributeNRE,x");
			curr=NULL; return;
		    }

		    //the CONST (and the following) arguments can be left off for InsAttr
		    textValue2 = strtok(NULL,",");

		    textValue3 = strtok(NULL,",");
		    //if REF, check to make sure the ref (LCL) is actually an integer, and is > 0:
		    if (textValue2 != NULL && strcmp(textValue2, "REF") == 0) {
			errno = 0;
			char *suffixPtr;

			long tempResult = strtol(textValue3, &suffixPtr, 10);
			if (errno || tempResult < 0 || suffixPtr[0] != '\0') {
			    globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"Evaluator",__FILE__,"Unexpected input in Updates line... The input (LCL) should be a positive integer -> 'U,updateOp,AttributeNRE,REF,LCL,...");
			    curr=NULL; return;
			}
		    }

		    //if textValue2 is CONST or REF, then textValue3 is required
		    if (textValue2 != NULL && strcmp(textValue2, "<NOVAL>") != 0) {
			if (textValue3 == NULL) {
			    globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"Evaluator",__FILE__,"Unexpected input in Updates line... expecting a reference (an LCL) for x in line -> 'U,updateOp,AttributeNRE,REF,x");
			    curr=NULL; return;
			}
		    }

		    //textValue4 is used if textValue2==REF, and the NRE in textValue3 is an attribute node:
		    textValue4 = strtok(NULL,",");

		    gUpdatesArray.push_back(pair<int, string>(0, "Attribute Insertion"));
		    curr = new QueryEvaluationTreeUpdatesNode(oper,
			    QueryEvaluationTreeUpdatesNode::INSERT_ATTRIBUTE, nre,
			    textValue1, textValue2, textValue3, textValue4);

		}
		else if (strcmp(updateOperation, "InsENode") == 0) {
		    if (textValue1 == NULL) {
			globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"Evaluator",__FILE__,"Unexpected input in Updates line... expecting the new element's tagname for x in line -> 'U,InsENode,elementNRE,x");
			curr=NULL; return;
		    }
		    //textValue1 == newElementTag
		    textValue2 = strtok(NULL,",");	//textValue2 == constOrRef
		    //textValue3 = strtok(NULL,",");	//textValue3 == constValueOrNRE
		    //textValue4 = strtok(NULL,",");	//textValue4 == possibleAttributeName (if constValueOrNRE refers to an attribute node)

		    if (textValue2 == NULL) {
			globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"Evaluator",__FILE__,"Unexpected input in Updates line... expecting one of CONST, REF, or <NOVAL> for x in line -> 'U,InsENode,elementNRE,newElementName,x");
			curr=NULL; return;
		    }

		    if (strcmp(textValue2, "<NOVAL>") != 0) {
			textValue3 = strtok(NULL,",");	//textValue3 == constValueOrNRE

			if (strcmp(textValue2, "REF") == 0) {
			    errno = 0;
			    char *suffixPtr;

			    long tempResult = strtol(textValue3, &suffixPtr, 10);
			    if (errno || tempResult < 0 || suffixPtr[0] != '\0') {
				globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"Evaluator",__FILE__,"Unexpected input in Updates line... x (the NRE) should be a positive integer in the line -> 'U,InsENode,ElementNRE,newChildTag,REF,x,...");
				curr=NULL; return;
			    }

			    //might be a "placeholder" (have the user enter a dummy value of -1 or something):
			    textValue4 = strtok(NULL,",");	//textValue4 == possibleAttributeName (if constValueOrNRE refers to an attribute node)
			}
		    }

		    gUpdatesArray.push_back(pair<int, string>(0, "Element Insertion"));
		    curr = new QueryEvaluationTreeUpdatesNode(oper,
			    QueryEvaluationTreeUpdatesNode::INSERT_ELEMENT_NODE, nre,
			    textValue1, textValue2, textValue3, textValue4);

		    //read in the attribute pairs and add them to the QueryEvaluationTreeUpdatesNode
		    //<attributeName, constOrRef, valueOrNRE, attributeNameIfNreIsAttribute>
		    char * attributeName = strtok(NULL, ",");
		    while (attributeName) {

			char *constOrRef = NULL;
			char *valueOrNRE = NULL;
			char *attributeNameIfNreIsAttribute = NULL;


			constOrRef = strtok(NULL, ",");
			if (constOrRef == NULL) {
			    globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"Evaluator",__FILE__,"Unexpected input in Updates line... expecting one of CONST, REF, or <NOVAL> for attribute in InsENode line");
			    curr=NULL; return;
			}

			if (strcmp(constOrRef, "<NOVAL>") != 0) {
			    valueOrNRE = strtok(NULL,",");	//textValue3 == constValueOrNRE

			    if (strcmp(constOrRef, "REF") == 0) {
				errno = 0;
				char *suffixPtr;

				long tempResult = strtol(valueOrNRE, &suffixPtr, 10);
				if (errno || tempResult < 0 || suffixPtr[0] != '\0') {
				    globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"Evaluator",__FILE__,"Unexpected input in Updates line... attribute NRE should be a positive integer");
				    curr=NULL; return;
				}

				//might be a "placeholder" (have the user enter a dummy value of -1 or something):
				attributeNameIfNreIsAttribute = strtok(NULL,",");	//(actual value if constValueOrNRE refers to an attribute node)
			    }
			}

			AttributeInfo attributeInfo(attributeName, constOrRef, valueOrNRE, attributeNameIfNreIsAttribute);

			//downcasts are usually not a good idea, but putting virtual functions into
			//QueryEvaluationTreeNode is not that clean either...
			static_cast<QueryEvaluationTreeUpdatesNode*>(curr)->addRepeatedPair(attributeInfo);

			attributeName = strtok(NULL, ",");
		    } //while attributeName
		}
		else if (strcmp(updateOperation, "InsFile") == 0) {
		    globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"Evaluator",__FILE__,"The InsFile update operator is not currently supported. You can use the 'append' mode from the command line to append an XML file to an existing document");
		    curr=NULL; return;
		}
		else {
		    globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"Evaluator",__FILE__, "The update operation (UpdateOp) does not match any supported operation names -> U,UpdateOp,..." );
		    curr = NULL;
		}

	    } //case 'U'

