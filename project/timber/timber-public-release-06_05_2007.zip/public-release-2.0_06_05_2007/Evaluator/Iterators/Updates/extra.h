#include <vector>
using std::vector;
using std::pair;
extern vector< pair<int, string> > gUpdatesArray;
#include "QueryEvaluationTreeUpdatesNode.h"
