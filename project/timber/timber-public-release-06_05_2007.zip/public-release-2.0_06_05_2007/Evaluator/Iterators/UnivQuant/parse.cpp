
#include "parse.hpp"

char QueryEvaluationTreeUnivQuantNode::getIdentifier(void) { return 'u'; }

char UnivQuantPlanParser::getIteratorIdentifier(void) { return 'u'; }

void 
UnivQuantPlanParser::getQueryEvalNode(EvaluatorClass* evaluator, char* line, void* queryInput, QueryEvaluationTreeNode*& curr)
	    {
		char *token = strtok(line+2,",");
		if (token == NULL)
		{
		    globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"Evaluator",__FILE__,"Expecting rootNRE in UnivQuant Line.");
		    curr=NULL; return;
		}
		NREType rootNRE = (NREType)atoi(token);
		if (rootNRE > evaluator->maxNRE)
		    evaluator->maxNRE = rootNRE;

		token = strtok(NULL,",");
		if (token == NULL)
		{
		    globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"Evaluator",__FILE__,"Expecting number of nodes in pattern in UnivQuant Line.");
		    curr=NULL; return;
		}
		int num = atoi(token);

		int *relation;
		if (num > 0)
		    relation = new int[num];
		else
		    relation = NULL;

		for (int i=0; i<num; i++)
		{
		    token = strtok(NULL,",");
		    if (token == NULL)
		    {
			globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"Evaluator",__FILE__,"Expecting relation in UnivQuant Line.");
			curr=NULL; return;
		    }
		    relation[i] = (strcmp(token,"P") == 0? PARENT_CHILD : ANCS_DESC);
		}

		UnivQuantCondition *cond = new UnivQuantCondition;
		token = strtok(NULL,",");
		if (token == NULL)
		{
		    globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"Evaluator",__FILE__,"Expecting compareWhat in UnivQuant Line.");
		    curr=NULL; return;
		}

		int compareWhat = (strcmp(token,"T") == 0? UQC_COMPARE_TEXT : UQC_COMPARE_ATTR);
		cond->setCompareWhat(compareWhat);

		token = strtok(NULL,",");
		if (token == NULL)
		{
		    globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"Evaluator",__FILE__,"Expecting attribute name in UnivQuant Line.");
		    curr=NULL; return;
		}
		char *attrName;
		/*	if (strcmp(token,"NULL") == 0)
			attrName = NULL;
			else
			{*/
		attrName = new char[strlen(token) +1];
		strcpy(attrName,token);
		//	}
		cond->setAttrName(attrName);

		token = strtok(NULL,",");
		if (token == NULL)
		{
		    globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"Evaluator",__FILE__,"Expecting operation in UnivQuant Line.");
		    curr=NULL; return;
		}
		int opr;
		if (strcmp(token,"EQN") == 0)
		    opr = UQC_EQ_NUM;
		else if (strcmp(token,"NEN") == 0)
		    opr = UQC_NE_NUM;
		else if (strcmp(token,"LTN") == 0)
		    opr = UQC_LT_NUM;
		else if (strcmp(token,"LEN") == 0)
		    opr = UQC_LE_NUM;
		else if (strcmp(token,"GTN") == 0)
		    opr = UQC_GT_NUM;
		else if (strcmp(token,"GEN") == 0)
		    opr = UQC_GE_NUM;
		else if (strcmp(token,"EQS") == 0)
		    opr = UQC_EQ_STR;
		else if (strcmp(token,"NES") == 0)
		    opr = UQC_NE_STR;
		else if (strcmp(token,"LTS") == 0)
		    opr = UQC_LT_STR;
		else if (strcmp(token,"LES") == 0)
		    opr = UQC_LE_STR;
		else if (strcmp(token,"GTS") == 0)
		    opr = UQC_GT_STR;
		else if (strcmp(token,"GES") == 0)
		    opr = UQC_GE_STR; 
		else if (strcmp(token,"S") == 0)
		    opr = UQC_STARTS_WITH;
		else
		    opr = UQC_CONTAINS;
		cond->setOperation(opr);

		token = strtok(NULL,",");
		if (token == NULL)
		{
		    globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"Evaluator",__FILE__,"Expecting number in UnivQuant Line.");
		    curr=NULL; return;
		}
		double number = atof(token);
		cond->setNum(number);

		token = strtok(NULL,",");
		if (token == NULL)
		{
		    globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"Evaluator",__FILE__,"Expecting str in UnivQuant Line.");
		    curr=NULL; return;
		}
		char *str;
		if (strcmp(token,"NULL") == 0)
		    str = NULL;
		else
		{
		    str = new char[strlen(token) +1];
		    strcpy(str,token);
		}
		cond->setStr(str);

		IteratorClass **pattern;
		if (num > 0)
		    pattern = new IteratorClass *[num];
		else
		    pattern = NULL;
		if (pattern == NULL)
		{
		    globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"Evaluator",__FILE__,"Pattern cannot be NULL in UnivQuant Line.");
		    curr=NULL; return;
		}
		for (int i=0; i<num; i++)
		{  
		    char newLine[MAX_FILE_INTERFACE_LINE_SIZE];
		    if (((std::iostream *)queryInput)->eof() == 0)
			((std::iostream *)queryInput)->getline(newLine,MAX_FILE_INTERFACE_LINE_SIZE);
		    else
		    {
			globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"Evaluator",__FILE__,"Unexpected end of file in UnivQuant Line.");
			curr=NULL; return;
		    }
		    // evaluator should return 1 index access/scan node.
		    QueryEvaluationTreeNode *n = evaluator->getQueryEvalNode(newLine,queryInput);
		    QueryEvaluationTree *nt = new QueryEvaluationTree(n);
		    pattern[i] = evaluator->getExecTree(nt);
		    delete nt;

		    if (pattern[i] == NULL)
		    {
			globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"Evaluator",__FILE__,"Pattern cannot be NULL in UnivQuant Line.");
			curr=NULL; return;
		    }
		}


		char newLine[MAX_FILE_INTERFACE_LINE_SIZE];
		if (((std::iostream *)queryInput)->eof() == 0)
		    ((std::iostream *)queryInput)->getline(newLine,MAX_FILE_INTERFACE_LINE_SIZE);
		else
		{
		    globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"Evaluator",__FILE__,"Unexpected end of file in UnivQuant Line.");
		    curr=NULL; return;
		}
		QueryEvaluationTreeNode *oper = evaluator->getQueryEvalNode(newLine,queryInput);
		if (oper == NULL)
		{
		    globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"Evaluator",__FILE__,"Unexpected operand returned (NULL) in UnivQuant Line.");
		    curr=NULL; return;
		}
		curr = new QueryEvaluationTreeUnivQuantNode(oper,rootNRE, num, pattern, relation, cond);
	    }

