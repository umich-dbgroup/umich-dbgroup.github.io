/*
COPYRIGHT  � 2000-2004 
THE REGENTS OF THE UNIVERSITY OF MICHIGAN
ALL RIGHTS RESERVED

PERMISSION IS GRANTED TO USE, COPY, CREATE DERIVATIVE WORKS AND REDISTRIBUTE THIS SOFTWARE AND SUCH DERIVATIVE WORKS FOR 
NONCOMMERCIAL EDUCATION AND RESEARCH PURPOSES, SO LONG AS NO FEE IS CHARGED, AND SO LONG AS THE COPYRIGHT NOTICE ABOVE, 
THIS GRANT OF PERMISSION, AND THE DISCLAIMER BELOW APPEAR IN ALL COPIES MADE; AND SO LONG AS THE NAME OF THE UNIVERSITY 
OF MICHIGAN IS NOT USED IN ANY ADVERTISING OR PUBLICITY PERTAINING TO THE USE OR DISTRIBUTION OF THIS SOFTWARE WITHOUT 
SPECIFIC, WRITTEN PRIOR AUTHORIZATION.

THIS SOFTWARE IS PROVIDED AS IS, WITHOUT REPRESENTATION FROM THE UNIVERSITY OF MICHIGAN AS TO ITS FITNESS FOR ANY PURPOSE, 
AND WITHOUT WARRANTY BY THE UNIVERSITY OF MICHIGAN OF ANY KIND, EITHER EXPRESS OR IMPLIED, INCLUDING WITHOUT LIMITATION THE 
IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE. THE REGENTS OF THE UNIVERSITY OF MICHIGAN SHALL 
NOT BE LIABLE FOR ANY DAMAGES, INCLUDING SPECIAL, INDIRECT, INCIDENTAL, OR CONSEQUENTIAL DAMAGES, WITH RESPECT TO ANY CLAIM 
ARISING OUT OF OR IN CONNECTION WITH THE USE OF THE SOFTWARE, EVEN IF IT HAS BEEN OR IS HEREAFTER ADVISED OF THE POSSIBILITY 
OF SUCH DAMAGES.
*/


#ifndef QueryEvaluationTreeNode_H
#define QueryEvaluationTreeNode_H

#include "../Evaluator/Evaluator_definitions.h"
class EvaluatorClass;
class IteratorClass;
#include <stdio.h>
#include <string>

class QueryEvaluationTreeNode
{
public:
	QueryEvaluationTreeNode();
	virtual ~QueryEvaluationTreeNode();

	/*
	int getQueryEvaluationTreeNodeType();
	void setQueryEvaluationTreeNodeType(int type);
	*/
	

	void setNodeNumber(int num);
	void setCost(int cost);
	void setAccumulatedCost(int cost);
	void setOrderbyPosition(int pos);

	int getNodeNumber();
	int getCost();
	int getAccumulatedCost();
	int getOrderbyPosition();
	
//	virtual void printQueryEvaluationTreeNode(bool recursive, int depth = 0) {}
//	virtual char* toString() {return "";}
	virtual void deleteStructures() {};

	virtual void processQueryEvalNode(EvaluatorClass* evaluator,IteratorClass*& curr) = 0;
	virtual char getIdentifier(void) = 0;

private:
	int queryEvaluationTreeNodeType;

	// the following are  used for query plan generatation
	// the number of node in the subpattern after this join
	int nodeNumber;
	// the offset of the node, which the join result is ordered by, 
	// in the list of node in the result
	int orderbyPosition;
	// the cost of this join itself. (not include the cost of other
	// opertions which is descendant of this node in the query 
	// evaluation tree. 
	int cost;

	// the cost for the sub-evaluationtree, rooted at this noon
	int accumulatedCost;
};



#endif

