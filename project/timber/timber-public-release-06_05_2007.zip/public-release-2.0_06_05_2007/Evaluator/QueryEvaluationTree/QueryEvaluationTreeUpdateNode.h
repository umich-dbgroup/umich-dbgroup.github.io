#include "QueryEvaluationTreeNode.h"

#ifndef __QueryEvaluationTreeUpdateNode_H
#define __QueryEvaluationTreeUpdateNode_H
#include <timber-compat.h>



class QueryEvaluationTreeUpdateNode: public QueryEvaluationTreeNode
{
public:
	QueryEvaluationTreeUpdateNode(QueryEvaluationTreeNode* operand,
		int num, int *list);
	~QueryEvaluationTreeUpdateNode();

	int getNum();
	void setNum(int num);


	int *getList();
	void setList(int *list);

	QueryEvaluationTreeNode *getOperand();
	void setOperand(QueryEvaluationTreeNode* operand);
	void deleteStructures();

private:
	QueryEvaluationTreeNode* operand;
	int num;
	int *list;
};


#endif
