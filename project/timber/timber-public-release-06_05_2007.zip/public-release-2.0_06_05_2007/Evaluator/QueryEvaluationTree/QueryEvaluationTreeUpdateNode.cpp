#include "QueryEvaluationTreeUpdateNode.h"

QueryEvaluationTreeUpdateNode::QueryEvaluationTreeUpdateNode(
					QueryEvaluationTreeNode* operand,int num, int *list)
: QueryEvaluationTreeNode(EVALUATION_OP_UPDATE)
{
	this->operand = operand;
	this->num = num;
	this->list = list;
}

QueryEvaluationTreeUpdateNode::~QueryEvaluationTreeUpdateNode()
{
	if (operand)
		delete operand;
	if (list)
		delete [] list;
}

int QueryEvaluationTreeUpdateNode::getNum()
{
	return this->num;
}

void QueryEvaluationTreeUpdateNode::setNum(int num)
{
	this->num = num;
}

int *QueryEvaluationTreeUpdateNode::getList()
{
	return this->list;
}

void QueryEvaluationTreeUpdateNode::setList(int *list)
{
	this->list= list;
}

QueryEvaluationTreeNode *QueryEvaluationTreeUpdateNode::getOperand()
{
	return this->operand;
}

void QueryEvaluationTreeUpdateNode::setOperand(QueryEvaluationTreeNode *operand)
{
	this->operand = operand;
}

void QueryEvaluationTreeUpdateNode::deleteStructures()
{
	operand->deleteStructures();
}
