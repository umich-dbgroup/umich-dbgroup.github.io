/*
COPYRIGHT  � 2000-2004 
THE REGENTS OF THE UNIVERSITY OF MICHIGAN
ALL RIGHTS RESERVED

PERMISSION IS GRANTED TO USE, COPY, CREATE DERIVATIVE WORKS AND REDISTRIBUTE THIS SOFTWARE AND SUCH DERIVATIVE WORKS FOR 
NONCOMMERCIAL EDUCATION AND RESEARCH PURPOSES, SO LONG AS NO FEE IS CHARGED, AND SO LONG AS THE COPYRIGHT NOTICE ABOVE, 
THIS GRANT OF PERMISSION, AND THE DISCLAIMER BELOW APPEAR IN ALL COPIES MADE; AND SO LONG AS THE NAME OF THE UNIVERSITY 
OF MICHIGAN IS NOT USED IN ANY ADVERTISING OR PUBLICITY PERTAINING TO THE USE OR DISTRIBUTION OF THIS SOFTWARE WITHOUT 
SPECIFIC, WRITTEN PRIOR AUTHORIZATION.

THIS SOFTWARE IS PROVIDED AS IS, WITHOUT REPRESENTATION FROM THE UNIVERSITY OF MICHIGAN AS TO ITS FITNESS FOR ANY PURPOSE, 
AND WITHOUT WARRANTY BY THE UNIVERSITY OF MICHIGAN OF ANY KIND, EITHER EXPRESS OR IMPLIED, INCLUDING WITHOUT LIMITATION THE 
IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE. THE REGENTS OF THE UNIVERSITY OF MICHIGAN SHALL 
NOT BE LIABLE FOR ANY DAMAGES, INCLUDING SPECIAL, INDIRECT, INCIDENTAL, OR CONSEQUENTIAL DAMAGES, WITH RESPECT TO ANY CLAIM 
ARISING OUT OF OR IN CONNECTION WITH THE USE OF THE SOFTWARE, EVEN IF IT HAS BEEN OR IS HEREAFTER ADVISED OF THE POSSIBILITY 
OF SUCH DAMAGES.
*/

#include "QueryEvaluationTreeStructuralNonBinJoinNode.h"

QueryEvaluationTreeStructuralNonBinJoinNode::QueryEvaluationTreeStructuralNonBinJoinNode(int num)
: QueryEvaluationTreeNode(EVALUATION_OP_STRUCTURALNONBINJOIN)
{
	this->num = num;
	operands = new QueryEvaluationTreeNode	*[num];
	positions = NULL;
	projectWhich = NULL;
	relationships = NULL;
}


QueryEvaluationTreeStructuralNonBinJoinNode::~QueryEvaluationTreeStructuralNonBinJoinNode()
{
	for (int i=0; i<num; i++)
		delete operands[i];
	delete [] operands;
	if (positions) delete [] positions;
	if (projectWhich) delete [] projectWhich;
	if (relationships) delete [] relationships;
}


int QueryEvaluationTreeStructuralNonBinJoinNode::getEstimatedDepth()
{
	return this->estimatedDepth;
}

int QueryEvaluationTreeStructuralNonBinJoinNode::getNum()
{
	return this->num;
}

QueryEvaluationTreeNode	*QueryEvaluationTreeStructuralNonBinJoinNode::getOperand(int index)
{
	if (index >= num)
		return NULL;
	return operands[index];
}

QueryEvaluationTreeNode	**QueryEvaluationTreeStructuralNonBinJoinNode::getOperands()
{
	return operands;
}

int *QueryEvaluationTreeStructuralNonBinJoinNode::getPositions()
{
	return positions;
}

int *QueryEvaluationTreeStructuralNonBinJoinNode::getRelationships()
{
	return relationships;
}

bool *QueryEvaluationTreeStructuralNonBinJoinNode::getProjectWhich()
{
	return projectWhich;
}

void QueryEvaluationTreeStructuralNonBinJoinNode::setEstimatedDepth(int estimatedDepth)
{
	this->estimatedDepth = estimatedDepth;
}

void QueryEvaluationTreeStructuralNonBinJoinNode::setRelationships(int *relationships)
{
	if (this->relationships)
		delete this->relationships;
	this->relationships = relationships;
}

void QueryEvaluationTreeStructuralNonBinJoinNode::setPositions(int *positions)
{
	if (this->positions)
		delete this->positions;
	this->positions = positions;
}

void QueryEvaluationTreeStructuralNonBinJoinNode::setProjectWhich(bool *projectWhich)
{
	if (this->projectWhich)
		delete this->projectWhich;
	this->projectWhich = projectWhich;
}

void QueryEvaluationTreeStructuralNonBinJoinNode::setOperand(int index, QueryEvaluationTreeNode *operand)
{
	if (index >= num)
		return;
	operands[index] = operand;
}

void QueryEvaluationTreeStructuralNonBinJoinNode::setOperands(QueryEvaluationTreeNode **operands)
{
	for (int i=0; i<num; i++)
		setOperand(i,operands[i]);
}

void QueryEvaluationTreeStructuralNonBinJoinNode::deleteStructures()
{
	for (int i=0; i<num; i++)
		operands[i]->deleteStructures();
}
