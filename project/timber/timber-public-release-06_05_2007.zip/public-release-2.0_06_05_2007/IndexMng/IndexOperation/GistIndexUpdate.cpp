/*
COPYRIGHT  (c) 2000-2004 
THE REGENTS OF THE UNIVERSITY OF MICHIGAN
ALL RIGHTS RESERVED

PERMISSION IS GRANTED TO USE, COPY, CREATE DERIVATIVE WORKS AND
REDISTRIBUTE THIS SOFTWARE AND SUCH DERIVATIVE WORKS FOR NONCOMMERCIAL
EDUCATION AND RESEARCH PURPOSES, SO LONG AS NO FEE IS CHARGED, AND SO LONG
AS THE COPYRIGHT NOTICE ABOVE, THIS GRANT OF PERMISSION, AND THE
DISCLAIMER BELOW APPEAR IN ALL COPIES MADE; AND SO LONG AS THE NAME OF THE
UNIVERSITY OF MICHIGAN IS NOT USED IN ANY ADVERTISING OR PUBLICITY
PERTAINING TO THE USE OR DISTRIBUTION OF THIS SOFTWARE WITHOUT SPECIFIC,
WRITTEN PRIOR AUTHORIZATION.

THIS SOFTWARE IS PROVIDED AS IS, WITHOUT REPRESENTATION FROM THE
UNIVERSITY OF MICHIGAN AS TO ITS FITNESS FOR ANY PURPOSE, AND WITHOUT
WARRANTY BY THE UNIVERSITY OF MICHIGAN OF ANY KIND, EITHER EXPRESS OR
IMPLIED, INCLUDING WITHOUT LIMITATION THE IMPLIED WARRANTIES OF
MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE. THE REGENTS OF THE
UNIVERSITY OF MICHIGAN SHALL NOT BE LIABLE FOR ANY DAMAGES, INCLUDING
SPECIAL, INDIRECT, INCIDENTAL, OR CONSEQUENTIAL DAMAGES, WITH RESPECT TO
ANY CLAIM ARISING OUT OF OR IN CONNECTION WITH THE USE OF THE SOFTWARE,
EVEN IF IT HAS BEEN OR IS HEREAFTER ADVISED OF THE POSSIBILITY OF SUCH
DAMAGES.
*/

#include "GistIndexUpdate.h"

/**
* GistIndexUpdate
* Gist B-tree indices manipulation
*/

/**
* Constructor
* Initialize index
*
* @param indexName Name of the index
* @param gistIndexType Index type in gist extension format
* @param indexType Type of index
* @param keySize The size of the index key
*/
GistIndexUpdate::GistIndexUpdate(char *indexName,
		gist_ext_t *gistIndexType, int indexType, int keySize)
{
	this->indexName  = indexName;
	index = NULL;

	this->keySize = keySize;
	recordNumber = 0;
	this->indexType = indexType;
	this->gistIndexType = gistIndexType;
}

/**
* Destructor
*/
GistIndexUpdate::~GistIndexUpdate()
{
	if (index)
		delete index;
}

/**
* Create a new index
*/
rc_tGist 
GistIndexUpdate::create()
{
	rc_tGist ret;

	index = new gist;
	ret = index->create(indexName,gistIndexType);
	if (ret != RCOKGist)
	{
		globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"GistIndexUpdate::create",__FILE__,"After creating B-tree Gist");
	}
	recordNumber = 0;
	return ret;
}

/**
* Open existing index for operations
*/
rc_tGist 
GistIndexUpdate::open()
{
	rc_tGist ret;

	index = new gist;
	ret = index->open(indexName);
	if (ret != RCOKGist)
	{
		globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"GistIndexUpdate::open",__FILE__,"After opening B-tree Gist");
	}
	return ret;
}

/**
* Insert <key,data> pair to the index
*
* @param insertedKey Key to be inserted
* @param insertedData Data to be inserted in ListNode type
*/
rc_tGist 
GistIndexUpdate::insert(void *insertedKey,ListNode *insertedData)
{
	rc_tGist ret;
	recordNumber++;

	//if it is string, need to measure real length from the key
	if (indexType == STRING_INDEX)
		ret = index->insert(insertedKey, (int)(strlen((char *)insertedKey))+1,
				(void *)insertedData,
				sizeof(ListNode));
	else
		ret = index->insert(insertedKey,keySize,(void *)insertedData,sizeof(ListNode));

	if (ret != RCOKGist) 
	{
		globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"GistIndexUpdate::insert",__FILE__,"After inserting record to B-tree Gist");
	}
	return ret;
}

/**
*Yunyao: 10/19/2004, added to support term expansion (build tagName - stdTagName index)
*
* Insert <key,data> pair to the index, 
*
* @param insertedKey Key to be inserted in string type
* @param insertedData Data to be inserted in string type
* 
* correspnding to gist type by_str_str_ext
*/
rc_tGist 
GistIndexUpdate::insert(char * insertedKey,char * insertedData)
{
	rc_tGist ret;
	recordNumber++;

	ret = index->insert((void *)insertedKey, (int)(strlen((char *)insertedKey))+1,
			(void *)insertedData, 
			(int)(strlen((char *)insertedData)) + 1);

	if (ret != RCOKGist) {
		globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"GistIndexUpdate::insert",__FILE__,"After inserting record to B-tree Gist");
	}
	return ret;
}

/**
*Yunyao: 04/26/2005, added to support term expansion (build tagName - stdTagName index)
*
* Insert <key,data> pair to the index, 
*
* @param insertedKey Key to be inserted in string type
* @param insertedData Data to be inserted in int type
* 
* correspnding to gist type by_str_str_ext
*/
rc_tGist 
GistIndexUpdate::insert(char * insertedKey,int insertedData)
{
	rc_tGist ret;
	recordNumber++;

	ret = index->insert((void *)insertedKey, (int)(strlen((char *)insertedKey))+1,
			(void *)&insertedData, sizeof(int));

	if (ret != RCOKGist) {
		globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"GistIndexUpdate::insert",__FILE__,"After inserting record to B-tree Gist");
	}
	return ret;
}

/**
*Yunyao: 04/27/2005, added to support term expansion (build tagName - stdTagName index)
*
* Insert <key,data> pair to the index, 
*
* @param insertedKey Key to be inserted in string type
* @param insertedData bitset to be inserted in int type
* 
* correspnding to gist type by_str_str_ext
*/
rc_tGist 
GistIndexUpdate::insert(KeyType * insertedKey,void * insertedData, int size)
{
	rc_tGist ret;
	recordNumber++;

	ret = index->insert((void *)insertedKey, (int)sizeof(double), insertedData, size);

	if (ret != RCOKGist) {
		globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"GistIndexUpdate::insert",__FILE__,"After inserting record to B-tree Gist");
	}
	return ret;
}

/**
*Yunyao: 10/19/2004, added to support term expansion (build tagName - stdTagName index)
*
*@param gist_query_t: given a query type of gist, return if there are entries for that query
*/

bool 
GistIndexUpdate::entryNotExist(gist_query_t *query)
{
	bool eof = false;
	gist_cursor_t cursor;
	cursor.k = 0;
	cursor.io = 0;
	cursor.query = NULL;
	cursor.ext = NULL;
	cursor.cext = NULL;
	cursor.iter = NULL;
	cursor.state = NULL;
	unsigned long keysz;  
	unsigned long datasz;
	char *fetchedString = NULL;
	void *str = NULL;

	rc_tGist ret;

	ret = index->fetch_init(cursor, query);

	if (ret != RCOKGist) {
		globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"GistIndexUpdate::insert",__FILE__,"After inserting record to B-tree Gist");
	}

	ret = index->fetch(cursor,fetchedString, keysz, str, datasz, eof);

	if (ret != RCOKGist) {
		globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"GistIndexUpdate::insert",__FILE__,"After inserting record to B-tree Gist");
	}

	if (fetchedString)
		delete [] fetchedString;

	if (str)
		delete [] (char*) str;

	return eof;
}

/**
*Yunyao: 10/19/2004, added to support term expansion (build tagName - stdTagName index)
*
*@param gist_query_t: given a query type of gist, return the number of entries for that query
*/

int 
GistIndexUpdate::count(gist_query_t *query)
{
	return index->count(query);
}

/**
* Delete 
* Given a query type of gist, remove that entry
*/
rc_tGist 
GistIndexUpdate::del(gist_query_t *query)
{
	rc_tGist ret;

	ret = index->remove(query);
	if (ret != RCOKGist)
	{
		globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"GistIndexUpdate::del",__FILE__,"After removing B-tree Gist record");
	}
	return ret;
}

/**
* Get number of records in the indices inserted in this session
*/
int 
GistIndexUpdate::getRecordNumber()
{
	return recordNumber;
}

/**
* Close an index
*/
void 
GistIndexUpdate::close()
{
	(void)index->close();
}

