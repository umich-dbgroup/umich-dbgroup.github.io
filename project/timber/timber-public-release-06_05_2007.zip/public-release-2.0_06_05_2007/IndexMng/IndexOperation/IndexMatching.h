/*
COPYRIGHT  (c) 2000-2004 
THE REGENTS OF THE UNIVERSITY OF MICHIGAN
ALL RIGHTS RESERVED

PERMISSION IS GRANTED TO USE, COPY, CREATE DERIVATIVE WORKS AND
REDISTRIBUTE THIS SOFTWARE AND SUCH DERIVATIVE WORKS FOR NONCOMMERCIAL
EDUCATION AND RESEARCH PURPOSES, SO LONG AS NO FEE IS CHARGED, AND SO LONG
AS THE COPYRIGHT NOTICE ABOVE, THIS GRANT OF PERMISSION, AND THE
DISCLAIMER BELOW APPEAR IN ALL COPIES MADE; AND SO LONG AS THE NAME OF THE
UNIVERSITY OF MICHIGAN IS NOT USED IN ANY ADVERTISING OR PUBLICITY
PERTAINING TO THE USE OR DISTRIBUTION OF THIS SOFTWARE WITHOUT SPECIFIC,
WRITTEN PRIOR AUTHORIZATION.

THIS SOFTWARE IS PROVIDED AS IS, WITHOUT REPRESENTATION FROM THE
UNIVERSITY OF MICHIGAN AS TO ITS FITNESS FOR ANY PURPOSE, AND WITHOUT
WARRANTY BY THE UNIVERSITY OF MICHIGAN OF ANY KIND, EITHER EXPRESS OR
IMPLIED, INCLUDING WITHOUT LIMITATION THE IMPLIED WARRANTIES OF
MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE. THE REGENTS OF THE
UNIVERSITY OF MICHIGAN SHALL NOT BE LIABLE FOR ANY DAMAGES, INCLUDING
SPECIAL, INDIRECT, INCIDENTAL, OR CONSEQUENTIAL DAMAGES, WITH RESPECT TO
ANY CLAIM ARISING OUT OF OR IN CONNECTION WITH THE USE OF THE SOFTWARE,
EVEN IF IT HAS BEEN OR IS HEREAFTER ADVISED OF THE POSSIBILITY OF SUCH
DAMAGES.
*/

#ifndef __IndexMatching_H
#define __IndexMatching_H
#include <timber-compat.h>

#include "../IndexMng/IndexMng.h"
#include "../Common/IndexMatchingType.h"
#include "../Common/IndexCombination.h"
#include <map>
#include <list>
#include <set>
using std::list;

typedef std::list<IndexCombination*> IndexCombSet;

/**
* This class is for Index Matching
* 
* This class try to match index created with condition specified
* currently only either full match or superset match
*
* @author Rushi Dasai et al
* @author Nuwee Wiwatwattana 
* @version 1.0
*/
class IndexMatching
{
public:

	/**
	* Default Constructor
	*/
	IndexMatching(IndexMng* indexMng);

	/**
	* Default Destructor
	*/
	~IndexMatching(void) {};

	/*
	* Process Method
	*
	* Match each conjunctive condition
	*
	* Find a set of combination of index that match particular conjunctive condition.
	* Process is classified by the type of the node in the selection condition.
	* In each type, we try to find either an index or combination of them that can fully answer
	* or partially answer the query (conjunct). For partial match, the filtering conditions
	* that need to be further apply on are also given in each combination information.
	*
	* @param fileName The name of the XML document
	* @param nodeType The node type of the selection condition
	* @param conj Conjunctive condition break down from disjunctive conditions
	* @param icFullSet Index Combination Set that can fully answer this conjunctive condition (return value)
	* @param icPartialSet Index Combination Set that can partially answer this conjunctive condition (return value)
	* @returns Whether it has any errors
	*/
	int matchIndex(char* fileName, int nodeType, ConjunctiveCondition* conj, IndexCombSet& icFullSet, IndexCombSet& icPartialSet);

	/**
	* Process Method
	*
	* Match join index
	*
	* @param fileName The name of the xml file to find the corresponding index
	* @param leftSide Value of a left side (key side) that the index built on
	* @param leftSideType Type of a left side (key side) that the index built on see IndexMng_definitions.h
	* @param rightSide Value of a right side (return side) that the index built on
	* @param rightSideType Type of a right side (return side) that the index built on see IndexMng_definitions.h
	* @param iMatchInfo Index Matching Type of the join index matched, NULL otherwise (return value)
	* @return Whether it has any errors.
	*/
	int matchJoinIndex(char* fileName, char* leftSide, int leftSideType, char* rightSide, int rightSideType, IndexMatchingType*& iMatchInfo);

	/**
	* Process Method
	*
	* Find condtions left from a given join index
	*
	* @param indexName The name of the join index file
	* @param indexInfo The index info type of the join index (optional, can provide only indexName)
	* @param cond Conditions given to be filtered
	* @param condLeft Conjunctive condition left from the join index (return value)
	* @return Whether it has any errors.
	*/
	int conditionLeftFromJoinIndex(char* indexName, IndexInfoType* indexInfo, ConjunctiveCondition* cond, ConjunctiveCondition*& condLeft);

private:

	PhysicalDataMng* pDataMng;
	lvid_t volumeID;
	IndexMng* indexMng;

	/*
	* Internal Method
	*
	* Match text index for text node type in the selection condition
	* This can only match VALUEINDEX_TEXTVALUE
	* @param fileName The name of the XML document
	* @param conjunct Conjunctive condition
	* @param icFullSet The index combination set that can fully answer the given conjunctive condition (return value)
	* @returns Whether there is an error
	*/
	int matchTextIndex(char *fileName, ConjunctiveCondition* conjunct, IndexCombSet& icFullSet);

	/*
	* Internal Method
	*
	* Match element index for element node type in the selection condition
	* This can only match VALUEINDEX_ELEMENTCONTENT and VALUEINDEX_ELEMENTTAG
	* @param fileName The name of the XML document
	* @param conjunct Conjunctive condition
	* @param icFullSet The index combination set that can fully answer the given conjunctive condition (return value)
	* @param icPartialSet The index combination set that can partially answer the given conjunctive condition (return value)
	* @returns Whether there is an error
	*/
	int matchElementIndex(char *fileName,ConjunctiveCondition* conjunct, IndexCombSet& icSet, IndexCombSet& icPartialSet);

	/*
	* Internal Method
	*
	* Match attribute index for attribute node type in the selection condition
	* This can only match VALUEINDEX_ATTRIBUTECONTENT, VALUEINDEX_ATTRIBUTENAME and VALUEINDEX_ATTRIBUTEVALUE
	* @param fileName The name of the XML document
	* @param conjunct Conjunctive condition
	* @param icFullSet The index combination set that can fully answer the given conjunctive condition (return value)
	* @param icPartialSet The index combination set that can partially answer the given conjunctive condition (return value)
	* @returns Whether there is an error
	*/
	int matchAttributeIndex(char *fileName, ConjunctiveCondition* conjunct, IndexCombSet& icSet, IndexCombSet& icPartialSet) ;


	/*
	* Internal Method
	*
	* For each predicate in the conjunct, determine whether any 4 indexes built on attribute exist and
	* could be able to answer, put that in the  position-determined array
	* [0] for ATTRNAME, [1] for ATTRVALUE, [2] for ATTRCONTENT, [3] for ATTRNAME_ID_PAIR
	* without having to care whether it is a partial or full match.
	* @param fileName The name of the XML document
	* @param ccond A conjunctive condition to find the covering
	* @param L An array vector of size equals to number of conjuncts, 
	*		    each contains an array size 4 of indexMatchingType for ATTRNAME,ATTRVALUE,ATTRCONTENT,,ATTRCONTENT,ATTRNAME_ID_PAIR index 
	*/
	void findCoveringIndexes(char* fileName, ConjunctiveCondition* ccond, std::vector<IndexMatchingType** > &L);

	/*
	* Internal Method
	*
	* Generate valid combination of indices and leave-up filter for partial match, 
	* 2^size[conjunct] are possible. (Recursive Function)
	* @param bitmap The bitmap vector to control the generation
	* @param L The vector of an array of IndexMatchingType covering indexes found
	* @param ccond A conjunctive condition on working
	* @param icFullSet The index combination set that can fully answer this conjunct  (return value)
	* @param icPartialSet The index combination set that can partially answer this conjunct (return value)
	* @param i Current value of the round
	* @param imt_list List of IndexmatchingType matched the predicates
	* @param pc_list List of filter need to be applied on for partial match
	*/
	void generateCombination(unsigned int	bitmap,	
		std::vector<IndexMatchingType**>& L,
		ConjunctiveCondition	*ccond,
		IndexCombSet& icFullSet,
		IndexCombSet& icPartialSet,
		unsigned int	i,
		std::list<IndexMatchingType*>  *imt_list,
		std::list<PredicateCondition*> *pc_list 
		);

	//bool isDominated(std::map<IndexMatchingType*,	std::set<PredicateCondition*> >& L, IndexCombination	*c);*/
};

/*
* Utility Function
*
* Given the Index combination set 
* Try to append one more to the set by retaining uniqueness
*
* @param icSet Pointer to the set of pointer to IndexMatchingType
* @param ic New IndexCombination to be appened to, if unique
*/
void push_back_unique(IndexCombSet &icSet, IndexCombination *ic);

/*
* Utility Function
*
* Given the list of Index Matching Type
* Try to append one more to the list by retaining uniqueness
*
* @param imt_list Pointer to the list of pointer to IndexMatchingType
* @param imt New IndexMatchingType to be appened to, if unique
*/
void push_back_unique(list<IndexMatchingType*>  *imt_list,  IndexMatchingType *imt);
#endif
