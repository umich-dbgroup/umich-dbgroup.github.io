/*
COPYRIGHT  (c) 2000-2004 
THE REGENTS OF THE UNIVERSITY OF MICHIGAN
ALL RIGHTS RESERVED

PERMISSION IS GRANTED TO USE, COPY, CREATE DERIVATIVE WORKS AND
REDISTRIBUTE THIS SOFTWARE AND SUCH DERIVATIVE WORKS FOR NONCOMMERCIAL
EDUCATION AND RESEARCH PURPOSES, SO LONG AS NO FEE IS CHARGED, AND SO LONG
AS THE COPYRIGHT NOTICE ABOVE, THIS GRANT OF PERMISSION, AND THE
DISCLAIMER BELOW APPEAR IN ALL COPIES MADE; AND SO LONG AS THE NAME OF THE
UNIVERSITY OF MICHIGAN IS NOT USED IN ANY ADVERTISING OR PUBLICITY
PERTAINING TO THE USE OR DISTRIBUTION OF THIS SOFTWARE WITHOUT SPECIFIC,
WRITTEN PRIOR AUTHORIZATION.

THIS SOFTWARE IS PROVIDED AS IS, WITHOUT REPRESENTATION FROM THE
UNIVERSITY OF MICHIGAN AS TO ITS FITNESS FOR ANY PURPOSE, AND WITHOUT
WARRANTY BY THE UNIVERSITY OF MICHIGAN OF ANY KIND, EITHER EXPRESS OR
IMPLIED, INCLUDING WITHOUT LIMITATION THE IMPLIED WARRANTIES OF
MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE. THE REGENTS OF THE
UNIVERSITY OF MICHIGAN SHALL NOT BE LIABLE FOR ANY DAMAGES, INCLUDING
SPECIAL, INDIRECT, INCIDENTAL, OR CONSEQUENTIAL DAMAGES, WITH RESPECT TO
ANY CLAIM ARISING OUT OF OR IN CONNECTION WITH THE USE OF THE SOFTWARE,
EVEN IF IT HAS BEEN OR IS HEREAFTER ADVISED OF THE POSSIBILITY OF SUCH
DAMAGES.
*/

#ifndef __IndexIncrementalUpdate_H
#define __IndexIncrementalUpdate_H
#include <timber-compat.h>

#include "../IndexMng/IndexMng.h"

/**
* This class is for Index Incremental Update
* 
* This class update available indices given a particular type of update.
* currently parent index, inverted index, join index not support
*
* @author Nuwee Wiwatwattana 
* @version 1.0
*/
class IndexIncrementalUpdate
{
public:
	/**
	* Default Constructor
	*/
	IndexIncrementalUpdate(IndexMng* idxMng);

	/**
	* Default Destructor
	*/
	~IndexIncrementalUpdate(void);

	/**
	* Process Method
	*
	* Perform relevant incremental index update in case of node deletion
	* Node can be element or text or attribute node.
	*
	* @param fileinfo The file info type of the xml file to perform incremental index update
	* @param parentNode The data node pointer of the parent
	* @param nodeToDelete The data node pointer of the node to be deleted
	* @return Whether it has any errors.
	*/
	bool nodeDeletion(FileInfoType* fileinfo, DM_ElementNode* parentNode, DM_DataNode* nodeToDelete);

	/**
	* Process Method
	*
	* Perform relevant incremental index update in case of node deletion
	* Node can be element or text or attribute node.
	*
	* @param fileinfo The file info type of the xml file to perform incremental index update
	* @param parentKey The key of the parent node
	* @param nodeToDelete The data node pointer of the node to be deleted
	* @return Whether it has any errors.
	*/
	bool nodeDeletion(FileInfoType* fileinfo, KeyType parentKey, DM_DataNode* nodeToDelete); 

	/**
	* Process Method
	*
	* Perform relevant incremental index update in case of node insertion
	* Node can be element or text or attribute
	*
	* @param fileinfo The file info type of the xml file to perform incremental index update
	* @param parentNode The data node pointer of the parent
	* @param nodeToInsert The data node pointer of the node to be inserted
	* @return Whether it has any errors.
	*/
	bool nodeInsertion(FileInfoType* fileinfo, DM_ElementNode* parentNode, DM_DataNode* nodeToInsert);

	/**
	* Process Method
	*
	* Perform relevant incremental index update in case of node insertion
	* Node can be element or text or attribute
	*
	* @param fileinfo The file info type of the xml file to perform incremental index update
	* @param parentKey The parent key
	* @param nodeToInsert The data node pointer of the node to be inserted
	* @return Whether it has any errors.
	*/
	bool nodeInsertion(FileInfoType* fileinfo, KeyType parentKey, DM_DataNode* nodeToInsert);

	/**
	* Process Method
	*
	* Perform relevant incremental index update in case of attribute deletion
	*
	* @param fileinfo The file info type of the xml file to perform incremental index update
	* @param parentNode The data node pointer of the parent
	* @param attributeKey The attribute key of that to be deleted its attribute name, data
	* @param attributeName The string contains attributename to be deleted
	* @param attributeValue The value of the attribute value to be deleted in Value type
	* @return Whether it has any errors.
	*/
	bool attributeDeletion(FileInfoType* fileinfo, DM_ElementNode* parentNode, KeyType attributeKey,
		char* attributeName, Value* attributeValue);

	/**
	* Process Method
	*
	* Perform relevant incremental index update in case of attribute insertion
	*
	* @param fileinfo The file info type of the xml file to perform incremental index update
	* @param parentNode The data node pointer of the parent
	* @param attributeKey The attribute key of that to be inserted its attribute name, data
	* @param attributeName The string contains attributename to be inserted
	* @param attributeValue The value of the attribute value to be inserted in Value type
	* @return Whether it has any errors.
	*/
	bool attributeInsertion(FileInfoType* fileinfo, DM_ElementNode* parentNode, KeyType attributeKey,
		char* attributeName, Value* attributeValue);

	/**
	* Process Method
	*
	* Perform relevant incremental index update in case of attribute value modification of a particular attribute name
	*
	* @param fileinfo The file info type of the xml file to perform incremental index update
	* @param parentNode The data node pointer of the parent
	* @param attributeKey The attribute key of that to be modified its attribute value
	* @param attributeName The string contains attributename
	* @param oldAttributeValue The old value of the attribute value
	* @param newAttributeValue The new value of the attribute value
	* @return Whether it has any errors.
	*/
	bool attributeValueModification(FileInfoType* fileinfo, DM_ElementNode* parentNode, KeyType attributeKey, char* attributeName,
		Value* oldAttributeValue, Value* newAttributeValue);

	/**
	* Process Method
	*
	* Perform relevant incremental index update in case of attribute value deletion of a particular attribute name
	* Only the value of the atribute is deleted, the attribute name and attribute node is still present.
	*
	* @param fileinfo The file info type of the xml file to perform incremental index update
	* @param parentNode The data node pointer of the parent
	* @param attributeKey The attribute key of that to be modified its attribute value
	* @param attributeName The string contains attributename
	* @param oldAttributeValue The old value of the attribute value
	* @return Whether it has any errors.
	*/
	bool attributeValueDeletion(FileInfoType* fileinfo, DM_ElementNode* parentNode, KeyType attributeKey,
		char* attributeName, Value* oldAttributeValue);

	/**
	* Process Method
	*
	* Perform relevant incremental index update in case of key (start, end, level) modification
	* Node can be element, text or attribute node
	*
	* @param fileinfo The file info type of the xml file to perform incremental index update
	* @param oldNode The data node pointer of the node to change its key(s)
	* @param newStartKey The anew start key to be changed to
	* @param newEndKey The new end key
	* @param newLevel The new level value
	* @return Whether it has any errors.
	*/
	bool keyModification(FileInfoType* fileinfo, DM_DataNode* oldNode, KeyType newStartKey, KeyType newEndKey,short newLevel);

private:

	IndexMng* indexMng;

	/**
	* Object pointer to gist index
	*/
	gist *index;

	/**
	* Object pointer to updatable tagname id, or attribute name id
	*/
	TagNameAndNodeIdIndex* tagIdIndex;

	/**
	* The name of the index with path
	*/
	char indexNamePath[MAX_INDEX_NAME_LENGTH];

	//--------Node Deletion---------//
	/**
	* Process Method
	*
	* Perform relevant incremental index update in case of element node deletion
	*
	* @param fileinfo The file info type of the xml file to perform incremental index update
	* @param nodeToDelete The data node pointer of the node to be deleted
	* @return Whether it has any errors.
	*/
	bool elementNodeDeletion(FileInfoType* fileinfo, DM_ElementNode* nodeToDelete);

	/**
	* Process Method
	*
	* Perform relevant incremental index update in case of text node deletion
	*
	* @param fileinfo The file info type of the xml file to perform incremental index update
	* @param parentNode The data node pointer of the parent
	* @param parentKey The key of the parent node (if parentNode = null, use this to get data node)
	* @param nodeToDelete The data node pointer of the node to be deleted
	* @return Whether it has any errors.
	*/
	bool textNodeDeletion(FileInfoType* fileinfo,  DM_ElementNode* parentNode, KeyType parentKey, DM_TextNode* nodeToDelete);

	/**
	* Process Method
	*
	* Perform relevant incremental index update in case of attribute node deletion
	*
	* @param fileinfo The file info type of the xml file to perform incremental index update
	* @param parentNode The data node pointer of the parent
	* @param parentKey The key of the parent node (if parentNode = null, use this to get data node)
	* @param nodeToDelete The data node pointer of the node to be deleted
	* @return Whether it has any errors.
	*/
	bool attributeNodeDeletion(FileInfoType* fileinfo,  DM_ElementNode* parentNode, KeyType parentKey, DM_AttributeNode* nodeToDelete);

	//--------Node Insertion---------//
	/**
	* Process Method
	*
	* Perform relevant incremental index update in case of element node insertion
	*
	* @param fileinfo The file info type of the xml file to perform incremental index update
	* @param nodeToInsert The data node pointer of the node to be inserted
	* @return Whether it has any errors.
	*/
	bool elementNodeInsertion(FileInfoType* fileinfo, DM_ElementNode* nodeToInsert);

	/**
	* Process Method
	*
	* Perform relevant incremental index update in case of text node insertion
	*
	* @param fileinfo The file info type of the xml file to perform incremental index update
	* @param parentNode The data node pointer of the parent
	* @param parentKey The parent key (if parentNode = NULL, use this to get parentNode)
	* @param nodeToInsert The data node pointer of the node to be inserted
	* @return Whether it has any errors.
	*/
	bool textNodeInsertion(FileInfoType* fileinfo, DM_ElementNode* parentNode, KeyType parentKey, DM_TextNode* nodeToInsert);

	/**
	* Process Method
	*
	* Perform relevant incremental index update in case of attribute node insertion
	*
	* @param fileinfo The file info type of the xml file to perform incremental index update
	* @param parentNode The data node pointer of the parent
	* @param parentKey The parent key (if parentNode = NULL, use this to get parentNode)
	* @param nodeToInsert The data node pointer of the node to be inserted
	* @return Whether it has any errors.
	*/
	bool attributeNodeInsertion(FileInfoType* fileinfo, DM_ElementNode* parentNode, KeyType parentKey, DM_AttributeNode* nodeToInsert);

	//--------Key Modification---------//

	/**
	* Process Method
	*
	* Perform relevant incremental index update in case of key (start, end, level) modification on element node
	*
	* @param fileinfo The file info type of the xml file to perform incremental index update
	* @param oldNode The data node pointer of the node to change its key(s)
	* @param newStartKey The anew start key to be changed to
	* @param newEndKey The new end key
	* @param newLevel The new level value
	* @return Whether it has any errors.
	*/
	bool keyElementNodeModification(FileInfoType* fileinfo, DM_ElementNode* oldNode, KeyType newStartKey, KeyType newEndKey, short newLevel);

	/**
	* Process Method
	*
	* Perform relevant incremental index update in case of key (start, end, level) modification on text node
	*
	* @param fileinfo The file info type of the xml file to perform incremental index update
	* @param oldNode The data node pointer of the node to change its key(s)
	* @param newStartKey The anew start key to be changed to
	* @param newEndKey The new end key
	* @param newLevel The new level value
	* @return Whether it has any errors.
	*/
	bool keyTextNodeModification(FileInfoType* fileinfo, DM_TextNode* oldNode, KeyType newStartKey, KeyType newEndKey, short newLevel);

	/**
	* Process Method
	*
	* Perform relevant incremental index update in case of key (start, end, level) modification on attribute node
	*
	* @param fileinfo The file info type of the xml file to perform incremental index update
	* @param oldNode The data node pointer of the node to change its key(s)
	* @param newStartKey The anew start key to be changed to
	* @param newEndKey The new end key
	* @param newLevel The new level value
	* @return Whether it has any errors.
	*/
	bool keyAttributeNodeModification(FileInfoType* fileinfo, DM_AttributeNode* oldNode, KeyType newStartKey, KeyType newEndKey, short newLevel);
};

#endif

