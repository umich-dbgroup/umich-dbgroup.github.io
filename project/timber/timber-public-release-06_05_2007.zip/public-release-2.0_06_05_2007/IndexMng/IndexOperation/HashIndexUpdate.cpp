/*
COPYRIGHT  (c) 2000-2004 
THE REGENTS OF THE UNIVERSITY OF MICHIGAN
ALL RIGHTS RESERVED

PERMISSION IS GRANTED TO USE, COPY, CREATE DERIVATIVE WORKS AND
REDISTRIBUTE THIS SOFTWARE AND SUCH DERIVATIVE WORKS FOR NONCOMMERCIAL
EDUCATION AND RESEARCH PURPOSES, SO LONG AS NO FEE IS CHARGED, AND SO LONG
AS THE COPYRIGHT NOTICE ABOVE, THIS GRANT OF PERMISSION, AND THE
DISCLAIMER BELOW APPEAR IN ALL COPIES MADE; AND SO LONG AS THE NAME OF THE
UNIVERSITY OF MICHIGAN IS NOT USED IN ANY ADVERTISING OR PUBLICITY
PERTAINING TO THE USE OR DISTRIBUTION OF THIS SOFTWARE WITHOUT SPECIFIC,
WRITTEN PRIOR AUTHORIZATION.

THIS SOFTWARE IS PROVIDED AS IS, WITHOUT REPRESENTATION FROM THE
UNIVERSITY OF MICHIGAN AS TO ITS FITNESS FOR ANY PURPOSE, AND WITHOUT
WARRANTY BY THE UNIVERSITY OF MICHIGAN OF ANY KIND, EITHER EXPRESS OR
IMPLIED, INCLUDING WITHOUT LIMITATION THE IMPLIED WARRANTIES OF
MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE. THE REGENTS OF THE
UNIVERSITY OF MICHIGAN SHALL NOT BE LIABLE FOR ANY DAMAGES, INCLUDING
SPECIAL, INDIRECT, INCIDENTAL, OR CONSEQUENTIAL DAMAGES, WITH RESPECT TO
ANY CLAIM ARISING OUT OF OR IN CONNECTION WITH THE USE OF THE SOFTWARE,
EVEN IF IT HAS BEEN OR IS HEREAFTER ADVISED OF THE POSSIBILITY OF SUCH
DAMAGES.
*/

#include "HashIndexUpdate.h"

/**
* HashIndexUpdate
* 
* This class provides hash indices manipulation
* 
* @version 1.0
*/

/**
* Constructor
*
* @param indexName The name of the index
* @param indexType The tpye of the index (int, float, string)
*/
HashIndexUpdate::HashIndexUpdate(char *indexName,int indexType)
{
	char indexNameWithPath[MAX_INDEX_NAME_LENGTH];

	// append path with the indexname
	strcpy(indexNameWithPath,gSettings->getStringValue("GIST_DEFAULT_FILEPATH").c_str());
	strcat(indexNameWithPath,indexName);

	this->indexName = new char[strlen(indexName)+1];
	strcpy(this->indexName,indexName);

	//set key size
	if (indexType == INT_INDEX)
		this->keySize = sizeof(int);
	else if (indexType == FLOAT_INDEX)
		this->keySize = sizeof(float);
	else
		this->keySize = sizeof(double);

	this->dataSize = sizeof(double) + sizeof(double) + sizeof(int) +sizeof(int);
	this->recSize = this->keySize + this->dataSize;
	buffer = new char[recSize];
	this->contMaxSize = cont.GetSize();
	indexFile = fopen(indexNameWithPath,"wb");
	char *tableFileName = new char[strlen(indexNameWithPath) + 5];
	strcpy(tableFileName,indexNameWithPath);
	strcat(tableFileName,".tab"); //hash index has extension .tab


	rangeTableFile = fopen(tableFileName,"wb");
	fseek(rangeTableFile,sizeof(int),0);

	//index instead of table
	//	this->rangeIndex = new gist;
	//rangeIndex->create(tableFileName,&bt_dbl_ext);

	delete [] tableFileName;
	numRanges = 0;
	this->recordNumber = 0;
}

/**
* Destructor
*/
HashIndexUpdate::~HashIndexUpdate()
{
	delete [] indexName;
	delete [] buffer;
	//	delete rangeIndex;
}

void HashIndexUpdate::create()
{
	this->recordNumber = 0;
}

void HashIndexUpdate::open()
{
	this->recordNumber = 0;
}


/**
* Insert <key,data> pair to the index
*
* @param insertedKey Key to be inserted
* @param insertedData Data to be inserted in ListNode type
* @returns Error code
*/
int HashIndexUpdate::insert(void *insertedKey,ListNode insertedData)
{
	memcpy(buffer,insertedKey,keySize);
	memcpy(buffer+keySize,&insertedData,dataSize);
	if (cont.AddData(buffer,recSize) == FAILURE)
	{
		if (writeContainer() == FAILURE)
			return FAILURE;
		if (writeRange(insertedKey) == FAILURE)
			return FAILURE;
		if (cont.AddData(buffer,recSize) == FAILURE)
			return FAILURE;
	}

	this->recordNumber++;
	return SUCCESS;
}

/**
* Get number of records in the indices inserted in this session
* 
* @returns Number of records
*/
int HashIndexUpdate::getRecordNumber()
{
	return recordNumber;
}

/**
* Close an index
*
* @param Error code
*/
int HashIndexUpdate::close()
{
	if (!(cont.IsEmpty()))
		if (writeContainer() == FAILURE)
			return FAILURE;
	fclose(indexFile);

	fseek(rangeTableFile,0,0);
	if (fwrite(&numRanges,1,sizeof(int),rangeTableFile) < sizeof(int))
	{
		//printf("error in writing number of ranges in close method in HashIndexUpdate...\n");
		globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"HashIndexUpdate::close",__FILE__,"Size is wrong");
		return FAILURE;
	}
	fclose(rangeTableFile);
	//rangeIndex->close();
	return SUCCESS;
}

/**
* write Container
*
* @param Error code
*/
int HashIndexUpdate::writeContainer()
{
	int addCursor = cont.GetAddCursor();
	if (fwrite(&addCursor,1,sizeof(int),indexFile) < sizeof(int))
	{
		//printf("error in writing container size in writeContainer method in HashIndexUpdate...\n");
		globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"HashIndexUpdate::writeContainer",__FILE__,"Size is wrong");
		return FAILURE;
	}
	if ( (int)fwrite(cont.GetContainer(),1,this->contMaxSize,indexFile) < this->contMaxSize)
	{
		//printf("error in writing container in writeContainer method in HashIndexUpdate...\n");
		globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"HashIndexUpdate::writeContainer",__FILE__,"Max Size is wrong");
		return FAILURE;
	}
	cont.Initialize();
	return SUCCESS;
}

/**
* write Range 
*
* @param startRange The start of the range
* @param Error code
*/
int HashIndexUpdate::writeRange(void *startRange)
{
	if ( (int)fwrite(startRange,1,keySize,rangeTableFile) < keySize)
	{
		//printf("error in writing range in writeRange method in HashIndexUpdate...\n");
		globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"HashIndexUpdate::writeRange",__FILE__,"Key Size is wrong");
		return FAILURE;
	}
	numRanges++;

	//(void)rangeIndex->insert(insertedKey,keySize,(void *)insertedData,sizeof(ListNode));
	return SUCCESS;
}
