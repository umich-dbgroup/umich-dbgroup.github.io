/*
COPYRIGHT  (c) 2000-2004 
THE REGENTS OF THE UNIVERSITY OF MICHIGAN
ALL RIGHTS RESERVED

PERMISSION IS GRANTED TO USE, COPY, CREATE DERIVATIVE WORKS AND
REDISTRIBUTE THIS SOFTWARE AND SUCH DERIVATIVE WORKS FOR NONCOMMERCIAL
EDUCATION AND RESEARCH PURPOSES, SO LONG AS NO FEE IS CHARGED, AND SO LONG
AS THE COPYRIGHT NOTICE ABOVE, THIS GRANT OF PERMISSION, AND THE
DISCLAIMER BELOW APPEAR IN ALL COPIES MADE; AND SO LONG AS THE NAME OF THE
UNIVERSITY OF MICHIGAN IS NOT USED IN ANY ADVERTISING OR PUBLICITY
PERTAINING TO THE USE OR DISTRIBUTION OF THIS SOFTWARE WITHOUT SPECIFIC,
WRITTEN PRIOR AUTHORIZATION.

THIS SOFTWARE IS PROVIDED AS IS, WITHOUT REPRESENTATION FROM THE
UNIVERSITY OF MICHIGAN AS TO ITS FITNESS FOR ANY PURPOSE, AND WITHOUT
WARRANTY BY THE UNIVERSITY OF MICHIGAN OF ANY KIND, EITHER EXPRESS OR
IMPLIED, INCLUDING WITHOUT LIMITATION THE IMPLIED WARRANTIES OF
MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE. THE REGENTS OF THE
UNIVERSITY OF MICHIGAN SHALL NOT BE LIABLE FOR ANY DAMAGES, INCLUDING
SPECIAL, INDIRECT, INCIDENTAL, OR CONSEQUENTIAL DAMAGES, WITH RESPECT TO
ANY CLAIM ARISING OUT OF OR IN CONNECTION WITH THE USE OF THE SOFTWARE,
EVEN IF IT HAS BEEN OR IS HEREAFTER ADVISED OF THE POSSIBILITY OF SUCH
DAMAGES.
*/

#ifndef __GistIndexUpdate_h
#define __GistIndexUpdate_h
#include <timber-compat.h>


#include "gist.h"
#include "gist_btree.h"
#include "gist_cursor.h"
#include <bitset>

#include "../Common/ListNode.h"
class gist;

/**
* GistIndexUpdate
* Gist B-tree indices manipulation
*/
class GistIndexUpdate
{
public:

	/**
	* Constructor
	* Initialize index
	*
	* @param indexName Name of the index
	* @param gistIndexType Index type in gist extension format
	* @param indexType Type of index
	* @param keySize The size of the index key
	*/
	GistIndexUpdate(char *indexName,gist_ext_t *gistIndexType, int indexType, int keySize) ;
	/**
	* Destructor
	*/
	~GistIndexUpdate() ;

	/**
	* Create a new index
	*/
	rc_tGist create() ;

	/**
	* Open existing index for operations
	*/
	rc_tGist open() ;

	/**
	* Insert <key,data> pair to the index
	*
	* @param insertedKey Key to be inserted
	* @param insertedData Data to be inserted in ListNode type
	*/
	rc_tGist insert(void *insertedKey,ListNode *insertedData) ;

	/**
	*Yunyao: 10/19/2004, added to support term expansion (build tagName - stdTagName index)
	*
	* Insert <key,data> pair to the index, 
	*
	* @param insertedKey Key to be inserted in string type
	* @param insertedData Data to be inserted in string type
	* 
	* correspnding to gist type by_str_str_ext
	*/
	rc_tGist insert(char * insertedKey,char * insertedData) ;

	/**
	*Yunyao: 04/26/2005, added to support term expansion (build tagName - stdTagName index)
	*
	* Insert <key,data> pair to the index, 
	*
	* @param insertedKey Key to be inserted in string type
	* @param insertedData Data to be inserted in int type
	* 
	* correspnding to gist type by_str_str_ext
	*/
	rc_tGist insert(char * insertedKey,int insertedData) ;

	/**
	*Yunyao: 04/27/2005, added to support term expansion (build tagName - stdTagName index)
	*
	* Insert <key,data> pair to the index, 
	*
	* @param insertedKey Key to be inserted in string type
	* @param insertedData bitset to be inserted in int type
	* 
	* correspnding to gist type by_str_str_ext
	*/
	rc_tGist insert(KeyType * insertedKey,void * insertedData, int size) ;

	/**
	*Yunyao: 10/19/2004, added to support term expansion (build tagName - stdTagName index)
	*
	*@param gist_query_t: given a query type of gist, return if there are entries for that query
	*/

	bool entryNotExist(gist_query_t *query) ;

	/**
	*Yunyao: 10/19/2004, added to support term expansion (build tagName - stdTagName index)
	*
	*@param gist_query_t: given a query type of gist, return the number of entries for that query
	*/

	int count(gist_query_t *query) ;

	/**
	* Delete 
	* Given a query type of gist, remove that entry
	*/
	rc_tGist del(gist_query_t *query) ;

	/**
	* Get number of records in the indices inserted in this session
	*/
	int getRecordNumber() ;

	/**
	* Close an index
	*/
	void close() ;

private:
	char *indexName;
	gist *index;
	gist_ext_t *gistIndexType;
	int indexType;
	int recordNumber;
	int keySize;
};

#endif

