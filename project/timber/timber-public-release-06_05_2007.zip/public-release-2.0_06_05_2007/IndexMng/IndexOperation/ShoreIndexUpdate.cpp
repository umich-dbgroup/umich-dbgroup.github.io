/*
COPYRIGHT  (c) 2000-2004 
THE REGENTS OF THE UNIVERSITY OF MICHIGAN
ALL RIGHTS RESERVED

PERMISSION IS GRANTED TO USE, COPY, CREATE DERIVATIVE WORKS AND
REDISTRIBUTE THIS SOFTWARE AND SUCH DERIVATIVE WORKS FOR NONCOMMERCIAL
EDUCATION AND RESEARCH PURPOSES, SO LONG AS NO FEE IS CHARGED, AND SO LONG
AS THE COPYRIGHT NOTICE ABOVE, THIS GRANT OF PERMISSION, AND THE
DISCLAIMER BELOW APPEAR IN ALL COPIES MADE; AND SO LONG AS THE NAME OF THE
UNIVERSITY OF MICHIGAN IS NOT USED IN ANY ADVERTISING OR PUBLICITY
PERTAINING TO THE USE OR DISTRIBUTION OF THIS SOFTWARE WITHOUT SPECIFIC,
WRITTEN PRIOR AUTHORIZATION.

THIS SOFTWARE IS PROVIDED AS IS, WITHOUT REPRESENTATION FROM THE
UNIVERSITY OF MICHIGAN AS TO ITS FITNESS FOR ANY PURPOSE, AND WITHOUT
WARRANTY BY THE UNIVERSITY OF MICHIGAN OF ANY KIND, EITHER EXPRESS OR
IMPLIED, INCLUDING WITHOUT LIMITATION THE IMPLIED WARRANTIES OF
MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE. THE REGENTS OF THE
UNIVERSITY OF MICHIGAN SHALL NOT BE LIABLE FOR ANY DAMAGES, INCLUDING
SPECIAL, INDIRECT, INCIDENTAL, OR CONSEQUENTIAL DAMAGES, WITH RESPECT TO
ANY CLAIM ARISING OUT OF OR IN CONNECTION WITH THE USE OF THE SOFTWARE,
EVEN IF IT HAS BEEN OR IS HEREAFTER ADVISED OF THE POSSIBILITY OF SUCH
DAMAGES.
*/

/**
* IndexUpdate
* 
* This class provides shore b-tree indices manipulation
* 
* @version 1.0
*/

#include "ShoreIndexUpdate.h"

/**
* Constructor
*
* @param volume_id The volume id
* @param index_type The tpye of the index (int, float, string)
* @param indexkey_size The size of the key
*/
ShoreIndexUpdate::ShoreIndexUpdate(lvid_t volume_id,		
						 int index_type,
						 int indexkey_size)
{
	this->volumeID = volume_id;
	this->indexType = index_type;

	switch (this->indexType)
	{
	case INT_INDEX:
		this->keySize = sizeof(int);
		break;

	case FLOAT_INDEX:
		this->keySize = sizeof(float);
		break;

	case DOUBLE_INDEX:
		this->keySize = sizeof(double);
		break;

	case STRING_INDEX:
		this->keySize = indexkey_size;
		break;

	default: 
		break;
	}

	this->bodySize = sizeof(ListNode);

}

/**
* Create an index
*/
rc_t ShoreIndexUpdate::create()
{
	rc_t rc;

	switch (this->indexType)
	{
	case INT_INDEX:
		rc = ss_m::create_index(this->volumeID, 
			ss_m::t_btree, 
			ss_m::t_regular,
			"i4", 0, indexID);
		if (rc)
		{
			globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"IndexUpdate::create",__FILE__,"After create an index");
			return rc;
		}
		break;

	case FLOAT_INDEX:
		rc = ss_m::create_index(this->volumeID, 
			ss_m::t_btree, 
			ss_m::t_regular,
			"f4", 0, indexID);
		if (rc)
		{
			globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"IndexUpdate::create",__FILE__,"After create an index");
			return rc;
		}
		break;

	case DOUBLE_INDEX:
		rc = ss_m::create_index(this->volumeID, 
			ss_m::t_btree, 
			ss_m::t_regular,
			"f8", 0, indexID);
		if (rc)
		{
			globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"IndexUpdate::create",__FILE__,"After create an index");
			return rc;
		}
		break;

	case STRING_INDEX:
		{	
			char index_t[10] = "b*";
			char size[10];
			itoa(this->keySize, size, 10);
			strcpy(index_t+2, size);

			//strcpy(index_t+2, "f4");

			rc = ss_m::create_index(this->volumeID, 
				ss_m::t_btree, 
				ss_m::t_regular,
				index_t, 0, indexID);
			if (rc)
			{
				globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"IndexUpdate::create",__FILE__,"After create an index");
				return rc;
			}
			break;
		}

	default: break;
	}

	this->recordNumber = 0;
	return rc;
}

/**
* Set the current index
*
* @param index_id The index id
*/
void ShoreIndexUpdate::open(serial_t index_id)
{
	this->indexID = index_id;
}

/**
* Insert <key,data> pair to the index
*
* @param index_key Key to be inserted
* @param index_body Data to be inserted in ListNode type
*/
rc_t ShoreIndexUpdate::insert(void* index_key, ListNode* index_body)
{
	vec_t* key = NULL;

	switch (this->indexType)
	{
	case INT_INDEX:
		key = new vec_t(index_key, this->keySize);
		break;

	case STRING_INDEX:
		{
			int size = strlen((char*) index_key);

			key = new vec_t(index_key, size);
			break;
		}

	default:
		{
			globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"IndexUpdate::insert",__FILE__,"Illegal index type");
		}
	}

	vec_t data(index_body, this->bodySize);  

	rc_t rc = ss_m::create_assoc(this->volumeID,
		this->indexID,
		*key,
		data);
	if (rc) 
	{
		globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"IndexUpdate::insert",__FILE__,"After insert key/data to an index");
		return rc;				
	}

	this->recordNumber++;
	return rc;
}

/**
* Get the current index id
*
* @returns The index id
*/
serial_t ShoreIndexUpdate::getIndexID()
{
	return this->indexID;
}

/**
* Get number of records in the indices inserted in this session
* 
* @returns Number of records
*/
int ShoreIndexUpdate::getRecordNumber()
{
	return this->recordNumber;
}
