/*
COPYRIGHT  (c) 2000-2004 
THE REGENTS OF THE UNIVERSITY OF MICHIGAN
ALL RIGHTS RESERVED

PERMISSION IS GRANTED TO USE, COPY, CREATE DERIVATIVE WORKS AND
REDISTRIBUTE THIS SOFTWARE AND SUCH DERIVATIVE WORKS FOR NONCOMMERCIAL
EDUCATION AND RESEARCH PURPOSES, SO LONG AS NO FEE IS CHARGED, AND SO LONG
AS THE COPYRIGHT NOTICE ABOVE, THIS GRANT OF PERMISSION, AND THE
DISCLAIMER BELOW APPEAR IN ALL COPIES MADE; AND SO LONG AS THE NAME OF THE
UNIVERSITY OF MICHIGAN IS NOT USED IN ANY ADVERTISING OR PUBLICITY
PERTAINING TO THE USE OR DISTRIBUTION OF THIS SOFTWARE WITHOUT SPECIFIC,
WRITTEN PRIOR AUTHORIZATION.

THIS SOFTWARE IS PROVIDED AS IS, WITHOUT REPRESENTATION FROM THE
UNIVERSITY OF MICHIGAN AS TO ITS FITNESS FOR ANY PURPOSE, AND WITHOUT
WARRANTY BY THE UNIVERSITY OF MICHIGAN OF ANY KIND, EITHER EXPRESS OR
IMPLIED, INCLUDING WITHOUT LIMITATION THE IMPLIED WARRANTIES OF
MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE. THE REGENTS OF THE
UNIVERSITY OF MICHIGAN SHALL NOT BE LIABLE FOR ANY DAMAGES, INCLUDING
SPECIAL, INDIRECT, INCIDENTAL, OR CONSEQUENTIAL DAMAGES, WITH RESPECT TO
ANY CLAIM ARISING OUT OF OR IN CONNECTION WITH THE USE OF THE SOFTWARE,
EVEN IF IT HAS BEEN OR IS HEREAFTER ADVISED OF THE POSSIBILITY OF SUCH
DAMAGES.
*/


#include <string>
#include <fstream>
#include "IndexMatchingType.h"
#include "IndexCombination.h"
#include <float.h>
#include <math.h>
#include <string>
#include <iostream>
#include "../IndexOperation/GistIndexUpdate.h"

using namespace std;
class gist;
/**
* IndexMatchingType
* 
* This class is a defined type that holds the index name
* its type and description, the min and max key for scan index purpose
* Also, it tells you which selectionCondition need to be filtered out later
*
* @see IndexMatching
* 
* @author Rushi Dasai et al
* @version 1.0
*/

/*
* Default Constructor
*/
IndexMatchingType::IndexMatchingType()
{
	minkey = NULL;
	maxkey = NULL;
	strcpy(indexName,"\0");
	indexType = 0;
	indexDescription = 0;
	indexSource = 0;
	isUpdatable = false;
	isValueIndex = false;
}


/*
* Constructor
*
* Given a full information provided
*
* @param iName Index Name
* @param iType Index type string, int, float, etc.
* @param iDescription Type of index e.g. elementtag, attributecontent index
* @param iSource The source of index e.g. gist or shore
* @param mCond The condition on this IndexMatching Type
* @param mink Min  value yey
* @param maxk Max value key
*/
IndexMatchingType::IndexMatchingType(const char *iName,
									 int iType,
									 int iDescription,
									 int iSource,
									 bool iUpdatable,
									 bool iValueIndex,
									 Value *mink,
									 Value *maxk)
{
	strcpy(indexName, iName);
	indexType = iType;
	indexDescription = iDescription;
	indexSource = iSource;
	isUpdatable = iUpdatable;
	isValueIndex = iValueIndex;
	if (mink != NULL)
		minkey = new Value(mink);
	else minkey = NULL;

	if (maxk != NULL)
		maxkey = new Value(maxk);
	else maxkey = NULL;
}

/*
* Copy Constructor
*/
IndexMatchingType::IndexMatchingType(IndexMatchingType* im)
{
	this->indexDescription = im->indexDescription;
	strcpy(this->indexName,im->indexName);
	this->indexType = im->indexType;
	this->indexSource = im->indexSource;
	this->isUpdatable = im->isUpdatable;
	this->isValueIndex = im->isValueIndex;
	this->maxkey = new Value(im->maxkey);
	this->minkey = new Value(im->minkey);
}



/*
* Default Destructor
*/
IndexMatchingType::~IndexMatchingType()
{
	if (minkey) delete minkey;
	if (maxkey) delete maxkey;
	minkey = NULL;
	maxkey = NULL;
}

/*
* Debug purpose
* 
* Print Index Matching Type properties
* -Index name, minkey and maxkey
* @param out std output stream
* @imt IndexMatchingType instance itself
*/
std::ostream& operator<<(std::ostream &out, IndexMatchingType& imt)
{
	imt.print(out);
	return out;
}

/*
* Internal Method
*
* Print IndexMatchingType info
* @param out std output stream
*/
void IndexMatchingType::print(std::ostream &out)
{

		out << "IndexName: " << this->indexName << endl;
		out << "IndexType: " << this->indexType << endl;
		out << "IndexDescription: " << this->indexDescription << endl;
		out << "IndexSource: " << this->indexSource << endl;
		out << "Updatable?: " << this->isUpdatable << endl;
		out << "Is Value Index?: " << this->isValueIndex << endl;
		out << "MinKey: " ;
		if (this->minkey->getValueType() == INT_VALUE) 
			out << this->minkey->getIntValue();
		else if (this->minkey->getValueType() == REAL_VALUE)
			out << this->minkey->getRealValue();
		else out << this->minkey->getStrValue();
		out << endl;
		out << "MaxKey: ";
		if (this->maxkey->getValueType() == INT_VALUE) 
			out << this->maxkey->getIntValue();
		else if (this->maxkey->getValueType() == REAL_VALUE)
			out << this->maxkey->getRealValue();
		else out << this->maxkey->getStrValue();
		out << endl;
}

/*
* Constructor
*
* @param iInfo Index Info Type
* @param pCond Predicate Conditions that this has been matched
*/
IndexMatchingType::IndexMatchingType(IndexInfoType *iInfo, PredicateCondition *pCond)
{
	strcpy(indexName, iInfo->indexName);
	indexType = iInfo->indexType;
	indexDescription = iInfo->indexDescription;
	indexSource = iInfo->indexSource;
	isUpdatable = iInfo->isUpdatable;

	int valueType;
	Value *minlimit, *maxlimit;
	minlimit = new Value;
	maxlimit = new Value;

	switch (indexDescription) {
		case VALUEINDEX_TEXTVALUE:
			isValueIndex = true;
			break;
		case VALUEINDEX_ATTRIBUTEVALUE:
			isValueIndex = true;
			break;
		case VALUEINDEX_ELEMENTCONTENT:
			isValueIndex = true;
			break;
		case VALUEINDEX_ATTRIBUTECONTENT:
			isValueIndex = true;
			break;
		default:
			isValueIndex = false;
			break;
	}
	//assign default min and max for each value type
	switch (indexType) {
	case INT_INDEX:
		valueType = INT_VALUE;
		minlimit->setValueType(valueType);
		minlimit->setIntValue(INT_MIN);
		maxlimit->setValueType(valueType);
		maxlimit->setIntValue(INT_MAX);
		break;
	case FLOAT_INDEX:
		valueType = REAL_VALUE;
		minlimit->setValueType(valueType);
		minlimit->setRealValue(FLT_MIN);
		maxlimit->setValueType(valueType);
		maxlimit->setRealValue(FLT_MAX);
		break;
	case DOUBLE_INDEX:
		valueType = REAL_VALUE;
		minlimit->setValueType(valueType);
		minlimit->setRealValue(DBL_MIN);
		maxlimit->setValueType(valueType);
		maxlimit->setRealValue(DBL_MAX);
		break;
	default: // STRING_INDEX:
		valueType = STRING_VALUE;
		minlimit->setValueType(valueType);
		minlimit->setStrValue(" ");
		maxlimit->setValueType(valueType);
		maxlimit->setStrValue("~");
		break;
	}

	switch (pCond->getOperator()) {
	case VALUE_COMP_OP_LT:
		//get the most greatest number less than this right value
		if (indexType == INT_INDEX)
		{
			int limit = INT_MAX;
			if (pCond->getRightValue()->getValueType() == INT_VALUE) {
				limit = pCond->getRightValue()->getIntValue();
				limit = limit - 1;
			}
			else if (pCond->getRightValue()->getValueType() == REAL_VALUE) {
				limit = (int)pCond->getRightValue()->getRealValue();
				//e.g. 10.4 -> 10 -> 10
				//e.g. 10.6 -> 11 -> 10
				//note that even this if you built index not direct to type, 
				//this may still be incorrect, because the precision is distorted when stored in index
				if ((double)limit > pCond->getRightValue()->getRealValue()) {
					//was fold up, need to minus
					limit = limit - 1;
				}
				//if fold down, it's already less than what endpoint is
			}
			maxkey = new Value(INT_VALUE);
			maxkey->setIntValue(limit);
		}
		else if ((indexType == FLOAT_INDEX) ||
			(indexType == DOUBLE_INDEX))
		{
			double limit = DBL_MAX;
			// Comment: do not work
			////convert to real value for correct precision in retrieving index
			if (pCond->getRightValue()->getValueType() == INT_VALUE) {
				limit = static_cast<double>(pCond->getRightValue()->getIntValue());
				//limit = limit - 0.000000000000001;
			}
			else if (pCond->getRightValue()->getValueType() == REAL_VALUE) {
				limit = pCond->getRightValue()->getRealValue();
				//limit = limit - 0.000000000000001;
			}
			gist* index;

			index = new gist();
			gist_cursor_t cursor;

			//get path from the settings file
			char indexNameWithPath[100];

			// append path with the indexname
			strcpy(indexNameWithPath,gSettings->getStringValue("GIST_DEFAULT_FILEPATH").c_str());
			strcat(indexNameWithPath,iInfo->indexName);

			index->open(indexNameWithPath);

			bt_query_t *qLT;
			// Awkwardly access index to get the greatest number less than this value
			if (indexType == FLOAT_INDEX)
				qLT = new bt_query_t(bt_query_t::bt_lt, new float((float)limit),NULL);
			else
				qLT = new bt_query_t(bt_query_t::bt_lt, new double(limit),NULL);

			//initialize the cursor

			cursor.k = 0;
			cursor.io = 0;
			cursor.query = NULL;
			cursor.ext = NULL;
			cursor.cext = NULL;
			cursor.iter = NULL;
			cursor.state = NULL;
			rc_tGist rc = index->fetch_init(cursor, qLT);
			if (rc)
			{
				globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"IndexMatchingType",__FILE__,"Problem with intializing fetching from index.");
				maxkey = new Value(pCond->getRightValue());
				minkey = new Value(minlimit);
				return;
			}

			float fetchedFloat = (float)limit;
			double fetchedDouble = limit;
			ListNode str;
			unsigned long keysz;  
			unsigned long datasz;
			bool eof = false;
			int foundLower = 0;

			while (!eof) {
				foundLower++;
				switch (indexType)
				{
				case FLOAT_INDEX:
					limit = (double)fetchedFloat;
					rc = index->fetch(cursor,&fetchedFloat,keysz,(void *)&str,datasz, eof);
					break;
				case DOUBLE_INDEX:
					limit = fetchedDouble;
					rc = index->fetch(cursor,&fetchedDouble,keysz,(void *)&str,datasz, eof);
					break;
				}
				if (rc)
				{
					globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"IndexMatchingType",__FILE__,"Problem in fetching data from index.");
					maxkey = new Value(pCond->getRightValue());
					minkey = new Value(minlimit);
					return;
				}
			}

			
			maxkey = new Value(REAL_VALUE);
			maxkey->setRealValue(limit);
			if (foundLower <= 1) maxkey->setRealValue(limit-1); //it's the lowest number or lower than what's stored

			delete qLT;
			index->close();
			delete index;
			
		}
		else { //string index, not expected
			maxkey = new Value(pCond->getRightValue());
		}
		minkey = new Value(minlimit);
		break;
	case VALUE_COMP_OP_LE:
		minkey = new Value(minlimit);
		maxkey = new Value(pCond->getRightValue());
		break;
	case VALUE_COMP_OP_GT:
		//get the most lowest number greater than this right value
		if (indexType == INT_INDEX)
		{
			int limit = INT_MIN;
			if (pCond->getRightValue()->getValueType() == INT_VALUE) {
				limit = pCond->getRightValue()->getIntValue();
				limit = limit + 1;
			}
			else if (pCond->getRightValue()->getValueType() == REAL_VALUE) {
				limit = (int)pCond->getRightValue()->getRealValue();
				//e.g. 10.4 -> 10 -> 11
				//e.g. 10.6 -> 11 -> 11
				//note that even this if you built index not direct to type, 
				//this may still be incorrect, because the precision is distorted when stored in index
				if ((double)limit < pCond->getRightValue()->getRealValue()) {
					//was fold down, need to plus
					limit = limit + 1;
				}
				//if fold up, it's already greater than what endpoint is
			}
			minkey = new Value(INT_VALUE);
			minkey->setIntValue(limit);
		}
		else if ((indexType == FLOAT_INDEX) ||
			(indexType == DOUBLE_INDEX))
		{
			double limit = DBL_MIN, limitpoint = DBL_MIN;

			//convert to real value for correct precision in retrieving index
			if (pCond->getRightValue()->getValueType() == INT_VALUE) {
				limit = static_cast<double>(pCond->getRightValue()->getIntValue());
				//limit = limit + 0.000000000000001;
			}
			else if (pCond->getRightValue()->getValueType() == REAL_VALUE) {
				limit = pCond->getRightValue()->getRealValue();
				//limit = limit + 0.000000000000001;
			}
			limitpoint = limit;
			// Awkwardly access index to get the lowest number greater than this value
			gist* index;

			index = new gist();
			gist_cursor_t cursor;

			//get path from the settings file
			char indexNameWithPath[100];

			// append path with the indexname
			strcpy(indexNameWithPath,gSettings->getStringValue("GIST_DEFAULT_FILEPATH").c_str());
			strcat(indexNameWithPath,iInfo->indexName);

			index->open(indexNameWithPath);

			bt_query_t *qGT;
			// Awkwardly access index to get the greatest number less than this value
			if (indexType == FLOAT_INDEX)
				qGT = new bt_query_t(bt_query_t::bt_gt, new float((float)limit),NULL);
			else
				qGT = new bt_query_t(bt_query_t::bt_gt, new double(limit),NULL);

			//initialize the cursor

			cursor.k = 0;
			cursor.io = 0;
			cursor.query = NULL;
			cursor.ext = NULL;
			cursor.cext = NULL;
			cursor.iter = NULL;
			cursor.state = NULL;
			rc_tGist rc = index->fetch_init(cursor, qGT);
			if (rc)
			{
				globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"IndexMatchingType",__FILE__,"Problem with intializing fetching from index.");
				minkey = new Value(pCond->getRightValue());
				maxkey = new Value(maxlimit);
				return;
			}

			float fetchedFloat = (float)limit;
			double fetchedDouble = limit;
			ListNode str;
			unsigned long keysz;  
			unsigned long datasz;
			bool eof = false, found = false;

			while(!eof)
			{
				switch (indexType)
				{
				case FLOAT_INDEX:
					rc = index->fetch(cursor,&fetchedFloat,keysz,(void *)&str,datasz, eof);
					limit = (double)fetchedFloat;
					
					break;
				case DOUBLE_INDEX:
					rc = index->fetch(cursor,&fetchedDouble,keysz,(void *)&str,datasz, eof);
					limit = fetchedDouble;
					break;
				}
				if (rc)
				{
					globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"IndexMatchingType",__FILE__,"Problem in fetching data from index.");
					minkey = new Value(pCond->getRightValue());
					maxkey = new Value(maxlimit);
					return;
				}
				if (limit > limitpoint) { //get the lowest number greater than, we do this b/c of potential duplicates
					//70 70 70 100, getting > 70 must go through index until passing stub of 70
					found = true;
					break;
				}
		}	

			
			minkey = new Value(REAL_VALUE);
			minkey->setRealValue(limit);
			if (!found) minkey->setRealValue(limitpoint+1); //it's the lowest number or lower than what's stored

			delete qGT;
			index->close();
			delete index;
		}
		else { //string index, not expected
			minkey = new Value(pCond->getRightValue());
		}
		maxkey = new Value(maxlimit);
		break;
	case VALUE_COMP_OP_GE:
		minkey = new Value(pCond->getRightValue());
		maxkey = new Value(maxlimit);			
		break;
	case VALUE_COMP_OP_NE:
	case VALUE_COMP_OP_EQ:
		minkey = new Value(pCond->getRightValue());
		maxkey = new Value(pCond->getRightValue());
	}
	delete minlimit;
	delete maxlimit;
}

/*
* Operator
*
* Compares whether two type instance are equal
* All properties of IndexMatching Type must match
*
* @param imt Another IndexMatchingType would like to compare wih
*/
bool IndexMatchingType::equals(IndexMatchingType &imt)
{
	return (strcmp(indexName, imt.indexName) == 0)
		&& indexType == imt.indexType
		&& indexDescription == imt.indexDescription
		&& indexSource == imt.indexSource
		&& isUpdatable == imt.isUpdatable
		&& isValueIndex == imt.isValueIndex
		&& minkey->getValueType() == imt.minkey->getValueType()
		&& maxkey->getValueType() == imt.maxkey->getValueType()
		&& minkey->compareValue(VALUE_COMP_OP_EQ, imt.minkey)
		&& maxkey->compareValue(VALUE_COMP_OP_EQ, imt.maxkey);
}

/*
* Default Destructor
*/
IndexCombination::~IndexCombination()
{
	for (list<IndexMatchingType*>::iterator it = (this->ilist).begin(); it != this->ilist.end(); ++it) {
		IndexMatchingType *cur = (*it);
		if (cur) delete cur;
		cur = NULL;
	}
	if (this->filter) delete this->filter;
	this->filter = NULL;
}

/*
* Operator
*
* Answer whether the given Index combination equals to self
* Two combination is equal iff each contains another
* @param ic2 Index Combination to be compared with
* @returns Whether it is equal
*/
bool IndexCombination::equals(const IndexCombination *ic2) const
{
	return this->contains(ic2) && ic2->contains(this);
}


/*
* Operator
* 
* Check whether an Index Combination contains in (is a subset)
* of another index Combination by comparing all the IndexMatchingType
* member, and filters.
*
* @param _ic2 The Index Combination to check the containment
* @returns Whether it contains in
*/
bool IndexCombination::contains(const IndexCombination *ic2) const
{

	//filter

	// for each ic1's IndexMatchingType list
	// check whether there is in ic2
	// ic1 (= ic2
	for (list<IndexMatchingType*>::const_iterator it1 = this->ilist.begin();
		it1 != this->ilist.end(); ++it1) {
			IndexMatchingType *imt1 = (*it1);
			bool flag = false;

			for (list<IndexMatchingType*>::const_iterator it2 = ic2->ilist.begin();
				it2 != ic2->ilist.end(); ++it2) {

					IndexMatchingType *imt2 = (*it2);

					if (imt1->equals(*imt2)) {
						flag = true;
						break;
					}
				}
				if (flag == false)
					return false;
		}

		// filter is a conjunctive condition
		// if ic1 has, ic2 also has the same number of filters
		if (this->filter) {
			if (!ic2->filter)
				return false;
			if (this->filter->getNumber() != ic2->filter->getNumber())
				return false;

			//for each filter in ic1
			// there must be equivalent filter in ic2
			for (int i = 0; i < this->filter->getNumber(); i++) {
				bool flag = false;
				for (int j = 0; j < ic2->filter->getNumber(); j++) {
					PredicateCondition *pc1 = this->filter->getCondAt(i);
					PredicateCondition *pc2 = ic2->filter->getCondAt(j);

					bool lflag;
					int lv1 = pc1->getLeftValue();
					int lv2 = pc2->getLeftValue();

					//condition not in the range of constants, means it's an attribute name 
					if ((lv1 < SCAN_LEFTVALUE_VALUE ||
						lv1 > SCAN_LEFTVALUE_ELEMENTCONTENT) && 
						(lv2 < SCAN_LEFTVALUE_VALUE ||
						lv2 > SCAN_LEFTVALUE_ELEMENTCONTENT))
					{
						lflag = strcmp((char*)lv1, (char*)lv2) == 0;
					}
					else
						lflag = lv1 == lv2; //check equality of conditions type

					// check operator and right value
					if (lflag
						&& pc1->getOperator() == pc2->getOperator()
						&& pc1->getRightValue()->compareValue(VALUE_COMP_OP_EQ, 
						pc2->getRightValue()))
					{
						flag = true;
						break;
					}

				}
				if (flag == false)
					return false;
			}
		}
		// if ic1 has no filter, but ic2 has filter
		else if (ic2->filter) {
				return false;
		}

		return true;
}

/**
* Debug Method
* Print the content of the indexCombination.
*/
void IndexCombination::print()
{
	cout << "------------Index Combination--------------" << endl;
	for (list<IndexMatchingType*>::iterator it = (this->ilist).begin(); it != this->ilist.end(); ++it) {
		IndexMatchingType *cur = (*it);
		cout << *cur;
		cout << "---------------------------" << endl;
	}

	cout << "Filter condition:";
	if (this->filter != NULL) this->filter->printConjunctiveCondition();
	else cout << "NONE" << endl;
}
