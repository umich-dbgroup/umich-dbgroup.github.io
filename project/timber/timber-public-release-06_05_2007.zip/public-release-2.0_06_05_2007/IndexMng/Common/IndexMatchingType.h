/*
COPYRIGHT  (c) 2000-2004 
THE REGENTS OF THE UNIVERSITY OF MICHIGAN
ALL RIGHTS RESERVED

PERMISSION IS GRANTED TO USE, COPY, CREATE DERIVATIVE WORKS AND
REDISTRIBUTE THIS SOFTWARE AND SUCH DERIVATIVE WORKS FOR NONCOMMERCIAL
EDUCATION AND RESEARCH PURPOSES, SO LONG AS NO FEE IS CHARGED, AND SO LONG
AS THE COPYRIGHT NOTICE ABOVE, THIS GRANT OF PERMISSION, AND THE
DISCLAIMER BELOW APPEAR IN ALL COPIES MADE; AND SO LONG AS THE NAME OF THE
UNIVERSITY OF MICHIGAN IS NOT USED IN ANY ADVERTISING OR PUBLICITY
PERTAINING TO THE USE OR DISTRIBUTION OF THIS SOFTWARE WITHOUT SPECIFIC,
WRITTEN PRIOR AUTHORIZATION.

THIS SOFTWARE IS PROVIDED AS IS, WITHOUT REPRESENTATION FROM THE
UNIVERSITY OF MICHIGAN AS TO ITS FITNESS FOR ANY PURPOSE, AND WITHOUT
WARRANTY BY THE UNIVERSITY OF MICHIGAN OF ANY KIND, EITHER EXPRESS OR
IMPLIED, INCLUDING WITHOUT LIMITATION THE IMPLIED WARRANTIES OF
MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE. THE REGENTS OF THE
UNIVERSITY OF MICHIGAN SHALL NOT BE LIABLE FOR ANY DAMAGES, INCLUDING
SPECIAL, INDIRECT, INCIDENTAL, OR CONSEQUENTIAL DAMAGES, WITH RESPECT TO
ANY CLAIM ARISING OUT OF OR IN CONNECTION WITH THE USE OF THE SOFTWARE,
EVEN IF IT HAS BEEN OR IS HEREAFTER ADVISED OF THE POSSIBILITY OF SUCH
DAMAGES.
*/

#ifndef __IndexMatchingType_H
#define __IndexMatchingType_H
#include <timber-compat.h>

#include "../../PhysicalDataMng/ScanInfo/SelectionCondition.h"
#include "../../XMLParser/TreeStructure/Value.h"
#include "IndexMng_definitions.h"
#include <list>
#include <fstream>

/**
* IndexMatchingType
* 
* This class is a defined type that holds the index name
* its type and description, the min and max key for scan index purpose
* Also, it tells you which selectionCondition need to be filtered out later
*
* @see IndexMatching
* 
* @author Rushi Dasai et al
* @version 1.0
*/

class IndexMatchingType {
public:

	char			    indexName[MAX_INDEX_NAME_LENGTH];
	int					indexType;
	int					indexDescription;
	int					indexSource; //shore or gist
	bool				isUpdatable; //updatable index?
	bool				isValueIndex; //is a value (content) index?
	Value*				minkey;
	Value*				maxkey;

	/*
	* Default Constructor
	*/
	IndexMatchingType();

	/*
	* Default Destructor
	*/
	~IndexMatchingType();

	/*
	* Internal Method
	*
	* Print IndexMatchingType info
	*/
	void print(std::ostream &out);

	/*
	* Constructor
	*
	* Given a full information provided
	*
	* @param iName Index Name
	* @param iType Index type string, int, float, etc.
	* @param iDescription Type of index e.g. elementtag, attributecontent index
	* @param iSource The source of index e.g. gist or shore
	* @param mink Min  value yey
	* @param maxk Max value key
	*/
	IndexMatchingType(const char *iName,
		int iType,
		int iDescription,
		int iSource,
		bool iUpdatable,
		bool iValueIndex,
		Value *mink = NULL,
		Value *maxk = NULL);

	/*
	* Constructor
	*
	* @param iInfo Index Info Type
	* @param pCond Predicate Conditions that this has been matched
	*/
	IndexMatchingType(IndexInfoType *iInfo, PredicateCondition *pCond);

	/*
	* Copy Constructor
	*/
	IndexMatchingType(IndexMatchingType* im);

	/*
	* Operator
	*
	* Compares whether two type instance are equal
	* All properties of IndexMatching Type must match
	*/
	bool equals(IndexMatchingType &imt);
};

/*
* Debug purpose
* 
* Print Index Matching Type properties
* -Index name, minkey and maxkey
*/
std::ostream& operator<<(std::ostream &out, IndexMatchingType& imt);

#endif

