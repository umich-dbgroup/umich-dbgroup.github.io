/*
COPYRIGHT  (c) 2000-2004 
THE REGENTS OF THE UNIVERSITY OF MICHIGAN
ALL RIGHTS RESERVED

PERMISSION IS GRANTED TO USE, COPY, CREATE DERIVATIVE WORKS AND
REDISTRIBUTE THIS SOFTWARE AND SUCH DERIVATIVE WORKS FOR NONCOMMERCIAL
EDUCATION AND RESEARCH PURPOSES, SO LONG AS NO FEE IS CHARGED, AND SO LONG
AS THE COPYRIGHT NOTICE ABOVE, THIS GRANT OF PERMISSION, AND THE
DISCLAIMER BELOW APPEAR IN ALL COPIES MADE; AND SO LONG AS THE NAME OF THE
UNIVERSITY OF MICHIGAN IS NOT USED IN ANY ADVERTISING OR PUBLICITY
PERTAINING TO THE USE OR DISTRIBUTION OF THIS SOFTWARE WITHOUT SPECIFIC,
WRITTEN PRIOR AUTHORIZATION.

THIS SOFTWARE IS PROVIDED AS IS, WITHOUT REPRESENTATION FROM THE
UNIVERSITY OF MICHIGAN AS TO ITS FITNESS FOR ANY PURPOSE, AND WITHOUT
WARRANTY BY THE UNIVERSITY OF MICHIGAN OF ANY KIND, EITHER EXPRESS OR
IMPLIED, INCLUDING WITHOUT LIMITATION THE IMPLIED WARRANTIES OF
MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE. THE REGENTS OF THE
UNIVERSITY OF MICHIGAN SHALL NOT BE LIABLE FOR ANY DAMAGES, INCLUDING
SPECIAL, INDIRECT, INCIDENTAL, OR CONSEQUENTIAL DAMAGES, WITH RESPECT TO
ANY CLAIM ARISING OUT OF OR IN CONNECTION WITH THE USE OF THE SOFTWARE,
EVEN IF IT HAS BEEN OR IS HEREAFTER ADVISED OF THE POSSIBILITY OF SUCH
DAMAGES.
*/

#ifndef __IndexCombination_H
#define __IndexCombination_H
#include <timber-compat.h>

#include <list>
#include "../../PhysicalDataMng/ScanInfo/ConjunctiveCondition.h"
#include "IndexMatchingType.h"

/**
* IndexCombination
* 
* 
* It is a list of IndexMatchingType that signify a particular
* combination that can (partially/fully) answer a predicate condition
* matchIndex returns a set of these
*
* @see IndexMatchingType
* @see IndexMatching
* 
* @author Rushi Dasai et al
* @version 1.0
*/
class IndexCombination {
public:

	/*
	* List of IndexMatchingType
	*/
	std::list<IndexMatchingType*> ilist;

	/*
	* Filter need to be applied to this list
	* to obtain the designated result
	*/
	ConjunctiveCondition *filter;

	/*
	* Default Constructor
	*/
	IndexCombination() {filter=NULL;}

	/*
	* Default Destructor
	*/
	~IndexCombination();

	/*
	* Operator
	*
	* Answer whether the given Index combination equals to self
	* Two combination is equal iff each contains another
	* @param ic2 Index Combination to be compared with
	* @returns Whether it is equal
	*/
	bool equals(const IndexCombination *ic2) const;

	/*
	* Operator
	* 
	* Check whether an Index Combination contains in (is a subset)
	* of another index Combination by comparing all the IndexMatchingType
	* member, and filters.
	*
	* @param _ic2 The Index Combination to check the containment
	* @returns Whether it contains in
	*/
	bool contains(const IndexCombination *ic2) const;

	/**
	* Debug Method
	* Print the content of the indexCombination.
	*/
	void print();
};


#endif // __ IndexCombination_H
