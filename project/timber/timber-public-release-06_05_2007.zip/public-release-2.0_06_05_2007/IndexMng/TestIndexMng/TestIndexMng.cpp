/*
COPYRIGHT  (c) 2000-2004 
THE REGENTS OF THE UNIVERSITY OF MICHIGAN
ALL RIGHTS RESERVED

PERMISSION IS GRANTED TO USE, COPY, CREATE DERIVATIVE WORKS AND
REDISTRIBUTE THIS SOFTWARE AND SUCH DERIVATIVE WORKS FOR NONCOMMERCIAL
EDUCATION AND RESEARCH PURPOSES, SO LONG AS NO FEE IS CHARGED, AND SO LONG
AS THE COPYRIGHT NOTICE ABOVE, THIS GRANT OF PERMISSION, AND THE
DISCLAIMER BELOW APPEAR IN ALL COPIES MADE; AND SO LONG AS THE NAME OF THE
UNIVERSITY OF MICHIGAN IS NOT USED IN ANY ADVERTISING OR PUBLICITY
PERTAINING TO THE USE OR DISTRIBUTION OF THIS SOFTWARE WITHOUT SPECIFIC,
WRITTEN PRIOR AUTHORIZATION.

THIS SOFTWARE IS PROVIDED AS IS, WITHOUT REPRESENTATION FROM THE
UNIVERSITY OF MICHIGAN AS TO ITS FITNESS FOR ANY PURPOSE, AND WITHOUT
WARRANTY BY THE UNIVERSITY OF MICHIGAN OF ANY KIND, EITHER EXPRESS OR
IMPLIED, INCLUDING WITHOUT LIMITATION THE IMPLIED WARRANTIES OF
MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE. THE REGENTS OF THE
UNIVERSITY OF MICHIGAN SHALL NOT BE LIABLE FOR ANY DAMAGES, INCLUDING
SPECIAL, INDIRECT, INCIDENTAL, OR CONSEQUENTIAL DAMAGES, WITH RESPECT TO
ANY CLAIM ARISING OUT OF OR IN CONNECTION WITH THE USE OF THE SOFTWARE,
EVEN IF IT HAS BEEN OR IS HEREAFTER ADVISED OF THE POSSIBILITY OF SUCH
DAMAGES.
*/

#include "TestIndexMng.h"

/**
* TestIndexMng
* 
* This class provide test cases as well as code examples for how to use the functionality provided
* in this IndexMng project. 
* 
* @author Nuwee Wiwatwattana
* @version 1.0
*/

/**
* Constructor
*/
TestIndexMng::TestIndexMng(IndexMng* iMng, char* filename)
{
	IndexMatching* iMatching = new IndexMatching(iMng);
	IndexCombSet icFullSet, icPartialSet;

	// Test 1 $elementtag = author
	//ConjunctiveCondition* conj = new ConjunctiveCondition(1);
	//Value* val1 = new Value(STRING_VALUE);
	//val1->setStrValue("author");
	//PredicateCondition* pred1 = new PredicateCondition(SCAN_LEFTVALUE_NODETAG,SCAN_OP_EQ,val1); 
	//conj->setCond(0,pred1);
	//iMatching->matchIndex(filename,ELEMENT_NODE,conj, icFullSet, icPartialSet);
	//cout << "Full match: " << icFullSet.size() << endl;
	//for (list<IndexCombination*>::const_iterator it = icFullSet.begin(); it != icFullSet.end(); ++it) {
	//	IndexCombination* ic = *it;
	//	ic->print();
	//}
	//cout << "Partial match: " << icPartialSet.size() << endl;
	//for (list<IndexCombination*>::const_iterator it = icPartialSet.begin(); it != icPartialSet.end(); ++it) {
	//	IndexCombination* ic = *it;
	//	ic->print();
	//}
	//for (IndexCombSet::iterator it = icFullSet.begin(); it != icFullSet.end(); ++it) {
	//	IndexCombination* ic = *it;
	//	delete ic;
	//}
	//for (IndexCombSet::iterator it = icPartialSet.begin(); it != icPartialSet.end(); ++it) {
	//	IndexCombination* ic = *it;
	//	delete ic;
	//}

	//Test 2 author=John Doe
	ConjunctiveCondition* conj = new ConjunctiveCondition(2);
	Value* val1 = new Value(STRING_VALUE);
	val1->setStrValue("author");
	PredicateCondition* pred1 = new PredicateCondition(SCAN_LEFTVALUE_NODETAG,SCAN_OP_EQ,val1); 
	conj->setCond(0,pred1);
	Value* val2 = new Value(STRING_VALUE);
	val2->setStrValue("John Doe");
	PredicateCondition* pred2 = new PredicateCondition(SCAN_LEFTVALUE_ELEMENTCONTENT,SCAN_OP_EQ,val2); 
	conj->setCond(1,pred2);
	iMatching->matchIndex(filename,ELEMENT_NODE,conj, icFullSet, icPartialSet);
	cout << "Full match: " << icFullSet.size() << endl;
	for (list<IndexCombination*>::const_iterator it = icFullSet.begin(); it != icFullSet.end(); ++it) {
		IndexCombination* ic = *it;
		ic->print();
	}
	cout << "Partial match: " << icPartialSet.size() << endl;
	for (list<IndexCombination*>::const_iterator it = icPartialSet.begin(); it != icPartialSet.end(); ++it) {
		IndexCombination* ic = *it;
		ic->print();
	}
	for (IndexCombSet::iterator it = icFullSet.begin(); it != icFullSet.end(); ++it) {
		IndexCombination* ic = *it;
		delete ic;
	}
	for (IndexCombSet::iterator it = icPartialSet.begin(); it != icPartialSet.end(); ++it) {
		IndexCombination* ic = *it;
		delete ic;
	}

	//Test 3 $text = John Doe
	//conjunctivecondition* conj = new conjunctivecondition(1);
	//value* val1 = new value(string_value);
	//val1->setstrvalue("john doe");
	//predicatecondition* pred1 = new predicatecondition(scan_leftvalue_value,scan_op_eq,val1); 
	//conj->setcond(0,pred1);
	//imatching->matchindex(filename,text_node,conj, icfullset, icpartialset);
	//cout << "full match: " << icfullset.size() << endl;
	//for (list<indexcombination*>::const_iterator it = icfullset.begin(); it != icfullset.end(); ++it) {
	//	indexcombination* ic = *it;
	//	ic->print();
	//}
	//cout << "partial match: " << icpartialset.size() << endl;
	//for (list<indexcombination*>::const_iterator it = icpartialset.begin(); it != icpartialset.end(); ++it) {
	//	indexcombination* ic = *it;
	//	ic->print();
	//}
	//for (indexcombset::iterator it = icfullset.begin(); it != icfullset.end(); ++it) {
	//	indexcombination* ic = *it;
	//	delete ic;
	//}
	//for (indexcombset::iterator it = icpartialset.begin(); it != icpartialset.end(); ++it) {
	//	indexcombination* ic = *it;
	//	delete ic;
	//}

	//Test 4 $attrname = number
	//ConjunctiveCondition* conj = new ConjunctiveCondition(1);
	//Value* val1 = new Value(STRING_VALUE);
	//val1->setStrValue("number");
	//PredicateCondition* pred1 = new PredicateCondition(SCAN_LEFTVALUE_HASATTRIBUTE,SCAN_OP_EQ,val1); 
	//conj->setCond(0,pred1);
	//iMatching->matchIndex(filename,ATTRIBUTE_NODE,conj, icFullSet, icPartialSet);
	//cout << "Full match: " << icFullSet.size() << endl;
	//for (IndexCombSet::const_iterator it = icFullSet.begin(); it != icFullSet.end(); ++it) {
	//	IndexCombination* ic = *it;
	//	ic->print();
	//}
	//cout << "Partial match: " << icPartialSet.size() << endl;
	//for (IndexCombSet::const_iterator it = icPartialSet.begin(); it != icPartialSet.end(); ++it) {
	//	IndexCombination* ic = *it;
	//	ic->print();
	//}
	//for (IndexCombSet::iterator it = icFullSet.begin(); it != icFullSet.end(); ++it) {
	//	IndexCombination* ic = *it;
	//	delete ic;
	//}
	//for (IndexCombSet::iterator it = icPartialSet.begin(); it != icPartialSet.end(); ++it) {
	//	IndexCombination* ic = *it;
	//	delete ic;
	//}

	//Test 5 number = 5
	//ConjunctiveCondition* conj = new ConjunctiveCondition(1);
	//char leftval[7];
	//strcpy(leftval,"number");
	//Value* val1 = new Value(INT_VALUE);
	//val1->setIntValue(5);
	//PredicateCondition* pred1 = new PredicateCondition((int)&leftval,SCAN_OP_EQ,val1); 
	//conj->setCond(0,pred1);
	//iMatching->matchIndex(filename,ATTRIBUTE_NODE,conj, icFullSet, icPartialSet);
	//cout << "Full match: " << icFullSet.size() << endl;
	//for (list<IndexCombination*>::iterator it = icFullSet.begin(); it != icFullSet.end(); ++it) {
	//	IndexCombination* ic = *it;
	//	ic->print();
	//}
	//cout << "Partial match: " << icPartialSet.size() << endl;
	//for (list<IndexCombination*>::iterator it = icPartialSet.begin(); it != icPartialSet.end(); ++it) {
	//	IndexCombination* ic = *it;
	//	ic->print();
	//}
	//for (IndexCombSet::iterator it = icFullSet.begin(); it != icFullSet.end(); ++it) {
	//	IndexCombination* ic = *it;
	//	delete ic;
	//}
	//for (IndexCombSet::iterator it = icPartialSet.begin(); it != icPartialSet.end(); ++it) {
	//	IndexCombination* ic = *it;
	//	delete ic;
	//}

	delete conj;
	delete iMatching;
}

/**
* Destructor
*/
TestIndexMng::~TestIndexMng(void)
{
}

