/*
COPYRIGHT  (c) 2000-2004 
THE REGENTS OF THE UNIVERSITY OF MICHIGAN
ALL RIGHTS RESERVED

PERMISSION IS GRANTED TO USE, COPY, CREATE DERIVATIVE WORKS AND
REDISTRIBUTE THIS SOFTWARE AND SUCH DERIVATIVE WORKS FOR NONCOMMERCIAL
EDUCATION AND RESEARCH PURPOSES, SO LONG AS NO FEE IS CHARGED, AND SO LONG
AS THE COPYRIGHT NOTICE ABOVE, THIS GRANT OF PERMISSION, AND THE
DISCLAIMER BELOW APPEAR IN ALL COPIES MADE; AND SO LONG AS THE NAME OF THE
UNIVERSITY OF MICHIGAN IS NOT USED IN ANY ADVERTISING OR PUBLICITY
PERTAINING TO THE USE OR DISTRIBUTION OF THIS SOFTWARE WITHOUT SPECIFIC,
WRITTEN PRIOR AUTHORIZATION.

THIS SOFTWARE IS PROVIDED AS IS, WITHOUT REPRESENTATION FROM THE
UNIVERSITY OF MICHIGAN AS TO ITS FITNESS FOR ANY PURPOSE, AND WITHOUT
WARRANTY BY THE UNIVERSITY OF MICHIGAN OF ANY KIND, EITHER EXPRESS OR
IMPLIED, INCLUDING WITHOUT LIMITATION THE IMPLIED WARRANTIES OF
MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE. THE REGENTS OF THE
UNIVERSITY OF MICHIGAN SHALL NOT BE LIABLE FOR ANY DAMAGES, INCLUDING
SPECIAL, INDIRECT, INCIDENTAL, OR CONSEQUENTIAL DAMAGES, WITH RESPECT TO
ANY CLAIM ARISING OUT OF OR IN CONNECTION WITH THE USE OF THE SOFTWARE,
EVEN IF IT HAS BEEN OR IS HEREAFTER ADVISED OF THE POSSIBILITY OF SUCH
DAMAGES.
*/

#ifndef __IndexNameTable_H
#define __IndexNameTable_H
#include <timber-compat.h>

#include "../Common/IndexMng_definitions.h"

/**
* IndexNameTable
* 
* This class is an index catalog given an index name
* return the index info of that index file
* 
* @version 1.0
*/

class IndexNameTable
{
public:


	/**
	* Constructor
	*
	* @param volumeID The device volume id
	*/
	IndexNameTable(lvid_t volumeID);

	/**
	* Destructor
	*/
	~IndexNameTable();

	/**
	* Process method
	* Insert an index name - indexinfo association
	*
	* @param indexname The name of the index
	* @param indexinfo The index info the index being inserted
	* @returns Error code
	*/
	int insertIndex(char* indexname,
		IndexInfoType* indexinfo);

	/**
	* Process method
	* Delete an index name - indexinfo association
	*
	* @param indexname The name of the index
	* @returns Error code
	*/
	int deleteIndex(char* indexname);

	/**
	* Process method
	* Get an index info of the index name
	*
	* @param indexname The name of the index
	* @returns The indexinfoType of the index
	*/
	IndexInfoType* getIndexInfo(char* indexname);

	/**
	* Scan method
	* Start the scan of the whole catalog
	*/
	void startTableScan();

	/**
	* Scan method
	* Get the next matching index
	*
	* @returns The indexinfoType of the index
	*/
	IndexInfoType* getNextIndexInfo();
private:
	lvid_t volumeID;
	serial_t IndexNameTable_IndexID;
	scan_index_i* scanindex;
};

#endif
