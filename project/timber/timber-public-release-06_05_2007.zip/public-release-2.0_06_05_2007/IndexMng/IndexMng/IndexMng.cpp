/*
COPYRIGHT  (c) 2000-2004 
THE REGENTS OF THE UNIVERSITY OF MICHIGAN
ALL RIGHTS RESERVED

PERMISSION IS GRANTED TO USE, COPY, CREATE DERIVATIVE WORKS AND
REDISTRIBUTE THIS SOFTWARE AND SUCH DERIVATIVE WORKS FOR NONCOMMERCIAL
EDUCATION AND RESEARCH PURPOSES, SO LONG AS NO FEE IS CHARGED, AND SO LONG
AS THE COPYRIGHT NOTICE ABOVE, THIS GRANT OF PERMISSION, AND THE
DISCLAIMER BELOW APPEAR IN ALL COPIES MADE; AND SO LONG AS THE NAME OF THE
UNIVERSITY OF MICHIGAN IS NOT USED IN ANY ADVERTISING OR PUBLICITY
PERTAINING TO THE USE OR DISTRIBUTION OF THIS SOFTWARE WITHOUT SPECIFIC,
WRITTEN PRIOR AUTHORIZATION.

THIS SOFTWARE IS PROVIDED AS IS, WITHOUT REPRESENTATION FROM THE
UNIVERSITY OF MICHIGAN AS TO ITS FITNESS FOR ANY PURPOSE, AND WITHOUT
WARRANTY BY THE UNIVERSITY OF MICHIGAN OF ANY KIND, EITHER EXPRESS OR
IMPLIED, INCLUDING WITHOUT LIMITATION THE IMPLIED WARRANTIES OF
MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE. THE REGENTS OF THE
UNIVERSITY OF MICHIGAN SHALL NOT BE LIABLE FOR ANY DAMAGES, INCLUDING
SPECIAL, INDIRECT, INCIDENTAL, OR CONSEQUENTIAL DAMAGES, WITH RESPECT TO
ANY CLAIM ARISING OUT OF OR IN CONNECTION WITH THE USE OF THE SOFTWARE,
EVEN IF IT HAS BEEN OR IS HEREAFTER ADVISED OF THE POSSIBILITY OF SUCH
DAMAGES.
*/

#include "IndexMng.h"
#include <time.h>
#include <float.h>
#include <bitset>
#include <string.h>
using std::bitset;

/* start of inverted index section */
#include "../../TextMng/Stemming/Porter.h"
#include "../../TextMng/TermExpansion/TermExpansion.h"
using namespace porter;
// #define CHECK_TIME
#ifdef CHECK_TIME
extern double indexTime;
clock_t st, et;
#endif
/* end of inverted index section */

/**
* IndexMng
* 
* This class is for Index Management
* 
* This class interpret the index description, build index and help access 
* the indexes
*
* Currently support B-tree and Hash index
* 
* @version 1.0
*/

/**
* Constructor
* Build the Index Management based on the current Data Management.
* @param pDataMng The current Data Management
*/
IndexMng::IndexMng(PhysicalDataMng* pDataMng)
{
	this->pDataMng = pDataMng;
	this->volumeID = pDataMng->getVolumeID();
	this->xmlNameTable = pDataMng->getXMLNameTable();
	this->pDataMng->beginTransaction();
	this->indexNameTable = new IndexNameTable(this->volumeID);
	this->fileIndexTable = new FileIndexTable(this->volumeID);
	this->pDataMng->endTransaction();
}

/**
* Default destructor
*/
IndexMng::~IndexMng()
{
	delete this->indexNameTable;
	delete this->fileIndexTable;
}

/**
* Process Method
*
* Build value index with given name, based on the data from a file 
* (xml document), and satisfy the index description.
*
* @param filename The name of the file (xml document) the index is going to built on.
* @param index_description The description of the value index. value can be
* <pre>
*@@	VALUEINDEX_ELEMENTTAG			build index on element tag (using tag encoding)
*@@	VALUEINDEX_ELEMENTTAGSTR		build index on element tag (using tag name)
*@@	VALUEINDEX_CHILDNUMBER			build index on element node, based on number of children
*@@	VALUEINDEX_ATTRIBUTENUMBER		build index on element node, based on number of attribute
*@@	VALUEINDEX_ATTRIBUTENAME		build index on attribute node, based on each of the attribute name
*@@	VALUEINDEX_ATTRIBUTEVALUE		build index on attribute node, based on each of the attribute value.
*@@	VALUEINDEX_TEXTVALUE			build index on text node, based on the contend of the node
*@@	VALUEINDEX_ATTRIBUTECONTENT		build index on element node, based on the value of the attribute of a given value
*@@	VALUEINDEX_ELEMENTCONTENT		build index on the element node (with given tag), based on the value of the textnode which is its direct child
*@@	VALUEINDEX_INVERTEDINDEX_ELEM	build index on element node, based on words in its text.	
*@@	VALUEINDEX_INVERTEDINDEX_TEXT	build index on text node, based on words in its text.	
*@@ VALUEINDEX_TAGNAME_ID_PAIR		build index on a combined element tag and tag node id, for updatable operations
*@@ VALUEINDEX_ATTRIBUTENAME_ID_PAIR	build index on a combined attribute name and node id, for updatable operations
*@@ VALUEINDEX_NAME_STANDARDNAME_PAIR	build index on name (both tag name and attribute name),as the key, and the 
**                                      standard name, for term expansion
*@@ VALUEINDEX_STANDARDNAME_NAME_PAIR	build index on name (both tag name and attribute name) and the standard name
*                                       as the key, for term expansion
*@@ VALUEINDEX_NAME_POS                 build index on name (both tag name and attribute name) and its 
*                                       position in the bitset map
*@@ VALUEINDEX_ANCESTOR_DESCENDANT_SUMMARIZATION   build index on node and bitset representing the types of nodes as
*                                                  its descendant
*@@ VALUEINDEX_SKEY_POS_SUMMARIZATION   build index on node and its position in a bitset representing the type of node
* <\pre>
* @param strval The string value that is used for some type of index, e.g. VALUEINDEX_ATTRIBUTECONTENT, VALUEINDEX_ELEMENTCONTENT
* @param indexSource is either SHORE_INDEX or GIST_INDEX or HASH_INDEX. If it is SHORE_INDEX, it builds a shore index. Otherwise, it 
*			builds a GIST_INDEX.
* @param indexType is either INT_INDEX, FLOAT_INDEX, or STRING_INDEX. If you are indexing nametags or attr names 
*			it is STRING_INDEX by default.
* @param indexName The name of the index created (return value)
* @param colorName Optional value for the name suffix of multicolor index (for Multicolor XML)
* @param rootColor The key of the root of the color tree (for Multicolor XML)
* @returns Whether the index is created successfully. 
*/

bool  IndexMng::buildValueIndex(
								char* filename,                               
								int index_description, // catType
								char* strval, // optional value
								int indexSource, // genType
								int indexType, // valType
								char *indexName,
								char *colorName, //name for color index
								KeyType rootColor) //Key of the color root, in case building color indices 
{

	rc_tGist gistret;
	rc_t rc;
	bool case_insensitive = false;
	char indexname[MAX_INDEX_NAME_LENGTH] = "index_";
	char indexNameWithPath[MAX_INDEX_NAME_LENGTH];
	strcpy(indexname+6, filename);

	short i;

	//Get the setting whether we build the content-related index in a case insensitive mode
	case_insensitive = gSettings->getBooleanValue("INDEX_CASE_INSENSITIVE",false);

	FileInfoType *fileinfo = this->pDataMng->getFileInfo(filename);

	if (fileinfo == NULL)
	{
		globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"IndexMng::buildValueIndex",__FILE__,"File does not exist, can not build index on it.");
		return false;
	}
	KeyType rootkey = fileinfo->rootKey;


	// define the index name index type and the size of the index key and the
	// scan condition based on the index description
	int indextype = indexType;
	char* indexkey = NULL;
	char* tempIndexkey = NULL;
	int indexkey_size = 0;
	SelectionCondition* scancond = new SelectionCondition();

	switch (index_description) 
	{

		// key - tag name enconding
		// return - element node id
	case VALUEINDEX_ELEMENTTAG:
		{
			//Multicolor color index
			//Case of building color index, if rootColor is not the real root key
			if (rootColor == rootkey) { 
				strcpy(indexname+6+strlen(filename)-4, "_elementtag");
			}
			else {
				strcpy(indexname+6+strlen(filename)-4, "_elementtag_");
				strcpy(indexname+6+strlen(filename)-4+12,colorName);

			}

			indextype = INT_INDEX;
			indexkey_size = sizeof(int);
			scancond->setNodeType(ELEMENT_NODE);
			scancond->setCondition(NULL);
			scancond->setReturnType(SCAN_RETURN_THISNODE);
		}
		break;
		// key - tag name
		// return - element node id
	case VALUEINDEX_ELEMENTTAGSTR:
		{
			//Multicolor color index
			//Case of building color index, if rootColor is not the real root key
			if (rootColor == rootkey) { 
				strcpy(indexname+6+strlen(filename)-4, "_elementtagstr");
			}
			else {
				strcpy(indexname+6+strlen(filename)-4, "_elementtagstr_");
				strcpy(indexname+6+strlen(filename)-4+15,colorName);

			}

			indextype = STRING_INDEX;
			indexkey_size = MAX_NODETAG_LENGTH;
			scancond->setNodeType(ELEMENT_NODE);
			scancond->setCondition(NULL);
			scancond->setReturnType(SCAN_RETURN_THISNODE);
		}
		break;

		// key - tag name , node id
		// return - element node id
	case VALUEINDEX_TAGNAME_ID_PAIR:
		{
			strcpy(indexname+6+strlen(filename)-4, "_tagid");
			indextype = STRING_INDEX;
			//we had 3 because there is a one character delimiter between the tagname
			//and the key, the key has NUM_LEFT_DIGITS, followed by a decimal point,
			//followed by NUM_RIGHT_DIGITS, followed by another one character delimiter
			//indexkey_size = MAX_NODETAG_LENGTH + 
			//	1 + //delimiter
			//	TagNameAndNodeIdIndex::NUM_LEFT_DIGITS +
			//	1 + //decimal point
			//	TagNameAndNodeIdIndex::NUM_RIGHT_DIGITS +
			//	1; //delimiter

			//AN: actually, this is just asking for the tagname length, not the concatenated length...
			//string tempString(MAX_NODETAG_LENGTH, 'A');
			//indexkey_size = TagNameAndNodeIdIndex::getKeyLength(tempString.c_str());
			//AN: so do this:
			indexkey_size = MAX_NODETAG_LENGTH;

			scancond->setNodeType(ELEMENT_NODE);
			scancond->setCondition(NULL);
			scancond->setReturnType(SCAN_RETURN_THISNODE);
		}
		break;

		// key - attribute name , node id
		// return - element node id
	case VALUEINDEX_ATTRIBUTENAME_ID_PAIR:
		{
			strcpy(indexname+6+strlen(filename)-4, "_atagid");
			indextype = STRING_INDEX;
			//we no longer have a maximum attribute name length, and we're not using indexkey_size with gist:
			//indexkey_size = MAX_ATTRIBUTE_NAME_LENGTH;
			//string tempString(MAX_ATTRIBUTE_NAME_LENGTH, 'A');
			//indexkey_size = TagNameAndNodeIdIndex::getKeyLength(tempString.c_str());
			//indexkey_size = MAX_ATTRIBUTE_NAME_LENGTH;

			//assigning -1 will cause 'indexkey = new char[indexkey_size + 1]' to not waste any memory:
			indexkey_size = -1;
			scancond->setNodeType(ATTRIBUTE_NODE);
			scancond->setCondition(NULL);
			scancond->setReturnType(SCAN_RETURN_THISNODE);
		}
		break;

		// TODO: better/faster way to build the two indices
		// Yunyao Li: 10-20-2004 added to support term expansion
		// key - tag/attribute name
		// return - standardlized name
	case VALUEINDEX_NAME_STANDARDNAME_PAIR:
		// key - standardlized name
		// return - tag/attribute name
	case VALUEINDEX_STANDARDNAME_NAME_PAIR:
		{
			indextype = STRING_INDEX;

			strcpy(indexname+6+strlen(filename)-4, "_stdtag_tag");

			indexkey_size = MAX_NODETAG_LENGTH;
			scancond->setNodeType(SCAN_ALLNODES);
			scancond->setCondition(NULL);
			scancond->setReturnType(SCAN_RETURN_THISNODE);
		}

		break;

		// key - attribute name
		// return - attribute node id
	case VALUEINDEX_ATTRIBUTENAME:
		{
			//Multicolor color index
			//Case of building color index, if rootColor is not the real root key
			if (rootColor == rootkey) { 
				strcpy(indexname+6+strlen(filename)-4, "_attrname");
			}
			else {
				strcpy(indexname+6+strlen(filename)-4, "_attrname_");
				strcpy(indexname+6+strlen(filename)-4+10,colorName);

			}

			indextype = STRING_INDEX;
			//we no longer have a maximum attribute name length, and we're not using indexkey_size with gist:
			//indexkey_size = MAX_ATTRIBUTE_NAME_LENGTH;
			//assigning -1 will cause 'indexkey = new char[indexkey_size + 1]' to not waste any memory:
			indexkey_size = -1;
			scancond->setNodeType(ATTRIBUTE_NODE);
			scancond->setCondition(NULL);
			scancond->setReturnType(SCAN_RETURN_THISNODE);
		}
		break;

		// key - attribute value
		// return - attribute node id
	case VALUEINDEX_ATTRIBUTEVALUE:
		{
			// indextype = STRING_INDEX;
			indextype = indexType;
			if (indextype == INT_INDEX)
			{
				strcpy(indexname+6+strlen(filename)-4, "_attrvalueint");
				indexkey_size = sizeof(int);
			}
			else if (indextype == STRING_INDEX)
			{
				strcpy(indexname+6+strlen(filename)-4, "_attrvaluestr");
				indexkey_size = MAX_TEXT_VALUE_LENGTH;
			}
			else if (indextype == FLOAT_INDEX)
			{
				strcpy(indexname+6+strlen(filename)-4, "_attrvalueflt");
				indexkey_size = sizeof(float);
			}
			else  if (indextype == DOUBLE_INDEX)
			{
				strcpy(indexname+6+strlen(filename)-4, "_attrvaluedbl");
				indexkey_size = sizeof(double);
			}
			else
			{
				globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"IndexMng::buildValueIndex",__FILE__,"Invalid key index type.");
				return false;
			}
			scancond->setNodeType(ATTRIBUTE_NODE);
			scancond->setCondition(NULL);
			scancond->setReturnType(SCAN_RETURN_THISNODE);
		}
		break;

		//key - element content
		//return - content node id
	case VALUEINDEX_TEXTVALUE:
		{
			// indextype = STRING_INDEX;
			indextype = indexType;
			if (indextype == INT_INDEX)
			{
				strcpy(indexname+6+strlen(filename)-4, "_textvalueint");
				indexkey_size = sizeof(int);
			}
			else if (indextype == STRING_INDEX)
			{
				strcpy(indexname+6+strlen(filename)-4, "_textvaluestr");
				indexkey_size = MAX_TEXT_VALUE_LENGTH;
			}
			else if (indextype == FLOAT_INDEX)
			{
				strcpy(indexname+6+strlen(filename)-4, "_textvalueflt");
				indexkey_size = sizeof(float);
			}
			else if (indextype == DOUBLE_INDEX)
			{
				strcpy(indexname+6+strlen(filename)-4, "_textvaluedbl");
				indexkey_size = sizeof(double);
			}
			else
			{
				globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"IndexMng::buildValueIndex",__FILE__,"Invalid key index type.");
				return false;
			}
			scancond->setNodeType(TEXT_NODE);
			scancond->setCondition(NULL);
			scancond->setReturnType(SCAN_RETURN_THISNODE);
		}
		break;

		//key - attribute content of a apecified attribute name
		//return - element node id parent of the attribute
	case VALUEINDEX_ATTRIBUTECONTENT:
		{
			indextype = indexType;
			if (indextype == INT_INDEX)
			{
				strcpy(indexname+6+strlen(filename)-4, "_attributecontentint_");
				indexkey_size = sizeof(int);
			}
			else if (indextype == STRING_INDEX)
			{
				strcpy(indexname+6+strlen(filename)-4, "_attributecontentstr_");
				indexkey_size = MAX_TEXT_VALUE_LENGTH;
			}
			else if (indextype == FLOAT_INDEX)
			{
				strcpy(indexname+6+strlen(filename)-4, "_attributecontentflt_");
				indexkey_size = sizeof(float);
			}
			else if (indextype == DOUBLE_INDEX)
			{
				strcpy(indexname+6+strlen(filename)-4, "_attributecontentdbl_");
				indexkey_size = sizeof(double);
			}
			else
			{
				globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"IndexMng::buildValueIndex",__FILE__,"Invalid key index type.");
				return false;
			}

			strcpy(indexname+6+strlen(filename)-4+21, strval);
			//Multicolor
			//Case of building color index
			if (rootColor != rootkey)  {
				strcpy(indexname+6+strlen(filename)-4+21+strlen(strval), "_");
				strcpy(indexname+6+strlen(filename)-4+21+strlen(strval)+1,colorName);

			}

			scancond->setNodeType(ELEMENT_NODE);
			Value* val = new Value(STRING_VALUE);
			val->setStrValue(strval);
			PredicateCondition* pred = new PredicateCondition(SCAN_LEFTVALUE_HASATTRIBUTE,
				SCAN_OP_EQ,val);

			ConjunctiveCondition* conj = new ConjunctiveCondition(1);
			conj->insertCond(pred);
			DisjunctiveCondition* disj = new DisjunctiveCondition(1);
			disj->insertCond(conj);

			scancond->setCondition(disj);
			scancond->setReturnType(SCAN_RETURN_THISNODE);

		}
		break;

		//key - element content of a apecified element tag name
		//return - element node id
	case VALUEINDEX_ELEMENTCONTENT:
		{
			indextype = indexType;
			if (indextype == INT_INDEX)
			{
				strcpy(indexname+6+strlen(filename)-4, "_elementcontentint_");
				indexkey_size = sizeof(int);
			}
			else if (indextype == STRING_INDEX)
			{
				strcpy(indexname+6+strlen(filename)-4, "_elementcontentstr_");
				indexkey_size = MAX_TEXT_VALUE_LENGTH;
			}
			else if (indextype == FLOAT_INDEX)
			{
				strcpy(indexname+6+strlen(filename)-4, "_elementcontentflt_");
				indexkey_size = sizeof(float);
			}
			else if (indextype == DOUBLE_INDEX)
			{
				strcpy(indexname+6+strlen(filename)-4, "_elementcontentdbl_");
				indexkey_size = sizeof(double);
			}
			else{
				globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"IndexMng::buildValueIndex",__FILE__,"Invalid key index type.");
				return false;
			}
			strcpy(indexname+6+strlen(filename)-4+19, strval);
			//Multicolor
			//Case of building color index
			if (rootColor != rootkey)  {
				strcpy(indexname+6+strlen(filename)-4+19+strlen(strval), "_");
				strcpy(indexname+6+strlen(filename)-4+19+strlen(strval)+1,colorName);

			}

			scancond->setNodeType(ELEMENT_NODE);

			//Value* val = new Value(STRING_VALUE);
			//val->setStrValue(strval); 
			Value* val = new Value(INT_VALUE);
			val->setIntValue(this->xmlNameTable->getCodeByName(strval));

			PredicateCondition* pred = new PredicateCondition(SCAN_LEFTVALUE_NODETAG,
				SCAN_OP_EQ,val);

			ConjunctiveCondition* conj = new ConjunctiveCondition(1);
			conj->insertCond(pred);
			DisjunctiveCondition* disj = new DisjunctiveCondition(1);
			disj->insertCond(conj);

			scancond->setCondition(disj);
			scancond->setReturnType(SCAN_RETURN_THISNODE);
		}
		break;

		/**
		* Inverted Index
		* 
		*   build inverted index on the content of each element node
		*
		*   VALUEINDEX_INVERTEDINDEX_TEXT: return the textnode itself
		*   VALUEINDEX_INVERTEDINDEX_ELEM: return parent element node
		*
		*   MAX_TEXT_VALUE_LENGTH_INV = 1000 => defined in "porter.h"
		*
		* @author Cong Yu
		* @version 1.0
		*/
	case VALUEINDEX_INVERTEDINDEX_TEXT_STEM: // primary index
	case VALUEINDEX_INVERTEDINDEX_ELEM_STEM:
	case VALUEINDEX_INVERTEDINDEX_TEXT_NOSTEM:
	case VALUEINDEX_INVERTEDINDEX_ELEM_NOSTEM:
		{
			indextype = STRING_INDEX;

			// create the name of the index
			if (index_description == VALUEINDEX_INVERTEDINDEX_TEXT_STEM) {
				strcpy(indexname+6+strlen(filename)-4, "_invtext_s");
			}
			else if (index_description == VALUEINDEX_INVERTEDINDEX_TEXT_NOSTEM) {
				strcpy(indexname+6+strlen(filename)-4, "_invtext_n");
			}
			else if (index_description == VALUEINDEX_INVERTEDINDEX_ELEM_NOSTEM) {
				strcpy(indexname+6+strlen(filename)-4, "_invelem_n");
			}
			else {
				strcpy(indexname+6+strlen(filename)-4, "_invelem_s");
			}

			// set up scan condition: scan for all element nodes
			indexkey_size = MAX_WORD_LENGTH;
			scancond->setNodeType(ELEMENT_NODE);
			scancond->setCondition(NULL);
			scancond->setReturnType(SCAN_RETURN_THISNODE);
		}
		break;

		// Yunyao: 01-13-05, added to support NALIX
		// @author: Yunyao Li
		// @ version: 1.0
	case VALUEINDEX_INVERTEDINDEX_TEXT_NAME_STEM:
	case VALUEINDEX_INVERTEDINDEX_TEXT_NAME_NOSTEM:
		{
			indextype = STRING_INDEX;

			// create the name of the index
			if (index_description == VALUEINDEX_INVERTEDINDEX_TEXT_NAME_STEM)
				strcpy(indexname+6+strlen(filename)-4, "_invtext_name_s");
			else
				strcpy(indexname+6+strlen(filename)-4, "_invtext_name_n");

			// set up scan condition: scan for all element nodes
			indexkey_size = MAX_WORD_LENGTH;
			scancond->setNodeType(SCAN_ALLNODES);
			scancond->setCondition(NULL);
			scancond->setReturnType(SCAN_RETURN_THISNODE);

			tempIndexkey = new char[indexkey_size + MAX_NODETAG_LENGTH];
		}
		break;

		// Yunyao: 04-25-05, added to support ancestor-descendant summarization index
	// @author: Yunyao Li
	// @ version: 1.0
	case VALUEINDEX_NAME_POS:
		{
			indextype = STRING_INDEX;

			// create the name of the index
			strcpy(indexname+6+strlen(filename)-4, "_name_pos");

			// set up scan condition: scan for all element nodes
			indexkey_size = MAX_NODETAG_LENGTH;
			// currently only consider element node
			// TODO: add attribute node as well
			scancond->setNodeType(ELEMENT_NODE);
			scancond->setCondition(NULL);
			scancond->setReturnType(SCAN_RETURN_THISNODE);
		}
		break;
	
	// Yunyao: 04-26-05, added to support ancestor-descendant summarization index
	// @author: Yunyao Li
	// @ version: 1.0
	case VALUEINDEX_ANCESTOR_DESCENDANT_SUMMARIZATION:
		{
			indextype = DOUBLE_INDEX;

			// create the name of the index
			strcpy(indexname+6+strlen(filename)-4, "_anc_desc");

			// set up scan condition: scan for all element nodes
			indexkey_size = sizeof(double);
			// currently only consider element node
			// TODO: add attribute node as well
			scancond->setNodeType(ELEMENT_NODE);
			scancond->setCondition(NULL);
			scancond->setReturnType(SCAN_RETURN_THISNODE);
		}
		break;
	case VALUEINDEX_SKEY_POS_SUMMARIZATION:
	{
		indextype = DOUBLE_INDEX;

		// create the name of the index
		strcpy(indexname+6+strlen(filename)-4,"_skey_pos");

		// set up scan condition: scan for all element nodes
		indexkey_size = sizeof(double);
		// currently only consider element node
		// TODO: add attribute node as well
		scancond->setNodeType(ELEMENT_NODE);
		scancond->setCondition(NULL);
		scancond->setReturnType(SCAN_RETURN_THISNODE);
	}
	break;

	case VALUEINDEX_PARENT:
		{
			indextype = DOUBLE_INDEX;
			indexSource = HASH_INDEX; //force to be hash index, the only we support
			strcpy(indexname+6+strlen(filename)-4, "_parent");
			indexkey_size = sizeof(double);
			scancond->setNodeType(SCAN_ALLNODES);
			scancond->setCondition(NULL);
			scancond->setReturnType(SCAN_RETURN_THISNODE);
		}
		break;

	default: 
		{
			globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"IndexMng::buildValueIndex",__FILE__,"Illegal index description.");
			return false;
		}
		break;
	}

	int sizeToAllocate ;
	if (indexkey_size < 100)
	{
		sizeToAllocate = 100 ;
	}
	else
	{
		sizeToAllocate = indexkey_size ;
	}

	indexkey = new char[sizeToAllocate + 1];

	//create a new index.
	//note here is a problem in GiST index that we use double_cmp for dataCmp
	// which should be a customerized comparison! (gist_btree.cpp)

	// check whether the index exists in the system.
	IndexInfoType* indexinfo = this->indexNameTable->getIndexInfo(indexname);
	if (indexinfo != NULL) 
	{
		globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"IndexMng::buildValueIndex",__FILE__,"An index with same name exists in the system.");
		delete indexinfo;
		return false;

		/****************************************************************************
		* Because of the update functionality,                                      *
		* we now do not allow rebuild the index that already exists.			    *               *
		****************************************************************************/
		//!!!!  !!!!
		// rebuild the index with the same name
		// remove the old index file and 
		// remove the association of the name and index file

		//if (indexinfo->indexSource == SHORE_INDEX) //for shore we explicitly use the interface to destroy index
		//	//note for gist, we just remove the physical file below.
		//{
		//	rc = ss_m::destroy_index(this->volumeID, indexinfo->indexID);
		//	if (rc)
		//	{
		//		globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"IndexMng::buildValueIndex",__FILE__,"After destroying old index from shore.");
		//		return false;
		//	}
		//}
		//this->indexNameTable->deleteIndex(indexname);
		//this->fileIndexTable->deleteIndex(filename, indexname);
		//delete indexinfo;
	}

	GistIndexUpdate *gistIndex = NULL;
	ShoreIndexUpdate *indexp = NULL;
	HashIndexUpdate *hashIndex = NULL;

	GistIndexUpdate *tempGistIndex = NULL;

	gist* basicGistIndex = NULL;
	TagNameAndNodeIdIndex* tagIdIndex = NULL;
	int tempRecordNumber = 0;

	if (index_description == VALUEINDEX_TAGNAME_ID_PAIR || index_description == VALUEINDEX_ATTRIBUTENAME_ID_PAIR) {


		// append path with the indexname
		strcpy(indexNameWithPath,gSettings->getStringValue("GIST_DEFAULT_FILEPATH").c_str());
		strcat(indexNameWithPath,indexname);


		remove(indexNameWithPath);

		basicGistIndex = new gist();
		rc_tGist gistSuccess = basicGistIndex->create(indexNameWithPath, &bt_str_ext);
		if (gistSuccess != RCOKGist) {
			globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"IndexMng::buildValueIndex",__FILE__,"After creating index from gist.");
			return false;
		}

		tagIdIndex = new TagNameAndNodeIdIndex();
	}
	else if (indexSource == GIST_INDEX)
	{

		// append path with the indexname
		strcpy(indexNameWithPath,gSettings->getStringValue("GIST_DEFAULT_FILEPATH").c_str());
		strcat(indexNameWithPath,indexname);

		if (indextype == STRING_INDEX)
			gistIndex = new GistIndexUpdate(indexNameWithPath,&bt_str_ext,indextype,indexkey_size);
		else if (indextype == INT_INDEX)
			gistIndex = new GistIndexUpdate(indexNameWithPath,&bt_int_ext,indextype,indexkey_size);
		else if (indextype == FLOAT_INDEX)
			gistIndex = new GistIndexUpdate(indexNameWithPath,&bt_flt_ext,indextype,indexkey_size);
		else if (indextype == DOUBLE_INDEX)
			gistIndex = new GistIndexUpdate(indexNameWithPath,&bt_dbl_ext,indextype,indexkey_size);
		indexp = NULL;
		hashIndex= NULL;

		// remove the previous index file
		remove(indexNameWithPath);
		gistret = gistIndex->create();
		if (gistret != RCOKGist){
			globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"IndexMng::buildValueIndex",__FILE__,"After creating index from gist.");
			return false;
		}

		// a temp index
		if (index_description == VALUEINDEX_NAME_STANDARDNAME_PAIR || 
			index_description == VALUEINDEX_STANDARDNAME_NAME_PAIR ||
			index_description == VALUEINDEX_INVERTEDINDEX_TEXT_NAME_STEM||
			index_description == VALUEINDEX_INVERTEDINDEX_TEXT_NAME_NOSTEM)
		{
			strcpy(indexNameWithPath,gSettings->getStringValue("GIST_DEFAULT_FILEPATH").c_str());
			strcat(indexNameWithPath,"temp");
			// remove the previous index file
			remove(indexNameWithPath);
			tempGistIndex = new GistIndexUpdate(indexNameWithPath,&bt_str_ext,indextype,indexkey_size);

			gistret = tempGistIndex->create();
			if (gistret != RCOKGist){
				globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"IndexMng::buildValueIndex",__FILE__,"After creating index from gist.");
				return false;
			}
		}
	}
	else if (indexSource == SHORE_INDEX)
	{

		indexp = new ShoreIndexUpdate(this->volumeID, indextype,indexkey_size);
		gistIndex = NULL;
		hashIndex = NULL;
		rc = indexp->create();
		if (rc)
		{
			globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"IndexMng::buildValueIndex",__FILE__,"After creating index from shore.");
			return false;
		}
	}
	else // hash index
	{
		// append path with the indexname
		strcpy(indexNameWithPath,gSettings->getStringValue("GIST_DEFAULT_FILEPATH").c_str());
		strcat(indexNameWithPath,indexname);

		if (indextype == STRING_INDEX)
		{
			globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"IndexMng::buildValueIndex",__FILE__,"Hash indices don't work with strings");
			return false;
		}
		remove(indexNameWithPath);
		hashIndex = new HashIndexUpdate(indexname,indextype);
		indexp = NULL;
		gistIndex = NULL;
	}


	char tagname[30] = {'\0'};
	int count = 0;

	// open a scan based on the predicate
	ScanInfo *scaninfo = this->pDataMng->startScan(fileinfo, rootkey, 0, -1,
		NULL, scancond);

	DM_DataNode* node = this->pDataMng->scanFetchNext(scaninfo);

	//Multicolor index
	//Get end key of the root color to limit the range of node insertion
	KeyType colorEndKey;
	if (rootColor != rootkey) {
		DM_DataNode* subTreeRootNode = this->pDataMng->fetchDataNodeFromDBFile(*fileinfo,rootColor);
		colorEndKey= subTreeRootNode->getEndKey();
		delete subTreeRootNode;
	}

	char stdTerm[MaxNumSense][MaxStrLen];
	int num;

	TermExpansion * termExpansion;

	termExpansion = new TermExpansion;

		//--------------------------------------------------------------------------------------
	// Yunyao: added 04/26/2005
	//    Before we build ancestor_descendant_summarization index, we need to make sure that 
	//    name_pos mapping index exists
	//--------------------------------------------------------------------------------------
	// pointer to the name_pos index
	IndexInfoType* mapIndexinfo = NULL;

	// total number of entries in the name_pos index
	int numTypes = 0;

	// stack keeping nodes, where each node on the stack is the child of the node below it
	ListNode * nodeStack = NULL;

	// map information for corresponding nodes in the stack
	int pos;

	// bitset representing the types of descendants of each node
	bitset<MAX_BITSET_LENGTH> descMap[MAX_DEPTH];

	// current stack stackTop
	int stackTop = -1;

	gist *mapGistIndex = NULL;

	bool eof = false;
	gist_cursor_t cursor;
	unsigned long keysz = 3000000;  
	unsigned long datasz = (unsigned long) sizeof(int);

	bt_query_t* query = NULL;
	char *t2 ;

	if (index_description == VALUEINDEX_ANCESTOR_DESCENDANT_SUMMARIZATION ||
		index_description == VALUEINDEX_SKEY_POS_SUMMARIZATION)
	{
		mapIndexinfo = this->getMatchingIndex(filename,VALUEINDEX_NAME_POS);

		// check the existence of VALUEINDEX_NAME_POS
		if (mapIndexinfo == NULL)
		{
			delete [] indexkey;
			indexkey = NULL;

			globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"IndexMng::buildValueIndex",__FILE__,
				                          "Please build a name pos index first.");
			return false;
		}

		numTypes = mapIndexinfo->recordNumber;

		// check the number of entries of VALUEINDEX_NAME_POS
		if (numTypes <= 0)
		{
			delete [] indexkey;
			indexkey = NULL;

			globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"IndexMng::buildValueIndex",__FILE__,
				                          "The name pos index is empty.");
			return false;
		}

		char mapIndexName[MAX_INDEX_NAME_LENGTH] = "index_";
		strcpy(mapIndexName+6, filename);
		strcpy(mapIndexName+6+strlen(filename)-4, "_name_pos");

		char mapIndexNameWithPath[MAX_INDEX_NAME_LENGTH] = "";
		strcpy(mapIndexNameWithPath,gSettings->getStringValue("GIST_DEFAULT_FILEPATH").c_str());
		strcat(mapIndexNameWithPath,mapIndexName);

		mapGistIndex = new gist();

		rc_tGist gistret;
		// open the map index
		gistret = mapGistIndex->open(mapIndexNameWithPath);

		if (gistret)
		{
			globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"IndexMng::dumpIndex",__FILE__,"Could not open index file.");
			delete mapGistIndex;
			return false;
		}

		// bitset: keeping the types of descendant
		if (numTypes > MAX_BITSET_LENGTH)
		{
			delete [] indexkey;
			indexkey = NULL;

			globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"IndexMng::buildValueIndex",__FILE__,
				                          "The types of descendant is more than MAX_BITSET_LENGTH. Please increase MAX_BITSET_LENGTH, and try again.");
			return false;
		}	

		strcpy(indexkey, node->getTag(this->xmlNameTable));
	
		// create equality query that will find the exact key

		//TODO: Clean up sizeToAllocate, don't hard code 100
		//TODO: The bt_query_t setup is outside of the case statement this
		//      is different from all other indices

		int sizeToAllocate ;
		sizeToAllocate = strlen(indexkey) ;
		if (sizeToAllocate < 100)
		{
			sizeToAllocate = 100 ;
		}
		t2 = new char[sizeToAllocate] ;
		strcpy(t2, indexkey) ;
		query = new bt_query_t(bt_query_t::bt_eq, (void *)t2, NULL);

		nodeStack = new ListNode[MAX_DEPTH];
	}
	//-----------------------------------------------------------------------------------------

	while (node != NULL)
	{
		// build index body
		KeyType startkey = node->getKey();
		KeyType endkey = node->getEndKey();
		short level = node->getLevel();

		ListNode indexbody;
		indexbody.SetStartPos(startkey);
		indexbody.SetEndPos(endkey);
		indexbody.SetLevel(level);



		//Multicolor - check ranges for color index
		if (rootColor != rootkey) {
			//if it is not in the color range we are interested in, skip
			if ( (node->getKey() < rootColor) || (node->getKey() > colorEndKey)){
				delete node;
				node = this->pDataMng->scanFetchNext(scaninfo);
				continue;
			}
		}

		// create index item based on different index description.
		// for some kind of index (e.g. index on attribute name), one
		// node can have more than one index item associated with it
		switch (index_description) 
		{

		case VALUEINDEX_TAGNAME_ID_PAIR:
			{
				strcpy(indexkey, node->getTag(this->xmlNameTable));
				bool success = tagIdIndex->insertNode(indexkey, startkey.toDouble(), &indexbody, sizeof(indexbody), basicGistIndex);
				if (!success) return false;
				tempRecordNumber++;
			}
			break;

		case VALUEINDEX_ATTRIBUTENAME_ID_PAIR:
			{
				for (int i=0; i<node->getAttributeNumber(); i++) 
				{
					//char* getNameByCode (int code);
					((DM_AttributeNode*) node)->getAttr(i, indexkey);
					//char *attributeName = this->xmlNameTable->getNameByCode(atoi(indexkey));
					//strcpy(indexkey, node->getTag(this->xmlNameTable));

					//bool success = tagIdIndex->insertNode(attributeName, startkey.toDouble(), &indexbody, sizeof(indexbody), basicGistIndex);
					bool success = tagIdIndex->insertNode(indexkey, startkey.toDouble(), &indexbody, sizeof(indexbody), basicGistIndex);					if (!success) return false;

					//should I increment this inside the loop?:
					//yes, because each is a separate record (due to the different <name,ids> pairs)
					//unlike the non-updatable attribute name index
					tempRecordNumber++;

					delete [] indexkey;
					indexkey = NULL;
				}
			}
			break;
			// TODO: better/faster way to build the two indices
			// Yunyao Li: added to support term expansion
			// key - tag/attribute name
			// return - standardlized name
			// NOTE: by default, we use stemming
			// TODO: add choice for non-stemming/stemming
		case VALUEINDEX_NAME_STANDARDNAME_PAIR:
			// key - standardlized name
			// return - tag/attribute name
		case VALUEINDEX_STANDARDNAME_NAME_PAIR:
			{		
				int newPos = -1;

				if (indexSource != GIST_INDEX)
				{		
					delete [] indexkey;
					indexkey = NULL;

					globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"IndexMng::buildValueIndex",__FILE__,"Can only support Gist index for tag-stdTag index.");
					return false;
				}

				if (node->getFlag() == ELEMENT_NODE)
				{
					strcpy(indexkey, node->getTag(this->xmlNameTable));
					indexkey = _strlwr(indexkey) ;

					//todo: check if stemming is necessary
					// stemming
					//newPos = stem(indexkey, 0, strlen(indexkey));
					//indexkey[newPos+1] = '\0';

					// create equality query that will find the exact key
					//GT: Test change
					char *t = new char[strlen(indexkey)+1] ;
					strcpy(t, indexkey) ;
					bt_query_t query(bt_query_t::bt_eq, (void *)t, NULL);

					// determine whether there is other entries with the same key in the index
					if (tempGistIndex->count(&query) == 0 && gistIndex->count(&query) == 0)
					{
						termExpansion->expandTerm(indexkey,stdTerm,num);

						// can't find the term in WordNet
						if (num == 0)
						{
							gistret = tempGistIndex->insert(indexkey, indexkey);
							if (gistret != RCOKGist){
								globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"IndexMng::buildValueIndex",__FILE__,"Inserting record to gist.");
								return false;
							}

							gistret = gistIndex->insert(indexkey, indexkey);
							if (gistret != RCOKGist){
								globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"IndexMng::buildValueIndex",__FILE__,"Inserting record to gist.");
								return false;
							}
						}

						for (int k = 0; k < num; k++)
						{
							// added to reduce the number of same entry (syntactically)
							if (strcmp(stdTerm[k],stdTerm[k-1]) == 0)
								continue;
							else
							{
								gistret = tempGistIndex->insert(indexkey, stdTerm[k]);
								if (gistret != RCOKGist){
									globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"IndexMng::buildValueIndex",__FILE__,"Inserting record to gist.");
									return false;
								}

								gistret = gistIndex->insert(stdTerm[k],indexkey);
								if (gistret != RCOKGist){
									globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"IndexMng::buildValueIndex",__FILE__,"Inserting record to gist.");
									return false;
								}

								tempRecordNumber++;
							}							
						}
					}

					// TODO: check this further: delete query here would cause memory problem; indexkey would have some strange character
					//if (query)
					//	delete query;
				}
				else if (node->getFlag() == ATTRIBUTE_NODE)
				{
					for (int i=0; i<node->getAttributeNumber(); i++) 
					{
						char * indexkeyatt;
						((DM_AttributeNode*) node)->getAttr(i, indexkeyatt);

						//todo: check if stemming is necessary
						// stemming
						//newPos = stem(indexkeyatt, 0, strlen(indexkeyatt));
						//indexkeyatt[newPos+1] = '\0';

						// create equality query that will find the exact key
						//GT: Test change
						char *t = new char[strlen(indexkeyatt)+1] ;
						strcpy(t, indexkeyatt) ;
						bt_query_t query (bt_query_t::bt_eq, (void *)t, NULL);

						if (tempGistIndex->count(&query) == 0)
						{
							termExpansion->expandTerm(indexkeyatt,stdTerm,num);

							if (num == 0)
							{
								gistret = tempGistIndex->insert(indexkeyatt, indexkeyatt);

								if (gistret != RCOKGist){
									globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"IndexMng::buildValueIndex",__FILE__,"Inserting record to gist.");
									return false;
								}

								gistret = gistIndex->insert(indexkeyatt,indexkeyatt);
								if (gistret != RCOKGist){
									globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"IndexMng::buildValueIndex",__FILE__,"Inserting record to gist.");
									return false;
								}
							}

							for (int k = 0; k < num; k++)
							{
								gistret = tempGistIndex->insert(indexkeyatt, stdTerm[k]);
								if (gistret != RCOKGist){
									globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"IndexMng::buildValueIndex",__FILE__,"Inserting record to gist.");
									return false;
								}

								gistret = gistIndex->insert(stdTerm[k],indexkeyatt);
								if (gistret != RCOKGist){
									globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"IndexMng::buildValueIndex",__FILE__,"Inserting record to gist.");
									return false;
								}
							}

							tempRecordNumber++;
						}
						// TODO: check this further: delete query here would cause memory problem; indexkey would have some strange character
						//if (query)
						//	delete query;

						if (indexkeyatt)
							delete [] indexkeyatt;
					}
				}
			}

			break;

				// Yunyao: added 04-26-05 for supporting ancestor-descendant index
		case VALUEINDEX_NAME_POS:
			{
				if (indexSource != GIST_INDEX)
				{		
					delete [] indexkey;
					indexkey = NULL;

					globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"IndexMng::buildValueIndex",__FILE__,"Can only support Gist index for name pos index.");
					return false;
				}

				if (node->getFlag() == ELEMENT_NODE)
				{
					strcpy(indexkey, node->getTag(this->xmlNameTable));
					
					// create equality query that will find the exact key
					char *t = new char[strlen(indexkey)+1] ;
					strcpy(t, indexkey) ;
					bt_query_t query (bt_query_t::bt_eq, (void *)t, NULL);

					// determine whether there is other entries with the same key in the index
					if (gistIndex->count(&query) == 0)
					{
						gistret = gistIndex->insert(indexkey, tempRecordNumber);
						if (gistret != RCOKGist){
							globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"IndexMng::buildValueIndex",__FILE__,"Inserting record to gist.");
							return false;
						}

						tempRecordNumber++;
					}

				}
				//TODO: uncomment the following to support index on attribute name - pos
				/*-----------------------------------------------------------------------
				else if (node->getFlag() == ATTRIBUTE_NODE)
				{
					for (i=0; i<node->getAttributeNumber(); i++) 
					{
						char * indexkeyatt;
						((DM_AttributeNode*) node)->getAttr(i, indexkeyatt);

						// create equality query that will find the exact key
						bt_query_t query (bt_query_t::bt_eq, (void *)indexkeyatt, NULL);
						
						if (gistIndex->count(query) == 0)
						{
							gistret = gistIndex->insert(indexkeyatt, &tempRecordNumber);
							
							if (gistret != RCOKGist)
							{
								globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"IndexMng::buildValueIndex",__FILE__,"Inserting record to gist.");
								return false;
							}

							tempRecordNumber++;
						}
						// TODO: check this further: 
						//       delete query here would cause memory problem; 
						//       indexkey would have some strange character
						//if (query)
						//	delete query;

						if (indexkeyatt)
							delete [] indexkeyatt;
					}
				}
				-----------------------------------------------------------------------*/

				break;
			}

		// Yunyao: added 04-26-05
		//---------------------------------------------------------------------------------
		case VALUEINDEX_ANCESTOR_DESCENDANT_SUMMARIZATION:
			{
				if (indexSource != GIST_INDEX)
				{		
					delete [] indexkey;
					indexkey = NULL;

					globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"IndexMng::buildValueIndex",__FILE__,"Can only support Gist index for name pos index.");
					return false;
				}

				// If the stack is empty, or the node to be added is a child of the current stack 
				// simply push the node onto the stack
				if (stackTop == -1 || nodeStack[stackTop].isParentOf(&indexbody))
				{
					stackTop++;
					nodeStack[stackTop].SetStartPos(indexbody.GetStartPos());
					nodeStack[stackTop].SetEndPos(indexbody.GetEndPos());
					nodeStack[stackTop].SetLevel(indexbody.GetLevel());


					descMap[stackTop].reset(); 
					strcpy(indexkey, node->getTag(this->xmlNameTable));
					
					resetCursor(cursor);
					eof = false;

					if (cursor.iter)
					{
						delete cursor.iter;
						cursor.iter = NULL;
					}

					query->val1 = indexkey;
					
					gistret = mapGistIndex->fetch_init(cursor, query);
					if (gistret)
					{
						globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"Evaluator",__FILE__,"Problem with intializing fetching from index.");
						return false;
					}

					keysz = (unsigned long)(strlen(indexkey) + 1);

					gistret = mapGistIndex->fetch(cursor,indexkey, keysz, &pos, datasz, eof);

					if (gistret) {
						globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"GistIndexUpdate::insert",__FILE__,"Problems with fetching from index");
					}

					if (eof)
					{
						globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"GistIndexUpdate::insert",__FILE__,"Problem with fetching from index");
						return false;
					}

					descMap[stackTop].set(pos);
				}
				else
				{
					while (!nodeStack[stackTop].isParentOf(&indexbody))
					{
						KeyType k = nodeStack[stackTop].GetStartPos();

						// add the current stackTop node into the index
						gistret = gistIndex->insert(&k, &descMap[stackTop], numTypes);
						if (gistret != RCOKGist){
							globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"IndexMng::buildValueIndex",__FILE__,"Inserting record to gist.");
							return false;
						}

						tempRecordNumber++;
						descMap[stackTop-1] |= descMap[stackTop];
						stackTop--;
					}

					stackTop++;
					nodeStack[stackTop].SetStartPos(indexbody.GetStartPos());
					nodeStack[stackTop].SetEndPos(indexbody.GetEndPos());
					nodeStack[stackTop].SetLevel(indexbody.GetLevel());
					descMap[stackTop].reset(); 

					//char *t = node->getTag(this->xmlNameTable) ;
					//cout << "strlen = " << strlen(t) << endl ;
					strcpy(indexkey, node->getTag(this->xmlNameTable));
					//strcpy(indexkey, t) ;

					resetCursor(cursor);
					eof = false;
					if (cursor.iter)
					{
						delete cursor.iter;
						cursor.iter = NULL;
					}
					
					query->val1 = indexkey;

					gistret = mapGistIndex->fetch_init(cursor, query);
					if (gistret)
					{
						globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"Evaluator",__FILE__,"Problem with intializing fetching from index.");
						return false;
					}

					keysz = (unsigned long)(strlen(indexkey) + 1);
					gistret = mapGistIndex->fetch(cursor,indexkey, keysz, &pos, datasz, eof);

					if (gistret) {
						globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"GistIndexUpdate::insert",__FILE__,"Problems with fetching from index");
					}

					if (eof)
					{
						globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"GistIndexUpdate::insert",__FILE__,"Problem with fetching from index");
						return false;
					}

					descMap[stackTop].set(pos);
				}

				/* 
				// TODO: support attribute node
				*/

				break;
			}
			//---------------------------------------------------------------------------------
			case VALUEINDEX_SKEY_POS_SUMMARIZATION:
			{
				if (indexSource != GIST_INDEX)
				{		
					delete [] indexkey;
					indexkey = NULL;

					globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"IndexMng::buildValueIndex",__FILE__,"Can only support Gist index for name pos index.");
					return false;
				}

				strcpy(indexkey, node->getTag(this->xmlNameTable));
					
				resetCursor(cursor);
				eof = false;

				if (cursor.iter)
				{
					delete cursor.iter;
					cursor.iter = NULL;
				}

				strcpy((char *)query->val1,node->getTag(this->xmlNameTable));
					
				gistret = mapGistIndex->fetch_init(cursor, query);
				if (gistret)
				{
					globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"Evaluator",__FILE__,"Problem with intializing fetching from index.");
					return false;
				}

				keysz = (unsigned long)(strlen(indexkey) + 1);

				gistret = mapGistIndex->fetch(cursor,indexkey, keysz, &pos, datasz, eof);

				if (gistret) {
					globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"GistIndexUpdate::insert",__FILE__,"Problems with fetching from index");
				}

				if (eof)
				{
					globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"GistIndexUpdate::insert",__FILE__,"Problem with fetching from index");
					return false;
				}

				KeyType k = node->getKey();

				// add the current stackTop node into the index
				gistret = gistIndex->insert(&k, &pos, sizeof(int));
				if (gistret != RCOKGist){
					globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"IndexMng::buildValueIndex",__FILE__,"Inserting record to gist.");
					return false;
				}

				tempRecordNumber++;

				/* 
				// TODO: support attribute node
				*/

				break;
			}
			//---------------------------------------------------------------------------------


		case VALUEINDEX_ELEMENTTAG:
			{
				int indexkeyint = node->getTag();
				if (indexSource == SHORE_INDEX)
				{
					rc = indexp->insert(&indexkeyint, &indexbody);
					if (rc)
					{
						globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"IndexMng::buildValueIndex",__FILE__,"Inserting record to shore.");
						return false;
					}
				}
				else if (indexSource == GIST_INDEX)
				{
					gistret = gistIndex->insert(&indexkeyint, &indexbody);
					if (gistret != RCOKGist){
						globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"IndexMng::buildValueIndex",__FILE__,"Inserting record to gist.");
						return false;
					}
				}
				else 
				{
					//not support hash
					globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"IndexMng::buildValueIndex",__FILE__,"Does not support specified source type index for this type of index.");
					return false;
				}
			}
			break;

		case VALUEINDEX_ELEMENTTAGSTR:
			{
				strcpy(indexkey, node->getTag(this->xmlNameTable));
				if (indexSource == SHORE_INDEX)
				{
					rc = indexp->insert(indexkey, &indexbody);
					if (rc)
					{
						globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"IndexMng::buildValueIndex",__FILE__,"Inserting record to shore.");
						return false;
					}
				}
				else if (indexSource == GIST_INDEX)
				{
					gistret = gistIndex->insert(indexkey, &indexbody);
					if (gistret != RCOKGist){
						globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"IndexMng::buildValueIndex",__FILE__,"Inserting record to gist.");
						return false;
					}
				}
				else 
				{
					//not support hash
					globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"IndexMng::buildValueIndex",__FILE__,"Does not support specified source type index for this type of index.");
					return false;
				}
			}
			break;

		case VALUEINDEX_ATTRIBUTENAME:
			{
				for (int i=0; i<node->getAttributeNumber(); i++) 
				{
					((DM_AttributeNode*) node)->getAttr(i, indexkey);
					if (indexSource == SHORE_INDEX)
					{
						rc = indexp->insert(indexkey, &indexbody);

						delete [] indexkey;
						indexkey = NULL;

						if (rc)
						{
							globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"IndexMng::buildValueIndex",__FILE__,"Inserting record to shore.");
							return false;
						}
					}
					else if (indexSource == GIST_INDEX)
					{
						gistret = gistIndex->insert(indexkey, &indexbody);

						delete [] indexkey;
						indexkey = NULL;

						if (gistret != RCOKGist){
							globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"IndexMng::buildValueIndex",__FILE__,"Inserting record to gist.");
							return false;
						}
					}
					else 
					{	
						delete [] indexkey;
						indexkey = NULL;

						//not support hash
						globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"IndexMng::buildValueIndex",__FILE__,"Does not support specified source type index for this type of index.");
						return false;
					}
				}
			}
			break;

		case VALUEINDEX_ATTRIBUTEVALUE:
			{
				//char attrname[MAX_ATTRIBUTE_NAME_LENGTH];

				for (int i=0; i<node->getAttributeNumber(); i++) 
				{
					//char* attrname = NULL;
					//Value* attrval = ((DM_AttributeNode*) node)->getAttr(i, attrname);
					//not using attrname below, so use this method:
					Value* attrval = ((DM_AttributeNode*) node)->getAttrAt(i);

					if (indextype == STRING_INDEX)
					{
						strcpy(indexkey ,attrval->valueToString());
						if (case_insensitive) indexkey = _strlwr(indexkey);
						if (indexSource == SHORE_INDEX)
						{
							rc = indexp->insert(indexkey, &indexbody);
							if (rc)
							{
								globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"IndexMng::buildValueIndex",__FILE__,"Inserting record to shore.");
								return false;
							}
						}
						else if (indexSource == GIST_INDEX)
						{
							gistret = gistIndex->insert(indexkey, &indexbody);
							if (gistret != RCOKGist){
								globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"IndexMng::buildValueIndex",__FILE__,"Inserting record to gist.");
								return false;
							}
						}
						else 
						{
							//not support hash
							globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"IndexMng::buildValueIndex",__FILE__,"Does not support specified source type index for this type of index.");
							return false;
						}
					}
					else if (indextype == INT_INDEX)
					{
						int intval = atoi(attrval->getStrValue());
						if (indexSource == SHORE_INDEX) 
						{
							rc = indexp->insert(&intval, &indexbody);
							if (rc)
							{
								globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"IndexMng::buildValueIndex",__FILE__,"Inserting record to shore.");
								return false;
							}
						}
						else if (indexSource == GIST_INDEX)
						{
							gistret = gistIndex->insert(&intval, &indexbody);
							if (gistret != RCOKGist){
								globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"IndexMng::buildValueIndex",__FILE__,"Inserting record to gist.");
								return false;
							}
						}
						else 
						{
							//not support hash
							globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"IndexMng::buildValueIndex",__FILE__,"Does not support specified source type index for this type of index.");
							return false;
						}
					}
					else if (indextype == FLOAT_INDEX)
					{
						float floatval = (float)(atof(attrval->getStrValue()));
						if (indexSource == SHORE_INDEX) 
						{
							rc = indexp->insert(&floatval, &indexbody);
							if (rc)
							{
								globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"IndexMng::buildValueIndex",__FILE__,"Inserting record to shore.");
								return false;
							}
						}
						else if (indexSource == GIST_INDEX)
						{
							gistret = gistIndex->insert(&floatval, &indexbody);
							if (gistret != RCOKGist){
								globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"IndexMng::buildValueIndex",__FILE__,"Inserting record to gist.");
								return false;
							}
						}
						else 
						{
							//not support hash
							globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"IndexMng::buildValueIndex",__FILE__,"Does not support specified source type index for this type of index.");
							return false;
						}
					}
					else if (indextype == DOUBLE_INDEX)
					{
						double doubleval = (double)(atof(attrval->getStrValue()));
						if (indexSource == SHORE_INDEX) 
						{
							rc = indexp->insert(&doubleval, &indexbody);
							if (rc)
							{
								globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"IndexMng::buildValueIndex",__FILE__,"Inserting record to shore.");
								return false;
							}
						}
						else if (indexSource == GIST_INDEX)
						{
							gistret = gistIndex->insert(&doubleval, &indexbody);
							if (gistret != RCOKGist){
								globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"IndexMng::buildValueIndex",__FILE__,"Inserting record to gist.");
								return false;
							}
						}
						else 
						{
							//not support hash
							globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"IndexMng::buildValueIndex",__FILE__,"Does not support specified source type index for this type of index.");
							return false;
						}
					}
				}
			}
			break;

		case VALUEINDEX_TEXTVALUE:
			{

				if (indextype == STRING_INDEX)
				{
					strcpy(indexkey ,((DM_TextNode*) node)->getCharValue());
					if (case_insensitive) indexkey = _strlwr(indexkey);
					if (indexSource == SHORE_INDEX)
					{
						rc = indexp->insert(indexkey, &indexbody);
						if (rc)
						{
							globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"IndexMng::buildValueIndex",__FILE__,"Inserting record to shore.");
							return false;
						}
					}
					else if (indexSource == GIST_INDEX)
					{
						gistret = gistIndex->insert(indexkey, &indexbody);
						if (gistret != RCOKGist){
							globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"IndexMng::buildValueIndex",__FILE__,"Inserting record to gist.");
							return false;
						}
					}
					else 
					{
						//not support hash
						globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"IndexMng::buildValueIndex",__FILE__,"Does not support specified source type index for this type of index.");
						return false;
					}

				}
				else if (indextype == INT_INDEX)
				{
					int intval = atoi(((DM_TextNode*) node)->getCharValue());
					if (indexSource == SHORE_INDEX)
					{
						rc = indexp->insert(&intval, &indexbody);
						if (rc)
						{
							globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"IndexMng::buildValueIndex",__FILE__,"Inserting record to shore.");
							return false;
						}
					}
					else if (indexSource == GIST_INDEX)
					{
						gistret = gistIndex->insert(&intval, &indexbody);
						if (gistret != RCOKGist){
							globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"IndexMng::buildValueIndex",__FILE__,"Inserting record to gist.");
							return false;
						}
					}
					else 
					{
						//not support hash
						globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"IndexMng::buildValueIndex",__FILE__,"Does not support specified source type index for this type of index.");
						return false;
					}
				}
				else if (indextype == FLOAT_INDEX)
				{
					float floatval = (float)(atof(((DM_TextNode*) node)->getCharValue()));
					if (indexSource == SHORE_INDEX) 
					{
						rc = indexp->insert(&floatval, &indexbody);
						if (rc)
						{
							globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"IndexMng::buildValueIndex",__FILE__,"Inserting record to shore.");
							return false;
						}
					}
					else if (indexSource == GIST_INDEX)
					{
						gistret = gistIndex->insert(&floatval, &indexbody);
						if (gistret != RCOKGist){
							globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"IndexMng::buildValueIndex",__FILE__,"Inserting record to gist.");
							return false;
						}
					}
					else 
					{
						//not support hash
						globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"IndexMng::buildValueIndex",__FILE__,"Does not support specified source type index for this type of index.");
						return false;
					}
				}
				else if (indextype == DOUBLE_INDEX)
				{
					double doubleval = (double)(atof(((DM_TextNode*) node)->getCharValue()));
					if (indexSource == SHORE_INDEX) 
					{
						rc = indexp->insert(&doubleval, &indexbody);
						if (rc)
						{
							globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"IndexMng::buildValueIndex",__FILE__,"Inserting record to shore.");
							return false;
						}
					}
					else if (indexSource == GIST_INDEX)
					{
						gistret = gistIndex->insert(&doubleval, &indexbody);
						if (gistret != RCOKGist){
							globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"IndexMng::buildValueIndex",__FILE__,"Inserting record to gist.");
							return false;
						}
					}
					else 
					{
						//not support hash
						globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"IndexMng::buildValueIndex",__FILE__,"Does not support specified source type index for this type of index.");
						return false;
					}
				}
			}
			break;

		case VALUEINDEX_ATTRIBUTECONTENT:
			{
				KeyType attrnodekey = ((DM_ElementNode*) node)->getAttributes();
				DM_DataNode* attrnode = this->pDataMng->fetchDataNodeFromDBFile((const FileInfoType)*fileinfo, attrnodekey);
				if (!attrnode) break;
				Value* attrval = ((DM_AttributeNode*) attrnode)->getAttr(strval);
				if (indextype == STRING_INDEX)
				{
					strcpy(indexkey ,attrval->getStrValue());
					if (case_insensitive) indexkey = _strlwr(indexkey);
					if (indexSource == SHORE_INDEX)
					{
						rc = indexp->insert(indexkey, &indexbody);
						if (rc)
						{
							globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"IndexMng::buildValueIndex",__FILE__,"Inserting record to shore.");
							return false;
						}
					}
					else if (indexSource == GIST_INDEX)
					{
						gistret = gistIndex->insert(indexkey, &indexbody);
						if (gistret != RCOKGist){
							globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"IndexMng::buildValueIndex",__FILE__,"Inserting record to gist.");
							return false;
						}
					}
					else 
					{
						//not support hash
						globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"IndexMng::buildValueIndex",__FILE__,"Does not support specified source type index for this type of index.");
						return false;
					}
				}
				else if (indextype == INT_INDEX)
				{
					int intval = atoi(attrval->getStrValue());
					if (indexSource == SHORE_INDEX) 
					{
						rc = indexp->insert(&intval, &indexbody);
						if (rc)
						{
							globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"IndexMng::buildValueIndex",__FILE__,"Inserting record to shore.");
							return false;
						}
					}
					else if (indexSource == GIST_INDEX)
					{
						gistret = gistIndex->insert(&intval, &indexbody);
						if (gistret != RCOKGist){
							globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"IndexMng::buildValueIndex",__FILE__,"Inserting record to gist.");
							return false;
						}
					}
					else 
					{
						//not support hash
						globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"IndexMng::buildValueIndex",__FILE__,"Does not support specified source type index for this type of index.");
						return false;
					}
				}
				else if (indextype == FLOAT_INDEX)
				{
					float floatval = (float)(atof(attrval->getStrValue()));
					if (indexSource == SHORE_INDEX) 
					{
						rc = indexp->insert(&floatval, &indexbody);
						if (rc)
						{
							globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"IndexMng::buildValueIndex",__FILE__,"Inserting record to shore.");
							return false;
						}
					}
					else if (indexSource == GIST_INDEX)
					{
						gistret = gistIndex->insert(&floatval, &indexbody);
						if (gistret != RCOKGist){
							globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"IndexMng::buildValueIndex",__FILE__,"Inserting record to gist.");
							return false;
						}
					}
					else 
					{
						//not support hash
						globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"IndexMng::buildValueIndex",__FILE__,"Does not support specified source type index for this type of index.");
						return false;
					}
				}
				else if (indextype == DOUBLE_INDEX)
				{
					double doubleval = (double)(atof(attrval->getStrValue()));
					if (indexSource == SHORE_INDEX)
					{
						rc = indexp->insert(&doubleval, &indexbody);
						if (rc)
						{
							globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"IndexMng::buildValueIndex",__FILE__,"Inserting record to shore.");
							return false;
						}
					}
					else if (indexSource == GIST_INDEX)
					{
						gistret = gistIndex->insert(&doubleval, &indexbody);
						if (gistret != RCOKGist){
							globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"IndexMng::buildValueIndex",__FILE__,"Inserting record to gist.");
							return false;
						}
					}
					else 
					{
						//not support hash
						globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"IndexMng::buildValueIndex",__FILE__,"Does not support specified source type index for this type of index.");
						return false;
					}
				}


				delete attrnode;

			}
			break;

		case VALUEINDEX_ELEMENTCONTENT:
			{
				KeyType childkey = ((DM_ElementNode*) node)->getFirstChild();
				while (childkey >= 0)
				{
					DM_DataNode* childnode = this->pDataMng->fetchDataNodeFromDBFile((const FileInfoType)*fileinfo, childkey);
					if (childnode == NULL)
						break;

					if (childnode->getFlag() == TEXT_NODE)
					{
						if (indextype == STRING_INDEX)
						{
							strcpy(indexkey,((DM_TextNode*) childnode)->getCharValue());
							if (case_insensitive) indexkey = _strlwr(indexkey);
							if (indexSource == SHORE_INDEX)
							{
								rc = indexp->insert(indexkey, &indexbody);
								if (rc)
								{
									globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"IndexMng::buildValueIndex",__FILE__,"Inserting record to shore.");
									return false;
								}
							}
							else if (indexSource == GIST_INDEX)
							{
								gistret = gistIndex->insert(indexkey, &indexbody);
								if (gistret != RCOKGist){
									globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"IndexMng::buildValueIndex",__FILE__,"Inserting record to gist.");
									return false;
								}
							}
							else 
							{
								//not support hash
								globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"IndexMng::buildValueIndex",__FILE__,"Does not support specified source type index for this type of index.");
								return false;
							}
						}
						else
						{
							if (indextype == INT_INDEX)
							{
								int intval = atoi(((DM_TextNode*) childnode)->getCharValue());
								if (indexSource == SHORE_INDEX)
								{
									rc = indexp->insert(&intval, &indexbody);
									if (rc)
									{
										globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"IndexMng::buildValueIndex",__FILE__,"Inserting record to shore.");
										return false;
									}
								}
								else if (indexSource == GIST_INDEX)
								{
									gistret = gistIndex->insert(&intval, &indexbody);
									if (gistret != RCOKGist){
										globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"IndexMng::buildValueIndex",__FILE__,"Inserting record to gist.");
										return false;
									}
								}
								else 
								{
									//not support hash
									globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"IndexMng::buildValueIndex",__FILE__,"Does not support specified source type index for this type of index.");
									return false;
								}
							}
							else if (indextype == FLOAT_INDEX)
							{
								float floatval = (float)(atof(((DM_TextNode*) childnode)->getCharValue()));
								if (indexSource == SHORE_INDEX)
								{
									rc = indexp->insert(&floatval, &indexbody);
									if (rc)
									{
										globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"IndexMng::buildValueIndex",__FILE__,"Inserting record to shore.");
										return false;
									}
								}
								else if (indexSource == GIST_INDEX)
								{
									gistret = gistIndex->insert(&floatval, &indexbody);
									if (gistret != RCOKGist){
										globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"IndexMng::buildValueIndex",__FILE__,"Inserting record to gist.");
										return false;
									}
								}
								else 
								{
									//not support hash
									globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"IndexMng::buildValueIndex",__FILE__,"Does not support specified source type index for this type of index.");
									return false;
								}
							}
							else if (indextype == DOUBLE_INDEX)
							{
								double doubleval = (double)(atof(((DM_TextNode*) childnode)->getCharValue()));
								if (indexSource == SHORE_INDEX)
								{
									rc = indexp->insert(&doubleval, &indexbody);
									if (rc)
									{
										globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"IndexMng::buildValueIndex",__FILE__,"Inserting record to shore.");
										return false;
									}
								}
								else if (indexSource == GIST_INDEX)
								{
									gistret = gistIndex->insert(&doubleval, &indexbody);
									if (gistret != RCOKGist){
										globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"IndexMng::buildValueIndex",__FILE__,"Inserting record to gist.");
										return false;
									}
								}
								else 
								{
									//not support hash
									globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"IndexMng::buildValueIndex",__FILE__,"Does not support specified source type index for this type of index.");
									return false;
								}
							}
						}                     
					}

					childkey = childnode->getNextSibling();
					//Multicolor
					//If key is not valid , and it is char node, and attribute key is valid
					if ((!childkey.isValid()) && 
						((childnode->getFlag() == TEXT_NODE) || (childnode->getFlag() == COMMENT_NODE)) &&
						(((DM_CharNode*)childnode)->getAttributes().isValid())) {
							// it is part of the children of Multicolor node
							//go to that attribute node to get next sibling of this char node
							DM_DataNode* attrnode;
							attrnode = this->pDataMng->fetchDataNodeFromDBFile((const FileInfoType)*fileinfo, ((DM_CharNode*)childnode)->getAttributes());
							childkey = ((DM_AttributeNode*)attrnode)->getMCTNextSibling(node->getKey(),childnode->getKey());
							delete attrnode;
						}
						//end Multicolor
						delete childnode;
				} //while childkey >=0
			}
			break;

			/**
			* Inverted Index
			* 
			*   build inverted index on the content of each element node
			*
			*   VALUEINDEX_INVERTEDINDEX_TEXT*: return the textnode itself
			*   VALUEINDEX_INVERTEDINDEX_ELEM*: return parent element node (deprecated)
			*
			* @author Cong Yu
			* @version 1.0
			*
			*/
		case VALUEINDEX_INVERTEDINDEX_TEXT_STEM: // the chosen one!
		case VALUEINDEX_INVERTEDINDEX_TEXT_NOSTEM:
			{
				strcpy(tagname, node->getTag(this->xmlNameTable));

				char* temp_str;
				int strLen = -1, curPos = -1, nextPos = -1, newPos = -1;
				short wordCount;
				DM_DataNode* childnode;

				KeyType childkey = ((DM_ElementNode*) node)->getFirstChild();

				//Yunyao: 01/31/05, added to take tag name into consideration when doing keyword search
				//        Maybe only as temp change to support NaLIX, but may be needed for other keyword search as ell
				//-------------------------------------------------------------
				if (childkey >= 0)
				{
					childnode = this->pDataMng->fetchDataNodeFromDBFile((const FileInfoType)*fileinfo, childkey);
				}
				else
					childnode = node;
				indexbody.SetStartPos(childnode->getKey());
				indexbody.SetEndPos(childnode->getEndKey());
				indexbody.SetLevel(childnode->getLevel());
				memset(indexkey, 0, MAX_WORD_LENGTH);
				strcpy(indexkey, node->getTag(this->xmlNameTable));

				if (case_insensitive) indexkey = _strlwr(indexkey);

				// stem or not stem the all lower case word
				if (index_description == VALUEINDEX_INVERTEDINDEX_TEXT_STEM) {
					newPos = stem(indexkey, 0, (nextPos-curPos-1));
					indexkey[newPos+1] = '\0';
				}

				if (indexSource == SHORE_INDEX)
				{
					rc = indexp->insert(indexkey, &indexbody);
					if (rc)
					{
						globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"IndexMng::buildValueIndex",__FILE__,"Inserting record to shore.");
						return false;
					}
				}
				else if (indexSource == GIST_INDEX)
				{
					gistret = gistIndex->insert(indexkey, &indexbody);
					if (gistret != RCOKGist){
						globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"IndexMng::buildValueIndex",__FILE__,"Inserting record to gist.");
						return false;
					}
				}
				else 
				{
					//not support hash
					globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"IndexMng::buildValueIndex",__FILE__,"Does not support specified source type index for this type of index.");
					return false;
				}
				//---------------------------------------------------------------

				while (childkey >= 0)
				{
					childnode = this->pDataMng->fetchDataNodeFromDBFile((const FileInfoType)*fileinfo, childkey);
					if (childnode == NULL) break;

					if (childnode->getFlag() == TEXT_NODE) {

						indexbody.SetStartPos(childnode->getKey());
						indexbody.SetEndPos(childnode->getEndKey());
						indexbody.SetLevel(childnode->getLevel());

						// temp_str points to the entire content of the element node
						temp_str = ((DM_TextNode*) childnode)->getCharValue();

						strLen = strlen(temp_str);
						curPos = 0;
						wordCount = 0;
						bool stemFlag = false;

						// for each word in the string
						//  1) convert into lower case and stem it
						//  2) check if it is a stop word (or a keyword)
						//  3) insert it into GiST
						while (curPos <= strLen) {

							memset(indexkey, 0, MAX_WORD_LENGTH);

							// fetchNextWord puts a word into indexkey
							// note that curPos may be changed by fetchNextWord
							nextPos = fetchNextWord(temp_str, indexkey, curPos);
							if (curPos >= strLen) break;

							// stem or not stem the all lower case word
							if (index_description == VALUEINDEX_INVERTEDINDEX_TEXT_STEM) {
								stemFlag = true;
								newPos = stem(indexkey, 0, (nextPos-curPos-1));
								// memset(&(indexkey[newPos+1]), 0, (nextPos-curPos-newPos));
								indexkey[newPos+1] = '\0';
							}

							// check against the stop word list
							if ( !isStop(indexkey, stemFlag) ) {

								indexbody.SetOffset(wordCount);
								//indexbody.seckey = (int)seckey;
								//// don't count <bm> as part of article
								//indexbody.articlekey = isbm ? -1 : (int)articlekey;

#ifdef CHECK_TIME
								// no duplicating
								st = clock();
#endif

								if (case_insensitive) indexkey = _strlwr(indexkey);

								if (indexSource == SHORE_INDEX)
								{
									rc = indexp->insert(indexkey, &indexbody);
									if (rc)
									{
										globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"IndexMng::buildValueIndex",__FILE__,"Inserting record to shore.");
										return false;
									}
								}
								else if (indexSource == GIST_INDEX)
								{
									gistret = gistIndex->insert(indexkey, &indexbody);
									if (gistret != RCOKGist){
										globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"IndexMng::buildValueIndex",__FILE__,"Inserting record to gist.");
										return false;
									}
								}
								else 
								{
									//not support hash
									globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"IndexMng::buildValueIndex",__FILE__,"Does not support specified source type index for this type of index.");
									return false;
								}
#ifdef CHECK_TIME
								et = clock();
								indexTime += (et - st) / ( CLOCKS_PER_SEC / (double)1000.0);
#endif
							}
							wordCount++;
							curPos = nextPos;

						} // end of while (curPos <= strLen)
					} // end of if (childnode->getFlag() == TEXT_NODE)

					childkey = childnode->getNextSibling();
					//Multicolor
					//If key is not valid , and it is char node, and attribute key is valid
					if ((!childkey.isValid()) && 
						((childnode->getFlag() == TEXT_NODE) || (childnode->getFlag() == COMMENT_NODE)) &&
						(((DM_CharNode*)childnode)->getAttributes().isValid())) {
							// it is part of the children of Multicolor node
							//go to that attribute node to get next sibling of this char node
							DM_DataNode* attrnode;
							attrnode = this->pDataMng->fetchDataNodeFromDBFile((const FileInfoType)*fileinfo, ((DM_CharNode*)childnode)->getAttributes());
							childkey = ((DM_AttributeNode*)attrnode)->getMCTNextSibling(node->getKey(),childnode->getKey());
							delete attrnode;
						}
						//end Multicolor

						delete childnode;
				}
			}
			break;

		case VALUEINDEX_INVERTEDINDEX_ELEM_STEM:
		case VALUEINDEX_INVERTEDINDEX_ELEM_NOSTEM:
			// not used frequently, not support for inex
			{
				// these two inverted index options are deprecated,
				// some functionalities are not supported
				char* temp_str;
				int strLen, curPos, nextPos, newPos;
				short wordCount;
				DM_DataNode* childnode;
				KeyType childkey = ((DM_ElementNode*) node)->getFirstChild();
				while (childkey >= 0)
				{
					childnode = this->pDataMng->fetchDataNodeFromDBFile((const FileInfoType)*fileinfo, childkey);
					if (childnode == NULL) break;

					if (childnode->getFlag() == TEXT_NODE) {

						// temp_str points to the entire content of the element node
						temp_str = ((DM_TextNode*) childnode)->getCharValue();
						strLen = strlen(temp_str);
						curPos = 0;
						wordCount = 0;
						bool stemFlag = false;

						// for each word in the string
						//  1) convert into lower case and stem it
						//  2) check if it is a stop word
						//  3) insert it into GiST
						while (curPos <= strLen) {

							memset(indexkey, 0, MAX_WORD_LENGTH);
							nextPos = fetchNextWord(temp_str, indexkey, curPos);
							//if (strncmp(indexkey,"oneb",4) == 0)
							//   cout<<indexkey<<endl;

							if (curPos >= strLen) break;

							if (index_description == VALUEINDEX_INVERTEDINDEX_ELEM_STEM) {
								stemFlag = true;
								newPos = stem(indexkey, 0, (nextPos-curPos-1));
								// memset(&(indexkey[newPos+1]), 0, (nextPos-curPos-newPos));
								indexkey[newPos+1] = '\0';
							}

							if (case_insensitive) indexkey = _strlwr(indexkey);

							// check against the stop word list
							// Yunyao: removed to support NaLIX
							//if ( !isStop(indexkey, stemFlag) ) {
							indexbody.SetOffset(wordCount);
							if (indexSource == SHORE_INDEX)
							{
								rc = indexp->insert(indexkey, &indexbody);
								if (rc)
								{
									globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"IndexMng::buildValueIndex",__FILE__,"Inserting record to shore.");
									return false;
								}
							}
							else if (indexSource == GIST_INDEX)
							{
								gistret = gistIndex->insert(indexkey, &indexbody);
								if (gistret != RCOKGist){
									globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"IndexMng::buildValueIndex",__FILE__,"Inserting record to gist.");
									return false;
								}
							}
							else 
							{
								//not support hash
								globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"IndexMng::buildValueIndex",__FILE__,"Does not support specified source type index for this type of index.");
								return false;
							}
							// Yunyao: removed to support NaLIX
							//}
							wordCount++;
							curPos = nextPos;
						}
					}            

					childkey = childnode->getNextSibling();

					//If key is not valid , and it is char node, and attribute key is valid
					if ((!childkey.isValid()) && 
						((childnode->getFlag() == TEXT_NODE) || (childnode->getFlag() == COMMENT_NODE)) &&
						(((DM_CharNode*)childnode)->getAttributes().isValid())) {
							// it is part of the children of Multicolor node
							//go to that attribute node to get next sibling of this char node
							DM_DataNode* attrnode;
							attrnode = this->pDataMng->fetchDataNodeFromDBFile((const FileInfoType)*fileinfo, ((DM_CharNode*)childnode)->getAttributes());
							childkey = ((DM_AttributeNode*)attrnode)->getMCTNextSibling(node->getKey(),childnode->getKey());
							delete attrnode;
						}
						//end Multicolor

						delete childnode;
				}
			}
			break;

			// Yunyao: added 01-13-05, to support NaLIX
		case VALUEINDEX_INVERTEDINDEX_TEXT_NAME_STEM:
		case VALUEINDEX_INVERTEDINDEX_TEXT_NAME_NOSTEM:
			{
				//TODO: add attribute also
				if (node->getFlag() == ELEMENT_NODE)
					strcpy(tagname, node->getTag(this->xmlNameTable));
				else
					break;

				char* temp_str;
				int strLen, curPos, nextPos, newPos;
				short wordCount;
				DM_DataNode* childnode;
				KeyType childkey = ((DM_ElementNode*) node)->getFirstChild();
				while (childkey >= 0)
				{
					childnode = this->pDataMng->fetchDataNodeFromDBFile((const FileInfoType)*fileinfo, childkey);
					if (childnode == NULL) break;

					if (childnode->getFlag() == TEXT_NODE) 
					{
						// temp_str points to the entire content of the element node
						temp_str = ((DM_TextNode*) childnode)->getCharValue();

						strLen = strlen(temp_str);
						curPos = 0;
						wordCount = 0;
						bool stemFlag = false;

						// for each word in the string
						//  1) convert into lower case and stem it
						//  2) check if it is a stop word (or a keyword)
						//  3) insert it into GiST
						while (curPos <= strLen) {
							memset(indexkey, 0, MAX_WORD_LENGTH);
							memset(tempIndexkey, 0, MAX_NODETAG_LENGTH + MAX_WORD_LENGTH);

							// fetchNextWord puts a word into indexkey
							// note that curPos may be changed by fetchNextWord
							nextPos = fetchNextWord(temp_str, indexkey, curPos);
							if (curPos >= strLen) break;

							// stem or not stem the all lower case word
							if (index_description == VALUEINDEX_INVERTEDINDEX_TEXT_NAME_STEM) {
								stemFlag = true;
								newPos = stem(indexkey, 0, (nextPos-curPos-1));
								// memset(&(indexkey[newPos+1]), 0, (nextPos-curPos-newPos));
								indexkey[newPos+1] = '\0';
							}

							// check against the stop word list
							if ( !isStop(indexkey, stemFlag) ) {

#ifdef CHECK_TIME
								// no duplicating
								st = clock();
#endif

								if (case_insensitive) indexkey = _strlwr(indexkey);

								if (indexSource == SHORE_INDEX)
								{
									rc = indexp->insert(indexkey, &indexbody);
									if (rc)
									{
										globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"IndexMng::buildValueIndex",__FILE__,"Inserting record to shore.");
										return false;
									}
								}
								else if (indexSource == GIST_INDEX)
								{
									strcpy(tempIndexkey, indexkey);
									strcpy(tempIndexkey + strlen(indexkey), tagname);
									// create equality query that will find the exact key
									char *t = new char[strlen(tempIndexkey)+1] ;
									strcpy(t, tempIndexkey) ;
									bt_query_t query(bt_query_t::bt_eq, (void *)t, NULL);

									//cout << "******************" << endl;
									//cout << "Inserting " << indexkey << " in " << tagname << endl;

									// determine whether there is other entries with the same key in the index
									if (tempGistIndex->count(&query) == 0)
									{
										gistret = tempGistIndex->insert(tempIndexkey, "");
										if (gistret != RCOKGist){
											globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"IndexMng::buildValueIndex",__FILE__,"Inserting record to gist.");
											return false;
										}

										gistret = gistIndex->insert(indexkey, tagname);
										if (gistret != RCOKGist){
											globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"IndexMng::buildValueIndex",__FILE__,"Inserting record to gist.");
											return false;
										}
									}
									//else
									//	cout << "Already have " << indexkey << " in " << tagname << endl;
								}
								else 
								{
									//not support hash
									globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"IndexMng::buildValueIndex",__FILE__,"Does not support specified source type index for this type of index.");
									return false;
								}
#ifdef CHECK_TIME
								et = clock();
								indexTime += (et - st) / ( CLOCKS_PER_SEC / (double)1000.0);
#endif
							}
							wordCount++;
							curPos = nextPos;

						} // end of while (curPos <= strLen)
					} // end of if (childnode->getFlag() == TEXT_NODE)

					childkey = childnode->getNextSibling();
					//Multicolor
					//If key is not valid , and it is char node, and attribute key is valid
					if ((!childkey.isValid()) && 
						((childnode->getFlag() == TEXT_NODE) || (childnode->getFlag() == COMMENT_NODE)) &&
						(((DM_CharNode*)childnode)->getAttributes().isValid())) {
							// it is part of the children of Multicolor node
							//go to that attribute node to get next sibling of this char node
							DM_DataNode* attrnode;
							attrnode = this->pDataMng->fetchDataNodeFromDBFile((const FileInfoType)*fileinfo, ((DM_CharNode*)childnode)->getAttributes());
							childkey = ((DM_AttributeNode*)attrnode)->getMCTNextSibling(node->getKey(),childnode->getKey());
							delete attrnode;
						}
						//end Multicolor

						delete childnode;
				}
			}
			break;

		case VALUEINDEX_PARENT:
			{
				//If it is attribute node and it is multicolored, then we need to get all parents
				if ((node->getFlag() == ATTRIBUTE_NODE) && (((DM_AttributeNode*)node)->getMCTNum() > 0)) {
					KeyType* parentarray = NULL;
					KeyType k = node->getKey();
					int parentnum = ((DM_AttributeNode*)node)->getAllParents(parentarray);
					for (int i = 0; i < parentnum ; i++){
						DM_DataNode *parent =  this->pDataMng->fetchDataNodeFromDBFile((const FileInfoType)*fileinfo, parentarray[i]);
						indexbody.SetStartPos(parent->getKey());
						indexbody.SetEndPos(parent->getEndKey());
						indexbody.SetLevel(parent->getLevel());
						indexbody.SetOffset((short)parent->getChildNumber());

						if (indexSource == HASH_INDEX) {
							if (hashIndex->insert(&k, indexbody) == FAILURE) {
								globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"IndexMng::buildValueIndex",__FILE__,"Cannot insert to hash index for building parent index.");
								return false;
							}
						}
						else 
						{
							globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"IndexMng::buildValueIndex",__FILE__,"IndexSource not support for building parent index.");
							return false;
						}

						delete parent;
					}
					delete [] parentarray;
				}

				//If it is text node and multicolored (by seeing attributekey)
				//Fetch attribute node to get all parents like condition above
				else if (((node->getFlag() == TEXT_NODE) || (node->getFlag() == COMMENT_NODE)) 
					&& (((DM_CharNode*)node)->getAttributes().isValid())) {
						DM_DataNode *attrnode =  this->pDataMng->fetchDataNodeFromDBFile((const FileInfoType)*fileinfo, ((DM_CharNode*)node)->getAttributes());
						KeyType* parentarray  = NULL;
						KeyType k = node->getKey();
						int parentnum = ((DM_AttributeNode*)node)->getAllParents(parentarray);
						for (int i = 0; i < parentnum ; i++){
							DM_DataNode *parent =  this->pDataMng->fetchDataNodeFromDBFile((const FileInfoType)*fileinfo, parentarray[i]);
							indexbody.SetStartPos(parent->getKey());
							indexbody.SetEndPos(parent->getEndKey());
							indexbody.SetLevel(parent->getLevel());
							indexbody.SetOffset((short)parent->getChildNumber());

							if (indexSource == HASH_INDEX) {
								if (hashIndex->insert(&k, indexbody) == FAILURE) {
									globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"IndexMng::buildValueIndex",__FILE__,"Cannot insert to hash index for building parent index.");
									return false;
								}
							}
							else 
							{
								globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"IndexMng::buildValueIndex",__FILE__,"IndexSource not support for building parent index.");
								return false;
							}

							delete parent;
						}
						delete [] parentarray;
						delete attrnode;
					}
					//end Multicolor

				else { //else b/c multicolor
					KeyType parentKey = node->getParent();
					if (parentKey != -1)
					{
						DM_DataNode *parent =  this->pDataMng->fetchDataNodeFromDBFile((const FileInfoType)*fileinfo, parentKey);
						if (parent)
						{
							if (parent->getFlag() == ELEMENT_NODE)
							{
								indexbody.SetStartPos(parent->getKey());
								indexbody.SetEndPos(parent->getEndKey());
								indexbody.SetLevel(parent->getLevel());
								indexbody.SetOffset((short)parent->getChildNumber());
								KeyType k = node->getKey();


								if (indexSource == HASH_INDEX) {
									if (hashIndex->insert(&k, indexbody) == FAILURE) {
										globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"IndexMng::buildValueIndex",__FILE__,"Cannot insert to hash index for building parent index.");
										return false;
									}
								}
								else 
								{
									globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"IndexMng::buildValueIndex",__FILE__,"IndexSource not support for building parent index.");
									return false;
								}
							}
							delete parent;
						}
					}
				}//else b/c multicolor
			}
			break;

		default: 
			globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"IndexMng::buildValueIndex",__FILE__,"Illegal Index Description.");
			break;

		} // end of switch (index_description)

		count++;

		if ((count%10000) == 0) 
		{
			char tmpbuf[128];
			_strtime( tmpbuf );
			cout << count << " nodes have been examined   " <<  "OS time:      " << tmpbuf  << endl;
		}
		delete node;

		node = this->pDataMng->scanFetchNext(scaninfo);

	} // end of while (node != NULL)

		// if building anc-desc summarization index, and the nodeStack is not empty
	// insert all the nodes on the node stack into the index
	if (index_description == VALUEINDEX_ANCESTOR_DESCENDANT_SUMMARIZATION)
	{
		while (stackTop > -1)
		{
			if (indexSource != GIST_INDEX)
			{		
				delete [] indexkey;
				indexkey = NULL;

				globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"IndexMng::buildValueIndex",__FILE__,"Can only support Gist index for name pos index.");
				return false;
			}

			KeyType k = nodeStack[stackTop].GetStartPos();

			if (nodeStack[stackTop].GetLevel() == -1)
				cout << "error msg" << endl;

			// add the current stackTop node into the index
			gistret = gistIndex->insert(&k, &descMap[stackTop], numTypes);
			if (gistret != RCOKGist){
				globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"IndexMng::buildValueIndex",__FILE__,"Inserting record to gist.");
				return false;
			}

			tempRecordNumber++;

			if (stackTop > 1)
				descMap[stackTop-1] |= descMap[stackTop];
			stackTop--;
		}

		// not needed, since indexkey will be deleted else where
		//if (query)
		//	delete query;

		indexkey = 0;
	} // end if

	if (index_description == VALUEINDEX_SKEY_POS_SUMMARIZATION)
	{
		indexkey = 0;
	} // end if 

	// create association between the index name and index info. 
	indexinfo = new IndexInfoType;
	strcpy(indexinfo->indexName, indexname);
	strcpy(indexinfo->fileName, filename);
	if (indexSource == SHORE_INDEX) indexinfo->indexID = indexp->getIndexID();
	else indexinfo->indexID = 0;
	indexinfo->indexSource = (indexSource == SHORE_INDEX ? SHORE_INDEX : (indexSource == GIST_INDEX ? GIST_INDEX : HASH_INDEX));
	indexinfo->indexType = indextype;
	indexinfo->indexDescription = index_description;
	indexinfo->indexKeyLength = indexkey_size;
	if (index_description == VALUEINDEX_TAGNAME_ID_PAIR || index_description == VALUEINDEX_ATTRIBUTENAME_ID_PAIR){
		indexinfo->recordNumber = tempRecordNumber;
		indexinfo->isUpdatable = true;
	}
	else {
		indexinfo->recordNumber = (indexSource == SHORE_INDEX ? indexp->getRecordNumber() : (indexSource == GIST_INDEX ? gistIndex->getRecordNumber() : hashIndex->getRecordNumber()));
		indexinfo->isUpdatable = false;
	}

	//not used for value index
	indexinfo->leftSideType = 0;
	strcpy(indexinfo->leftSide,"\0");
	indexinfo->rightSideType = 0;
	strcpy(indexinfo->rightSide,"\0");
	indexinfo->isCaseInsensitive = case_insensitive;

	printf("%d records were inserted into index %s\n", indexinfo->recordNumber, indexname);


	//(indexSource == GIST_INDEX ? gistIndex->getRecordNumber()  :  hashIndex->getRecordNumber() ));   

	//Wrap selection condition to be able to store correctly in Shore
	int scancondLen;
	char* scancondBuffer = scancond->wrap(&scancondLen); //Stupid?? but can't find other way right now
	memcpy(indexinfo->selectionCondition,scancondBuffer,scancondLen);
	indexinfo->selectionConditionLength = scancondLen;
	indexinfo->sc = scancond;
	delete scancondBuffer;

	//Insert scan info into MetaData table
	if ( this->indexNameTable->insertIndex(indexname, indexinfo) == 0 ) {
		if (this->fileIndexTable->insertIndex(filename, indexinfo) != 0) {
			delete indexinfo;
			return false;
		}
	}
	else {
		delete indexinfo;
		return false;
	}
	delete indexinfo;
	delete fileinfo;

	if (index_description == VALUEINDEX_NAME_STANDARDNAME_PAIR || index_description == VALUEINDEX_STANDARDNAME_NAME_PAIR)
	{
		if (termExpansion)
			delete termExpansion;
	}

	if (tagIdIndex) {
		//close calls flush actually:
		//tagIdIndex->flush();
		basicGistIndex->close();
		delete tagIdIndex;
		delete basicGistIndex;
	}

	if (gistIndex) {
		gistIndex->close();
		delete gistIndex;
	}

	if (mapGistIndex)
	{
		mapGistIndex->close();
		delete mapGistIndex;
	}

	if (tempGistIndex)
	{
		tempGistIndex->close();
		delete tempGistIndex;
	}

	if (indexp)
		delete indexp;

	if (indexkey)
		delete [] indexkey;

	if (tempIndexkey)
		delete [] tempIndexkey;

	if (hashIndex)
	{
		if (hashIndex->close() == FAILURE)
			return false;
		delete hashIndex;
	}

	this->pDataMng->clearScan(scaninfo);
	if (indexName)
		strcpy(indexName,indexname);

	return true;
}

/**
* Process Method
*
* Build value join index with given name, based on the data from a file 
* (xml document), and satisfy the index description.
* It reads witness tree results from a file generated by the evaluator.
* It assume that the witness node with nre =1 is the left side, nre = 2 is the right side
*
* @param filename The name of the file (xml document) the index is going to built on.
* @param witnessFileName The name of the witness tree file produced by evaluator evaluated the join conditions.
* @param indexSource is assumed to be only GIST_INDEX.
* @param leftSide The value of th left side (key side) that the index built on
* @param leftSideIndexType The type of the left side predicate (key), either JOININDEX_ELEMENTCONTENT, JOININDEX_ATTRIBUTEVALUE or JOININDEX_ATTRIBUTECONTENT
* @param rightSide The value of th right side (return side) that the index built on
* @param rightSideIndexType The type of the right side predicate (return), either JOININDEX_ELEMENTCONTENT, JOININDEX_ATTRIBUTEVALUE or JOININDEX_ATTRIBUTECONTENT
* @returns Whether the index is created successfully. 
*/
bool IndexMng::buildJoinIndex(char* filename, char* witnessFileName, int indexSource,
							  char* leftSide, int leftSideIndexType, char* rightSide, int rightSideIndexType)
{
	FILE *input;
	rc_tGist ret;
	int count = 0;

	//Get the setting whether we build the content-related index in a case insensitive mode
	bool case_insensitive = gSettings->getBooleanValue("INDEX_CASE_INSENSITIVE",false);

	char indexname[MAX_INDEX_NAME_LENGTH] = "joinindex_";
	char indexNameWithPath[MAX_INDEX_NAME_LENGTH];

	//copy name from portion of witness tree filename
	int  ch = '_';
	char *pdest = strchr( witnessFileName, ch);
	strcpy(indexname+10, pdest+1);

	/*strcpy(indexname+10, filename);
	if (leftSideIndexType == JOININDEX_ELEMENTCONTENT) {
	strcpy(indexname+10+strlen(filename)-4,"_ec_");
	}
	else if (leftSideIndexType == JOININDEX_ATTRIBUTEVALUE) {
	strcpy(indexname+10+strlen(filename)-4,"_av_");
	}
	else if (leftSideIndexType == JOININDEX_ATTRIBUTECONTENT) {
	strcpy(indexname+10+strlen(filename)-4,"_ac_");
	}
	else if (leftSideIndexType == COLORJOININDEX) {
	strcpy(indexname+10+strlen(filename)-4,"_co_");
	}

	strcpy(indexname+10+strlen(filename)-4+4, leftSide);

	if (rightSideIndexType == JOININDEX_ELEMENTCONTENT) {
	strcpy(indexname+10+strlen(filename)-4+4+strlen(leftSide),"_ec_");
	}
	else if (rightSideIndexType == JOININDEX_ATTRIBUTEVALUE) {
	strcpy(indexname+10+strlen(filename)-4+4+strlen(leftSide),"_av_");
	}
	else if (rightSideIndexType == JOININDEX_ATTRIBUTECONTENT) {
	strcpy(indexname+10+strlen(filename)-4+4+strlen(leftSide),"_ac_");
	}
	else if (rightSideIndexType == COLORJOININDEX) {
	strcpy(indexname+10+strlen(filename)-4+4+leftColorLen,"_co_");
	}

	strcpy(indexname+10+strlen(filename)-4+4+leftColorLen+4, rightSide);*/

	IndexInfoType* indexinfo = this->indexNameTable->getIndexInfo(indexname);
	if (indexinfo != NULL) 
	{
		//we do not allow existed index to be overwrittten because of update issues.
		globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"IndexMng::buildJoinIndex",__FILE__,"An index with same name exists in the system.");
		delete indexinfo;
		return false;

		// rebuild the index with the same name
		// remove the old index file and 
		// remove the association of the name and index file
		//this->indexNameTable->deleteIndex(indexname);
		//this->fileIndexTable->deleteIndex(filename, indexname);
		//delete indexinfo;
	}

	GistIndexUpdate *gistIndex = NULL;

	if (indexSource == GIST_INDEX)
	{

		// append path with the indexname
		strcpy(indexNameWithPath,gSettings->getStringValue("GIST_DEFAULT_FILEPATH").c_str());
		strcat(indexNameWithPath,indexname);

		gistIndex = new GistIndexUpdate(indexNameWithPath,&bt_dbl_ext,DOUBLE_INDEX,sizeof(double));
		// remove the previous index file
		remove(indexNameWithPath);
		ret = gistIndex->create();
		if (ret != RCOKGist){
			globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"IndexMng::buildJoinIndex",__FILE__,"After creating index from gist.");
			delete gistIndex;
			return false;
		}
	}
	else{
		globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"IndexMng::buildJoinIndex",__FILE__,"Incorrect index source type (only support gist).");
		return false;
	}
	//read in the witness tree file
	input = fopen(witnessFileName,"r");
	if (!input)
	{
		globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"IndexMng::buildJoinIndex",__FILE__,"Could not open witness tree file.");
		gistIndex->close();
		delete gistIndex;
		return false;
	}

	int num;

	//Assumption: node with nre = 1 is the left side
	//			  node with nre = 2 is the right side
	//scan the input file for the number of nodes in the witness tree
	while (fscanf(input,"%d",&num) != EOF)
	{

		double score;
		KeyType insertKey;
		ListNode insertData;
		//scan the input file for score of witness tree
		if (fscanf(input,"%lf",&score) == EOF)
		{
			globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"IndexMng::buildJoinIndex",__FILE__,"Expecting score in input file.");
			gistIndex->close();
			delete gistIndex;
			break;
		}

		//scan the file for nodes in the witness tree
		for (int i=0; i<num; i++)
		{
			char fName[MAX_XMLFILE_NAME_LENGTH];
			char dummyName[MAX_XMLFILE_NAME_LENGTH];
			KeyType sk,ek;
			int level,offset;
			int localLevel;
			NREType nre;
			char nodeType[2];

			//scan for the type of the node
			if (fscanf(input,"%s",nodeType) == EOF)
			{
				globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"IndexMng::buildJoinIndex",__FILE__,"Expecting node type in input file.");
				gistIndex->close();
				delete gistIndex;
				return false;
			}

			if (strcmp(nodeType,"s") == 0 || strcmp(nodeType,"c") == 0)
			{	//if node is not a dummy node
				//scan for the filename that this node came from
				if (fscanf(input,"%s",fName) == EOF)
				{
					globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"IndexMng::buildJoinIndex",__FILE__,"Expecting file name in input file.");
					gistIndex->close();
					delete gistIndex;
					return false;
				}

				//scan for start key of this node
				if (fscanf(input,"%lf",&sk) == EOF)
				{
					globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"IndexMng::buildJoinIndex",__FILE__,"Expecting start key in input file.");
					gistIndex->close();
					delete gistIndex;
					return false;
				}

				//scan for end key of this node
				if (fscanf(input,"%lf",&ek) == EOF)
				{
					globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"IndexMng::buildJoinIndex",__FILE__,"Expecting end key in input file.");
					gistIndex->close();
					delete gistIndex;
					return false;
				}

				//scan for level of this node
				if (fscanf(input,"%d",&level) == EOF)
				{
					globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"IndexMng::buildJoinIndex",__FILE__,"Expecting level in input file.");
					gistIndex->close();
					delete gistIndex;
					return false;
				}

				//scan for offset of this node
				if (fscanf(input,"%d",&offset) == EOF)
				{
					globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"IndexMng::buildJoinIndex",__FILE__,"Expecting offset in input file.");
					gistIndex->close();
					delete gistIndex;
					return false;
				}

				//scan for nre of this node
				if (fscanf(input,"%d",&nre) == EOF)
				{
					globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"IndexMng::buildJoinIndex",__FILE__,"Expecting NRE in input file.");
					gistIndex->close();
					delete gistIndex;
					return false;
				}

				if (strcmp(nodeType,"c") == 0)
				{
					//scan for level of this node
					if (fscanf(input,"%d",&localLevel) == EOF)
					{
						globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"IndexMng::buildJoinIndex",__FILE__,"Expecting local level in input file.");
						gistIndex->close();
						delete gistIndex;
						return false;
					}
				}

				if (nre == 1) {
					insertKey = sk;
				}
				else if (nre == 2) {
					insertData.SetStartPos(sk);
					insertData.SetEndPos(ek);
					insertData.SetLevel((short)level);
					insertData.SetOffset((short)offset);
					insertData.setNRE(nre);
					ret = gistIndex->insert(&insertKey,&insertData);
					if (ret != RCOKGist){
						globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"IndexMng::buildJoinIndex",__FILE__,"After creating index from gist.");
						delete gistIndex;
						return false;
					}
					count++;
					if ((count%10000) == 0) 
					{
						char tmpbuf[128];
						_strtime( tmpbuf );
						cout << count << " results added to index file   " <<  "OS time:      " << tmpbuf  << endl;
					}
				}

			}
			else if (strcmp(nodeType,"d") == 0)
			{
				//its a dummy node, we just pretend to read
				//scan for start key of this node
				if (fscanf(input,"%lf",&sk) == EOF)
				{
					globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"Evaluator",__FILE__,"Expectiong start key in input file.");
					gistIndex->close();
					delete gistIndex;
					return false;
				}

				//scan for nre of this node
				if (fscanf(input,"%d",&nre) == EOF)
				{
					globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"Evaluator",__FILE__,"Expectiong NRE in input file.");
					gistIndex->close();
					delete gistIndex;
					return false;
				}

				//scan for level of this node
				if (fscanf(input,"%d",&localLevel) == EOF)
				{
					globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"Evaluator",__FILE__,"Expectiong local level in input file.");
					gistIndex->close();
					delete gistIndex;
					return false;
				}

				//scan for the dummyname that this node came from
				if (fscanf(input,"%s",dummyName) == EOF)
				{
					globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"Evaluator",__FILE__,"Expectiong dummy name in input file.");
					gistIndex->close();
					delete gistIndex;
					return false;
				}
			}
			else
			{
				globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"Evaluator",__FILE__,"Unrecognized node type in input file.");
				gistIndex->close();
				delete gistIndex;
				return false;
			}
		}//for number of nodes in witness tree
	}//while not eof


	if (input) fclose(input);

	// create association between the index name and index info. 
	indexinfo = new IndexInfoType;
	strcpy(indexinfo->indexName, indexname);
	strcpy(indexinfo->fileName, filename);
	indexinfo->indexSource = GIST_INDEX;
	indexinfo->indexType = DOUBLE_INDEX;
	indexinfo->indexDescription = JOININDEX;
	indexinfo->indexKeyLength = sizeof(double);
	indexinfo->recordNumber =  gistIndex->getRecordNumber();
	indexinfo->isUpdatable = false;
	indexinfo->leftSideType = leftSideIndexType;
	strcpy(indexinfo->leftSide,leftSide);
	indexinfo->rightSideType = rightSideIndexType;
	strcpy(indexinfo->rightSide,rightSide);
	indexinfo->isCaseInsensitive = case_insensitive;

	//not used for join index
	indexinfo->sc = NULL;
	strcpy(indexinfo->selectionCondition,"\0");
	indexinfo->selectionConditionLength = 0;
	indexinfo->indexID = 0;

	printf("%d records were inserted into index %s\n", indexinfo->recordNumber, indexname);


	//Insert scan info into MetaData table
	if ( this->indexNameTable->insertIndex(indexname, indexinfo) == 0 ) {
		if (this->fileIndexTable->insertIndex(filename, indexinfo) != 0) {
			delete indexinfo;
			return false;
		}
	}
	else {
		delete indexinfo;
		return false;
	}
	delete indexinfo;

	if (gistIndex) {
		gistIndex->close();
		delete gistIndex;
	}

	return true;
}

/**
* Process Method
*
* Create a value join query plan from 2-side predicates given
* It assume that the plan created will have witness node with nre =1 as the left side, nre = 2 as the right side
*
* @param filename The name of the file (xml document) the index is going to built on.
* @param planFileName The name of the plan tree file to be written to. (return value)
* @param witnessFileName The name of the witness tree file to be produced by evaluator. (return value)
* @param indexSource is assumed to be only GIST_INDEX.
* @param leftSide The value of th left side (key side) that the index built on
* @param leftSideIndexType The type of the left side predicate (key), either JOININDEX_ELEMENTCONTENT, JOININDEX_ATTRIBUTEVALUE or JOININDEX_ATTRIBUTECONTENT
* @param rightSide The value of th right side (return side) that the index built on
* @param rightSideIndexType The type of the right side predicate (return), either JOININDEX_ELEMENTCONTENT, JOININDEX_ATTRIBUTEVALUE or JOININDEX_ATTRIBUTECONTENT
* @returns Whether the index is created successfully. 
*/
bool IndexMng::createJoinIndexQueryPlan(char* filename, char* planFileName, char* witnessFileName,
										char* leftSide, int leftSideIndexType, char* rightSide,	int rightSideIndexType)
{
	FILE* planFile;
	int leftNRE = 1;
	int rightNRE = 2;

	strcpy(planFileName,"joinindexplan_");
	strcpy(planFileName+14,filename);
	strcpy(planFileName+14+strlen(filename)-4,"_");
	if (leftSideIndexType == JOININDEX_ELEMENTCONTENT) {
		strcpy(planFileName+14+strlen(filename)-4+1,"ec_");
	}
	else if (leftSideIndexType == JOININDEX_ATTRIBUTEVALUE) {
		strcpy(planFileName+14+strlen(filename)-4+1,"av_");
	}
	else if (leftSideIndexType == JOININDEX_ATTRIBUTECONTENT) {
		strcpy(planFileName+14+strlen(filename)-4+1,"ac_");
	}
	else if (leftSideIndexType == COLORJOININDEX) {
		strcpy(planFileName+14+strlen(filename)-4+1,"co_");
	}

	int leftColorLen =0;
	KeyType leftColorRootKey,rightColorRootKey;
	if (leftSideIndexType == COLORJOININDEX) {
		int  ch = '_';
		//extract colorname, after the last _ in leftSide (expect key_colorname, e.g. 2_moviegenre)
		char *pdest = strrchr( leftSide, ch );
		char* stopstring;
		leftColorLen = strlen(pdest+1);
		leftColorRootKey.key = strtod(leftSide,&stopstring);
		strcpy(planFileName+14+strlen(filename)-4+1+3, pdest+1);
		strcpy(planFileName+14+strlen(filename)-4+1+3+leftColorLen,"_");
	}
	else {
		strcpy(planFileName+14+strlen(filename)-4+1+3,leftSide);
		strcpy(planFileName+14+strlen(filename)-4+1+3+strlen(leftSide),"_");
	}

	if (rightSideIndexType == JOININDEX_ELEMENTCONTENT) {
		strcpy(planFileName+14+strlen(filename)-4+1+3+strlen(leftSide)+1,"ec_");
	}
	else if (rightSideIndexType == JOININDEX_ATTRIBUTEVALUE) {
		strcpy(planFileName+14+strlen(filename)-4+1+3+strlen(leftSide)+1,"av_");
	}
	else if (rightSideIndexType == JOININDEX_ATTRIBUTECONTENT) {
		strcpy(planFileName+14+strlen(filename)-4+1+3+strlen(leftSide)+1,"ac_");
	}
	else if (rightSideIndexType == COLORJOININDEX) {
		strcpy(planFileName+14+strlen(filename)-4+1+3+leftColorLen+1,"co_");
	}

	if (rightSideIndexType == COLORJOININDEX) {
		int  ch = '_';
		char* stopstring;
		//extract colorname
		char *pdest = strrchr( rightSide, ch );
		rightColorRootKey.key = strtod(rightSide,&stopstring);
		strcpy(planFileName+14+strlen(filename)-4+1+3+leftColorLen+1+3,pdest+1);
	}
	else strcpy(planFileName+14+strlen(filename)-4+1+3+strlen(leftSide)+1+3,rightSide);

	//witness file
	strcpy(witnessFileName,"joinindexwitness_");
	//copy name from plan name
	int  ch = '_';
	char *pdest = strchr( planFileName, ch);
	strcpy(witnessFileName+17, pdest+1);

	//remove existing files
	remove(planFileName);
	remove(witnessFileName);

	planFile = fopen(planFileName,"w");
	//file writer iterator line to witness tree file (join result)
	fprintf(planFile,"w,%s\n",witnessFileName);
	// projector for nre = 1 (left side), = 2 (right side) only
	fprintf(planFile,"P,2,%d,%d,1\n",leftNRE,rightNRE);

	if ((leftSideIndexType == COLORJOININDEX) && (rightSideIndexType == COLORJOININDEX))
	{
		FileInfoType *fileinfo = this->pDataMng->getFileInfo(filename);

		if (fileinfo == NULL)
		{
			globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"IndexMng::createJoinIndexQueryPlan",__FILE__,"File does not exist, can not build index on it.");
			return false;
		}
		/*
		If we use the copy method, this must be use
		f,1,2,EO,SK,1,-1,NULL,GEN,C,-1,COLORROOTSTARTKEY,NULL,NULL,NULL,EO,SK,1,-1,NULL,LTN,C,-1,COLORROOTENDKEY,NULL,NULL,NULL
		S,1,movdb.xml,0,ELEMENT_NODE,THISNODE,0,0
		else if we use the pararell version of source, this can be use, and should be faster because only range queries
		S,1,movdb.xml,0,ELEMENT_NODE,THISNODE,0,1,COLORROOTSTARTKEY,COLORROOTENDKEY
		*/
		//join line
		fprintf(planFile,"j,10,%d,NULL,%d,NULL,-1,NULL,NULL,EQN,AS,AS,0,NULL,NULL\n",leftNRE,rightNRE);
		//left input
		//fprintf(planFile,"R,-1,K,1,%d,A,E\n",leftNRE+2);
		//fprintf(planFile,"V,%d,A,-1,%d\n",leftNRE,leftNRE+2);
		DM_DataNode* leftColorRoot = this->pDataMng->fetchDataNodeFromDBFile((const FileInfoType)*fileinfo, leftColorRootKey);
		if (leftColorRoot == NULL){
			globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"IndexMng::createJoinIndexQueryPlan",__FILE__,"left input color root node not found.");
			return false;
		}
		//fprintf(planFile,"f,1,2,EO,SK,%d,-1,NULL,GEN,C,-1,%f,NULL,NULL,NULL,EO,SK,%d,-1,NULL,LTN,C,-1,%f,NULL,NULL,NULL\n",leftNRE,leftColorRootKey.toDouble(),leftNRE,leftColorRoot->getEndKey().toDouble());
		//fprintf(planFile,"S,%d,%s,0,ELEMENT_NODE,THISNODE,0,0\n",leftNRE,filename);
		fprintf(planFile,"S,%d,%s,0,ELEMENT_NODE,THISNODE,0,1,%f,%f,0,0\n",leftNRE,filename,leftColorRootKey.toDouble(),leftColorRoot->getEndKey().toDouble());

		//right input
		//fprintf(planFile,"R,-1,K,1,%d,A,E\n",rightNRE+2);
		//fprintf(planFile,"V,%d,A,-1,%d\n",rightNRE,rightNRE+2);
		DM_DataNode* rightColorRoot = this->pDataMng->fetchDataNodeFromDBFile((const FileInfoType)*fileinfo, rightColorRootKey);
		if (rightColorRoot == NULL){
			globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"IndexMng::createJoinIndexQueryPlan",__FILE__,"right input color root node not found.");
			return false;
		}
		//fprintf(planFile,"f,1,2,EO,SK,%d,-1,NULL,GEN,C,-1,%f,NULL,NULL,NULL,EO,SK,%d,-1,NULL,LTN,C,-1,%f,NULL,NULL,NULL\n",rightNRE,rightColorRootKey.toDouble(),rightNRE,rightColorRoot->getEndKey().toDouble());
		//fprintf(planFile,"S,%d,%s,0,ELEMENT_NODE,THISNODE,0,0",rightNRE,filename);
		fprintf(planFile,"S,%d,%s,0,ELEMENT_NODE,THISNODE,0,1,%f,%f,0,0\n",rightNRE,filename,rightColorRootKey.toDouble(),rightColorRoot->getEndKey().toDouble());

		delete leftColorRoot;
		delete rightColorRoot;
		delete fileinfo;
	} //if colorjoin index
	else {
		//create join iterator line
		fprintf(planFile,"j,10,%d,NULL,%d,NULL,-1,",leftNRE,rightNRE);
		if ((leftSideIndexType == JOININDEX_ATTRIBUTEVALUE) || (leftSideIndexType == JOININDEX_ATTRIBUTECONTENT)) {
			fprintf(planFile,"%s,",leftSide);
		}
		else if (leftSideIndexType == JOININDEX_ELEMENTCONTENT) {
			fprintf(planFile,"NULL,");
		}
		else {
			globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"IndexMng::createJoinIndexQueryPlan",__FILE__,"Invalid left side index type.");
			return false;
		}

		if ((rightSideIndexType == JOININDEX_ATTRIBUTEVALUE) || (rightSideIndexType == JOININDEX_ATTRIBUTECONTENT))	{
			fprintf(planFile,"%s,",rightSide);
		}
		else if (rightSideIndexType == JOININDEX_ELEMENTCONTENT) {
			fprintf(planFile,"NULL,");
		}
		else {
			globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"IndexMng::createJoinIndexQueryPlan",__FILE__,"Invalid right side index type.");
			return false;
		}

		//if (compareType == STRING_INDEX) {
		fprintf(planFile,"EQS,"); //always use string because it is content comparison
		//}
		//else {
		//number comparison
		//	fprintf(planFile,"EQN,");
		//}

		if (leftSideIndexType == JOININDEX_ELEMENTCONTENT) {
			fprintf(planFile,"T,");
		}
		else if (leftSideIndexType == JOININDEX_ATTRIBUTEVALUE) {
			fprintf(planFile,"V,");
		}
		else if (leftSideIndexType == JOININDEX_ATTRIBUTECONTENT) {
			fprintf(planFile,"A,");
		}
		else {
			globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"IndexMng::createJoinIndexQueryPlan",__FILE__,"Invalid left side index type.");
			return false;
		}

		if (rightSideIndexType == JOININDEX_ELEMENTCONTENT) {
			fprintf(planFile,"T,1,NULL,NULL\n");
		}
		else if (rightSideIndexType == JOININDEX_ATTRIBUTEVALUE) {
			fprintf(planFile,"V,1,NULL,NULL\n");
		}
		else if (rightSideIndexType == JOININDEX_ATTRIBUTECONTENT) {
			fprintf(planFile,"A,1,NULL,NULL\n");
		}
		else {
			globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"IndexMng::createJoinIndexQueryPlan",__FILE__,"Invalid right side index type.");
			return false;
		}

		//create left side input
		if (leftSideIndexType == JOININDEX_ELEMENTCONTENT) {
			fprintf(planFile,"r,-1,1,");
			//if (compareType == STRING_INDEX)
			fprintf(planFile,"TS,%d,A,NULL,E\n",leftNRE);
			//else
			//	fprintf(planFile,"TN,%d,A,NULL,E\n",leftNRE);

			IndexInfoType* indexinfo = this->getMatchingIndex(filename,VALUEINDEX_ELEMENTTAG, NULL, -1) ;
			fprintf(planFile,"I,%d,%s,%s,GIST,STR,%s\n",leftNRE,indexinfo->indexName,filename,leftSide);
			delete indexinfo;
		}
		else if (leftSideIndexType == JOININDEX_ATTRIBUTEVALUE) {
			fprintf(planFile,"r,-1,1,");
			//if (compareType == STRING_INDEX)
			fprintf(planFile,"VS,%d,A,%s,E\n",leftNRE,leftSide);
			//else
			//	fprintf(planFile,"VN,%d,A,%s,E\n",leftNRE,leftSide);

			IndexInfoType* indexinfo = this->getMatchingIndex(filename,VALUEINDEX_ATTRIBUTENAME, NULL, -1);
			fprintf(planFile,"I,%d,%s,%s,GIST,STR,%s\n",leftNRE,indexinfo->indexName,filename,leftSide);
			delete indexinfo;
		}
		else if (leftSideIndexType == JOININDEX_ATTRIBUTECONTENT) {
			fprintf(planFile,"r,-1,1,");
			//if (compareType == STRING_INDEX)
			fprintf(planFile,"VS,%d,A,%s,E\n",leftNRE+2,leftSide);
			//else
			//	fprintf(planFile,"VN,%d,A,%s,E\n",leftNRE+2,leftSide);

			fprintf(planFile,"V,%d,1A,1,%d\n",leftNRE+2,leftNRE);
			IndexInfoType* indexinfo = this->getMatchingIndex(filename,VALUEINDEX_ATTRIBUTENAME, NULL, -1);
			fprintf(planFile,"I,%d,%s,%s,GIST,STR,%s\n",leftNRE+2,indexinfo->indexName,filename,leftSide);
			delete indexinfo;
		}
		else {
			globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"IndexMng::createJoinIndexQueryPlan",__FILE__,"Invalid left side index type.");
			return false;
		} 

		//create right side input
		if (rightSideIndexType == JOININDEX_ELEMENTCONTENT) {
			fprintf(planFile,"r,-1,1,");
			//if (compareType == STRING_INDEX)
			fprintf(planFile,"TS,%d,A,NULL,E\n",rightNRE);
			//else
			//	fprintf(planFile,"TN,%d,A,NULL,E\n",rightNRE);

			IndexInfoType* indexinfo = this->getMatchingIndex(filename,VALUEINDEX_ELEMENTTAG, NULL, -1);
			fprintf(planFile,"I,%d,%s,%s,GIST,STR,%s\n",rightNRE,indexinfo->indexName,filename,rightSide);
			delete indexinfo;
		}
		else if (rightSideIndexType == JOININDEX_ATTRIBUTEVALUE) {
			fprintf(planFile,"r,-1,1,");
			//if (compareType == STRING_INDEX)
			fprintf(planFile,"VS,%d,A,%s,E\n",rightNRE,rightSide);
			//else
			//	fprintf(planFile,"VN,%d,A,%s,E\n",rightNRE,rightSide);

			IndexInfoType* indexinfo = this->getMatchingIndex(filename,VALUEINDEX_ATTRIBUTENAME, NULL, -1);
			fprintf(planFile,"I,%d,%s,%s,GIST,STR,%s\n",rightNRE,indexinfo->indexName,filename,rightSide);
			delete indexinfo;
		}
		else if (rightSideIndexType == JOININDEX_ATTRIBUTECONTENT) {
			fprintf(planFile,"r,-1,1,");
			//if (compareType == STRING_INDEX)
			fprintf(planFile,"VS,%d,A,%s,E\n",rightNRE+2,rightSide);
			//else
			//	fprintf(planFile,"VN,%d,A,%s,E\n",rightNRE+2,rightSide);

			fprintf(planFile,"V,%d,1A,1,%d\n",rightNRE+2,rightNRE);
			IndexInfoType* indexinfo = this->getMatchingIndex(filename,VALUEINDEX_ATTRIBUTENAME, NULL, -1);
			fprintf(planFile,"I,%d,%s,%s,GIST,STR,%s",rightNRE+2,indexinfo->indexName,filename,rightSide);
			delete indexinfo;
		}
		else {
			globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"IndexMng::createJoinIndexQueryPlan",__FILE__,"Invalid right side index type.");
			return false;
		} 
	}//else not color join index
	fclose(planFile);
	return true;
}

/**
* Process Method
* Delete index from Timber
*
* @param filename The name of the XML document
* @param indexDescription The description of the value index. 
* @param strval The string value that is used for some type of index, e.g. VALUEINDEX_ATTRIBUTECONTENT, VALUEINDEX_ELEMENTCONTENT
* @param indexSource is assumed to be only GIST_INDEX.
* @param indexType is either INT_INDEX, FLOAT_INDEX, or STRING_INDEX.	
* * for join index
* @param leftSide The value of th left side (key side) that the index built on
* @param leftSideIndexType The type of the left side predicate (key), either JOININDEX_ELEMENTCONTENT, JOININDEX_ATTRIBUTEVALUE or JOININDEX_ATTRIBUTECONTENT
* @param rightSide The value of th right side (return side) that the index built on
* @param rightSideIndexType The type of the right side predicate (return), either JOININDEX_ELEMENTCONTENT, JOININDEX_ATTRIBUTEVALUE or JOININDEX_ATTRIBUTECONTENT
* * for multicolor xml
* @param colorName Optional value for the name suffix of multicolor index
* @param rootColor The key of the root of the color tree
* @returns Whether the index is deleted successfully. 
*/
bool IndexMng::deleteIndex(char* filename, int indexDescription, char* strval,int indexSource,int indexType, 
						   char* leftSide,int leftSideIndexType,char* rightSide,	int rightSideIndexType,	
						   char *colorName,	KeyType rootColor)
{
	char indexNameToDelete[100];

	if (this->constructIndexName(filename, indexNameToDelete, indexDescription, strval, indexType, leftSide, leftSideIndexType, rightSide, rightSideIndexType, colorName, rootColor))
	{
		return this->deleteIndex(indexNameToDelete);
	}
	else return false;
}

/**
* Process Method
* Delete index from Timber
* @param indexname The name of the index to be deleted
* @returns Whether the deletion is done successfully
*/
bool IndexMng::deleteIndex(char* indexname)
{
	char indexNameWithPath[MAX_INDEX_NAME_LENGTH];
	rc_t rc;

	// check whether this index exist


	cout << "delete index " << indexname << endl ;

	IndexInfoType* indexinfo = this->indexNameTable->getIndexInfo(indexname);

	if (indexinfo == NULL)
	{
		globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"IndexMng::deleteIndex",__FILE__,"An index does not exist for deletion.");
		return false;
	}

	if (indexinfo->indexSource == SHORE_INDEX){ //for shore we explicitly use the interface to destroy index

		rc = ss_m::destroy_index(this->volumeID, indexinfo->indexID);
		if (rc)
		{
			globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"IndexMng::deleteIndex",__FILE__,"after destroying old index from shore.");
			delete indexinfo;
			return false;
		}
	}
	//for gist, or hash just remove the physical file
	else if (indexinfo->indexSource == HASH_INDEX) {
		strcpy(indexNameWithPath,gSettings->getStringValue("GIST_DEFAULT_FILEPATH").c_str());
		strcat(indexNameWithPath,indexname);
		remove(indexNameWithPath);

		//remove also .tab file
		strcpy(indexNameWithPath,gSettings->getStringValue("GIST_DEFAULT_FILEPATH").c_str());
		strcat(indexNameWithPath,indexname);
		strcat(indexNameWithPath,".tab");
		remove(indexNameWithPath);
	}
	else {
		// append path with the indexname
		strcpy(indexNameWithPath,gSettings->getStringValue("GIST_DEFAULT_FILEPATH").c_str());
		strcat(indexNameWithPath,indexname);
		remove(indexNameWithPath);
	}

	// delete the association of the indexname to it body.
	if (this->indexNameTable->deleteIndex(indexname) == 0) {
		if(this->fileIndexTable->deleteIndex(indexinfo->fileName, indexname) == 0) {
			delete indexinfo;
			return true;
		}
	}
	delete indexinfo;
	return false;
}



/**
* existIndex
*
* Check whether the index of the name given exists in the database
* @param indexName the name of the index
* @returns Boolean value whether an index exists 
*/
bool IndexMng::existIndex(char* indexName)
{
	IndexInfoType* indexinfo = this->indexNameTable->getIndexInfo(indexName);
	if (indexinfo == NULL){
		return false;
	}
	delete indexinfo;
	return true;
}

/*
* Metaretrieval Method
*
* Find the index that match the description and value predicate
* @param filename The name of the XML document
* @param indexDescription The index that want to find its existent in the system
* @param v Right Value of a predicate condition that the index built on
* @param valueType the type of the value
* @returns IndexInfoType of the index that matched the tvalue and description
*/
IndexInfoType* IndexMng::getMatchingIndex(char *filename, int indexDescription, Value *v, int valueType)
{
	int preferIndexType = -1, secondIndexType = -1, thirdIndexType = -1;
	IndexInfoType *first = NULL, *second = NULL, *third = NULL;

	//set type matching priority
	if (valueType == INT_VALUE) {
		preferIndexType = INT_INDEX;
		secondIndexType = DOUBLE_INDEX;
		thirdIndexType = FLOAT_INDEX;
	}
	else if (valueType == REAL_VALUE) {
		preferIndexType = DOUBLE_INDEX;
		secondIndexType = FLOAT_INDEX;
		//thirdIndexType = INT_INDEX;
	}
	else {//(valueType == STRING_VALUE)
		preferIndexType = STRING_INDEX;
	}

	// Loop through all the available indexes
	this->fileIndexTable->startScanIndex(filename);
	IndexInfoType* indexinfo;
	while ((indexinfo = this->fileIndexTable->getNextIndexInfo()) != NULL) {
		// Does this index match our description?
		if (indexinfo->indexDescription == indexDescription) { 
			// If value was passed, check the value, and type of value
			if (v != NULL) {
				SelectionCondition* idxcond = new SelectionCondition(indexinfo->selectionCondition);
				PredicateCondition* idxpred = idxcond->getCondition()->getCondAt(0)->getCondAt(0);
				if (idxpred->getRightValue()->compareValue(VALUE_COMP_OP_EQ,v)) {
					if (valueType != -1) {
						if (indexinfo->indexType == preferIndexType){
							delete idxcond;
							first = indexinfo;
							break;
						}
						else if (indexinfo->indexType == secondIndexType) {
							delete idxcond;
							second = indexinfo;
						}
						else if (indexinfo->indexType == thirdIndexType) {
							delete idxcond;
							third = indexinfo;
						}
						else {
							delete idxcond;
							delete indexinfo;
						}
					}
					else {
						delete idxcond;
						first = indexinfo;
						break;
					}
				}
				else {
					delete idxcond;
					delete indexinfo;
				}
			}
			else if (v == NULL && valueType != -1) {
				//check only index type
				if (indexinfo->indexType == preferIndexType){
					first = indexinfo;
					break;
				}
				else if (indexinfo->indexType == secondIndexType) {
					second = indexinfo;
				}
				else if (indexinfo->indexType == thirdIndexType) {
					third = indexinfo;
				}
				else {
					delete indexinfo;
				}
			}
			else {
				first = indexinfo;
				break;
			}

		}
		else delete indexinfo;
	}
	this->fileIndexTable->closeScanIndex();

	if (first){
		if (second) delete second;
		if (third) delete third;
		return first;
	}
	else if (second) {
		if (third) delete third;
		return second;
	}
	else if (third) {
		return third;
	}
	else {
		return NULL;
	}
}

/*
* Metaretrieval Method
*
* Find the index that match the description and value predicate
* @param filename The name of the XML document
* @param indexDescription The index that want to find its existent in the system (expect JOININDEX)
* @param leftSide Value of a left side (key side) that the index built on
* @param leftSideType Type of a left side (key side) that the index built on see IndexMng_definitions.h
* @param rightSide Value of a right side (return side) that the index built on
* @param rightSideType Type of a right side (return side) that the index built on see IndexMng_definitions.h
* @returns IndexInfoType of the index that matched the value and description
*/
IndexInfoType* IndexMng::getMatchingIndex(char *filename, int indexDescription, 
										  char* leftSide, int leftSideType, char* rightSide, int rightSideType)
{
	// Loop through all the available indexes
	this->fileIndexTable->startScanIndex(filename);
	IndexInfoType* indexinfo;
	while ((indexinfo = this->fileIndexTable->getNextIndexInfo()) != NULL) {
		// Does this index match our description?
		if (indexinfo->indexDescription == indexDescription) { 
			//for join index must check the two sides index join by
			if ((leftSide != NULL) && (leftSideType != NULL) && (rightSide != NULL) && (rightSideType != NULL)){
				if ((strcmp(indexinfo->leftSide,leftSide) == 0) &&
					(indexinfo->leftSideType == leftSideType) &&
					(strcmp(indexinfo->rightSide,rightSide) == 0) &&
					(indexinfo->rightSideType == rightSideType)){
						this->fileIndexTable->closeScanIndex();
						return indexinfo;
					}
			}
			else {
				this->fileIndexTable->closeScanIndex();
				return indexinfo;
			}
		}
		delete indexinfo;
	}
	this->fileIndexTable->closeScanIndex();
	return NULL;
}

/**
* Internal method
* Construct standard index name from the properties of the index
* Usually index_filename_description_type_optionalvalues
* or joinindex_filename_lefttype_left_righttype_right
*
* @param filename The name of the file (xml document) the index is going to built on.
* @param indexName The name of the index created (return value)
* @param indexDescription The description of the value index. 
* @param strval The string value that is used for some type of index, e.g. VALUEINDEX_ATTRIBUTECONTENT, VALUEINDEX_ELEMENTCONTENT
* @param indexType is either INT_INDEX, FLOAT_INDEX, or STRING_INDEX.	
* * for join index
* @param leftSide The value of th left side (key side) that the index built on
* @param leftSideIndexType The type of the left side predicate (key), either JOININDEX_ELEMENTCONTENT, JOININDEX_ATTRIBUTEVALUE or JOININDEX_ATTRIBUTECONTENT
* @param rightSide The value of th right side (return side) that the index built on
* @param rightSideIndexType The type of the right side predicate (return), either JOININDEX_ELEMENTCONTENT, JOININDEX_ATTRIBUTEVALUE or JOININDEX_ATTRIBUTECONTENT
* * for multicolor xml
* @param colorName Optional value for the name suffix of multicolor index
* @param rootColor The key of the root of the color tree
* @returns Whether the name is constructed properly. 
*/
bool IndexMng::constructIndexName(char* fileName,
								  char* indexName,
								  int indexDescription,
								  char* strval,
								  int indexType, 
								  char* leftSide,
								  int leftSideIndexType,
								  char* rightSide,
								  int rightSideIndexType,	
								  char *colorName,
								  KeyType rootColor)
{

	//
	// This code removes the period, but doesn't touch fileName. 
	// TODO: Transform this code to use sprintf
	//
	char tfileName[100] ;
	strcpy(tfileName, fileName) ;
	for (int i = 0 ; i < strlen(tfileName); i++)
	{
		if (tfileName[i] == '.')
		{
			tfileName[i] = 0 ;
			break ;
		}
	}
	
	switch (indexDescription) {
		case VALUEINDEX_ELEMENTTAG:
			{
				strcpy(indexName,"index_");
				strcpy(indexName+6, fileName);
				//Multicolor color index
				//Case of building color index, if rootColor is not the real root key (0)
				if (rootColor == 0) { 
					strcpy(indexName+6+strlen(fileName)-4, "_elementtag");
				}
				else {
					strcpy(indexName+6+strlen(fileName)-4, "_elementtag_");
					strcpy(indexName+6+strlen(fileName)-4+12,colorName);

				}
			}
			break;
		case VALUEINDEX_ELEMENTTAGSTR:
			{
				strcpy(indexName,"index_");
				strcpy(indexName+6, fileName);
				//Multicolor color index
				//Case of building color index, if rootColor is not the real root key (0)
				if (rootColor == 0) { 
					strcpy(indexName+6+strlen(fileName)-4, "_elementtagstr");
				}
				else {
					strcpy(indexName+6+strlen(fileName)-4, "_elementtagstr_");
					strcpy(indexName+6+strlen(fileName)-4+15,colorName);

				}
			}
			break;
		case VALUEINDEX_TAGNAME_ID_PAIR:
			{
				strcpy(indexName,"index_");
				strcpy(indexName+6, fileName);
				strcpy(indexName+6+strlen(fileName)-4, "_tagid");
			}
			break;
		case VALUEINDEX_ATTRIBUTENAME_ID_PAIR:
			{
				strcpy(indexName,"index_");
				strcpy(indexName+6, fileName);
				strcpy(indexName+6+strlen(fileName)-4, "_atagid");
			}
			break;
			// Yunyao Li: 10-20-2004 added to support term expansion
		case VALUEINDEX_NAME_STANDARDNAME_PAIR:
		case VALUEINDEX_STANDARDNAME_NAME_PAIR:
			{
				strcpy(indexName,"index_");
				strcpy(indexName+6, fileName);
				strcpy(indexName+6+strlen(fileName)-4, "_stdtag_tag");
			}
			break;

		case VALUEINDEX_INVERTEDINDEX_TEXT_NAME_STEM:
			sprintf(indexName, "index_%s_invtext_name_s", tfileName) ;
			break ;

		case VALUEINDEX_INVERTEDINDEX_TEXT_NAME_NOSTEM:
			sprintf(indexName, "index_%s_invtext_name_n", tfileName) ;
			break ;

		case VALUEINDEX_ANCESTOR_DESCENDANT_SUMMARIZATION:
			sprintf(indexName, "index_%s_anc_desc", tfileName) ;
			break ;

		case VALUEINDEX_NAME_POS:
			//cout << "VALUEINDEX_NAME_POS: fileName= " << tfileName << endl ;
			sprintf(indexName, "index_%s_name_pos", tfileName) ;
			break ;

		case VALUEINDEX_SKEY_POS_SUMMARIZATION:
			sprintf(indexName, "index_%s_skey_pos", tfileName) ;
			break ;

		case VALUEINDEX_ATTRIBUTENAME:
			{
				strcpy(indexName,"index_");
				strcpy(indexName+6, fileName);
				//Multicolor color index
				//Case of building color index, if rootColor is not the real root key (0)
				if (rootColor == 0) { 
					strcpy(indexName+6+strlen(fileName)-4, "_attrname");
				}
				else {
					strcpy(indexName+6+strlen(fileName)-4, "_attrname_");
					strcpy(indexName+6+strlen(fileName)-4+10,colorName);

				}
			}
			break;
		case VALUEINDEX_ATTRIBUTEVALUE:
			{
				strcpy(indexName,"index_");
				strcpy(indexName+6, fileName);
				if (indexType == INT_INDEX)
				{
					strcpy(indexName+6+strlen(fileName)-4, "_attrvalueint");
				}
				else if (indexType == STRING_INDEX)
				{
					strcpy(indexName+6+strlen(fileName)-4, "_attrvaluestr");
				}
				else if (indexType == FLOAT_INDEX)
				{
					strcpy(indexName+6+strlen(fileName)-4, "_attrvalueflt");
				}
				else  if (indexType == DOUBLE_INDEX)
				{
					strcpy(indexName+6+strlen(fileName)-4, "_attrvaluedbl");
				}
			}
			break;
		case VALUEINDEX_TEXTVALUE:
			{
				strcpy(indexName,"index_");
				strcpy(indexName+6, fileName);
				if (indexType == INT_INDEX)
				{
					strcpy(indexName+6+strlen(fileName)-4, "_textvalueint");
				}
				else if (indexType == STRING_INDEX)
				{
					strcpy(indexName+6+strlen(fileName)-4, "_textvaluestr");
				}
				else if (indexType == FLOAT_INDEX)
				{
					strcpy(indexName+6+strlen(fileName)-4, "_textvalueflt");
				}
				else if (indexType == DOUBLE_INDEX)
				{
					strcpy(indexName+6+strlen(fileName)-4, "_textvaluedbl");
				}
			}
			break;
		case VALUEINDEX_ATTRIBUTECONTENT:
			{
				strcpy(indexName,"index_");
				strcpy(indexName+6, fileName);
				if (indexType == INT_INDEX)
				{
					strcpy(indexName+6+strlen(fileName)-4, "_attributecontentint_");
				}
				else if (indexType == STRING_INDEX)
				{
					strcpy(indexName+6+strlen(fileName)-4, "_attributecontentstr_");
				}
				else if (indexType == FLOAT_INDEX)
				{
					strcpy(indexName+6+strlen(fileName)-4, "_attributecontentflt_");
				}
				else if (indexType == DOUBLE_INDEX)
				{
					strcpy(indexName+6+strlen(fileName)-4, "_attributecontentdbl_");
				}
				strcpy(indexName+6+strlen(fileName)-4+21, strval);
				//Multicolor
				//Case of building color index
				if (rootColor != 0)  {
					strcpy(indexName+6+strlen(fileName)-4+21+strlen(strval), "_");
					strcpy(indexName+6+strlen(fileName)-4+21+strlen(strval)+1,colorName);

				}
			}
			break;
		case VALUEINDEX_ELEMENTCONTENT:
			{
				strcpy(indexName,"index_");
				strcpy(indexName+6, fileName);
				if (indexType == INT_INDEX)
				{
					strcpy(indexName+6+strlen(fileName)-4, "_elementcontentint_");
				}
				else if (indexType == STRING_INDEX)
				{
					strcpy(indexName+6+strlen(fileName)-4, "_elementcontentstr_");
				}
				else if (indexType == FLOAT_INDEX)
				{
					strcpy(indexName+6+strlen(fileName)-4, "_elementcontentflt_");
				}
				else if (indexType == DOUBLE_INDEX)
				{
					strcpy(indexName+6+strlen(fileName)-4, "_elementcontentdbl_");
				}
				strcpy(indexName+6+strlen(fileName)-4+19, strval);
				//Multicolor
				//Case of building color index
				if (rootColor != 0)  {
					strcpy(indexName+6+strlen(fileName)-4+19+strlen(strval), "_");
					strcpy(indexName+6+strlen(fileName)-4+19+strlen(strval)+1,colorName);

				}
			}
			break;
		case VALUEINDEX_INVERTEDINDEX_TEXT_STEM: // primary index
		case VALUEINDEX_INVERTEDINDEX_ELEM_STEM:
		case VALUEINDEX_INVERTEDINDEX_TEXT_NOSTEM:
		case VALUEINDEX_INVERTEDINDEX_ELEM_NOSTEM:
			{

				strcpy(indexName,"index_");
				strcpy(indexName+6, fileName);
				if (indexDescription == VALUEINDEX_INVERTEDINDEX_TEXT_STEM) {
					strcpy(indexName+6+strlen(fileName)-4, "_invtext_s");
				}
				else if (indexDescription == VALUEINDEX_INVERTEDINDEX_TEXT_NOSTEM) {
					strcpy(indexName+6+strlen(fileName)-4, "_invtext_n");
				}
				else if (indexDescription == VALUEINDEX_INVERTEDINDEX_ELEM_NOSTEM) {
					strcpy(indexName+6+strlen(fileName)-4, "_invelem_n");
				}
				else {
					strcpy(indexName+6+strlen(fileName)-4, "_invelem_s");
				}
			}
			break;
		case VALUEINDEX_PARENT:
			{
				strcpy(indexName,"index_");
				strcpy(indexName+6, fileName);
				strcpy(indexName+6+strlen(fileName)-4, "_parent");
			}
			break;
		case JOININDEX: 
			{
				strcpy(indexName,"joinindex_");
				strcpy(indexName+10, fileName);
				if (leftSideIndexType == JOININDEX_ELEMENTCONTENT) {
					strcpy(indexName+10+strlen(fileName)-4,"_ec_");
				}
				else if (leftSideIndexType == JOININDEX_ATTRIBUTEVALUE) {
					strcpy(indexName+10+strlen(fileName)-4,"_av_");
				}
				else if (leftSideIndexType == JOININDEX_ATTRIBUTECONTENT) {
					strcpy(indexName+10+strlen(fileName)-4,"_ac_");
				}
				else if (leftSideIndexType == COLORJOININDEX) {
					strcpy(indexName+10+strlen(fileName)-4,"_co_");
				}

				strcpy(indexName+10+strlen(fileName)-4+4, leftSide);

				if (rightSideIndexType == JOININDEX_ELEMENTCONTENT) {
					strcpy(indexName+10+strlen(fileName)-4+4+strlen(leftSide),"_ec_");
				}
				else if (rightSideIndexType == JOININDEX_ATTRIBUTEVALUE) {
					strcpy(indexName+10+strlen(fileName)-4+4+strlen(leftSide),"_av_");
				}
				else if (rightSideIndexType == JOININDEX_ATTRIBUTECONTENT) {
					strcpy(indexName+10+strlen(fileName)-4+4+strlen(leftSide),"_ac_");
				}
				else if (leftSideIndexType == COLORJOININDEX) {
					strcpy(indexName+10+strlen(fileName)-4+4+strlen(leftSide),"_co_");
				}
				strcpy(indexName+10+strlen(fileName)-4+4+strlen(leftSide)+4, rightSide);
			}
			break;
		default:
			{
				globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"IndexMng::constructIndexName",__FILE__,"Index description not recognized.");
				return false;
			}
			break;
	}
	return true;
}

/**
* Dump Index
* Dump everything from a gist index file int standard cout
* 
* @param indexName Index file name
*/
void IndexMng::dumpIndex(char* indexName)
{
	gist* gistIndex;
	rc_tGist rc;
	char *indexNameWithPath;

	gistIndex = new gist();

	//get path from the settings file
	indexNameWithPath = new char[strlen(gSettings->getStringValue("GIST_DEFAULT_FILEPATH").c_str())+strlen(indexName)+1];

	// append path with the indexname
	strcpy(indexNameWithPath,gSettings->getStringValue("GIST_DEFAULT_FILEPATH").c_str());
	strcat(indexNameWithPath,indexName);

	//check whether the index name is in the system
	bool exist = this->existIndex(indexName);
	if (!exist) {
		globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"IndexMng::dumpIndex",__FILE__,"The index not exist in the system.");
		delete [] indexNameWithPath;
		delete gistIndex;
		return;
	}

	rc = gistIndex->open(indexNameWithPath);
	if (rc)
	{
		globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"IndexMng::dumpIndex",__FILE__,"Could not open index file.");
		delete [] indexNameWithPath;
		delete gistIndex;
		return;
	}

	rc = gistIndex->dump(cout);
	if (rc)
	{
		globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"IndexMng::dumpIndex",__FILE__,"Could not dump index file.");
		delete [] indexNameWithPath;
		delete gistIndex;
		return;
	}

	rc = gistIndex->close();
	if (rc)
	{
		globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"IndexMng::dumpIndex",__FILE__,"Could not close index file.");
		delete [] indexNameWithPath;
		delete gistIndex;
		return;
	}
	delete [] indexNameWithPath;
	delete gistIndex;
	return;
}

/**
* getIndexNamesAndInfo
* Get all indices built on the system with all information
* concatenated in a string
* 
* @param num Counting number of indices (return value)
* @returns Verbose index description, with file name, and other descriptions
*/
char **IndexMng::getIndexNamesAndInfo(int *num)
{
	char **indexArray = NULL;
	int count = 0;
	int fileNum;
	IndexInfoType *indexInfo = NULL;

	char** fileNames = this->pDataMng->getFileNames(&fileNum);

	for (int i=0; i<fileNum; i++)
	{
		fileIndexTable->startScanIndex(fileNames[i]);
		indexInfo = fileIndexTable->getNextIndexInfo();
		while (indexInfo)
		{
			count++;
			delete indexInfo;
			indexInfo =fileIndexTable->getNextIndexInfo();
		}
		fileIndexTable->closeScanIndex();
	}


	if (count == 0)
	{
		*num = 0;
		return NULL;
	}

	indexArray = new char *[count];
	count = 0;
	for (int i=0; i<fileNum; i++)
	{
		fileIndexTable->startScanIndex(fileNames[i]);
		indexInfo =fileIndexTable->getNextIndexInfo();

		char fileName[255] ;
		strcpy(fileName, fileNames[i]) ;
		while (indexInfo)
		{
			char description[500];
			int size;
			memset(description, 0, 500) ;
			getIndexDescription(indexInfo,description,size);
			int fileNameSize = strlen(indexInfo->fileName);

			indexArray[count] = new char[size + fileNameSize + 2];
			sprintf(indexArray[count], "%s,%s", fileName, description) ;
			delete indexInfo;
			count++;
			indexInfo =fileIndexTable->getNextIndexInfo();
		}
		fileIndexTable->closeScanIndex();
	}

	*num = count;

	//clear memory
	delete indexInfo;
	for (int i = 0 ; i < fileNum ; i++) {
		delete [] fileNames[i];
	}
	delete [] fileNames;

	return indexArray;
}

/**
* getIndexNamesAndInfo
* Get all indices built on given filename with all information
* concatenated in a string
* 
* @param filename The name of the document
* @param num Counting number of indices (return value)
* @returns Verbose index description, with file name, and other descriptions
*/
char **IndexMng::getIndexNamesAndInfoForFile(char *fileName, int *num)
{
	char **indexArray = NULL;
	int count = 0;
	IndexInfoType *indexInfo = NULL;

	fileIndexTable->startScanIndex(fileName);
	indexInfo = fileIndexTable->getNextIndexInfo();
	while (indexInfo)
	{
		count++;
		delete indexInfo;
		indexInfo =fileIndexTable->getNextIndexInfo();
	}
	if (count == 0)
	{
		*num = 0;
		return NULL;
	}
	indexArray = new char *[count];
	count = 0;

	fileIndexTable->startScanIndex(fileName);
	indexInfo =fileIndexTable->getNextIndexInfo();

	while (indexInfo)
	{
		char description[300];
		int size;
		memset(description, 0, 300) ;
		getIndexDescription(indexInfo,description,size);
		int fileNameSize = strlen(indexInfo->fileName);

		indexArray[count] = new char[size + fileNameSize + 2];
		sprintf(indexArray[count], "%s,%s", fileName, description) ;
		delete indexInfo;
		count++;
		indexInfo =fileIndexTable->getNextIndexInfo();
	}
	*num = count;
	delete indexInfo;
	return indexArray;
}

/**
* getIndexDescription
* Get the string description of an index from index info type
*
* @param indexInfo The index information
* @param description The string description (return value)
* @param size String length (return value)
*/
void IndexMng::getIndexDescription(IndexInfoType *indexInfo, char *description, int &size)
{
	size = strlen(indexInfo->indexName);
	char descr[200];

	memset(descr, 0, 200) ;

	if (strncmp(indexInfo->indexName,"joinindex",9) == 0)
	{
		strcpy(descr,",Join index built on two sides of predicate.");
	}
	if ( strcmp(indexInfo->indexName+strlen(indexInfo->fileName)-4+7,"elementtag") == 0)
	{
		strcpy(descr,",Index built on element tag. Returned node is element node itself.");
	}
	else if (strncmp(indexInfo->indexName+strlen(indexInfo->fileName)-4+7,"elementtag",10) == 0)
	{
		strcpy(descr,",Index built on specific color element tag. Returned node is element node itself.");
	}
	else if ( strcmp(indexInfo->indexName+strlen(indexInfo->fileName)-4+7,"elementtagstr") == 0)
	{
		strcpy(descr,",Index built on element tag string name. Returned node is element node itself.");
	}
	else if (strncmp(indexInfo->indexName+strlen(indexInfo->fileName)-4+7,"elementtagstr",13) == 0)
	{
		strcpy(descr,",Index built on specific color element tag string name. Returned node is element node itself.");
	}
	else if (strcmp(indexInfo->indexName+strlen(indexInfo->fileName)-4+7,"tagid") == 0)
	{
		strcpy(descr,",Index built on concatenated tagname and id. Returned node is element node itself.");
	}
	else if (strcmp(indexInfo->indexName+strlen(indexInfo->fileName)-4+7,"atagid") == 0)
	{
		strcpy(descr,",Index built on concatenated attribute name and id. Returned node is attribute node itself.");
	}
	else if (strcmp(indexInfo->indexName+strlen(indexInfo->fileName)-4+7,"attrname") == 0)
	{
		strcpy(descr,",Index built attribute names. Returned node is attribute node itself.");
	}
	else if (strcmp(indexInfo->indexName+strlen(indexInfo->fileName)-4+7,"attrvalueint") == 0)
	{
		strcpy(descr,",Index built on integer value of all attributes. Returned node is attribute node itself.");
	}
	else if (strcmp(indexInfo->indexName+strlen(indexInfo->fileName)-4+7,"attrvalueflt") == 0)
	{
		strcpy(descr,",Index built on float value of all attributes. Returned node is attribute node itself.");
	}
	else if (strcmp(indexInfo->indexName+strlen(indexInfo->fileName)-4+7,"attrvaluedbl") == 0)
	{
		strcpy(descr,",Index built on double value of all attributes. Returned node is attribute node itself.");
	}
	else if (strcmp(indexInfo->indexName+strlen(indexInfo->fileName)-4+7,"attrvaluestr") == 0)
	{
		strcpy(descr,",Index built on string value of all attributes. Returned node is attribute node itself.");
	}
	else if (strcmp(indexInfo->indexName+strlen(indexInfo->fileName)-4+7,"textvalueint") == 0)
	{
		strcpy(descr,",Index built on integer value of all text nodes. Returned node is text node itself.");
	}
	else if (strcmp(indexInfo->indexName+strlen(indexInfo->fileName)-4+7,"textvalueflt") == 0)
	{
		strcpy(descr,",Index built on float value of all text nodes. Returned node is text node itself.");
	}
	else if (strcmp(indexInfo->indexName+strlen(indexInfo->fileName)-4+7,"textvaluedbl") == 0)
	{
		strcpy(descr,",Index built on double value of all text nodes. Returned node is text node itself.");
	}
	else if (strcmp(indexInfo->indexName+strlen(indexInfo->fileName)-4+7,"textvaluestr") == 0)
	{
		strcpy(descr,",Index built on string value of all text nodes. Returned node is text node itself.");
	}
	else if (strncmp(indexInfo->indexName+strlen(indexInfo->fileName)-4+7,"attributecontentint",19) == 0)
	{
		sprintf(descr, "%s%s%s",
			",Index built on integer value of attribute ",
			indexInfo->indexName+strlen(indexInfo->fileName)-4+7+20,
			". Returned node is element node that the attributes belong to." ) ;

	}
	else if (strncmp(indexInfo->indexName+strlen(indexInfo->fileName)-4+7,"attributecontentflt",19) == 0)
	{
		sprintf(descr, "%s%s%s",
			",Index built on float value of attribute ",
			indexInfo->indexName-4+7+20,
			". Returned node is element node that the attributes belong to.") ;

	}
	else if (strncmp(indexInfo->indexName+strlen(indexInfo->fileName)-4+7,"attributecontentdbl",19) == 0)
	{
		sprintf(descr, "%s%s%s",
			",Index built on double value of attribute ",
			indexInfo->indexName-4+7+20,
			". Returned node is element node that the attributes belong to.") ;

	}
	else if (strncmp(indexInfo->indexName+strlen(indexInfo->fileName)-4+7,"attributecontentstr",19) == 0)
	{
		sprintf(descr, "%s%s%s",
			",Index built on string value of attribute ",
			indexInfo->indexName-4+7+20,
			". Returned node is element node that the attributes belong to.") ;

	}
	else if (strncmp(indexInfo->indexName+strlen(indexInfo->fileName)-4+7,"elementcontentint",17) == 0)
	{
		sprintf(descr, "%s%s%s",
			",Index built on integer text content of element with tag ",
			indexInfo->indexName-4+7+18,
			". Returned node is element node that is right above the text.") ;

	}
	else if (strncmp(indexInfo->indexName+strlen(indexInfo->fileName)-4+7,"elementcontentflt",17) == 0)
	{
		sprintf(descr, "%s%s%s",
			",Index built on float text content of element with tag ",
			indexInfo->indexName-4+7+18,
			". Returned node is element node that is right above the text.") ;

	}
	else if (strncmp(indexInfo->indexName+strlen(indexInfo->fileName)-4+7,"elementcontentdbl",17) == 0)
	{
		sprintf(descr, "%s%s%s",
			",Index built on double text content of element with tag ",
			indexInfo->indexName-4+7+18,
			". Returned node is element node that is right above the text.") ;

	}
	else if (strncmp(indexInfo->indexName+strlen(indexInfo->fileName)-4+7,"elementcontentstr",17) == 0)
	{
		sprintf(descr, "%s%s%s",
			",Index built on string text content of element with tag ",
			indexInfo->indexName-4+7+18,
			". Returned node is element node that is right above the text." ) ;

	}
	else if (strcmp(indexInfo->indexName+strlen(indexInfo->fileName)-4+7,"invtext_n") == 0)
	{
		strcpy(descr,",Inverted index built on non-stop words in text without stemming. Returned node is text node itself.");
	}
	else if (strcmp(indexInfo->indexName+strlen(indexInfo->fileName)-4+7,"invtext_s") == 0)
	{
		strcpy(descr,",Inverted index built on non-stop words in text with stemming. Returned node is text node itself.");
	}
	else if (strcmp(indexInfo->indexName+strlen(indexInfo->fileName)-4+7,"invelem_n") == 0)
	{
		strcpy(descr,",Inverted index built on non-stop words in text without stemming. Returned node is the element node right above text.");
	}
	else if (strcmp(indexInfo->indexName+strlen(indexInfo->fileName)-4+7,"invelem_s") == 0)
	{
		strcpy(descr,",Inverted index built on non-stop words in text with stemming. Returned node is the element node right above text.");
	}
	else if (strcmp(indexInfo->indexName+strlen(indexInfo->fileName)-4+7,"parent") == 0)
	{
		strcpy(descr,",index built on the parent of a node. Given a start key, returned node is its parent.");
	}
	else if (strcmp(indexInfo->indexName+strlen(indexInfo->fileName)-4+7,"stdtag_tag") == 0)
	{
		strcpy(descr,",index built on the standard term and term in the document (tag name and attribuate name). Given a term by the user, returned node(s) is actual term.");
	}

	sprintf(description, "%s,%s%s", indexInfo->indexName,
		indexInfo->indexType == INT_INDEX ? "i" :
	indexInfo->indexType == STRING_INDEX ? "s" :
	indexInfo->indexType == FLOAT_INDEX ? "f" : "d",
		descr ) ;

	size += strlen(descr) + 2 ;
}

/**
* buildTextFile
* Write node information into a text file
* 
* @param textIndexName Text file name
* @param in The input in ListNode type
*/
void IndexMng::buildTextFile(char *textIndexName,ListNode *in)
{
	FILE *indexFile = fopen(textIndexName,"a");

	fprintf(indexFile,"%lf %lf %d %d\n",in->GetStartPos().toDouble(),
		in->GetEndPos().toDouble(),in->GetLevel(), in->GetOffset());
	fclose(indexFile);
}

/**
* Process Method
*
* @param cursor Scan cursor
*/
void IndexMng::resetCursor(gist_cursor_t  cursor)
{
	cursor.k = 0;
	cursor.io = 0;
	cursor.query = NULL;
	cursor.ext = NULL;
	cursor.cext = NULL;
	cursor.iter = NULL;
	cursor.state = NULL;
}


