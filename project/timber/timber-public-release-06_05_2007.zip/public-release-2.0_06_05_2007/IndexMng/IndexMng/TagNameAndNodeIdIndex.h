/*
COPYRIGHT  (c) 2000-2004 
THE REGENTS OF THE UNIVERSITY OF MICHIGAN
ALL RIGHTS RESERVED

PERMISSION IS GRANTED TO USE, COPY, CREATE DERIVATIVE WORKS AND
REDISTRIBUTE THIS SOFTWARE AND SUCH DERIVATIVE WORKS FOR NONCOMMERCIAL
EDUCATION AND RESEARCH PURPOSES, SO LONG AS NO FEE IS CHARGED, AND SO LONG
AS THE COPYRIGHT NOTICE ABOVE, THIS GRANT OF PERMISSION, AND THE
DISCLAIMER BELOW APPEAR IN ALL COPIES MADE; AND SO LONG AS THE NAME OF THE
UNIVERSITY OF MICHIGAN IS NOT USED IN ANY ADVERTISING OR PUBLICITY
PERTAINING TO THE USE OR DISTRIBUTION OF THIS SOFTWARE WITHOUT SPECIFIC,
WRITTEN PRIOR AUTHORIZATION.

THIS SOFTWARE IS PROVIDED AS IS, WITHOUT REPRESENTATION FROM THE
UNIVERSITY OF MICHIGAN AS TO ITS FITNESS FOR ANY PURPOSE, AND WITHOUT
WARRANTY BY THE UNIVERSITY OF MICHIGAN OF ANY KIND, EITHER EXPRESS OR
IMPLIED, INCLUDING WITHOUT LIMITATION THE IMPLIED WARRANTIES OF
MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE. THE REGENTS OF THE
UNIVERSITY OF MICHIGAN SHALL NOT BE LIABLE FOR ANY DAMAGES, INCLUDING
SPECIAL, INDIRECT, INCIDENTAL, OR CONSEQUENTIAL DAMAGES, WITH RESPECT TO
ANY CLAIM ARISING OUT OF OR IN CONNECTION WITH THE USE OF THE SOFTWARE,
EVEN IF IT HAS BEEN OR IS HEREAFTER ADVISED OF THE POSSIBILITY OF SUCH
DAMAGES.
*/

#pragma once

#include "gist.h"
#include "gist_btree.h"
#include "gist_cursor.h"

#include "float.h"

#include "../../Utilities/ErrorInfoClass.h"
extern ErrorInfoClass globalErrorInfo;
/**
 * TagNameAndNodeIdIndex
 *
 * Gist B-tree index wrapper that stores keys containing
 * the tag name and node id, and supports queries on both
 * tag name and tag name/node id.
 *
 * @author Andrew
 * @version 1.0
 */
using std::string;

class TagNameAndNodeIdIndex
{
public:

	/**
	 * Constructor
	 */
	//TagNameAndNodeIdIndex(void);

	/**
	 * Destructor
	 */
	//~TagNameAndNodeIdIndex(void);

	/**
	 * Inserts a node into the index.
	 *
	 * This method constructs the key for the node using the
	 * specified tag name and node id, and inserts it into
	 * the underlying gist index.
	 *
	 * @param tagName the tag name of the node to insert (cannot contain DELIMITER)
	 * @param nodeId the node id of the node to insert
	 * @param data the data associated with the node
	 * @param dataSize the size of data
	 * @param gistIndex the gist index in which to insert the node
	 *
	 * @return true if the insertion was successful, false otherwise
	 */
	static bool insertNode(const char* tagName, double nodeId, void* data,
							int dataSize, gist* gistIndex);

	/**
	 * Deletes the specified node from the index.
	 *
	 * This method constructs the key for the node using
	 * the specified tag name and node id, and removes it
	 * from the underlying gist index.
	 *
	 * @param tagName the tag name of the node to delete
	 * @param nodeId the node id of the node to delete
	 * @param gistIndex the gist index from which to delete the node
	 *
	 * @return true if the deletion was successful, false otherwise
	 */
	static bool deleteNode(const char* tagName, double nodeId, gist* gistIndex);

	/**
	 * Returns a gist query object that returns all nodes that
	 * have the exact specified tag name.
	 *
	 * This method constructs a range query that retrieves
	 * all keys with the specified tag name.
	 *
	 * @param tagNamePrefix the tag name to query
	 *
	 * @return a bt_query_t representing the query, or NULL
	 *         if this index is uninitialized
	 */
	static bt_query_t* getTagNameQuery(const char* tagNamePrefix);

	/**
	 * Returns a gist query object that returns the node
	 * with the specified tag name and node id.
	 *
	 * This method constructs the key for the node using
	 * the specified tag name and node id, and creates
	 * an equality query.
	 *
	 * @param tagName the tag name to query
	 * @param nodeId the node id to query
	 *
	 * @return a bt_query_t representing the query, or NULL if
	 *         this index is uninitialized
	 */
	static bt_query_t* getTagNameAndNodeIdQuery(const char* tagName, double nodeId);

	/**
	 * Parses the tag name and node id from a key.
	 *
	 * This is the inverse of the createKeyString method.
	 * The tag name and node id will be written to the
	 * specified pointers.  The specified key must be a
	 * valid key of the form:
	 * <tagName><DELIMITER><nodeId><DELIMITER>
	 *
	 * @param key the key to parse
	 * @param tagName pointer to the char* which will hold the tag name
	 * @param nodeId pointer to the double which will hold the node id
	 */
	static void parseKey(const char* key, char** tagName, double* nodeId);

	static int getKeyLength(const char* tagName);

private:
	// delimiter used for concatenating tag names and ids
	static const char DELIMITER = '<';

	// number of digits to the left of the decimal point for node ids
	//static const int NUM_LEFT_DIGITS = 12;
	static const int NUM_LEFT_DIGITS = DBL_DIG + 2;

	// number of digits to the right of the decimal point for node ids
	//static const int NUM_RIGHT_DIGITS = 10;
	static const int NUM_RIGHT_DIGITS = DBL_DIG;

	/**
	 * This is a private helper method used to construct the actual key
	 * that is used when inserting values into the gist index.
	 *
	 * The key is constructed as follows:
	 * <tagName><DELIMITER><nodeId><DELIMITER>
	 *
	 * @param tagName the tag name
	 * @param nodeId the node id
	 *
	 * @return string representing the concatenated key
	 */

	static string createKeyString(const char* tagName, double nodeId);
};

