#include "ContainerClass.h"

ContainerClass::ContainerClass(int size)
{
	this->size = size;
//	container = new char[size];
	Initialize();
}

ContainerClass::~ContainerClass()
{
//	delete [] container;
}

void ContainerClass::Initialize()
{
	addCursor = 0;
	scanCursor = 0;
	oldScanCursor = -1;
}

bool ContainerClass::IsFull()
{
	return (addCursor==size?true:false);
}

bool ContainerClass::IsEmpty()
{
	return (addCursor == 0?true:false);
}

bool ContainerClass::EnoughSpace(int size)
{
	return (this->size - addCursor +1 < size?false:true);
}

bool ContainerClass::ExceedBoundry(int size)
{
	return (scanCursor+size <= addCursor?false:true);
}

bool ContainerClass::ExceedBoundry(int start ,int size)
{
	return (start+size <= addCursor?false:true);
}

int ContainerClass::GetAddCursor()
{
	return addCursor;
}

int ContainerClass::GetScanCursor()
{
	return scanCursor;
}

int ContainerClass::GetOldScanCursor()
{
	return oldScanCursor;
}

void ContainerClass::SetScanCursor(int scanCursor)
{
	this->scanCursor = scanCursor;
}

void ContainerClass::SetAddCursor(int addCursor)
{
	this->addCursor = addCursor;
}


int ContainerClass::AddData(char *newData,int length)
{
	if (newData == NULL)
		return FAILURE;
	if (!(this->EnoughSpace(length)))
		return FAILURE;
	memcpy(container+addCursor,newData,length);
	addCursor+=length;
	return SUCCESS;
}

char *ContainerClass::GetContianer()
{
	return container;
}

int ContainerClass::GetData(int start, int length, char *data)
{
	if (IsEmpty())
		return FAILURE;

	if (!ExceedBoundry(start, length))
	{
		memcpy(data,container+start,length);
		return SUCCESS;
	}
	else
		return FAILURE;
}

int ContainerClass::GetNext(int length, char *data)
{
	if (IsEmpty())
		return FAILURE;

	if (length == 0)
		return FAILURE;

	if (!ExceedBoundry(length))
	{
		oldScanCursor = scanCursor;
		memcpy(data,container+scanCursor,length);
		scanCursor+=length;
		return SUCCESS;
	}
	else
		return FAILURE;
}

char *ContainerClass::GetNextPtr(int length)
{
	if (IsEmpty())
		return NULL;

	if (length == 0)
		return NULL;

	if (!ExceedBoundry(length))
	{
		oldScanCursor = scanCursor;
		scanCursor+=length;
		return container+oldScanCursor;
	}
	else
		return NULL;
}


int ContainerClass::GetSize()
{
	return size;
}

void ContainerClass::CopyContainer(ContainerClass *cont)
{
/*	char tmpStr[PAGESIZE];
	Initialize();
	cont->GetData(0,cont->GetAddCursor(),tmpStr);
	AddData(tmpStr,cont->GetAddCursor());*/
	this->Initialize();
	AddData(cont->GetContianer(),cont->GetAddCursor());
}

	