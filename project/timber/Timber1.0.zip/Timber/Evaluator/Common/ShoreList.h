/*
COPYRIGHT  � 2000-2004 
THE REGENTS OF THE UNIVERSITY OF MICHIGAN
ALL RIGHTS RESERVED

PERMISSION IS GRANTED TO USE, COPY, CREATE DERIVATIVE WORKS AND REDISTRIBUTE THIS SOFTWARE AND SUCH DERIVATIVE WORKS FOR 
NONCOMMERCIAL EDUCATION AND RESEARCH PURPOSES, SO LONG AS NO FEE IS CHARGED, AND SO LONG AS THE COPYRIGHT NOTICE ABOVE, 
THIS GRANT OF PERMISSION, AND THE DISCLAIMER BELOW APPEAR IN ALL COPIES MADE; AND SO LONG AS THE NAME OF THE UNIVERSITY 
OF MICHIGAN IS NOT USED IN ANY ADVERTISING OR PUBLICITY PERTAINING TO THE USE OR DISTRIBUTION OF THIS SOFTWARE WITHOUT 
SPECIFIC, WRITTEN PRIOR AUTHORIZATION.

THIS SOFTWARE IS PROVIDED AS IS, WITHOUT REPRESENTATION FROM THE UNIVERSITY OF MICHIGAN AS TO ITS FITNESS FOR ANY PURPOSE, 
AND WITHOUT WARRANTY BY THE UNIVERSITY OF MICHIGAN OF ANY KIND, EITHER EXPRESS OR IMPLIED, INCLUDING WITHOUT LIMITATION THE 
IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE. THE REGENTS OF THE UNIVERSITY OF MICHIGAN SHALL 
NOT BE LIABLE FOR ANY DAMAGES, INCLUDING SPECIAL, INDIRECT, INCIDENTAL, OR CONSEQUENTIAL DAMAGES, WITH RESPECT TO ANY CLAIM 
ARISING OUT OF OR IN CONNECTION WITH THE USE OF THE SOFTWARE, EVEN IF IT HAS BEEN OR IS HEREAFTER ADVISED OF THE POSSIBILITY 
OF SUCH DAMAGES.
*/

#ifndef __ShoreList_h
#define __ShoreList_h

#include "../../IndexMng/Common/ContainerClass.h"
//extern char shoreListTempBuf[CONTAINER_SIZE + sizeof(serial_t) + 5];


/**
* a linked list of records kept in disk.
* @see ContainerClass
* @author Shurug Al-Khalifa 
* @version 1.0
*/
class ShoreList
{
public:
	/**
	Constructor.
	@param fileID the id of the file that you would like to store the list in.
	@param volumeID is the id of the volume that you are storing file in.
	**/
	ShoreList(serial_t fileID, lvid_t volumeID);

	/**
	Constructor.
	**/
	ShoreList();

	/**
	Destructor.
	**/
	~ShoreList();

	/**
	a buffer used to write the record in.
	**/
	static char *tempBuf;//[CONTAINER_SIZE + sizeof(serial_t) + 5];

	/**
	Access Method.
	@returns true if the list is empty. false otherwise.
	**/
	bool IsEmpty();

	/**
	Access Method.
	@returns the record id of the first record in the list.
	**/
	serial_t GetHead();

	/**
	Access Method.
	@returns the record id of the last record in the list.
	**/
	serial_t GetTail();

	/**
	Process Method.
	Sets the first record in the list to be value of head.
	@param head the record id you want the first record in your list
		to be set to.
	**/
	void SetHead(serial_t head);

	/**
	Process Method.
	Sets the last record in the list to be value of tail.
	@param tail the record id you want the last record in your list
		to be set to.
	**/
	void SetTail(serial_t tail);

	/**
	Process Method.
	Sets the size of the list to be value of size.
	@param size is the new size.
	**/
	void setSize(int size);

	/**
	Process Method.
	Adds a record to the end of the list.
	@param cont is the record you want to add.
	@param nextRecID is the record id of the next record you are planning on 
		storing.
	**/
	int AddToList(ContainerClass *cont, serial_t nextRecID);

	/**
	Process Method.
	initializes the scan cursor.
	**/
	void StartScan();

	/**
	Access Method.
	Gets the next record from list according to the scan cursor.
	@param cont is a container that will hold the read record.
	@return SUCCESS if the record was read. If the end of the list has 
	been reached, it returns FAILURE.
	**/
	int GetNext(ContainerClass *cont);

	/**
	Access Method.
	@returns the number of records in the list.
	**/
	int Size();

	/**
	Access Method.
	@returns the value of the scan cursor.
	**/
	serial_t GetScanCursor();

	/**
	Process Method.
	sets the value of the first record to be stored. call it at the very begining.
	@param currRecID is the id of the first record in the list.
	**/
	void SetCurrRecID(serial_t currRecID);  

	/**
	Access Method.
	@returns the curr Record ID.
	**/
	serial_t GetCurrRecID();

	/**
	Process Method.
	initializes the list.
	**/
	void Initialize();

	/**
	Process Method.
	sets the id of the file to store the list in.
	@param fileID is the new file id.
	**/
	void SetFileID(serial_t fileID);

	/**
	Process Method.
	sets the id of the volume to store the file in.
	@param volumeID is the new volume id.
	**/
	void SetVolumeID(lvid_t volumeID);

	/**
	Process Method.
	appends another list to the end of this list.
	@param appendedList is the list that you want to append.
	**/
	int AppendToList(ShoreList *appendedList);

	/**
	Process Method.
	prepends another list to the begining of this list.
	@param prependedList is the list that you want to prepend.
	@param nextRecID the next record ID.
	**/
	int simplePrependToList(ShoreList *prependedList,serial_t nextRecID);

	/**
	Process Method.
	prepends another list to the begining of this list and adds an element in the
	middle.
	@param prependedList is the list that you want to prepend.
	@param newElement is the element that comes in the middle between the two lists.
	@param nextRecID the next record ID.
	**/
	int complexPrependToList(ShoreList *prependedList,ContainerClass *newElement, 
									 serial_t nextRecID);

	/**
	Process Method.
	copies a new list to this list.
	@param newList is the list you want to copy to this list.
	**/
	void copyList(ShoreList *newList);

	/**
	Process Method.
	copies a new list to this list.
	@param newList is the list you want to copy to this list.
	@param nextRecID the next record ID.
	**/
	int copyList(ShoreList *newList, serial_t nextRecID);

	int prependBuffer(ContainerClass *cont, serial_t nextRecID);

	/**
	Process Method
	@param newScanCursor is the new scan cursor
	--------------------------
	Yunyao - added on 12-15-03
	--------------------------
	**/
	void SetScanCursor(serial_t newScanCursor);
private:
	/**
	the record id of the first record in the list.
	**/
	serial_t head;

	/**
	the record id of the last record in the list.
	**/
	serial_t tail;

	/**
	number of records in the list.
	**/
	int size;

	/**
	id of the file to store the list in.
	**/
	serial_t fileID;

	/**
	id of the volume to store the file in.
	**/
	lvid_t volumeID;

	/**
	the id of the next record to scan.
	**/
	serial_t scanCursor;

	/**
	the id of the next rec to be added to the list.
	**/
	serial_t currRecID;    

	/**
	used in checking shore errors.
	**/
	rc_t rc;

	/**
	an older version of scanCursor.
	**/
	serial_t oldScanCursor;

	/**
	size of buffer that is written to list.
	**/
	int bufSize;

	/**
	numbers of records scanned.
	**/
	int recordsRead;
};


#endif
