/*
COPYRIGHT  � 2000-2004 
THE REGENTS OF THE UNIVERSITY OF MICHIGAN
ALL RIGHTS RESERVED

PERMISSION IS GRANTED TO USE, COPY, CREATE DERIVATIVE WORKS AND REDISTRIBUTE THIS SOFTWARE AND SUCH DERIVATIVE WORKS FOR 
NONCOMMERCIAL EDUCATION AND RESEARCH PURPOSES, SO LONG AS NO FEE IS CHARGED, AND SO LONG AS THE COPYRIGHT NOTICE ABOVE, 
THIS GRANT OF PERMISSION, AND THE DISCLAIMER BELOW APPEAR IN ALL COPIES MADE; AND SO LONG AS THE NAME OF THE UNIVERSITY 
OF MICHIGAN IS NOT USED IN ANY ADVERTISING OR PUBLICITY PERTAINING TO THE USE OR DISTRIBUTION OF THIS SOFTWARE WITHOUT 
SPECIFIC, WRITTEN PRIOR AUTHORIZATION.

THIS SOFTWARE IS PROVIDED AS IS, WITHOUT REPRESENTATION FROM THE UNIVERSITY OF MICHIGAN AS TO ITS FITNESS FOR ANY PURPOSE, 
AND WITHOUT WARRANTY BY THE UNIVERSITY OF MICHIGAN OF ANY KIND, EITHER EXPRESS OR IMPLIED, INCLUDING WITHOUT LIMITATION THE 
IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE. THE REGENTS OF THE UNIVERSITY OF MICHIGAN SHALL 
NOT BE LIABLE FOR ANY DAMAGES, INCLUDING SPECIAL, INDIRECT, INCIDENTAL, OR CONSEQUENTIAL DAMAGES, WITH RESPECT TO ANY CLAIM 
ARISING OUT OF OR IN CONNECTION WITH THE USE OF THE SOFTWARE, EVEN IF IT HAS BEEN OR IS HEREAFTER ADVISED OF THE POSSIBILITY 
OF SUCH DAMAGES.
*/

#include "ComplexListNode.h"
#include "../../Evaluator/Evaluator/EvaluatorClass.h"

/**
 * a complex tree node. part of WitnessTree.
 * @see ListNode
 * @see WitnessTree 
 * @author Shurug Al-Khalifa 
 * @version 1.0
 */
ComplexListNode::ComplexListNode(DataMng *dataMng)
{
    this->dataMng = dataMng;
    initialize();
}

void ComplexListNode::initialize()
{
    listNode.initialize();
    dummy = false;
    localLevel = -1;
//    skip = false;
}

ComplexListNode::~ComplexListNode()
{
}

void ComplexListNode::SetStartPos(KeyType newStartPos)
{
    listNode.SetStartPos(newStartPos);
}

KeyType ComplexListNode::GetStartPos()
{
    return listNode.GetStartPos();
}

void ComplexListNode::SetEndPos(KeyType newEndPos)
{
    listNode.SetEndPos(newEndPos);
}

KeyType ComplexListNode::GetEndPos()
{
    return listNode.GetEndPos();
}

void ComplexListNode::SetLevel(short newLevel)
{
    listNode.SetLevel(newLevel);
}

short ComplexListNode::GetLevel()
{
    return listNode.GetLevel();
}

void ComplexListNode::SetOffset(short newOffset)
{
    listNode.SetOffset(newOffset);
}

short ComplexListNode::GetOffset()
{
    return listNode.GetOffset();
}

NREType ComplexListNode::getNRE()
{
	return listNode.getNRE();
}

void ComplexListNode::setNRE(NREType nre)
{
	listNode.setNRE(nre);
}

void ComplexListNode::SetLocalLevel(short newLevel)
{
    this->localLevel = newLevel;
}

short ComplexListNode::GetLocalLevel()
{
    return this->localLevel;
}

DM_DataNode *ComplexListNode::GetData()
{
    FileIDType fid  = EvaluatorClass::getFileID((int)this->getFileIndex());
    if (fid == -1)
        return NULL;
    if (this->GetStartPos() < 0)
        return NULL;
    else
        return dataMng->getDataNode(fid,this->GetStartPos());
}

void ComplexListNode::SetDummyName(char *newName)
{
    if (!newName)
        return;
    if (strlen(newName) >= MAX_DUMMY_NAME)
    {
        cout<<"Warning: Array limits exceeded. Copying a new string to dummyName in ComplexListNode."<<endl;
        cout<<"new string truncated to fit. Lost "<<(strlen(newName) - MAX_DUMMY_NAME +1)<<" characters."<<endl;
        strncpy(dummyName,newName,MAX_DUMMY_NAME-1);
        dummyName[MAX_DUMMY_NAME-1] = '\0';
    }
    else
        strcpy(dummyName,newName);
}

char *ComplexListNode::GetDummyName()
{
    return dummyName;
}

bool ComplexListNode::IsDummy()
{
    return dummy;
}

void ComplexListNode::SetDummy(bool newDummy)
{
    dummy = newDummy;
}

void ComplexListNode::GetListNode(ListNode *listNode)
{
	*listNode = this->listNode;
}

void ComplexListNode::setListNode(ListNode *listNode)
{
    this->listNode = *listNode;
}
/*
void ComplexListNode::setSkipNode(bool skip)
{
    this->skip = skip;
}

bool ComplexListNode::skipNode()
{
    return skip;
}
*/
ListNode *ComplexListNode::GetListNode()
{
    return &listNode;
}

bool ComplexListNode::isAncsOf(ComplexListNode *potentialDesc)
{
    return this->GetListNode()->isAncsOf(potentialDesc->GetListNode());
}
bool ComplexListNode::isDescOf(ComplexListNode *potentialAncs)
{
    return this->GetListNode()->isDescOf(potentialAncs->GetListNode());
}
bool ComplexListNode::isNotContainedIn(ComplexListNode *someNode)
{
    return this->GetListNode()->isNotContainedIn(someNode->GetListNode());
}
bool ComplexListNode::isParentOf(ComplexListNode *potentialChild)
{
    return this->GetListNode()->isParentOf(potentialChild->GetListNode());
}
bool ComplexListNode::isChildOf(ComplexListNode *potentialParent)
{
    return this->GetListNode()->isChildOf(potentialParent->GetListNode());
}

void ComplexListNode::setFileIndex(char fileIndex)
{
    listNode.setFileIndex(fileIndex);
}

char ComplexListNode::getFileIndex()
{
    return listNode.getFileIndex();
}

void ComplexListNode::setDataMng(DataMng *dataMng)
{
    this->dataMng = dataMng;
}

DataMng *ComplexListNode::getDataMng()
{
    return dataMng;
}
