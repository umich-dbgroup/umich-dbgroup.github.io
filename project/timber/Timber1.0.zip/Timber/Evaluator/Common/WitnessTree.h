/*
COPYRIGHT  � 2000-2004 
THE REGENTS OF THE UNIVERSITY OF MICHIGAN
ALL RIGHTS RESERVED

PERMISSION IS GRANTED TO USE, COPY, CREATE DERIVATIVE WORKS AND REDISTRIBUTE THIS SOFTWARE AND SUCH DERIVATIVE WORKS FOR 
NONCOMMERCIAL EDUCATION AND RESEARCH PURPOSES, SO LONG AS NO FEE IS CHARGED, AND SO LONG AS THE COPYRIGHT NOTICE ABOVE, 
THIS GRANT OF PERMISSION, AND THE DISCLAIMER BELOW APPEAR IN ALL COPIES MADE; AND SO LONG AS THE NAME OF THE UNIVERSITY 
OF MICHIGAN IS NOT USED IN ANY ADVERTISING OR PUBLICITY PERTAINING TO THE USE OR DISTRIBUTION OF THIS SOFTWARE WITHOUT 
SPECIFIC, WRITTEN PRIOR AUTHORIZATION.

THIS SOFTWARE IS PROVIDED AS IS, WITHOUT REPRESENTATION FROM THE UNIVERSITY OF MICHIGAN AS TO ITS FITNESS FOR ANY PURPOSE, 
AND WITHOUT WARRANTY BY THE UNIVERSITY OF MICHIGAN OF ANY KIND, EITHER EXPRESS OR IMPLIED, INCLUDING WITHOUT LIMITATION THE 
IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE. THE REGENTS OF THE UNIVERSITY OF MICHIGAN SHALL 
NOT BE LIABLE FOR ANY DAMAGES, INCLUDING SPECIAL, INDIRECT, INCIDENTAL, OR CONSEQUENTIAL DAMAGES, WITH RESPECT TO ANY CLAIM 
ARISING OUT OF OR IN CONNECTION WITH THE USE OF THE SOFTWARE, EVEN IF IT HAS BEEN OR IS HEREAFTER ADVISED OF THE POSSIBILITY 
OF SUCH DAMAGES.
*/


#ifndef __WitnessTree_h
#define __WitnessTree_h


#include "NRETable.h"
#include "ComplexListNode.h"
class DataMng;
class ListNode;
class ComplexListNode;
#define LIST_NODE         0
#define LIST_NODE_WITH_DATA 1

#define INITIAL_TREE_SIZE_DEFAULT   16

/**
 * A tree that gets passed on the pipe between iterators. 
 * It is an array representation of a tree.
 * It may be a simple tree (its nodes are of type ListNode) where each node is a 
 * set of start key, end key, level and offset.
 * Or it may be a complex tree (its nodes are of type ComplexListNode) where each
 * node is a ListNode and an actual data (from DB) pointer. (and some other stuff).
 * @see ComplexListNode
 * @see ListNode
 * @author Shurug Al-Khalifa 
 * @version 1.0
 */
class WitnessTree
{
public:
    /**
       Constructor.
       @param which is either LIST_NODE or LIST_NODE_WITH_DATA. If it is LIST_NODE, then 
       the tree consists of simple list nodes (startKey, endKey, and level). 
       If it is LIST_NODE_WITH_DATA, then tree nodes are complex and will contain
       data and other information (along with startKey, endKey, and level).
	   @param dataMng an instance of the data manager.
       @param size is the maximum number of nodes in the array currently. This may be
       expanded if needed.
    **/
    WitnessTree(int which = LIST_NODE, DataMng *dataMng = NULL);

    /**
       Destructor.
       Releases memory used by the tree.
    **/
    ~WitnessTree() ;

    /**
       Access Method.
       Prints tree information in a depth-first pre-order manner to the stream. 
    **/
    void dumpBuffer(FILE* stream, bool printNRETable = false);

    /**
       Access Method.
       returns a pointer to tree node number index (depth-first pre-order 
       numbering of tree nodes).
       @param index the node number you wish to get. this method skips skippable nodes.
	   @param override if true, node with index will be returned eventhough it is not used.
       @returns a pointer to node number index.
    **/
    void *findNode(int index, bool override = false);

	void *findNodeNRE(NREType nre);
	void startFindNodesNRE(NREType nre);
	void *getNextNodeNRE();
	int getNextIndexNRE();

	/**
       Access Method.
       returns the actual index of a node (counting skippable nodes).
       @param index the index of the node ignoring skippable nodes.
	   @param override if true, node with index will be returned eventhough it is not used.
       @returns the actual index of the node inthe tree.
    **/
   // int getActualIndex(int index, bool override = false);

	 /**
       Access Method.
       returns a pointer to tree node number index (depth-first pre-order 
       numbering of tree nodes). the index here is the actual index. i.e. skippable nodes are
	   counted.
       @param index the node number you wish to get. this method does not skip skippable nodes.
			therefore, index is the actual index of the node.
	   @param override if true, node with index will be returned eventhough it is not used.
       @returns a pointer to node number index.
    **/
    void *getNodeByIndex(int index, bool override = false);

    /**
       Process Method.
       Appends a number of simple nodes to the array representation of the tree. These 
       are added to the end of the array.
       @param listToAppend is a pointer to an array of nodes that we want to append.
       @param size the number of nodes we want to append.
    **/
    void appendList(ListNode *listToAppend,int size, bool alterNRETable = true);

	/**
       Process Method.
       Assigns the data manager to each node (complexListNodes).
       @param dataMng an instance of the data manager.
    **/
    void assignDataMng(DataMng *dataMng);

    /**
       Process Method.
       Appends a number of complex nodes to the array representation of the tree. These 
       are added to the end of the array.
       @param listToAppend is a pointer to an array of nodes that we want to append.
	   @param dataMng an instance of the data manager.
       @param size the number of nodes we want to append.
    **/
    void appendList(ComplexListNode *listToAppend, DataMng *dataMng,int size, bool alterNRETable = true);

    /**
       Access Method.
       @returns a pointer to the first node in the tree.
    **/
    void *getBuffer();

	/**
       Access Method.
       @returns a pointer to the data manager.
    **/
    DataMng *getDataMng();

    /**
       Process Method.
       Initializes the tree.
    **/
    void initialize();

    /**
       Access Method.
       @returns the number of nodes in the tree without counting skippable nodes.
    **/
    int length();

	/**
       Access Method.
       @returns the number of nodes in the tree counting skippable nodes. i.e. the 
	   actual length of the tree.
    **/
 //   int correctLength();

    /**
       Access Method.
       gets the ancestor that is a given number of levels up of a given node.
       @param index is the index in the tree of the node that we want to get
       its ancs.
       @param levelsUp is the number of levels upwards we should go. A parent 
       is 1 level up.
       @returns the index of the ancestor requested. If it doesn't exist, -1 
       is returned. If index provided is not 
       correct, -1 is returned.
    **/
    int GetAncs(int index,int levelsUp = 1);

    /**
       Access Method.
       gets the ith child of a given node.
       @param index is the index in the tree of the node that we want to get
       its child.
       @param childNum is the number of the child that is to be returned. If
       it is 1, first child is returned. If it is 2, second child... etc.
       if childNum = -1, last child is returned.
	   @param desc if true, don't check the level condition. return a child or desc of node.
       @returns the index of the child requested. If it doesn't exist, -1 
       is returned. If index provided is not 
       correct, -1 is returned.
    **/   
    int GetChild(int index,int childNum = 1, bool desc = false);

    /**
       Access Method.
       gets the following sibling of a given node.
       @param index is the index in the tree of the node that we want to get
       its next sibling.
	   @param desc if true, don't check the level condition. return a sibling or a nephew of node.
       @returns the index of the sibling requested. If it doesn't exist, -1 
       is returned. If index provided is not 
       correct, -1 is returned.
    **/   
    int GetNextSibling(int index, bool desc = false);

    /**
       Access Method.
       gets the number of children of a given node.
       @param index is the index in the tree of the node that we want to get
       its number of children.
       @returns the number of children of the given node. If index provided 
       is not correct, -1 is returned.
    **/   
    int getNumChildren(int index);

    /**
       Access Method.
       gets the depth of the subtree rooted at given node.
       @param index is the index in the tree of the node that we want to get
       its depth.
       @returns the depth of subtree of the given node. If index provided 
       is not correct, -1 is returned.
    **/   
    int getSubTreeDepth(int index);

    /**
       Process Method.
       Assigns a new value to the variable used. This method is used to 
       resereve nodes in the array without using them now.
       @param newUsed is the new value assigned to the variable used.
    **/
    void SetUsed(int newUsed); 

    /**
       Process Method.
       sorts the tree nodes according to start key in ascending order.
    **/
    void sortList();

    /**
       Process Method.
       This method is used when you need to switch to complex or simple
       nodes right after declaring the tree (not used yet). You can always 
       use switchToComplex instead. This is just faster.
       @param which is either LIST_NODE or LIST_NODE_WITH_DATA. If it is LIST_NODE, then 
       the tree will consist of simple list nodes (startKey, endKey, and level). 
       If it is LIST_NODE_WITH_DATA, then tree nodes are complex and will contain
       data and other information (along with startKey, endKey, and level). 
	   @param dataMng an instance of the data manager.
    **/
    void overrideConstructor(int which, DataMng *dataMng);

    /**
       Process Method.
       This method is used when you need to switch to complex 
       nodes.
	   @param dataMng an instance of the data manager.
    **/
    void switchToComplex(DataMng *dataMng);

    /**
       Access Method.
       @returns true if the tree nodes are simple. returns false if they
       are complex.
    **/
    bool isSimple();
   
    /**
       Process Method.
       deletes a node from the tree.
       @param index is the index of the node to be deleted.
       @returns SUCCESS if the indexed node is deleted. returns FAILURE if the 
       node doesn't exist.
    **/
    int deleteNode(int index);

	/**
	* Process Method.
	* Deletes an entire subtree from the tree.
	* @returns the number of nodes that were deleted.
	*/
	int deleteNodeAndDescendants(KeyType rootStartKey, KeyType rootEndKey);

    /**
       Process Method.
       inserts a node into the tree at a given position.
       @param index is the index in the tree where the new node should be inserted.
       @param nodeToInsert is the node to be inserted in the tree.
       @returns SUCCESS if the node was inserted at index. returns FAILURE if the 
       index given exceeds size by more than 1.
    **/
    int insertNode(int index, ListNode *nodeToInsert);

    /**
       Process Method.
       inserts a node into the tree at a given position.
       @param index is the index in the tree where the new node should be inserted.
       @param nodeToInsert is the node to be inserted in the tree.
	   @param dataMng an instance of the data manager.
       @returns SUCCESS if the node was inserted at index. returns FAILURE if the 
       index given exceeds size by more than 1.
    **/
    int insertNode(int index, ComplexListNode *nodeToInsert, DataMng *dataMng);

    /**
       Process Method.
       inserts a node into the tree at the correct location (according to start key).
       @param nodeToInsert is the node to be inserted in the tree.
       @returns index of inserted node if the node was inserted. 
    **/
    int sortedInsertNode(ListNode *nodeToInsert, int startHint = 0);

    /**
       Process Method.
       inserts a node into the tree at the correct location (according to start key).
       @param nodeToInsert is the node to be inserted in the tree.
	   @param dataMng an instance of the data manager.
	   @param startHint is an index in teh tree from where to start searching for proper 
		location for inserting. just for efficiency.
       @returns index of inserted node if the node was inserted. 
    **/
    int sortedInsertNode(ComplexListNode *nodeToInsert, DataMng *dataMng, int startHint = 0);

    /**
       Access Method.
       gets the ancestor that is a given number of local levels up of a given node.
       @param index is the index in the tree of the node that we want to get
       its ancs.
       @param levelsUp is the number of levels upwards we should go. A parent 
       is 1 level up.
       @returns the index of the ancestor requested. If it doesn't exist, -1 
       is returned. If index provided is not 
       correct, -1 is returned.
    **/
    int GetLocalAncs(int index,int levelsUp = 1);

    /**
       Access Method.
       gets the ith child of a given node using local levels.
       @param index is the index in the tree of the node that we want to get
       its child.
       @param childNum is the number of the child that is to be returned. If
       it is 1, first child is returned. If it is 2, second child... etc.
       if childNum = -1, last child is returned.
	   @param desc if true, don't check the level condition. return a child or desc of node.
       @returns the index of the child requested. If it doesn't exist, -1 
       is returned. If index provided is not 
       correct, -1 is returned.
    **/   
    int GetLocalChild(int index,int childNum = 1, bool desc = false);

    /**
       Access Method.
       gets the following sibling of a given node using local levels.
       @param index is the index in the tree of the node that we want to get
       its next sibling.
	   @param desc if true, don't check the level condition. return a sibling or a nephew of node.
       @returns the index of the sibling requested. If it doesn't exist, -1 
       is returned. If index provided is not 
       correct, -1 is returned.
    **/   
    int GetNextLocalSibling(int index,bool desc = false);

    /**
       Access Method.
       gets the number of children of a given node using local levels.
       @param index is the index in the tree of the node that we want to get
       its child.
       @returns the number of children of the given node. If index provided 
       is not correct, -1 is returned.
    **/   
    int getLocalNumChildren(int index);

    /**
       Access Method.
       gets the depth of the subtree rooted at given node using local levels.
       @param index is the index in the tree of the node that we want to get
       its child.
       @returns the depth of subtree of the given node. If index provided 
       is not correct, -1 is returned.
    **/   
    int getLocalSubTreeDepth(int index);

    /**
       Process Method.
       sets the simple buffer to a new value with or without deleting the old one.
       @param newBuf is an allocated buffer to be the new simpleBuf.
       @param deleteOldBuf is a flag, if true the old buffer will be deleted. otherwise it
       is just assigned the new value.
    **/
    void setSimpleBuf(ListNode *newBuf, bool deleteOldBuf = true);

    /**
       Process Method.
       sets the complex buffer to a new value with or without deleting the old one.
       @param newBuf is an allocated buffer to be the new complexBuf.
       @param deleteOldBuf is a flag, if true the old buffer will be deleted. otherwise it
       is just assigned the new value.
    **/
    void setComplexBuf(ComplexListNode *newBuf, bool deleteOldBuf = true);

    /**
       Access Method.
       @returns the member variable deleteBuffersOnDestruct which decides whether or
       not the buffers are to be deleted on destructor.
    **/
    bool getDeleteBuffers();

    /**
       Process Method.
       sets the value of the member variable deleteBuffersOnDestruct.
       @param deleteBuffersOnDestruct is the new value for the member variable.
    **/
    void setDeleteBuffers(bool deleteBuffersOnDestruct);

	/**
       Access Method.
       @returns the score of teh tree
    **/
    double getScore();

	/**
       Process Method.
       sets the score of the tree
       @param score is the new score to be assigned to the tree.
    **/
    void setScore(double score);

	/**
       Process Method.
       starts a scan of the tree nodes. i.e. sets some cursor to be 0.
   **/
    void startScan();

	/**
		Access Method.
		@returns a pointer to the next scanned node in teh tree.
	**/
    void *getNext();


	/**
		Process Method.
		copies a witness tree to this witness tree.
		@param tree is the witness tree to be copied to this witness tree.
	**/
	void copyTree(WitnessTree *tree);

	  /**
	   Process Method.
	   deletes all node from the tree	   
	---------------------------------------------------------------------------
	Yunyao - 12-15-03 - Added to efficiently delete all the nodes in the buffer
	---------------------------------------------------------------------------	
	**/
	void deleteAllNode();

	/**
	   Process Method.
	   Replace a list node in the tree at a specific position with another node
	   @param nodeToInsert is the node to be used to replace an existing node in the tree
	   @param index is the position of the node to be replaced
	   @return (TRUE)SUCCESS if replacement is done successfully; (FALSE)FAILURE if no node at the specific position exists
	---------------------------------------------------------
	Yunyao - 12-15-03 - Added to replace a node in the buffer
	---------------------------------------------------------
	**/
	bool replaceNode(ListNode * nodeToInsert, int index);

	/**
	   Process Method.
	   Replace a list node in the tree at a specific position with another node
	   @param nodeToInsert is the node to be used to replace an existing node in the tree
	   @param index is the position of the node to be replaced
	   @dataMng is the pointer to the Data Manager
	   @return (TRUE)SUCCESS if replacement is done successfully; (FALSE)FAILURE if no node at the specific position exists
	---------------------------------------------------------
	Yunyao - 12-15-03 - Added to replace a node in the buffer
	---------------------------------------------------------
	**/
	bool replaceNode(ComplexListNode * nodeToInsert, int index, DataMng *dataMng);

	/**
	   Process Method
	   Set up the NRE table of the witness tree using given NRE values
	   @param nre is the array containing NRE values
	---------------------------------------------------------------------------
	Yunyao - 12-15-03 - Added to add an entry to NRE table of the witness tree
	---------------------------------------------------------------------------	
	**/
	void setNREByIndex(int index, NREType nre);

	NRETable *getNRETable();


	int getIndexOfNRE(NREType nre);
	void reconstructNRETable();

	bool equalTree(WitnessTree *toBeCompared);
	bool equalTree(WitnessTree *toBeCompared, int &index, int length = -1);

	bool moreThanOneMatch(NREType nre);

private:
    ListNode *bufSimple;
    ComplexListNode *bufComplex;
    int bufSize;
    int used;
    int scanCursor;
    double score;
    DataMng *dataMng;
    bool deleteBuffersOnDestruct;

	NRETable *nreTable;

    /**
       Process Method.
       Ensures that the array allocated for the tree can accomodate a given
       number of nodes. It basically doubles the size of the array allocated.
       If it is still not enough for size, it allocates exactly used+size.
       @param size is the number of nodes we wish to add to the tree.
    **/
    void accomodate (int size);

};

#endif
