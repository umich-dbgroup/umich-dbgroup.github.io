/*
COPYRIGHT  � 2000-2004 
THE REGENTS OF THE UNIVERSITY OF MICHIGAN
ALL RIGHTS RESERVED

PERMISSION IS GRANTED TO USE, COPY, CREATE DERIVATIVE WORKS AND REDISTRIBUTE THIS SOFTWARE AND SUCH DERIVATIVE WORKS FOR 
NONCOMMERCIAL EDUCATION AND RESEARCH PURPOSES, SO LONG AS NO FEE IS CHARGED, AND SO LONG AS THE COPYRIGHT NOTICE ABOVE, 
THIS GRANT OF PERMISSION, AND THE DISCLAIMER BELOW APPEAR IN ALL COPIES MADE; AND SO LONG AS THE NAME OF THE UNIVERSITY 
OF MICHIGAN IS NOT USED IN ANY ADVERTISING OR PUBLICITY PERTAINING TO THE USE OR DISTRIBUTION OF THIS SOFTWARE WITHOUT 
SPECIFIC, WRITTEN PRIOR AUTHORIZATION.

THIS SOFTWARE IS PROVIDED AS IS, WITHOUT REPRESENTATION FROM THE UNIVERSITY OF MICHIGAN AS TO ITS FITNESS FOR ANY PURPOSE, 
AND WITHOUT WARRANTY BY THE UNIVERSITY OF MICHIGAN OF ANY KIND, EITHER EXPRESS OR IMPLIED, INCLUDING WITHOUT LIMITATION THE 
IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE. THE REGENTS OF THE UNIVERSITY OF MICHIGAN SHALL 
NOT BE LIABLE FOR ANY DAMAGES, INCLUDING SPECIAL, INDIRECT, INCIDENTAL, OR CONSEQUENTIAL DAMAGES, WITH RESPECT TO ANY CLAIM 
ARISING OUT OF OR IN CONNECTION WITH THE USE OF THE SOFTWARE, EVEN IF IT HAS BEEN OR IS HEREAFTER ADVISED OF THE POSSIBILITY 
OF SUCH DAMAGES.
*/

#include "NRETable.h"

NRETableEntry::NRETableEntry()
{
	this->capacity = 0;
	this->list = NULL;
	this->initialize();
}

NRETableEntry::~NRETableEntry()
{
	if (list)
		delete [] list;
}

void NRETableEntry::initialize()
{
	this->size = 0;
	cursor = 0;
}

void NRETableEntry::startScan()
{
	cursor = 0;
}

int NRETableEntry::getNextIndex()
{
	if (!list)
		return FAILURE;
	if (cursor >= size)
	{
		cursor = 0;
		return FAILURE;
	}
	return list[cursor++];
}



int NRETableEntry::getSize()
{
	return this->size;
}


bool NRETableEntry::moreThanOneMatch()
{
	return size > 1;
}

void NRETableEntry::mergeEntry(NRETableEntry *toMerge)
{
	if (!toMerge->getList())
		return;

	int toMergeSize = toMerge->getSize();
	if (list)
	{
		int availSpace = capacity - size;
		
		if (toMergeSize > availSpace)
		{
			capacity += toMergeSize;
			int *tmp = list;
			list = new int[capacity];
			memcpy(list,tmp,size*sizeof(int));
			delete [] tmp;
		}
	}
	else
	{
		capacity = toMergeSize;
		list = new int[capacity];
	}
	
	memcpy(list+size,toMerge->getList(),toMergeSize*sizeof(int));
	size += toMergeSize;
}
	
void NRETableEntry::copyEntry(NRETableEntry *toCopy)
{
	this->initialize();
	if (!toCopy->getList())
		return;
	if (toCopy->getSize() > capacity)
	{
		capacity = toCopy->getSize();
		if (list) delete [] list;
		list = new int[capacity];
	}
	memcpy(list,toCopy->getList(),toCopy->getSize()*sizeof(int));
	size = toCopy->getSize();
}

int *NRETableEntry::getList()
{
	return this->list;
}

void NRETableEntry::addOffset(int offset)
{
	for (int i=0; i<size; i++)
		list[i] += offset;
}

bool NRETableEntry::isEmpty()
{
	return size == 0;
}

void NRETableEntry::addOffsetToSpecNode(int indexValue, int offset)
{
	int ind = findNodeWithSpecIndex(indexValue);
	if (ind != FAILURE)
		list[ind] += offset;
}

void NRETableEntry::addOffsetToRangeOfNodes(int startValue, int endValue, int offset)
{
	int startInd = findNodeWithSpecIndex(startValue);
	if (startInd != FAILURE)
	{
		for (int i=startInd; i<size; i++)
		{
			if (list[i] == endValue)
			{
				list[i] += offset;
				return;
			}
			if (list[i] > endValue)
				return;
			list[i] += offset;
		}
	}
}

void NRETableEntry::addOffsetToRangeOfNodesAny(int startValue, int endValue, int offset)
{
	if (isEmpty())
		return;
	int startInd = -1;
	for (int i=0; i<size; i++)
	{
		if (list[i] >= startValue)
		{
			startInd = i;
			break;
		}
	}
	if (startInd != -1)
	{
		for (int i=startInd; i<size; i++)
		{
			if (list[i] == endValue)
			{
				list[i] += offset;
				return;
			}
			if (list[i] > endValue)
				return;
			list[i] += offset;
		}
	}
}

int NRETableEntry::findNodeWithSpecIndex(int index)
{
	for (int i=0; i<size; i++)
	{
		if (index == list[i])
			return i;
		if (index > list[i])
			return FAILURE;
	}
	return FAILURE;
}

int NRETableEntry::getFirstIndex()
{
	if (this->isEmpty())
		return FAILURE;
	return this->list[0];
}

void NRETableEntry::appendIndex(int index)
{
	if (!list)
	{
		capacity = NRE_TABLE_ENTRY_INIT_CAPACITY;
		list = new int[capacity];
	}
	else
	{
		if (size == capacity)
		{
			capacity *= 2;
			int *tmp = list;
			list = new int[capacity];
			memcpy(list,tmp,size*sizeof(int));
			delete [] tmp;
		}
	}

	list[size++] = index;
}

void NRETableEntry::deleteIndex(int index)
{
	if (this->isEmpty())
		return;
	int loc = this->findNodeWithSpecIndex(index);

	if (loc == FAILURE)
		return;

	for (int i=loc; i<size-1; i++)
		list[i] = list[i+1];
	size--;

}

void NRETableEntry::insertIndex(int index)
{
	if (!list)
	{
		capacity = NRE_TABLE_ENTRY_INIT_CAPACITY;
		list = new int[capacity];
		list[size++] = index;
		return;
	}
	int loc;
	for (int i=0; i<size; i++)
		if (index < list[i])
			break;
	loc = i;

	if (loc == size)
	{
		appendIndex(index);
		return;
	}

	if (size == capacity)
	{
		capacity *= 2;
		int *tmp = list;
		list = new int[capacity];
		memcpy(list,tmp,loc*sizeof(int));
		list[loc] = index;
		memcpy(list+loc+1,tmp+loc,(size-loc)*sizeof(int));
		delete [] tmp;
	}
	else
	{
		 for (i=size; i>loc; i--)
            list[i] = list[i-1];
		 list[loc] = index;
	}
	size++;
}

void NRETableEntry::printList(FILE* stream)
{
	if (this->isEmpty())
		fprintf(stream, "Empty.");
	else
		for (int i=0; i<size; i++)
			fprintf(stream, "%d ",list[i]);
	fprintf(stream, "\n");
}

NRETable::NRETable()
{
	capacity = globalNRETableCapacity;
	table = new NRETableEntry[capacity];
	this->numUsedEntries = 0;
}

NRETable::~NRETable()
{
	delete [] table;
}

void NRETable::initialize()
{
	for (int i=0; i<capacity; i++)
		table[i].initialize();
	this->numUsedEntries = 0;
}

void NRETable::mergeTable(NRETable *toMerge)
{
	for (int i=0; i<capacity; i++)
	{
		if (table[i].getSize() == 0 && toMerge->getEntryByNRE(i)->getSize() > 0)
			this->numUsedEntries++;
		table[i].mergeEntry(toMerge->getEntryByNRE(i));
	}
}

void NRETable::copyTable(NRETable *toCopy)
{
	for (int i=0; i<capacity; i++)
		table[i].copyEntry(toCopy->getEntryByNRE(i));
	this->numUsedEntries = toCopy->getNumUsedEntries();
}

NRETableEntry *NRETable::getEntryByNRE(NREType nre)
{
	if (nre < 0 || nre >= this->capacity)
		return NULL;
	return &table[nre];
}

void NRETable::startScanningNRE(NREType nre)
{
	currNRE = nre;
	if (nre < 0 || nre >= this->capacity)
		return;
	table[nre].startScan();
}

int NRETable::getNextIndex()
{
	if (currNRE < 0 || currNRE >= capacity)
		return FAILURE;
	int ind = table[currNRE].getNextIndex();
	if (ind == FAILURE)
		currNRE = -1;
	return ind;
}

void NRETable::addOffsetToSpecNode(NREType nre, int indexValue, int offset)
{
	if (nre < 0 || nre >= this->capacity)
		return;
	table[nre].addOffsetToSpecNode(indexValue,offset);
}

void NRETable::addOffsetToRangeOfNodesWithNRE(NREType nre, int startValue, int endValue, int offset)
{
	if (nre < 0 || nre >= this->capacity)
		return;
	table[nre].addOffsetToRangeOfNodes(startValue,endValue,offset);
}

void NRETable::addOffsetToRangeOfNodes(int startValue, int endValue, int offset)
{
	for (int i=0; i<capacity; i++)
	{
		if (table[i].isEmpty())
			continue;
		table[i].addOffsetToRangeOfNodesAny(startValue,endValue,offset);
	}
}

int NRETable::getFirstIndex(NREType nre)
{
	if (nre < 0 || nre >= this->capacity)
		return -1;
	return table[nre].getFirstIndex();
}

void NRETable::appendIndex(NREType nre, int index)
{
	if (nre < 0 || nre >= this->capacity)
		return;
	if (table[nre].getSize() == 0)
		this->numUsedEntries++;
	table[nre].appendIndex(index);
}

void NRETable::deleteIndex(NREType nre, int index)
{
	if (nre < 0 || nre >= this->capacity)
		return;
	table[nre].deleteIndex(index);
	if (table[nre].getSize() == 0)
		this->numUsedEntries--;
}

void NRETable::insertIndex(NREType nre, int index)
{
	if (nre < 0 || nre >= this->capacity)
		return;
	if (table[nre].getSize() == 0)
		this->numUsedEntries++;
	table[nre].insertIndex(index);
}

void NRETable::printTable(FILE* stream)
{
	for (int i=0; i<capacity; i++)
	{
		fprintf(stream, "nre = %d --> ",i);
		table[i].printList(stream);
	}
}

int NRETable::getNumUsedEntries()
{
	return this->numUsedEntries;
}

int NRETable::getCapacity()
{
	return this->capacity;
}

void NRETable::startScanningAllTable()
{
	for (int i=0; i<capacity; i++)
		if (table[i].getSize() > 0)
		{
			table[i].startScan();
			this->currNRE = i;
			return;
		}
}

int NRETable::getNextSAT()
{
	if (currNRE < 0 || currNRE >= capacity)
		return FAILURE;
	int ind = table[currNRE].getNextIndex();
	while (ind == FAILURE)
	{
		currNRE++;
		if (currNRE == capacity)
			return FAILURE;
		if (table[currNRE].getSize() == 0)
			continue;
		table[currNRE].startScan();
		ind = table[currNRE].getNextIndex();
	}
	return ind;
}

bool NRETable::moreThanOneMatch(NREType nre)
{
	if (nre < 0 || nre >= this->capacity)
		return false;
	return table[nre].moreThanOneMatch();
}