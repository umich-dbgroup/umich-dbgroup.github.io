#include "datainstantiationiterator.h"

DataInstantiationIterator::DataInstantiationIterator(IteratorClass *input, 
		int index, 
		DataInstantiationSpecification* diSpec,
		DataMng *dataMng)
{
	this->input = input;
	this->index= index;
	this->diSpec = diSpec; 
	this->dataMng = dataMng;

	this->input->next(inTuple);
	if (inTuple)
	{
		if (inTuple->isSimple())
			resultBuffer = new WitnessTree;
		else
			resultBuffer = new WitnessTree(LIST_NODE_WITH_DATA,dataMng);
	}
	else
		resultBuffer = NULL;

}

DataInstantiationIterator::~DataInstantiationIterator()
{
	if (resultBuffer)
		delete resultBuffer;
	if (diSpec)
		delete diSpec;
	delete input;
}

void DataInstantiationIterator::next(WitnessTree *&node)
{
	if (inTuple == NULL)
	{
		node = NULL;
		return;
	}

	FileIDType fileid;
	KeyType nodeKey;
	if (inTuple->isSimple())
	{
		ListNode *n = (ListNode *)inTuple->findNode(index);
		nodeKey = n->GetStartPos();
		fileid= EvaluatorClass::getFileID(n->getFileIndex());
	}
	else
	{
		ComplexListNode *n = (ComplexListNode *)inTuple->findNode(index);
		nodeKey = n->GetStartPos();
		fileid= EvaluatorClass::getFileID(n->getFileIndex());
	}
	if (fileid == -1)
	{
		node = NULL;
		return;
	}
	 

	this->dataMng->dataInstantiation(fileid, nodeKey, this->diSpec);

	resultBuffer->initialize();
	if (inTuple->isSimple())
		resultBuffer->appendList((ListNode *)inTuple->getBuffer(),inTuple->length());
	else
		resultBuffer->appendList((ComplexListNode *)inTuple->getBuffer(),dataMng,inTuple->length());
	node = resultBuffer;
	input->next(inTuple);

	return;
}



