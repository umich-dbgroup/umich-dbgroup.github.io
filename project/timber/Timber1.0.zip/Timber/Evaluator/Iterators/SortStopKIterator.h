/*
COPYRIGHT  � 2000-2004 
THE REGENTS OF THE UNIVERSITY OF MICHIGAN
ALL RIGHTS RESERVED

PERMISSION IS GRANTED TO USE, COPY, CREATE DERIVATIVE WORKS AND REDISTRIBUTE THIS SOFTWARE AND SUCH DERIVATIVE WORKS FOR 
NONCOMMERCIAL EDUCATION AND RESEARCH PURPOSES, SO LONG AS NO FEE IS CHARGED, AND SO LONG AS THE COPYRIGHT NOTICE ABOVE, 
THIS GRANT OF PERMISSION, AND THE DISCLAIMER BELOW APPEAR IN ALL COPIES MADE; AND SO LONG AS THE NAME OF THE UNIVERSITY 
OF MICHIGAN IS NOT USED IN ANY ADVERTISING OR PUBLICITY PERTAINING TO THE USE OR DISTRIBUTION OF THIS SOFTWARE WITHOUT 
SPECIFIC, WRITTEN PRIOR AUTHORIZATION.

THIS SOFTWARE IS PROVIDED AS IS, WITHOUT REPRESENTATION FROM THE UNIVERSITY OF MICHIGAN AS TO ITS FITNESS FOR ANY PURPOSE, 
AND WITHOUT WARRANTY BY THE UNIVERSITY OF MICHIGAN OF ANY KIND, EITHER EXPRESS OR IMPLIED, INCLUDING WITHOUT LIMITATION THE 
IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE. THE REGENTS OF THE UNIVERSITY OF MICHIGAN SHALL 
NOT BE LIABLE FOR ANY DAMAGES, INCLUDING SPECIAL, INDIRECT, INCIDENTAL, OR CONSEQUENTIAL DAMAGES, WITH RESPECT TO ANY CLAIM 
ARISING OUT OF OR IN CONNECTION WITH THE USE OF THE SOFTWARE, EVEN IF IT HAS BEEN OR IS HEREAFTER ADVISED OF THE POSSIBILITY 
OF SUCH DAMAGES.
*/

#ifndef __SortStopKIterator_h
#define __SortStopKIterator_h

#include "../Common/IteratorClass.h"
#include <float.h>

/**
* An access method that performs a sort by score and stops after outputting k top scoring trees.
* @see WitnessTree
* @see IteratorClass
* @author Shurug Al-Khalifa 
* @version 1.0
*/
class SortStopKIterator : public IteratorClass
{
public:
	/**
	Constructor. 
	initializes vars.
	@param input is where this iterator gets its input trees.
	@param k is the number of results to be produced.
	@param inSize is the number of inputs to be read from iterator "input".
    @param dataMng an instance of the data manager.
	**/
	SortStopKIterator(IteratorClass *input, int k, int inSize, DataMng *dataMng);

	/**
	Destructor.
	releases the memory used by output buffer and so.
	**/
	~SortStopKIterator();

	/**
	Access Method
	gets the next output from this iterator.
	@param node is a pointer that well be set to the output buffer or NULL (indicating that
	there are no more results).
	**/
	void next(WitnessTree *&node);

private:
	void insertInArray(WitnessTree *inTuple);
	WitnessTree *resultBuffer;
	WitnessTree *sortArray;
	int k;
	int inSize;
	IteratorClass *input;
	WitnessTree *inTuple;
	int cursor;
	DataMng *dataMng;
	double lowestScore;
	int sortArrayCursor;
	int lowestScoreIndex;
	int binSearch(double key);
	
};


#endif