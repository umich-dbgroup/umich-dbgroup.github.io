/*
COPYRIGHT  � 2000-2004 
THE REGENTS OF THE UNIVERSITY OF MICHIGAN
ALL RIGHTS RESERVED

PERMISSION IS GRANTED TO USE, COPY, CREATE DERIVATIVE WORKS AND REDISTRIBUTE THIS SOFTWARE AND SUCH DERIVATIVE WORKS FOR 
NONCOMMERCIAL EDUCATION AND RESEARCH PURPOSES, SO LONG AS NO FEE IS CHARGED, AND SO LONG AS THE COPYRIGHT NOTICE ABOVE, 
THIS GRANT OF PERMISSION, AND THE DISCLAIMER BELOW APPEAR IN ALL COPIES MADE; AND SO LONG AS THE NAME OF THE UNIVERSITY 
OF MICHIGAN IS NOT USED IN ANY ADVERTISING OR PUBLICITY PERTAINING TO THE USE OR DISTRIBUTION OF THIS SOFTWARE WITHOUT 
SPECIFIC, WRITTEN PRIOR AUTHORIZATION.

THIS SOFTWARE IS PROVIDED AS IS, WITHOUT REPRESENTATION FROM THE UNIVERSITY OF MICHIGAN AS TO ITS FITNESS FOR ANY PURPOSE, 
AND WITHOUT WARRANTY BY THE UNIVERSITY OF MICHIGAN OF ANY KIND, EITHER EXPRESS OR IMPLIED, INCLUDING WITHOUT LIMITATION THE 
IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE. THE REGENTS OF THE UNIVERSITY OF MICHIGAN SHALL 
NOT BE LIABLE FOR ANY DAMAGES, INCLUDING SPECIAL, INDIRECT, INCIDENTAL, OR CONSEQUENTIAL DAMAGES, WITH RESPECT TO ANY CLAIM 
ARISING OUT OF OR IN CONNECTION WITH THE USE OF THE SOFTWARE, EVEN IF IT HAS BEEN OR IS HEREAFTER ADVISED OF THE POSSIBILITY 
OF SUCH DAMAGES.
*/

#include "ScanIterator.h"
#include "../Evaluator/EvaluatorClass.h"
ScanIterator::ScanIterator(KeyType startKey,ScanRange *scanRanges,SelectionCondition *condition, char openFileIndex,NREType assignedNRE,
						   DataMng* dataMng,FileIDType fileid)
{
	this->startKey = startKey;
	this->scanRanges = scanRanges;
	this->condition = condition;
	this->dataMng = dataMng;
	this->fid = fileid;
	this->openFileIndex = openFileIndex;
	this->assignedNRE = assignedNRE;

	resultBuffer = new WitnessTree;
	numScanned = 0;
	//start the scanning of the file
	sid = dataMng->startScan(fid,startKey,-1,-1,scanRanges,condition,true,1);
	if (sid != -1)
		inTuple = dataMng->scanFetchNext(fid,sid);
	else
		inTuple = NULL;
	if (condition->getNodeType() != DOCUMENT_NODE)
	{
		this->overflowSID = dataMng->startScan(fid,startKey,-1,-1,scanRanges,new SelectionCondition(condition),true,2);
		//this->overflowSID = dataMng->startScan(fid,startKey,-1,-1,scanRanges,condition,true,2);
		if (overflowSID != -1)
		{
			this->overflowSection = new SortIterator(overflowSID,fid,-1,dataMng);
			overflowSection->next(overflowTuple);
		}
		else
		{
			this->overflowSection  = NULL;
			overflowTuple = NULL;
		}
	}
	else {
		this->overflowSID = -1;
		this->overflowSection  = NULL;
	}
}

ScanIterator::~ScanIterator()
{
	delete resultBuffer;
	if (sid != -1)
		dataMng->clearScan(fid,sid);
	if (overflowSID != -1)
		dataMng->clearScan(fid,overflowSID);
	if (overflowSection)
		delete overflowSection;

}

void ScanIterator::next(WitnessTree *&node)
{
#ifdef EVAL_TIME_OUT
	clock_t currTime = clock();
	double queryDuration = (double)(currTime - gQueryStartTime) / CLOCKS_PER_SEC;
	if (queryDuration >= gTimeOutAfter)
	{
		globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"Evaluator",__FILE__,"Query Timed Out.");
		node = NULL;
		return;
	}
#endif

	if (condition->getNodeType() == DOCUMENT_NODE) 
	{
		if (numScanned == 1)
		{
			node = NULL;
			return;
		}
		else if (inTuple)
		{
			numScanned++;
			resultBuffer->initialize();
			ListNode n;

			n.SetStartPos(inTuple->getKey());
			n.SetEndPos(inTuple->getEndKey());
			n.SetLevel(inTuple->getLevel());
			n.setNRE(assignedNRE);
			n.setFileIndex(openFileIndex);
			resultBuffer->appendList(&n,1);
			node = resultBuffer;
			return;
		}
		else
		{
			node = NULL;
			return;
		}
	}

	if (inTuple || overflowTuple)
	{
		numScanned++;
		resultBuffer->initialize();
		ListNode n;
		n.setNRE(assignedNRE);
		n.setFileIndex(openFileIndex);
		if (originalSectionFirst(inTuple,overflowTuple))
		{
			n.SetStartPos(inTuple->getKey());
			n.SetEndPos(inTuple->getEndKey());
			n.SetLevel(inTuple->getLevel());	
			inTuple = dataMng->scanFetchNext(fid,sid);
		}
		else
		{
			ListNode *n2 = (ListNode *)overflowTuple->getNodeByIndex(0);
			n.SetStartPos(n2->GetStartPos());
			n.SetEndPos(n2->GetEndPos());
			n.SetLevel(n2->GetLevel());
			overflowSection->next(overflowTuple);
		}
		resultBuffer->appendList(&n,1);
		node = resultBuffer;
		return;
	}
	node = NULL;
}

bool ScanIterator::originalSectionFirst(DM_DataNode *origTuple, WitnessTree *overflowTuple)
{
	if (!origTuple)
		return false;
	if (!overflowTuple)
		return true;

	KeyType origSK = origTuple->getKey();
	KeyType overflowSK = ((ListNode *)overflowTuple->getNodeByIndex(0))->GetStartPos();

	return (origSK <= overflowSK);
}