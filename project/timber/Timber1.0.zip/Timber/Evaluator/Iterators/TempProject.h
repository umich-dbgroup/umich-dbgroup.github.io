#ifndef __tempprojectclass_h
#define __tempprojectclass_h

#include "../Common/IteratorClass.h"


/**
* An access method that performs a projection and duplicate elimination of trees that have similar start keys.
* it assumes input is sorted by whatever you want to keep.
* @see WitnessTree
* @see IteratorClass
* @author Shurug Al-Khalifa 
* @version 1.0
*/

class TempProjectClass : public IteratorClass
{
public:
	/**
	Constructor. 
	initializes vars.
	@param in is where this iterator gets its input trees.
	@param index is an array of indices of nodes you want to keep in input trees.
	@param size is the number of nodes you wna tto keep in the input trees. i.e. the size of index array.
    @param dataMng an instance of the data manager.
	**/
	TempProjectClass(IteratorClass *in, int *index, int size,DataMng *dataMng)
	{
		this->in = in;
		this->index = index;
		this->size = size;
		this->dataMng = dataMng;

		resultBuffer = new WitnessTree(LIST_NODE);
		in->next(inTuple);
		if (inTuple)
		{
			if (!(inTuple->isSimple()))
				resultBuffer->switchToComplex(dataMng);
		}
	}

	void next(WitnessTree *&node)
	{
		while (inTuple)
		{
			//here we are comparing previous nodes with current nodes
			for (int i=0;i<size; i++)
			{

				//once we find that a node is different than the previous one, we output it and get new input
				if (inTuple->isSimple())
				{
					if ( ((ListNode *)(inTuple->findNode(index[i])))->GetStartPos() 
						!= ((ListNode *)(resultBuffer->findNode(i, true)))->GetStartPos())
						break;
				}
				else
				{
					if ( ((ComplexListNode *)(inTuple->findNode(index[i])))->GetStartPos() 
						!= ((ComplexListNode *)(resultBuffer->findNode(i, true)))->GetStartPos())
						break;
				}
			}

			if (i == size)
			{
				//if we come here, it means that the current tree is identical to the previous one.
				in->next(inTuple);
				continue;
			}

			//copying the inTuple nodes to be kept to resultBuffer.
			resultBuffer->initialize();
			for (i=0; i<size; i++)
			{
				if (inTuple->isSimple())
					resultBuffer->appendList((ListNode *)(inTuple->findNode(index[i])),1);
				else
					resultBuffer->appendList((ComplexListNode *)(inTuple->findNode(index[i])),dataMng,1);

			}
			resultBuffer->setScore(inTuple->getScore());
			in->next(inTuple);
			node = resultBuffer;
			return;
		}
		node = NULL;
		return;
	}

	~TempProjectClass()
	{
		delete resultBuffer;
		if (index)
			delete [] index;
		delete in;
	}
private:
	IteratorClass *in;
	WitnessTree *inTuple;
	DataMng *dataMng;
	int *index;
	int size;
	WitnessTree *resultBuffer;
};

#endif