#ifndef __constructpartialmatcher_h
#define __constructpartialmatcher_h
#include "TextFileReader.h"
#include "../Evaluator/EvaluatorClass.h"

#include "../Common/ConstructSpecification.h"

class ExecArrayType;

class ConstructPartialMatcher : public IteratorClass
{
public:
	ConstructPartialMatcher(IteratorClass *input, ExecArrayType *pattern, int *relation, 
		int *getWhat, char **attrNames, int rootIndex,
		TransactionIDType tid,FileIDType fid,DataMng *dataMng);
	~ConstructPartialMatcher();
	
	void next(WitnessTree *&node);
private:
	IteratorClass *input;
	ExecArrayType *pattern;
	WitnessTree *resultBuffer;
	TransactionIDType tid;
	FileIDType fid;
	DataMng *dataMng;
	int *relation;
	int *getWhat;
	char **attrNames;
	WitnessTree *inTuple;
	int rootIndex;
	WitnessTree **res;
	void getMatches(int index, KeyType sk, KeyType ek, int lev, int localLev = 0);
};



#endif