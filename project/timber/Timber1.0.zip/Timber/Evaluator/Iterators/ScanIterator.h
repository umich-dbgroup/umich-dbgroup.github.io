/*
COPYRIGHT  � 2000-2004 
THE REGENTS OF THE UNIVERSITY OF MICHIGAN
ALL RIGHTS RESERVED

PERMISSION IS GRANTED TO USE, COPY, CREATE DERIVATIVE WORKS AND REDISTRIBUTE THIS SOFTWARE AND SUCH DERIVATIVE WORKS FOR 
NONCOMMERCIAL EDUCATION AND RESEARCH PURPOSES, SO LONG AS NO FEE IS CHARGED, AND SO LONG AS THE COPYRIGHT NOTICE ABOVE, 
THIS GRANT OF PERMISSION, AND THE DISCLAIMER BELOW APPEAR IN ALL COPIES MADE; AND SO LONG AS THE NAME OF THE UNIVERSITY 
OF MICHIGAN IS NOT USED IN ANY ADVERTISING OR PUBLICITY PERTAINING TO THE USE OR DISTRIBUTION OF THIS SOFTWARE WITHOUT 
SPECIFIC, WRITTEN PRIOR AUTHORIZATION.

THIS SOFTWARE IS PROVIDED AS IS, WITHOUT REPRESENTATION FROM THE UNIVERSITY OF MICHIGAN AS TO ITS FITNESS FOR ANY PURPOSE, 
AND WITHOUT WARRANTY BY THE UNIVERSITY OF MICHIGAN OF ANY KIND, EITHER EXPRESS OR IMPLIED, INCLUDING WITHOUT LIMITATION THE 
IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE. THE REGENTS OF THE UNIVERSITY OF MICHIGAN SHALL 
NOT BE LIABLE FOR ANY DAMAGES, INCLUDING SPECIAL, INDIRECT, INCIDENTAL, OR CONSEQUENTIAL DAMAGES, WITH RESPECT TO ANY CLAIM 
ARISING OUT OF OR IN CONNECTION WITH THE USE OF THE SOFTWARE, EVEN IF IT HAS BEEN OR IS HEREAFTER ADVISED OF THE POSSIBILITY 
OF SUCH DAMAGES.
*/

#ifndef __ScanIterator_h
#define __ScanIterator_h

//#include "../Evaluator/EvaluatorClass.h"
#include "../../DataMng/DataMng.h"
//#include "../../PhysicalDataMng/PhysicalDataMng.h"
#include "../Common/IteratorClass.h"
#include "SortIterator.h"
/**
* An access method that performs a scan on the DB according to the condition
* you pass.
* @see WitnessTree
* @see SelectionCondition
* @see ScanRange
* @see DataMng
* @see IteratorClass
* @author Shurug Al-Khalifa 
* @version 1.0
*/
class ScanIterator : public IteratorClass
{
public:
	/**
	Constructor.
	@param startKey the key of the DB node you want to start scanning from.
	@param scanRanges a list of start, end key pairs. Scan will scan nodes that
			fall in these ranges.
	@param condition a structure that has a bunch of predicates separated by ands and ors.
			nodes that satisfy these conditions are scanned.
	@param data_mng an instance of the data manager.
	@param fid current file id.
	**/
	ScanIterator(KeyType startKey,ScanRange *scanRanges,SelectionCondition *condition, char openFileIndex, NREType assignedNRE,
		DataMng* dataMng,FileIDType fileid);

	/**
	Destructor
	releases the space used by output buffer.
	**/
	~ScanIterator();

	/**
	Access Method
	gets the next output from this iterator.
	@param node is a pointer that well be set to the output buffer or NULL (indicating that
	there are no more results).
	**/
	void next(WitnessTree *&node);

private:
	
	/**
	id of the scan that will be performed.
	**/
	ScanIDType sid;

	ScanIDType overflowSID;

	bool originalSectionFirst(DM_DataNode *origTuple, WitnessTree *overflowTuple);

	/**
	id of the file that will be scanned.
	**/
	FileIDType fid;

	/**
	instance of the data manager.
	**/
	DataMng *dataMng;

	/**
	input nodes from the database.
	**/
	DM_DataNode *inTuple;

	WitnessTree *overflowTuple;

	/**
	condition to be applied on scanned nodes and the only ones that satisfy it pass.
	**/
	SelectionCondition *condition;

	/**
	key of the starting node of the scan.
	**/
	KeyType startKey;

	/**
	a list of start, end key pairs. Scan will scan nodes that fall in these ranges.
	**/
	ScanRange *scanRanges;

	/**
	a buffer that holds each of the results of the scan
	**/
	WitnessTree *resultBuffer;
	char openFileIndex;
	NREType assignedNRE;
	int numScanned;

	SortIterator *overflowSection;
};

#endif

