/*
COPYRIGHT  � 2000-2004 
THE REGENTS OF THE UNIVERSITY OF MICHIGAN
ALL RIGHTS RESERVED

PERMISSION IS GRANTED TO USE, COPY, CREATE DERIVATIVE WORKS AND REDISTRIBUTE THIS SOFTWARE AND SUCH DERIVATIVE WORKS FOR 
NONCOMMERCIAL EDUCATION AND RESEARCH PURPOSES, SO LONG AS NO FEE IS CHARGED, AND SO LONG AS THE COPYRIGHT NOTICE ABOVE, 
THIS GRANT OF PERMISSION, AND THE DISCLAIMER BELOW APPEAR IN ALL COPIES MADE; AND SO LONG AS THE NAME OF THE UNIVERSITY 
OF MICHIGAN IS NOT USED IN ANY ADVERTISING OR PUBLICITY PERTAINING TO THE USE OR DISTRIBUTION OF THIS SOFTWARE WITHOUT 
SPECIFIC, WRITTEN PRIOR AUTHORIZATION.

THIS SOFTWARE IS PROVIDED AS IS, WITHOUT REPRESENTATION FROM THE UNIVERSITY OF MICHIGAN AS TO ITS FITNESS FOR ANY PURPOSE, 
AND WITHOUT WARRANTY BY THE UNIVERSITY OF MICHIGAN OF ANY KIND, EITHER EXPRESS OR IMPLIED, INCLUDING WITHOUT LIMITATION THE 
IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE. THE REGENTS OF THE UNIVERSITY OF MICHIGAN SHALL 
NOT BE LIABLE FOR ANY DAMAGES, INCLUDING SPECIAL, INDIRECT, INCIDENTAL, OR CONSEQUENTIAL DAMAGES, WITH RESPECT TO ANY CLAIM 
ARISING OUT OF OR IN CONNECTION WITH THE USE OF THE SOFTWARE, EVEN IF IT HAS BEEN OR IS HEREAFTER ADVISED OF THE POSSIBILITY 
OF SUCH DAMAGES.
*/

#include "IndexHashValueJoinIterator.h"

IndexHashValueJoinIterator::IndexHashValueJoinIterator(IteratorClass *left, IteratorClass *right, NREType leftNRE, NREType rightNRE, 
		int estimatedSizeOfRight, 
		  DataMng *dataMng, bool outerJoin, NREType rootNRE,
		char *indexName, int openFileIndex, bool atLeastOne)
{
	this->left = left;
	this->right = right;
	maxSizeRight = 0;
	this->leftNRE = leftNRE;
	this->rightNRE = rightNRE;
	this->dataMng = dataMng;
	this->outerJoin = outerJoin;
	this->rootNRE = rootNRE;
	this->indexName = indexName;
	this->openFileIndex = openFileIndex;
	this->atLeastOne = atLeastOne;

	if (this->atLeastOne)
	{
		ibMax = 100;
		ib = new int[ibMax];
		ibSz = 0;
	}
	else
	{
		ib = NULL;
		ibSz = 0;
		ibMax = 0;
	}
	if (estimatedSizeOfRight <= 0)
		this->estimatedSizeOfRight = gSettings->getIntegerValue("INITIAL_DEFAULT_RIGHT_ARRAY_SIZE",INITIAL_RIGHT_ARRAY_SIZE_DEFAULT);
	else
		this->estimatedSizeOfRight = estimatedSizeOfRight;


	rightArray = new WitnessTree[this->estimatedSizeOfRight];
	actualSizeRight = 0;
	this->rightCursor = 0;

	left->next(leftTuple);
	right->next(rightTuple);

	resultBuffer = new WitnessTree(LIST_NODE_WITH_DATA,dataMng);
	leftJoined = false;
	indAccess = NULL;
	indAccessTuple = NULL;
}

IndexHashValueJoinIterator::~IndexHashValueJoinIterator()
{
	
	if (this->maxSizeRight < this->actualSizeRight)
		this->maxSizeRight = this->actualSizeRight;
	for (int i=0; i<this->maxSizeRight; i++)
		rightArray[i].setDeleteBuffers(true);
	
	delete [] rightArray;

	delete resultBuffer;
	
	delete left;
	if (right) delete right;

	if (indexName)
		delete [] indexName;

	if (indAccess)
		delete indAccess;
	if (ib) delete [] ib;
}

void IndexHashValueJoinIterator::next(WitnessTree *&node)
{
#ifdef EVAL_TIME_OUT
	clock_t currTime = clock();
	double queryDuration = (double)(currTime - gQueryStartTime) / CLOCKS_PER_SEC;
	if (queryDuration >= gTimeOutAfter)
	{
		globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"Evaluator",__FILE__,"Query Timed Out.");
		node = NULL;
		return;
	}
#endif
	int res = joinNested() ;

	if (res == SUCCESS)
	{
		node = resultBuffer;
		return;
	}
	else
	{
		node = NULL;
		return;
	}
}

void IndexHashValueJoinIterator::addToArray(WitnessTree *&treeArray, WitnessTree *inTree, int &arraySize, int &maxSize, int index)
{
	//in this method, we write inTree into the buffer treeArray.

	//if the array is not big enough, double its size
	if (arraySize >= maxSize)
	{
		WitnessTree *tmp = treeArray;
		maxSize *= 2;
		treeArray = new WitnessTree[maxSize];
		memcpy(treeArray, tmp, arraySize * sizeof(WitnessTree));
		delete [] tmp;
	}

	//now copy inTree to the next empty slot in treeArray
	treeArray[arraySize].copyTree(inTree);
	typedef pair<double, int> DoubleIntPair;

	treeArray[arraySize].setDeleteBuffers(false);

	if (this->atLeastOne)
	{
		inTree->startFindNodesNRE(rightNRE);
		ComplexListNode *n = (ComplexListNode *)inTree->getNextNodeNRE();
		
		while (n)
		{
			KeyType sk = n->GetStartPos();
			hashTable.insert(DoubleIntPair(sk.toDouble(),arraySize));
			n = (ComplexListNode *)inTree->getNextNodeNRE();
		}
	}
	else
	{
		KeyType sk = ((ComplexListNode *)inTree->getNodeByIndex(index))->GetStartPos();
		hashTable.insert(DoubleIntPair(sk.toDouble(),arraySize));
	}
	arraySize++;
}


void IndexHashValueJoinIterator::writeToResult(WitnessTree *leftTree, WitnessTree *rightTree)
{
	// in this method, we write leftTree and rightTree into resultBuffer under a bogus
	//root "root"

	if (leftTree)
	{
		resultBuffer->initialize();

		//adding the dummy root.
		ComplexListNode dummy;
		dummy.SetDummy(true);
		dummy.SetDummyName("<root>");
		dummy.setNRE(this->rootNRE);
		resultBuffer->appendList(&dummy,dataMng,1);	

		//adding leftTree
		if (leftTree->isSimple())
			resultBuffer->appendList((ListNode *)leftTree->getBuffer(),leftTree->length());
		else
		{
			//if leftTree already has a dummy root, don't add it.
			if (((ComplexListNode *)leftTree->findNode(0))->IsDummy() && 
				strcmp("<root>",((ComplexListNode *)leftTree->getNodeByIndex(0))->GetDummyName()) == 0)	
				resultBuffer->appendList((ComplexListNode *)leftTree->getNodeByIndex(1),dataMng,(leftTree->length())-1);
			else
				resultBuffer->appendList((ComplexListNode *)leftTree->getBuffer(),dataMng,leftTree->length());
		}

	//	dummy.SetDummyName("<subroot>");
	//	resultBuffer->appendList(&dummy,dataMng,1);	
		initSize = resultBuffer->length();
	}
	//adding rightTree
	if (rightTree)
	{
		if (rightTree->isSimple())
			resultBuffer->appendList((ListNode *)rightTree->getBuffer(),rightTree->length());
		else
		{
			//if rightTree already has a dummy root, don't add it.
			if (((ComplexListNode *)rightTree->findNode(0))->IsDummy() && 
				strcmp("<root>",((ComplexListNode *)rightTree->getNodeByIndex(0))->GetDummyName()) == 0)	
				resultBuffer->appendList((ComplexListNode *)rightTree->getNodeByIndex(1),dataMng,(rightTree->length())-1);
			else
				resultBuffer->appendList((ComplexListNode *)rightTree->getBuffer(),dataMng,rightTree->length());
		}
	}
}

int IndexHashValueJoinIterator::joinable(WitnessTree *in1, WitnessTree *in2, int &result)
{
	// in this method, we check if in1 and in2 join. it returns 0 if there is a
	//match in case of sorted input. it returns 1 if there is a match in case
	//of nested-loop join

	result = SUCCESS;

	return useIndexToMatch(in1,in2,result);
}


int IndexHashValueJoinIterator::setIndex(WitnessTree *leftTree,  
										WitnessTree *rightTree, bool checkMultiple)
{

	//this method sets leftIndex and rightIndex to the proper values
	if (leftTree)
	{
		if (checkMultiple && leftTree->moreThanOneMatch(leftNRE))
		{
			globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"Evaluator",__FILE__,"More than one node matched left NRE.");
			return FAILURE;
		}
		this->leftIndex = leftTree->getIndexOfNRE(leftNRE);
		if (leftIndex == -1)
		{
			globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"Evaluator",__FILE__,"Could not find node with left NRE.");
			return FAILURE;
		}
	}

	if (rightTree)
	{
		if (checkMultiple && rightTree->moreThanOneMatch(rightNRE))
		{
			globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"Evaluator",__FILE__,"More than one node matched right NRE.");
			return FAILURE;
		}
		this->rightIndex = rightTree->getIndexOfNRE(rightNRE);
		if (rightIndex == -1)
		{
			globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"Evaluator",__FILE__,"Could not find node with right NRE.");
			return FAILURE;
		}
	}
	return SUCCESS;
}

int IndexHashValueJoinIterator::joinNested()
{
	int result;
	while (leftTuple)
	{	
		writeToResult(leftTuple,NULL);

		//as long as we still have right inputs,
		while (rightTuple)
		{ //we are still writing to the array... i.e. we are joining with the first left input tree

			if (this->setIndex(NULL,rightTuple,!atLeastOne) == FAILURE)
				return FAILURE;
			//write right input tree to the buffer
			addToArray(rightArray, rightTuple, actualSizeRight, estimatedSizeOfRight,rightIndex);

			//check if left and right input trees join
			if (joinable(leftTuple,&(rightArray[actualSizeRight-1]),result))
				writeToResult(NULL,&(rightArray[actualSizeRight-1]));

			if (result == FAILURE)
				return FAILURE;

			right->next(rightTuple);
			if (!rightTuple)
			{
				delete right;
				right = NULL;
				if (globalErrorInfo.doWeHaveAProblem())
					return FAILURE;
				left->next(leftTuple);
				if (resultBuffer->length() > initSize)
					return SUCCESS;
				if (outerJoin)
					return SUCCESS;

				if (!leftTuple)
					return FAILURE;
				else
					writeToResult(leftTuple,NULL);
			}
		}
		//we read all right input, and we have in the buffer. so now, we read
		//right inputs from buffer.
		if (actualSizeRight == 0)
		{
			if (!outerJoin)
				return FAILURE;
			else
			{
				//writeToResult(leftTuple,NULL);
				left->next(leftTuple);
				return SUCCESS;
			}
		}

		if (useIndexAndHashToMatch(leftTuple,result))
		{
			left->next(leftTuple);
			return SUCCESS;
		}
		left->next(leftTuple);
		if (outerJoin)
			return SUCCESS;
	}
	return FAILURE;
}

void IndexHashValueJoinIterator::addToBuffer(int index)
{
	if (ibSz == ibMax)
	{
		ibMax *= 2;
		int *tmp = ib;
		ib = new int[ibMax];
		memcpy(ib,tmp,ibSz*sizeof(int));
		delete [] tmp;
	}
	ib[ibSz] = index;
	ibSz++;
}

bool IndexHashValueJoinIterator::leftJoins(KeyType sk, bool addToBuf)
{
	indAccess = getIndexAccess(sk);
	indAccess->next(indAccessTuple);

	bool foundMatches = false;
	while (indAccessTuple)
	{
		KeyType indexSK = ((ListNode *)indAccessTuple->getNodeByIndex(0))->GetStartPos();
		hashTabIter = this->hashTable.find(indexSK.toDouble());

		while (hashTabIter != hashTable.end() && hashTabIter->first == indexSK.toDouble())
		{
			foundMatches = true;
			if (addToBuf)
				addToBuffer(hashTabIter->second);
			else
				writeToResult(NULL,&rightArray[hashTabIter->second]);
			hashTabIter++;
		}
		indAccess->next(indAccessTuple);
	}
	delete indAccess;
	indAccess = NULL;
	return foundMatches;
}

int compareInts(const void *n1, const void *n2)
{
	return (*((int *)n1)) - (*((int *)n2)); 
}

void IndexHashValueJoinIterator::sortIndexBuffer()
{
	qsort(ib,ibSz,sizeof(int),&compareInts);
}

void IndexHashValueJoinIterator::writeIndexBufferToResult()
{
	int lastIndex = -1;
	for (int i=0; i<ibSz; i++)
	{
		if (lastIndex != ib[i])
		{
			writeToResult(NULL,&rightArray[ib[i]]);
			lastIndex = ib[i];
		}
	}
}

bool IndexHashValueJoinIterator::useIndexAndHashToMatch(WitnessTree *in1,int &result)
{
	result = SUCCESS;
	if (this->atLeastOne)
	{
		bool leftJoined = false;
		in1->startFindNodesNRE(this->leftNRE);
		int leftIndex = in1->getNextIndexNRE();

		if (leftIndex == -1)
		{
			globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"Evaluator",__FILE__,"Could not find node with left NRE.");
			result = FAILURE;
			return false;
		}

		while (leftIndex != -1)
		{
			KeyType sk = ((ComplexListNode *)in1->getNodeByIndex(leftIndex))->GetStartPos();
			if (leftJoins(sk,true))
				leftJoined = true;
			leftIndex = in1->getNextIndexNRE();
		}
		sortIndexBuffer();
		writeIndexBufferToResult();
		ibSz = 0;
		return leftJoined;
	}
	else
	{
		if (this->setIndex(in1,NULL,!atLeastOne) == FAILURE)
		{
			result = FAILURE;
			return false;
		}
		KeyType sk = ((ComplexListNode *)in1->getNodeByIndex(leftIndex))->GetStartPos();
		return leftJoins(sk,false);
	}
}


int IndexHashValueJoinIterator::useIndexToMatch(WitnessTree *in1, WitnessTree *in2, int &result)
{
	result = SUCCESS;
	if (this->atLeastOne)
	{
		in1->startFindNodesNRE(this->leftNRE);
		int leftIndex = in1->getNextIndexNRE();

		if (leftIndex == -1)
		{
			globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"Evaluator",__FILE__,"Could not find node with left NRE.");
			result = FAILURE;
			return 0;
		}

		while (leftIndex != -1)
		{
			in2->startFindNodesNRE(this->rightNRE);
			int rightIndex = in2->getNextIndexNRE();

			if (rightIndex == -1)
			{
				globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"Evaluator",__FILE__,"Could not find node with right NRE.");
				result = FAILURE;
				return 0;
			}
			while (rightIndex != -1)
			{
				if (compareStartKeys(in1,in2,leftIndex,rightIndex))
					return 1;
				rightIndex = in2->getNextIndexNRE();
			}

			leftIndex = in1->getNextIndexNRE();
		}
		return 0;
	}
	else
	{
		if (this->setIndex(in1,in2,!atLeastOne) == FAILURE)
		{
			result = FAILURE;
			return 0;
		}
		return compareStartKeys(in1,in2,leftIndex,rightIndex);
	}
}

int IndexHashValueJoinIterator::compareStartKeys(WitnessTree *in1, WitnessTree *in2,int index1, int index2)
{
	KeyType leftSK = in1->isSimple()? ((ListNode *)in1->getNodeByIndex(index1))->GetStartPos():
						((ComplexListNode *)in1->getNodeByIndex(index1))->GetStartPos();
	KeyType rightSK = in2->isSimple()? ((ListNode *)in2->getNodeByIndex(index2))->GetStartPos():
						((ComplexListNode *)in2->getNodeByIndex(index2))->GetStartPos();

	GistIndexAccess *ia = getIndexAccess(leftSK);
	WitnessTree *iaTuple;

	ia->next(iaTuple);
	while (iaTuple)
	{
		KeyType indexSK = ((ListNode *)iaTuple->getNodeByIndex(0))->GetStartPos();
		if (indexSK == rightSK)
		{
			delete ia;
			return 1;
		}
		ia->next(iaTuple);
	}

	delete ia;
	return 0;
}

GistIndexAccess *IndexHashValueJoinIterator::getIndexAccess(KeyType leftSK)
{
	bt_query_t *pred;
	pred = new bt_query_t(bt_query_t::bt_eq, new double(leftSK.toDouble()), NULL);

	char *newIndexName = new char[strlen(indexName)+1];
	strcpy(newIndexName,indexName);
	GistIndexAccess *ia = new GistIndexAccess(newIndexName,pred,DOUBLE_INDEX,(char)openFileIndex,SUPPLEMENTARY_NODES_NRE);
	return ia;
}