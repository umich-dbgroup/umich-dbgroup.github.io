/*
COPYRIGHT  � 2000-2004 
THE REGENTS OF THE UNIVERSITY OF MICHIGAN
ALL RIGHTS RESERVED

PERMISSION IS GRANTED TO USE, COPY, CREATE DERIVATIVE WORKS AND REDISTRIBUTE THIS SOFTWARE AND SUCH DERIVATIVE WORKS FOR 
NONCOMMERCIAL EDUCATION AND RESEARCH PURPOSES, SO LONG AS NO FEE IS CHARGED, AND SO LONG AS THE COPYRIGHT NOTICE ABOVE, 
THIS GRANT OF PERMISSION, AND THE DISCLAIMER BELOW APPEAR IN ALL COPIES MADE; AND SO LONG AS THE NAME OF THE UNIVERSITY 
OF MICHIGAN IS NOT USED IN ANY ADVERTISING OR PUBLICITY PERTAINING TO THE USE OR DISTRIBUTION OF THIS SOFTWARE WITHOUT 
SPECIFIC, WRITTEN PRIOR AUTHORIZATION.

THIS SOFTWARE IS PROVIDED AS IS, WITHOUT REPRESENTATION FROM THE UNIVERSITY OF MICHIGAN AS TO ITS FITNESS FOR ANY PURPOSE, 
AND WITHOUT WARRANTY BY THE UNIVERSITY OF MICHIGAN OF ANY KIND, EITHER EXPRESS OR IMPLIED, INCLUDING WITHOUT LIMITATION THE 
IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE. THE REGENTS OF THE UNIVERSITY OF MICHIGAN SHALL 
NOT BE LIABLE FOR ANY DAMAGES, INCLUDING SPECIAL, INDIRECT, INCIDENTAL, OR CONSEQUENTIAL DAMAGES, WITH RESPECT TO ANY CLAIM 
ARISING OUT OF OR IN CONNECTION WITH THE USE OF THE SOFTWARE, EVEN IF IT HAS BEEN OR IS HEREAFTER ADVISED OF THE POSSIBILITY 
OF SUCH DAMAGES.
*/


#include "MergeTreesIterator.h"

MergeTreesIterator::MergeTreesIterator(IteratorClass **inputs,int numInputs, DataMng *dataMng)
{
	this->inputs = inputs;
	this->numInputs = numInputs;
	this->dataMng = dataMng;

	resultBuffer = new WitnessTree(LIST_NODE_WITH_DATA,dataMng);
	inTuple = new WitnessTree *[numInputs];
	for (int i=0; i<numInputs; i++)
		inputs[i]->next(inTuple[i]);
	res = SUCCESS;
}

MergeTreesIterator::~MergeTreesIterator()
{
	delete resultBuffer;
	delete [] inTuple;
	for (int i=0; i<numInputs; i++)
		delete inputs[i];
	delete [] inputs;
}

void MergeTreesIterator::next(WitnessTree *&node)
{
	//as long as we have at least one input
	while (res == SUCCESS)
	{
		//fuse the trees into resultBuffer
		fuseTrees();

		//get new inputs
		res = getInputs();
		node = resultBuffer;
		return;
	}
	node = NULL;
}

int MergeTreesIterator::getInputs()
{

	//this method gets input trees from input iterators. it returns FAILURE
	// if all inputs are done.
	bool oneIsThere = false;
	for (int i=0; i<numInputs; i++)
	{
		if (inTuple[i])
		{
			inputs[i]->next(inTuple[i]);
			if (inTuple[i])
				oneIsThere = true;
		}
	}
	return (oneIsThere? SUCCESS : FAILURE);
}


bool MergeTreesIterator::allNullInputs()
{
	for (int i=0; i<numInputs; i++)
	{
		if (inTuple[i])
			return false;
	}
	return true;
}

void MergeTreesIterator::fuseTrees()
{
	//this method just just merges the input trees into resultBuffer.
	resultBuffer->initialize();

	//write the bogus root
	ComplexListNode n;
	n.SetDummy(true);
	n.SetDummyName("<root>");
	resultBuffer->appendList(&n,dataMng,1);

	//write the input trees
	for (int i=0; i<numInputs; i++)
	{
		if (inTuple[i] == NULL)
			continue;

		if (inTuple[i]->isSimple())
			resultBuffer->appendList((ListNode *)inTuple[i]->getBuffer(),inTuple[i]->length());
		else
		{
			ComplexListNode *n2 = (ComplexListNode *)inTuple[i]->getNodeByIndex(0);
			if (n2)
				if (n2->IsDummy())
					if (strncmp(n2->GetDummyName(),"<root>",6) == 0)
						resultBuffer->appendList((ComplexListNode *)inTuple[i]->getNodeByIndex(1),dataMng,inTuple[i]->length()-1);
					else
						resultBuffer->appendList((ComplexListNode *)inTuple[i]->getBuffer(),dataMng,inTuple[i]->length());
				else
					resultBuffer->appendList((ComplexListNode *)inTuple[i]->getBuffer(),dataMng,inTuple[i]->length());
		}
	}
}