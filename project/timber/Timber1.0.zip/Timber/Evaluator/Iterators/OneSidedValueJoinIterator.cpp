/*
COPYRIGHT  � 2000-2004 
THE REGENTS OF THE UNIVERSITY OF MICHIGAN
ALL RIGHTS RESERVED

PERMISSION IS GRANTED TO USE, COPY, CREATE DERIVATIVE WORKS AND REDISTRIBUTE THIS SOFTWARE AND SUCH DERIVATIVE WORKS FOR 
NONCOMMERCIAL EDUCATION AND RESEARCH PURPOSES, SO LONG AS NO FEE IS CHARGED, AND SO LONG AS THE COPYRIGHT NOTICE ABOVE, 
THIS GRANT OF PERMISSION, AND THE DISCLAIMER BELOW APPEAR IN ALL COPIES MADE; AND SO LONG AS THE NAME OF THE UNIVERSITY 
OF MICHIGAN IS NOT USED IN ANY ADVERTISING OR PUBLICITY PERTAINING TO THE USE OR DISTRIBUTION OF THIS SOFTWARE WITHOUT 
SPECIFIC, WRITTEN PRIOR AUTHORIZATION.

THIS SOFTWARE IS PROVIDED AS IS, WITHOUT REPRESENTATION FROM THE UNIVERSITY OF MICHIGAN AS TO ITS FITNESS FOR ANY PURPOSE, 
AND WITHOUT WARRANTY BY THE UNIVERSITY OF MICHIGAN OF ANY KIND, EITHER EXPRESS OR IMPLIED, INCLUDING WITHOUT LIMITATION THE 
IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE. THE REGENTS OF THE UNIVERSITY OF MICHIGAN SHALL 
NOT BE LIABLE FOR ANY DAMAGES, INCLUDING SPECIAL, INDIRECT, INCIDENTAL, OR CONSEQUENTIAL DAMAGES, WITH RESPECT TO ANY CLAIM 
ARISING OUT OF OR IN CONNECTION WITH THE USE OF THE SOFTWARE, EVEN IF IT HAS BEEN OR IS HEREAFTER ADVISED OF THE POSSIBILITY 
OF SUCH DAMAGES.
*/

#include "OneSidedValueJoinIterator.h"

OneSidedValueJoinIterator::OneSidedValueJoinIterator(IteratorClass *left, char *joinIndexName, char openFileIndex,
													 NREType leftNRE, NREType assignedRightNRE,   
		 bool nest, bool outerJoin, NREType rootNRE,DataMng *dataMng)
{
	this->left = left;
	this->openFileIndex = openFileIndex;
	this->leftNRE = leftNRE;
	this->assignedRightNRE = assignedRightNRE;
	this->dataMng = dataMng;
	this->joinIndexName = joinIndexName;
	
	this->nest = nest;
	this->outerJoin = outerJoin;
	this->rootNRE = rootNRE;

	leftJoined = false;
	
	left->next(leftTuple);

	right = NULL;
	if (leftTuple)
	{
		if (leftTuple->isSimple())
			resultBuffer = new WitnessTree;
		else
			resultBuffer = new WitnessTree(LIST_NODE_WITH_DATA,dataMng);
		if (setIndex(leftTuple) == FAILURE)
			leftTuple = NULL;

	}
	else
		resultBuffer = NULL;
	
}

OneSidedValueJoinIterator::~OneSidedValueJoinIterator()
{

	if (resultBuffer) delete resultBuffer;
	
	delete left;
	if (right) delete right;
	if (joinIndexName) delete [] joinIndexName;
}

void OneSidedValueJoinIterator::next(WitnessTree *&node)
{
#ifdef EVAL_TIME_OUT
	clock_t currTime = clock();
	double queryDuration = (double)(currTime - gQueryStartTime) / CLOCKS_PER_SEC;
	if (queryDuration >= gTimeOutAfter)
	{
		globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"Evaluator",__FILE__,"Query Timed Out.");
		node = NULL;
		return;
	}
#endif

	if (!leftTuple)
	{
		node = NULL;
		return;
	}
	int result;
	while (!joinable(leftTuple,result))
	{
		if (result == FAILURE)
		{
			node = NULL;
			return;
		}
	//	left->next(leftTuple);
		if (!leftTuple)
		{
			node = NULL;
			return;
		}
		
	}
	if (result == FAILURE)
	{
		node = NULL;
		return;
	}
	node = resultBuffer;
}

void OneSidedValueJoinIterator::writeToResult(WitnessTree *leftTree, WitnessTree *rightTree)
{
	// in this method, we write leftTree and rightTree into resultBuffer under a bogus
	//root "root"

	if (leftTree)
	{
		resultBuffer->initialize();

		//adding the dummy root.
		ComplexListNode dummy;
		dummy.SetDummy(true);
		dummy.SetDummyName("<root>");
		dummy.setNRE(this->rootNRE);
		resultBuffer->appendList(&dummy,dataMng,1);	

		//adding leftTree
		if (leftTree->isSimple())
			resultBuffer->appendList((ListNode *)leftTree->getBuffer(),leftTree->length());
		else
		{
			//if leftTree already has a dummy root, don't add it.
			if (((ComplexListNode *)leftTree->findNode(0))->IsDummy() && 
				strcmp("<root>",((ComplexListNode *)leftTree->getNodeByIndex(0))->GetDummyName()) == 0)	
				resultBuffer->appendList((ComplexListNode *)leftTree->getNodeByIndex(1),dataMng,(leftTree->length())-1);
			else
				resultBuffer->appendList((ComplexListNode *)leftTree->getBuffer(),dataMng,leftTree->length());
		}

		initSize = resultBuffer->length();
	}
	//adding rightTree
	if (rightTree)
	{
		if (rightTree->isSimple())
			resultBuffer->appendList((ListNode *)rightTree->getBuffer(),rightTree->length());
		else
		{
			//if rightTree already has a dummy root, don't add it.
			if (((ComplexListNode *)rightTree->findNode(0))->IsDummy() && 
				strcmp("<root>",((ComplexListNode *)rightTree->getNodeByIndex(0))->GetDummyName()) == 0)	
				resultBuffer->appendList((ComplexListNode *)rightTree->getNodeByIndex(1),dataMng,(rightTree->length())-1);
			else
				resultBuffer->appendList((ComplexListNode *)rightTree->getBuffer(),dataMng,rightTree->length());
		}
	}
}

bool OneSidedValueJoinIterator::joinable(WitnessTree *&leftTuple, int &result)
{
	result = SUCCESS;
	if (nest)
	{
		writeToResult(leftTuple,NULL);
		right->next(rightTuple);
		while (rightTuple)
		{
			writeToResult(NULL,rightTuple);
			right->next(rightTuple);
		}
		left->next(leftTuple);
		if (leftTuple)
		{
			if (setIndex(leftTuple) == FAILURE)
			{
				result = FAILURE;
				return false;
			}
		}
		if (initSize == resultBuffer->length())
			return this->outerJoin;
		return true;
		//we need to get new left in any case
	}
	else
	{
		if (!leftJoined)
		{
			leftJoined = true;
		
			right->next(rightTuple);
			if (rightTuple)
			{
				writeToResult(leftTuple,rightTuple);
				return true;
				//we need NOT get new left
			}
			else
			{
				//we need to get new left
				left->next(leftTuple);
				if (leftTuple)
				{
					if (setIndex(leftTuple) == FAILURE)
					{
						result = FAILURE;
						return false;
					}
				}
				writeToResult(leftTuple,NULL);
				return this->outerJoin;
			}

		}
		else
		{
			right->next(rightTuple);
			if (rightTuple)
			{
				writeToResult(leftTuple,rightTuple);
				return true;
				//we need NOT get new left
			}
			else
			{
				left->next(leftTuple);
				if (leftTuple)
				{
					writeToResult(leftTuple,NULL);
					if (setIndex(leftTuple) == FAILURE)
					{
						result = FAILURE;
						return false;
					}
				}
				//we need to get new left
				return false;
			}
		}
	}
}

int OneSidedValueJoinIterator::setIndex(WitnessTree *leftTree)
{
	if (leftTree->moreThanOneMatch(leftNRE))
	{
		globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"Evaluator",__FILE__,"More than one node matched left NRE.");
		return FAILURE;
	}
	this->leftIndex = leftTree->getIndexOfNRE(leftNRE);
	if (leftIndex == -1)
	{
		globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"Evaluator",__FILE__,"Could not find node with left NRE.");
		return FAILURE;
	}
	KeyType leftSK = (leftTree->isSimple()? 
			((ListNode *)leftTree->getNodeByIndex(leftIndex))->GetStartPos():
			((ComplexListNode *)leftTree->getNodeByIndex(leftIndex))->GetStartPos());

	bt_query_t *pred;
	pred = new bt_query_t(bt_query_t::bt_eq, new double(leftSK.toDouble()), NULL);

	if (right) delete right;
	char *newIndexName = new char[strlen(joinIndexName)+1];
	strcpy(newIndexName,joinIndexName);
	right = new GistIndexAccess(newIndexName,pred,DOUBLE_INDEX,openFileIndex,assignedRightNRE);
	leftJoined = false;
	return SUCCESS;
}