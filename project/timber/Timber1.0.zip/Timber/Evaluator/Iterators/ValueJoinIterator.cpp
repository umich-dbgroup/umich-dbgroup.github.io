/*
COPYRIGHT  � 2000-2004 
THE REGENTS OF THE UNIVERSITY OF MICHIGAN
ALL RIGHTS RESERVED

PERMISSION IS GRANTED TO USE, COPY, CREATE DERIVATIVE WORKS AND REDISTRIBUTE THIS SOFTWARE AND SUCH DERIVATIVE WORKS FOR 
NONCOMMERCIAL EDUCATION AND RESEARCH PURPOSES, SO LONG AS NO FEE IS CHARGED, AND SO LONG AS THE COPYRIGHT NOTICE ABOVE, 
THIS GRANT OF PERMISSION, AND THE DISCLAIMER BELOW APPEAR IN ALL COPIES MADE; AND SO LONG AS THE NAME OF THE UNIVERSITY 
OF MICHIGAN IS NOT USED IN ANY ADVERTISING OR PUBLICITY PERTAINING TO THE USE OR DISTRIBUTION OF THIS SOFTWARE WITHOUT 
SPECIFIC, WRITTEN PRIOR AUTHORIZATION.

THIS SOFTWARE IS PROVIDED AS IS, WITHOUT REPRESENTATION FROM THE UNIVERSITY OF MICHIGAN AS TO ITS FITNESS FOR ANY PURPOSE, 
AND WITHOUT WARRANTY BY THE UNIVERSITY OF MICHIGAN OF ANY KIND, EITHER EXPRESS OR IMPLIED, INCLUDING WITHOUT LIMITATION THE 
IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE. THE REGENTS OF THE UNIVERSITY OF MICHIGAN SHALL 
NOT BE LIABLE FOR ANY DAMAGES, INCLUDING SPECIAL, INDIRECT, INCIDENTAL, OR CONSEQUENTIAL DAMAGES, WITH RESPECT TO ANY CLAIM 
ARISING OUT OF OR IN CONNECTION WITH THE USE OF THE SOFTWARE, EVEN IF IT HAS BEEN OR IS HEREAFTER ADVISED OF THE POSSIBILITY 
OF SUCH DAMAGES.
*/

#include "ValueJoinIterator.h"

ValueJoinIterator::ValueJoinIterator(IteratorClass *left, IteratorClass *right, NREType leftNRE, NREType rightNRE, 
		int leftTag, int rightTag, int estimatedSizeOfRight, char *attrNameLeft, char *attrNameRight,
		  DataMng *dataMng, int operation, 
		int joinByWhatLeft, int joinByWhatRight, bool sortedInput, bool nest, bool outerJoin, NREType rootNRE,
		char *indexName, int openFileIndex,
		bool atLeastOne)
{
	this->left = left;
	this->right = right;
	maxSizeRight = 0;
	this->leftNRE = leftNRE;
	this->rightNRE = rightNRE;
	this->leftTag = leftTag;
	this->rightTag = rightTag;
	this->sortedInput = sortedInput;
	this->dataMng = dataMng;
	this->joinByWhatLeft = joinByWhatLeft;
	this->joinByWhatRight = joinByWhatRight;
	this->operation = operation;
//	this->leftIsActual = (leftTag? true : false);
//	this->rightIsActual = (rightTag? true : false);
	this->nest = nest;
	this->outerJoin = outerJoin;
	this->rootNRE = rootNRE;
	this->indexName = indexName;
	this->openFileIndex = openFileIndex;
	this->atLeastOne = atLeastOne;

	if (sortedInput)
	{
		this->estimatedSizeOfRight = gSettings->getIntegerValue("INITIAL_BUFFER_SIZE",INITIAL_BUFFER_SIZE_DEFAULT);
		this->operation = JOINOP_EQ_STR;  // for sort-merge i support equi-joins only for now
		readFromArray = false;
	}
	else if (estimatedSizeOfRight <= 0)
		this->estimatedSizeOfRight = gSettings->getIntegerValue("INITIAL_DEFAULT_RIGHT_ARRAY_SIZE",INITIAL_RIGHT_ARRAY_SIZE_DEFAULT);
	else
		this->estimatedSizeOfRight = estimatedSizeOfRight;

	this->attrNameLeft = attrNameLeft;
	this->attrNameRight = attrNameRight;


	rightArray = new WitnessTree[this->estimatedSizeOfRight];
	actualSizeRight = 0;
	this->rightCursor = 0;

	left->next(leftTuple);
	right->next(rightTuple);

	resultBuffer = new WitnessTree(LIST_NODE_WITH_DATA,dataMng);
	leftJoined = false;
}

ValueJoinIterator::~ValueJoinIterator()
{
	//if (rightArray[0].getDeleteBuffers() == false)
	//{
		if (this->maxSizeRight < this->actualSizeRight)
			this->maxSizeRight = this->actualSizeRight;
		for (int i=0; i<this->maxSizeRight; i++)
			rightArray[i].setDeleteBuffers(true);
	//}
	delete [] rightArray;

	delete resultBuffer;
	
	delete left;
	if (right) delete right;

	if (attrNameLeft)
		delete [] attrNameLeft;
	if (attrNameRight)
		delete [] attrNameRight;
	if (indexName)
		delete [] indexName;
}

void ValueJoinIterator::next(WitnessTree *&node)
{
#ifdef EVAL_TIME_OUT
	clock_t currTime = clock();
	double queryDuration = (double)(currTime - gQueryStartTime) / CLOCKS_PER_SEC;
	if (queryDuration >= gTimeOutAfter)
	{
		globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"Evaluator",__FILE__,"Query Timed Out.");
		node = NULL;
		return;
	}
#endif
	int res;
	if (this->sortedInput)
		res = nest? joinSortMergeN() : joinSortMerge();
	else
		res = nest? joinNestedLoopsN() : joinNestedLoops();

	if (res == SUCCESS)
	{
		node = resultBuffer;
		return;
	}
	else
	{
		node = NULL;
		return;
	}
}

void ValueJoinIterator::addToArray(WitnessTree *&treeArray, WitnessTree *inTree, int &arraySize, int &maxSize)
{
	//in this method, we write inTree into the buffer treeArray.

	//if the array is not big enough, double its size
	if (arraySize >= maxSize)
	{
		WitnessTree *tmp = treeArray;
		maxSize *= 2;
		treeArray = new WitnessTree[maxSize];
		memcpy(treeArray, tmp, arraySize * sizeof(WitnessTree));
		delete [] tmp;
	}

	//now copy inTree to the next empty slot in treeArray
	treeArray[arraySize].copyTree(inTree);
	treeArray[arraySize].setDeleteBuffers(false);
	arraySize++;
}


void ValueJoinIterator::writeToResult(WitnessTree *leftTree, WitnessTree *rightTree)
{
	// in this method, we write leftTree and rightTree into resultBuffer under a bogus
	//root "root"

	if (leftTree)
	{
		resultBuffer->initialize();

		//adding the dummy root.
		ComplexListNode dummy;
		dummy.SetDummy(true);
		dummy.SetDummyName("<root>");
		dummy.setNRE(this->rootNRE);
		resultBuffer->appendList(&dummy,dataMng,1);	

		//adding leftTree
		if (leftTree->isSimple())
			resultBuffer->appendList((ListNode *)leftTree->getBuffer(),leftTree->length());
		else
		{
			//if leftTree already has a dummy root, don't add it.
			if (((ComplexListNode *)leftTree->findNode(0))->IsDummy() && 
				strcmp("<root>",((ComplexListNode *)leftTree->getNodeByIndex(0))->GetDummyName()) == 0)	
				resultBuffer->appendList((ComplexListNode *)leftTree->getNodeByIndex(1),dataMng,(leftTree->length())-1);
			else
				resultBuffer->appendList((ComplexListNode *)leftTree->getBuffer(),dataMng,leftTree->length());
		}

	//	dummy.SetDummyName("<subroot>");
	//	resultBuffer->appendList(&dummy,dataMng,1);	
		initSize = resultBuffer->length();
	}
	//adding rightTree
	if (rightTree)
	{
		if (rightTree->isSimple())
			resultBuffer->appendList((ListNode *)rightTree->getBuffer(),rightTree->length());
		else
		{
			//if rightTree already has a dummy root, don't add it.
			if (((ComplexListNode *)rightTree->findNode(0))->IsDummy() && 
				strcmp("<root>",((ComplexListNode *)rightTree->getNodeByIndex(0))->GetDummyName()) == 0)	
				resultBuffer->appendList((ComplexListNode *)rightTree->getNodeByIndex(1),dataMng,(rightTree->length())-1);
			else
				resultBuffer->appendList((ComplexListNode *)rightTree->getBuffer(),dataMng,rightTree->length());
		}
	}
}

int ValueJoinIterator::joinable(WitnessTree *in1, WitnessTree *in2, int &result)
{
	// in this method, we check if in1 and in2 join. it returns 0 if there is a
	//match in case of sorted input. it returns 1 if there is a match in case
	//of nested-loop join

	in1->switchToComplex(dataMng);
	in2->switchToComplex(dataMng);
	result = SUCCESS;

	if (this->indexName != NULL)
	//we are using index to match right inputs
		return useIndexToMatch(in1,in2,result);


	//if we are doing cartesian product, this is always true
	if (joinByWhatLeft == JOINBY_NOTHING || joinByWhatRight == JOINBY_NOTHING)
		return (sortedInput? 0: 1);

	if (this->atLeastOne)
		return this->processAtLeastOne(in1, in2,result);

	if (this->setIndex(in1,in2) == FAILURE)
	{
		result = FAILURE;
		return 0;
	}
	if (leftIndex == -1 || rightIndex == -1)
		return (sortedInput? -1: 0);
	//if we are joining by start key, then compare start keys of left and right trees
	if (joinByWhatLeft == JOINBY_STARTKEY || joinByWhatRight == JOINBY_STARTKEY)
		return this->joinableByStartKey(in1,in2,result);
	if (joinByWhatLeft == JOINBY_ENDKEY || joinByWhatRight == JOINBY_ENDKEY)
		return this->joinableByEndKey(in1,in2,result);
	//if we are joining by level, then compare levels of left and right trees
	if (joinByWhatLeft == JOINBY_LEVEL || joinByWhatRight == JOINBY_LEVEL)
		return this->joinableByLevel(in1,in2,result);

	
	in1->switchToComplex(dataMng);
	in2->switchToComplex(dataMng);


	if (joinByWhatLeft == JOINBY_TREE || joinByWhatRight == JOINBY_TREE ||
		joinByWhatRight == JOINBY_TREE_WITHOUT_ROOT || joinByWhatLeft == JOINBY_TREE_WITHOUT_ROOT)
		return this->joinableBySubtree(in1,in2,leftIndex,rightIndex,result);


	char *txtLeft = NULL;
	char *txtRight = NULL;
	int leftTag = -1;
	int rightTag = -1;

	if (joinByWhatLeft == JOINBY_ATTRIBUTE)
		txtLeft = getAttribute(in1,leftIndex, attrNameLeft,result);
	else if (joinByWhatLeft == JOINBY_TEXT)
		txtLeft = getText(in1, leftIndex, false,result);
	else if (joinByWhatLeft == JOINBY_DESC_TEXT)
		txtLeft = getText(in1, leftIndex, true,result);
	else 
		txtLeft = getValue(in1, leftIndex, attrNameLeft,result, leftTag);

	if (result == FAILURE)
		return 0;

	if (joinByWhatRight == JOINBY_ATTRIBUTE)
		txtRight = getAttribute(in2,rightIndex, attrNameRight,result);
	else if (joinByWhatRight == JOINBY_TEXT)
		txtRight = getText(in2,rightIndex,false,result);
	else if (joinByWhatRight == JOINBY_DESC_TEXT)
		txtRight = getText(in2,rightIndex,true,result);
	else 
		txtRight = getValue(in2, rightIndex, attrNameRight,result, rightTag);


	if (result == FAILURE)
		return 0;


	if (txtLeft == NULL && txtRight == NULL && leftTag == -1 && rightTag == -1)
		return (this->sortedInput? -1 : 0);



	if (txtLeft == NULL && leftTag == -1)
	{
		if (txtRight) delete [] txtRight;
		return (sortedInput? -1: 0);
	}
	if (txtRight == NULL && rightTag == -1)
	{
		if (txtLeft) delete [] txtLeft;
		return (sortedInput? 1: 0);
	}
	

	if (!this->sortedInput && (operation == JOINOP_EQ_NUM || operation == JOINOP_EQ_STR ||
		operation == JOINOP_NE_NUM || operation == JOINOP_NE_STR ))
	{
		if (leftTag != -1 && rightTag == -1)
		{
			char *t = dataMng->getPhysicalDataMng()->getXMLNameTable()->getNameByCode(leftTag);
			txtLeft = new char[strlen(t)+1];
			strcpy(txtLeft,t);
		}
		else if (leftTag == -1 && rightTag != -1)
		{
			char *t = dataMng->getPhysicalDataMng()->getXMLNameTable()->getNameByCode(rightTag);
			txtRight = new char[strlen(t)+1];
			strcpy(txtRight,t);
		}
	}
	else
	{// in the cass of non-equi join, we need to get the text to figure out whose bigger or smaller
		if (leftTag != -1)
		{
			char *t = dataMng->getPhysicalDataMng()->getXMLNameTable()->getNameByCode(leftTag);
			txtLeft = new char[strlen(t)+1];
			strcpy(txtLeft,t);
		}
		if (rightTag != -1)
		{
			char *t = dataMng->getPhysicalDataMng()->getXMLNameTable()->getNameByCode(rightTag);
			txtRight = new char[strlen(t)+1];
			strcpy(txtRight,t);
		}
	}
	
	int res;
	if (!this->sortedInput)
	{

		//based on the operation and whether it is numerical or string comparison, 
		//return true if they match, false if they do not.
	
		switch (operation)
		{
		case JOINOP_EQ_NUM: if (txtLeft && txtRight) res = atof(txtLeft) == atof(txtRight); 
							else res = leftTag == rightTag; break; 
		case JOINOP_EQ_STR: if (txtLeft && txtRight) res = (strcmp(txtLeft, txtRight) == 0); 
							else res = leftTag == rightTag; break;

		case JOINOP_NE_NUM: if (txtLeft && txtRight) res = atof(txtLeft) != atof(txtRight); 
							else res = leftTag != rightTag; break; 
		case JOINOP_NE_STR: if (txtLeft && txtRight) res = (strcmp(txtLeft, txtRight) != 0); 
							else res = leftTag != rightTag; break;

		case JOINOP_LT_NUM: res = atof(txtLeft) < atof(txtRight); break; 
		case JOINOP_LT_STR: res = (strcmp(txtLeft, txtRight) < 0); break;

		case JOINOP_LE_NUM: res = atof(txtLeft) <= atof(txtRight); break; 
		case JOINOP_LE_STR: res = (strcmp(txtLeft, txtRight) <= 0); break;

		case JOINOP_GT_NUM: res = atof(txtLeft) > atof(txtRight); break; 
		case JOINOP_GT_STR: res = (strcmp(txtLeft, txtRight) > 0); break;

		case JOINOP_GE_NUM: res = atof(txtLeft) >= atof(txtRight); break; 
		case JOINOP_GE_STR: res = (strcmp(txtLeft, txtRight) >= 0); break;

		case JOINOP_CONTAINS: res = (strstr(txtLeft,txtRight) != NULL); break;
		case JOINOP_CONTAINED_BY: res = (strstr(txtRight,txtLeft) != NULL); break;
		default: result = FAILURE; res = 0;
		globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"Evaluator",__FILE__,"Unrecognized operation.");
		}		
	}
	else
	{
		//if sort-merge join, return 0 if they are equal, return -1 if left is smaller than right
		//return 1 if right is smaller than left.
		switch (operation)
		{
		case JOINOP_EQ_STR: res = strcmp(txtLeft, txtRight);break;
		case JOINOP_EQ_NUM:if (atof(txtLeft) == atof(txtRight))
							res = 0;
						else if (atof(txtLeft) < atof(txtRight))
							res = -1;
						else
							res = 1;
						break;
		case JOINOP_CONTAINS: if (strstr(txtLeft, txtRight) != NULL)
									  res = 0;
								  else
									  res = strcmp(txtLeft, txtRight);
							  break;
		case JOINOP_CONTAINED_BY: if (strstr(txtRight, txtLeft) != NULL)
										  res= 0;
									  else
										  res = strcmp(txtLeft, txtRight);
								  break;
		default: result = FAILURE; res = 0;
		globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"Evaluator",__FILE__,"Unrecognized operation.");
		}
	}

	delete [] txtLeft;
	delete [] txtRight;
	return res;
}


int ValueJoinIterator::setIndex(WitnessTree *leftTree,  
										WitnessTree *rightTree)
{

	//this method sets leftIndex and rightIndex to the proper values
	if (leftTree)
	{
		if (this->leftTag != -1)
		{
			this->leftIndex = EvaluatorClass::findNode(leftTree, this->leftTag, dataMng);
			if (leftIndex == -1)
			{
				globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"Evaluator",__FILE__,"Could not find node with left tag.");
				return FAILURE;
			}
		}
		else
		{
			if (leftTree->moreThanOneMatch(leftNRE))
			{
				globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"Evaluator",__FILE__,"More than one node matched left NRE.");
				return FAILURE;
			}
			this->leftIndex = leftTree->getIndexOfNRE(leftNRE);
			if (leftIndex == -1)
			{
				globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"Evaluator",__FILE__,"Could not find node with left NRE.");
				return FAILURE;
			}
		}
	}

	if (rightTree)
	{
		if (this->rightTag != -1)
		{
			this->rightIndex = EvaluatorClass::findNode(rightTree, this->rightTag, dataMng);
			if (rightIndex == -1)
			{
				globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"Evaluator",__FILE__,"Could not find node with right tag.");
				return FAILURE;
			}
		}
		else
		{
			if (rightTree->moreThanOneMatch(rightNRE))
			{
				globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"Evaluator",__FILE__,"More than one node matched right NRE.");
				return FAILURE;
			}
			this->rightIndex = rightTree->getIndexOfNRE(rightNRE);
			if (rightIndex == -1)
			{
				globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"Evaluator",__FILE__,"Could not find node with right NRE.");
				return FAILURE;
			}
		}
	}
	return SUCCESS;
}

int ValueJoinIterator::joinableByStartKey(WitnessTree *in1, WitnessTree *in2,int &result)
{
	result = SUCCESS;
	KeyType sk1, sk2;
	//get left start key
	if (in1->isSimple())
	{
		ListNode *n = (ListNode *)in1->getNodeByIndex(leftIndex);
		if (n)
			sk1 = n->GetStartPos();
		else
			return (sortedInput? -1: 0);
	}
	else
	{
		ComplexListNode *n = (ComplexListNode *)in1->getNodeByIndex(leftIndex);
		if (n)
			sk1 = n->GetStartPos();
		else
			return (sortedInput? -1: 0);
	}

	//get right start key
	if (in2->isSimple())
	{
		ListNode *n = (ListNode *)in2->getNodeByIndex(rightIndex);
		if (n)
			sk2 = n->GetStartPos();
		else
			return (sortedInput? -1: 0);
	}
	else
	{
		ComplexListNode *n = (ComplexListNode *)in2->getNodeByIndex(rightIndex);
		if (n)
			sk2 = n->GetStartPos();
		else
			return (sortedInput? -1: 0);
	}

	if (!this->sortedInput)
	{
		//if nested-loop join, return true or false based on operation
		switch (operation)
		{
		case JOINOP_EQ_NUM:
		case JOINOP_EQ_STR:
			return (sk1 == sk2);
		case JOINOP_NE_NUM: 
		case JOINOP_NE_STR:
			return (sk1 != sk2);
		case JOINOP_LT_NUM: 
		case JOINOP_LT_STR:
			return (sk1 < sk2);
		case JOINOP_LE_NUM:
		case JOINOP_LE_STR:
			return (sk1 <= sk2);
		case JOINOP_GT_NUM: 
		case JOINOP_GT_STR:
			return (sk1 > sk2);
		case JOINOP_GE_NUM: 
		case JOINOP_GE_STR: 
			return (sk1 >= sk2);
		default: return 0;
		}
	}
	else
	{
		//if sort-merge join, return 0 if they are equal, return -1 if left is smaller than right
		//return 1 if right is smaller than left.
		switch (operation)
		{
		case JOINOP_EQ_NUM: 
		case JOINOP_EQ_STR:
			if (sk1 == sk2) return 0; else if (sk1 < sk2) return -1; else return 1;
		default: return -1;
		}
	}
}

int ValueJoinIterator::joinableByEndKey(WitnessTree *in1, WitnessTree *in2,int &result)
{
	result = SUCCESS;
	KeyType ek1, ek2;
	//get left end key
	if (in1->isSimple())
	{
		ListNode *n = (ListNode *)in1->getNodeByIndex(leftIndex);
		if (n)
			ek1 = n->GetEndPos();
		else
			return (sortedInput? -1: 0);
	}
	else
	{
		ComplexListNode *n = (ComplexListNode *)in1->getNodeByIndex(leftIndex);
		if (n)
			ek1 = n->GetEndPos();
		else
			return (sortedInput? -1: 0);
	}

	//get right end key
	if (in2->isSimple())
	{
		ListNode *n = (ListNode *)in2->getNodeByIndex(rightIndex);
		if (n)
			ek2 = n->GetEndPos();
		else
			return (sortedInput? -1: 0);
	}
	else
	{
		ComplexListNode *n = (ComplexListNode *)in2->getNodeByIndex(rightIndex);
		if (n)
			ek2 = n->GetEndPos();
		else
			return (sortedInput? -1: 0);
	}

	if (!this->sortedInput)
	{
		//if nested-loop join, return true or false based on operation
		switch (operation)
		{
		case JOINOP_EQ_NUM:
		case JOINOP_EQ_STR:
			return (ek1 == ek2);
		case JOINOP_NE_NUM: 
		case JOINOP_NE_STR:
			return (ek1 != ek2);
		case JOINOP_LT_NUM: 
		case JOINOP_LT_STR:
			return (ek1 < ek2);
		case JOINOP_LE_NUM:
		case JOINOP_LE_STR:
			return (ek1 <= ek2);
		case JOINOP_GT_NUM: 
		case JOINOP_GT_STR:
			return (ek1 > ek2);
		case JOINOP_GE_NUM: 
		case JOINOP_GE_STR: 
			return (ek1 >= ek2);
		default: return 0;
		}
	}
	else
	{
		//if sort-merge join, return 0 if they are equal, return -1 if left is smaller than right
		//return 1 if right is smaller than left.
		switch (operation)
		{
		case JOINOP_EQ_NUM: 
		case JOINOP_EQ_STR:
			if (ek1 == ek2) return 0; else if (ek1 < ek2) return -1; else return 1;
		default: return -1;
		}
	}
}

int ValueJoinIterator::joinableByLevel(WitnessTree *in1, WitnessTree *in2,int &result)
{
	result = SUCCESS;
	int l1,l2;

	//get left tree's level
	if (in1->isSimple())
	{
		ListNode *n = (ListNode *)in1->getNodeByIndex(leftIndex);
		if (n)
			l1 = n->GetLevel();
		else
			return (sortedInput? -1: 0);
	}
	else
	{
		ComplexListNode *n = (ComplexListNode *)in1->getNodeByIndex(leftIndex);
		if (n)
			l1 = n->GetLevel();
		else
			return (sortedInput? -1: 0);
	}

	//get right tree's level
	if (in2->isSimple())
	{
		ListNode *n = (ListNode *)in2->getNodeByIndex(rightIndex);
		if (n)
			l2 = n->GetLevel();
		else
			return (sortedInput? -1: 0);
	}
	else
	{
		ComplexListNode *n = (ComplexListNode *)in2->getNodeByIndex(rightIndex);
		if (n)
			l2 = n->GetLevel();
		else
			return (sortedInput? -1: 0);
	}
	if (!this->sortedInput)
	{
		//if nested-loop join, return true or false based on operation
		
		switch (operation)
		{
		case JOINOP_EQ_NUM:
		case JOINOP_EQ_STR:
			return (l1 == l2);
		case JOINOP_NE_NUM: 
		case JOINOP_NE_STR:
			return (l1 != l2);
		case JOINOP_LT_NUM: 
		case JOINOP_LT_STR:
			return (l1 < l2);
		case JOINOP_LE_NUM:
		case JOINOP_LE_STR:
			return (l1 <= l2);
		case JOINOP_GT_NUM: 
		case JOINOP_GT_STR:
			return (l1 > l2);
		case JOINOP_GE_NUM: 
		case JOINOP_GE_STR: 
			return (l1 >= l2);
		default: return 0;
		}
	}
	else
	{
		switch (operation)
		{
			//if sort-merge join, return 0 if they are equal, return -1 if left is smaller than right
			//return 1 if right is smaller than left.
		case JOINOP_EQ_NUM:
		case JOINOP_EQ_STR:
			if (l1 == l2) return 0; else if (l1 < l2) return -1; else return 1;
		default: return -1;
		}
	}
}

char *ValueJoinIterator::getAttribute(WitnessTree *in, int index, char *attrName, int &result)
{
	FileIDType fileid = EvaluatorClass::getFileID(((ComplexListNode *)in->getNodeByIndex(index))->getFileIndex());
	if (fileid == -1)
	{
		globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"Evaluator",__FILE__,"File is unloaded in Timber.");
		result = FAILURE;
		return NULL;
	}
	//get attr node from DB
	if (EvaluatorClass::GetAttributes(in,index,dataMng,fileid) == FAILURE)
		return NULL;

	//get left actual attr value
	Value *attr = ((DM_AttributeNode *)((ComplexListNode *)in->getNodeByIndex(index+1))->GetData())->getAttr(attrName);
	if (!attr)
		return NULL;

	if (attr->getStrValue() == NULL)
		return NULL;
	char *txt = new char[strlen(attr->getStrValue())+1];
	strcpy(txt,attr->getStrValue());
	return txt;		
}

char *ValueJoinIterator::getText(WitnessTree *in, int index, bool desc, int &result)
{
	FileIDType fileid = EvaluatorClass::getFileID(((ComplexListNode *)in->getNodeByIndex(index))->getFileIndex());
	if (fileid == -1)
	{
		globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"Evaluator",__FILE__,"File is unloaded in Timber.");
		result = FAILURE;
		return NULL;
	}

/*	int res;
	//get text node from DB
	if ((res = EvaluatorClass::GetText(in,index,dataMng,fileid)) == FAILURE)
		return NULL;

	char *tmp = ((DM_CharNode *)((ComplexListNode *)(in->getNodeByIndex(res)))->GetData())->getCharValue();
	//get actual text value
	char *txt = new char[strlen(tmp)+1];

	strcpy(txt,tmp);*/

	char *txt = EvaluatorClass::returnText(in,index,dataMng,fileid,desc);
		
	return txt;
}


char *ValueJoinIterator::getValue(WitnessTree *in, int index, char *attrName, int &result, int &tag)
{
	result = SUCCESS;
	Value *val;
	char *txt = NULL;
	DM_DataNode *n = ((ComplexListNode *)in->getNodeByIndex(index))->GetData();
	tag = -1;
	switch (n->getFlag())
	{
	case ELEMENT_NODE:
		//if it is an element node, return its tag
		/*if (n->getTag())
		{
			txt = new char[strlen(n->getTag())+1];
			strcpy(txt,n->getTag());
		}*/
		tag = n->getTag();
		break;
	case DOCUMENT_NODE:
		//if document node, return the xml file name
		if (((DM_DocumentNode *)n)->getXMLFileName())
		{
			txt = new char[strlen(((DM_DocumentNode *)n)->getXMLFileName())+1];
			strcpy(txt,((DM_DocumentNode *)n)->getXMLFileName());
		}
		break;
	case ATTRIBUTE_NODE:
		//if attribute node, return the value of attribute "attrName"
		val = ((DM_AttributeNode *)n)->getAttr(attrName);
		if (val != NULL)
		{
			if (val->getStrValue() != NULL && strlen(val->getStrValue()) != 0)
			{
				txt = new char[strlen(val->getStrValue())+1];
				strcpy(txt,val->getStrValue());
			}
		}
		break;
	case TEXT_NODE:
		//if text node, return the text value
		if (((DM_CharNode *)n)->getCharValue())
		{
			txt = new char[strlen(((DM_CharNode *)n)->getCharValue())+1];
			strcpy(txt,((DM_CharNode *)n)->getCharValue());
		}
		break;
	}
	return txt;
}


int ValueJoinIterator::joinNestedLoops()
{
	int result;
	while (leftTuple)
	{	
		//as long as we still have left inputs,
		if (rightTuple)
		{ //we are still writing to the array... i.e. we are joining with the first left input tree

			//write right input tree to the buffer
			addToArray(rightArray, rightTuple, actualSizeRight, estimatedSizeOfRight);


			//check if left and right input trees join
			while (!joinable(leftTuple,&(rightArray[actualSizeRight-1]),result))
			{
				if (result == FAILURE)
					return FAILURE;

				//if they don;t, get next right input tree.
				right->next(rightTuple);
				if (!rightTuple)
				{
					delete right;
					right = NULL;
					if (globalErrorInfo.doWeHaveAProblem())
						return FAILURE;
					if (outerJoin && !leftJoined)
					{
						writeToResult(leftTuple,NULL);
						left->next(leftTuple);
						return SUCCESS;
					}
					left->next(leftTuple);
					leftJoined = false;
					break;
				}

				//write right input tree to the buffer.
				addToArray(rightArray, rightTuple, actualSizeRight, estimatedSizeOfRight);
			}
			if (!rightTuple)
				continue;

			leftJoined = true;
			//left and right input trees joined--> write them to result and output
			writeToResult(leftTuple,&rightArray[actualSizeRight-1]);

			right->next(rightTuple);
			if (!rightTuple)
			{
				if (right)
					delete right;
				right = NULL;
				if (globalErrorInfo.doWeHaveAProblem())
						return FAILURE;
				left->next(leftTuple);
				leftJoined = false;
			}
			return SUCCESS;
		}
		else
		{
			//we read all right input, and we have in the buffer. so now, we read
			//right inputs from buffer.
			if (actualSizeRight == 0)
			{
				if (!outerJoin)
					return FAILURE;
				else
				{
					writeToResult(leftTuple,NULL);
					left->next(leftTuple);
					return SUCCESS;
				}
			}

			//check if left input tree joins with buffered right input tree.
			while (!joinable(leftTuple,&(rightArray[rightCursor]),result))
			{
				//as long as they don't join, advance right cursor.
				if (result == FAILURE)
					return FAILURE;
				rightArray[rightCursor].setDeleteBuffers(true);
				rightCursor++;
				if (rightCursor == actualSizeRight)
				{
					if (outerJoin && !leftJoined)
					{
						writeToResult(leftTuple,NULL);
						left->next(leftTuple);
						return SUCCESS;
					}
					left->next(leftTuple);
					leftJoined = false;
					break;
				}
			}
			if (rightCursor == actualSizeRight)
			{
				rightCursor = 0;
				continue;
			}

			leftJoined = true;
			//we reach this point-->join left and right-->write them to resultBuffer and 
			// output
			writeToResult(leftTuple,&rightArray[rightCursor]);
			
			rightCursor++;
			if (rightCursor == actualSizeRight)
			{
				left->next(leftTuple);
				leftJoined = false;
				rightCursor = 0;
			}
			return SUCCESS;
		}
	}
	return FAILURE;
}


int ValueJoinIterator::joinNestedLoopsN()
{
	int result;
	while (leftTuple)
	{	
		writeToResult(leftTuple,NULL);

		//as long as we still have right inputs,
		while (rightTuple)
		{ //we are still writing to the array... i.e. we are joining with the first left input tree

			//write right input tree to the buffer
			addToArray(rightArray, rightTuple, actualSizeRight, estimatedSizeOfRight);

			//check if left and right input trees join
			if (joinable(leftTuple,&(rightArray[actualSizeRight-1]),result))
				writeToResult(NULL,&(rightArray[actualSizeRight-1]));

			if (result == FAILURE)
				return FAILURE;

			right->next(rightTuple);
			if (!rightTuple)
			{
				delete right;
				right = NULL;
				if (globalErrorInfo.doWeHaveAProblem())
					return FAILURE;
				left->next(leftTuple);
				if (resultBuffer->length() > initSize)
					return SUCCESS;
				if (outerJoin)
					return SUCCESS;

				if (!leftTuple)
					return FAILURE;
				else
					writeToResult(leftTuple,NULL);
			}
		}

		//we read all right input, and we have in the buffer. so now, we read
		//right inputs from buffer.
		if (actualSizeRight == 0)
		{
			if (!outerJoin)
				return FAILURE;
			else
			{
				left->next(leftTuple);
				return SUCCESS;
			}
		}

		rightCursor = 0;
		//check if left input tree joins with buffered right input tree.
		while (rightCursor < actualSizeRight)
		{
			if (joinable(leftTuple,&(rightArray[rightCursor]),result))
				writeToResult(NULL,&(rightArray[rightCursor]));
			if (result == FAILURE)
				return FAILURE;
			rightArray[rightCursor].setDeleteBuffers(true);
			rightCursor++;
		}
		left->next(leftTuple);
		if (resultBuffer->length() > initSize)
			return SUCCESS;
		if (outerJoin)
			return SUCCESS;
	}
	return FAILURE;
}

int ValueJoinIterator::joinSortMerge()
{
	int result;
	while (leftTuple && rightTuple)
	{ //as long as we have inputs from both sides.
		if (readFromArray)
		{
			//if we have some right input trees  buffered already, we read from the buffer.
			if (rightCursor == actualSizeRight)
			{
				//if we reach end of buffer, get next left and start reading the buffer again
				left->next(leftTuple);
				leftJoined = false;
				if (!leftTuple)
					return FAILURE;
				rightCursor = 0;
			}

			// if left input tree joins with buffered right input tree, then output the joined tree
			if (joinable(leftTuple,&rightArray[rightCursor],result) == 0)
			{
				if (result == FAILURE)
					return FAILURE;
				leftJoined = true;
				this->writeToResult(leftTuple,&rightArray[rightCursor]);
				rightCursor++;
				return SUCCESS;
			}

			//if left input tree does not join with buffered right input tree, then we know that
			// it will join with none of teh buffered right input trees --> ignore buffer and 
			//start reading from source again.
			readFromArray = false;
			if (this->maxSizeRight < actualSizeRight)
				maxSizeRight = actualSizeRight;
			actualSizeRight = 0;
			rightCursor = 0;
		}

		//here , we read input not from buffer but from actual source

		//check if left input tree joins with right input tree
		int res = joinable(leftTuple,rightTuple,result);
		if (result == FAILURE)
			return FAILURE;
		if (res == 0)
		{//found a match

			
			leftJoined = true;
			//add the right input tree to the buffer because it might join with te next left input tree.
			addToArray(this->rightArray,rightTuple,this->actualSizeRight,this->estimatedSizeOfRight);

			//write the two input trees to resultBuffer and output them 
			this->writeToResult(leftTuple,rightTuple);

			right->next(rightTuple);
			if (!rightTuple)
			{
				delete right;
				right = NULL;
				if (globalErrorInfo.doWeHaveAProblem())
					return FAILURE;
				left->next(leftTuple);
				leftJoined = false;
				this->rightCursor = 0;
				readFromArray = true;
			}
			return SUCCESS;
		}
		else if (res < 0)
		{  // left is smaller than right --> advance left
			if (outerJoin && !leftJoined)
			{
				this->writeToResult(leftTuple,NULL);
				left->next(leftTuple);
				if (this->actualSizeRight > 0)
				{
					this->rightCursor = 0;
					readFromArray = true;
				}
				return SUCCESS;
			}
			else
			{
				left->next(leftTuple);
				leftJoined = false;
				if (this->actualSizeRight > 0)
				{
					this->rightCursor = 0;
					readFromArray = true;
				}
			}
		}
		else // right is smaller than left --> advance right
		{
			right->next(rightTuple);
			if (outerJoin && !leftJoined)
			{
				this->writeToResult(leftTuple,NULL);
				return SUCCESS;
			}
		}	
	}

	if (globalErrorInfo.doWeHaveAProblem())
					return FAILURE;
	if (leftTuple) 
	{
		//if we reach here, it means we ran out of right inputs
		if (actualSizeRight == 0)
		{
			if (!outerJoin)
				return FAILURE;
			else
			{
				if (!leftJoined)
				{
					this->writeToResult(leftTuple,NULL);
					left->next(leftTuple);
					return SUCCESS;
				}
			}
		}
		else
		{
			//try to join with buffered right input trees
			if (rightCursor == actualSizeRight)
			{
				if (outerJoin && !leftJoined)
				{
					this->writeToResult(leftTuple,NULL);
					left->next(leftTuple);
					rightCursor = 0;
					return SUCCESS;
				}
				left->next(leftTuple);
				leftJoined = false;
				if (!leftTuple)
					return FAILURE;
				rightCursor = 0;
			}
			if (joinable(leftTuple,&rightArray[rightCursor],result) == 0)
			{
				if (result == FAILURE)
					return FAILURE;
				leftJoined = true;
				this->writeToResult(leftTuple,&rightArray[rightCursor]);
				rightCursor++;
				return SUCCESS;
			}

			if (!outerJoin)
				return FAILURE;
			else
			{
				if (!leftJoined)
				{
					this->writeToResult(leftTuple,NULL);
					left->next(leftTuple);
					return SUCCESS;
				}
			}
		}
	}
	return FAILURE;
}

int ValueJoinIterator::joinSortMergeN()
{
	int result;
	while (leftTuple && rightTuple)
	{ //as long as we have inputs from both sides.
		
		writeToResult(leftTuple,NULL);
		if (readFromArray)
		{
			rightCursor = 0;
			// if left input tree joins with buffered right input tree, then output the joined tree
			while (joinable(leftTuple,&rightArray[rightCursor],result) == 0)
			{
				if (result == FAILURE)
					return FAILURE;
				this->writeToResult(NULL,&rightArray[rightCursor]);
				rightCursor++;
				if (rightCursor == actualSizeRight)
				{
					left->next(leftTuple);
					readFromArray = true;
					return SUCCESS;
				}
			}

			//if left input tree does not join with buffered right input tree, then we know that
			// it will join with none of teh buffered right input trees --> ignore buffer and 
			//start reading from source again.
			readFromArray = false;

			if (this->maxSizeRight < actualSizeRight)
				maxSizeRight = actualSizeRight;
			actualSizeRight = 0;
		}

		//here , we read input not from buffer but from actual source

		//check if left input tree joins with right input tree
		int res = joinable(leftTuple,rightTuple,result);
		if (result == FAILURE)
			return FAILURE;
		while (res == 0)
		{//found a match

			//add the right input tree to the buffer because it might join with te next left input tree.
			addToArray(this->rightArray,rightTuple,this->actualSizeRight,this->estimatedSizeOfRight);

			//write the two input trees to resultBuffer 
			this->writeToResult(NULL,rightTuple);

			right->next(rightTuple);
			if (!rightTuple)
			{
				delete right;
				right = NULL;
				if (globalErrorInfo.doWeHaveAProblem())
					return FAILURE;
				left->next(leftTuple);
				return SUCCESS;
			}
			res = joinable(leftTuple,rightTuple,result);
			if (result == FAILURE)
				return FAILURE;
		}
		if (res < 0)
		{  // left is smaller than right --> advance left
			left->next(leftTuple);
			if (this->actualSizeRight > 0)
				readFromArray = true;
		}
		else // right is smaller than left --> advance right
			right->next(rightTuple);
		if (resultBuffer->length() > initSize)
			return SUCCESS;
		if (outerJoin)
			return SUCCESS;
	}
	if (globalErrorInfo.doWeHaveAProblem())
		return FAILURE;
	if (leftTuple) 
	{
		//if we reach here, it means we ran out of right inputs
		if (actualSizeRight == 0)
		{
			if (!outerJoin)
				return FAILURE;
			else
			{
				writeToResult(leftTuple,NULL);
				left->next(leftTuple);
				return SUCCESS;
			}
		}
		else
		{
			writeToResult(leftTuple,NULL);
			//try to join with buffered right input trees
			rightCursor = 0;
			while (joinable(leftTuple,&rightArray[rightCursor],result) == 0)
			{
				if (result == FAILURE)
					return FAILURE;
				this->writeToResult(NULL,&rightArray[rightCursor]);
				rightCursor++;
				if (rightCursor == actualSizeRight)
				{
					left->next(leftTuple);
					return SUCCESS;
				}
			}
			if (!outerJoin)
				return FAILURE;
			else
			{
				left->next(leftTuple);
				return SUCCESS;
			}
		}
	}
	return FAILURE;
}

int ValueJoinIterator::processAtLeastOne(WitnessTree *in1, WitnessTree *in2, int &result)
{
	// for each left NRE check all right nres
	in1->startFindNodesNRE(this->leftNRE);
	int leftIndex = in1->getNextIndexNRE();
	
	if (leftIndex == -1)
	{
		globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"Evaluator",__FILE__,"Could not find node with left NRE.");
		result = FAILURE;
		return 0;
	}

	while (leftIndex != -1)
	{
		KeyType skLeft = -1;
		KeyType ekLeft = -1;
		int levelLeft = -1;
		char *leftTxt = NULL;
		int leftTag = -1;
		
		switch (this->joinByWhatLeft)
		{
		case JOINBY_ATTRIBUTE:
			leftTxt = getAttribute(in1,leftIndex,this->attrNameLeft,result);
			break;
		case JOINBY_TEXT:
			leftTxt = getText(in1,leftIndex,false,result);
			break;
		case JOINBY_STARTKEY:
			skLeft = in1->isSimple()? ((ListNode *)in1->getNodeByIndex(leftIndex))->GetStartPos():
			((ComplexListNode *)in1->getNodeByIndex(leftIndex))->GetStartPos();
			break;
		case JOINBY_ENDKEY:
			ekLeft = in1->isSimple()? ((ListNode *)in1->getNodeByIndex(leftIndex))->GetEndPos():
			((ComplexListNode *)in1->getNodeByIndex(leftIndex))->GetEndPos();
			break;
		case JOINBY_LEVEL:
			levelLeft = in1->isSimple()? ((ListNode *)in1->getNodeByIndex(leftIndex))->GetLevel():
			((ComplexListNode *)in1->getNodeByIndex(leftIndex))->GetLevel();
			break;
		case JOINBY_VALUE:
			leftTxt = getValue(in1,leftIndex,attrNameLeft,result,leftTag);
			break;
		case JOINBY_DESC_TEXT:
			leftTxt = getText(in1,leftIndex,true,result);
			break;
		}
		if (result == FAILURE)
			return 0;
		if (leftTxt == NULL && leftTag == -1 && (this->joinByWhatLeft == JOINBY_ATTRIBUTE ||
			this->joinByWhatLeft == JOINBY_TEXT || this->joinByWhatLeft == JOINBY_DESC_TEXT ||
			this->joinByWhatLeft == JOINBY_VALUE))
		{
			leftIndex = in1->getNextIndexNRE();
			continue;
		}
		
		in2->startFindNodesNRE(this->rightNRE);
		int rightIndex = in2->getNextIndexNRE();

		if (rightIndex == -1)
		{
			globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"Evaluator",__FILE__,"Could not find node with right NRE.");
			result = FAILURE;
			if (leftTxt) delete [] leftTxt;
			return 0;
		}
		while (rightIndex != -1)
		{
			if (joinByWhatRight == JOINBY_TREE || joinByWhatLeft == JOINBY_TREE ||
				joinByWhatRight == JOINBY_TREE_WITHOUT_ROOT || joinByWhatLeft == JOINBY_TREE_WITHOUT_ROOT)
			{
				if (this->joinableBySubtree(in1,in2,leftIndex,rightIndex,result) == 1)
					return 1;
				if (result == FAILURE)
					return 0;
				rightIndex = in2->getNextIndexNRE();
				continue;
			}
			KeyType skRight = -1;
			KeyType ekRight = -1;
			int levelRight = -1;
			char *rightTxt = NULL;
			int rightTag = -1;
			bool res = false;
			switch (this->joinByWhatRight)
			{
			case JOINBY_ATTRIBUTE:
			case JOINBY_TEXT:
			case JOINBY_VALUE:
			case JOINBY_DESC_TEXT:
				if (this->joinByWhatRight == JOINBY_ATTRIBUTE)
					rightTxt = getAttribute(in2,rightIndex,this->attrNameRight,result);
				else if (this->joinByWhatRight == JOINBY_TEXT)
					rightTxt = getText(in2,rightIndex,false,result);
				else if (this->joinByWhatRight == JOINBY_VALUE)
					rightTxt = getValue(in2,rightIndex,attrNameRight,result,rightTag);
				else if (this->joinByWhatRight == JOINBY_DESC_TEXT)
					rightTxt = getText(in2,rightIndex,true,result);
				else
				{
					res = false;
					break;
				}
				if (result == FAILURE)
				{
					if (leftTxt) delete [] leftTxt;
					return 0;
				}
				if (!this->sortedInput && (operation == JOINOP_EQ_NUM || operation == JOINOP_EQ_STR ||
					operation == JOINOP_NE_NUM || operation == JOINOP_NE_STR ))
				{
					if (leftTag != -1 && rightTag == -1)
					{
						char *t = dataMng->getPhysicalDataMng()->getXMLNameTable()->getNameByCode(leftTag);
						leftTxt = new char[strlen(t)+1];
						strcpy(leftTxt,t);
					}
					else if (leftTag == -1 && rightTag != -1)
					{
						char *t = dataMng->getPhysicalDataMng()->getXMLNameTable()->getNameByCode(rightTag);
						rightTxt = new char[strlen(t)+1];
						strcpy(rightTxt,t);
					}
				}
				else
				{// in the cass of non-equi join, we need to get the text to figure out whose bigger or smaller
					if (leftTag != -1)
					{
						char *t = dataMng->getPhysicalDataMng()->getXMLNameTable()->getNameByCode(leftTag);
						leftTxt = new char[strlen(t)+1];
						strcpy(leftTxt,t);
					}
					if (rightTag != -1)
					{
						char *t = dataMng->getPhysicalDataMng()->getXMLNameTable()->getNameByCode(rightTag);
						rightTxt = new char[strlen(t)+1];
						strcpy(rightTxt,t);
					}
				}

				if (rightTxt != NULL)
				{
					if (operation == JOINOP_EQ_NUM)
						res = atof(leftTxt) == atof(rightTxt);
					else if (operation == JOINOP_EQ_STR)
						res = (strcmp(leftTxt, rightTxt) == 0); 
					else if (operation == JOINOP_NE_NUM)
						res = atof(leftTxt) != atof(rightTxt); 
					else if (operation == JOINOP_NE_STR)
						res = (strcmp(leftTxt, rightTxt) != 0); 
					else if (operation == JOINOP_LT_NUM)
						res = atof(leftTxt) < atof(rightTxt); 
					else if (operation == JOINOP_LT_STR) 
						res = (strcmp(leftTxt, rightTxt) < 0); 
					else if (operation == JOINOP_LE_NUM)
						res = atof(leftTxt) <= atof(rightTxt);
					else if (operation == JOINOP_LE_STR)
						res = (strcmp(leftTxt, rightTxt) <= 0);
					else if (operation == JOINOP_GT_NUM)
						res = atof(leftTxt) > atof(rightTxt); 
					else if (operation == JOINOP_GT_STR)
						res = (strcmp(leftTxt, rightTxt) > 0); 
					else if (operation == JOINOP_GE_NUM)
						res = atof(leftTxt) >= atof(rightTxt);  
					else if (operation == JOINOP_GE_STR) 
						res = (strcmp(leftTxt, rightTxt) >= 0); 
					else if (operation == JOINOP_CONTAINS)
						res = (strstr(leftTxt,rightTxt) != NULL); 
					else if (operation == JOINOP_CONTAINED_BY)
						res = (strstr(rightTxt,leftTxt) != NULL);
					else
						res = false;
				}
				else if (rightTag != -1)
				{
					if (operation == JOINOP_EQ_NUM)
						res = leftTag == rightTag;
					else if (operation == JOINOP_EQ_STR)
						res = leftTag == rightTag; 
					else if (operation == JOINOP_NE_NUM)
						res = leftTag != rightTag; 
					else if (operation == JOINOP_NE_STR)
						res = leftTag != rightTag; 
					else 
						res = false;
				}
				else
					res = false;
				break;
			case JOINBY_STARTKEY:
				skRight = in2->isSimple()? ((ListNode *)in2->getNodeByIndex(rightIndex))->GetStartPos():
				((ComplexListNode *)in2->getNodeByIndex(rightIndex))->GetStartPos();
				if (operation == JOINOP_EQ_NUM || operation == JOINOP_EQ_STR)
					res = skLeft == skRight;
				else if (operation == JOINOP_NE_NUM || operation == JOINOP_NE_STR)
					res = skLeft != skRight;
				else if (operation == JOINOP_LT_NUM || operation == JOINOP_LT_STR)
					res = skLeft < skRight;
				else if (operation == JOINOP_LE_NUM || operation == JOINOP_LE_STR)
					res = skLeft <= skRight;
				else if (operation == JOINOP_GT_NUM || operation == JOINOP_GT_STR)
					res = skLeft > skRight;
				else if (operation == JOINOP_GE_NUM || operation == JOINOP_GE_STR)
					res = skLeft >= skRight;
				else
					res = false;
				break;
			case JOINBY_ENDKEY:
				ekRight = in2->isSimple()? ((ListNode *)in2->getNodeByIndex(rightIndex))->GetEndPos():
				((ComplexListNode *)in2->getNodeByIndex(rightIndex))->GetEndPos();
				if (operation == JOINOP_EQ_NUM || operation == JOINOP_EQ_STR)
					res = ekLeft == ekRight;
				else if (operation == JOINOP_NE_NUM || operation == JOINOP_NE_STR)
					res = ekLeft != ekRight;
				else if (operation == JOINOP_LT_NUM || operation == JOINOP_LT_STR)
					res = ekLeft < ekRight;
				else if (operation == JOINOP_LE_NUM || operation == JOINOP_LE_STR)
					res = ekLeft <= ekRight;
				else if (operation == JOINOP_GT_NUM || operation == JOINOP_GT_STR)
					res = ekLeft > ekRight;
				else if (operation == JOINOP_GE_NUM || operation == JOINOP_GE_STR)
					res = ekLeft >= ekRight;
				else
					res = false;
				break;
			case JOINBY_LEVEL:
				levelRight = in2->isSimple()? ((ListNode *)in2->getNodeByIndex(rightIndex))->GetLevel():
				((ComplexListNode *)in2->getNodeByIndex(rightIndex))->GetLevel();
				if (operation == JOINOP_EQ_NUM || operation == JOINOP_EQ_STR)
					res = levelLeft == levelRight;
				else if (operation == JOINOP_NE_NUM || operation == JOINOP_NE_STR)
					res = levelLeft != levelRight;
				else if (operation == JOINOP_LT_NUM || operation == JOINOP_LT_STR)
					res = levelLeft < levelRight;
				else if (operation == JOINOP_LE_NUM || operation == JOINOP_LE_STR)
					res = levelLeft <= levelRight;
				else if (operation == JOINOP_GT_NUM || operation == JOINOP_GT_STR)
					res = levelLeft > levelRight;
				else if (operation == JOINOP_GE_NUM || operation == JOINOP_GE_STR)
					res = levelLeft >= levelRight;
				else
					res = false;
				break;
			}
			if (rightTxt) delete [] rightTxt;
			if (res == true)
			{
				if (leftTxt) delete [] leftTxt;
				return 1;
			}
			rightIndex = in2->getNextIndexNRE();
		}

		if (leftTxt) delete [] leftTxt;
		leftIndex = in1->getNextIndexNRE();
	}
	return 0;
}

int ValueJoinIterator::joinableBySubtree(WitnessTree *in1,WitnessTree *in2, int leftIndex, int rightIndex,int &result)
{

	WitnessTree l(LIST_NODE_WITH_DATA,dataMng);
	WitnessTree r(LIST_NODE_WITH_DATA,dataMng);

	if (in1->isSimple())
		l.appendList((ListNode *)in1->getNodeByIndex(leftIndex),1);
	else
		l.appendList((ComplexListNode *)in1->getNodeByIndex(leftIndex),dataMng,1);


	FileIDType fileid = EvaluatorClass::getFileID(((ComplexListNode *)l.getNodeByIndex(0))->getFileIndex());
	if (fileid == -1)
	{
		globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"Evaluator",__FILE__,"File is unloaded in Timber.");
		result = FAILURE;
		return 0;
	}
	int index = 0;
	EvaluatorClass::GetAllDesc(&l,index,dataMng,fileid);

	if (in2->isSimple())
		r.appendList((ListNode *)in2->getNodeByIndex(rightIndex),1);
	else
		r.appendList((ComplexListNode *)in2->getNodeByIndex(rightIndex),dataMng,1);

	fileid = EvaluatorClass::getFileID(((ComplexListNode *)r.getNodeByIndex(0))->getFileIndex());
	if (fileid == -1)
	{
		globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"Evaluator",__FILE__,"File is unloaded in Timber.");
		result = FAILURE;
		return 0;
	}
	index = 0;
	EvaluatorClass::GetAllDesc(&r,index,dataMng,fileid);

	if (joinByWhatRight == JOINBY_TREE || joinByWhatLeft == JOINBY_TREE)
		return compareValueTrees(&l,&r,0);
	else
		return compareValueTrees(&l,&r,1);
}

int ValueJoinIterator::compareValueTrees(WitnessTree *in1, WitnessTree *in2, int startFrom)
{
	if (in1->length() != in2->length())
		return 0;
	for (int i=startFrom; i<in1->length(); i++)
	{
		ComplexListNode *n1 = (ComplexListNode *)in1->getNodeByIndex(i);
		ComplexListNode *n2 = (ComplexListNode *)in2->getNodeByIndex(i);

		DM_DataNode *dn1 = n1->GetData();
		DM_DataNode *dn2 = n2->GetData();

		if (dn1->getFlag() != dn2->getFlag())
			return 0;

		switch (dn1->getFlag())
		{
		case ELEMENT_NODE:
			if (dn1->getTag() != dn2->getTag())
				return 0;
			break;
		case DOCUMENT_NODE:
			if (strcmp(((DM_DocumentNode *)dn1)->getXMLFileName(),((DM_DocumentNode *)dn2)->getXMLFileName()) != 0)
				return 0;
			break;
		case ATTRIBUTE_NODE:
			{
				short attrNum1 = ((DM_AttributeNode *)dn1)->getAttributeNumber();
				short attrNum2 = ((DM_AttributeNode *)dn2)->getAttributeNumber();
				if (attrNum1 != attrNum2)
					return 0;
				for (short j=0; j<attrNum1; j++)
				{
					if (strcmp(((DM_AttributeNode *)dn1)->getAttributeNameAt(j),
						((DM_AttributeNode *)dn2)->getAttributeNameAt(j)) != 0)
						return 0;

					if (strcmp(
						((DM_AttributeNode *)dn1)->getAttr(((DM_AttributeNode *)dn1)->getAttributeNameAt(j))->getStrValue(),
						((DM_AttributeNode *)dn2)->getAttr(((DM_AttributeNode *)dn2)->getAttributeNameAt(j))->getStrValue())
						!= 0)
						return 0;
				}
			}
			break;
		case TEXT_NODE:
			if (strcmp(((DM_CharNode *)dn1)->getCharValue(),((DM_CharNode *)dn1)->getCharValue()) != 0)
				return 0;
			break;
		}
	}
	return 1;
}

int ValueJoinIterator::useIndexToMatch(WitnessTree *in1, WitnessTree *in2, int &result)
{
	result = SUCCESS;
	if (this->atLeastOne)
	{
		in1->startFindNodesNRE(this->leftNRE);
		int leftIndex = in1->getNextIndexNRE();

		if (leftIndex == -1)
		{
			globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"Evaluator",__FILE__,"Could not find node with left NRE.");
			result = FAILURE;
			return 0;
		}

		while (leftIndex != -1)
		{
			in2->startFindNodesNRE(this->rightNRE);
			int rightIndex = in2->getNextIndexNRE();

			if (rightIndex == -1)
			{
				globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"Evaluator",__FILE__,"Could not find node with right NRE.");
				result = FAILURE;
				return 0;
			}
			while (rightIndex != -1)
			{
				if (compareStartKeys(in1,in2,leftIndex,rightIndex))
					return 1;
				rightIndex = in2->getNextIndexNRE();
			}
			leftIndex = in1->getNextIndexNRE();
		}
		return 0;
	}
	else
	{
		if (this->setIndex(in1,in2) == FAILURE)
		{
			result = FAILURE;
			return 0;
		}
		return compareStartKeys(in1,in2,leftIndex,rightIndex);
	}
}

int ValueJoinIterator::compareStartKeys(WitnessTree *in1, WitnessTree *in2,int index1, int index2)
{
	KeyType leftSK = in1->isSimple()? ((ListNode *)in1->getNodeByIndex(index1))->GetStartPos():
						((ComplexListNode *)in1->getNodeByIndex(index1))->GetStartPos();
	KeyType rightSK = in2->isSimple()? ((ListNode *)in2->getNodeByIndex(index2))->GetStartPos():
						((ComplexListNode *)in2->getNodeByIndex(index2))->GetStartPos();

	bt_query_t *pred;
	pred = new bt_query_t(bt_query_t::bt_eq, new double(leftSK.toDouble()), NULL);

	char *newIndexName = new char[strlen(indexName)+1];
	strcpy(newIndexName,indexName);
	GistIndexAccess *ia = new GistIndexAccess(newIndexName,pred,DOUBLE_INDEX,(char)openFileIndex,SUPPLEMENTARY_NODES_NRE);
	WitnessTree *iaTuple;

	ia->next(iaTuple);
	while (iaTuple)
	{
		KeyType indexSK = ((ListNode *)iaTuple->getNodeByIndex(0))->GetStartPos();
		if (indexSK == rightSK)
		{
			delete ia;
			return 1;
		}
		ia->next(iaTuple);
	}

	delete ia;
	return 0;
}
