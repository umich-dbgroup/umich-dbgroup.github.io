/*
COPYRIGHT  � 2000-2004 
THE REGENTS OF THE UNIVERSITY OF MICHIGAN
ALL RIGHTS RESERVED

PERMISSION IS GRANTED TO USE, COPY, CREATE DERIVATIVE WORKS AND REDISTRIBUTE THIS SOFTWARE AND SUCH DERIVATIVE WORKS FOR 
NONCOMMERCIAL EDUCATION AND RESEARCH PURPOSES, SO LONG AS NO FEE IS CHARGED, AND SO LONG AS THE COPYRIGHT NOTICE ABOVE, 
THIS GRANT OF PERMISSION, AND THE DISCLAIMER BELOW APPEAR IN ALL COPIES MADE; AND SO LONG AS THE NAME OF THE UNIVERSITY 
OF MICHIGAN IS NOT USED IN ANY ADVERTISING OR PUBLICITY PERTAINING TO THE USE OR DISTRIBUTION OF THIS SOFTWARE WITHOUT 
SPECIFIC, WRITTEN PRIOR AUTHORIZATION.

THIS SOFTWARE IS PROVIDED AS IS, WITHOUT REPRESENTATION FROM THE UNIVERSITY OF MICHIGAN AS TO ITS FITNESS FOR ANY PURPOSE, 
AND WITHOUT WARRANTY BY THE UNIVERSITY OF MICHIGAN OF ANY KIND, EITHER EXPRESS OR IMPLIED, INCLUDING WITHOUT LIMITATION THE 
IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE. THE REGENTS OF THE UNIVERSITY OF MICHIGAN SHALL 
NOT BE LIABLE FOR ANY DAMAGES, INCLUDING SPECIAL, INDIRECT, INCIDENTAL, OR CONSEQUENTIAL DAMAGES, WITH RESPECT TO ANY CLAIM 
ARISING OUT OF OR IN CONNECTION WITH THE USE OF THE SOFTWARE, EVEN IF IT HAS BEEN OR IS HEREAFTER ADVISED OF THE POSSIBILITY 
OF SUCH DAMAGES.
*/

#ifndef __ValueSortIterator_h
#define __ValueSortIterator_h

#include "SortIterator.h"
#include "../Evaluator/EvaluatorClass.h"
#include <math.h>

/**
* An access method that performs a value sort. It uses the ANSI qsort.
* @see IteratorClass
* @see EvaluatorClass
* @see WitnessTree
* @author Shurug Al-Khalifa 
* @version 1.0
*/
class ValueSortIterator : public IteratorClass
{
public:
	/**
	Constructor.
	@param input is where this iterator gets its input trees.
	@param numExpected is the number of trees this iterator expects to get from the input iterator.
	@param sortBy is one of the following:
			SORTBY_ATTRIBUTE_NUM: the input trees are sorted by attribute value of the attr attrName of the
								elements specified in elements. if elements is NULL, then the attribute 
								value of node numElements in input tree is the sorting value.
								Compared as numbers.
			SORTBY_ATTRIBUTE_STR: the input trees are sorted by attribute value of the attr attrName of the
								elements specified in elements. if elements is NULL, then the attribute 
								value of node numElements in input tree is the sorting value.
								Compared as strings.
			SORTBY_TEXT_NUM: the input trees are sorted by text value of element names specified in
								elements array. Compared as numbers. 
			SORTBY_TEXT_STR: the input trees are sorted by text value of element names specified in
								elements array. Compared as strings. 
			SORTBY_TAGNAME: the input trees are sorted by tag name of element indexed by numElements.
			SORT_BY_START_KEY: the input trees are sorted by start key of element indexed by nre
	@param attrName is ignored if sortBy == SORTBY_TEXT_* or SORTBY_TAGNAME. If sortBy == SORTBY_ATTRIBUTE_*
			then attrName holds the name of the attribute used in the sort.
	@param order is an array of size numElements that specifies whether elements[i] is to be sorted 
			is an ACSENDING or DESCENDING order.
	@param data_mng an instance of the data manager.
	**/
	ValueSortIterator(IteratorClass *input, int numExpected, int num, int *sortBy,  
									NREType *nre, char **attrName, int *order, DataMng *dataMng, int *whereEmptyGoes);

	/**
	Destructor.
	Releases memory used by output buffer and sort array.
	**/
	~ValueSortIterator();

	/**
	Access Method
	gets the next output from this iterator.
	@param node is a pointer that well be set to the output buffer or NULL (indicating that
	there are no more results).
	**/
	void next(WitnessTree *&node);

private:
	int size;
	int i;
	IteratorClass *input;
	WitnessTree *sortArray;
	WitnessTree *resultBuffer;
	WitnessTree *inTuple;
	
	
	DataMng *dataMng;
};


#endif