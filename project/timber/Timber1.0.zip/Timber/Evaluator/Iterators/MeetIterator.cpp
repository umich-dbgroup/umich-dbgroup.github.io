/*
COPYRIGHT  � 2000-2004 
THE REGENTS OF THE UNIVERSITY OF MICHIGAN
ALL RIGHTS RESERVED

PERMISSION IS GRANTED TO USE, COPY, CREATE DERIVATIVE WORKS AND REDISTRIBUTE THIS SOFTWARE AND SUCH DERIVATIVE WORKS FOR 
NONCOMMERCIAL EDUCATION AND RESEARCH PURPOSES, SO LONG AS NO FEE IS CHARGED, AND SO LONG AS THE COPYRIGHT NOTICE ABOVE, 
THIS GRANT OF PERMISSION, AND THE DISCLAIMER BELOW APPEAR IN ALL COPIES MADE; AND SO LONG AS THE NAME OF THE UNIVERSITY 
OF MICHIGAN IS NOT USED IN ANY ADVERTISING OR PUBLICITY PERTAINING TO THE USE OR DISTRIBUTION OF THIS SOFTWARE WITHOUT 
SPECIFIC, WRITTEN PRIOR AUTHORIZATION.

THIS SOFTWARE IS PROVIDED AS IS, WITHOUT REPRESENTATION FROM THE UNIVERSITY OF MICHIGAN AS TO ITS FITNESS FOR ANY PURPOSE, 
AND WITHOUT WARRANTY BY THE UNIVERSITY OF MICHIGAN OF ANY KIND, EITHER EXPRESS OR IMPLIED, INCLUDING WITHOUT LIMITATION THE 
IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE. THE REGENTS OF THE UNIVERSITY OF MICHIGAN SHALL 
NOT BE LIABLE FOR ANY DAMAGES, INCLUDING SPECIAL, INDIRECT, INCIDENTAL, OR CONSEQUENTIAL DAMAGES, WITH RESPECT TO ANY CLAIM 
ARISING OUT OF OR IN CONNECTION WITH THE USE OF THE SOFTWARE, EVEN IF IT HAS BEEN OR IS HEREAFTER ADVISED OF THE POSSIBILITY 
OF SUCH DAMAGES.
*/


#include "MeetIterator.h"
#include "../JoinAlgorithms/StackBasedTermJoin.h"

MeetIterator::MeetIterator(char *phrase, char *indexName,  char openFileIndex,double (__cdecl *scoreFunction)(char *elementsInXML, int keywordSet)
		,int (__cdecl *ancsDepthThresholdFunction)(KeyType sk, int level, int keywordSet)
		,bool (__cdecl *ancsQualifies)(double score, int keywordSet), char *parentIndexName,int bufPoolSize, int keywordSet,NREType assignedNRE,
		DataMng *dataMng, bool simpleScore)
{
	this->phrase = phrase;
	this->dataMng = dataMng;
	this->indexName = indexName;
	this->scoreFunction = scoreFunction;
	this->ancsDepthThresholdFunction = ancsDepthThresholdFunction;
	this->ancsQualifies = ancsQualifies;
	this->assignedNRE = assignedNRE;
	this->keywordSet = keywordSet;
	
	
	this->simpleScore = simpleScore;
	this->parentIndexName = parentIndexName;
	this->openFileIndex = openFileIndex;
	if (this->parentIndexName)
		parentIndex = new HashIndexAccess(parentIndexName,DOUBLE_INDEX,assignedNRE,bufPoolSize);
	else
		parentIndex  = NULL;
	resultBuffer = new WitnessTree;

	if (!phrase)
	{
		cout<<"ERROR: in MeetIterator. phrase passed is NULL. Halting."<<endl;
		exit(1);
	}
	
	if (!indexName)
	{
		cout<<"ERROR: in MeetIterator. indexName passed is NULL. Halting."<<endl;
		exit(1);
	}

	wordNum = PhraseFinderIterator::wordCount(phrase);
	if (wordNum == 0)
	{
		cout<<"ERROR: in MeetIterator. phrase passed has 0 words. Halting."<<endl;
		exit(1);
	}
	this->indices = new GistIndexAccess *[wordNum];

	PhraseFinderIterator::extractWords(phrase, indices, NULL, indexName,openFileIndex,DEFAULT_NODES_NRE);
	if (this->simpleScore)
	{
		inputSets = new SortedSet<SBTermJoinStackNode>[wordNum];
		complexInputSets = NULL;
		xmlBuffer = new char[INITIAL_XML_BUFFER_SIZE];
		xmlBufferSize = INITIAL_XML_BUFFER_SIZE;
		readBuffer = NULL;
	}
	else
	{
		complexInputSets = new SortedSet<SBTermJoinComplexStackNode>[wordNum];
		inputSets = NULL;	
		volumeID = dataMng->getVolumeID();
		xmlBuffer = new char[INITIAL_XML_BUFFER_SIZE_COMPLEX];
		xmlBufferSize = INITIAL_XML_BUFFER_SIZE_COMPLEX;
		rc = ss_m::create_file(volumeID, fileID,ss_m::t_regular);
		if (rc) 
		{
			printf("after create file\n");
			cerr << rc << endl;
			return;				
		}
		
		rc = ss_m::create_id(volumeID,gSettings->getIntegerValue("MAX_ID_PER_FILE_STRUCTURAL_JOINS",10000),startID);
		
		if (rc) 
		{
			printf("after create id\n");
			cerr << rc << endl;
			return;				
		}
		readBuffer = new ContainerClass;
	}
	
}

MeetIterator::~MeetIterator()
{
	delete resultBuffer;
	delete [] xmlBuffer;
	delete [] indices;
	if (parentIndexName)
		delete [] parentIndexName;
	if (this->simpleScore)
		delete [] inputSets;
	else
		delete [] complexInputSets;
	if (parentIndex)
		delete parentIndex;
}

void MeetIterator::next(WitnessTree *&node)
{
	if (resultSet.getScanCursor() == 0)
	{
		getInputs();
		meet();
		if (resultSet.isEmpty())
		{
			node = NULL;
			return;
		}
		WitnessTree *outTree = resultSet.getNext();
		if (outTree)
		{
			resultBuffer->initialize();
			resultBuffer->appendList((ListNode *)outTree->getBuffer(),outTree->length());
			resultBuffer->setScore(outTree->getScore());
			node  = resultBuffer;
		}
		else
		{
			node = NULL;
			return;
		}
	}
	else if (resultSet.getScanCursor() == resultSet.getActualSize())
	{
		node = NULL;
		return;
	}
	else
	{
		WitnessTree *outTree = resultSet.getNext();
		if (outTree)
		{
			resultBuffer->initialize();
			resultBuffer->appendList((ListNode *)outTree->getBuffer(),outTree->length());
			resultBuffer->setScore(outTree->getScore());
			node  = resultBuffer;
		}
		else
		{
			node = NULL;
			return;
		}
	}
}

void MeetIterator::getInputs()
{
	for (int i=0; i<wordNum; i++)
		getOneInput(i);
}

void MeetIterator::getOneInput(int index)
{
	indices[index]->next(inTuple);
	while (inTuple)
	{
		if (simpleScore)
			inputSets[index].append((ListNode *)inTuple->findNode(0));
		else
			complexInputSets[index].append((ListNode *)inTuple->findNode(0));
		indices[index]->next(inTuple);
	}
}

int MeetIterator::getAncs(KeyType sk,char fileIndex, ComplexListNode &ancs)
{
	if (this->parentIndexName)
	{					
		parentIndex->setKey(&sk);
		WitnessTree *ancsTree;
		parentIndex->next(ancsTree);
		if (!ancsTree)
			return FAILURE;
		ancs.setListNode(((ComplexListNode *)ancsTree->getNodeByIndex(0))->GetListNode());
	}
	else
	{
		WitnessTree t(LIST_NODE_WITH_DATA,dataMng);
		ComplexListNode nd;
		nd.SetStartPos(sk);
		t.appendList(&nd,dataMng,1);
		FileIDType fileid = EvaluatorClass::getFileID(fileIndex);
		if (fileid == -1)
			return FAILURE;
		int r = EvaluatorClass::getAncs(&t,0,1,dataMng,fileid);
		if (r == FAILURE)
			return FAILURE;
		if (((ComplexListNode *)t.getNodeByIndex(r))->GetData()->getFlag() != ELEMENT_NODE)
			return FAILURE;
		ancs = *((ComplexListNode *)t.getNodeByIndex(r));
		ancs.setNRE(assignedNRE);
	}
	return SUCCESS;
}

void MeetIterator::meet()
{
	while (!(allSetsEmpty()))
	{
		int maxLevel = getMaxLevelInSets();
		for (int i=0; i<wordNum; i++)
		{
			if (simpleScore)
			{
				if (!(inputSets[i].isEmpty()) && inputSets[i].getMaxLevel() == maxLevel)
				{
					getParents(maxLevel,i);
					//inputSets[i].mergeDuplicates(startID,fileID,volumeID);
					inputSets[i].removeDuplicates();
				}
			}
			else
			{
				if (!(complexInputSets[i].isEmpty()) && complexInputSets[i].getMaxLevel() == maxLevel)
				{
					getParentsComplex(maxLevel,i);
					//complexInputSets[i].mergeDuplicates(startID,fileID,volumeID);
					complexInputSets[i].removeDuplicates();
				}
			}
		}
		intersectSets();
	}
}

void MeetIterator::intersectSets()
{
	//what i'll be doing now is scan through the sets and find all kinds of intersections.
	int count = 0;
	for (int i=0; i<wordNum; i++)
	{
		if (simpleScore)
		{
			if (!(inputSets[i].isEmpty()))
			{
				inputSets[i].startScan();
				count++;
			}
		}
		else
		{
			if (!(complexInputSets[i].isEmpty()))
			{
				complexInputSets[i].startScan();
				count++;
			}
		}
	}
	if (count <= 1)
		return;
	KeyType min = findMinCurrStartKey();
	
	while (min != DBL_MAX)
	{
		if (simpleScore)
		{
			SBTermJoinStackNode *firstMin = NULL;
			int firstMinSetIndex = 0;
			for (i=0; i<wordNum; i++)
			{
				SBTermJoinStackNode *curr = inputSets[i].getCurr();
				if (curr)
				{
					if (curr->GetActualAncs()->GetStartPos() == min)
					{
						if (curr->nodeIsAncs())
						{
							if (!firstMin)
							{
								firstMin = curr;
								firstMinSetIndex = i;
							}
							else
							{
								firstMin->mergeCounters(curr->getCounters());
								inputSets[i].remove(inputSets[i].getScanCursor());
							}
						}
						else 
							firstMinSetIndex = i;
					}
				}
			}
			inputSets[firstMinSetIndex].getNext();
		}
		else
		{
			SBTermJoinComplexStackNode *firstMin = NULL;
			int firstMinSetIndex = 0;
			for (i=0; i<wordNum; i++)
			{
				SBTermJoinComplexStackNode *curr = complexInputSets[i].getCurr();
				if (curr)
				{
					if (curr->GetActualAncs()->GetStartPos() == min)
					{
						
						if (curr->nodeIsAncs())
						{
							if (!firstMin)
							{
								firstMin = curr;
								firstMinSetIndex = i;
							}
							else
							{
								firstMin->mergeCounters(curr->getCounters());
								firstMin->mergeBuffersAndLists(curr->GetBuffer(),curr->GetListOfBuffers(),startID,fileID,volumeID);
								complexInputSets[i].remove(complexInputSets[i].getScanCursor());
							}
						}
						else
							firstMinSetIndex = i;
					}
				}
			}
			complexInputSets[firstMinSetIndex].getNext();
		}
		min = findMinCurrStartKey();
	}
}

KeyType MeetIterator::findMinCurrStartKey()
{
	KeyType min = DBL_MAX;
	for (int i=0; i<wordNum; i++)
	{
		if (simpleScore)
		{
			if (inputSets[i].getCurr())
			{
				if (inputSets[i].getCurr()->GetActualAncs()->GetStartPos() < min)
					min = inputSets[i].getCurr()->GetActualAncs()->GetStartPos();
			}
		}
		else
		{
			if (complexInputSets[i].getCurr())
			{
				if (complexInputSets[i].getCurr()->GetActualAncs()->GetStartPos() < min)
					min = complexInputSets[i].getCurr()->GetActualAncs()->GetStartPos();
			}
		}
	}
	return min;
}

void MeetIterator::getParents(int level, int index)
{
	inputSets[index].startScan();
	SBTermJoinStackNode *n = inputSets[index].getNext();
	while (n)
	{
		if (n->GetActualAncs()->GetLevel() == level)
		{
			int i = inputSets[index].getScanCursor() -1;
			if (n->nodeIsAncs())
				outputNode(index,i);
			KeyType startKey = n->GetActualAncs()->GetStartPos();
			ComplexListNode ancs;
			
			int r = getAncs(startKey,n->GetActualAncs()->getFileIndex(),ancs);
			if (r != FAILURE)
			{
				int lev = n->GetActualAncs()->GetLevel(); 
				n->SetActualAncsComplex(&ancs);
				if (!(n->nodeIsAncs()))
				{
					n->setSize(wordNum);
					n->incrementCounterAt(index);
					n->setIsAncs(true);
				}	
				if (lev == inputSets[index].getMaxLevel())
					inputSets[index].findMaxLevel();
			}
			else
				inputSets[index].remove(i);
		}
		n = inputSets[index].getNext();
	}
}

void MeetIterator::getParentsComplex(int level, int index)
{
	complexInputSets[index].startScan();
	SBTermJoinComplexStackNode *n = complexInputSets[index].getNext();
	while (n)
	{
		if (n->GetActualAncs()->GetLevel() == level)
		{
			int i = complexInputSets[index].getScanCursor() -1;
			if (n->nodeIsAncs())
				outputNode(index,i);
			KeyType startKey = n->GetActualAncs()->GetStartPos();
			ComplexListNode ancs;

			int r = getAncs(startKey,n->GetActualAncs()->getFileIndex(), ancs);
			if (r != FAILURE)
			{
				int lev = n->GetActualAncs()->GetLevel(); 
				if (!(n->nodeIsAncs()))
				{
					n->setSize(wordNum);
					addNodeToAncs(index,i);
					n->incrementCounterAt(index);
					n->setIsAncs(true);
				}
				n->SetActualAncsComplex(&ancs);
				if (lev == complexInputSets[index].getMaxLevel())
					complexInputSets[index].findMaxLevel();
			}
			else
				complexInputSets[index].remove(i);
		}
		n = complexInputSets[index].getNext();
	}
}


bool MeetIterator::allSetsEmpty()
{
	for (int i=0; i<wordNum; i++)
	{
		if (simpleScore)
		{
			if (!inputSets[i].isEmpty())
				return false;
		}
		else
		{
			if (!complexInputSets[i].isEmpty())
				return false;
		}
	}
	return true;
}

void MeetIterator::outputNode(int setIndex, int setItemIndex)
{
	// output inputSets[setIndex].getNodeAt(setItemIndex)
	if (simpleScore)
		StackBasedTermJoin::convertToXML(inputSets[setIndex].getNodeAt(setItemIndex),xmlBuffer,xmlBufferSize,wordNum,
		volumeID,fileID);
	else
		StackBasedTermJoin::convertToXMLComplex(complexInputSets[setIndex].getNodeAt(setItemIndex),xmlBuffer,xmlBufferSize,wordNum,
		volumeID,fileID);
	double score = scoreFunction(xmlBuffer,keywordSet); 
    if (ancsQualifies(score,keywordSet))
	{
		if (simpleScore)
		{
			resultBuffer->initialize();
			resultBuffer->appendList((ListNode *)inputSets[setIndex].getNodeAt(setItemIndex)->GetActualAncs(),1);
			resultBuffer->setScore(score);
		}
		else
		{
			resultBuffer->initialize();
			resultBuffer->appendList((ListNode *)complexInputSets[setIndex].getNodeAt(setItemIndex)->GetActualAncs(),1);
			resultBuffer->setScore(score);
		}
		resultSet.appendWitness(resultBuffer);
	}
}


void MeetIterator::addNodeToAncs(int setIndex, int setItemIndex)
{
	SBTermJoinComplexStackNode *n = complexInputSets[setIndex].getNodeAt(setItemIndex);
	int strSize = sizeof(ListNode)+sizeof(int)+sizeof(int);
	char str[100];
	int sz = sizeof(ListNode)+sizeof(int);
	memcpy(str,&sz,sizeof(int));
	int i = setIndex;
	memcpy(str+sizeof(int),&i,sizeof(int));
	memcpy(str+sizeof(int)+sizeof(int),n->GetActualAncs(),sizeof(ListNode));
	if (n->AddToBuffer(n->GetBuffer(),str,strSize) == FAILURE)
	{
		if (n->EmptyListOfBuffers(n->GetListOfBuffers()))
		{
			serial_t currRecID = startID;
			startID.increment(1);
			n->WriteBufferToList(n->GetBuffer(),
						n->GetListOfBuffers(),fileID,volumeID,currRecID,startID);
			startID.increment(1);
			n->GetListOfBuffers()->StartScan();
		}
		else
		{
			n->WriteBufferToList(n->GetBuffer(),n->GetListOfBuffers(),startID);
			startID.increment(1);
		}
		n->NewBuffer();
		n->AddToBuffer(n->GetBuffer(),str,strSize);
	}
}

int MeetIterator::getMaxLevelInSets()
{
	int globalMax = -1;
	for (int i=0; i<wordNum; i++)
	{
		if (simpleScore)
		{
			if (inputSets[i].getMaxLevel() > globalMax)
				globalMax = inputSets[i].getMaxLevel();
		}
		else
		{
			if (complexInputSets[i].getMaxLevel() > globalMax)
				globalMax = complexInputSets[i].getMaxLevel();
		}
	}
	return globalMax;
}