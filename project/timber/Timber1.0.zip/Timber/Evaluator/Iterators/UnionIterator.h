/*
COPYRIGHT  � 2000-2004 
THE REGENTS OF THE UNIVERSITY OF MICHIGAN
ALL RIGHTS RESERVED

PERMISSION IS GRANTED TO USE, COPY, CREATE DERIVATIVE WORKS AND REDISTRIBUTE THIS SOFTWARE AND SUCH DERIVATIVE WORKS FOR 
NONCOMMERCIAL EDUCATION AND RESEARCH PURPOSES, SO LONG AS NO FEE IS CHARGED, AND SO LONG AS THE COPYRIGHT NOTICE ABOVE, 
THIS GRANT OF PERMISSION, AND THE DISCLAIMER BELOW APPEAR IN ALL COPIES MADE; AND SO LONG AS THE NAME OF THE UNIVERSITY 
OF MICHIGAN IS NOT USED IN ANY ADVERTISING OR PUBLICITY PERTAINING TO THE USE OR DISTRIBUTION OF THIS SOFTWARE WITHOUT 
SPECIFIC, WRITTEN PRIOR AUTHORIZATION.

THIS SOFTWARE IS PROVIDED AS IS, WITHOUT REPRESENTATION FROM THE UNIVERSITY OF MICHIGAN AS TO ITS FITNESS FOR ANY PURPOSE, 
AND WITHOUT WARRANTY BY THE UNIVERSITY OF MICHIGAN OF ANY KIND, EITHER EXPRESS OR IMPLIED, INCLUDING WITHOUT LIMITATION THE 
IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE. THE REGENTS OF THE UNIVERSITY OF MICHIGAN SHALL 
NOT BE LIABLE FOR ANY DAMAGES, INCLUDING SPECIAL, INDIRECT, INCIDENTAL, OR CONSEQUENTIAL DAMAGES, WITH RESPECT TO ANY CLAIM 
ARISING OUT OF OR IN CONNECTION WITH THE USE OF THE SOFTWARE, EVEN IF IT HAS BEEN OR IS HEREAFTER ADVISED OF THE POSSIBILITY 
OF SUCH DAMAGES.
*/


#ifndef __unioniterator_h
#define __unioniterator_h

#include "../Evaluator/EvaluatorClass.h"

/**
* An access method that performs set union.
* @see DifferenceIterator
* @see IntersectionIterator
* @see IteratorClass
* @see EvaluatorClass
* @see WitnessTree
* @author Shurug Al-Khalifa 
* @version 1.0
*/
class UnionIterator : public IteratorClass
{
public:
	/**
	Constructor
	initializes the variables. 
	@param left is the left input
	@param right is the right input.
	@param dataMng an instance of the data manager.
	@param length if this is -1 then deep equality is performed. otherwise, partial 
	equality of trees is perfomed. (length is the length of the tree to be compared
	starting from root).
	**/
	UnionIterator(IteratorClass *left,IteratorClass *right, DataMng *dataMng, int length = -1);

	/**
	Destructor
	frees the output buffer.
	**/
	~UnionIterator();

	/**
	Access Method
	gets the next output from this iterator.
	@param node is a pointer that well be set to the output buffer or NULL (indicating that
	there are no more results).
	**/
	void next(WitnessTree *&node);
private:
	

	/**
	left input
	**/
	IteratorClass *left;

	/**
	right input
	**/
	IteratorClass *right;

	/**
	tree read from the left input
	**/
	WitnessTree *leftTuple;

	/**
	tree read from the right input
	**/
	WitnessTree *rightTuple;
 DataMng *dataMng;
	/**
	holds the index of the node in the tree where the equality test failed
	**/
	int index;

	/**
	length of the tree that should be compared in the partial equality version
	**/
	int length;

	/**
	buffer used to hold the output
	**/
	WitnessTree *resultBuffer;

};

#endif