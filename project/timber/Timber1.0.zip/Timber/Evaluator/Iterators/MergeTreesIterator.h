/*
COPYRIGHT  � 2000-2004 
THE REGENTS OF THE UNIVERSITY OF MICHIGAN
ALL RIGHTS RESERVED

PERMISSION IS GRANTED TO USE, COPY, CREATE DERIVATIVE WORKS AND REDISTRIBUTE THIS SOFTWARE AND SUCH DERIVATIVE WORKS FOR 
NONCOMMERCIAL EDUCATION AND RESEARCH PURPOSES, SO LONG AS NO FEE IS CHARGED, AND SO LONG AS THE COPYRIGHT NOTICE ABOVE, 
THIS GRANT OF PERMISSION, AND THE DISCLAIMER BELOW APPEAR IN ALL COPIES MADE; AND SO LONG AS THE NAME OF THE UNIVERSITY 
OF MICHIGAN IS NOT USED IN ANY ADVERTISING OR PUBLICITY PERTAINING TO THE USE OR DISTRIBUTION OF THIS SOFTWARE WITHOUT 
SPECIFIC, WRITTEN PRIOR AUTHORIZATION.

THIS SOFTWARE IS PROVIDED AS IS, WITHOUT REPRESENTATION FROM THE UNIVERSITY OF MICHIGAN AS TO ITS FITNESS FOR ANY PURPOSE, 
AND WITHOUT WARRANTY BY THE UNIVERSITY OF MICHIGAN OF ANY KIND, EITHER EXPRESS OR IMPLIED, INCLUDING WITHOUT LIMITATION THE 
IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE. THE REGENTS OF THE UNIVERSITY OF MICHIGAN SHALL 
NOT BE LIABLE FOR ANY DAMAGES, INCLUDING SPECIAL, INDIRECT, INCIDENTAL, OR CONSEQUENTIAL DAMAGES, WITH RESPECT TO ANY CLAIM 
ARISING OUT OF OR IN CONNECTION WITH THE USE OF THE SOFTWARE, EVEN IF IT HAS BEEN OR IS HEREAFTER ADVISED OF THE POSSIBILITY 
OF SUCH DAMAGES.
*/

#ifndef __MergeTreesIterator_h
#define __MergeTreesIterator_h

#include "../Common/IteratorClass.h"

/**
* An access method that merges the input trees from several sources such that the
* first tree from input 1 merges with first tree from input 2 and first tree from input
* 3 and .... it adds a dummy root.
* @see IteratorClass
* @see EvaluatorClass
* @see WitnessTree
* @author Shurug Al-Khalifa 
* @version 1.0
*/

class MergeTreesIterator : public IteratorClass
{
public:
	/**
	Constructor
	initializes the variables. 
	@param inputs is an array of input iterators.
	@param numInputs is the number of input iterators.
	@param dataMng an instance of the data manager.
	**/
	MergeTreesIterator(IteratorClass **inputs,int numInputs, DataMng *dataMng);

	/**
	Destructor
	frees the output buffer and so.
	**/
	~MergeTreesIterator();
	
	/**
	Access Method
	gets the next output tree from this iterator.
	@param node is a pointer that well be set to the output buffer or NULL (indicating that
	there are no more results).
	**/
	void next(WitnessTree *&node);
private:

	int getInputs();

	bool allNullInputs();

	void fuseTrees();

	/**
	an IteratorClass that produces input for this iterator.
	**/
	IteratorClass **inputs;
	 DataMng *dataMng;

	 int numInputs;
	/**
	The input tree read from input
	**/
	WitnessTree **inTuple;

	/**
	A buffer that holds the output tree.
	**/
	WitnessTree *resultBuffer;
	int res;
};

#endif