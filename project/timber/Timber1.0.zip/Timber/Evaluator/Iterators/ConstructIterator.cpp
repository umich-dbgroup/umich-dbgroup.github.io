/*
COPYRIGHT  � 2000-2004 
THE REGENTS OF THE UNIVERSITY OF MICHIGAN
ALL RIGHTS RESERVED

PERMISSION IS GRANTED TO USE, COPY, CREATE DERIVATIVE WORKS AND REDISTRIBUTE THIS SOFTWARE AND SUCH DERIVATIVE WORKS FOR 
NONCOMMERCIAL EDUCATION AND RESEARCH PURPOSES, SO LONG AS NO FEE IS CHARGED, AND SO LONG AS THE COPYRIGHT NOTICE ABOVE, 
THIS GRANT OF PERMISSION, AND THE DISCLAIMER BELOW APPEAR IN ALL COPIES MADE; AND SO LONG AS THE NAME OF THE UNIVERSITY 
OF MICHIGAN IS NOT USED IN ANY ADVERTISING OR PUBLICITY PERTAINING TO THE USE OR DISTRIBUTION OF THIS SOFTWARE WITHOUT 
SPECIFIC, WRITTEN PRIOR AUTHORIZATION.

THIS SOFTWARE IS PROVIDED AS IS, WITHOUT REPRESENTATION FROM THE UNIVERSITY OF MICHIGAN AS TO ITS FITNESS FOR ANY PURPOSE, 
AND WITHOUT WARRANTY BY THE UNIVERSITY OF MICHIGAN OF ANY KIND, EITHER EXPRESS OR IMPLIED, INCLUDING WITHOUT LIMITATION THE 
IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE. THE REGENTS OF THE UNIVERSITY OF MICHIGAN SHALL 
NOT BE LIABLE FOR ANY DAMAGES, INCLUDING SPECIAL, INDIRECT, INCIDENTAL, OR CONSEQUENTIAL DAMAGES, WITH RESPECT TO ANY CLAIM 
ARISING OUT OF OR IN CONNECTION WITH THE USE OF THE SOFTWARE, EVEN IF IT HAS BEEN OR IS HEREAFTER ADVISED OF THE POSSIBILITY 
OF SUCH DAMAGES.
*/

#include "ConstructIterator.h"
#include "ScanIterator.h"
//#include "ShoreFile.h"
#include "../Stack/stack.h"
#include "../Stack/SimpleStackNode.h"
ConstructIterator::ConstructIterator(IteratorClass *input, ConstructSpecification *spec, 
		DataMng *dataMng)
{
	this->input = input;
	this->spec = spec;
	
	
	this->dataMng = dataMng;
	this->res = NULL;
	if (spec)
	{
		int maxSz = 0;
		for (int i=0; i<spec->getSize(); i++)
			if (spec->getSpecByIndex(i)->getPattern())
				if (spec->getSpecByIndex(i)->getPattern()->GetSize() > maxSz)
					maxSz = spec->getSpecByIndex(i)->getPattern()->GetSize();
		if (maxSz > 1)
			res = new WitnessTree *[maxSz-1];
	}
	resultBuffer = new WitnessTree(LIST_NODE_WITH_DATA,dataMng);
	dummyNodeCounter = 0;
}

ConstructIterator::~ConstructIterator()
{
	delete resultBuffer;
	if (spec)
		delete spec;
	if (res)
		delete [] res;
	delete input;
}
	
void ConstructIterator::next(WitnessTree *&node)
{
#ifdef EVAL_TIME_OUT
	clock_t currTime = clock();
	double queryDuration = (double)(currTime - gQueryStartTime) / CLOCKS_PER_SEC;
	if (queryDuration >= gTimeOutAfter)
	{
		globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"Evaluator",__FILE__,"Query Timed Out.");
		node = NULL;
		return;
	}
#endif
	input->next(inTuple);
	if (inTuple)
	{
		
		// if we do not have specs or the spec is of size zero, then just pass the inTuple to the result
		if (!spec || spec->getSize() == 0)
		{
			resultBuffer->copyTree(inTuple);
			node = resultBuffer;
			return;
		}

		resultBuffer->initialize();
		resultBuffer->setScore(inTuple->getScore());
		//here we actually construct the output based on the specs
		//constructOutput is a recursive function that should start with spec of index 0 (pass zero)
		int res = constructOutput(0);
		int sz = spec->getSize() - 1;
		while (res != FAILURE && res < sz)
			res = constructOutput(res+1);
		
		if (res == FAILURE)
		{
			node = NULL;
			return;
		}
		node = resultBuffer;
		return;
	}
	node = NULL;
}

int ConstructIterator::constructOutput(int index)
{
	//each node in the spec represents an element\attr\content in the output
	// example: RETURN <result id="2"> $a\\author <result>
	// in the specs we would have "result" node, "id=2" node and "$a\\author" node. 
	// the type of the node is kept in type member of each spec.
	ComplexListNode n;
	n.SetLocalLevel((short)spec->getSpecByIndex(index)->getLevel());
	n.SetDummy(true);
	n.SetStartPos((KeyType)dummyNodeCounter);
	dummyNodeCounter++;
	//according to the type of the node, behave differently
	switch (spec->getSpecByIndex(index)->getType())
	{
	case CONSTRUCT_TYPE_ELEMENT:
		{ //if the node is an element node, then we have onde piece of data that we need
			// to get: element name (tag). we can get it from teo sources: either constant
			// or reference. the member source should decide which.
			
			switch (spec->getSpecByIndex(index)->getSource())
			{
			case CONSTRUCT_SRC_CONST:
				{ // if source is const. this means that the members str1 or str2 hold the tag name
					if (spec->getSpecByIndex(index)->getStr1() == NULL
						&& spec->getSpecByIndex(index)->getStr2() == NULL)
						//if both is null... there is an error
					{
						globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"Evaluator",__FILE__,"There is no constant sring passed for element name.");
						return FAILURE;
					}

					//if str1 has data, then it is the element name
					char *elemName = spec->getSpecByIndex(index)->getStr1()? spec->getSpecByIndex(index)->getStr1()
						:spec->getSpecByIndex(index)->getStr2();

					// here we are replacing spaces in the element name with underscores.
					for (int i=0; i<(int)strlen(elemName) ;i++)
						if (elemName[i] == ' ')
							elemName[i] = '_';

					// adding the < and >
					strcpy(n.GetDummyName(),"<");
					strcat(n.GetDummyName(),elemName);
					strcat(n.GetDummyName(),">");
			
					n.setNRE(spec->getSpecByIndex(index)->getAssignedNRE());
				
					//write this element node to resultBuffer.
					resultBuffer->appendList(&n,dataMng,1);
				}
				break;
			case CONSTRUCT_SRC_REFERENCE:
				{
					// if we are getting element name from some reference, then we have a pattern to evaluate
					// the pattern can be read from an index or from the input witness tree itself
					char *str;
					if (spec->getSpecByIndex(index)->getNodeSource() == CPM_NODE_SRC_INDEX)
					{
						//the pattern is read from an index
						if (spec->getSpecByIndex(index)->getPattern())
						{
							//the root of the pattern should be in the input witness tree.
							NREType rootNRE = spec->getSpecByIndex(index)->getPatternRootNRE();
							inTuple->startFindNodesNRE(rootNRE);
							void *n1 = inTuple->getNextNodeNRE();

							while (n1)
							{
								//get start-end-level info of the root.
								KeyType sk = inTuple->isSimple()? ((ListNode *)n1)->GetStartPos():((ComplexListNode *)n1)->GetStartPos();
								KeyType ek = inTuple->isSimple()? ((ListNode *)n1)->GetEndPos():((ComplexListNode *)n1)->GetEndPos();
								short lev = inTuple->isSimple()? ((ListNode *)n1)->GetLevel():((ComplexListNode *)n1)->GetLevel();

								//since we are building an element name, we should find one match only. 
								// the element name is returned in str.
								if (getFirstMatch(index,0,sk,ek,lev,str) == FAILURE)
								{
									globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"Evaluator",__FILE__,"Could not get reference string for element name.");
									return FAILURE;
								}

								// if str is NULL, there is an error
								if (str == NULL)
								{
									globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"Evaluator",__FILE__,"Could not get reference string for element name.");
									return FAILURE;
								}

								// replacing spaces with underscores
								for (int i=0; i<(int)strlen(str) ;i++)
									if (str[i] == ' ')
										str[i] = '_';

								//adding the < and >
								strcpy(n.GetDummyName(),"<");
								strcat(n.GetDummyName(),str);
								strcat(n.GetDummyName(),">");
								delete [] str;
								n.setNRE(spec->getSpecByIndex(index)->getAssignedNRE());

								//finally, appending this element to the result buffer.
								resultBuffer->appendList(&n,dataMng,1);
								n1 = inTuple->getNextNodeNRE();
							}
						}
						else
						{//$b case. where we don't really have a pattern. it is just $b. 
							//again the $b should be in the input witness tree.
							NREType rootNRE = spec->getSpecByIndex(index)->getPatternRootNRE();
							inTuple->startFindNodesNRE(rootNRE);
							int ind = inTuple->getNextIndexNRE();
							void *n1;
							if (ind !=FAILURE)
								n1 = inTuple->getNodeByIndex(ind);
							else
								n1 = NULL;

							while (n1)
							{
								// add $b node to resultBuffer.
								
								if (inTuple->isSimple())
								{
									((ListNode *)n1)->setNRE(spec->getSpecByIndex(index)->getAssignedNRE());
									resultBuffer->appendList((ListNode *)n1,1);
								}
								else
								{
									((ComplexListNode *)n1)->setNRE(spec->getSpecByIndex(index)->getAssignedNRE());
									resultBuffer->appendList((ComplexListNode *)n1,dataMng,1);
								}
								((ComplexListNode *)resultBuffer->getNodeByIndex(resultBuffer->length()-1))->SetLocalLevel((short)spec->getSpecByIndex(index)->getLevel());

								// if it is $b/@attr for example, then we need to get the attr. get actual data does 
								//that.
								if (getActualData(index,-1,(short)spec->getSpecByIndex(index)->getLevel(),resultBuffer,inTuple,ind,true) == FAILURE)
									return FAILURE;

								//getting a meaningful string out of the $b data
								setStr(str,(ComplexListNode *)resultBuffer->getNodeByIndex(resultBuffer->length()-1));

								if (str == NULL)
								{
									globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"Evaluator",__FILE__,"Could not get string for element name.");
									return FAILURE;
								}
								//replacing spaces with underscores.
								for (int i=0; i<(int)strlen(str) ;i++)
									if (str[i] == ' ')
										str[i] = '_';
								
								strcpy(n.GetDummyName(),"<");
								strcat(n.GetDummyName(),str);
								strcat(n.GetDummyName(),">");
								n.setNRE(spec->getSpecByIndex(index)->getAssignedNRE());
								delete [] str;
								//remove $b
								resultBuffer->deleteNode(resultBuffer->length()-1);

								//appending the elementname to resultBuffer 
								resultBuffer->appendList(&n,dataMng,1);
								ind = inTuple->getNextIndexNRE();
								if (ind !=FAILURE)
									n1 = inTuple->getNodeByIndex(ind);
								else
									n1 = NULL;
							}
						}
					}
					else
					{ 
						//in case the source of the pattern is the input witness tree.
						if (scanWitnessTree(index,inTuple) == FAILURE)
							return FAILURE;

						//set str to be the element name we got from scanning the witness tree
						setStr(str,(ComplexListNode *)resultBuffer->getNodeByIndex(resultBuffer->length()-1));


						if (str == NULL)
						{
							globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"Evaluator",__FILE__,"Could not get string for element name.");
							return FAILURE;
						}

						//replace spaces with underscores.
						for (int i=0; i<(int)strlen(str) ;i++)
							if (str[i] == ' ')
								str[i] = '_';

						//add the < and >
						strcpy(n.GetDummyName(),"<");
						strcat(n.GetDummyName(),str);
						strcat(n.GetDummyName(),">");
						n.setNRE(spec->getSpecByIndex(index)->getAssignedNRE());
						delete [] str;
						resultBuffer->deleteNode(resultBuffer->length()-1);

						//append the node with the element name.
						resultBuffer->appendList(&n,dataMng,1);
					}
				}
				break;
			}
		}
		break;
	case CONSTRUCT_TYPE_ATTRIBUTE:
	case CONSTRUCT_TYPE_OPTIONAL_ATTR:
		{
			//if the node is an attr node, then we have two pieces of data that we need
			// to get: attr name and attr value. we can get the attr value from two sources: either constant
			// or reference. the member source should decide which. attr name is always const.
			
			switch (spec->getSpecByIndex(index)->getSource())
			{
			case CONSTRUCT_SRC_CONST:
				{ //in case the attr name and value are constants, they are in str1 and str2
					//if either is NULL we have an error
					if (spec->getSpecByIndex(index)->getStr1() == NULL)
					{
						globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"Evaluator",__FILE__,"Attribute name string is NULL.");
						return FAILURE;
					}
					char *attrName = spec->getSpecByIndex(index)->getStr1();
					for (int i=0; i<(int)strlen(attrName) ;i++)
						if (attrName[i] == ' ')
							attrName[i] = '_';

					//adding the @ and the "s.
					strcpy(n.GetDummyName(),"@");
					strcat(n.GetDummyName(),attrName);
					strcat(n.GetDummyName(),"=\"");
					if (spec->getSpecByIndex(index)->getStr2() != NULL)
						strcat(n.GetDummyName(),spec->getSpecByIndex(index)->getStr2());
					strcat(n.GetDummyName(),"\"");
					n.setNRE(spec->getSpecByIndex(index)->getAssignedNRE());

					//finally adding the node to the resultBuffer.
					if (spec->getSpecByIndex(index)->getType() == CONSTRUCT_TYPE_OPTIONAL_ATTR && 
						spec->getSpecByIndex(index)->getStr2() == NULL)
					{
					}
					else
						resultBuffer->appendList(&n,dataMng,1);
				}
				break;
			case CONSTRUCT_SRC_REFERENCE:
				{ // if the source of attr value is reference. the pattern should be read from index or 
					// input witness tree.
					char *str;
					if (spec->getSpecByIndex(index)->getNodeSource() == CPM_NODE_SRC_INDEX)
					{ //if the pattern is to be read from index
						if (spec->getSpecByIndex(index)->getPattern())
						{
							//the root of the pattern is in the input witness tree.
							NREType rootNRE = spec->getSpecByIndex(index)->getPatternRootNRE();
							inTuple->startFindNodesNRE(rootNRE);
							void *n1 = inTuple->getNextNodeNRE();

							if (n1 == NULL && spec->getSpecByIndex(index)->getType() != CONSTRUCT_TYPE_OPTIONAL_ATTR)
							{
								char *attrName = spec->getSpecByIndex(index)->getStr1();
								for (int i=0; i<(int)strlen(attrName) ;i++)
									if (attrName[i] == ' ')
										attrName[i] = '_';

								//adding the @ and the "s.
								strcpy(n.GetDummyName(),"@");
								strcat(n.GetDummyName(),attrName);
								strcat(n.GetDummyName(),"=\"\"");
								
								n.setNRE(spec->getSpecByIndex(index)->getAssignedNRE());

								//finally , add the attr node to the resultBuffer
								resultBuffer->appendList(&n,dataMng,1);
							}
							while (n1)
							{
								//get start-end-level info of the root.
								KeyType sk = inTuple->isSimple()? ((ListNode *)n1)->GetStartPos():((ComplexListNode *)n1)->GetStartPos();
								KeyType ek = inTuple->isSimple()? ((ListNode *)n1)->GetEndPos():((ComplexListNode *)n1)->GetEndPos();
								short lev = inTuple->isSimple()? ((ListNode *)n1)->GetLevel():((ComplexListNode *)n1)->GetLevel();

								//get the first match for the pattern. and put the value of the attr in str.
								if (getFirstMatch(index,0,sk,ek,lev,str) == FAILURE)
									str = NULL;

								// add the @ and the "s
								char *attrName = spec->getSpecByIndex(index)->getStr1();
								for (int i=0; i<(int)strlen(attrName) ;i++)
									if (attrName[i] == ' ')
										attrName[i] = '_';

								//adding the @ and the "s.
								strcpy(n.GetDummyName(),"@");
								strcat(n.GetDummyName(),attrName);
								strcat(n.GetDummyName(),"=\"");
								if (str)
									strcat(n.GetDummyName(),str);
								strcat(n.GetDummyName(),"\"");
								n.setNRE(spec->getSpecByIndex(index)->getAssignedNRE());

								//finally , add the attr node to the resultBuffer
								if (spec->getSpecByIndex(index)->getType() == CONSTRUCT_TYPE_OPTIONAL_ATTR && 
									str == NULL)
								{
								}
								else
									resultBuffer->appendList(&n,dataMng,1);
								if (str) delete [] str;
								n1 = inTuple->getNextNodeNRE();
							}
						}
						else
						{//$b case
							NREType rootNRE = spec->getSpecByIndex(index)->getPatternRootNRE();
							inTuple->startFindNodesNRE(rootNRE);
							int ind = inTuple->getNextIndexNRE();
							void *n1 = NULL;
							if (ind != FAILURE)
								n1 = inTuple->getNodeByIndex(ind);
							else if (spec->getSpecByIndex(index)->getType() != CONSTRUCT_TYPE_OPTIONAL_ATTR)
							{
								char *attrName = spec->getSpecByIndex(index)->getStr1();
								for (int i=0; i<(int)strlen(attrName) ;i++)
									if (attrName[i] == ' ')
										attrName[i] = '_';

								//adding the @ and the "s.
								strcpy(n.GetDummyName(),"@");
								strcat(n.GetDummyName(),attrName);
								strcat(n.GetDummyName(),"=\"\"");

								n.setNRE(spec->getSpecByIndex(index)->getAssignedNRE());

								//finally add the attr node to resultBuffer.
								resultBuffer->appendList(&n,dataMng,1);
								n1 = NULL;
							}
							while (n1)
							{
								// add the root to resultBuffer
								if (inTuple->isSimple())
								{
									((ListNode *)n1)->setNRE(spec->getSpecByIndex(index)->getAssignedNRE());
									resultBuffer->appendList((ListNode *)n1,1);
								}
								else
								{
									((ComplexListNode *)n1)->setNRE(spec->getSpecByIndex(index)->getAssignedNRE());
									resultBuffer->appendList((ComplexListNode *)n1,dataMng,1);
								}
								((ComplexListNode *)resultBuffer->getNodeByIndex(resultBuffer->length()-1))->SetLocalLevel((short)spec->getSpecByIndex(index)->getLevel());

								// get the actual data the will be the attr value.
								if (getActualData(index,-1,(short)spec->getSpecByIndex(index)->getLevel(),resultBuffer,inTuple,ind,true) == FAILURE)
									return FAILURE;
			
								//put in str the attr value.
								setStr(str,(ComplexListNode *)resultBuffer->getNodeByIndex(resultBuffer->length()-1));

								char *attrName = spec->getSpecByIndex(index)->getStr1();
								for (int i=0; i<(int)strlen(attrName) ;i++)
									if (attrName[i] == ' ')
										attrName[i] = '_';

								//adding the @ and the "s.
								strcpy(n.GetDummyName(),"@");
								strcat(n.GetDummyName(),attrName);
								strcat(n.GetDummyName(),"=\"");
								if (str)
									strcat(n.GetDummyName(),str);
								strcat(n.GetDummyName(),"\"");

								n.setNRE(spec->getSpecByIndex(index)->getAssignedNRE());
								resultBuffer->deleteNode(resultBuffer->length()-1);

								//finally add the attr node to resultBuffer.
								if (spec->getSpecByIndex(index)->getType() == CONSTRUCT_TYPE_OPTIONAL_ATTR &&
														str == NULL)
								{
								}
								else
									resultBuffer->appendList(&n,dataMng,1);
								if (str) delete [] str;
								ind = inTuple->getNextIndexNRE();
								if (ind !=FAILURE)
									n1 = inTuple->getNodeByIndex(ind);
								else
									n1 = NULL;
							}
						}
					}
					else
					{
						// if pattern tree is to be read from the input witness tree
						// scan the witness tree for the first match.
						if (scanWitnessTree(index,inTuple) == FAILURE)
							str = NULL;
						else
						//set str to be the attr value scanned from the witness tree 
							setStr(str,(ComplexListNode *)resultBuffer->getNodeByIndex(resultBuffer->length()-1));

						//add the @ and the "s.
						char *attrName = spec->getSpecByIndex(index)->getStr1();
						for (int i=0; i<(int)strlen(attrName) ;i++)
							if (attrName[i] == ' ')
								attrName[i] = '_';

						//adding the @ and the "s.
						strcpy(n.GetDummyName(),"@");
						strcat(n.GetDummyName(),attrName);
						strcat(n.GetDummyName(),"=\"");
						if (str)
							strcat(n.GetDummyName(),str);
						strcat(n.GetDummyName(),"\"");

							n.setNRE(spec->getSpecByIndex(index)->getAssignedNRE());
						resultBuffer->deleteNode(resultBuffer->length()-1);


						//finally, add this attr node to resultBuffer.
						if (spec->getSpecByIndex(index)->getType() == CONSTRUCT_TYPE_OPTIONAL_ATTR &&
														str == NULL)
						{
						}
						else
							resultBuffer->appendList(&n,dataMng,1);
						if (str) delete [] str;
					}
				}
				break;
			}	
			return index;
		}
		break;
	case CONSTRUCT_TYPE_CONTENT:
		{
			//if the node is a content node (text node), then we have one piece of data that we need
			// to get: the text content. we can get it from two sources: either constant
			// or reference. the member source should decide which. 
			switch (spec->getSpecByIndex(index)->getSource())
			{
			case CONSTRUCT_SRC_CONST:
				{ //if source is constant, then we expect str1 or str2 in the spec to be the value

					//if both are null, there is an error.
					if (spec->getSpecByIndex(index)->getStr1() == NULL
						&& spec->getSpecByIndex(index)->getStr2() == NULL)
					{
						globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"Evaluator",__FILE__,"Constant string for content is NULL.");
						return FAILURE;
					}

					//get the content
					char *dummyContent = spec->getSpecByIndex(index)->getStr1()? spec->getSpecByIndex(index)->getStr1()
						:spec->getSpecByIndex(index)->getStr2();
					n.SetDummyName(dummyContent);
					n.setNRE(spec->getSpecByIndex(index)->getAssignedNRE());

					//append the node to the resultBuffer
					resultBuffer->appendList(&n,dataMng,1);
				}
				break;
			case CONSTRUCT_SRC_REFERENCE:
				{ // if source is ref, then we expect to have a pattern. the pattern can be read from the index
					//or witness tree.
					if (spec->getSpecByIndex(index)->getNodeSource() == CPM_NODE_SRC_INDEX)
					{
						// if it is read from index
						if (spec->getSpecByIndex(index)->getPattern())
						{
							// the root of the pattern is a node in the input witness tree
							NREType rootNRE = spec->getSpecByIndex(index)->getPatternRootNRE();
							inTuple->startFindNodesNRE(rootNRE);
							void *n = inTuple->getNextNodeNRE();
							while (n)
							{
								//get start-end-level info of the root
								KeyType sk = inTuple->isSimple()? ((ListNode *)n)->GetStartPos():((ComplexListNode *)n)->GetStartPos();
								KeyType ek = inTuple->isSimple()? ((ListNode *)n)->GetEndPos():((ComplexListNode *)n)->GetEndPos();
								short lev = inTuple->isSimple()? ((ListNode *)n)->GetLevel():((ComplexListNode *)n)->GetLevel();

								// get all the matches of the nodes in the pattern tree from the index.
								if (getMatches(index,0,sk,ek,lev,(short)spec->getSpecByIndex(index)->getLevel()) == FAILURE)
									return FAILURE;
								n = inTuple->getNextNodeNRE();
							}
						}
						else
						{//$b case
							NREType rootNRE = spec->getSpecByIndex(index)->getPatternRootNRE();
							inTuple->startFindNodesNRE(rootNRE);
							int ind = inTuple->getNextIndexNRE();
							void *n;
							if (ind !=FAILURE)
								n = inTuple->getNodeByIndex(ind);
							else
								n = NULL;
							while (n)
							{
								//adding the root of the pattern to the resultBuffer
								if (inTuple->isSimple())
								{
									((ListNode *)n)->setNRE(spec->getSpecByIndex(index)->getAssignedNRE());
									resultBuffer->appendList((ListNode *)n,1);
								}
								else
								{
									((ComplexListNode *)n)->setNRE(spec->getSpecByIndex(index)->getAssignedNRE());
									resultBuffer->appendList((ComplexListNode *)n,dataMng,1);
								}

								((ComplexListNode *)resultBuffer->getNodeByIndex(resultBuffer->length()-1))->SetLocalLevel((short)spec->getSpecByIndex(index)->getLevel());

								//getting the actual data that is needed. it might be attr or text or whatever
								if (getActualData(index,-1,(short)spec->getSpecByIndex(index)->getLevel(),resultBuffer,inTuple,ind) == FAILURE)
									return FAILURE;
								ind = inTuple->getNextIndexNRE();
								if (ind !=FAILURE)
									n = inTuple->getNodeByIndex(ind);
								else
									n = NULL;
							}
						}
					}
					else
					{
						//if the pattern is read from the witness tree
						if (scanWitnessTree(index,inTuple, false) == FAILURE)
							return FAILURE;
					}
				}
				break;
			}
			return index;
		}
		break;
	}

	//getting the child spec of the current spec
	int child = spec->getChildIndex(index);
	while (child != FAILURE)
	{
		//construct the output for the child
		int res = constructOutput(child);
		if (res == FAILURE)
			return FAILURE;
		
		index = res;

		//get next sibling
		child = spec->getSiblingIndex(child);
	}
	return index;
}


int ConstructIterator::getMatches(int specIndex, int patternIndex, KeyType sk, KeyType ek, short lev, short localLev)
{	

	//this method gets all the matches for a specific pattern node. sk,ek and lev are the info of the node that
	// matched the pattern node the is a parent of this node.
	if (patternIndex != 0)
	{

		//the first step is to set the index reads if they are not already set
		if (spec->getSpecByIndex(specIndex)->getPattern()->GetEntryByIndex(patternIndex)->GetIterator() == NULL)
		{
			if (setSourceOfData(specIndex,patternIndex) == FAILURE)
				return FAILURE;
		}

		int child = spec->getSpecByIndex(specIndex)->getPattern()->getChildIndex(patternIndex);

		//the realtionship between this pattern node and its parent.
		bool parentChild = (spec->getSpecByIndex(specIndex)->getRelation()[patternIndex] == PARENT_CHILD);
		bool passes = true;

		//keep reading from the index until no more entries in the index or a match is found.
		while (res[patternIndex-1])
		{
			//start-end-lev of this current node read from the index.
			KeyType startKey = (res[patternIndex-1]->isSimple()? ((ListNode *)res[patternIndex-1]->findNode(0))->GetStartPos() : ((ComplexListNode *)res[patternIndex-1]->findNode(0))->GetStartPos());
			KeyType endKey = (res[patternIndex-1]->isSimple()? ((ListNode *)res[patternIndex-1]->findNode(0))->GetEndPos() : ((ComplexListNode *)res[patternIndex-1]->findNode(0))->GetEndPos());
			short level = (res[patternIndex-1]->isSimple()? ((ListNode *)res[patternIndex-1]->findNode(0))->GetLevel() : ((ComplexListNode *)res[patternIndex-1]->findNode(0))->GetLevel());

			//if it is a desc of the node that comes before it in the pattern then check the relationship
			if (sk < startKey && ek > endKey)
			{
				if (parentChild)
				{ // if the relationship is parent-child --> check level
					if (level == (lev+1))
						passes = true;
					else
						passes = false;
				}	
				if (passes)
				{ // if the current node is a match, then we need to add to the resultBuffer if
					// it is the last node in the pattern or check the next node in the pattern.
					if (child == -1)
					{		
						//this means the node is the last in the pattern (leaf)
						((ListNode *)res[patternIndex-1]->findNode(0))->setNRE(spec->getSpecByIndex(specIndex)->getAssignedNRE());
						resultBuffer->appendList((ListNode *)res[patternIndex-1]->findNode(0),1);
						((ComplexListNode *)resultBuffer->getNodeByIndex(resultBuffer->length()-1))->SetLocalLevel(localLev);
						if (getActualData(specIndex,patternIndex,localLev,resultBuffer,NULL,-1) == FAILURE)
							return FAILURE;
					}
					else
					{
						//continue evaluating the pattern
						int child2 = spec->getSpecByIndex(specIndex)->getPattern()->getChildIndex(patternIndex);
						while (child2 != -1)
						{
							if (getMatches(specIndex,child2,startKey,endKey,level,localLev) == FAILURE)
								return FAILURE;
							child2 = spec->getSpecByIndex(specIndex)->getPattern()->getSiblingIndex(child2);
						}	
					}
				}
			}
			else if (ek < startKey)
				//this means that we need to move on and get a new sk, ek and lev
				break;

			//get next entry from the index
			spec->getSpecByIndex(specIndex)->getPattern()->GetEntryByIndex(patternIndex)->GetIterator()->next(res[patternIndex-1]);
		}
	}
	else
	{
		//if we are dealing with the root of the pattern
		if (spec->getSpecByIndex(specIndex)->getPattern() == NULL)
		{
			globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"Evaluator",__FILE__,"Pattern is NULL when trying to get matches for content.");
			return FAILURE;
		}

		//get the first child of the root.
		int child = spec->getSpecByIndex(specIndex)->getPattern()->getChildIndex(patternIndex);
		if (child == -1)
		{
			//this is a special case when you have $b for example only
			NREType rootNRE = spec->getSpecByIndex(specIndex)->getPatternRootNRE();
			inTuple->startFindNodesNRE(rootNRE);
			int ind = inTuple->getNextIndexNRE();
			void *n;
			if (ind !=FAILURE)
				n = inTuple->getNodeByIndex(ind);
			else
				n = NULL;
			while (n)
			{
				if (inTuple->isSimple())
				{
					((ListNode *)n)->setNRE(spec->getSpecByIndex(specIndex)->getAssignedNRE());
					resultBuffer->appendList((ListNode *)n,1);
				}
				else
				{
					((ComplexListNode *)n)->setNRE(spec->getSpecByIndex(specIndex)->getAssignedNRE());
					resultBuffer->appendList((ComplexListNode *)n,dataMng,1);
				}
				((ComplexListNode *)resultBuffer->getNodeByIndex(resultBuffer->length()-1))->SetLocalLevel(localLev);
				if (getActualData(specIndex,patternIndex,localLev,resultBuffer,inTuple,ind) == FAILURE)
					return FAILURE;
				ind = inTuple->getNextIndexNRE();
				if (ind !=FAILURE)
					n = inTuple->getNodeByIndex(ind);
				else
					n = NULL;
			}
		}
		while (child != -1)
		{
			//get matches for the child node in the pattern
			if (getMatches(specIndex, child, sk, ek, lev,localLev) == FAILURE)
				return FAILURE;

			//get sibling of the child
			child = spec->getSpecByIndex(specIndex)->getPattern()->getSiblingIndex(child);
		}

		//initialize the index reads for the next root. --> we cannot assume that input witness trees are sorted.
		for (int i=0; i<spec->getSpecByIndex(specIndex)->getPattern()->GetSize(); i++)
			spec->getSpecByIndex(specIndex)->getPattern()->GetEntryByIndex(i)->SetIterator(NULL);
	}
	return SUCCESS;
}

int ConstructIterator::getFirstMatch(int specIndex, int patternIndex, KeyType sk, KeyType ek, short lev,char *&str)
{
	//this method gets the first match of a node in a pattern and returns it in str. 
	//sk,ek and lev are the info of the node that
	// matched the pattern node the is a parent of this node.
	if (patternIndex != 0)
	{
		// setting the index reads if they are not already set
		if (spec->getSpecByIndex(specIndex)->getPattern()->GetEntryByIndex(patternIndex)->GetIterator() == NULL)
		{
			if (setSourceOfData(specIndex,patternIndex) == FAILURE)
				return FAILURE;
		}

		// getting the child of this pattern node
		int child = spec->getSpecByIndex(specIndex)->getPattern()->getChildIndex(patternIndex);

		//the relationship between this node and the preceding node in the pattern
		bool parentChild = (spec->getSpecByIndex(specIndex)->getRelation()[patternIndex] == PARENT_CHILD);
		bool passes = true;

		//as long as the index still prduces antries or we found a match
		while (res[patternIndex-1])
		{
			//start-end-lev of the current node read from the index
			KeyType startKey = (res[patternIndex-1]->isSimple()? ((ListNode *)res[patternIndex-1]->findNode(0))->GetStartPos() : ((ComplexListNode *)res[patternIndex-1]->findNode(0))->GetStartPos());
			KeyType endKey = (res[patternIndex-1]->isSimple()? ((ListNode *)res[patternIndex-1]->findNode(0))->GetEndPos() : ((ComplexListNode *)res[patternIndex-1]->findNode(0))->GetEndPos());
			short level = (res[patternIndex-1]->isSimple()? ((ListNode *)res[patternIndex-1]->findNode(0))->GetLevel() : ((ComplexListNode *)res[patternIndex-1]->findNode(0))->GetLevel());

			// if the node read from the index isa desc of the node read for the previous node the pattern
			if (sk < startKey && ek > endKey)
			{
				if (parentChild)
				{ //if relationship is parent-child, check level
					if (level == (lev+1))
						passes = true;
					else
						passes = false;
				}	
				if (passes)
				{ // if the node is a match for the previous nod ein the pattern tree
					if (child == -1)
					{	// if this pattern node is the leaf of the pattern
						if (spec->getSpecByIndex(specIndex)->getGetWhat()[patternIndex] == CPM_GET_SUBTREE ||
							spec->getSpecByIndex(specIndex)->getGetWhat()[patternIndex] == CPM_GET_ITSELF)
						{ // if we are getting subtree or node itself and since we are finding the first
							// match only --> subtree = itself --> write the node only to the resultBuffer
							ComplexListNode n;
							n.SetStartPos(((ListNode *)res[patternIndex-1]->findNode(0))->GetStartPos());
							n.SetEndPos(((ListNode *)res[patternIndex-1]->findNode(0))->GetEndPos());
							n.SetLevel(((ListNode *)res[patternIndex-1]->findNode(0))->GetLevel());
						
						//	FileIDType fileid = EvaluatorClass::getFileID((int)((ListNode *)res[patternIndex-1]->findNode(0))->getFileIndex());
						//	if (fileid == -1)
						//		return FAILURE;
					//		EvaluatorClass::GetData(&n,dataMng,fileid);
							if (n.GetData())
								//setting str to be the string associated with this pattern node
								setStr(str,&n);
							else
								str = NULL;
						}
						else
						{ // if we are getting text or attr
							WitnessTree t(LIST_NODE_WITH_DATA,dataMng);
							((ListNode *)res[patternIndex-1]->findNode(0))->setNRE(spec->getSpecByIndex(specIndex)->getAssignedNRE());
							t.appendList((ListNode *)res[patternIndex-1]->findNode(0),1);

							//get the actual data node needed (text node or attr node) from DB
							if (getActualData(specIndex,patternIndex,lev,&t,NULL,-1) == FAILURE)
								return FAILURE;
							if (t.length() > 0)
								// setting the str to be the string associated with the node
								//that we just gotten from DB.
								setStr(str,(ComplexListNode *)t.getNodeByIndex(0));
							else
								str = NULL;
						}
						return SUCCESS;
					}
					else
					{
						//if node is not a leaf, then continue getting matches
						int child2 = spec->getSpecByIndex(specIndex)->getPattern()->getChildIndex(patternIndex);
						while (child2 != -1)
						{
							getFirstMatch(specIndex,child2,startKey,endKey,level,str);
							child2 = spec->getSpecByIndex(specIndex)->getPattern()->getSiblingIndex(child2);
						}	
					}

				}
			}
			else if (ek < startKey)
				// get a new sk-ek-lev because the current one does not have any more matches.
				break;

			//read next entry from index
			spec->getSpecByIndex(specIndex)->getPattern()->GetEntryByIndex(patternIndex)->GetIterator()->next(res[patternIndex-1]);
		}
	}
	else
	{
		//dealing with the root of the pattern
		if (spec->getSpecByIndex(specIndex)->getPattern() == NULL)
		{
			globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"Evaluator",__FILE__,"Pattern is NULL when trying to get first match for element name oe attribue value.");
			return FAILURE;
		}

		//get the child of the root
		int child = spec->getSpecByIndex(specIndex)->getPattern()->getChildIndex(patternIndex);
		if (child == -1)
		{
			//this is a special case. we only have $b
			NREType rootNRE = spec->getSpecByIndex(specIndex)->getPatternRootNRE();
			inTuple->startFindNodesNRE(rootNRE);
			int ind = inTuple->getNextIndexNRE();
			void *n1;
			if (ind !=FAILURE)
				n1 = inTuple->getNodeByIndex(ind);
			else
				n1 = NULL;
			while (n1)
			{
				//add the root to resultBuffer
				if (inTuple->isSimple())
				{
					((ListNode *)n1)->setNRE(spec->getSpecByIndex(specIndex)->getAssignedNRE());
					resultBuffer->appendList((ListNode *)n1,1);
				}
				else
				{
					((ComplexListNode *)n1)->setNRE(spec->getSpecByIndex(specIndex)->getAssignedNRE());
					resultBuffer->appendList((ComplexListNode *)n1,dataMng,1);
				}

				//get from DB the actual data needed (attr,text, itself or subtree)
				if (getActualData(specIndex,patternIndex,lev,resultBuffer,inTuple,ind) == FAILURE)
					return FAILURE;

				if (spec->getSpecByIndex(specIndex)->getGetWhat()[patternIndex] == CPM_GET_SUBTREE ||
					spec->getSpecByIndex(specIndex)->getGetWhat()[patternIndex] == CPM_GET_ITSELF)
				{
					// if we are getting subtree or node itself and since we are finding the first
					// match only --> subtree = itself --> write the node only to the resultBuffer
					ComplexListNode n;
					if (inTuple->isSimple())
						n.setListNode((ListNode *)n1);
					else
						n = *((ComplexListNode *)n1);

					if (n.GetData())
						//set str to be string associated with the data
						setStr(str,&n);
					else
						str = NULL;
				}
				else
				{
					//if we are getting the attr or the text of the root
					WitnessTree t(LIST_NODE_WITH_DATA,dataMng);

					// add the root to resultBuffer
					if (inTuple->isSimple())
					{
						((ListNode *)n1)->setNRE(spec->getSpecByIndex(specIndex)->getAssignedNRE());
						t.appendList(((ListNode *)n1),1);
					}
					else
					{
						((ComplexListNode *)n1)->setNRE(spec->getSpecByIndex(specIndex)->getAssignedNRE());
						t.appendList(((ComplexListNode *)n1),dataMng,1);
					}

					//get the actual data node from DB.
					if (getActualData(specIndex,patternIndex,lev,&t,NULL,-1) == FAILURE)
						return FAILURE;
					if (t.length() > 1)
						//get the string associated with the data node and put it in str
						setStr(str,(ComplexListNode *)t.getNodeByIndex(1));
					else
						str = NULL;
				}
			}
		}
		while (child != -1)
		{
			//get children matches
			if (getFirstMatch(specIndex,child,sk,ek,lev,str) == FAILURE)
				return FAILURE;
			child = spec->getSpecByIndex(specIndex)->getPattern()->getSiblingIndex(child);
		}	

		//initialize the index reads for the next input witness tree
		for (int i=0; i<spec->getSpecByIndex(specIndex)->getPattern()->GetSize(); i++)
			spec->getSpecByIndex(specIndex)->getPattern()->GetEntryByIndex(i)->SetIterator(NULL);
	}
	return SUCCESS;
}


int ConstructIterator::setSourceOfData(int specIndex, int patternIndex)
{
	// in this method, we initialize the index reads or the scans
	if (spec->getSpecByIndex(specIndex)->getPattern()->GetEntryByIndex(patternIndex)->GetQueryEvalNode()->getQueryEvaluationTreeNodeType() 
		== EVALUATION_OP_INDEX_ACCESS)
	{
		//index access
		QueryEvaluationTreeIndexAccessNode *newNode = 
			(QueryEvaluationTreeIndexAccessNode *)spec->getSpecByIndex(specIndex)->getPattern()->GetEntryByIndex(patternIndex)->GetQueryEvalNode();
		if (newNode->isFromFile())
		{
		//	spec->getSpecByIndex(specIndex)->getPattern()->GetEntryByIndex(patternIndex)->SetIterator(
		//		new ShoreFile(&(dataMng->getVolumeID()),&(newNode->getFid())));
		}
		else
		{		
			if (newNode->getShoreOrGist() == SHORE_INDEX)
			{
			}
			else
			{
				bt_query_t *pred;

				if (newNode->getIndexType() == INT_INDEX)
				{
					int val;
					val = atoi((char *)newNode->getValue());
					if (newNode->getValue2() != NULL)
					{
						int val2 = atoi((char *)newNode->getValue2());
						pred = new bt_query_t(bt_query_t::bt_betw, new int(val), new int(val2));
					}
					else
						pred = new bt_query_t(bt_query_t::bt_eq, new int(val), NULL);
				}
				else if (newNode->getIndexType() == FLOAT_INDEX)
				{
					float val;
					val = (float) atof((char *)newNode->getValue());
					if (newNode->getValue2() != NULL)
					{
						float val2 = (float) atof((char *)newNode->getValue2());
						pred = new bt_query_t(bt_query_t::bt_betw, new float(val), new float(val2));
					}
					else
						pred = new bt_query_t(bt_query_t::bt_eq, new float(val), NULL);
				}
				else
				{
					char *val = new char[strlen((char *)newNode->getValue())+1];
					strcpy(val,(char *)newNode->getValue());
					if (newNode->getValue2() != NULL)
					{
						char *val2 = new char[strlen((char *)newNode->getValue2())+1];
						strcpy(val2,(char *)newNode->getValue2());
						pred = new bt_query_t(bt_query_t::bt_betw, val, val2);
					}
					else
						pred = new bt_query_t(bt_query_t::bt_eq, val, NULL);
				}
				int openFileIndex = EvaluatorClass::openFile(newNode->getFileName(),dataMng);
				if (openFileIndex == -1)
				{
					globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"Evaluator",__FILE__,"You are trying to access index of an unloaded file.");
					return FAILURE;
				}
				spec->getSpecByIndex(specIndex)->getPattern()->GetEntryByIndex(patternIndex)->SetIterator(	
					new GistIndexAccess(newNode->getIndexName(),pred,newNode->getIndexType(),(char)openFileIndex,DEFAULT_NODES_NRE));
			}
		}
	}
	else
	{ //scan access
		QueryEvaluationTreeScanAccessNode *newNode = 
			(QueryEvaluationTreeScanAccessNode *)spec->getSpecByIndex(specIndex)->getPattern()->GetEntryByIndex(patternIndex)->GetQueryEvalNode();
		int openFileIndex = EvaluatorClass::openFile(newNode->getFileName(),dataMng);
		if (openFileIndex == -1)
		{
			globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"Evaluator",__FILE__,"You are trying to scan an unloaded file.");
			return FAILURE;
		}
		FileIDType fid = EvaluatorClass::getFileID(openFileIndex);
		spec->getSpecByIndex(specIndex)->getPattern()->GetEntryByIndex(patternIndex)->SetIterator(new ScanIterator(newNode->getScanRoot(),
			newNode->getScanRange(),newNode->getScanCondition(),(char)openFileIndex,DEFAULT_NODES_NRE,dataMng,fid));
	}
	spec->getSpecByIndex(specIndex)->getPattern()->GetEntryByIndex(patternIndex)->GetIterator()->next(res[patternIndex-1]);
	return SUCCESS;
}

int ConstructIterator::getActualData(int specIndex, int patternIndex, short localLev, WitnessTree *t, WitnessTree *origTree, int index, bool ignoreSubtree)
{
	// in this method, the data node is read from the DB according to what is needed
	int getWhat = 
		(patternIndex == -1?spec->getSpecByIndex(specIndex)->getRootGetWhat():spec->getSpecByIndex(specIndex)->getGetWhat()[patternIndex]);

	if (ignoreSubtree && (getWhat == CPM_GET_SUBTREE || getWhat == CPM_GET_LOCAL_SUBTREE))
		getWhat = CPM_GET_ITSELF;

	if (getWhat == CPM_GET_LOCAL_SUBTREE && origTree == NULL)
		getWhat = CPM_GET_ITSELF;

	//((ComplexListNode *)t->getNodeByIndex(t->length()-1))->setNRE(spec->getSpecByIndex(specIndex)->getAssignedNRE());
	switch (getWhat)
	{
	case CPM_GET_ITSELF: // if the node itself is needed, it is already there.
		break;
	case CPM_GET_SUBTREE:
		{ // if the subtree is needed, we go get it from the database
			int len = t->length()-1;
			FileIDType fileid;
			if (t->isSimple())
				fileid = EvaluatorClass::getFileID((int)((ListNode *)t->getNodeByIndex(len))->getFileIndex());
			else
				fileid = EvaluatorClass::getFileID((int)((ComplexListNode *)t->getNodeByIndex(len))->getFileIndex());
			if (fileid == -1)
			{
				globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"Evaluator",__FILE__,"You are trying to access an unloaded file.");
				return FAILURE;
			}
			EvaluatorClass::GetAllDesc(t,len,dataMng,fileid,localLev,spec->getSpecByIndex(specIndex)->getAssignedNRE());
		}
		break;
	case CPM_GET_LOCAL_SUBTREE:
		{
			getLocalSubtree(origTree,index,t,spec->getSpecByIndex(specIndex)->getAssignedNRE(),localLev+1);
		}
		break;
	case CPM_GET_TEXT:
		{
			// if the text is needed, text nodes are read from DB
			int len = t->length() -1;
			FileIDType fileid;
			if (t->isSimple())
				fileid = EvaluatorClass::getFileID((int)((ListNode *)t->getNodeByIndex(len))->getFileIndex());
			else
				fileid = EvaluatorClass::getFileID((int)((ComplexListNode *)t->getNodeByIndex(len))->getFileIndex());
			if (fileid == -1)
			{
				globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"Evaluator",__FILE__,"You are trying to access an unloaded file.");
				return FAILURE;
			}
			EvaluatorClass::GetText(t,len,dataMng,fileid,localLev,spec->getSpecByIndex(specIndex)->getAssignedNRE());
		//	if (res != FAILURE)
		//		((ComplexListNode *)t->getNodeByIndex(res))->setNRE(spec->getSpecByIndex(specIndex)->getAssignedNRE());
			t->deleteNode(len);
		}
		break;
	case CPM_GET_VALUE:
		{
			char *str;
			int len = t->length() -1;
			if (patternIndex == -1)
				this->setStr(str,(ComplexListNode *)t->getNodeByIndex(len),
				spec->getSpecByIndex(specIndex)->getRootAttrName());
			else
				this->setStr(str,(ComplexListNode *)t->getNodeByIndex(len),
					spec->getSpecByIndex(specIndex)->getAttrNames()[patternIndex]);
			ComplexListNode n;
			n.SetDummy(true);
			n.SetDummyName(str);
			n.SetLocalLevel(localLev);
			n.setNRE(spec->getSpecByIndex(specIndex)->getAssignedNRE());
			t->deleteNode(len);
			t->appendList(&n,dataMng,1);
			if (str) delete [] str;
		}
		break;
	case CPM_GET_ATTR:
		{
			// if attr node is needed, then the attr node is read from DB
			FileIDType fileid;
			if (t->isSimple())
				fileid = EvaluatorClass::getFileID((int)((ListNode *)t->getNodeByIndex(t->length() -1))->getFileIndex());
			else
				fileid = EvaluatorClass::getFileID((int)((ComplexListNode *)t->getNodeByIndex(t->length() -1))->getFileIndex());
			if (fileid == -1)
			{
				globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"Evaluator",__FILE__,"You are trying to access an unloaded file.");
				return FAILURE;
			}			
			if (EvaluatorClass::GetAttributes(t,t->length() -1,dataMng,fileid,localLev) == SUCCESS)
			{
				if (patternIndex != -1)
				{
					if (spec->getSpecByIndex(specIndex)->getAttrNames())
					{
						if (spec->getSpecByIndex(specIndex)->getAttrNames()[patternIndex])
						{
							Value *val1 = ((DM_AttributeNode *)((ComplexListNode *)t->getNodeByIndex(t->length() -1))->GetData())->getAttr(
								spec->getSpecByIndex(specIndex)->getAttrNames()[patternIndex]);
							if (val1)
							{
								ComplexListNode n;
								n.SetDummy(true);
								n.SetDummyName(val1->getStrValue());
								n.SetLocalLevel(localLev);
								n.setNRE(spec->getSpecByIndex(specIndex)->getAssignedNRE());
								t->deleteNode(t->length()-1);
								t->deleteNode(t->length()-1);
								t->appendList(&n,dataMng,1);
							}
							else
							{
								t->deleteNode(t->length()-1);
								t->deleteNode(t->length()-1);
							}
						}
						else
						{
							t->deleteNode(t->length()-1);
							t->deleteNode(t->length()-1);
						}
					}
					else
					{
						t->deleteNode(t->length()-1);
						t->deleteNode(t->length()-1);
					}
				}
				else
				{
					if (spec->getSpecByIndex(specIndex)->getRootAttrName())
					{
						Value *val1 = ((DM_AttributeNode *)((ComplexListNode *)t->getNodeByIndex(t->length() -1))->GetData())->getAttr(
							spec->getSpecByIndex(specIndex)->getRootAttrName());
						if (val1)
						{
							ComplexListNode n;
							n.SetDummy(true);
							n.SetDummyName(val1->getStrValue());
							n.SetLocalLevel(localLev);
							n.setNRE(spec->getSpecByIndex(specIndex)->getAssignedNRE());
							t->deleteNode(t->length()-1);
							t->deleteNode(t->length()-1);
							t->appendList(&n,dataMng,1);
						}
						else
						{
							t->deleteNode(t->length()-1);
							t->deleteNode(t->length()-1);
						}
					}
					else
					{
						t->deleteNode(t->length()-1);
						t->deleteNode(t->length()-1);
					}
				}
			}
			else
				t->deleteNode(t->length()-1);
		}
		break;
	}
	return SUCCESS;
}

void ConstructIterator::setStr(char *&str, ComplexListNode *n, char *attrName)
{
	// in this method, we set the string str to be the data associated with the node n
	str = NULL;
	if (n->GetData())
	{
		switch (n->GetData()->getFlag())
		{
		case DOCUMENT_NODE:
			str = new char[strlen(((DM_DocumentNode *)n->GetData())->getXMLFileName())+1];
			strcpy(str,((DM_DocumentNode *)n->GetData())->getXMLFileName());
			break;
		case ELEMENT_NODE:
			// for an element node, str is the tag
			{
				char *tagName = dataMng->getPhysicalDataMng()->getXMLNameTable()->getNameByCode(n->GetData()->getTag());
				if (tagName)
				{
					str = new char[strlen(tagName)+1];
					strcpy(str,tagName);
				}
			}
			break;
		case ATTRIBUTE_NODE:
			{ //for attr, str is the value of the first attribute
				//char name[MAX_ATTRIBUTE_NAME_LENGTH];
				char* name = NULL;

				Value *val;
				if (!attrName)
					val = ((DM_AttributeNode *)n->GetData())->getAttr(0,name);
				else
					val = ((DM_AttributeNode *)n->GetData())->getAttr(attrName);
				if (val)
				{
					str = new char[strlen(val->getStrValue())+1];
					strcpy(str,val->getStrValue());
				}
			}
			break;
		case TEXT_NODE:
			//for text node, str is the text content
			str = new char[strlen(((DM_CharNode *)n->GetData())->getCharValue()) + 1];
			strcpy(str,((DM_CharNode *)n->GetData())->getCharValue());
			break;
		}
	}
	else if (n->IsDummy())
	{
		str = new char[strlen(n->GetDummyName())+1];
		strcpy(str,n->GetDummyName());
	}
}

int ConstructIterator::scanWitnessTree(int specIndex, WitnessTree *tree, bool returnAfterFirst)
{
	// in this method, we scan the input witness tree for a given set of tags in a pattern
	
//	char currExpectedTag[MAX_NODETAG_LENGTH];
	int currExpectedTag = -1;
	tree->startFindNodesNRE(spec->getSpecByIndex(specIndex)->getPatternRootNRE());
	ComplexListNode *root = (ComplexListNode *)tree->getNextNodeNRE();
	
	while (root)
	{
		//push the root into the stack
		stack<SimpleStackNode> s;
		s.Push(root);
		int currExpTagIndex = 1;
		int lastTagIndex = spec->getSpecByIndex(specIndex)->getPattern()->GetSize() - 1;
		//strcpy(currExpectedTag,spec->getSpecByIndex(specIndex)->getTagNames()[currExpTagIndex]);
		currExpectedTag = spec->getSpecByIndex(specIndex)->getTagNames()[currExpTagIndex];
		tree->startScan();
		tree->switchToComplex(dataMng);
		int ind = 0;
		ComplexListNode *n = (ComplexListNode *)tree->getNext();

		//as long as we still have nodes in the witness tree
		while (n)
		{
			if (n->IsDummy() || n->GetStartPos() == -1)
			{ 
				// skip the dummy node
				n = (ComplexListNode *)tree->getNext();
				ind++;
				continue;
			}
		
			//skip non-element nodes
			if (n->GetData())
			{
				if (n->GetData()->getFlag() != ELEMENT_NODE)
				{
					n = (ComplexListNode *)tree->getNext();
					ind++;
					continue;
				}
			}
			else
			{
				globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"Evaluator",__FILE__,"Could not get data of node when scanning witness tree.");
				return FAILURE;
			}

			//popping the stack

			ComplexListNode *stackTop = s.GetTop()->GetActualAncsComplex();
			while (n->isNotContainedIn(stackTop))
			{
				s.Pop();
				currExpTagIndex--;
			//	strcpy(currExpectedTag,spec->getSpecByIndex(specIndex)->getTagNames()[currExpTagIndex]);
				currExpectedTag = spec->getSpecByIndex(specIndex)->getTagNames()[currExpTagIndex];
				if (s.IsEmpty())
					break;
				stackTop = s.GetTop()->GetActualAncsComplex();
			}

			if (s.IsEmpty())
				break;

			//the current tag does not match the expected tag, skip
			if (n->GetData()->getTag() != currExpectedTag)
			{
				n = (ComplexListNode *)tree->getNext();
				ind++;
				continue;
			}

			//if relationship is parent child, check level condition
			if (spec->getSpecByIndex(specIndex)->getRelation()[currExpTagIndex-1] == PARENT_CHILD)
				if (!(s.GetTop()->GetActualAncsComplex()->isParentOf(n)))
				{
					n = (ComplexListNode *)tree->getNext();
					ind++;
					continue;
				}

				if  (currExpTagIndex == lastTagIndex)
				{ // if the current tag is the last one in the pattern, add the match to resultBuffer
					n->SetLocalLevel((short)spec->getSpecByIndex(specIndex)->getLevel());
					n->setNRE(spec->getSpecByIndex(specIndex)->getAssignedNRE());
					resultBuffer->appendList(n,dataMng,1);
					if (getActualData(specIndex,currExpTagIndex,(short)spec->getSpecByIndex(specIndex)->getLevel(),resultBuffer,tree,ind,returnAfterFirst) == FAILURE)
						return FAILURE;
					if (returnAfterFirst)
						return SUCCESS;
				}
				else
				{
					//else, just push the node into stack
					currExpTagIndex++;
					//strcpy(currExpectedTag,spec->getSpecByIndex(specIndex)->getTagNames()[currExpTagIndex]);
					currExpectedTag = spec->getSpecByIndex(specIndex)->getTagNames()[currExpTagIndex];
					s.Push(n);
				}
				n = (ComplexListNode *)tree->getNext();
				ind++;
		}
		root = (ComplexListNode *)tree->getNextNodeNRE();
	}
	return SUCCESS;//(returnAfterFirst? FAILURE : SUCCESS);
}

void ConstructIterator::getLocalSubtree(WitnessTree *origTree,int index,WitnessTree *t, NREType nre, short localLev)
{
	int child = origTree->GetLocalChild(index);

	while (child != FAILURE)
	{
		t->appendList((ComplexListNode *)origTree->getNodeByIndex(child),dataMng,1);
		((ComplexListNode *)t->getNodeByIndex(t->length()-1))->setNRE(nre);
		((ComplexListNode *)t->getNodeByIndex(t->length()-1))->SetLocalLevel(localLev);
		getLocalSubtree(origTree,child,t,nre,localLev+1);
		child = origTree->GetNextLocalSibling(child);
	}
}