/*
COPYRIGHT  � 2000-2004 
THE REGENTS OF THE UNIVERSITY OF MICHIGAN
ALL RIGHTS RESERVED

PERMISSION IS GRANTED TO USE, COPY, CREATE DERIVATIVE WORKS AND REDISTRIBUTE THIS SOFTWARE AND SUCH DERIVATIVE WORKS FOR 
NONCOMMERCIAL EDUCATION AND RESEARCH PURPOSES, SO LONG AS NO FEE IS CHARGED, AND SO LONG AS THE COPYRIGHT NOTICE ABOVE, 
THIS GRANT OF PERMISSION, AND THE DISCLAIMER BELOW APPEAR IN ALL COPIES MADE; AND SO LONG AS THE NAME OF THE UNIVERSITY 
OF MICHIGAN IS NOT USED IN ANY ADVERTISING OR PUBLICITY PERTAINING TO THE USE OR DISTRIBUTION OF THIS SOFTWARE WITHOUT 
SPECIFIC, WRITTEN PRIOR AUTHORIZATION.

THIS SOFTWARE IS PROVIDED AS IS, WITHOUT REPRESENTATION FROM THE UNIVERSITY OF MICHIGAN AS TO ITS FITNESS FOR ANY PURPOSE, 
AND WITHOUT WARRANTY BY THE UNIVERSITY OF MICHIGAN OF ANY KIND, EITHER EXPRESS OR IMPLIED, INCLUDING WITHOUT LIMITATION THE 
IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE. THE REGENTS OF THE UNIVERSITY OF MICHIGAN SHALL 
NOT BE LIABLE FOR ANY DAMAGES, INCLUDING SPECIAL, INDIRECT, INCIDENTAL, OR CONSEQUENTIAL DAMAGES, WITH RESPECT TO ANY CLAIM 
ARISING OUT OF OR IN CONNECTION WITH THE USE OF THE SOFTWARE, EVEN IF IT HAS BEEN OR IS HEREAFTER ADVISED OF THE POSSIBILITY 
OF SUCH DAMAGES.
*/

#include "ValueSortIterator.h"

//int listLength;
//char **elementsList;
DataMng *gdataMngVal;

NREType *gNREVal;
char **gAttrNameVal;
int *gOrderVal;
int *gSortByVal;
int gNumVal;
int *gWhereEmptyGoesVal;

int compareNodesValSort(const void *elem1,const void *elem2)
{
	for (int i=0; i<gNumVal; i++)
	{
		int index1 = ((WitnessTree *)elem1)->getIndexOfNRE(gNREVal[i]);
		int index2 = ((WitnessTree *)elem2)->getIndexOfNRE(gNREVal[i]);
		if (index1 == FAILURE && index2 == FAILURE)
			continue;
		if (index1 == FAILURE)
			return (-1*gWhereEmptyGoesVal[i]);
		if (index2 == FAILURE)
			return (gWhereEmptyGoesVal[i]);

		FileIDType fileid1 = EvaluatorClass::getFileID(((ComplexListNode *)((WitnessTree *)elem1)->getNodeByIndex(index1))->getFileIndex());
		if (fileid1 == -1)
			return -1;
		FileIDType fileid2 = EvaluatorClass::getFileID(((ComplexListNode *)((WitnessTree *)elem2)->getNodeByIndex(index2))->getFileIndex());
		if (fileid2 == -1)
			return -1;

		switch (gSortByVal[i])
		{
		case SORTBY_TEXT_NUM:
		case SORTBY_TEXT_STR:
			{
				int res1 = EvaluatorClass::GetText((WitnessTree *)elem1,index1,gdataMngVal,fileid1);
				int res2 = EvaluatorClass::GetText((WitnessTree *)elem2,index2,gdataMngVal,fileid2);
				if ((res1 == FAILURE  || res1 == 0) && (res2 == FAILURE  || res2 == 0))
					continue;
				if (res1 == FAILURE  || res1 == 0)
					return (-1*gWhereEmptyGoesVal[i]);

				if (res2 == FAILURE  || res2 == 0)
					return (gWhereEmptyGoesVal[i]);
				char *txt1 = ((DM_CharNode *)((ComplexListNode *)((WitnessTree *)elem1)->getNodeByIndex(res1))->GetData())->getCharValue();
				char *txt2 = ((DM_CharNode *)((ComplexListNode *)((WitnessTree *)elem2)->getNodeByIndex(res2))->GetData())->getCharValue();

				if (gSortByVal[i] == SORTBY_TEXT_NUM)
				{
					double num1 = atof(txt1);
					double num2 = atof(txt2);
					if (num1 == num2)
						continue;
					else
						return (int)(gOrderVal[i]* ceil(num1 - num2));
				}
				else
				{
					int r = strcmp(txt1,txt2);
					if (r == 0)
						continue;
					else
						return gOrderVal[i]*r;
				}
			}
			break;
		case SORTBY_ATTRIBUTE_NUM:
		case SORTBY_ATTRIBUTE_STR:
			{
				int res1 = EvaluatorClass::GetAttributes((WitnessTree *)elem1,index1,gdataMngVal,fileid1);
				int res2 = EvaluatorClass::GetAttributes((WitnessTree *)elem2,index2,gdataMngVal,fileid2);
				if (res1 == FAILURE && res2 == FAILURE)
					continue;
				if (res1 == FAILURE)
					return (-1*gWhereEmptyGoesVal[i]);

				if (res2 == FAILURE)
					return (gWhereEmptyGoesVal[i]);
				
				Value *val1 = ((DM_AttributeNode *)((ComplexListNode *)((WitnessTree *)elem1)->getNodeByIndex(index1+1))->GetData())->getAttr(gAttrNameVal[i]);
				Value *val2 = ((DM_AttributeNode *)((ComplexListNode *)((WitnessTree *)elem2)->getNodeByIndex(index2+1))->GetData())->getAttr(gAttrNameVal[i]);
			
				if (!val1 && !val2) 
					continue;
				
				if (!val1)
					return (-1*gWhereEmptyGoesVal[i]);
				if (!val2)
					return (gWhereEmptyGoesVal[i]);

				char *txt1 = val1->getStrValue();
				char *txt2 = val2->getStrValue();
				if (gSortByVal[i] == SORTBY_ATTRIBUTE_NUM)
				{
					double num1 = atof(txt1);
					double num2 = atof(txt2);
					if (num1 == num2)
						continue;
					else
						return (int)(gOrderVal[i]* ceil(num1 - num2));
				}
				else
				{
					int r = strcmp(txt1,txt2);
					if (r == 0)
						continue;
					else
						return gOrderVal[i]*r;
				}
			}
			break;
		case SORTBY_TAGNAME:
			{
				ComplexListNode *n1 = (ComplexListNode *)((WitnessTree *)elem1)->getNodeByIndex(index1);
				ComplexListNode *n2 = (ComplexListNode *)((WitnessTree *)elem2)->getNodeByIndex(index2);
				DM_DataNode *dn1 = n1->GetData();
				DM_DataNode *dn2 = n2->GetData();
				if (dn1 == NULL && dn2 == NULL)
					continue;
				if (dn1 == NULL)
					return -1*gWhereEmptyGoesVal[i];
				
				if (dn2 == NULL)
					return gWhereEmptyGoesVal[i];
				
				if (dn1->getFlag() != ELEMENT_NODE && dn2->getFlag() != ELEMENT_NODE)
					continue;
				
				if (dn1->getFlag() != ELEMENT_NODE)
					return (-1*gWhereEmptyGoesVal[i]);

				if (dn2->getFlag() != ELEMENT_NODE)
					return (gWhereEmptyGoesVal[i]);
				if (((DM_ElementNode *)dn1)->getTag() == ((DM_ElementNode *)dn2)->getTag())
					continue;

				char *tag1 = gdataMngVal->getPhysicalDataMng()->getXMLNameTable()->getNameByCode(((DM_ElementNode *)dn1)->getTag());
				char *tag2 = gdataMngVal->getPhysicalDataMng()->getXMLNameTable()->getNameByCode(((DM_ElementNode *)dn2)->getTag());
				int r = strcmp(tag1, tag2);
				if (r == 0)
					continue;
				else
					return gOrderVal[i] * r;
			}
			break;
		case SORTBY_VALUE_NUM:
		case SORTBY_VALUE_STR:
			{
				DM_DataNode *dn1 = ((ComplexListNode *)((WitnessTree *)elem1)->getNodeByIndex(index1))->GetData();
				DM_DataNode *dn2 = ((ComplexListNode *)((WitnessTree *)elem2)->getNodeByIndex(index2))->GetData();
				if (dn1 == NULL && dn2 == NULL)
					continue;
				if (dn1 == NULL)
					return -1*gWhereEmptyGoesVal[i];
				
				if (dn2 == NULL)
					return gWhereEmptyGoesVal[i];

				char *txt1;
				char *txt2;
				Value *val1;
				Value *val2;
				if (dn1->getFlag() == ELEMENT_NODE)
					txt1 = gdataMngVal->getPhysicalDataMng()->getXMLNameTable()->getNameByCode(((DM_ElementNode *)dn1)->getTag());

				else if (dn1->getFlag() == DOCUMENT_NODE)
				{
					if (((DM_DocumentNode *)dn1)->getXMLFileName())
						txt1 = ((DM_DocumentNode *)dn1)->getXMLFileName();
					else
						txt1 = NULL;
				}
				else if (dn1->getFlag() == ATTRIBUTE_NODE)
				{
					//if attribute node, return the value of attribute "attrName"
					
					val1 = ((DM_AttributeNode *)dn1)->getAttr(gAttrNameVal[i]);
					if (val1 != NULL)
					{
						if (val1->getStrValue() != NULL && strlen(val1->getStrValue()) != 0)
							txt1 = val1->getStrValue();
						else
							txt1 = NULL;
					}
					else
						txt1 = NULL;
				} 
				else
				{
					//if text node, return the text value
					if (((DM_CharNode *)dn1)->getCharValue())
						txt1 = ((DM_CharNode *)dn1)->getCharValue();
					else
						txt1 = NULL;
				}

				//getting second vLUES
				if (dn2->getFlag() == ELEMENT_NODE)
					txt2 = gdataMngVal->getPhysicalDataMng()->getXMLNameTable()->getNameByCode(((DM_ElementNode *)dn2)->getTag());

				else if (dn2->getFlag() == DOCUMENT_NODE)
				{
					if (((DM_DocumentNode *)dn2)->getXMLFileName())
						txt2 = ((DM_DocumentNode *)dn2)->getXMLFileName();
					else
						txt2 = NULL;
				}
				else if (dn2->getFlag() == ATTRIBUTE_NODE)
				{
					//if attribute node, return the value of attribute "attrName"
					
					val2 = ((DM_AttributeNode *)dn2)->getAttr(gAttrNameVal[i]);
					if (val2 != NULL)
					{
						if (val2->getStrValue() != NULL && strlen(val2->getStrValue()) != 0)
							txt2 = val2->getStrValue();
						else
							txt2 = NULL;
					}
					else
						txt2 = NULL;
				} 
				else
				{
					//if text node, return the text value
					if (((DM_CharNode *)dn2)->getCharValue())
						txt2 = ((DM_CharNode *)dn2)->getCharValue();
					else
						txt2 = NULL;
				}
				if (!txt1 && !txt2) 
					continue;
				
				if (!txt1)
					return (-1*gWhereEmptyGoesVal[i]);
				if (!txt2)
					return (gWhereEmptyGoesVal[i]);

				if (gSortByVal[i] == SORTBY_VALUE_NUM)
				{
					double num1 = atof(txt1);
					double num2 = atof(txt2);
					if (num1 == num2)
						continue;
					else
						return (int)(gOrderVal[i]* ceil(num1 - num2));
				}
				else
				{
					int r = strcmp(txt1,txt2);
					if (r == 0)
						continue;
					else
						return gOrderVal[i]*r;
				}

			}
			break;
			case SORT_BY_START_KEY:
				{
					KeyType sk1 = ((ComplexListNode *)((WitnessTree *)elem1)->getNodeByIndex(index1))->GetStartPos();
					KeyType sk2 = ((ComplexListNode *)((WitnessTree *)elem2)->getNodeByIndex(index2))->GetStartPos();
					if (sk1 == sk2)
						continue;
					else
					{
						if (sk1 < sk2)
							return (-1*gOrderVal[i]);
						else
							return (gOrderVal[i]);
					}
				}
				break;
		}
	}
	int n = ((WitnessTree *)elem1)->length() < ((WitnessTree *)elem2)->length()?
		((WitnessTree *)elem1)->length() : ((WitnessTree *)elem2)->length();
	for (int i=0; i<n; i++)
	{
		if (((ComplexListNode *)((WitnessTree *)elem1)->findNode(i))->GetStartPos() ==
			((ComplexListNode *)((WitnessTree *)elem2)->findNode(i))->GetStartPos())
			continue;
		else
		{
			if (((ComplexListNode *)((WitnessTree *)elem1)->findNode(i))->GetStartPos() <
				((ComplexListNode *)((WitnessTree *)elem2)->findNode(i))->GetStartPos())
				return -1;
			else
				return 1;
		}
	}
	if (((WitnessTree *)elem1)->length() < ((WitnessTree *)elem2)->length())
		return -1;
	else if (((WitnessTree *)elem1)->length() > ((WitnessTree *)elem2)->length())
		return 1;
	return 0;
}


ValueSortIterator::ValueSortIterator(IteratorClass *input, int numExpected, int num, int *sortBy,  
									NREType *nre, char **attrName, int *order, DataMng *dataMng, int *whereEmptyGoes)
{
	this->dataMng = dataMng;
	this->input = input;
	size = 0;
	if (numExpected <= 0)
		numExpected = gSettings->getIntegerValue("INITIAL_DEFAULT_SORT_ARRAY_SIZE",INITIAL_SORT_ARRAY_SIZE_DEFAULT);
	numExpected++;
	sortArray = new WitnessTree[numExpected];
	resultBuffer  = new WitnessTree(LIST_NODE_WITH_DATA, dataMng);
	i=0;

	input->next(inTuple);
	while (inTuple)
	{
		inTuple->switchToComplex(dataMng);

		if (size >= numExpected)
		{
		//if sortArray size is not enough-->double it
			WitnessTree *tmp = sortArray;
			numExpected *= 2;
			sortArray = new WitnessTree[numExpected];
			memcpy(sortArray, tmp, size * sizeof(WitnessTree));
			delete [] tmp;
		}
		sortArray[size].copyTree(inTuple);
		sortArray[size].setDeleteBuffers(false);
		size++;

		input->next(inTuple);
	}
	delete input;

	if (globalErrorInfo.doWeHaveAProblem())
	{
		if (nre) delete [] nre;
		if (order) delete  [] order;
		if (sortBy) delete [] sortBy;
		if (whereEmptyGoes) delete [] whereEmptyGoes;
		if (attrName)
		{
			for (int i=0; i< num; i++)
				if (attrName[i])
					delete [] attrName[i];
			delete [] attrName;
		}
		size = 0;
		return;
	}
	
	gdataMngVal = dataMng;
	gNREVal = nre;
	gNumVal = num;
	gAttrNameVal = attrName;
	gOrderVal = order;
	gSortByVal = sortBy;
	gWhereEmptyGoesVal = whereEmptyGoes;

	EvalQuickSort s;
	if (s.quickSort(sortArray,0,size-1,compareNodesValSort) == FAILURE)
		size = 0;

	//qsort(sortArray,size,sizeof(WitnessTree),compareNodesValSort);

	if (nre) delete [] nre;
	if (order) delete  [] order;
	if (sortBy) delete [] sortBy;
	if (whereEmptyGoes) delete [] whereEmptyGoes;
	if (attrName)
	{
		for (int i=0; i< num; i++)
			if (attrName[i])
				delete [] attrName[i];
		delete [] attrName;
	}
}


ValueSortIterator::~ValueSortIterator()
{
	delete [] sortArray;
	delete resultBuffer;
}

void ValueSortIterator::next(WitnessTree *&node)
{	
#ifdef EVAL_TIME_OUT
	clock_t currTime = clock();
	double queryDuration = (double)(currTime - gQueryStartTime) / CLOCKS_PER_SEC;
	if (queryDuration >= gTimeOutAfter)
	{
		globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"Evaluator",__FILE__,"Query Timed Out.");
		node = NULL;
		return;
	}
#endif
	//read the array into output
	while (i < size)
	{
		//write array entry into resultBuffer
		resultBuffer->copyTree(&sortArray[i]);
		node = resultBuffer;
		i++;
		sortArray[i].setDeleteBuffers(true);
		return;
	}
	node = NULL;
	return;
}

