#ifndef __DataInstantiationIterator_h

#define __DataInstantiationIterator_h



#include "../Evaluator/EvaluatorClass.h"


 
class DataInstantiationIterator : public IteratorClass
{

public:
	
	DataInstantiationIterator(
IteratorClass *input,int index,DataInstantiationSpecification* diSpec,DataMng *dataMng);
	
	~DataInstantiationIterator();

	void next(WitnessTree *&node);

private:
	IteratorClass *input;
	int index;
	DataInstantiationSpecification* diSpec;
	
	DataMng *dataMng;
	WitnessTree *resultBuffer;
	WitnessTree *inTuple;
};
#endif
