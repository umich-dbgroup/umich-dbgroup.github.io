/*
COPYRIGHT  � 2000-2004 
THE REGENTS OF THE UNIVERSITY OF MICHIGAN
ALL RIGHTS RESERVED

PERMISSION IS GRANTED TO USE, COPY, CREATE DERIVATIVE WORKS AND REDISTRIBUTE THIS SOFTWARE AND SUCH DERIVATIVE WORKS FOR 
NONCOMMERCIAL EDUCATION AND RESEARCH PURPOSES, SO LONG AS NO FEE IS CHARGED, AND SO LONG AS THE COPYRIGHT NOTICE ABOVE, 
THIS GRANT OF PERMISSION, AND THE DISCLAIMER BELOW APPEAR IN ALL COPIES MADE; AND SO LONG AS THE NAME OF THE UNIVERSITY 
OF MICHIGAN IS NOT USED IN ANY ADVERTISING OR PUBLICITY PERTAINING TO THE USE OR DISTRIBUTION OF THIS SOFTWARE WITHOUT 
SPECIFIC, WRITTEN PRIOR AUTHORIZATION.

THIS SOFTWARE IS PROVIDED AS IS, WITHOUT REPRESENTATION FROM THE UNIVERSITY OF MICHIGAN AS TO ITS FITNESS FOR ANY PURPOSE, 
AND WITHOUT WARRANTY BY THE UNIVERSITY OF MICHIGAN OF ANY KIND, EITHER EXPRESS OR IMPLIED, INCLUDING WITHOUT LIMITATION THE 
IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE. THE REGENTS OF THE UNIVERSITY OF MICHIGAN SHALL 
NOT BE LIABLE FOR ANY DAMAGES, INCLUDING SPECIAL, INDIRECT, INCIDENTAL, OR CONSEQUENTIAL DAMAGES, WITH RESPECT TO ANY CLAIM 
ARISING OUT OF OR IN CONNECTION WITH THE USE OF THE SOFTWARE, EVEN IF IT HAS BEEN OR IS HEREAFTER ADVISED OF THE POSSIBILITY 
OF SUCH DAMAGES.
*/

#include "ExternalSortIterator.h"
#include "../Stack/SBJoinAncsStackNode.h"
#include "../Evaluator/Evaluator_definitions.h"
#include <math.h>

int *gNREX;
int gNumX;
int *gOrderSKX;
int gOrderScX;
int *gWhereEmptyGoesX;

int compareTreesXSK(const void *elem1,const void *elem2)
{
	if (gNREX) 
	{
		for (int i=0; i<gNumX; i++)
		{
			ComplexListNode *n1 = (ComplexListNode *)((WitnessTree *)elem1)->findNodeNRE(gNREX[i]);
			ComplexListNode *n2 = (ComplexListNode *)((WitnessTree *)elem2)->findNodeNRE(gNREX[i]);
			if (!n1 && !n2)
				continue;
			if (!n1)
				return -1*gWhereEmptyGoesX[i];

			if (!n2)
				return gWhereEmptyGoesX[i];

			if (n1->GetStartPos() == n2->GetStartPos())
				continue;
			else
			{
				if (n1->GetStartPos() < n2->GetStartPos())
					return (-1*gOrderSKX[i]);
				else
					return (gOrderSKX[i]);
			}
		}
	}

	//sorting by tree
	int n = ((WitnessTree *)elem1)->length() < ((WitnessTree *)elem2)->length()?
		((WitnessTree *)elem1)->length() : ((WitnessTree *)elem2)->length();
	for (int i=0; i<n; i++)
	{
		if (((ListNode *)((WitnessTree *)elem1)->findNode(i))->GetStartPos() ==
			((ListNode *)((WitnessTree *)elem2)->findNode(i))->GetStartPos())
			continue;
		else
		{
			if (gNREX)
			{
				if (((ListNode *)((WitnessTree *)elem1)->findNode(i))->GetStartPos() <
					((ListNode *)((WitnessTree *)elem2)->findNode(i))->GetStartPos())
					return -1;
				else
					return 1;
			}
			else
			{
				if (((ListNode *)((WitnessTree *)elem1)->findNode(i))->GetStartPos() <
					((ListNode *)((WitnessTree *)elem2)->findNode(i))->GetStartPos())
					return (-1*gNumX);
				else
					return (1*gNumX);
			}
		}
	}
	if (gNREX)
	{
		if (((WitnessTree *)elem1)->length() < ((WitnessTree *)elem2)->length())
			return -1;
		else if (((WitnessTree *)elem1)->length() > ((WitnessTree *)elem2)->length())
			return 1;
	}
	else
	{
		if (((WitnessTree *)elem1)->length() < ((WitnessTree *)elem2)->length())
			return -1*gNumX;
		else if (((WitnessTree *)elem1)->length() > ((WitnessTree *)elem2)->length())
			return 1*gNumX;
	}
	
	return 0;
}

int compareTreesXSKComplex(const void *elem1,const void *elem2)
{
	if (gNREX) 
	{
		for (int i=0; i<gNumX; i++)
		{
			ComplexListNode *n1 = (ComplexListNode *)((WitnessTree *)elem1)->findNodeNRE(gNREX[i]);
			ComplexListNode *n2 = (ComplexListNode *)((WitnessTree *)elem2)->findNodeNRE(gNREX[i]);
			if (!n1 && !n2)
				continue;
			if (!n1)
				return -1*gWhereEmptyGoesX[i];

			if (!n2)
				return gWhereEmptyGoesX[i];

			if (n1->GetStartPos() == n2->GetStartPos())
				continue;
			else
			{
				if (n1->GetStartPos() < n2->GetStartPos())
					return (-1*gOrderSKX[i]);
				else
					return (gOrderSKX[i]);
			}
		}
	}

	//sorting by tree
	int n = ((WitnessTree *)elem1)->length() < ((WitnessTree *)elem2)->length()?
		((WitnessTree *)elem1)->length() : ((WitnessTree *)elem2)->length();
	for (int i=0; i<n; i++)
	{
		if (((ComplexListNode *)((WitnessTree *)elem1)->findNode(i))->GetStartPos() ==
			((ComplexListNode *)((WitnessTree *)elem2)->findNode(i))->GetStartPos())
			continue;
		else
		{
			if (gNREX)
			{
				if (((ComplexListNode *)((WitnessTree *)elem1)->findNode(i))->GetStartPos() <
					((ComplexListNode *)((WitnessTree *)elem2)->findNode(i))->GetStartPos())
					return -1;
				else
					return 1;
			}
			else
			{
				if (((ComplexListNode *)((WitnessTree *)elem1)->findNode(i))->GetStartPos() <
					((ComplexListNode *)((WitnessTree *)elem2)->findNode(i))->GetStartPos())
					return (-1*gNumX);
				else
					return (1*gNumX);
			}
		}
	}
	if (gNREX)
	{
		if (((WitnessTree *)elem1)->length() < ((WitnessTree *)elem2)->length())
			return -1;
		else if (((WitnessTree *)elem1)->length() > ((WitnessTree *)elem2)->length())
			return 1;
	}
	else
	{
		if (((WitnessTree *)elem1)->length() < ((WitnessTree *)elem2)->length())
			return -1*gNumX;
		else if (((WitnessTree *)elem1)->length() > ((WitnessTree *)elem2)->length())
			return 1*gNumX;
	}
	
	return 0;
}

int compareTreesXScore(const void *elem1,const void *elem2)
{
	double score1 = ((WitnessTree *)elem1)->getScore();
	double score2 = ((WitnessTree *)elem2)->getScore();
	if (score1 == score2)
		return 0;
	else if (score1 < score2)
		return -1*gOrderScX;
	else
		return gOrderScX;
}

ExternalSortIterator::ExternalSortIterator(IteratorClass *input, int num, NREType *nre, int *order, DataMng *dataMng, int *whereEmptyGoes
										   , serial_t fileID, serial_t startID,int numWrites)
{	
	inMemSort = false;
	fileCreated = true;
	numCont = 0;
	allNull = false;
	numContIn = gSettings->getIntegerValue("EX_SORT_NUM_OF_CONTAINERS",EX_SORT_DEFAULT_NUM_CONT);
	if (numContIn < EX_SORT_DEFAULT_NUM_CONT)
		numContIn = EX_SORT_DEFAULT_NUM_CONT;
	cont = new ContainerClass[numContIn];

	res = new int[numContIn];
	inTree = new WitnessTree[numContIn];
	sortListsNum = 0;
	currSortList = 0;
	nextEmptySortList = 0;
	this->sortListsCap = gSettings->getIntegerValue("INITIAL_SORT_LISTS_NUM",INITIAL_SORT_LISTS_NUM_DEFAULT);
	this->input = input;
	this->dataMng = dataMng;
	this->num = num;
	this->nre= nre;
	this->orderSK = order;
	this->sortByWhat = SORT_BY_START_KEY;
	this->volumeID = dataMng->getVolumeID();
	this->whereEmptyGoes = whereEmptyGoes;

	this->fileID = fileID;
	this->startID = startID;
	this->numWrites = numWrites;
	this->sortArray = NULL;
	this->sortLists = NULL;
	//numWrites = 0;
	resultBuffer = new WitnessTree;

	buildSortArray();

	if (readInputIntoLists() == FAILURE)
		allNull = true;
	else
	{
		if (inMemSort)
			allNull = !readTreesFromContainers();
		else
		{
			if (sortTheLists() == FAILURE)
				allNull = true;
			else
			{
				//here we have 2 lists at locations 0 and 1 in the sortLists array
				sortLists[0].StartScan();
				sortLists[1].StartScan();
				res[0] = sortLists[0].GetNext(&cont[0]);
				res[1] = sortLists[1].GetNext(&cont[1]);
				
				if (res[0] == SUCCESS)
					res[0] = readWitnessTreeFromContainer(&inTree[0], &cont[0]);
				if (res[1] == SUCCESS)
					res[1] = readWitnessTreeFromContainer(&inTree[1], &cont[1]); 
				if (res[0] == FAILURE && res[1] == FAILURE)
					allNull = true;
				else
					allNull = false;
				numContIn = 2;
			}
		}
	}
}


ExternalSortIterator::ExternalSortIterator(IteratorClass *input,int order, DataMng *dataMng, serial_t fileID, serial_t startID
										   ,int numWrites)
{	
	inMemSort = false;
	fileCreated = true;
	numCont = 0;
	allNull = false;
	numContIn = gSettings->getIntegerValue("EX_SORT_NUM_OF_CONTAINERS",EX_SORT_DEFAULT_NUM_CONT);
	if (numContIn < EX_SORT_DEFAULT_NUM_CONT)
		numContIn = EX_SORT_DEFAULT_NUM_CONT;
	cont = new ContainerClass[numContIn];

	res = new int[numContIn];
	inTree = new WitnessTree[numContIn];
	sortListsNum = 0;
	currSortList = 0;
	nextEmptySortList = 0;
	this->sortListsCap = gSettings->getIntegerValue("INITIAL_SORT_LISTS_NUM",INITIAL_SORT_LISTS_NUM_DEFAULT);
	this->input = input;
	this->dataMng = dataMng;
	this->orderSc = order;
	this->sortByWhat = SORT_BY_SCORE;
	this->volumeID = dataMng->getVolumeID();
		this->fileID = fileID;
	this->startID = startID;
	this->numWrites = numWrites;
	this->sortArray = NULL;
	this->sortLists = NULL;
	resultBuffer = new WitnessTree;

	buildSortArray();

	if (readInputIntoLists() == FAILURE)
		allNull = true;
	else
	{
		if (inMemSort)
			allNull = !readTreesFromContainers();
		else
		{
			if (sortTheLists() == FAILURE)
				allNull = true;
			else
			{
				//here we have 2 lists at locations 0 and 1 in the sortLists array
				sortLists[0].StartScan();
				sortLists[1].StartScan();
				res[0] = sortLists[0].GetNext(&cont[0]);
				res[1] = sortLists[1].GetNext(&cont[1]);
				
				if (res[0] == SUCCESS)
					res[0] = readWitnessTreeFromContainer(&inTree[0], &cont[0]);
				if (res[1] == SUCCESS)
					res[1] = readWitnessTreeFromContainer(&inTree[1], &cont[1]); 
				if (res[0] == FAILURE && res[1] == FAILURE)
					allNull = true;
				else
					allNull = false;
				numContIn = 2;
			}
		}
	}
}

ExternalSortIterator::~ExternalSortIterator()
{
	delete resultBuffer;

	if (sortArray) delete [] sortArray;
	if (input) delete input;
	delete [] cont;

	delete [] res;
	delete [] inTree;
	if (this->sortByWhat == SORT_BY_START_KEY)
	{
		if (orderSK) delete [] orderSK;
		if (nre) delete [] nre;
		if (whereEmptyGoes) delete [] whereEmptyGoes;
	}

	if (sortLists)
		delete [] sortLists;
	if (fileCreated)
	{
	//	cout<<"destroy file ID: "<<fileID<<endl;
		rc = ss_m::destroy_file(volumeID, fileID, true, numWrites);
		if (rc) 
		{
			strstream msg;
			msg<<rc<<'\0';
			globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"Evaluator",__FILE__,msg.rdbuf()->str());
			return;				
		}
	}
}


void ExternalSortIterator::next(WitnessTree *&node)
{	
#ifdef EVAL_TIME_OUT
	clock_t currTime = clock();
	double queryDuration = (double)(currTime - gQueryStartTime) / CLOCKS_PER_SEC;
	if (queryDuration >= gTimeOutAfter)
	{
		globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"Evaluator",__FILE__,"Query Timed Out.");
		node = NULL;
		return;
	}
#endif
	if (mergeAndOutputContainers() == SUCCESS)
	{
		node = resultBuffer;
		return;
	}
	node = NULL;
}

int ExternalSortIterator::readInputIntoLists()
{
	input->next(inTuple);
	if (inTuple)
		treeNodeSz = inTuple->isSimple()? sizeof(ListNode):sizeof(ComplexListNode);
	else
		return FAILURE;

	int numEntries;

	while (inTuple)
	{
		for (int i=0; i<numContIn; i++)
		{
			numEntries = 0;

			int potSize = 0;
			int contCap = cont[i].GetSize();
			while (inTuple && potSize + treeSize(inTuple) < contCap)
			{
				potSize += treeSize(inTuple);
				if (!inTuple->isSimple())
					sortArray[numEntries].switchToComplex(dataMng);
				sortArray[numEntries].copyTree(inTuple);
				numEntries++;
				input->next(inTuple);
			}

			if (!inTuple)
			{
				if (globalErrorInfo.doWeHaveAProblem())
					return FAILURE;
			}
			if (numEntries == 0 && inTuple)
			{
				strstream msg;
				int maxSz = 0;
				while (inTuple)
				{
					int currSz = treeSize(inTuple);
					if (currSz > maxSz)
						maxSz = currSz;
					input->next(inTuple);
				}
				maxSz++;
				msg<<"A container cannot accomodate 1 witness tree... increase CONTAINER_SIZE parameter in settings file "<<
					"to at least "<<maxSz<<"..."<<'\0';
				globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"Evaluator",__FILE__,msg.rdbuf()->str());
				return FAILURE; 
			}

			if (sortTheArray(numEntries) == FAILURE)
				return FAILURE;
			writeArrayIntoContainer(&cont[i], numEntries);
			if (!inTuple)
				break;
#ifdef EVAL_TIME_OUT
	clock_t currTime = clock();
	double queryDuration = (double)(currTime - gQueryStartTime) / CLOCKS_PER_SEC;
	if (queryDuration >= gTimeOutAfter)
	{
		globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"Evaluator",__FILE__,"Query Timed Out.");
		return FAILURE;
	}
#endif
		}
		if (!inTuple && numCont <= numContIn)
			inMemSort = true;
		else
		{
			if (mergeContainers() == FAILURE)
				return FAILURE;
		}
	}
	
	if (globalErrorInfo.doWeHaveAProblem())
		return FAILURE;
	
	delete input;
	input = NULL;
	delete [] sortArray;
	sortArray = NULL;
	return SUCCESS;
}

int ExternalSortIterator::sortTheLists()
{
	while (sortListsNum > 2)
	{
		while (currSortList < sortListsNum)
		{
			if (mergeLists(currSortList) == FAILURE)
				return FAILURE;
			currSortList += numContIn;

		}
		sortListsNum = nextEmptySortList;
		currSortList = 0;
		nextEmptySortList = 0;
#ifdef EVAL_TIME_OUT
	clock_t currTime = clock();
	double queryDuration = (double)(currTime - gQueryStartTime) / CLOCKS_PER_SEC;
	if (queryDuration >= gTimeOutAfter)
	{
		globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"Evaluator",__FILE__,"Query Timed Out.");
		return FAILURE;
	}
#endif
	}
	return SUCCESS;
}

int ExternalSortIterator::mergeLists(int which)
{
	if (which == sortListsNum-1)
		//we have odd number of lists
	{
		sortLists[nextEmptySortList] = sortLists[which];
		nextEmptySortList++;
		return SUCCESS;
	}

	allNull = true;
	for (int i=which; i<which+numContIn; i++)
	{
		if (i >= sortListsNum)
		{
			res[i-which] = FAILURE;
			continue;
		}
		if (sortLists[i].IsEmpty())
		{
			res[i-which] = FAILURE;
			continue;
		}
		
		sortLists[i].StartScan();
		res[i-which] = sortLists[i].GetNext(&cont[i-which]);
		if (res[i-which] == SUCCESS)
		{
			res[i-which] = readWitnessTreeFromContainer(&inTree[i-which], &cont[i-which]);
			allNull = false;
		}
	}
	
	ShoreList tmpList;
	tmpList.SetFileID(fileID);
	tmpList.SetVolumeID(volumeID);

	while (!allNull)
	{
		int first = whoseFirst();
		if (first == FAILURE)
			return FAILURE;
		
		if (writeWitnessTreeIntoContainer(&inTree[first],&outCont) == FAILURE)
		{
			if (writeContainerToList(&outCont,&tmpList) == FAILURE)
				return FAILURE;
			writeWitnessTreeIntoContainer(&inTree[first],&outCont);
		}
		res[first] = readWitnessTreeFromContainer(&inTree[first], &cont[first]);
		if (res[first] == FAILURE)
		{
			res[first] = sortLists[which+first].GetNext(&cont[first]);
			if (res[first] == SUCCESS)
				res[first] = readWitnessTreeFromContainer(&inTree[first], &cont[first]);
		}

		allNull = !atLeastOneSuccess();
	}

	if (!outCont.IsEmpty())
	{
		if (writeContainerToList(&outCont,&tmpList) == FAILURE)
			return FAILURE;
	}
	sortLists[nextEmptySortList] = tmpList;
	nextEmptySortList++;
	return SUCCESS;
}

void ExternalSortIterator::writeArrayIntoContainer(ContainerClass *cont, int numEntries)
{
	cont->Initialize();
	if (numEntries > 0)
		numCont++;

	for (int i=0; i < numEntries; i++)
		writeWitnessTreeIntoContainer(&sortArray[i],cont);

}

int ExternalSortIterator::sortTheArray(int numEntries)
{
	if (numEntries == 0)
		return SUCCESS;

	EvalQuickSort s;
	if (this->sortByWhat == SORT_BY_START_KEY)
	{
		gNumX = this->num;
		gOrderSKX = this->orderSK;
		gNREX = this->nre;
		if (gNumX == 0)
		{
			gNumX = orderSK[0];
			gNREX = NULL;
		}
		gWhereEmptyGoesX = this->whereEmptyGoes;
		
	/*	if (sortArray[0].isSimple())
			qsort(sortArray,numEntries,sizeof(WitnessTree),compareTreesXSK);
		else
			qsort(sortArray,numEntries,sizeof(WitnessTree),compareTreesXSKComplex);*/
		int res;
		if (sortArray[0].isSimple())
			res = s.quickSort(sortArray,0,numEntries-1,compareTreesXSK);
		else
			res = s.quickSort(sortArray,0,numEntries-1,compareTreesXSKComplex);
		if (res == FAILURE)
			return FAILURE;
	}
	else
	{
		gOrderScX = this->orderSc; 
		//qsort(sortArray,numEntries,sizeof(WitnessTree),compareTreesXScore);
		if (s.quickSort(sortArray,0,numEntries-1,compareTreesXScore) == FAILURE)
			return FAILURE;
	}
	return SUCCESS;
}


bool ExternalSortIterator::readTreesFromContainers()
{
	bool atLeastOne = false;
	for (int i=0; i<numContIn; i++)
	{
		res[i] = readWitnessTreeFromContainer(&inTree[i], &cont[i]);
		if (res[i] == SUCCESS)
			atLeastOne = true;
	}
	return atLeastOne;
}

bool ExternalSortIterator::atLeastOneSuccess()
{
	for (int i=0; i<numContIn; i++)
		if (res[i] == SUCCESS)
			return true;
	return false;
}

int ExternalSortIterator::mergeContainers()
{

	if (sortListsNum == 0)
		sortLists = new ShoreList[sortListsCap];
	else if (sortListsNum == sortListsCap)
	{
		sortListsCap *= 2;
		ShoreList *tmp = sortLists;
		sortLists = new ShoreList[sortListsCap];
		memcpy(sortLists,tmp,sortListsNum*sizeof(ShoreList));
		delete [] tmp;
	}


	bool atLeastOne  = readTreesFromContainers();

	while (atLeastOne)
	{
		int first = whoseFirst();

		if (first == FAILURE)
			return FAILURE;

		if (writeWitnessTreeIntoContainer(&inTree[first],&outCont) == FAILURE)
		{
			if (writeContainerToList(&outCont,&sortLists[sortListsNum]) == FAILURE)
				return FAILURE;
			writeWitnessTreeIntoContainer(&inTree[first],&outCont);
		}
		res[first] = readWitnessTreeFromContainer(&inTree[first],&cont[first]);
		atLeastOne = atLeastOneSuccess();
#ifdef EVAL_TIME_OUT
	clock_t currTime = clock();
	double queryDuration = (double)(currTime - gQueryStartTime) / CLOCKS_PER_SEC;
	if (queryDuration >= gTimeOutAfter)
	{
		globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"Evaluator",__FILE__,"Query Timed Out.");
		return FAILURE;
	}
#endif
	}

	if (!outCont.IsEmpty())
	{
		if (writeContainerToList(&outCont,&sortLists[sortListsNum]) == FAILURE)
			return FAILURE;
	}
	sortListsNum++;
	return SUCCESS;
}



int ExternalSortIterator::mergeAndOutputContainers()
{
	if (!allNull)
	{
		int first = whoseFirst();
		if (first == FAILURE)
			return FAILURE;
		
		resultBuffer->copyTree(&inTree[first]);
		res[first] = readWitnessTreeFromContainer(&inTree[first], &cont[first]);
		if (!inMemSort && res[first] == FAILURE)
		{
			res[first] = sortLists[first].GetNext(&cont[first]);
			if (res[first] == SUCCESS)
				res[first] = readWitnessTreeFromContainer(&inTree[first], &cont[first]);
		}
		allNull = !atLeastOneSuccess();
		return SUCCESS;
	}
	return FAILURE;
}

int ExternalSortIterator::whoseFirst()
{
	int firstTree = 0;
	for (int j=0; j<numContIn; j++)
		if (res[j] == SUCCESS)
		{
			firstTree = j;
			break;
		}
	if (j == numContIn)
		return FAILURE;

	if (this->sortByWhat == SORT_BY_START_KEY)
	{	
		if (num == 0)
		{
			for (int currTree=firstTree+1; currTree<numContIn; currTree++)
			{
				if (res[currTree] == FAILURE) continue;
				int n = inTree[currTree].length() < inTree[firstTree].length()? inTree[currTree].length() : inTree[firstTree].length();
				for (int i=0; i<n; i++)
				{
					KeyType firstSK = inTree[firstTree].isSimple()? 
						((ListNode *)inTree[firstTree].getNodeByIndex(i))->GetStartPos():
						((ComplexListNode *)inTree[firstTree].getNodeByIndex(i))->GetStartPos();
					KeyType currSK = inTree[currTree].isSimple()? 
						((ListNode *) inTree[currTree].getNodeByIndex(i))->GetStartPos():
						((ComplexListNode *)inTree[currTree].getNodeByIndex(i))->GetStartPos();
					
					if (firstSK == currSK)
						continue;
					else
					{
						if (orderSK[0] == ASCENDING)
						{
							if (currSK < firstSK)
								firstTree = currTree;
							break;
						}
						else
						{
							if (currSK > firstSK)
								firstTree = currTree;
							break;
						}
					}
				}
				if (i == n && inTree[currTree].length() != inTree[firstTree].length())
				{
					if (orderSK[0] == ASCENDING)
					{
						if (inTree[currTree].length() < inTree[firstTree].length())
							firstTree = currTree;
					}
					else
					{
						if (inTree[currTree].length() > inTree[firstTree].length())
							firstTree = currTree;
					}
				}
			}
		}
		else
		{
			for (int currTree=firstTree+1; currTree<numContIn; currTree++)
			{
				if (res[currTree] == FAILURE) continue;
				for (int i=0; i<num; i++)
				{
					KeyType firstSK = inTree[firstTree].isSimple()? 
						((ListNode *)inTree[firstTree].findNodeNRE(nre[i]))->GetStartPos():
						((ComplexListNode *)inTree[firstTree].findNodeNRE(nre[i]))->GetStartPos();
					KeyType currSK = inTree[currTree].isSimple()? 
						((ListNode *) inTree[currTree].findNodeNRE(nre[i]))->GetStartPos():
						((ComplexListNode *)inTree[currTree].findNodeNRE(nre[i]))->GetStartPos();
					
					if (firstSK == currSK)
						continue;
					else
					{
						if (orderSK[0] == ASCENDING)
						{
							if (currSK < firstSK)
								firstTree = currTree;
							break;
						}
						else
						{
							if (currSK > firstSK)
								firstTree = currTree;
							break;
						}
					}
				}
			}
		}
	}
	else
	{
		if (this->orderSc == ASCENDING)
		{
			for (int currTree=firstTree+1; currTree<numContIn; currTree++)
			{
				if (res[currTree] == FAILURE) continue;
				if (inTree[firstTree].getScore() == inTree[currTree].getScore())
					continue;
				else if (inTree[firstTree].getScore() > inTree[currTree].getScore())
					firstTree = currTree;

			}
		}
		else
		{
			for (int currTree=firstTree+1; currTree<numContIn; currTree++)
			{
				if (res[currTree] == FAILURE) continue;
				if (inTree[firstTree].getScore() == inTree[currTree].getScore())
					continue;
				else if (inTree[firstTree].getScore() < inTree[currTree].getScore())
					firstTree = currTree;
			}
		}
	}
	return firstTree;
}





int ExternalSortIterator::writeContainerToList(ContainerClass *cont, ShoreList *list)
{
	if (list->IsEmpty())
	{
		//first write to list
		serial_t currRecID = startID;
		if (startID.increment(1) == true)
			//overflow of shore logical ids
		{
			globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"Evaluator",__FILE__,"Shore Logical ID overflow.");
			return FAILURE;
		}
		if (SBJoinAncsStackNode::WriteBufferToList(cont,list,fileID,volumeID,currRecID,startID) == FAILURE)
			return FAILURE;
		if (startID.increment(1) == true)
			//overflow of shore logical ids
		{
			globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"Evaluator",__FILE__,"Shore Logical ID overflow.");
			return FAILURE;
		}
	}
	else
	{
		if (SBJoinAncsStackNode::WriteBufferToList(cont,list,startID) == FAILURE)
			return FAILURE;
		if (startID.increment(1) == true)
			//overflow of shore logical ids
		{
			globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"Evaluator",__FILE__,"Shore Logical ID overflow.");
			return FAILURE;
		}
	}
	//numCont++;
	cont->Initialize();
	return SUCCESS;
}

int ExternalSortIterator::treeSize(WitnessTree *tree)
{
	return sizeof(double) + sizeof(int) + (treeNodeSz * tree->length());
}


int ExternalSortIterator::writeWitnessTreeIntoContainer(WitnessTree *tree, ContainerClass *cont)
{	
	int size = treeSize(tree);

	if (cont->EnoughSpace(size))
	{
		double sc = tree->getScore();
		int treeSz = tree->length();
		cont->AddData((char *)&sc,sizeof(double));
		cont->AddData((char *)&treeSz,sizeof(int));
		cont->AddData((char *)tree->getBuffer(),treeNodeSz*tree->length());
		return SUCCESS;
	}
	else
		return FAILURE;
}

int ExternalSortIterator::readWitnessTreeFromContainer(WitnessTree *tree, ContainerClass *cont)
{
	double sc;
	if (cont->GetNext(sizeof(double),(char *)&sc) == FAILURE)
		return FAILURE;

	tree->initialize();
	tree->setScore(sc);

	int treeSz;
	cont->GetNext(sizeof(int),(char *)&treeSz);

	if (treeNodeSz == sizeof(ListNode))
		tree->appendList((ListNode *)cont->GetNextPtr(treeSz*treeNodeSz),treeSz);
	else
		tree->appendList((ComplexListNode *)cont->GetNextPtr(treeSz*treeNodeSz),dataMng,treeSz);

	return SUCCESS;
}

int ExternalSortIterator::createFileAndID()
{
	cout<<"create file for nres: "<<this->nre[0]<<endl;
	rc = ss_m::create_file(volumeID, fileID,ss_m::t_regular);
	if (rc) 
	{
		strstream msg;
		msg<<rc<<'\0';
		globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"Evaluator",__FILE__,msg.rdbuf()->str());
		return FAILURE;				
	}
	fileCreated = true;
	int maxIDs = gSettings->getIntegerValue("MAX_ID_PER_FILE_EXTERNAL_SORT",1000000);
	rc = ss_m::create_id(volumeID,maxIDs,startID);

	if (rc) 
	{
		strstream msg;
		msg<<rc<<'\0';
		globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"Evaluator",__FILE__,msg.rdbuf()->str());	
		return FAILURE;				
	}
	numWrites = maxIDs;
	return SUCCESS;
}

void ExternalSortIterator::buildSortArray()
{
	int witTreeMinSz = sizeof(int) + sizeof(double) + sizeof(ListNode);
	int potSz = (int)ceil((double)(cont[0].GetSize() / witTreeMinSz));
	sortArray = new WitnessTree[potSz];
}
