/*
COPYRIGHT  � 2000-2004 
THE REGENTS OF THE UNIVERSITY OF MICHIGAN
ALL RIGHTS RESERVED

PERMISSION IS GRANTED TO USE, COPY, CREATE DERIVATIVE WORKS AND REDISTRIBUTE THIS SOFTWARE AND SUCH DERIVATIVE WORKS FOR 
NONCOMMERCIAL EDUCATION AND RESEARCH PURPOSES, SO LONG AS NO FEE IS CHARGED, AND SO LONG AS THE COPYRIGHT NOTICE ABOVE, 
THIS GRANT OF PERMISSION, AND THE DISCLAIMER BELOW APPEAR IN ALL COPIES MADE; AND SO LONG AS THE NAME OF THE UNIVERSITY 
OF MICHIGAN IS NOT USED IN ANY ADVERTISING OR PUBLICITY PERTAINING TO THE USE OR DISTRIBUTION OF THIS SOFTWARE WITHOUT 
SPECIFIC, WRITTEN PRIOR AUTHORIZATION.

THIS SOFTWARE IS PROVIDED AS IS, WITHOUT REPRESENTATION FROM THE UNIVERSITY OF MICHIGAN AS TO ITS FITNESS FOR ANY PURPOSE, 
AND WITHOUT WARRANTY BY THE UNIVERSITY OF MICHIGAN OF ANY KIND, EITHER EXPRESS OR IMPLIED, INCLUDING WITHOUT LIMITATION THE 
IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE. THE REGENTS OF THE UNIVERSITY OF MICHIGAN SHALL 
NOT BE LIABLE FOR ANY DAMAGES, INCLUDING SPECIAL, INDIRECT, INCIDENTAL, OR CONSEQUENTIAL DAMAGES, WITH RESPECT TO ANY CLAIM 
ARISING OUT OF OR IN CONNECTION WITH THE USE OF THE SOFTWARE, EVEN IF IT HAS BEEN OR IS HEREAFTER ADVISED OF THE POSSIBILITY 
OF SUCH DAMAGES.
*/


#ifndef __navigationalGetrelative_h
#define __navigationalGetrelative_h

#include "../Evaluator/EvaluatorClass.h"

//getting one node only
#define N_GET_ONE_ANCS					0
#define N_GET_ONE_CHILD					2

//getting all nodes and outputting them one by one (like a struc join)
#define N_GET_ALL_ANCS_ONEBYONE			3
#define N_GET_ALL_DESC_ONEBYONE			4
#define N_GET_ALL_CHILDREN_ONEBYONE		5

//getting all nodes and outputting them all at once
#define N_GET_ALL_ANCS_TOGETHER			6
#define N_GET_ALL_DESC_TOGETHER			7
#define N_GET_ALL_CHILDREN_TOGETHER		8

#define N_GET_DESC_TEXT					9
#define N_GET_CHILD_TEXT				10
#define N_GET_ATTR						11
#define N_GET_DEPTH						12

#define N_GET_ALL_ANCS_ONEBYONE_INCL	13
#define N_GET_ALL_DESC_ONEBYONE_INCL	14
#define N_GET_ALL_CHILDREN_ONEBYONE_INCL	15

/**
* An access method that gets a relative of a node navigationally
* @see IteratorClass
* @see EvaluatorClass
* @see WitnessTree
* @author Shurug Al-Khalifa 
* @version 1.0
*/
class NavigationalGetRelative : public IteratorClass
{
public:
	/**
	Constructor
	initializes the variables. 
	@param input is the iterator that this iterator gets its input trees from.
	@param index is the index in the input trees of the node you wish to get its relative.
	@param relation what do you want to get. it is one of the following:
			N_GET_ONE_ANCS: get a specific ancs that is "num" levels up from node at index.
			N_GET_ONE_CHILD: get a specific child that is number "num" of index node's children.
			N_GET_ALL_ANCS_ONEBYONE: get all ancestors til the root of the document and output them
					with the tree one at a time (like a atruct join).
			N_GET_ALL_DESC_ONEBYONE: get all descendants and output them
					with the tree one at a time (like a atruct join).	
			N_GET_ALL_CHILDREN_ONEBYONE: get all children of node at index and output them
					with the tree one at a time (like a atruct join).
			N_GET_ALL_ANCS_TOGETHER: get all ancestors til the root of the document and output them
					all at once with the tree.
			N_GET_ALL_DESC_TOGETHER: get all descendants of node at index and output them
					all at once with the tree.		
			N_GET_ALL_CHILDREN_TOGETHER: get all children of node at index and output them
					all at once with the tree.	
			N_GET_DESC_TEXT:get all text node descendants of node at index and output them
					all at once with the tree.						
			N_GET_CHILD_TEXT:get all text node children of node at index and output them
					all at once with the tree.				
			N_GET_ATTR: get attribute node of node at index and output it with the tree.
			N_GET_DEPTH: get depth of node at index.					
	@param num is either levels up (in case of ancs) or child number (in case of child)
			 in the following cases N_GET_ONE_ANCS and N_GET_ONE_CHILD	
	@param dataMng an instance of the data manager.
	**/
	NavigationalGetRelative(IteratorClass *input, NREType nre, int relation, int num, NREType assignedNRE,
		DataMng *dataMng);

	/**
	Destructor
	frees the output buffer and so.
	**/
	~NavigationalGetRelative();

	/**
	Access Method
	gets the next output tree from this iterator.
	@param node is a pointer that well be set to the output buffer or NULL (indicating that
	there are no more results).
	**/
	void next(WitnessTree *&node);

private:

	int getOneAncs();
	int getOneChild();

	int getAllAncsOneByOne();
	int getAllDescOneByOne();
	int getAllChildrenOneByOne();

	int getAllAncsTogether();
	int getAllDescTogether();
	int getAllChildrenTogether();

	int getDepth();
	int getDescText();
	int getChildText();
	int getAttr();
	void getNextInput();


	IteratorClass *input;
	NREType nre;
	int relation;
	int num;
	int index;
	char fileIndex;


	DataMng *dataMng;
	WitnessTree *resultBuffer;
	WitnessTree *inTuple;
	KeyType lastSK;
	FileIDType fileid;
	int childDescCursor;
	int childDescLastIndex;

	NREType assignedNRE;
	bool inclusive;
	bool firstTime;
};

#endif