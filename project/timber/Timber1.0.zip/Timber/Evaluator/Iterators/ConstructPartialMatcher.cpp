#include "ConstructPartialMatcher.h"
#include "ShoreFile.h"
ConstructPartialMatcher::ConstructPartialMatcher(IteratorClass *input, ExecArrayType *pattern, int *relation,
												 int *getWhat, char **attrNames, int rootIndex,
												 TransactionIDType tid,FileIDType fid,DataMng *dataMng)
{
	this->input = input;
	this->pattern = pattern;
	this->dataMng = dataMng;
	this->fid = fid;
	this->tid = tid ;
	this->relation = relation;
	this->rootIndex = rootIndex;
	this->getWhat = getWhat;
	this->attrNames = attrNames;

	this->cascadeDeletes = false;

	res = new WitnessTree *[pattern->GetSize() -1];
	input->next(inTuple);
	resultBuffer = new WitnessTree(LIST_NODE_WITH_DATA);
}
	
ConstructPartialMatcher::~ConstructPartialMatcher()
{
	delete resultBuffer;
	if (attrNames)
	{
		for (int i=0; i<pattern->GetSize(); i++)
		{
			if (attrNames[i])
				delete [] attrNames[i];
		}
		delete [] attrNames;
	}
	if (pattern)
		delete pattern;
	if (relation)
		delete [] relation;
	if (getWhat)
		delete [] getWhat;

	if (this->cascadeDeletes)
		delete input;
	delete [] res;
}
	
void ConstructPartialMatcher::next(WitnessTree *&node)
{
	while (inTuple)
	{
		resultBuffer->initialize();
		KeyType sk = inTuple->isSimple()? ((ListNode *)inTuple->findNode(rootIndex))->GetStartPos() :
										((ComplexListNode *)inTuple->findNode(rootIndex))->GetStartPos();
		KeyType ek = inTuple->isSimple()? ((ListNode *)inTuple->findNode(rootIndex))->GetEndPos() :
										((ComplexListNode *)inTuple->findNode(rootIndex))->GetEndPos();
		int lev = inTuple->isSimple()? ((ListNode *)inTuple->findNode(rootIndex))->GetLevel() :
										((ComplexListNode *)inTuple->findNode(rootIndex))->GetLevel();
		getMatches(0,sk,ek,lev);
		input->next(inTuple);
		if (resultBuffer->length() > 0)
		{
			node = resultBuffer;
			return;
		}
	}
	node = NULL;
}

void ConstructPartialMatcher::getMatches(int index, KeyType sk, KeyType ek, int lev, int localLev)
{	
	if (index != 0)
	{
		if (pattern->GetEntryByIndex(index)->GetIterator() == NULL)
		{
			QueryEvaluationTreeIndexAccessNode *newNode = 
				(QueryEvaluationTreeIndexAccessNode *)pattern->GetEntryByIndex(index)->GetQueryEvalNode();
			if (newNode->isFromFile())
			{
				pattern->GetEntryByIndex(index)->SetIterator(
					new ShoreFile(&(dataMng->getVolumeID()),&(newNode->getFid())));
			}
			else
			{		
				if (newNode->getShoreOrGist() == SHORE_INDEX)
				{
	//				pattern->GetEntryByIndex(index)->SetIterator(
	//					indexMng->openIndex(newNode->getIndexName(),newNode->getValue()));
				}
				else
				{
					
					//	memcpy(&val,newNode->getValue(),sizeof(int));
					bt_query_t *pred;
					
					if (newNode->getIndexType() == INT_INDEX)
					{
						int val;
						val = atoi((char *)newNode->getValue());
						if (newNode->getValue2() != NULL)
						{
							int val2 = atoi((char *)newNode->getValue2());
							pred = new bt_query_t(bt_query_t::bt_betw, new int(val), new int(val2));
						}
						else
							pred = new bt_query_t(bt_query_t::bt_eq, new int(val), NULL);
					}
					else if (newNode->getIndexType() == FLOAT_INDEX)
					{
						float val;
						val = (float) atof((char *)newNode->getValue());
						if (newNode->getValue2() != NULL)
						{
							float val2 = (float) atof((char *)newNode->getValue2());
							pred = new bt_query_t(bt_query_t::bt_betw, new float(val), new float(val2));
						}
						else
							pred = new bt_query_t(bt_query_t::bt_eq, new float(val), NULL);
					}
					else
					{
						char *val = new char[strlen((char *)newNode->getValue())+1];
						strcpy(val,(char *)newNode->getValue());
						if (newNode->getValue2() != NULL)
						{
							char *val2 = new char[strlen((char *)newNode->getValue2())+1];
							strcpy(val2,(char *)newNode->getValue2());
							pred = new bt_query_t(bt_query_t::bt_betw, val, val2);
						}
						else
							pred = new bt_query_t(bt_query_t::bt_eq, val, NULL);
					}
#ifndef _TEXTFILES
				pattern->GetEntryByIndex(index)->SetIterator(	
				new GistIndexAccess(newNode->getIndexName(),pred,newNode->getIndexType()));
#else
					delete pred;
					pattern->GetEntryByIndex(index)->SetIterator(
				new TextFileReader(newNode->getIndexName(),newNode->getValue(),newNode->getValue2(),newNode->getIndexType()));
#endif
				}
			}
			pattern->GetEntryByIndex(index)->GetIterator()->next(res[index-1]);
		}
		
		int child = pattern->getChildIndex(index);
		ComplexListNode n;
		n.SetDummy(true);
		n.SetDummyName("<subroot>");
		n.SetLocalLevel(localLev);
		localLev++;
		resultBuffer->appendList(&n,1);
		while (res[index-1])
		{
			KeyType startKey = ((ListNode *)res[index-1]->findNode(0))->GetStartPos();
			KeyType endKey = ((ListNode *)res[index-1]->findNode(0))->GetEndPos();
			int level = ((ListNode *)res[index-1]->findNode(0))->GetLevel();
			if (sk < startKey && ek > endKey)
			{
				if (relation[index] == PARENT_CHILD)
				{
					if (level == (lev+1))
					{
						if (child == -1)
						{
							resultBuffer->appendList((ListNode *)res[index-1]->getBuffer(),1);
							((ComplexListNode *)resultBuffer->findNode(resultBuffer->length() -1))->SetLocalLevel(localLev);
							EvaluatorClass::GetData(((ComplexListNode *)resultBuffer->findNode(resultBuffer->length() -1)),dataMng,fid,tid);
							switch (getWhat[index])
							{
							case CPM_GET_ITSELF:
								{
								}
								break;
							case CPM_GET_SUBTREE:
								{
									int t = resultBuffer->length() -1;
									EvaluatorClass::GetAllDesc(resultBuffer,t,NULL,dataMng,fid,tid,localLev+1);

								}
								break;
							case CPM_GET_TEXT:
								{
									if (EvaluatorClass::GetText(resultBuffer,resultBuffer->length() -1,dataMng,fid,tid,localLev+1)
											== FAILURE)
										resultBuffer->deleteNode(resultBuffer->length() -1);
								}
								break;
							case CPM_GET_ATTR:
								{
									if (EvaluatorClass::GetAttributes(resultBuffer,resultBuffer->length() -1,dataMng,fid,tid,localLev+1) != FAILURE)
									{
										Value *val1 = ((DM_AttributeNode *)((ComplexListNode *)(resultBuffer)->findNode(resultBuffer->length() -1))->GetData())->getAttr(attrNames[index]);
										if (val1)
										{
											ComplexListNode n;
											n.SetDummy(true);
											n.SetDummyName(val1->getStrValue());
											resultBuffer->deleteNode(resultBuffer->length() -1);
											resultBuffer->appendList(&n,1);
										}
										else
										{
											resultBuffer->deleteNode(resultBuffer->length() -1);
										}
									}
								}
								break;
							}
						}
						else
						{
							int child2 = pattern->getChildIndex(index);
							while (child2 != -1)
							{
								getMatches(child2,startKey,endKey,level,localLev+1);
								child2 = pattern->getSiblingIndex(child2);
							}	
						}
					}
				}
				else
				{
					if (child == -1)
					{
						resultBuffer->appendList((ListNode *)res[index-1]->getBuffer(),1);
						((ComplexListNode *)resultBuffer->findNode(resultBuffer->length() -1))->SetLocalLevel(localLev);
						EvaluatorClass::GetData(((ComplexListNode *)resultBuffer->findNode(resultBuffer->length() -1)),dataMng,fid,tid);
						switch (getWhat[index])
						{
						case CPM_GET_SUBTREE:
							{
								int t = resultBuffer->length() -1;
								EvaluatorClass::GetAllDesc(resultBuffer,t,NULL,dataMng,fid,tid,localLev+1);
								
							}
							break;
						case CPM_GET_TEXT:
							{
								EvaluatorClass::GetText(resultBuffer,resultBuffer->length() -1,dataMng,fid,tid,localLev+1);
							}
							break;
						case CPM_GET_ATTR:
							{
								if (EvaluatorClass::GetAttributes(resultBuffer,resultBuffer->length() -1,dataMng,fid,tid,localLev+1) != FAILURE)
								{
										Value *val1 = ((DM_AttributeNode *)((ComplexListNode *)(resultBuffer)->findNode(resultBuffer->length() -1))->GetData())->getAttr(attrNames[index]);
										if (val1)
										{
											ComplexListNode n;
											n.SetDummy(true);
											n.SetDummyName(val1->getStrValue());
											resultBuffer->deleteNode(resultBuffer->length() -1);
											resultBuffer->appendList(&n,1);
										}
										else
										{
											resultBuffer->deleteNode(resultBuffer->length() -1);
										}
								}

							}
							break;
						case CPM_GET_ITSELF:
							break;
						}
					}
					else
					{
						int child2 = pattern->getChildIndex(index);
						while (child2 != -1)
						{
							getMatches(child2,startKey,endKey,level,localLev+1);
							child2 = pattern->getSiblingIndex(child2);
						}	
					}
				}
			}
      else if (ek < startKey)
        break;
			pattern->GetEntryByIndex(index)->GetIterator()->next(res[index-1]);
		}
	//	pattern->GetEntryByIndex(index)->SetIterator(NULL);
	}
	else
	{
		ComplexListNode n;
		n.SetDummy(true);
		n.SetDummyName("<root>");
		n.SetLocalLevel(localLev);
		localLev++;
		resultBuffer->appendList(&n,1);
		int child = pattern->getChildIndex(index);
		while (child != -1)
		{
			getMatches(child, sk, ek, lev, localLev);
			child = pattern->getSiblingIndex(child);
		}	
	}

}