/*
COPYRIGHT  � 2000-2004 
THE REGENTS OF THE UNIVERSITY OF MICHIGAN
ALL RIGHTS RESERVED

PERMISSION IS GRANTED TO USE, COPY, CREATE DERIVATIVE WORKS AND REDISTRIBUTE THIS SOFTWARE AND SUCH DERIVATIVE WORKS FOR 
NONCOMMERCIAL EDUCATION AND RESEARCH PURPOSES, SO LONG AS NO FEE IS CHARGED, AND SO LONG AS THE COPYRIGHT NOTICE ABOVE, 
THIS GRANT OF PERMISSION, AND THE DISCLAIMER BELOW APPEAR IN ALL COPIES MADE; AND SO LONG AS THE NAME OF THE UNIVERSITY 
OF MICHIGAN IS NOT USED IN ANY ADVERTISING OR PUBLICITY PERTAINING TO THE USE OR DISTRIBUTION OF THIS SOFTWARE WITHOUT 
SPECIFIC, WRITTEN PRIOR AUTHORIZATION.

THIS SOFTWARE IS PROVIDED AS IS, WITHOUT REPRESENTATION FROM THE UNIVERSITY OF MICHIGAN AS TO ITS FITNESS FOR ANY PURPOSE, 
AND WITHOUT WARRANTY BY THE UNIVERSITY OF MICHIGAN OF ANY KIND, EITHER EXPRESS OR IMPLIED, INCLUDING WITHOUT LIMITATION THE 
IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE. THE REGENTS OF THE UNIVERSITY OF MICHIGAN SHALL 
NOT BE LIABLE FOR ANY DAMAGES, INCLUDING SPECIAL, INDIRECT, INCIDENTAL, OR CONSEQUENTIAL DAMAGES, WITH RESPECT TO ANY CLAIM 
ARISING OUT OF OR IN CONNECTION WITH THE USE OF THE SOFTWARE, EVEN IF IT HAS BEEN OR IS HEREAFTER ADVISED OF THE POSSIBILITY 
OF SUCH DAMAGES.
*/

#include "FileWriterIterator.h"
#include "float.h"

FileWriterIterator::FileWriterIterator(IteratorClass *input, const char *fileName, DataMng *dataMng)
{
	output = fopen(fileName,"w");
	count = 0;
	this->input = input;
	resultBuffer = new WitnessTree;
	//this->fileName = new char[strlen(fileName)+1];
	//strcpy(this->fileName, fileName);
	this->dataMng = dataMng;
}


FileWriterIterator::~FileWriterIterator()
{
	delete resultBuffer;
	fclose(output);
	//delete [] fileName;
	delete input;
}

void FileWriterIterator::next(WitnessTree *&node)
{
#ifdef EVAL_TIME_OUT
	clock_t currTime = clock();
	double queryDuration = (double)(currTime - gQueryStartTime) / CLOCKS_PER_SEC;
	if (queryDuration >= gTimeOutAfter)
	{
		globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"Evaluator",__FILE__,"Query Timed Out.");
		node = NULL;
		return;
	}
#endif
	if (!output)
	{
		globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"Evaluator",__FILE__,"Could not open output file.");
		node = NULL;
		return;
	}
	input->next(inTuple);

	//if no more inputs, we are done
	if (!inTuple)
	{
		node = NULL;
		return;
	}
	count++;
	if (!(inTuple->isSimple()))
	{
		//write input witness tree to result buffer
		resultBuffer->copyTree(inTuple);
		//writing to the file, number of nodes in witness tree and score of witness tree
		fprintf(output,"%d %lf\n",resultBuffer->length(),resultBuffer->getScore());

		//for each node in the witness tree, write its info
		for (int i = 0; i<resultBuffer->length(); i++)
		{
			ComplexListNode *n = (ComplexListNode *)(resultBuffer->findNode(i));

			char emptyStr[8];
			strcpy(emptyStr,"[EMPTY]");
			//write the file name along with start key, end key , level, offset, and nre to the file
			if (n->IsDummy()) {
				//fprintf(output,"d %lf %d %d %s\n",
				fprintf(output,"d %.*g %d %d %s\n",
				DBL_DIG+2,n->GetStartPos(),(int)n->getNRE(),n->GetLocalLevel(),strcmp(n->GetDummyName(),"") == 0?emptyStr:n->GetDummyName());
			}
			else
			{
				//get the file name that this node came from
				char *fileName = EvaluatorClass::getOpenFileName((int)n->getFileIndex());
				if (fileName == NULL)
				{
					globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"Evaluator",__FILE__,"File is not loaded in Timber.");
					node = NULL;
					return;
				}
				//fprintf(output,"c %s %lf %lf %d %d %d %d\n",fileName,
				fprintf(output,"c %s %.*g %.*g %d %d %d %d\n",fileName,
					DBL_DIG+2,n->GetStartPos(),DBL_DIG+2,n->GetEndPos(),n->GetLevel(),n->GetOffset(),(int)n->getNRE(),n->GetLocalLevel());
			}
		}
	}
	else
	{
		//write input witness tree to result buffer
		resultBuffer->copyTree(inTuple);
		
		//writing to the file, number of nodes in witness tree and score of witness tree
		fprintf(output,"%d %lf\n",resultBuffer->length(),resultBuffer->getScore());

		//for each node in the witness tree, write its info
		for (int i = 0; i<resultBuffer->length(); i++)
		{
			ListNode *n = (ListNode *)(resultBuffer->findNode(i));

			//get the file name that this node came from
			char *fileName = EvaluatorClass::getOpenFileName((int)n->getFileIndex());
			if (fileName == NULL)
			{
				globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"Evaluator",__FILE__,"File is not loaded in Timber.");
				node = NULL;
				return;
			}

			//write the file name along with start key, end key , level, offset, and nre to the file
			//fprintf(output,"s %s %lf %lf %d %d %d\n",fileName,
			fprintf(output,"s %s %.*g %.*g %d %d %d\n",fileName,
				DBL_DIG+2,n->GetStartPos(),DBL_DIG+2,n->GetEndPos(),n->GetLevel(),n->GetOffset(),(int)n->getNRE());
		}
	}
	node = resultBuffer;
	return;
}