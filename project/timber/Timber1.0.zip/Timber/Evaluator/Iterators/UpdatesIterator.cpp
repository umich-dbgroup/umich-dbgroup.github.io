#include "UpdatesIterator.h"

//defined in EvaluatorClass.cpp:
extern vector< pair<int, string> > gUpdatesArray;

UpdatesIterator::UpdatesIterator(IteratorClass *input, DataMng *dataMng, IndexIncrementalUpdate *indexUpdater,
								 int updateType, NREType nre, //char *indexToUpdate, 
								 char *textValue1, char *textValue2, char *textValue3, char *textValue4,
								 vector<AttributeInfo> repeated, int ind)
{

	this->updateType = updateType;
	this->dataMng = dataMng;

	this->ind = ind;
	//gNumUpdatesArray[ind] = 0;

	//AN: setInput() is currently a hack which flushes (i.e. breaks) the pipeline before any updates are performed
	//this is because we were having problems running out of logical IDs in shore, and
	//our (temporary) fix does not allow us to allocate new logical IDs (such as when an insert is performed)
	//interleaved with other iterators (e.g. structural joins)
	//this will be a large performance hit when performing updates and needs to be fixed.

#ifndef _BERKELEYDB
	if (ind == 0)
		setInput(input);
	else
		this->input = input;
#else 
    this->input = input;
#endif 

	this->indexUpdater = indexUpdater;
	
	this->nre = nre;
	this->lastElementKeyProcessed = -1;

	if (textValue1) {
		this->textValue1 = new char[strlen(textValue1)+1];
		strcpy(this->textValue1, textValue1);
	}
	else 
		this->textValue1 = NULL;

	if (textValue2) {
		this->textValue2 = new char[strlen(textValue2)+1];
		strcpy(this->textValue2, textValue2);
	}
	else
		this->textValue2 = NULL;
	
	if (textValue3) {
		this->textValue3 = new char[strlen(textValue3)+1];
		strcpy(this->textValue3, textValue3);
	}
	else
		this->textValue3 = NULL;

	if (textValue4) {
		this->textValue4 = new char[strlen(textValue4)+1];
		strcpy(this->textValue4, textValue4);
	}
	else
		this->textValue4 = NULL;

	this->repeated = repeated;

	this->input->next(inTuple);

	if (inTuple)
	{
		if (inTuple->isSimple())
			inTuple->switchToComplex(dataMng);
			//resultBuffer = new WitnessTree;
		//else
		resultBuffer = new WitnessTree(LIST_NODE_WITH_DATA, dataMng);
	}
	else
		resultBuffer = NULL;

}


UpdatesIterator::~UpdatesIterator()
{
	if (resultBuffer)
		delete resultBuffer;

	delete input;

	delete indexUpdater;

	if (textValue1)
		delete [] textValue1;

	if (textValue2)
		delete [] textValue2;

	if (textValue3)
		delete [] textValue3;

	if (textValue4)
		delete [] textValue4;

	//if (tempFileName[0] != '\0')
	//	remove(tempFileName);
}


void UpdatesIterator::next(WitnessTree *&node)
{
	//if we don't have any more input, we are done.
	if (!inTuple)
	{
		node = NULL;
		return;
	}

	//we'll just pass the input buffer through, perhaps after changes below due to updates:
	resultBuffer->copyTree(inTuple);
		
	KeyType curSK;
	//KeyType curSK = (inTuple->isSimple()? ((ListNode *)inTuple->findNode(0))->GetStartPos() :
	//	((ComplexListNode *)inTuple->findNode(0))->GetStartPos());

	FileIDType fileid;
	if (inTuple->isSimple()) {
		inTuple->switchToComplex(dataMng);
	}

	//we don't have to worry about multiple nodes with NRE=nre in the witness tree here
	//because the first parameter in the xquery update command must be a bound variable
	//and so it is guaranteed to be a singleton set.
	//if this changes in the future, then we would need to call:
	//startFindNodesNRE(nre) and then call getNextNodeNRE() inside a while loop until it returns NULL,
	//rather than just calling findNodeNRE(nre) below:
	ComplexListNode *n = (ComplexListNode*)inTuple->findNodeNRE(nre);

	//check if the node with nre is in the input tuple (witness tree)
	//if not, we have already deleted it and removed it from the witness tree
	//due to a previous update operation
	if (!n) {
		node = resultBuffer;
		input->next(inTuple);
		//if (!inTuple) {
		//	node  = NULL;
		//	return;
		//}
		return;
	}
	else {
		//we'll use nodeIndexInWitnessTree to remove nodes from the witness tree later...
		//(we don't add nodes to the witness tree because the physical plan does not specify NREs
		//for newly inserted nodes... this could/should be changed when the xquery update spec becomes more expressive)
		int nodeIndexInWitnessTree = resultBuffer->getIndexOfNRE(nre);

		if (inTuple->moreThanOneMatch(nre)) {
			ostringstream oss;
			oss << "More than one node mapped to NRE #" << nre
				<< ", the first argument to any update needs to be a bound variable (to guarantee a singleton set). "
				<< "The data was left unchanged by the update query, but indices must be rebuilt";
			globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"UpdatesIterator::next",__FILE__,oss.str().c_str());
			dataMng->abortTransaction();
			node = NULL;
			return;
		}

		curSK = n->GetStartPos();
		fileid = EvaluatorClass::getFileID(n->getFileIndex());

		if (fileid == -1) {
			node = NULL;
			return;
		}

		//writes to nodeIDMap:
		DM_DataNode *dataNode = n->GetData();

		if (dataNode == NULL) {

			//we're assuming that the node has already been deleted by a previous update operation here
			//(but hasn't been removed from the witness tree)
			//this is possible if 2 different variables in the xquery are bound to the same path.
			//(ideally, the query plan would not create this scenario)
			//so delete it from the result buffer, and pass the witness tree on:
			resultBuffer->deleteNode(nodeIndexInWitnessTree);
			node = resultBuffer;
			input->next(inTuple);
			return;

			//if the query plan would not ask us to work with deleted nodes, we would issue the following error:
			//ostringstream outStream;
			//outStream << "Could not fetch the data node with key=" << curSK.toDouble();
			//globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"UpdatesIterator",__FILE__, outStream.str().c_str());
			//node = NULL;
			//return;
		}
		//if the node exists, we know that it's parent still exists, and we grab it here:
		KeyType curParentSK = dataNode->getParent();
		DM_DataNode *parentNode = dataMng->getDataNode(fileid, curParentSK, true);


		//NOTE: we assume that the node to update is a stored node, rather than a dummy node

		//so, we have just grabbed the first parameter given to one of the xquery timber-delete, timber-insert*,
		//or timber-update... this parameter is a bound variable, so we don't have to worry about
		//multiple nodes in the witness tree with that nre.  this is not the case with subsequent parameters:
		
		//A FEW ASSUMPTIONS TO UNDERSCORE ABOUT NON-CONST PARAMETERS IN THE XQUERY UPDATE COMMANDS:
		//due to the xquery update semantics, we also require that subsequent parameters have
		//paths that map to singleton sets.  (e.g. a path such as $b/editor can only match one
		//editor for a given assignment to $b).  but unlike the first parameter, this may not actually
		//be the case: more than one node with the same nre might exist in the witness tree.
		//we will check this and issue a warning if it is not a singleton set, but we will not issue
		//an error and abort (since this would leave the indices and the device out of sync --
		//we don't currently have write-ahead logging for indices).
		//so, if it is not a singleton set, the assigned value will just be the first member
		//of this set (the first editor for instance)
		//furthermore, paths in the xquery update commands (other than the first parameter, which is a bound
		//variable) are not 'required matches', so the witness tree can get here
		//even if there is no matching node (e.g. no matching editor). In this case the value that
		//is assigned, when this (missing) node is referenced, will be the empty string ""

		//note: we store the number of updates in gUpdatesArray for each iterator, so that we can
		//display this information to the user after a query has been executed.
		//if a delete is requested of the same node more than once, we do not "double count" this
		//but if multiple modifications are requested to the same node, we will count each modification
		//for this update iterator

		switch(updateType) {
			case QueryEvaluationTreeUpdatesNode::MODIFY_TEXT_NODE:
			{
				if (dataNode->getFlag() != ELEMENT_NODE) {
					globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"UpdatesIterator",__FILE__,"The initial NRE in ModTNode must reference an element node. The data was not modified");
					node = NULL;
					dataMng->abortTransaction();
					return;
				}
				
				//use this to determine if something was actually deleted.
				//actually, we won't use it... technically nothing would have changed if no deletion
				//occurred, but we'll go ahead and count a modification from "" to "" as one update...
				//bool deletedTextNodes = false;

				//Delete all of the current text nodes (there might be more than one):
				int numChildren = dataMng->getNumChildren(fileid, curSK, true);
				//go backwards, so that deletions do not affect the update of the loop variable, i
				for (int i = numChildren-1; i >= 0; i--) {
					DM_DataNode * childNode = dataMng->getChild(fileid, curSK, i, true);

					if (childNode->getFlag() == TEXT_NODE) {
						//deletedTextNodes = true;
						dataMng->update(indexUpdater, fileid, DATAMNG_UPDATEOP_DELETELEAFNODE, childNode->getKey(), i, NULL);
					}
				}

				//we will insert the new value as the last child, so grab the current # of children:
				numChildren = dataMng->getNumChildren(fileid, curSK, true);

				//if textValue2 is a constant value, then we treat it as the new text value for the element
				if (strcmp("CONST", textValue1)==0) {
					DM_DataNode * tempTextNode = (DM_DataNode*) new DM_TextNode(-1, -1, textValue2);
					//(fileid, operation, key, childIndex, newNode)
					//should be able to use -1 here for numChildren to speed things up actually (?):
					dataMng->update(indexUpdater, fileid, DATAMNG_UPDATEOP_INSERTLEAFNODE, curSK, numChildren, tempTextNode);
					//dataMng->update(indexUpdater, fileid, DATAMNG_UPDATEOP_INSERTLEAFNODE, curSK, 0, tempTextNode);
					delete tempTextNode;
				}
				else if (strcmp("REF", textValue1)==0){
					//if REF, then textValue2 contains the NRE of the referenced node:
					int nreForReference = atoi(textValue2);
					ComplexListNode *referenceNode = (ComplexListNode *)inTuple->findNodeNRE(nreForReference);

					if (!referenceNode) {
						//if (deletedTextNodes) {
						gUpdatesArray.at(ind).first++;
						//}

						//Note: even though we are returning here, we have already deleted
						//the text node children above, according to our xquery update semantics:
						node = resultBuffer;
						input->next(inTuple);
						//if (!inTuple) {
						//	node  = NULL;
						//	return;
						//}
						return;
					}

					//if the path maps to more than one node, we issue a warning, only the first node in this
					//set will be used to assign the value
					if (inTuple->moreThanOneMatch(nreForReference)) {
						ostringstream oss;
						oss << "More than one node mapped to NRE #" << nreForReference << ", only the first of these nodes was used for the update";
						globalErrorInfo.insertProblem(ERR_TYPE_WARNING,__LINE__,"UpdatesIterator::ModifyTextNode",__FILE__,oss.str().c_str());
					}

					//if the value to copy is a "dummy node" (i.e. created during the query, such as
					//avg(price), as opposed to a value retrieved from the db), then:
					if (referenceNode->IsDummy()) {
						char * dummyValue = referenceNode->GetDummyName();
							//if the dummyValue is equal to "" we won't insert a text node
							if (strlen(dummyValue) > 0) {
								DM_DataNode * tempTextNode = (DM_DataNode*) new DM_TextNode(-1, -1, dummyValue);
								dataMng->update(indexUpdater, fileid, DATAMNG_UPDATEOP_INSERTLEAFNODE, curSK, numChildren, tempTextNode);
								delete tempTextNode;
							}
					}
					//otherwise the value to copy needs to be retrieved from the database
					else {
						KeyType referenceStartKey = referenceNode->GetStartPos();
						FileIDType referenceFileID = EvaluatorClass::getFileID(referenceNode->getFileIndex());

						DM_DataNode* sourceDataNode = referenceNode->GetData();

						//need to make sure the node hasn't been deleted from the database:
						if (sourceDataNode)
						switch(sourceDataNode->getFlag()) {

							case ELEMENT_NODE:
							{							
								//Concatenate the text node values of the reference element node,
								//and insert one text node with this concatenated value under
								//the target element node:
								string concatenatedText;
								int numReferenceChildren = dataMng->getNumChildren(referenceFileID, referenceStartKey, true);
								for (int i = 0; i < numReferenceChildren; i++) {
									DM_DataNode * childNode = dataMng->getChild(referenceFileID, referenceStartKey, i, true);
									if (childNode->getFlag() == TEXT_NODE) {
										if (concatenatedText.size() > 0)
											concatenatedText.append(" "); //not correct if getCharValue below returns empty string... can this happen?
										concatenatedText.append(static_cast<DM_TextNode*>(childNode)->getCharValue());
									}
								}

								if (concatenatedText.size() > 0) {
									DM_DataNode * tempTextNode = (DM_DataNode*) new DM_TextNode(-1, -1, concatenatedText.c_str());
									dataMng->update(indexUpdater, fileid, DATAMNG_UPDATEOP_INSERTLEAFNODE, curSK, numChildren, tempTextNode);
									delete tempTextNode;
								}
							}//case ELEMENT_NODE
							break;

							case ATTRIBUTE_NODE:
							{
								Value *attributeValue = static_cast<DM_AttributeNode*>(sourceDataNode)->getAttr(textValue3);
								if (attributeValue != NULL) {
									if (strlen(attributeValue->getStrValue()) > 0) {
										DM_DataNode * tempTextNode = (DM_DataNode*) new DM_TextNode(-1, -1, attributeValue->getStrValue());
										dataMng->update(indexUpdater, fileid, DATAMNG_UPDATEOP_INSERTLEAFNODE, curSK, numChildren, tempTextNode);
										delete tempTextNode;
									}
								}
							}
							break;

							//do we need a text source node option? It's not necessary from the xquery perspective
							//i.e. node/text() gives you a concatenation of text nodes, which we can access from the element (parent) node
							//case TEXT_NODE:
							//	break;
							default:
								globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"UpdatesIterator",__FILE__,"When using REF in ModTNode, the matching source node must be either an element or attribute node. The data was not modified");
								node = NULL;
								dataMng->abortTransaction();
								return;

						}//switch
					} //end of: else it's a DM_DataNode, and not a dummy node
				}
				else {
					globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"UpdatesIterator",__FILE__,"Expecting either CONST or REF in Update Line of Physical Plan. The data was not modified");
					node = NULL;
					dataMng->abortTransaction();
					return;
				}
									
			} //case MODIFY_TEXT_NODE
			break;
			case QueryEvaluationTreeUpdatesNode::DELETE_TEXT_NODE:
				{
					if (dataNode->getFlag() != ELEMENT_NODE) {
						globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"UpdatesIterator",__FILE__,"The NRE in DelTNode must reference an element node. The data was not modified");
						node = NULL;
						dataMng->abortTransaction();
						return;
					}

					//Delete all of the current text nodes (there might be more than one):
					int numChildren = dataMng->getNumChildren(fileid, curSK, true);
					//go backwards, so that deletions do not affect the update of the loop variable, i
					for (int i = numChildren-1; i >= 0; i--) {
						DM_DataNode * childNode = dataMng->getChild(fileid, curSK, i, true);

						if (childNode->getFlag() == TEXT_NODE)
							dataMng->update(indexUpdater, fileid, DATAMNG_UPDATEOP_DELETELEAFNODE, childNode->getKey(), i, NULL);
							//dataMng->update(indexUpdater, fileid, DATAMNG_UPDATEOP_DELETELEAFNODE, childNode->getKey(), -1, NULL);
					}

					//undo the increment that will occur at the end of this method if the text was not actually deleted:
					if (numChildren == 0)
						gUpdatesArray.at(ind).first--;
				}
				break;
			case QueryEvaluationTreeUpdatesNode::DELETE_TREE:
				{
					if (dataNode->getFlag() != ELEMENT_NODE) {
						globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"UpdatesIterator",__FILE__,"The NRE in DelTree must reference an element node. The data was not modified");
						node = NULL;
						dataMng->abortTransaction();
						return;
					}

					//we need to remove the deleted node/s from the witness tree:
					//resultBuffer->deleteNode(nodeIndexInWitnessTree);
					resultBuffer->deleteNodeAndDescendants(curSK, n->GetEndPos());

					double retval = dataMng->update(indexUpdater, fileid, DATAMNG_UPDATEOP_DELETESUBTREE, curSK, -1, NULL);
					
					//if the number of nodes deleted is equal to zero, then undo the increment that will be done at the end:
					if (retval == 0)
						gUpdatesArray.at(ind).first--;
				}
				break;
			case QueryEvaluationTreeUpdatesNode::DELETE_ATTRIBUTE:
				{
					if (dataNode->getFlag() != ATTRIBUTE_NODE) {
						globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"UpdatesIterator",__FILE__,"The NRE in DelAttr must reference an attribute node. The data was not modified");
						node = NULL;
						dataMng->abortTransaction();
						return;
					}
					
					//textValue1 contains the attribute name to delete:
					if (static_cast<DM_AttributeNode*>(dataNode)->hasAttributeWithName(textValue1)) {
						short numAttributes = static_cast<DM_AttributeNode*>(dataNode)->getAttributeNumber();

						if (numAttributes == 1) {
							//only one attribute (which we are deleting) so delete the attribute node:
							dataMng->update(indexUpdater, fileid, DATAMNG_UPDATEOP_DELETELEAFNODE, curSK, -1, NULL);
							//don't really need to do this here... if retval == -1 then we abort the transaction:
							//if (retval == -1)
							//	gUpdatesArray.at(ind).first--;

							//delete the attribute node from the witness tree:
							resultBuffer->deleteNode(nodeIndexInWitnessTree);
						}
						else {
							vector<char*> attributeNamesVector;
							vector<Value*> attributeValuesVector;

							for (short i = 0; i < numAttributes; i++) {
								//getAttr doesn't allocate space for the name char* that is passed in!:
								//char *attributeName = new char[MAX_ATTRIBUTE_NAME_LENGTH+1];
								char* attributeName = NULL;

								Value *attributeValue = new Value(static_cast<DM_AttributeNode*>(dataNode)->getAttr(i, attributeName));

								attributeNamesVector.push_back(attributeName);
								attributeValuesVector.push_back(attributeValue);

								//textValue1 contains the attribute name to delete:
								if (strcmp(attributeName, textValue1) == 0) {
									attributeNamesVector.pop_back();
									attributeValuesVector.pop_back();

									delete [] attributeName;
									delete attributeValue;
								}
							}

							//one less attribute now, so use numAttributes-1:
							char** attributeNames = new char*[numAttributes-1];
							Value** attributeValues = new Value*[numAttributes-1];
							for (int i = 0; i < numAttributes-1; i++) {
								attributeNames[i] = attributeNamesVector.at(i);
								attributeValues[i] = attributeValuesVector.at(i);
							}

							//create the new attribute node (minus the one attribute):
							DM_AttributeNode * tempAttributeNode = //(DM_DataNode*)
								new DM_AttributeNode(dataNode->getKey(), dataNode->getLevel(),
									numAttributes-1, attributeNames, attributeValues,
									dataNode->getParent());
							
							//DATAMNG_UPDATEOP_MODIFYNODE does not update the index like the other operations:
							Value* attrValue = static_cast<DM_AttributeNode*>(dataNode)->getAttr(textValue1);
							//indexUpdater->attributeDeletion(curParentSK, curSK, textValue1, attrValue);
							bool indexRetVal = indexUpdater->attributeDeletion(dataMng->getFileInfo(fileid), static_cast<DM_ElementNode*>(parentNode), curSK, textValue1, attrValue);
							if (!indexRetVal) {
								//unfortunately, gist does not support write-ahead logging for indices
								//so aborting the transaction will not return us to a correct state:
								globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"UpdatesIterator",__FILE__,
									"There was a problem with updating the indices.  The data was left unchanged by the update query, but indices must be rebuilt");
								node = NULL;
								dataMng->abortTransaction();
								return;
							}

							//we are storing attrNumber with the DM_ElementNode (nuwee is using this with multicolor stuff)
							//so we need to update the parent element node's attribute count here:
							//(DATAMNG_UPDATEOP_MODIFYNODE would take care of this, but we want to use
							//DATAMNG_UPDATEOP_MODIFYNODEINPLACE for the attribute node, to avoid the overflow)
							serial_t parentNodeRid = dataMng->getNodeRid(fileid, curParentSK);
							static_cast<DM_ElementNode*>(parentNode)->setAttrNumber(numAttributes-1);
							dataMng->update(indexUpdater, fileid, DATAMNG_UPDATEOP_MODIFYNODEINPLACE, curParentSK, -1, parentNode, &parentNodeRid);

							//we can do an 'in place' modification since the node will not be getting bigger after the deletion:
							serial_t nodeRid = dataMng->getNodeRid(fileid, curSK);
							dataMng->update(indexUpdater, fileid, DATAMNG_UPDATEOP_MODIFYNODEINPLACE, curSK, -1, tempAttributeNode, &nodeRid);


							//should I do a delete followed by an insertLeafNode here, or is modifynode working:
							//... actually, right now modify node is implemented as a delete followed by an insert!
							//dataMng->update(indexUpdater, fileid, DATAMNG_UPDATEOP_MODIFYNODE, curSK, -1, tempAttributeNode);
							
							//dataMng->update(indexUpdater, fileid, DATAMNG_UPDATEOP_DELETELEAFNODE, curSK, -1, NULL);
							//dataMng->update(indexUpdater, fileid, DATAMNG_UPDATEOP_INSERTLEAFNODE, curParentSK, -1, tempAttributeNode);							

							resultBuffer->deleteNode(nodeIndexInWitnessTree);
							
							delete tempAttributeNode;
						}
					} //end if hasAttributeWithName
					else {
						gUpdatesArray.at(ind).first--;
					}
				}
				break;

			case QueryEvaluationTreeUpdatesNode::DELETE_ATTRIBUTE_VALUE:
				{
					if (dataNode->getFlag() != ATTRIBUTE_NODE) {
						globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"UpdatesIterator",__FILE__,"The NRE in DelAttrValue must reference an attribute node. The data was not modified");
						node = NULL;
						dataMng->abortTransaction();
						return;
					}

					//the value for an attribute cannot be set to NULL, so we create a value with a zero length string
					Value *emptyValue = new Value(STRING_VALUE, "");

					//store the old value:
					Value* tempValue = static_cast<DM_AttributeNode*>(dataNode)->getAttr(textValue1);
					//setAttrValue below will delete tempValue, so create a new Value based on tempValue:
					Value* oldValue = NULL;
					if (tempValue != NULL) {
						oldValue = new Value(tempValue);

						//if the attribute value is already 'empty' then we will not perform the update,
						//and we will not increment the # of updates:
						if (tempValue->compareValue(VALUE_COMP_OP_EQ, emptyValue)) {
							gUpdatesArray.at(ind).first--;
							delete oldValue;
							delete emptyValue;
							break;
						}
					}

					//textValue1 contains the attribute name to delete:
					int index = static_cast<DM_AttributeNode*>(dataNode)->setAttrValue(textValue1, emptyValue);

					//note: we need to be a little careful here.  since the nodeIDMap will contain
					//the attribute node, and we have not made copies of the attribute and value arrays,
					//we need to make sure to write the DM_AttributeNode modifications to disk before
					//deleting the node from the nodeIDMap (which will call the destructor for the attribute
					//node, and delete all elements in the attribute/value arrays).  this is handled
					//in the modify method implementation below:

					//should I do a delete followed by an insertLeafNode here, or is modifynode working:
					//... actually, right now modify node is implemented as a delete followed by an insert!

					//if the attribute value was found (and changed) then update the node in the DB:
					if (index != -1) {
						//not really any different from a modify with "" as the new value:
						//indexUpdater->attributeValueDeletion(curParentSK, curSK, textValue1, oldValue);
						bool indexRetVal = indexUpdater->attributeValueDeletion(dataMng->getFileInfo(fileid),
							static_cast<DM_ElementNode*>(parentNode), curSK, textValue1, oldValue);
						if (!indexRetVal) {
							//unfortunately, gist does not support write-ahead logging for indices
							//so aborting the transaction will not return us to a correct state:
							globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"UpdatesIterator",__FILE__,
								"There was a problem with updating the indices.  The data was left unchanged by the update query, but indices must be rebuilt");
							node = NULL;
							dataMng->abortTransaction();
							return;
						}

						//we can do an 'in place' modification, since the node will not be getting bigger after the deletion:
						serial_t nodeRid = dataMng->getNodeRid(fileid, curSK);
						dataMng->update(indexUpdater, fileid, DATAMNG_UPDATEOP_MODIFYNODEINPLACE, curSK, -1, dataNode, &nodeRid);

						//dataMng->update(indexUpdater, fileid, DATAMNG_UPDATEOP_MODIFYNODE, curSK, -1, dataNode);
					}
					else {
						delete emptyValue;
						gUpdatesArray.at(ind).first--;
					}
					//should we remove the attribute node from the witness tree?  only if the node existed
					//only due to the removed value matching some condition... which we don't know here.
					//resultBuffer->deleteNode(nodeIndexInWitnessTree);

					delete oldValue;
				}
				break;

			case QueryEvaluationTreeUpdatesNode::INSERT_ATTRIBUTE:
				{
					if (dataNode->getFlag() != ELEMENT_NODE) {
						globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"UpdatesIterator",__FILE__,"The NRE in InsAttr must reference an element node. The data was left unmodified");
						node = NULL;
						dataMng->abortTransaction();
						return;
					}

					DM_AttributeNode *attributeNode = NULL;
					//if the element node already has an attribute node then insert the new attribute name with an empty value
					//(we will fall through to attribute value modification to update the attribute's value)
					//if (static_cast<DM_ElementNode*>(dataNode)->getAttributeNumber() > 0) {
					if (static_cast<DM_ElementNode*>(dataNode)->hasAttributes()) {
						KeyType attributeKey = static_cast<DM_ElementNode*>(dataNode)->getAttributes();

						attributeNode = (DM_AttributeNode*)dataMng->getDataNode(fileid, attributeKey, true);

						//we'll just insert an empty value and fall through to the modify attribute value case
						Value *emptyValue = new Value(STRING_VALUE, "");
						//textValue1 contains the attribute name
						int numAttributes = attributeNode->insertAttribute(textValue1, emptyValue);

						//numAttributes == -1 if an attribute already existed with name==textValue1
						if (numAttributes != -1) {
							//indexUpdater->attributeInsertion(curSK, attributeKey, textValue1, emptyValue);
							bool indexRetVal = indexUpdater->attributeInsertion(dataMng->getFileInfo(fileid), static_cast<DM_ElementNode*>(dataNode),
								attributeKey, textValue1, emptyValue);
							if (!indexRetVal) {
								//unfortunately, gist does not support write-ahead logging for indices
								//so aborting the transaction will not return us to a correct state:
								globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"UpdatesIterator",__FILE__,
									"There was a problem with updating the indices.  The data was left unchanged by the update query, but indices must be rebuilt");
								node = NULL;
								dataMng->abortTransaction();
								return;
							}

							//cannot do an 'in place' modification since we're inserting (getting larger):
							dataMng->update(indexUpdater, fileid, DATAMNG_UPDATEOP_MODIFYNODE, attributeKey, -1, attributeNode);
						}
						else {
							delete emptyValue;

							//we use lastAttributeKeyProcessed as a bit of a hack to limit (somewhat) redundant
							//warning messages when a query would cause an attribute to be inserted multiple times
							//for the same element node... due to the way we match witness trees in nested FOR queries
							//this can be quite easy to do for the user.
							if (curSK != this->lastElementKeyProcessed) {
								this->lastElementKeyProcessed = curSK;

								//we can either print a warning here, or in DM_AttributeNode
								//(the advantage of printing here is that we can use the nre)
								//(we may even want to take the warning out completely, since if the user intends this, then we'll take
								//a lot of extra time printing stuff out (and building up the warning messages)).
								//for now, we'll just print one warning message per specific attribute/element pair
								//where this failed insertion is attempted (we use lastAttributeKeyProcessed for this)
								ostringstream oss;
								oss << "Attempted to insert an attribute named '" <<
									textValue1 << "' into an element (with nre=" <<
									nre << " and start key = " << curSK.toString() <<
									") that already contained this attribute name";

								globalErrorInfo.insertProblem(ERR_TYPE_WARNING,__LINE__,"DM_AttributeNode::insertAttribute",__FILE__,oss.str().c_str());
							}

							//resultBuffer->copyTree(inTuple);
							node = resultBuffer;
							input->next(inTuple);
							//don't increment gUpdatesArray.at(ind).first here... no update performed.

							//if (!inTuple) {
							//	node  = NULL;
							//	return;
							//}
							return;
						}
					}
					//otherwise, create the new attribute node and write it to the database
					else {
						char** attributeNames = new char*[1];
						Value** attributeValues = new Value*[1];

						attributeNames[0] = new char[strlen(textValue1)+1];
						strcpy(attributeNames[0], textValue1);
						//use the empty value for now... then drop into modify below...
						attributeValues[0] = new Value(STRING_VALUE, "");
						attributeNode = new DM_AttributeNode(-1, -1, 1 /*numAttributes*/, attributeNames, attributeValues, curSK);
						
						dataMng->update(indexUpdater, fileid, DATAMNG_UPDATEOP_INSERTLEAFNODE, curSK, -1, attributeNode);							
					}

					//break out of the switch statement if no value is given for textValue2 (CONST REF <NOVAL>)
					//similarly, break out if there is no value for textValue3 (the actual value if CONST, the NRE if ref)
					//the user is creating an attribute without an associated text value.
					if (textValue2 == NULL || strcmp(textValue2, "<NOVAL>") == 0 || textValue3 == NULL)
						break;

					//assign the attribute node to be the current dataNode, and fall through to MODIFY_ATTRIBUTE_VALUE
					//note: DATA_MNG_MODIFYNODE will remove the attribute node from the nodeIDMap
					//and delete the node, so we should fetch it here again,
					//in case it was in the node idmap and was deleted:
					//dataNode = static_cast<DM_DataNode*>(attributeNode);
					//note: INSERTLEAFNODE removes the parent (dataNode) from the idMap & deletes it
					//so need to re-fetch dataNode as well... (this is getting messy).
					parentNode = dataMng->getDataNode(fileid, curSK, true);
					dataNode = dataMng->getDataNode(fileid,
						static_cast<DM_ElementNode*>(parentNode)->getAttributes(), true);
					//curSK = attributeNode->getKey();
					curSK = dataNode->getKey();
					curParentSK = dataNode->getParent();
				}
				//no break, EXPLICIT FALL-THROUGH... 

			case QueryEvaluationTreeUpdatesNode::MODIFY_ATTRIBUTE_VALUE:
				{
					if (dataNode->getFlag() != ATTRIBUTE_NODE) {
						globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"UpdatesIterator",__FILE__,"The NRE in ModANode must reference an attribute node. The data was left unmodified");
						node = NULL;
						dataMng->abortTransaction();
						return;
					}

					//store the old attribute value:
					Value* tempValue = static_cast<DM_AttributeNode*>(dataNode)->getAttr(textValue1);
					//setAttrValue below will delete tempValue, so create a new Value based on tempValue:
					Value* oldValue = NULL;
					if (tempValue != NULL) {
						oldValue = new Value(tempValue);
					}
					else {
						//if the attribute/value does not exist then continue to the next witness tree, nothing to modify here:
						node = resultBuffer;
						input->next(inTuple);

						//don't need to increment the update count here... even if dropping through from INSERT_ATTRIBUTE.
						//because tempValue would not be NULL in that case.
						return;
					}

					//if textValue2 is a constant value, then we treat it as the new text value for the element
					if (strcmp("CONST", textValue2)==0) {
						//textValue3 contains the new attribute value (in Evaluator.cpp we require textValue3 != NULL):
						Value *newAttrValue = new Value(STRING_VALUE, textValue3);

						bool success = setAttributeValue(textValue1, newAttrValue, oldValue,
							static_cast<DM_AttributeNode*>(dataNode), static_cast<DM_ElementNode*>(parentNode),
							indexUpdater, dataMng, fileid);
						if (!success) {
							node = NULL;
							dataMng->abortTransaction();
							return;
						}
					}
					else if (strcmp("REF", textValue2)==0){
						//if REF, then textValue3 contains the NRE of the referenced node:
						int nreForReference = atoi(textValue3);
						ComplexListNode *referenceNode = (ComplexListNode *)inTuple->findNodeNRE(nreForReference);

						if (!referenceNode) {
							//due to our xquery update semantics, we need to set the attribute value to ""
							//if there are is no matching referenceNode:

							Value* emptyValue = new Value(STRING_VALUE, "");

							//if the old attribute value isn't already equal to "", then change it to "":
							if (!oldValue->compareValue(VALUE_COMP_OP_EQ, emptyValue)) {

								bool success = setAttributeValue(textValue1, emptyValue, oldValue,
									static_cast<DM_AttributeNode*>(dataNode), static_cast<DM_ElementNode*>(parentNode),
									indexUpdater, dataMng, fileid);
								if (!success) {
									node = NULL;
									dataMng->abortTransaction();
									return;
								}
							}
							else {
								delete emptyValue;
							}

							delete oldValue;

							gUpdatesArray.at(ind).first++;

							node = resultBuffer;
							input->next(inTuple);
							//if (!inTuple) {
							//	node  = NULL;
							//	return;
							//}
							return;
						}

						//if the path maps to more than one node, we issue a warning, only the first node in this
						//set will be used to assign the value
						if (inTuple->moreThanOneMatch(nreForReference)) {
							ostringstream oss;
							oss << "More than one node mapped to NRE #" << nreForReference << ", only the first of these nodes was used for the update";
							globalErrorInfo.insertProblem(ERR_TYPE_WARNING,__LINE__,"UpdatesIterator::ModifyAttributeValue",__FILE__,oss.str().c_str());
						}

						//if the value to copy is a "dummy node" (i.e. created during the query, such as
						//avg(price), as opposed to a value retrieved from the db), then:
						if (referenceNode->IsDummy()) {
							char * dummyValue = referenceNode->GetDummyName();
							//we may have to modify an attribute value to "", so we don't want this condition here:
							//if (strlen(dummyValue) > 0) {
								Value *newAttrValue = new Value(STRING_VALUE, dummyValue);
								
								bool success = setAttributeValue(textValue1, newAttrValue, oldValue,
									static_cast<DM_AttributeNode*>(dataNode), static_cast<DM_ElementNode*>(parentNode),
									indexUpdater, dataMng, fileid);
								if (!success) {
									node = NULL;
									dataMng->abortTransaction();
									return;
								}
							//}
						}
						//otherwise the value to copy needs to be retrieved from the database
						else {
							KeyType referenceStartKey = referenceNode->GetStartPos();
							FileIDType referenceFileID = EvaluatorClass::getFileID(referenceNode->getFileIndex());

							DM_DataNode* sourceDataNode = referenceNode->GetData();

							if (sourceDataNode) {
								switch(sourceDataNode->getFlag()) {

									case ELEMENT_NODE:
									{							
										//Concatenate the text node values of the reference element node,
										//and insert one text node with this concatenated value under
										//the target element node:
										string concatenatedText;
										int numReferenceChildren = dataMng->getNumChildren(referenceFileID, referenceStartKey, true);
										for (int i = 0; i < numReferenceChildren; i++) {
											DM_DataNode * childNode = dataMng->getChild(referenceFileID, referenceStartKey, i, true);
											if (childNode->getFlag() == TEXT_NODE) {
												if (concatenatedText.size() > 0)
													concatenatedText.append(" "); //not correct if getCharValue below returns empty string... but this shouldn't happen
												concatenatedText.append(static_cast<DM_TextNode*>(childNode)->getCharValue());
											}
										}

										//we want to set the value to "", if needed, so we don't want this condition:
										//if (concatenatedText.size() > 0) {
											Value *newAttrValue = new Value(STRING_VALUE, concatenatedText.c_str());
											
											bool success = setAttributeValue(textValue1, newAttrValue, oldValue,
												static_cast<DM_AttributeNode*>(dataNode), static_cast<DM_ElementNode*>(parentNode),
												indexUpdater, dataMng, fileid);
											if (!success) {
												node = NULL;
												dataMng->abortTransaction();
												return;
											}
										//}
									}//case ELEMENT_NODE
									break;

									case ATTRIBUTE_NODE:
									{
										//Value *attributeValue = static_cast<DM_AttributeNode*>(sourceDataNode)->getAttr(textValue4);
										//Value *newAttrValue = new Value(STRING_VALUE, attributeValue->getStrValue());

										Value *newAttrValue = new Value(static_cast<DM_AttributeNode*>(sourceDataNode)->getAttr(textValue4));
										
										bool success = setAttributeValue(textValue1, newAttrValue, oldValue,
											static_cast<DM_AttributeNode*>(dataNode), static_cast<DM_ElementNode*>(parentNode),
											indexUpdater, dataMng, fileid);
										if (!success) {
											node = NULL;
											dataMng->abortTransaction();
											return;
										}
									}
									break;

									//do we need a text source node option... I don't think it's nec. from the xquery perspective
									//i.e. node/text() gives you a concatenation of text nodes, which we can access from the element (parent) node
									//case TEXT_NODE:
									//	break;
									default:
										globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"UpdatesIterator",__FILE__,"When using REF in ModANode, the matching source node must be either an element or attribute node. The data was left unmodified");
										node = NULL;
										dataMng->abortTransaction();
										return;

								}//switch
							} //if sourceDataNode != NULL
							//o.w. the sourceDataNode == NULL and we should set the attribute value to ""
							else if (!oldValue->compareValue(VALUE_COMP_OP_EQ, new Value(STRING_VALUE, ""))) {

								Value* emptyValue = new Value(STRING_VALUE, "");
								bool success = setAttributeValue(textValue1, emptyValue, oldValue,
									static_cast<DM_AttributeNode*>(dataNode), static_cast<DM_ElementNode*>(parentNode),
									indexUpdater, dataMng, fileid);
								if (!success) {
									node = NULL;
									dataMng->abortTransaction();
									return;
								}
							}

						} //end of: else it's a DM_DataNode, and not a dummy node
					}
					else {
						globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"UpdatesIterator",__FILE__,"Expecting either CONST or REF in Update Line of Physical Plan. The data was left unmodified");
						node = NULL;
						dataMng->abortTransaction();
						return;
					}

					delete oldValue;
				}
				break;

			case QueryEvaluationTreeUpdatesNode::INSERT_ELEMENT_NODE:
				{
					if (dataNode->getFlag() != ELEMENT_NODE) {
						globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"UpdatesIterator",__FILE__,"The NRE in InsENode must reference an element node. The data was left unmodified");
						node = NULL;
						dataMng->abortTransaction();
						return;
					}

					//check to see if the newly inserted element tag name already exists in the document:
					int code = dataMng->getPhysicalDataMng()->getXMLNameTable()->getCodeByName(textValue1);
					//if not, insert the name and retrieve the corresponding integer code:
					if (code == -1)
						code = dataMng->getPhysicalDataMng()->getXMLNameTable()->addNameToTable(textValue1);

					DM_DataNode * tempElementNode = (DM_DataNode*) new DM_ElementNode(0, 0, code);
					//insert as the last child:
					int indexToInsertAt = dataNode->getChildNumber();

					//insert the element node:
					//note: dataNode will not be valid after this update, if it has been stored in the nodeIdMap:
					//update returns a node key, currently not checking this...
					dataMng->update(indexUpdater, fileid, DATAMNG_UPDATEOP_INSERTLEAFNODE, dataNode->getKey(), indexToInsertAt, tempElementNode);

					//store the elementNodeKey for use when inserting attributes:
					KeyType *elementNodeKey = new KeyType(tempElementNode->getKey().toDouble());
					delete tempElementNode;

					if (textValue2 != NULL && strcmp(textValue2, "<NOVAL>") != 0) {

						//if textValue2 is a constant value, then we treat it as the new text value for the element
						if (strcmp("CONST", textValue2)==0) {
							//textValue3 contains the value for the new text node:
							//insert the text node for the newly inserted element
							DM_DataNode * tempTextNode = (DM_DataNode*) new DM_TextNode(-1, -1, textValue3);
							//insert text node as the first child (child 0) of the element node:
							dataMng->update(indexUpdater, fileid, DATAMNG_UPDATEOP_INSERTLEAFNODE, *elementNodeKey, 0, tempTextNode);							
							delete tempTextNode;
						}
						else if (strcmp("REF", textValue2)==0){
							//if REF, then textValue3 contains the NRE of the referenced node:
							int nreForReference = atoi(textValue3);
							ComplexListNode *referenceNode = (ComplexListNode *)inTuple->findNodeNRE(nreForReference);


							//if the path maps to more than one node, we issue a warning, only the first node in this
							//set will be used to assign the value
							if (inTuple->moreThanOneMatch(nreForReference)) {
								ostringstream oss;
								oss << "More than one node mapped to NRE #" << nreForReference << ", only the first of these nodes was used for the update";
								globalErrorInfo.insertProblem(ERR_TYPE_WARNING,__LINE__,"UpdatesIterator::InsertElementNode:AssignTextNodeValue",__FILE__,oss.str().c_str());
							}

							if (!referenceNode) {
								//we don't want to exit here anymore.  referenceNode may not match, so we just won't
								//create a text node here if that is the case...

								//node = resultBuffer;
								//input->next(inTuple);
								//return;
							}
							//if the value to copy is a "dummy node" (i.e. created during the query, such as
							//avg(price), as opposed to a value retrieved from the db), then:
							else if (referenceNode->IsDummy()) {
								char * dummyValue = referenceNode->GetDummyName();
									if (strlen(dummyValue) > 0) {
										DM_DataNode * tempTextNode = (DM_DataNode*) new DM_TextNode(-1, -1, dummyValue);
										dataMng->update(indexUpdater, fileid, DATAMNG_UPDATEOP_INSERTLEAFNODE, *elementNodeKey, 0, tempTextNode);
										delete tempTextNode;
									}
							}
							//otherwise the value to copy needs to be retrieved from the database
							else {
								KeyType referenceStartKey = referenceNode->GetStartPos();
								FileIDType referenceFileID = EvaluatorClass::getFileID(referenceNode->getFileIndex());

								DM_DataNode* sourceDataNode = referenceNode->GetData();
								if (sourceDataNode) {
									switch(sourceDataNode->getFlag()) {

										case ELEMENT_NODE:
										{
											string concatenatedText;
											int numReferenceChildren = dataMng->getNumChildren(referenceFileID, referenceStartKey, true);
											for (int i = 0; i < numReferenceChildren; i++) {
												DM_DataNode * childNode = dataMng->getChild(referenceFileID, referenceStartKey, i, true);
												if (childNode->getFlag() == TEXT_NODE) {
													if (concatenatedText.size() > 0)
														concatenatedText.append(" "); //not correct if getCharValue below returns empty string... can this happen?
													concatenatedText.append(static_cast<DM_TextNode*>(childNode)->getCharValue());
												}
											}

											if (concatenatedText.size() > 0) {
												DM_DataNode * tempTextNode = (DM_DataNode*) new DM_TextNode(-1, -1, concatenatedText.c_str());
												//no children, so insert at index=0
												dataMng->update(indexUpdater, fileid, DATAMNG_UPDATEOP_INSERTLEAFNODE, *elementNodeKey, 0, tempTextNode);
												delete tempTextNode;
											}
										}//case ELEMENT_NODE
										break;

										case ATTRIBUTE_NODE:
										{
											Value *attributeValue = static_cast<DM_AttributeNode*>(sourceDataNode)->getAttr(textValue4);
											if (attributeValue != NULL) {
												if (strlen(attributeValue->getStrValue()) > 0) {
													DM_DataNode * tempTextNode = (DM_DataNode*) new DM_TextNode(-1, -1, attributeValue->getStrValue());
													//no children, so insert at index=0
													dataMng->update(indexUpdater, fileid, DATAMNG_UPDATEOP_INSERTLEAFNODE, *elementNodeKey, 0, tempTextNode);
													delete tempTextNode;
												}
											}
										}
										break;

										//do we need a text source node option... I don't think it's nec. from the xquery perspective
										//i.e. node/text() gives you a concatenation of text nodes, which we can access from the element (parent) node
										//case TEXT_NODE:
										//	break;
										default:
											globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"UpdatesIterator",__FILE__,"When using REF in InsENode, the matching source node must be either an element or attribute node. The data was left unmodified");
											node = NULL;
											dataMng->abortTransaction();
											return;

									}//switch
								} //if sourceDataNode != NULL
								//else { }

							} //end of: else it's a DM_DataNode, and not a dummy node
						}
						else {
							globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"UpdatesIterator",__FILE__,"Expecting either CONST or REF for the text node value in Update Line of Physical Plan. The data was left unmodified");
							node = NULL;
							dataMng->abortTransaction();
							return;
						}
					} //if textValue2 != NULL

					//add an attribute node, if the "repeated" vector contains attribute name/value pairs:
					if (repeated.size() > 0) {
						//now we insert the attributes of the newly inserted element node:
						//(note: tempElementNode might not be valid any longer if a text node was added
						// as a child, and if it was stored in the nodeIDMap, so we fetch the element node again...
						//(also, we've deleted tempElementNode above, since we weren't going to use it further)
						// if it is stored in the nodeIDMap now, this call will retrieve it from there)
						DM_DataNode * elementNode = dataMng->getDataNode(fileid, *elementNodeKey, true);

						char** attributeNames = NULL;
						Value** attributeValues = NULL;

						//attributeNames = (char**)malloc(sizeof(char*) * repeated.size());
						//attributeValues = (Value**)malloc(sizeof(Value*) * repeated.size());
						attributeNames = new char*[repeated.size()];
						attributeValues = new Value*[repeated.size()];

						//AttributeInfo is a struct that contains:
						//<AttributeName, CONSTorREF, valueOrNRE, possibleAttributeName>

						//insert attributes of newly inserted element
						vector<AttributeInfo>::iterator iterator;
						int i = 0;
						for (iterator = repeated.begin(), i = 0; iterator != repeated.end(); iterator++, i++) {
							AttributeInfo attrInfo = *iterator;

							//the ith attribute name to insert:
							//attributeNames[i] = (char*)malloc(attrInfo.attributeName.size()+1);
							attributeNames[i] = new char[attrInfo.attributeName.size()+1];
							strcpy(attributeNames[i], attrInfo.attributeName.c_str());
							
							//we'll copy the ith attributes value into this:
							string value;

							if (attrInfo.constOrRef == "CONST") {
								value = attrInfo.valueOrNRE;
							}
							else if (attrInfo.constOrRef == "REF") {
								int nreForReference = atoi(attrInfo.valueOrNRE.c_str());
								ComplexListNode *referenceNode = (ComplexListNode *)inTuple->findNodeNRE(nreForReference);

								//if the path maps to more than one node, we issue a warning, only the first node in this
								//set will be used to assign the value
								if (inTuple->moreThanOneMatch(nreForReference)) {
									ostringstream oss;
									oss << "More than one node mapped to NRE #" << nreForReference << ", only the first of these nodes was used for the update";
									globalErrorInfo.insertProblem(ERR_TYPE_WARNING,__LINE__,"UpdatesIterator::InsertElement:AssignAttributeValue",__FILE__,oss.str().c_str());
								}

								if (!referenceNode) {
									//due to the xquery update semantics, we don't return here any more
									//and value already equals "", so we just fall-through/continue:
									//value = "";
									
									//node = resultBuffer;
									//input->next(inTuple);
									//return;
								}
								//if the value to copy is a "dummy node" (i.e. created during the query, such as
								//avg(price), as opposed to a value retrieved from the db), then:
								else if (referenceNode->IsDummy()) {
									value = referenceNode->GetDummyName();
								}
								//otherwise the value to copy needs to be retrieved from the database
								else {
									KeyType referenceStartKey = referenceNode->GetStartPos();
									FileIDType referenceFileID = EvaluatorClass::getFileID(referenceNode->getFileIndex());

									DM_DataNode* sourceDataNode = referenceNode->GetData();

									if (sourceDataNode)
									switch(sourceDataNode->getFlag()) {

										case ELEMENT_NODE:
										{
											int numReferenceChildren = dataMng->getNumChildren(referenceFileID, referenceStartKey, true);
											for (int i = 0; i < numReferenceChildren; i++) {
												DM_DataNode * childNode = dataMng->getChild(referenceFileID, referenceStartKey, i, true);
												if (childNode->getFlag() == TEXT_NODE) {
													if (value.size() > 0)
														value.append(" ");
													value.append(static_cast<DM_TextNode*>(childNode)->getCharValue());
												}
											}
										}//case ELEMENT_NODE
										break;

										case ATTRIBUTE_NODE:
										{
											Value *attributeValue = static_cast<DM_AttributeNode*>(sourceDataNode)->getAttr(attrInfo.attributeNameIfNreIsAttribute.c_str());
											if (attributeValue != NULL)
												value = attributeValue->getStrValue();
										}
										break;

										default:
											globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"UpdatesIterator",__FILE__,"When using REF in InsENode, the matching source node must be either an element or attribute node. The data was left unmodified");
											node = NULL;
											dataMng->abortTransaction();
											return;

									}//switch
								} //end of: else it's a DM_DataNode, and not a dummy node
							}
							else if (attrInfo.constOrRef != "<NOVAL>") {
								globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"UpdatesIterator",__FILE__,"Expecting either a CONST or REF value to be associated with an attribute in InsENode. The data was left unmodified");
								node = NULL;
								dataMng->abortTransaction();
								return;
							}

							attributeValues[i] = new Value(STRING_VALUE, value.c_str());
						}

						DM_DataNode *tempAttributeNode = (DM_DataNode*) new DM_AttributeNode(0, 0, (short)repeated.size(), attributeNames, attributeValues, elementNode->getKey());
						
						// release space allocated for our (temporary) attribute name and value arrays:
						// AN: should just give the attribute node ownership of these, to avoid creation/deletion costs:
						/*
						for (i=0; i < repeated.size(); i++ )
						{
							delete [] attributeNames[i];
							delete attributeValues[i];
						}
						delete [] attributeNames;
						delete [] attributeValues;
						*/

						//-1 since attributes are not inserted as "children" like element nodes:
						dataMng->update(indexUpdater, fileid, DATAMNG_UPDATEOP_INSERTLEAFNODE, elementNode->getKey(), -1, tempAttributeNode);

						delete tempAttributeNode;

					} // if repeated.size() > 0

					delete elementNodeKey;

				} // case QueryEvaluationTreeUpdatesNode::INSERT_ELEMENT_NODE:
				break;
		} //switch

		gUpdatesArray.at(ind).first++;
	} //else
	
	//resultBuffer->appendList((ComplexListNode*)inTuple->getBuffer(), dataMng, inTuple->length(), false);
	//do this at the top, then we'll just modify resultBuffer if needed:
	//resultBuffer->copyTree(inTuple);

	node = resultBuffer;
	input->next(inTuple);

	return;
}

/**
* set the attribute value for an existing attribute (with name = attributeName)
*/
bool UpdatesIterator::setAttributeValue(char* attributeName, Value* newAttributeValue, Value* oldAttributeValue,
										DM_AttributeNode* attributeNode, DM_ElementNode* parentNode,
										IndexIncrementalUpdate* indexUpdater, DataMng* dataMng, FileIDType fileid)
{
	//no need to change the value if old=new (the output for this update will show that a modification took place though)
	if (newAttributeValue->compareValue(VALUE_COMP_OP_EQ, oldAttributeValue)) {
		delete newAttributeValue;
		return true;
	}

	KeyType attributeKey = attributeNode->getKey();
	
	//textValue1 contains the attribute name associated with the new value
	int index = attributeNode->setAttrValue(attributeName, newAttributeValue);

	//if the attribute value was found (and changed) then update the node in the DB:
	if (index != -1) {
		bool indexRetVal = indexUpdater->attributeValueModification(dataMng->getFileInfo(fileid),
			static_cast<DM_ElementNode*>(parentNode), attributeKey, attributeName, oldAttributeValue, newAttributeValue);
		if (!indexRetVal) {
			//unfortunately, gist does not support write-ahead logging for indices
			//so aborting the transaction will not return us to a correct state:
			globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"UpdatesIterator",__FILE__,
				"There was a problem with updating the indices.  The data was left unchanged by the update query, but indices must be rebuilt");
			//node = NULL;
			//dataMng->abortTransaction();
			//return;
			return false;
		}

		//if the new attribute value is smaller than old attribute value, we can do an in place modification
		//(and avoid moving the node to the overflow):
		if (newAttributeValue->getValueSize() <= oldAttributeValue->getValueSize()) {
			serial_t nodeRid = dataMng->getNodeRid(fileid, attributeKey);
			dataMng->update(indexUpdater, fileid, DATAMNG_UPDATEOP_MODIFYNODEINPLACE, attributeKey, -1, attributeNode, &nodeRid);
		}
		else {
			dataMng->update(indexUpdater, fileid, DATAMNG_UPDATEOP_MODIFYNODE, attributeKey, -1, attributeNode);
		}
	}

	return true;
}

//void UpdatesIterator::modifyAttributeValue(DM_AttributeNode* attributeNode, char* attributeName, char* constOrRef, char* valueOrNRE, char* possibleAttributeName) {
//	return;
//}

/*
						char** attributeNames = NULL;
						Value** attributeValues = NULL;

						attributeNames = (char**)malloc(sizeof(char*) * repeated.size());
						attributeValues = (Value**)malloc(sizeof(Value*) * repeated.size());

						//insert attributes of newly inserted element
				        vector<String_Pair>::iterator iterator;
						int i = 0;
				        for (iterator = repeated.begin(), i = 0; iterator != repeated.end(); iterator++, i++) {
							attributeNames[i] = (char*)malloc(iterator->first.size()+1);
							strcpy(attributeNames[i], iterator->first.c_str());
							
							attributeValues[i] = new Value(STRING_VALUE, (char*)iterator->second.c_str());

							cout << "in attribute insert" << endl;
							//iterator->first
						}

						DM_DataNode *tempAttributeNode = (DM_DataNode*) new DM_AttributeNode(0, 0, repeated.size(), attributeNames, attributeValues, tempElementNode->getKey());
						//-1 since attributes are not inserted as "children" like element nodes:
						dataMng->update(indexUpdater, fileid, DATAMNG_UPDATEOP_INSERTLEAFNODE, tempElementNode->getKey(), -1, tempAttributeNode);
*/

/*
						double newStartKey = atof(tempElementNode->getKey().toString());
						double newEndKey = atof(tempElementNode->getEndKey().toString());

						//update the tagname,id index here...
						ListNode indexBody;
						indexBody.SetStartPos(newStartKey);
						indexBody.SetEndPos(newEndKey);
						indexBody.SetLevel(tempElementNode->getLevel());
						TagNameAndNodeIdIndex::insertNode(textValue1, newStartKey, &indexBody, sizeof(indexBody), gistIndex);
						//need to modify the index inside the call to dataMng->update since parent
						//endKey is modified when leaf node inserted (for instance)
						//(and for non leaf node, descendants' levels are modified)
*/

/*				case QueryEvaluationTreeUpdatesNode::DELETE_ELEMENT_NODE:

					{
					cout << "DELETING NODE " << curSK.toString() << " IN ITERATOR..." << endl;
					//dataMng->update(indexUpdater, fileid, int op, currSK, childIndex, DM_DataNode *newnode);
					//works if leaf node, since index update is simple
					dataMng->update(indexUpdater, fileid, DATAMNG_UPDATEOP_DELETELEAFNODE, curSK, -1, NULL);

					char *tagName = dataNode->getTag();
					TagNameAndNodeIdIndex::deleteNode(tagName, atof(curSK.toString()), gistIndex);

					//temp:
					//dataMng->reorganizeFile("bib.xml");
					}
					break;
*/

/**
 * setInput() is a temporary hack until logical ID problem is handled in a better way.
 * see notes in constructor of this file.
 */
void UpdatesIterator::setInput(IteratorClass *input)
{
	//we are guaranteed that deletes will not cause new logical IDs to be issued
	//(since we just remove things from the DB, and the modifications that are done to nodes
	//such as previous & next sibling pointers, numChildren counts, numAttribute counts
	//all preserve the length of the modified nodes, and we do these "in place" with
	//fixedSizeModifyNode in the UpdateHandler
	//some other operations may or may not require new logical IDs (modify attribute value
	//for instance will only require a new logical id if the size of the new value is greater
	//than the size of the old value), but we won't know this up-front (i.e. here).

	//FIXED:
	//currently, DELETE_ATTRIBUTE_VALUE will cause new logical IDs to be issued
	//(if we can modify a node that has become smaller "in place" we can get rid of this)
	//DELETE_ATTRIBUTE also has this same restriction at the moment

	if (updateType == QueryEvaluationTreeUpdatesNode::DELETE_TEXT_NODE ||
		updateType == QueryEvaluationTreeUpdatesNode::DELETE_TREE ||
		updateType == QueryEvaluationTreeUpdatesNode::DELETE_ATTRIBUTE ||
		updateType == QueryEvaluationTreeUpdatesNode::DELETE_ATTRIBUTE_VALUE)
	{
		this->input = input;	
	}
	else
	{
		//we need to block... for simplicity, write to file and then read from it.
		tempFileName = "tempUpdateFile.txt";
		FileWriterIterator *writer = new FileWriterIterator(input, tempFileName.c_str(), dataMng);

		writer->next(inTuple);
		while (inTuple)
			writer->next(inTuple);

		// this will delete the writer and the rest of the evaluation plan.
		// after this, we are safe in terms of shore ids.
		delete writer;

		// now, let us read the file and update.
		this->input = new FileReaderIterator(tempFileName.c_str(), dataMng);
	}
}
