/*
COPYRIGHT  (c) 2000-2004 
THE REGENTS OF THE UNIVERSITY OF MICHIGAN
ALL RIGHTS RESERVED

PERMISSION IS GRANTED TO USE, COPY, CREATE DERIVATIVE WORKS AND
REDISTRIBUTE THIS SOFTWARE AND SUCH DERIVATIVE WORKS FOR NONCOMMERCIAL
EDUCATION AND RESEARCH PURPOSES, SO LONG AS NO FEE IS CHARGED, AND SO LONG
AS THE COPYRIGHT NOTICE ABOVE, THIS GRANT OF PERMISSION, AND THE
DISCLAIMER BELOW APPEAR IN ALL COPIES MADE; AND SO LONG AS THE NAME OF THE
UNIVERSITY OF MICHIGAN IS NOT USED IN ANY ADVERTISING OR PUBLICITY
PERTAINING TO THE USE OR DISTRIBUTION OF THIS SOFTWARE WITHOUT SPECIFIC,
WRITTEN PRIOR AUTHORIZATION.

THIS SOFTWARE IS PROVIDED AS IS, WITHOUT REPRESENTATION FROM THE
UNIVERSITY OF MICHIGAN AS TO ITS FITNESS FOR ANY PURPOSE, AND WITHOUT
WARRANTY BY THE UNIVERSITY OF MICHIGAN OF ANY KIND, EITHER EXPRESS OR
IMPLIED, INCLUDING WITHOUT LIMITATION THE IMPLIED WARRANTIES OF
MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE. THE REGENTS OF THE
UNIVERSITY OF MICHIGAN SHALL NOT BE LIABLE FOR ANY DAMAGES, INCLUDING
SPECIAL, INDIRECT, INCIDENTAL, OR CONSEQUENTIAL DAMAGES, WITH RESPECT TO
ANY CLAIM ARISING OUT OF OR IN CONNECTION WITH THE USE OF THE SOFTWARE,
EVEN IF IT HAS BEEN OR IS HEREAFTER ADVISED OF THE POSSIBILITY OF SUCH
DAMAGES.
*/

#ifndef __MeaningfulClosestCommonAncestorStructureIterator_h
#define __MeaningfulClosestCommonAncestorStructureIterator_h


#include "../Stack/stack.h"
#include "../Evaluator/Evaluator_definitions.h"
#include "../Evaluator/EvaluatorClass.h"
#include "MCCASStackNode.h"

//Global settings class
#include "../../Utilities/Settings.h"
extern Settings* gSettings;

//Global error handling class
#include "../../Utilities/ErrorInfoClass.h"
extern ErrorInfoClass globalErrorInfo;

#define MLCA_MAX (1.7976931348623157e+308)

/**
* An access method that takes the input trees from several sources and find out the 
* meaningful closest common ancestor structures for the sets of nodes
* @see IteratorClass
* @see EvaluatorClass
* @see WitnessTree
* @see MCCASStackNode
* @author Yunyao Li
*/

class MeaningfulClosestCommonAncestorStructureIterator : public IteratorClass
{
public:
	/**
	Constructor
	initializes the variables. 
	@param inputs is an array of input iterators.
	@param numInputs is the number of input iterators
	@param nre is the pointer to an array of nre values of input nodes
	@param assignedNre is the nre value assigned to the root of MLCAS
	@param dataMng an instance of the data manager.
	**/
	MeaningfulClosestCommonAncestorStructureIterator(IteratorClass **inputs,int numInputs, NREType *nre, NREType assignedNre, int expectedInputSize, DataMng *dataMng, int expectedDepth, serial_t fileID);

	/**
	Destructor
	releases memory used by array and result buffer.
	**/
	~MeaningfulClosestCommonAncestorStructureIterator();
	
	/**
	Access Method
	gets the next output tree from this iterator.
	@param node is a pointer that well be set to the output buffer or NULL (indicating that
	there are no more results).
	**/
	void next(WitnessTree *&node);
private:
	/**
	get the parent node of an input node
	**/
	void GetParentNode(ListNode * child, ListNode * parent);
	
	/**
	get the parent node of an  input node of ComplexListNode type
	**/
	void GetParentNode(ComplexListNode * child, ComplexListNode *& parent);

	/**
	find all the MCCAS with the same root
	**/
	bool FindMCCAS();
    
	/**
	expand a input node into a new stacknode and push it into stack2
	**/
	void PushInputAsNewStackNode(int setNum);

	/**
	Pop results from stack2
	**/
	int popStack(KeyType startPosition);

    /**
	find the node with minStartKey from unprocessed input nodes
	**/
	void findInput(int &setNum);

	/**
	write the nodes in buffer to its Shore list
	**/
	int WriteBufferToItsList(ContainerClass *cont, ShoreList *list);

	/**
	insert a stack node into another stack node
	**/
	int InsertStackNode(MCCASStackNode * source, MCCASStackNode * target);

	/**
	push an input node onto tempStack
	**/	
	void PushInput(int setNum);

	/**
	 Replace the node with its parent node
	**/
	int ReplaceWithParentNode(MCCASStackNode * childNode);

	/**
	 copy the list from a stack node into anoter stack node
	 **/
	int CopyList(MCCASStackNode * source, MCCASStackNode * target);

	/**
	write buffer or list record
	**/
	int WriteBufferOrListRid(ContainerClass *cont1, ShoreList *list1, ContainerClass *cont2);

	/**
	write record in ShoreList to buffer
	**/
	int WriteListRidToBuffer(ContainerClass *cont1, ShoreList *list1, ContainerClass *cont2);

	/**
	write records in container to buffer
	**/
	void WriteContainerToBuffer(ContainerClass *cont1,ContainerClass *cont2);

	/**
	construct MCCAS sub-structure
	if reset = true, then start from the beginning of buffer & list
	**/
	void ConstructSubMCCASByIndex(MCCASStackNode * node, int index, bool reset);

	/**
	set the scanCursor of a buffer
	**/
	void BackwardScan(ContainerClass * cont, int length);

	/**
	Merge sub-MCCAS associated with the given index
	**/
	bool MergeSubMCCAS(MCCASStackNode * node, int index);

	/**
	Start scan when marge sub-MCCAS for record for newID
	**/
	void StartScanForNewID(MCCASStackNode * node, int index, int curList);

	/**
	Restart scan
	**/
	int RestartScan(MCCASStackNode * node, int index, int curList);

	/**
	current min ID from the array curMinIDs within the same structure as specified the signature
	**/
	int OverallMinID(bitset<MAX_NUM_VARIABLE> signature);

	/**
	write the data into buffer
	**/
	int WriteNodeIntoItsBuffer(MCCASStackNode * node);

	/**
	judge whether one of the input tree is NULL
	If one of the inputs is NULL, then no MCCAS can be found, stop calculation
	**/
	bool haveNullInput;

	/**
	an IteratorClass that produces input for this iterator.
	**/
	IteratorClass **inputs;
	
	/**
	DataManager
	**/
	DataMng *dataMng;

	/**
	Inputs array inTuples
	**/
	WitnessTree **inTuple;

	/**
	number of used nodes in outputArray
	**/
	int used;

	/**
	The size of outputArray
	**/
	int bufSize;

	/**
	Array that hold output in sortedOrder of startKS
	**/
	WitnessTree * outputArray;

	/**
	Array that hold output
	**/
	WitnessTree ** outputArrayOfWitnessTree;

	/**
	number of variables involved in the query
	**/
	int numInputs;

	/**
	estimated number of nodes for each input
	**/
	int expectedInputSize;

	/**
	A buffer that holds the output tree.
	**/
	WitnessTree *resultBuffer;

	int expectedDepth;

	/**
	There are complexListNodes in the input
	**/
	bool haveComplexInput;

	/**
	temporary stacks holding intermediate results
	**/
	stack<MCCASStackNode> * tempStack;

	/**
	minimum level of unprocessed input nodes
	**/
	KeyType minStartPos0;

	/**
	the position of scan cursor
	**/
	int pos;

	/**
	stop or not, set stop to true, when no more MCCAS can be generated
	**/
	bool stop;

	/**---------------------------------------------**/
	/** varibles for the new algorithm - start      **/
	/**---------------------------------------------**/
	serial_t startID;
	lvid_t volumeID;
	serial_t fileID;
	rc_t rc;

	bool fileCreated;
	ContainerClass ** readContainer;
	int ListNodeSize;
	int ComplexListNodeSize;

	/**
	copy of the latest output stack node without the buffer & list
	**/
	MCCASStackNode * copyOfLatestMCCAS;

	/**
	copy of the endPos of latest input that has been rejected
	**/
	KeyType copyOfLatestInvalidInputEndPos;

	/**
	first time scan the list
	**/
	bitset<MAX_NUM_VARIABLE> startScan;

	/**
	finished scan the list
	**/
	bitset<MAX_NUM_VARIABLE> finishScan;

	/**
	id of the record where current scan cursor each list is
	**/
	int curMaxIDs[MAX_NUM_VARIABLE];

	/**
	id of the record where current scan cursor each list is
	**/
	int curMinIDs[MAX_NUM_VARIABLE];

	/**
	id of the record where current scan cursor each list is
	**/
	int newMaxIDs[MAX_NUM_VARIABLE];

	/**
	id of the record where current scan cursor each list is
	**/
	int newMinIDs[MAX_NUM_VARIABLE];

	/**
	startPos of the next scan of container
	**/
	int curBufScanCursor[MAX_NUM_VARIABLE];

	/**
	startPos of the next scan of container
	**/
	serial_t curListScanCursor[MAX_NUM_VARIABLE];

	/**
	startPos of the next scan of container
	**/
	int newBufScanCursor[MAX_NUM_VARIABLE];

	/**
	startPos of the next scan of container
	**/
	serial_t newListScanCursor[MAX_NUM_VARIABLE];

	/**
	nre values
	**/
	NREType *nre;

	NREType rootNRE;
	char *tmpStr;
	int numWrites;
};

#endif