/*
COPYRIGHT  (c) 2000-2004 
THE REGENTS OF THE UNIVERSITY OF MICHIGAN
ALL RIGHTS RESERVED

PERMISSION IS GRANTED TO USE, COPY, CREATE DERIVATIVE WORKS AND
REDISTRIBUTE THIS SOFTWARE AND SUCH DERIVATIVE WORKS FOR NONCOMMERCIAL
EDUCATION AND RESEARCH PURPOSES, SO LONG AS NO FEE IS CHARGED, AND SO LONG
AS THE COPYRIGHT NOTICE ABOVE, THIS GRANT OF PERMISSION, AND THE
DISCLAIMER BELOW APPEAR IN ALL COPIES MADE; AND SO LONG AS THE NAME OF THE
UNIVERSITY OF MICHIGAN IS NOT USED IN ANY ADVERTISING OR PUBLICITY
PERTAINING TO THE USE OR DISTRIBUTION OF THIS SOFTWARE WITHOUT SPECIFIC,
WRITTEN PRIOR AUTHORIZATION.

THIS SOFTWARE IS PROVIDED AS IS, WITHOUT REPRESENTATION FROM THE
UNIVERSITY OF MICHIGAN AS TO ITS FITNESS FOR ANY PURPOSE, AND WITHOUT
WARRANTY BY THE UNIVERSITY OF MICHIGAN OF ANY KIND, EITHER EXPRESS OR
IMPLIED, INCLUDING WITHOUT LIMITATION THE IMPLIED WARRANTIES OF
MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE. THE REGENTS OF THE
UNIVERSITY OF MICHIGAN SHALL NOT BE LIABLE FOR ANY DAMAGES, INCLUDING
SPECIAL, INDIRECT, INCIDENTAL, OR CONSEQUENTIAL DAMAGES, WITH RESPECT TO
ANY CLAIM ARISING OUT OF OR IN CONNECTION WITH THE USE OF THE SOFTWARE,
EVEN IF IT HAS BEEN OR IS HEREAFTER ADVISED OF THE POSSIBILITY OF SUCH
DAMAGES.
*/

#include "MCCASStackNode.h"

using namespace std;

/**
* Define data structure MCCASStackNode and operations allowed on the data structure used by MLCAS(MCCAS)
* MeaningfulClosestCommonAncestorStructure
* @see SBJoinDescStackNode
* @see WitnessTree
* @author Yunyao Li
*/

MCCASStackNode :: MCCASStackNode()
{
    SBJoinDescStackNode::SBJoinDescStackNode();
	this->actualAncsWithSubtree = NULL;
    this->initialize();
}
	
/**
Destructor.
**/
MCCASStackNode :: ~MCCASStackNode()
{	
	if (this->actualAncsWithSubtree)
	{
		delete this->actualAncsWithSubtree;
	}
}

/**
Process Method.
initializes the data members.
**/
void MCCASStackNode :: initialize()
{
	SBJoinDescStackNode::initialize();

	// set everybit of the signature to be 0
	this->signature.reset();
	this->key = false;
	this->empty = true;
	this->numOfStructure = 0;
	this->keyValue = -1;

	if (this->actualAncsWithSubtree) 
		delete this->actualAncsWithSubtree;

	this->actualAncsWithSubtree = new WitnessTree;

	for (int i = 0; i < MAX_NUM_VARIABLE; i++)
	{
		this->minID[i] = -1;
		this->maxID[i] = -1;
	}
	this->globalMaxID = -1;
	this->globalMinID = -1;
}

/**
Access Method.
@returns the binary number of the top stack node
this number works as signature of the node, similar to the signature of a signature file.
**/
bitset<MAX_NUM_VARIABLE>  MCCASStackNode :: getSignature()
{
	return this->signature;
}

/**
Process Method.
set the value of the signature
**/
void MCCASStackNode :: setSignature(bitset<MAX_NUM_VARIABLE> signature)
{
	this->signature = signature;
}

/**
whether current node is a mccas
judge by checking whether current node is a all 1 node
**/
bool MCCASStackNode :: isMCCAS(int num)
{
	bitset<MAX_NUM_VARIABLE> temp;

	temp = this->signature;

	for (int i = 0; i < num; i++)
		temp.flip(i);

	return temp.none();
}

/**
whether current node belongs to a tagname in query itself
**/
bool  MCCASStackNode :: isKey()
{
	return key;
}

/**
mark current node to be a node belonging to a tagname in query
**/
void  MCCASStackNode :: setKey()
{
	this->key = true;
}

/**
mark current node to be a node not belonging to a tagname in query
**/
void  MCCASStackNode :: resetKey()
{
	key = false;
}

/**
print out the content of node
1. all == true: print out nodes along with other info
2. all == false, print out other info only without the nodes
**/
void  MCCASStackNode :: printNode(bool all)
{
	cout << "Information about the node itself" << endl;

	all = all;
	if (this->isSimple())
		printf("start pos = %f, end pos = %f, level = %d\n, offset = %d\n",
		       this->GetActualAncs()->GetStartPos(),
			   this->GetActualAncs()->GetEndPos(),
			   this->GetActualAncs()->GetLevel(),
			   this->GetActualAncs()->GetOffset());
	else
			printf("start pos = %f, end pos = %f, level = %d\n, offset = %d\n",
		       this->GetActualAncsComplex()->GetStartPos(),
			   this->GetActualAncsComplex()->GetEndPos(),
			   this->GetActualAncsComplex()->GetLevel(),
			   this->GetActualAncsComplex()->GetOffset());

	if (key)
		cout << "isKey = true" << endl;
	else
		cout << "isKey = false" << endl;
}

/**
copy MCCAS stack node
**/
void MCCASStackNode :: copyStackNode(MCCASStackNode * stacknode)
{
	if (stacknode->isSimple())
		this->SetActualAncs(stacknode->GetActualAncs());
	else
		this->SetActualAncsComplex(stacknode->GetActualAncsComplex());
    
	this->setSignature(stacknode->getSignature());

	if (stacknode->isKey())
		this->setKey();
	else
		this->resetKey();

	this->numOfStructure = stacknode->GetNumOfStructure();

	for (int i = 0; i < this->numOfStructure; i++)
	{
		this->signOfLists[i] = stacknode->GetSignByIndex(i);
	}

	this->globalMaxID = stacknode->GetGlobalMax();

	this->setActualAncsWithSubtree(stacknode->GetActualAncsWithSubtree());
}

void MCCASStackNode :: SetBufferByIndex(int index)
{
	this->listBuffers[index].Initialize();
}

void MCCASStackNode :: SetListByIndex(int index)
{
	this->lists[index].Initialize();
}

ContainerClass *MCCASStackNode :: GetBufferByIndex(int index)
{
	return &(this->listBuffers[index]);
}

ShoreList *MCCASStackNode :: GetListByIndex(int index)
{
	return &(this->lists[index]);
}

bitset<MAX_NUM_VARIABLE> MCCASStackNode :: GetSignByIndex(int index)
{
	return this->signOfLists[index];
}

void MCCASStackNode :: SetSignByIndex(int index, bitset<MAX_NUM_VARIABLE> newSign)
{
	this->signOfLists[index] = newSign;
}

void MCCASStackNode :: SetListsVolumeAndFileIDsByIndex(lvid_t volumeID,serial_t fileID, int index)
{	
	this->lists[index].SetVolumeID(volumeID);
	this->lists[index].SetFileID(fileID);
}

void MCCASStackNode :: SetListsVolumeAndFileIDs(lvid_t volumeID,serial_t fileID, int numOfLists)
{
	SBJoinDescStackNode::SetListsVolumeAndFileIDs(volumeID,fileID);

	for (int i = 0; i < numOfLists; i++)
	{
		this->SetListsVolumeAndFileIDsByIndex(volumeID,fileID,i);
	}
}

void MCCASStackNode :: SetNumOfStructure(int numOfLists)
{
	this->numOfStructure = numOfLists;
}
	
int MCCASStackNode :: GetNumOfStructure()
{
	return this->numOfStructure;
}


void MCCASStackNode :: SetMaxByIndex(int index, int id)
{
	this->maxID[index] = id;

	if (id > this->globalMaxID || this->globalMaxID == -1)
		this->globalMaxID = id;
}

int MCCASStackNode :: GetMaxByIndex(int index)
{
	return this->maxID[index];
}


void MCCASStackNode :: SetMinByIndex(int index, int id)
{
	this->minID[index] = id;
	if (id < this->globalMinID || this->globalMinID == -1)
		this->globalMinID = id;
}

int MCCASStackNode :: GetMinByIndex(int index)
{
	return this->minID[index];
}

void MCCASStackNode :: SetGlobalMax(int maxID)
{
	this->globalMaxID = maxID;
}

	
int MCCASStackNode :: GetGlobalMax()
{
	return this->globalMaxID;
}

void MCCASStackNode :: SetGlobalMin(int minID)
{
	this->globalMinID = minID;
}

	
int MCCASStackNode :: GetGlobalMin()
{
	return this->globalMinID;
}

int MCCASStackNode :: TypeOfRelationship(bitset<MAX_NUM_VARIABLE> signature)
{
	bitset<MAX_NUM_VARIABLE> resultAND, resultOR;

	for (int i = 0; i < this->numOfStructure; i ++)
	{
		if (this->signOfLists[i] == signature)
			return EQUAL;
		else 
		{
			resultAND = this->signOfLists[i] & signature;

			if (resultAND.any())
			{
				resultOR = this->signOfLists[i] | signature;

				if (this->signOfLists[i] == resultOR)
					return SUBSUMED_BY;
				else if (signature == resultOR)
					return CONSUMED_BY;
				else
					return HAVE_OVERLAP;
			}	
		}
	}
	
	return NO_OVERLAP;
}

bool MCCASStackNode :: IsEmpty()
{
	return this->empty;
}
	
void MCCASStackNode :: setEmpty()
{
	this->empty = false;
}

void MCCASStackNode :: resetEmpty()
{
	this->empty = true;
}

int MCCASStackNode :: GetKeyValue()
{
	return this->keyValue;
}

void MCCASStackNode :: SetKeyValue(int keyValue)
{
	this->keyValue = keyValue;
}

bool MCCASStackNode :: deleteSignByIndex(int index)
{
	if (index >= this->numOfStructure)
		return false;

	for (int i = index; i < this->numOfStructure - 1; i++)
	{
		this->signOfLists[i] = this->signOfLists[i + 1];
	}

	this->numOfStructure--;

	this->signOfLists[this->numOfStructure].reset();

	return true;
}

WitnessTree * MCCASStackNode :: GetActualAncsWithSubtree()
{
	return this->actualAncsWithSubtree;
}

void MCCASStackNode :: setActualAncsWithSubtree(WitnessTree * tree)
{
	if (tree->isSimple())
	{
		this->actualAncsWithSubtree->appendList((ListNode *)tree->getBuffer(), tree->length(), false);
	}
	else
	{
		this->actualAncsWithSubtree->appendList((ComplexListNode *)tree->getBuffer(), tree->getDataMng(), tree->length(), false);
	}
}

/* added by Shurug to prepare to delete this node when
	increasing the stack size*/
void MCCASStackNode::prepareToCopyDelete()
{
	SBJoinDescStackNode::prepareToCopyDelete();
	for (int i=0; i<MAX_NUM_VARIABLE; i++)
		this->listBuffers[i].nullifyContainer();
}