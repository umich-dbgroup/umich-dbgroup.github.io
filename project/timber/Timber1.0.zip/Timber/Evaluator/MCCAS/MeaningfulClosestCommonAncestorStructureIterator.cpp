/*
COPYRIGHT  (c) 2000-2004 
THE REGENTS OF THE UNIVERSITY OF MICHIGAN
ALL RIGHTS RESERVED

PERMISSION IS GRANTED TO USE, COPY, CREATE DERIVATIVE WORKS AND
REDISTRIBUTE THIS SOFTWARE AND SUCH DERIVATIVE WORKS FOR NONCOMMERCIAL
EDUCATION AND RESEARCH PURPOSES, SO LONG AS NO FEE IS CHARGED, AND SO LONG
AS THE COPYRIGHT NOTICE ABOVE, THIS GRANT OF PERMISSION, AND THE
DISCLAIMER BELOW APPEAR IN ALL COPIES MADE; AND SO LONG AS THE NAME OF THE
UNIVERSITY OF MICHIGAN IS NOT USED IN ANY ADVERTISING OR PUBLICITY
PERTAINING TO THE USE OR DISTRIBUTION OF THIS SOFTWARE WITHOUT SPECIFIC,
WRITTEN PRIOR AUTHORIZATION.

THIS SOFTWARE IS PROVIDED AS IS, WITHOUT REPRESENTATION FROM THE
UNIVERSITY OF MICHIGAN AS TO ITS FITNESS FOR ANY PURPOSE, AND WITHOUT
WARRANTY BY THE UNIVERSITY OF MICHIGAN OF ANY KIND, EITHER EXPRESS OR
IMPLIED, INCLUDING WITHOUT LIMITATION THE IMPLIED WARRANTIES OF
MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE. THE REGENTS OF THE
UNIVERSITY OF MICHIGAN SHALL NOT BE LIABLE FOR ANY DAMAGES, INCLUDING
SPECIAL, INDIRECT, INCIDENTAL, OR CONSEQUENTIAL DAMAGES, WITH RESPECT TO
ANY CLAIM ARISING OUT OF OR IN CONNECTION WITH THE USE OF THE SOFTWARE,
EVEN IF IT HAS BEEN OR IS HEREAFTER ADVISED OF THE POSSIBILITY OF SUCH
DAMAGES.
*/

#include "MeaningfulClosestCommonAncestorStructureIterator.h"

using namespace std;

/**
* An access method that takes the input trees from several sources and find out the 
* meaningful closest common ancestor structures for the sets of nodes
* @see IteratorClass
* @see EvaluatorClass
* @see WitnessTree
* @see MCCASStackNode
* @author Yunyao Li
*/

MeaningfulClosestCommonAncestorStructureIterator :: MeaningfulClosestCommonAncestorStructureIterator(IteratorClass **inputs,int numInputs, NREType *nre, NREType assignedNre, int expectedInputSize, DataMng *dataMng, int expectedDepth, serial_t fileID)
{
	// initialize the private variables
    this->inputs = inputs;
	this->numInputs = numInputs;
	numWrites = 0;
	fileCreated = true;
	this->fileID = fileID;
	if (expectedInputSize > 0)
		this->expectedInputSize = expectedInputSize;
	else
		this->expectedInputSize = gSettings->getIntegerValue("INITIAL_DEFAULT_DEPTH",16);
	
	if (expectedDepth > 0)
		this->expectedDepth = expectedDepth;
	else
		this->expectedDepth = gSettings->getIntegerValue("INITIAL_DEFAULT_DEPTH",16);

	this->dataMng = dataMng;	
	this->volumeID = dataMng->getVolumeID();
	this->haveNullInput = false;
	this->haveComplexInput = false;
	this->minStartPos0 = MLCA_MAX;
	this->used = 0;
	this->bufSize = this->expectedInputSize;
	this->pos = 0;
	this->stop = false;
	this->copyOfLatestMCCAS = new MCCASStackNode;
	this->copyOfLatestInvalidInputEndPos = -1;
	this->startScan.reset();
	this->finishScan.reset();
	this->outputArray = new WitnessTree;
	this->outputArray->SetUsed(this->numInputs + 1);
	this->nre = nre;
	this->rootNRE = assignedNre;

	this->inTuple = new WitnessTree * [numInputs];
	this->tempStack = new stack<MCCASStackNode>(this->expectedInputSize);

	tmpStr = new char[gSettings->getIntegerValue("CONTAINER_SIZE",CONTAINER_SIZE_DEFAULT)];
	readContainer = NULL;
	for (int i = 0; i < this->numInputs; i++)
	{
		inputs[i]->next(inTuple[i]);

		// if one of the input is empty
		if (!this->inTuple[i])
		{
			this->haveNullInput = true;
			break;
		}

		// if one of the input is complexListNode
		if (!this->inTuple[i]->isSimple())
		{
			this->haveComplexInput = true;
		}	

		this->curMaxIDs[i] = -1;
		this->curMinIDs[i] = -1;
	}

	// set up NRE table for the output witnessTree, 
	// this table will remain the same for all the output
	// therefore is only set up once
	this->outputArrayOfWitnessTree = new WitnessTree * [numInputs + 1];


    for (int i = 0; i < this->numInputs + 1; i++)
	{
		this->outputArrayOfWitnessTree[i] = new WitnessTree(LIST_NODE_WITH_DATA,dataMng);
	}

	this->ListNodeSize = sizeof(ListNode);
	this->ComplexListNodeSize = sizeof(ComplexListNode);

	resultBuffer = new WitnessTree(LIST_NODE_WITH_DATA,dataMng);

	if (!this->haveNullInput)
	{
		readContainer = new ContainerClass * [this->numInputs];

/*		rc = ss_m::create_file(volumeID, fileID,ss_m::t_regular);
		if (rc) 
		{
			// error of creating file
			strstream msg;
			msg<<rc<<'\0';
			globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"Evaluator",__FILE__,msg.rdbuf()->str());
			this->haveNullInput = true;
			return;				
		}

		fileCreated = true;*/
		int maxIDs = gSettings->getIntegerValue("MAX_ID_PER_FILE_STRUCTURAL_JOINS",10000);
		rc = ss_m::create_id(volumeID,maxIDs,startID);
		
		if (rc) 
		{
			// error of creating id
			strstream msg;
			msg<<rc<<'\0';
			globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"Evaluator",__FILE__,msg.rdbuf()->str());
			this->haveNullInput = true;
			return;				
		}	
		numWrites = maxIDs;
	}
}

/**
Destructor
frees the output buffer and so.
**/
MeaningfulClosestCommonAncestorStructureIterator :: ~MeaningfulClosestCommonAncestorStructureIterator()
{
	if (resultBuffer)
	{
		delete resultBuffer;

		if (outputArray)
			delete outputArray;
	}

	if (tmpStr) delete [] tmpStr;

	if (copyOfLatestMCCAS)
		delete copyOfLatestMCCAS;

	if (this->tempStack)
	{		
		delete this->tempStack;
	}

	if (this->outputArrayOfWitnessTree)
	{
	    for (int i = 0; i < this->numInputs + 1; i++)
			delete this->outputArrayOfWitnessTree[i];

		delete [] outputArrayOfWitnessTree;
	}

	if (this->readContainer)
	{	
		delete [] readContainer;
	}

	if (inTuple)
	{
		delete [] inTuple;
	}
		// destroy the file, if any has been created	
	if (fileCreated)
	{
		rc = ss_m::destroy_file(volumeID, fileID,true,numWrites);
		
		if (rc) 
		{
			// error when destroying file
			strstream msg;
			msg<<rc<<'\0';
			globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"Evaluator",__FILE__,msg.rdbuf()->str());
			return;				
		}
	}

	if (inputs)
	{
		for (int i=0; i<numInputs; i++)
			delete inputs[i];
		
		delete [] inputs;
	}
}
	
/**
Access Method
gets the next output tree from this iterator.
@param node is a pointer that well be set to the output buffer or NULL (indicating that
there are no more results).
**/
void MeaningfulClosestCommonAncestorStructureIterator :: next(WitnessTree *&node)
{
#ifdef EVAL_TIME_OUT
	clock_t currTime = clock();
	double queryDuration = (double)(currTime - gQueryStartTime) / CLOCKS_PER_SEC;
	if (queryDuration >= gTimeOutAfter)
	{
		globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"Evaluator",__FILE__,"Query Timed Out.");
		node = NULL;
		return;
	}
#endif
	bool merged = true;
	ComplexListNode * complexTempRoot;
	ListNode * tempRoot;

	// empty the buffer
	this->resultBuffer->initialize();

	if (this->haveNullInput && this->copyOfLatestMCCAS->IsEmpty())
	{	
		node = NULL;
		return;	
	}
	else
	{		
		// if a copy of LatestMCCAS exists
		// a copy of latest MCCAS is a rootedTree which contains all the MLCAS with the same root
		if (!this->copyOfLatestMCCAS->IsEmpty())
		{	
			// construct MLCAS from the c0 opy first
			// scan each list from start to end
			// there are multiple level of internal loops here
			for (int i = 0; i < this->copyOfLatestMCCAS->GetNumOfStructure(); i++)
			{	
				if(!this->MergeSubMCCAS(this->copyOfLatestMCCAS, i))
				{	
					if (i < this->copyOfLatestMCCAS->GetNumOfStructure() - 1)
					{
						if (this->RestartScan(this->copyOfLatestMCCAS, i, this->numInputs) == FAILURE)
						{
							node = NULL;
							return;
						}
					}
					else
					{
						merged = false;	
						break;
					}					
				}
				else
				{
					break;
				}
			}
			
			// output the merged MLCAS
			if (merged)
			{							
				// copy the root of MLCAS
				this->resultBuffer->appendList((ComplexListNode *)this->outputArrayOfWitnessTree[numInputs]->getBuffer(), this->dataMng, this->outputArrayOfWitnessTree[numInputs]->length(), true);

				// copy the output array of witnesstrees to the output buffer
				for (i = 0; i < this->numInputs; i++)
				{
					this->resultBuffer->appendList((ComplexListNode *)this->outputArrayOfWitnessTree[i]->getBuffer(), this->dataMng, this->outputArrayOfWitnessTree[i]->length(), true);				
				}

				node = this->resultBuffer;

				// if all the MLCAS contained in the copy have been constructed
				// delete the copy
				if (this->finishScan.count() == (unsigned)this->numInputs)
					this->copyOfLatestMCCAS->resetEmpty();

				return;
			}
		} 

		// if no copy exists, find one
		if (this->FindMCCAS())
		{			
			for (int i = 0; i < this->copyOfLatestMCCAS->GetNumOfStructure(); i++)
			{
				this->MergeSubMCCAS(this->copyOfLatestMCCAS, i);
			}

			// initialize the buffer
			this->outputArrayOfWitnessTree[this->numInputs]->SetUsed(0);

			// copy the root node of MLCAS
			if (this->copyOfLatestMCCAS->isSimple())
			{		
				tempRoot = this->copyOfLatestMCCAS->GetActualAncs();
				tempRoot->setNRE(this->rootNRE);
				this->outputArrayOfWitnessTree[this->numInputs]->appendList(tempRoot,1, false);
				this->resultBuffer->appendList(tempRoot, 1, true);
			}
			else
			{				
				complexTempRoot = this->copyOfLatestMCCAS->GetActualAncsComplex();
				complexTempRoot->setNRE(this->rootNRE);
				this->outputArrayOfWitnessTree[this->numInputs]->appendList(complexTempRoot, this->dataMng, 1, false);
				this->resultBuffer->appendList(complexTempRoot, this->dataMng, 1, true);
			}
			
			// copy the output array of witnesstrees to the output buffer
			for (i = 0; i < this->numInputs; i++)
			{
				this->resultBuffer->appendList((ComplexListNode *)this->outputArrayOfWitnessTree[i]->getBuffer(), this->dataMng, this->outputArrayOfWitnessTree[i]->length(), true);				
			}
		
			node = this->resultBuffer;
			return;
		}          
		else
		{
			node = NULL;
			return;
		}	
	}
}

/**
get the parent node of an input node
**/
void MeaningfulClosestCommonAncestorStructureIterator :: GetParentNode(ComplexListNode * child, ComplexListNode *& parent)
{
	WitnessTree * inputArray;
	inputArray = new WitnessTree(LIST_NODE_WITH_DATA,dataMng);
	inputArray->insertNode(0, child, dataMng);
	char fileIndex = ((ComplexListNode *)inputArray->getNodeByIndex(0))->getFileIndex();	
	int r = EvaluatorClass::getAncs(inputArray,0,1,dataMng,EvaluatorClass::getFileID(fileIndex));
	memcpy(parent,inputArray->getNodeByIndex(r),sizeof(ComplexListNode));
	delete inputArray;
}

/**
get the parent node of an input node
**/
void MeaningfulClosestCommonAncestorStructureIterator :: GetParentNode(ListNode * child, ListNode * parent)
{
	WitnessTree * inputArray;
	inputArray = new WitnessTree;
	inputArray->insertNode(0, child);
	char fileIndex = ((ListNode *)inputArray->getNodeByIndex(0))->getFileIndex();	
	int r = EvaluatorClass::getAncs(inputArray,0,1,dataMng,EvaluatorClass::getFileID(fileIndex));
	memcpy(parent,inputArray->getNodeByIndex(r),sizeof(ListNode));
	delete inputArray;
}    


/**
expand a input node into a new stacknode and push it into stack2
**/
void MeaningfulClosestCommonAncestorStructureIterator :: PushInputAsNewStackNode(int setNum)
{
	int curMaxID = 0;
	bitset<MAX_NUM_VARIABLE> newSignature, resultSign;
	newSignature.reset();
	newSignature.set(setNum);

	MCCASStackNode * stackTop;
	stackTop = this->tempStack->GetTop();
		
	if (this->tempStack->IsEmpty())
	{
		curMaxID = 0;		
	}
	else
	{
		switch (stackTop->TypeOfRelationship(newSignature))
		{
			// one of structures already contains the same keyword
			case SUBSUMED_BY:			
				for (int i = 0; i < stackTop->GetNumOfStructure(); i++)
				{
					resultSign = stackTop->GetSignByIndex(i) & newSignature;
					
					if (resultSign.any())
					{
						curMaxID = stackTop->GetGlobalMax();
						curMaxID++;
						break;
					}
				}
				break;
			// one of the structure is the same as the one contained by the stack top
			case EQUAL:	
				for (int i = 0; i < stackTop->GetNumOfStructure(); i++)
				{
					resultSign = stackTop->GetSignByIndex(i) & newSignature;
					
					if (resultSign.any())
					{
						curMaxID = stackTop->GetMaxByIndex(setNum);
						break;
					}
				}
				break;
			// the stack top does not contain the new keyword
			case NO_OVERLAP:
				curMaxID = stackTop->GetGlobalMin();
				break;
		}
	}
		
	if (!this->inTuple[setNum]->isSimple())
		this->tempStack->Push((ComplexListNode *)this->inTuple[setNum]->findNodeNRE(nre[setNum]));
	else
		this->tempStack->Push((ListNode *)this->inTuple[setNum]->findNodeNRE(nre[setNum]));

	//  copy the input witnessTree
	this->tempStack->GetTop()->setActualAncsWithSubtree(this->inTuple[setNum]);

	// set up global maxID so far
	this->tempStack->GetTop()->SetGlobalMin(curMaxID);
	this->tempStack->GetTop()->SetGlobalMax(curMaxID);
	this->tempStack->GetTop()->SetMaxByIndex(setNum, curMaxID);
	this->tempStack->GetTop()->SetMinByIndex(setNum, curMaxID);
    
	// set volume & fileID info
	this->tempStack->GetTop()->SetListsVolumeAndFileIDs(volumeID, fileID,numInputs);
	
	// initialize the buffers & link lists
	for (int i = 0; i < this->numInputs; i++)
	{
		this->tempStack->GetTop()->SetBufferByIndex(i);
		this->tempStack->GetTop()->SetListByIndex(i);
	}	

	// add the input node into the corresponding keyword buffer
	this->tempStack->GetTop()->SetSignByIndex(0, newSignature);
	this->tempStack->GetTop()->SetNumOfStructure(1);
    this->tempStack->GetTop()->setSignature(newSignature);
	this->tempStack->GetTop()->setKey();
	this->tempStack->GetTop()->SetKeyValue(setNum);
}

void MeaningfulClosestCommonAncestorStructureIterator :: PushInput(int setNum)
{
	if (this->tempStack->IsEmpty())
	{
		this->PushInputAsNewStackNode(setNum);
		return;
	}
	
	int curLevel, newLevel;
	
	MCCASStackNode * stackTop;	

	// if there is a node being rejected before the current input
	if (this->copyOfLatestInvalidInputEndPos != -1)
	{
		// reject all the nodes that are descendant of it
		if (this->inTuple[setNum]->isSimple())
		{
			if (this->copyOfLatestInvalidInputEndPos > ((ListNode *)this->inTuple[setNum]->findNodeNRE(nre[setNum]))->GetEndPos())
			{
				return;
			}
		}
		else
		{
			if (this->copyOfLatestInvalidInputEndPos > ((ComplexListNode *)this->inTuple[setNum]->findNodeNRE(nre[setNum]))->GetEndPos())
			{
				return;
			}
		}			
	}

	this->copyOfLatestInvalidInputEndPos = -1; 

	if (this->inTuple[setNum]->isSimple())
	{
		// if popStack
		if(popStack(((ListNode *)this->inTuple[setNum]->findNodeNRE(nre[setNum]))->GetStartPos()) == SUCCESS)
		{   
			this->PushInputAsNewStackNode(setNum);
			return;
		}
		else
		{		
			stackTop = this->tempStack->GetTop();

			if (stackTop->isSimple())
				curLevel = stackTop->GetActualAncs()->GetLevel();
			else
				curLevel = stackTop->GetActualAncsComplex()->GetLevel();

			newLevel = ((ListNode *)this->inTuple[setNum]->findNodeNRE(nre[setNum]))->GetLevel();

			// the input node is a child node of current stack top node
			if (newLevel == curLevel + 1)
			{
				this->PushInputAsNewStackNode(setNum);
				return;
			}
			else
			{
				this->PushInputAsNewStackNode(setNum);
				return;
			}
		}
	}
	else
	{
		// if popStack
		if(popStack(((ComplexListNode *)this->inTuple[setNum]->findNodeNRE(nre[setNum]))->GetStartPos()) == SUCCESS)
		{
			this->PushInputAsNewStackNode(setNum);
			return;
		}
		else
		{	
			stackTop = this->tempStack->GetTop();

			if (stackTop->isSimple())
				curLevel = stackTop->GetActualAncs()->GetLevel();
			else
				curLevel = stackTop->GetActualAncsComplex()->GetLevel();

			newLevel = ((ComplexListNode *)this->inTuple[setNum]->findNodeNRE(nre[setNum]))->GetLevel();

			// the input node is a child node of current stack top node
			if (newLevel == curLevel + 1)
			{
				this->PushInputAsNewStackNode(setNum);
				return;
			}
			else
			{
				this->PushInputAsNewStackNode(setNum);
				return;
			}
		}
	}
}

int MeaningfulClosestCommonAncestorStructureIterator :: CopyList(MCCASStackNode * source, MCCASStackNode * target)
{
	target->setSignature(target->getSignature() | source->getSignature());

	for (int i = 0; i < this->numInputs; i++)
	{
		if ( source->BufferExistsAndNotEmpty(source->GetBufferByIndex(i))
			|| !(source->EmptyListOfBuffers(source->GetListByIndex(i))))
		{	
			if (WriteBufferOrListRid(source->GetBufferByIndex(i),source->GetListByIndex(i),
								target->GetBufferByIndex(i)) == FAILURE)
								return FAILURE;
		}
	}

	return SUCCESS;
}

int MeaningfulClosestCommonAncestorStructureIterator::WriteBufferOrListRid(ContainerClass *cont1, ShoreList *list1, 
										  ContainerClass *cont2)
{
	if (!(list1->IsEmpty()))
		return WriteListRidToBuffer(cont1,list1,cont2);
	else
	{
		WriteContainerToBuffer(cont1,cont2);
		return SUCCESS;
	}
}


int MeaningfulClosestCommonAncestorStructureIterator::WriteListRidToBuffer(ContainerClass *cont1, ShoreList *list,
											  ContainerClass *cont2)
{
	if (WriteBufferToItsList(cont1,list) == FAILURE)
		return FAILURE;

	serial_t h = list->GetHead();
	serial_t t = list->GetTail();
	MCCASStackNode::AddToBuffer(cont2,(char *) (&(h)),sizeof(list->GetHead()));
	MCCASStackNode::AddToBuffer(cont2,(char *) (&(t)),sizeof(list->GetTail()));
	return SUCCESS;
}

void MeaningfulClosestCommonAncestorStructureIterator::WriteContainerToBuffer(ContainerClass *cont1,
											  ContainerClass *cont2)
{
	if (cont1->IsEmpty())
		return;

	int length = cont1->GetAddCursor();
//	char tmpStr[CONTAINER_SIZE];
	cont1->GetData(0,length,tmpStr);
	MCCASStackNode::AddToBuffer(cont2,tmpStr,length);
}

/**
 Pop stack
 **/
int MeaningfulClosestCommonAncestorStructureIterator :: popStack(KeyType startPosition)
{
	if (this->tempStack->IsEmpty())
		return FAILURE;

	if (startPosition == -1)
		// this means POP all
		startPosition = MLCA_MAX;

	while (startPosition > this->tempStack->GetTop()->GetActualAncs()->GetEndPos())
	{
		// pop top element in the stack
		MCCASStackNode * stackTop = this->tempStack->GetTop();

		if (stackTop->isMCCAS(this->numInputs))
		{
			// there is no MCCAS found so far
			if (this->copyOfLatestMCCAS->IsEmpty())
			{
				if (stackTop->isKey())
				{					
					if (this->WriteNodeIntoItsBuffer(stackTop) == FAILURE)
						return FAILURE;
				}

				this->startScan.reset();
				this->finishScan.reset();
				this->copyOfLatestMCCAS->resetEmpty();
				this->copyOfLatestMCCAS->initialize();
				this->copyOfLatestMCCAS->copyStackNode(stackTop);
				if (this->CopyList(stackTop, this->copyOfLatestMCCAS) == FAILURE)
					return FAILURE;	
				this->copyOfLatestMCCAS->setEmpty();
				this->tempStack->Pop();
				// can stop computing & start to output now
				this->stop = true;
			}
			else
			{
				if (stackTop->GetActualAncs()->isAncsOf(this->copyOfLatestMCCAS->GetActualAncs()))
				{
					this->stop = false;
				}
				else
				{
					if (stackTop->isKey())
					{						
						if (this->WriteNodeIntoItsBuffer(stackTop) == FAILURE)
							return FAILURE;
					}

					this->copyOfLatestMCCAS->copyStackNode(stackTop);
					if (this->CopyList(stackTop, this->copyOfLatestMCCAS) == FAILURE)
						return FAILURE;
					this->tempStack->Pop();
					// can stop computing & start to output now
					this->stop = true;
				}
			}
			
			// reset global max
			while(!this->tempStack->IsEmpty())
				this->tempStack->Pop();
			stackTop->SetGlobalMax(0);
			return SUCCESS;
		}
		else
		{	
			// there is no other element in the stack
			// or the next element in the stack is not a parent node of the current stack top
			// and the node is not the root of the XML document yet
			if (stackTop->GetActualAncs()->GetLevel() > 1 &&
				(this->tempStack->Size() == 1 ||
				!this->tempStack->GetByIndex(this->tempStack->Size()-2)->GetActualAncs()->isParentOf(stackTop->GetActualAncs())))
			{
				// replace the node with its parent node
				if (this->ReplaceWithParentNode(this->tempStack->GetTop()) == FAILURE)
					return FAILURE;
				this->tempStack->GetTop()->resetKey();
			}

			else if (this->tempStack->Size() > 1)
			{
				MCCASStackNode * poped;
				poped = this->tempStack->Pop();
				stackTop = this->tempStack->GetTop();
				if (this->InsertStackNode(poped, stackTop) == FAILURE)
					return FAILURE;
			}
		else
			break;
		}		
	}
	return FAILURE;
}

/**
find the node with maxLevel and minStartKey from unprocessed input nodes
**/
void MeaningfulClosestCommonAncestorStructureIterator :: findInput(int &setNum)
{
	int i;
	KeyType minTempStartPos = MLCA_MAX;
	ListNode * temp;
	ComplexListNode * complexTemp;

	setNum = -1;

	this->haveNullInput = true;

	for (i = 0; i < this->numInputs; i++)
	{			
		if (this->inTuple[i])
		{
			if (this->inTuple[i]->isSimple())
			{				
				//temp = (ListNode *)this->inTuple[i]->getNodeByIndex(0);
				temp = (ListNode *)this->inTuple[i]->findNodeNRE(nre[i]);
	            			
				this->haveNullInput = false;

				if (temp->GetStartPos() < minTempStartPos)
				{
					minTempStartPos = temp->GetStartPos();
					setNum = i;										
				}
			}
			else
			{						
				//complexTemp = (ComplexListNode *)this->inTuple[i]->getNodeByIndex(0);
				complexTemp = (ComplexListNode *)this->inTuple[i]->findNodeNRE(nre[i]);
	            
				this->haveNullInput = false;

				if (complexTemp->GetStartPos() < minTempStartPos)
				{
						minTempStartPos = complexTemp->GetStartPos();
						setNum = i;	
				}
			}	
		}  
	}

	// no input node could be found
	if (setNum == -1)
	{
		return;
	}
	
	this->minStartPos0 = minTempStartPos;    
}

int MeaningfulClosestCommonAncestorStructureIterator::WriteBufferToItsList(ContainerClass *cont, ShoreList *list)
{
	if (cont->IsEmpty())
		return SUCCESS;

	if (list->IsEmpty())
	{
		serial_t currRecID = startID;

		if (startID.increment(1) == true)
			//overflow of shore logical ids
		{
			globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"Evaluator",__FILE__,"Shore Logical ID overflow.");
			return FAILURE;
		}

		if (MCCASStackNode::WriteBufferToList(cont,list,fileID,volumeID,currRecID,startID) == FAILURE)
			return FAILURE;

		if (startID.increment(1) == true)
			//overflow of shore logical ids
		{
			globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"Evaluator",__FILE__,"Shore Logical ID overflow.");
			return FAILURE;
		}
	}
	else
	{
		if (MCCASStackNode::WriteBufferToList(cont,list,startID) == FAILURE)
			return FAILURE;
		
		if (startID.increment(1) == true)
			//overflow of shore logical ids
		{
			globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"Evaluator",__FILE__,"Shore Logical ID overflow.");
			return FAILURE;
		}
	}
	cont->Initialize();
	return SUCCESS;
}

int MeaningfulClosestCommonAncestorStructureIterator::ReplaceWithParentNode(MCCASStackNode * child)
{	
	bitset<MAX_NUM_VARIABLE> signature;
	signature.reset();

	if (this->WriteNodeIntoItsBuffer(child) == FAILURE)
		return FAILURE;
	
	if (child->isSimple())
	{
		ListNode * parent;
		parent = new ListNode;
		this->GetParentNode((ListNode *)child->GetActualAncs(), parent);
		
		if (child->isKey())
		{
			child->resetKey();
		}
		
		child->SetActualAncs(parent);

		delete parent;
	}
	else
	{
		ComplexListNode * parent;
		parent = new ComplexListNode;
		this->GetParentNode((ComplexListNode *)child->GetActualAncsComplex(), parent);
		
		if (child->isKey())
		{
			child->resetKey();
		}

		child->SetActualAncsComplex(parent);

		delete parent;
	}

	return SUCCESS;
}

int  MeaningfulClosestCommonAncestorStructureIterator:: WriteNodeIntoItsBuffer(MCCASStackNode * node)
{
	bitset<MAX_NUM_VARIABLE> signature;
	WitnessTree * tempTree;
	WitnessTree * tempComplexTree;
	
	int length;

	if (node->isKey())
	{
		tempComplexTree = new WitnessTree(LIST_NODE_WITH_DATA,dataMng);
		int setNum = node->GetKeyValue();
		int minID = node->GetGlobalMin();
		int maxID = node->GetGlobalMax();

		if (!node->GetBufferByIndex(setNum)->EnoughSpace(3 * sizeof(int) + ComplexListNodeSize))
		{
			if (this->WriteBufferToItsList(node->GetBufferByIndex(setNum), node->GetListByIndex(setNum)) == FAILURE)
				return FAILURE;
		}

		// record the minID associated with this node
		node->AddToBuffer(node->GetBufferByIndex(setNum),(char *)&minID,sizeof(int));
		
		// recode the maxID associated with this node
		node->AddToBuffer(node->GetBufferByIndex(setNum),(char *)&maxID,sizeof(int));
		
		tempTree = node->GetActualAncsWithSubtree();

		if (node->isSimple())
		{	
			tempComplexTree->appendList((ListNode *)tempTree->getBuffer(),tempTree->length(), false);
		}
		else
		{
			if (((ComplexListNode *)tempTree->findNode(0))->IsDummy() &&
			strcmp("<root>", ((ComplexListNode *)tempTree->getNodeByIndex(0))->GetDummyName()) == 0)
			{
				tempComplexTree->appendList((ComplexListNode *)tempTree->getBuffer() + 1, this->dataMng, tempTree->length() - 1, false);
			}
			else
			{
				tempComplexTree->appendList((ComplexListNode *)tempTree->getBuffer(), this->dataMng, tempTree->length(), false);
			}
		}

		length = tempComplexTree->length();
		
		// record the length of subtree of this node, which is a list node along with it's subtree
		node->AddToBuffer(node->GetBufferByIndex(setNum), (char *)&length, sizeof(int));
		
		// copy the subtree into the buffer
		node->AddToBuffer(node->GetBufferByIndex(setNum),(char *)tempComplexTree->getBuffer(),length * ComplexListNodeSize);		   

		delete tempComplexTree;
	}

	for(int i = node->GetNumOfStructure() - 1; i > -1 ; i--)
	{
		if (node->GetSignByIndex(i).count() == 1)
		{
			signature |= node->GetSignByIndex(i);
			node->deleteSignByIndex(i);
		}
	}

	if (signature.any())
	{
		node->SetSignByIndex(node->GetNumOfStructure(), signature);
		node->SetNumOfStructure(node->GetNumOfStructure() + 1);
	}

	return SUCCESS;
}

int MeaningfulClosestCommonAncestorStructureIterator::InsertStackNode(MCCASStackNode * source, MCCASStackNode * target)
{
	bitset<MAX_NUM_VARIABLE> signature;
	signature.reset();

	if (this->WriteNodeIntoItsBuffer(source) == FAILURE)
		return FAILURE;
	
	if (source->GetGlobalMax() > target->GetGlobalMax())
		target->SetGlobalMax(source->GetGlobalMax());

	for(int i = 1; i < source->GetNumOfStructure(); i++)
	{
		if (source->GetSignByIndex(i).count() == 1)
		{
			signature |= source->GetSignByIndex(i);
			source->deleteSignByIndex(i);
		}
	}

	if (signature.any())
	{
		source->SetSignByIndex(source->GetNumOfStructure(), signature);
		source->SetNumOfStructure(source->GetNumOfStructure() + 1);
	}

	switch (target->TypeOfRelationship(source->getSignature()))
	{
		case SUBSUMED_BY:
			// don't add the input node
			break;
		case EQUAL:
			for (int i = 0; i < this->numInputs; i++)
			{
				if (source->getSignature().test(i))
				{
					target->SetMaxByIndex(i, source->GetMaxByIndex(i));
				}
			}
			return this->CopyList(source,target);
		case NO_OVERLAP: 
			for (int i = 0; i < this->numInputs; i++)
			{
				if (source->getSignature().test(i))
				{
					target->SetMaxByIndex(i, source->GetMaxByIndex(i));
					target->SetMinByIndex(i, source->GetMinByIndex(i));
				}
			}
			// set signature for the node
			target->setSignature(target->getSignature() | source->getSignature());
			// set signature for individual structure
			target->SetSignByIndex(target->GetNumOfStructure(), source->getSignature());
			target->SetNumOfStructure(target->GetNumOfStructure() + 1);
			return this->CopyList(source, target);	
		case CONSUMED_BY:
			// set signature for the node
			for (int i = 0; i < this->numInputs; i++)
			{
				if (source->getSignature().test(i))
				{
					target->SetMaxByIndex(i, source->GetMaxByIndex(i));
					target->SetMinByIndex(i, source->GetMinByIndex(i));
				}
			}

			target->setSignature(target->getSignature() | source->getSignature());
			
			for (int i = 0; i < target->GetNumOfStructure(); i++)
			{
				if (source->getSignature() == (source->getSignature() | target->GetSignByIndex(i)))
				{
					// delete the corresponding original lists and copy the new ones
					for (int j = 0; j < this->numInputs; j++)
					{
						if (target->GetSignByIndex(i).test(j))
						{
							target->SetBufferByIndex(j);
							target->SetListByIndex(j);
						}
					}
					
					target->deleteSignByIndex(i);
				}
			}

			target->SetSignByIndex(target->GetNumOfStructure(), source->getSignature());
			target->SetNumOfStructure(target->GetNumOfStructure() + 1);
			
			return this->CopyList(source, target);	
		case HAVE_OVERLAP:
			for (int i = 0; i < source->GetNumOfStructure(); i++)
			{
				if ((source->GetSignByIndex(i) & target->GetSignByIndex(i)).any())
				{
					// delete the corresponding original lists
					for (int j = 0; j < this->numInputs; j++)
					{
						if (source->GetSignByIndex(i).test(j))
						{
							source->SetBufferByIndex(j);
							source->SetListByIndex(j);
							source->SetMaxByIndex(j, -1);
							source->SetMinByIndex(j, -1);
						}
					}

					source->SetSignByIndex(i, target->GetSignByIndex(i).reset());

					// delete the signature record of the structure
					for (int j = i; j < source->GetNumOfStructure() - 1; j++)
					{
						source->SetSignByIndex(j, source->GetSignByIndex(j + 1));
					}

					source->SetNumOfStructure(source->GetNumOfStructure()- 1);
					return SUCCESS;
				}
			}
	}
	return SUCCESS;
}

/**
construct MCCAS sub-structure
**/
void MeaningfulClosestCommonAncestorStructureIterator :: ConstructSubMCCASByIndex(MCCASStackNode * node, int index, bool reset)
{
	int i;
	bitset<MAX_NUM_VARIABLE> signature;
	signature = node->GetSignByIndex(index);
		
	ShoreList * list;

	// if there is only one buffer/list associated with the structure
	// simply scan the buffer/list
	if (signature.count() == 1)
	{
		for (i = 0; i < this->numInputs; i++)
		{
			if (signature.test(i))
			{
				break;
			}
		}
		
		// if restart scan
		if (reset)
		{
			list = node->GetListByIndex(i);
			list->StartScan();
		}
	}	
}

/**
find MCCAS structures
**/
bool MeaningfulClosestCommonAncestorStructureIterator :: FindMCCAS()
{
	int setNum = -1;
	
	this->finishScan.reset();
	this->startScan.reset();

	// initialize the copy
	for (int i = 0; i < this->numInputs; i++)
	{
		this->copyOfLatestMCCAS->SetBufferByIndex(i);
		this->copyOfLatestMCCAS->SetListByIndex(i);
		this->copyOfLatestMCCAS->SetMinByIndex(i,-1);
		this->copyOfLatestMCCAS->SetMaxByIndex(i,-1);
	}	

	do
	{
		findInput(setNum);	
		
		// read in input
		if (setNum != -1)
		{				
			this->PushInput(setNum);
			inputs[setNum]->next(inTuple[setNum]);
		}
	} while (setNum != -1 && this->stop == false);	

	//pop all the nodes in the stack
	if (setNum == -1)
		this->popStack(-1);

	if (this->stop == true)
	{
		this->stop = false;
		return true;
	}
	else
	{		
		return false;
	}
}

void MeaningfulClosestCommonAncestorStructureIterator :: BackwardScan(ContainerClass * cont, int length)
{
	cont->SetScanCursor(cont->GetScanCursor() - length);
	return;
}

bool MeaningfulClosestCommonAncestorStructureIterator :: MergeSubMCCAS(MCCASStackNode * node, int index)
{
	ShoreList * list;
	int newMaxID, newMinID = 0;
	int length;
	unsigned int counter = 0;

	for (int i = 0; i < this->numInputs; i++)
	{
		if (node->GetSignByIndex(index).test(i))
		{
			counter++;

			list = this->copyOfLatestMCCAS->GetListByIndex(i);

			// the first time to scan list[i]
			if (!this->startScan.test(i))
			{
				// mark the list to be scanned
				this->startScan.set(i);				
				list->StartScan();
				this->curListScanCursor[i] = list->GetHead();
				this->curBufScanCursor[i] = 0;
				this->newBufScanCursor[i] = 0;
				this->newListScanCursor[i] = list->GetHead();
				list->SetScanCursor(this->curListScanCursor[i]);

				// get data into buffer
				if (list->IsEmpty())
				{
					this->readContainer[i] = this->copyOfLatestMCCAS->GetBufferByIndex(i);
				}
				else
				{
					if (this->WriteBufferToItsList(this->readContainer[i], list) == FAILURE)
						return false;
					list->GetNext(this->readContainer[i]);
				}

				// get IDs and number of nodes in the WitnessTree
				this->readContainer[i]->GetNext(sizeof(int),(char *)&newMinID);
				this->readContainer[i]->GetNext(sizeof(int),(char *)&newMaxID);
				this->readContainer[i]->GetNext(sizeof(int),(char *)&length);

				// the minID of nodes in the list scanned so far
				this->curMinIDs[i] = newMinID;
				this->newMinIDs[i] = newMinID;

				// the maxID of nodes in the list scanned so far
				this->curMaxIDs[i] = newMaxID;
				this->newMinIDs[i] = newMaxID;								
				
				// read in the data nodes
				this->outputArrayOfWitnessTree[i]->SetUsed(0);
				this->outputArrayOfWitnessTree[i]->appendList((ComplexListNode *)this->readContainer[i]->GetNextPtr(length * ComplexListNodeSize,false,true), this->dataMng, length);
			}	
			// all the nodes with curMinID & curMaxID in the structure already merged with each other
			// move on to merge the remaining nodes
			else if ((this->finishScan & node->GetSignByIndex(index)).count() == counter - 1)
			{
				// read in another record
				if (this->readContainer[i]->GetNext(sizeof(int),(char *)&newMinID) == SUCCESS)
				{
					this->readContainer[i]->GetNext(sizeof(int),(char *)&newMaxID);	
					
					// read in a record with another id
					// discard it and rescan current list
					if (newMinID > this->curMaxIDs[i] && this->curMaxIDs[i] != -1)
					{
						this->newMaxIDs[i] = newMaxID;
						this->newMinIDs[i] = newMinID;
						this->newBufScanCursor[i] = this->readContainer[i]->GetScanCursor()- 2 * sizeof(int);						
						this->newListScanCursor[i] = node->GetListByIndex(i)->GetScanCursor();
						
						if (counter < node->GetSignByIndex(index).count())
						{								
							this->finishScan.set(i);
						}
						else
						{
							this->StartScanForNewID(node, index, counter);
							if (RestartScan(node, index, i + 1) == FAILURE)
								return false;
						}
					}
					else
					{	
						// rescan all the lists with index smaller than current index i
						if (this->RestartScan(node, index, i) == FAILURE)
							return false;									
							
						// continue read in data in current buffer readContainer[i]
						this->readContainer[i]->GetNext(sizeof(int),(char *)&length);
												
						this->outputArrayOfWitnessTree[i]->SetUsed(0);
						this->outputArrayOfWitnessTree[i]->appendList((ComplexListNode *)this->readContainer[i]->GetNextPtr(length * ComplexListNodeSize,false,true), this->dataMng, length);
					}
				}
				// if all the records in the lists have been scanned
				else if (list->IsEmpty() || (list->GetNext(this->readContainer[i])) == FAILURE)
				{
					if (counter < node->GetSignByIndex(index).count())
					{
						this->finishScan.set(i);
					}
					else
					{
						this->finishScan.set(i);
						return false;
					}
				}
				else
				{
					if (this->RestartScan(node, index, counter - 1) == FAILURE)
						return false;
					this->readContainer[i]->GetNext(sizeof(int),(char *)&newMinID);
					this->readContainer[i]->GetNext(sizeof(int),(char *)&newMaxID);
					this->readContainer[i]->GetNext(sizeof(int),(char *)&length);
				
					if (this->curMinIDs[i] == -1)
					{
						this->curMinIDs[i] = newMinID;
					}

					if (this->curMaxIDs[i] == -1)
					{
						this->curMaxIDs[i] = newMaxID;
					}

					// read in a record with another id
					// discard it and rescan current list
					if (newMinID > this->curMinIDs[i] && this->curMinIDs[i] != -1)
					{
						this->newBufScanCursor[i] = this->readContainer[i]->GetScanCursor()- sizeof(int);
						this->newListScanCursor[i] = node->GetListByIndex(i)->GetScanCursor();
						this->newMaxIDs[i] = newMaxID;
						this->newMinIDs[i] = newMinID;

						if (counter < node->GetSignByIndex(index).count())
						{		
							this->finishScan.set(i);
						}
						else
						{
							this->StartScanForNewID(node, index, counter);
							if (RestartScan(node, index, i + 1) == FAILURE)
								return false;
						}
					}
					else
					{									
						this->outputArrayOfWitnessTree[i]->SetUsed(0);
						this->outputArrayOfWitnessTree[i]->appendList((ComplexListNode *)this->readContainer[i]->GetNextPtr(length * ComplexListNodeSize,false,true), this->dataMng, length);

						this->finishScan.reset();
					}
				}
			}				
		}		
	}

	return true;
}

void MeaningfulClosestCommonAncestorStructureIterator :: StartScanForNewID(MCCASStackNode * node, int index, int curList)
{
	int min;

	min = this->OverallMinID(node->GetSignByIndex(index));

	for (int i = 0; i < this->numInputs; i++)
	{
		if (node->GetSignByIndex(index).test(i) && i <= curList)
		{	
			this->finishScan.reset(i);
			if (this->newMinIDs[i] == min)
			{							
				this->curBufScanCursor[i] = this->newBufScanCursor[i];
				this->curListScanCursor[i] = this->newListScanCursor[i];
				this->curMinIDs[i] = this->newMinIDs[i];
				this->curMaxIDs[i] = this->newMaxIDs[i];
			}
		}
	}
}

/**
Restart scan
**/
int MeaningfulClosestCommonAncestorStructureIterator :: RestartScan(MCCASStackNode * node, int index, int curList)
{
	ShoreList * list;
	int newMinID, newMaxID = 0;
	int length;

	for (int i = 0; i < curList; i++)
	{
		if (node->GetSignByIndex(index).test(i))
		{
			this->finishScan.reset(i);
			list = node->GetListByIndex(i);
			list->SetScanCursor(this->curListScanCursor[i]);

			if (list->IsEmpty())
			{
				this->readContainer[i] = this->copyOfLatestMCCAS->GetBufferByIndex(i);
			}
			else
			{
				if (this->WriteBufferToItsList(this->copyOfLatestMCCAS->GetBufferByIndex(i), this->copyOfLatestMCCAS->GetListByIndex(i)) == FAILURE)
					return FAILURE;
				list->GetNext(this->readContainer[i]);
			}

			this->readContainer[i]->SetScanCursor(this->curBufScanCursor[i]);
			this->readContainer[i]->GetNext(sizeof(int),(char *)&newMinID);
			this->readContainer[i]->GetNext(sizeof(int),(char *)&newMaxID);													
			this->readContainer[i]->GetNext(sizeof(int),(char *)&length);
							
			this->outputArrayOfWitnessTree[i]->SetUsed(0);
			this->outputArrayOfWitnessTree[i]->appendList((ComplexListNode *)this->readContainer[i]->GetNextPtr(length * ComplexListNodeSize,false,true), this->dataMng, length);
		}
	}

	return SUCCESS;
}

int MeaningfulClosestCommonAncestorStructureIterator :: OverallMinID(bitset<MAX_NUM_VARIABLE> signature)
{
	int min = -1;

	for (int i = 0; i < this->numInputs; i++)
	{
		if (signature.test(i))
		{
			if (this->newMinIDs[i] < min || min == -1)
			{
				min = this->newMinIDs[i];
			}
		}
	}

	return min;
}