#ifndef __HashIndexUpdate_h
#define __HashIndexUpdate_h


#include "../Common/ContainerClass.h"
#include "../../IndexMng/IndexOperation/GistIndexUpdate.h"

class HashIndexUpdate
{
public:

HashIndexUpdate(char *indexName,int indexType);	
~HashIndexUpdate();

void create();
void open();
int insert(void *insertedKey,ListNode insertedData);
int getRecordNumber();
int close();

private:
	int writeContainer();
	int writeRange(void *startRange);
	char *indexName;
	FILE *indexFile;

	FILE *rangeTableFile; 
	int numRanges;
	
	//index replacing table
	//gist *rangeIndex;


	int indexType;
	int recordNumber;
	int keySize;
	int dataSize;
	int contMaxSize;
	ContainerClass cont;
	char *buffer;
	int recSize;
};

#endif