#include "HashIndexUpdate.h"

HashIndexUpdate::HashIndexUpdate(char *indexName,int indexType)
{
	this->indexName = new char[strlen(indexName)+1];
	strcpy(this->indexName,indexName);
	if (indexType == INT_INDEX)
		this->keySize = sizeof(int);
	else if (indexType == FLOAT_INDEX)
		this->keySize = sizeof(float);
	else
		this->keySize = sizeof(double);
	this->dataSize = sizeof(double) + sizeof(double) + sizeof(int) +sizeof(int);
	this->recSize = this->keySize + this->dataSize;
	buffer = new char[recSize];
	this->contMaxSize = cont.GetSize();
	indexFile = fopen(this->indexName,"wb");
	char *tableFileName = new char[strlen(indexName) + 5];
	strcpy(tableFileName,indexName);
	strcat(tableFileName,".tab");

	
	rangeTableFile = fopen(tableFileName,"wb");
	fseek(rangeTableFile,sizeof(int),0);

	//index instead of table
//	this->rangeIndex = new gist;
	//rangeIndex->create(tableFileName,&bt_dbl_ext);

	delete [] tableFileName;
	numRanges = 0;
}

HashIndexUpdate::~HashIndexUpdate()
{
	delete [] indexName;
	delete [] buffer;
//	delete rangeIndex;
}

void HashIndexUpdate::create()
{
	
}

void HashIndexUpdate::open()
{
}

int HashIndexUpdate::insert(void *insertedKey,ListNode insertedData)
{
	memcpy(buffer,insertedKey,keySize);
	memcpy(buffer+keySize,&insertedData,dataSize);
	if (cont.AddData(buffer,recSize) == FAILURE)
	{
		if (writeContainer() == FAILURE)
			return FAILURE;
		if (writeRange(insertedKey) == FAILURE)
			return FAILURE;
		if (cont.AddData(buffer,recSize) == FAILURE)
			return FAILURE;
	}
	
	this->recordNumber++;
	return SUCCESS;
}

int HashIndexUpdate::getRecordNumber()
{
	return recordNumber;
}

int HashIndexUpdate::close()
{
	if (!(cont.IsEmpty()))
		if (writeContainer() == FAILURE)
			return FAILURE;
	fclose(indexFile);

	fseek(rangeTableFile,0,0);
	if (fwrite(&numRanges,1,sizeof(int),rangeTableFile) < sizeof(int))
	{
		printf("error in writing number of ranges in close method in HashIndexUpdate...\n");
		return FAILURE;
	}
	fclose(rangeTableFile);
    //rangeIndex->close();
    return SUCCESS;
}

int HashIndexUpdate::writeContainer()
{
	int addCursor = cont.GetAddCursor();
	if (fwrite(&addCursor,1,sizeof(int),indexFile) < sizeof(int))
	{
		printf("error in writing container size in writeContainer method in HashIndexUpdate...\n");
		return FAILURE;
	}
	if ( (int)fwrite(cont.GetContianer(),1,this->contMaxSize,indexFile) < this->contMaxSize)
	{
		printf("error in writing container in writeContainer method in HashIndexUpdate...\n");
		return FAILURE;
	}
	cont.Initialize();
	return SUCCESS;
}

int HashIndexUpdate::writeRange(void *startRange)
{
	if ( (int)fwrite(startRange,1,keySize,rangeTableFile) < keySize)
	{
		printf("error in writing range in writeRange method in HashIndexUpdate...\n");
		return FAILURE;
	}
	numRanges++;

	//(void)rangeIndex->insert(insertedKey,keySize,(void *)insertedData,sizeof(ListNode));
	return SUCCESS;
}