/*
COPYRIGHT  � 2000-2004 
THE REGENTS OF THE UNIVERSITY OF MICHIGAN
ALL RIGHTS RESERVED

PERMISSION IS GRANTED TO USE, COPY, CREATE DERIVATIVE WORKS AND REDISTRIBUTE THIS SOFTWARE AND SUCH DERIVATIVE WORKS FOR 
NONCOMMERCIAL EDUCATION AND RESEARCH PURPOSES, SO LONG AS NO FEE IS CHARGED, AND SO LONG AS THE COPYRIGHT NOTICE ABOVE, 
THIS GRANT OF PERMISSION, AND THE DISCLAIMER BELOW APPEAR IN ALL COPIES MADE; AND SO LONG AS THE NAME OF THE UNIVERSITY 
OF MICHIGAN IS NOT USED IN ANY ADVERTISING OR PUBLICITY PERTAINING TO THE USE OR DISTRIBUTION OF THIS SOFTWARE WITHOUT 
SPECIFIC, WRITTEN PRIOR AUTHORIZATION.

THIS SOFTWARE IS PROVIDED AS IS, WITHOUT REPRESENTATION FROM THE UNIVERSITY OF MICHIGAN AS TO ITS FITNESS FOR ANY PURPOSE, 
AND WITHOUT WARRANTY BY THE UNIVERSITY OF MICHIGAN OF ANY KIND, EITHER EXPRESS OR IMPLIED, INCLUDING WITHOUT LIMITATION THE 
IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE. THE REGENTS OF THE UNIVERSITY OF MICHIGAN SHALL 
NOT BE LIABLE FOR ANY DAMAGES, INCLUDING SPECIAL, INDIRECT, INCIDENTAL, OR CONSEQUENTIAL DAMAGES, WITH RESPECT TO ANY CLAIM 
ARISING OUT OF OR IN CONNECTION WITH THE USE OF THE SOFTWARE, EVEN IF IT HAS BEEN OR IS HEREAFTER ADVISED OF THE POSSIBILITY 
OF SUCH DAMAGES.
*/

#ifndef __GistIndexAccess_h
#define __GistIndexAccess_h

#include "../../IndexMng/IndexOperation/GistIndexUpdate.h"
#include "../Common/IteratorClass.h"
class WitnessTree;
class IteratorClass;
class gist;

/**
* GistIndexAccess
* 
* This class is a gist index retrieval iterator
* It is inherited from IteratorClass
* 
* @version 1.0
*/
class GistIndexAccess : public IteratorClass
{
public:

	/**
	* Constructor
	*
	* @param indexName The index name (actually the physical filename)
	* @param q The query accessing type of gist
	* @param indexType The index type (string, integer...)
	* @param openFileIndex The index in the open file table
	* @param assignedNRE NRE assigned to this index access
	*/
	GistIndexAccess(char *indexName,bt_query_t *q,int indexType,char openFileIndex, NREType assignedNRE)
	{
		// Assigning index name and query of gist type
		query = q;
		this->indexName = indexName;

		errorFound = false;
		//get path from the settings file
		indexNameWithPath = new char[strlen(gSettings->getStringValue("GIST_DEFAULT_FILEPATH").c_str())+strlen(indexName)+1];
		
		// append path with the indexname
		strcpy(indexNameWithPath,gSettings->getStringValue("GIST_DEFAULT_FILEPATH").c_str());
		strcat(indexNameWithPath,indexName);

		// open the index

		this->assignedNRE = assignedNRE;
		eof = false;
		this->indexType = indexType;
		if (indexType == STRING_INDEX)
			fetchedString = (char *)(malloc(sizeof(char)*101));/*MAX_NODETAG_LENGTH*/
		resultBuffer = new WitnessTree;
		numRead = 0;
		this->openFileIndex = openFileIndex;

		keysz = 3000000;
		datasz = 3000000;

		rc = index.open(indexNameWithPath);
		if (rc)
		{
			errorFound = true;
			globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"Evaluator",__FILE__,"Could not open index file.");
			return;
		}

		//initialize the cursor

		cursor.k = 0;
		cursor.io = 0;
		cursor.query = NULL;
		cursor.ext = NULL;
		cursor.cext = NULL;
		cursor.iter = NULL;
		cursor.state = NULL;
		rc = index.fetch_init(cursor, query);
		if (rc)
		{
			errorFound = true;
			globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"Evaluator",__FILE__,"Problem with intializing fetching from index.");
			return;
		}
	};

	/**
	* Destructor
	*
	* Close the index and clear buffer
	*/
	~GistIndexAccess()
	{
		if (cursor.iter != NULL) {
			((gist_lstk*) cursor.iter)->reset();
			delete cursor.iter;
			cursor.iter = NULL;
		}
		(void) index.close();
		delete resultBuffer;
		delete query;
		if (indexType == STRING_INDEX)
			free(fetchedString);
		delete [] indexNameWithPath;
		delete [] indexName;
	};

	/**
	* Iterator Method
	*
	* Reset the iterator to the beginning of the result
	*/
	void Reset()
	{
		eof = false;
		numRead = 0;
		errorFound = false;

		if (indexType == STRING_INDEX)
			free(fetchedString);
		rc = index.fetch_init(cursor, query);
		if (rc)
		{
			errorFound = true;
			globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"Evaluator",__FILE__,"Problem with intializing fetching from index.");
			return;
		}
	};

	/**
	* Iterator Method
	*
	* Get next key/data entry from the index
	* @param node A witness tree node that will be filled in by the data
	*/
	void next(WitnessTree *&node)
	{
		if (errorFound)
		{
			node = NULL;
			return;
		}
		ListNode str;// = (ListNode *)malloc(sizeof(ListNode));

		switch (indexType)
		{
			case STRING_INDEX:
				rc = index.fetch(cursor,fetchedString, keysz, (void *)&str, datasz, eof);
				break;
			case INT_INDEX:
				rc = index.fetch(cursor,&fetchedInt,keysz,(void *)&str, datasz, eof);
				break;
			case FLOAT_INDEX:
				rc = index.fetch(cursor,&fetchedFloat,keysz,(void *)&str,datasz, eof);
				break;
			case DOUBLE_INDEX:
				rc = index.fetch(cursor,&fetchedDouble,keysz,(void *)&str,datasz, eof);
				break;
			default:
				globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"Evaluator",__FILE__,"Unrecognized index type.");
				node = NULL;
				return;
		}
		if (rc)
		{
			globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"Evaluator",__FILE__,"Problem in fetching data from index.");
			node = NULL;
			return;
		}
		if (eof)
		{
			node  = NULL;
			return;
		}
		numRead++;
		resultBuffer->initialize();
		str.setNRE(assignedNRE);
		resultBuffer->appendList(&str,1);
		((ListNode *)resultBuffer->findNode(0))->setFileIndex(openFileIndex);
		//((ListNode *)resultBuffer->findNode(0))->setNRE(assignedNRE);
		node  = resultBuffer;
		return;
	};
private:
    gist_cursor_t cursor;
	gist index;
	bool eof;
	char *fetchedString;
	int fetchedInt;
	float fetchedFloat;
	double fetchedDouble;
	unsigned long keysz;  
	unsigned long datasz;
	bt_query_t *query;
	int indexType;
	WitnessTree *resultBuffer;
	char *indexName;
	char *indexNameWithPath;
	int numRead;
	char openFileIndex;
	NREType assignedNRE;
	bool errorFound;
	rc_tGist rc;
};

#endif
