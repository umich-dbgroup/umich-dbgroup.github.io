#include "QueryEvaluationTreeNode.h"

#ifndef __QueryEvaluationTreeUpdatesNode_H
#define __QueryEvaluationTreeUpdatesNode_H

#include "../Iterators/UpdatesIterator.h"
#include "AttributeInfo.h"

class QueryEvaluationTreeUpdatesNode: public QueryEvaluationTreeNode
{
public:
	//QueryEvaluationTreeUpdatesNode(QueryEvaluationTreeNode* operand,
	//	int updateType, NREType nre, char * indexToUpdate);
	QueryEvaluationTreeUpdatesNode(QueryEvaluationTreeNode* operand, 
		int updateType, NREType nre, 
		char* textValue1, char* textValue2, char* textValue3, char* textValue4); //, vector<String_Pair> repeated);
	~QueryEvaluationTreeUpdatesNode();

	int getUpdateType();
	void setUpdateType(int updateType);

	NREType getNRE();
	void setNRE(NREType nre);

	//char *getIndexToUpdate();
	//void setIndexToUpdate(char * indexToUpdate);

	char *getTextValue1();
	void setTextValue1(char * textValue);

	char *getTextValue2();
	void setTextValue2(char * textValue);

	char *getTextValue3();
	void setTextValue3(char * textValue);

	char *getTextValue4();
	void setTextValue4(char * textValue);

	AttributeInfo getRepeatedPair(int index);
	void setRepeatedPair(int index, AttributeInfo attrInfo);
	void addRepeatedPair(AttributeInfo attrInfo);

	vector<AttributeInfo> getRepeated();
	void setRepeated(vector<AttributeInfo> repeated);

	int getRepeatedSize();


	QueryEvaluationTreeNode *getOperand();
	void setOperand(QueryEvaluationTreeNode* operand);


	//UPDATE TYPES:
	//static const int DELETE_ELEMENT_NODE = 1;
	static const int DELETE_TEXT_NODE = 2;
	//static const int DELETE_ATTRIBUTE_NODE = 3;
	static const int DELETE_ATTRIBUTE = 4;
	static const int DELETE_ATTRIBUTE_VALUE = 5;
	static const int DELETE_TREE = 6;

	static const int INSERT_ELEMENT_NODE = 10;
	//static const int INSERT_ATTRIBUTE_NODE = 11;
	static const int INSERT_ATTRIBUTE = 12;
	//static const int INSERT_TREE = 13;
	static const int INSERT_XML_FILE = 14;

	//static const int MODIFY_ELEMENT_NODE = 20;
	static const int MODIFY_TEXT_NODE = 21;
	//static const int MODIFY_ATTRIBUTE_NODE = 22;
	//static const int MODIFY_ATTRIBUTE = 23;
	static const int MODIFY_ATTRIBUTE_VALUE = 24;
	void deleteStructures();

private:
	char *createString(char * in);

	QueryEvaluationTreeNode* operand;

	int updateType;
	NREType nre;
	//char *indexToUpdate;
	char *textValue1;
	char *textValue2;
	char *textValue3;
	char *textValue4;

	vector<AttributeInfo> repeated;
};


#endif