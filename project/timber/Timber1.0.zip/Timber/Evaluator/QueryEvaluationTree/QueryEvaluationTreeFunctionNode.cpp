/*
COPYRIGHT  � 2000-2004 
THE REGENTS OF THE UNIVERSITY OF MICHIGAN
ALL RIGHTS RESERVED

PERMISSION IS GRANTED TO USE, COPY, CREATE DERIVATIVE WORKS AND REDISTRIBUTE THIS SOFTWARE AND SUCH DERIVATIVE WORKS FOR 
NONCOMMERCIAL EDUCATION AND RESEARCH PURPOSES, SO LONG AS NO FEE IS CHARGED, AND SO LONG AS THE COPYRIGHT NOTICE ABOVE, 
THIS GRANT OF PERMISSION, AND THE DISCLAIMER BELOW APPEAR IN ALL COPIES MADE; AND SO LONG AS THE NAME OF THE UNIVERSITY 
OF MICHIGAN IS NOT USED IN ANY ADVERTISING OR PUBLICITY PERTAINING TO THE USE OR DISTRIBUTION OF THIS SOFTWARE WITHOUT 
SPECIFIC, WRITTEN PRIOR AUTHORIZATION.

THIS SOFTWARE IS PROVIDED AS IS, WITHOUT REPRESENTATION FROM THE UNIVERSITY OF MICHIGAN AS TO ITS FITNESS FOR ANY PURPOSE, 
AND WITHOUT WARRANTY BY THE UNIVERSITY OF MICHIGAN OF ANY KIND, EITHER EXPRESS OR IMPLIED, INCLUDING WITHOUT LIMITATION THE 
IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE. THE REGENTS OF THE UNIVERSITY OF MICHIGAN SHALL 
NOT BE LIABLE FOR ANY DAMAGES, INCLUDING SPECIAL, INDIRECT, INCIDENTAL, OR CONSEQUENTIAL DAMAGES, WITH RESPECT TO ANY CLAIM 
ARISING OUT OF OR IN CONNECTION WITH THE USE OF THE SOFTWARE, EVEN IF IT HAS BEEN OR IS HEREAFTER ADVISED OF THE POSSIBILITY 
OF SUCH DAMAGES.
*/

#include "QueryEvaluationTreeFunctionNode.h"


QueryEvaluationTreeFunctionNode::QueryEvaluationTreeFunctionNode(QueryEvaluationTreeNode* operand,NREType *assignedNRE,
		 int num, int *operation, int *onWhat, NREType *nre,
		char **attrName, bool treeLevel)
: QueryEvaluationTreeNode(EVALUATION_OP_FUNCTION)
{
	this->operand = operand;
	this->assignedNRE = assignedNRE;
	this->nre = nre;
	this->operation = operation;
	this->onWhat = onWhat;
	this->attrName = attrName;
	this->num = num;
	this->treeLevel = treeLevel;
}


QueryEvaluationTreeFunctionNode::~QueryEvaluationTreeFunctionNode()
{
	delete operand;
	
}

NREType *QueryEvaluationTreeFunctionNode::getNRE()
{
	return this->nre;
}

void QueryEvaluationTreeFunctionNode::setNRE(NREType *nre)
{
	this->nre  = nre;
}

NREType *QueryEvaluationTreeFunctionNode::getAssignedNRE()
{
	return this->assignedNRE;
}

void QueryEvaluationTreeFunctionNode::setAssignedNRE(NREType *assignedNRE)
{
	this->assignedNRE = assignedNRE;
}

int QueryEvaluationTreeFunctionNode::getNum()
{
	return this->num;
}

void QueryEvaluationTreeFunctionNode::setNum(int num)
{
	this->num = num;
}

bool QueryEvaluationTreeFunctionNode::getTreeLevel()
{
	return this->treeLevel;
}

void QueryEvaluationTreeFunctionNode::setTreeLevel(bool treeLevel)
{
	this->treeLevel = treeLevel;
}

int *QueryEvaluationTreeFunctionNode::getOperation()
{
	return this->operation;
}

void QueryEvaluationTreeFunctionNode::setOperation(int *operation)
{
	this->operation = operation;
}

int *QueryEvaluationTreeFunctionNode::getOnWhat()
{
	return this->onWhat;
}

void QueryEvaluationTreeFunctionNode::setOnWhat(int *onWhat)
{
	this->onWhat = onWhat;
}

char **QueryEvaluationTreeFunctionNode::getAttrName()
{
	return this->attrName;
}

void QueryEvaluationTreeFunctionNode::setAttrName(char **attrName)
{
	this->attrName = attrName;
}


QueryEvaluationTreeNode *QueryEvaluationTreeFunctionNode::getOperand()
{
	return this->operand;
}

void QueryEvaluationTreeFunctionNode::setOperand(QueryEvaluationTreeNode* operand)
{
	this->operand = operand;
}

void QueryEvaluationTreeFunctionNode::deleteStructures()
{
	if (nre) delete [] nre;
	if (operation) delete [] operation;
	if (onWhat) delete [] onWhat;
	if (attrName)
	{
		for (int i=0; i< num; i++)
			if (attrName[i]) delete [] attrName[i];
		delete [] attrName;
	}
	if (assignedNRE) delete [] assignedNRE;
	operand->deleteStructures();
}