/*
COPYRIGHT  � 2000-2004 
THE REGENTS OF THE UNIVERSITY OF MICHIGAN
ALL RIGHTS RESERVED

PERMISSION IS GRANTED TO USE, COPY, CREATE DERIVATIVE WORKS AND REDISTRIBUTE THIS SOFTWARE AND SUCH DERIVATIVE WORKS FOR 
NONCOMMERCIAL EDUCATION AND RESEARCH PURPOSES, SO LONG AS NO FEE IS CHARGED, AND SO LONG AS THE COPYRIGHT NOTICE ABOVE, 
THIS GRANT OF PERMISSION, AND THE DISCLAIMER BELOW APPEAR IN ALL COPIES MADE; AND SO LONG AS THE NAME OF THE UNIVERSITY 
OF MICHIGAN IS NOT USED IN ANY ADVERTISING OR PUBLICITY PERTAINING TO THE USE OR DISTRIBUTION OF THIS SOFTWARE WITHOUT 
SPECIFIC, WRITTEN PRIOR AUTHORIZATION.

THIS SOFTWARE IS PROVIDED AS IS, WITHOUT REPRESENTATION FROM THE UNIVERSITY OF MICHIGAN AS TO ITS FITNESS FOR ANY PURPOSE, 
AND WITHOUT WARRANTY BY THE UNIVERSITY OF MICHIGAN OF ANY KIND, EITHER EXPRESS OR IMPLIED, INCLUDING WITHOUT LIMITATION THE 
IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE. THE REGENTS OF THE UNIVERSITY OF MICHIGAN SHALL 
NOT BE LIABLE FOR ANY DAMAGES, INCLUDING SPECIAL, INDIRECT, INCIDENTAL, OR CONSEQUENTIAL DAMAGES, WITH RESPECT TO ANY CLAIM 
ARISING OUT OF OR IN CONNECTION WITH THE USE OF THE SOFTWARE, EVEN IF IT HAS BEEN OR IS HEREAFTER ADVISED OF THE POSSIBILITY 
OF SUCH DAMAGES.
*/


#include "QueryEvaluationTreeNode.h"

QueryEvaluationTreeNode::QueryEvaluationTreeNode(int type)
{
	this->queryEvaluationTreeNodeType = type;
}


QueryEvaluationTreeNode::~QueryEvaluationTreeNode()
{
}


void QueryEvaluationTreeNode::setQueryEvaluationTreeNodeType(int type)
{
	this->queryEvaluationTreeNodeType = type;
}

int QueryEvaluationTreeNode::getQueryEvaluationTreeNodeType()
{
	return this->queryEvaluationTreeNodeType;
}


void QueryEvaluationTreeNode::setNodeNumber(int num)
{
	this->nodeNumber = num;
}

void QueryEvaluationTreeNode::setCost(int cost)
{
	this->cost = cost;
}

void QueryEvaluationTreeNode::setAccumulatedCost(int cost)
{
	this->accumulatedCost = cost;
}

void QueryEvaluationTreeNode::setOrderbyPosition(int pos)
{
	this->orderbyPosition = pos;
}

int QueryEvaluationTreeNode::getNodeNumber()
{
	return this->nodeNumber;
}

int QueryEvaluationTreeNode::getCost()
{
	return this->cost;
}

int QueryEvaluationTreeNode::getAccumulatedCost()
{
	return this->accumulatedCost;
}

int QueryEvaluationTreeNode::getOrderbyPosition()
{
	return this->orderbyPosition;
}

/*void QueryEvaluationTreeNode::printQueryEvaluationTreeNode(bool recursive)
{
	switch (this->queryEvaluationTreeNodeType)
	{
	case EVALUATION_OP_STRUCTURALJOIN:
		((QueryEvaluationTreeStructuralJoinNode*) this)->printQueryEvaluationTreeNode(recursive);
		break;

	case EVALUATION_OP_SORT:
		((QueryEvaluationTreeSortNode*) this)->printQueryEvaluationTreeNode(recursive);
		break;

	case EVALUATION_OP_SELECTION:
		((QueryEvaluationTreeSelectionNode*) this)->printQueryEvaluationTreeNode(recursive);
		break;

//	case EVALUATION_OP_PROJECTION:
//		((QueryEvaluationTreeProjectionNode*) this)->printQueryEvaluationTreeNode(recursive);
//		break;

	case EVALUATION_OP_INDEX_ACCESS:
		((QueryEvaluationTreeIndexAccessNode*) this)->printQueryEvaluationTreeNode(recursive);
		break;

	case EVALUATION_OP_SCAN_ACCESS:
		((QueryEvaluationTreeScanAccessNode*) this)->printQueryEvaluationTreeNode(recursive);
		break;

	}
}
*/
