/*
COPYRIGHT  � 2000-2004 
THE REGENTS OF THE UNIVERSITY OF MICHIGAN
ALL RIGHTS RESERVED

PERMISSION IS GRANTED TO USE, COPY, CREATE DERIVATIVE WORKS AND REDISTRIBUTE THIS SOFTWARE AND SUCH DERIVATIVE WORKS FOR 
NONCOMMERCIAL EDUCATION AND RESEARCH PURPOSES, SO LONG AS NO FEE IS CHARGED, AND SO LONG AS THE COPYRIGHT NOTICE ABOVE, 
THIS GRANT OF PERMISSION, AND THE DISCLAIMER BELOW APPEAR IN ALL COPIES MADE; AND SO LONG AS THE NAME OF THE UNIVERSITY 
OF MICHIGAN IS NOT USED IN ANY ADVERTISING OR PUBLICITY PERTAINING TO THE USE OR DISTRIBUTION OF THIS SOFTWARE WITHOUT 
SPECIFIC, WRITTEN PRIOR AUTHORIZATION.

THIS SOFTWARE IS PROVIDED AS IS, WITHOUT REPRESENTATION FROM THE UNIVERSITY OF MICHIGAN AS TO ITS FITNESS FOR ANY PURPOSE, 
AND WITHOUT WARRANTY BY THE UNIVERSITY OF MICHIGAN OF ANY KIND, EITHER EXPRESS OR IMPLIED, INCLUDING WITHOUT LIMITATION THE 
IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE. THE REGENTS OF THE UNIVERSITY OF MICHIGAN SHALL 
NOT BE LIABLE FOR ANY DAMAGES, INCLUDING SPECIAL, INDIRECT, INCIDENTAL, OR CONSEQUENTIAL DAMAGES, WITH RESPECT TO ANY CLAIM 
ARISING OUT OF OR IN CONNECTION WITH THE USE OF THE SOFTWARE, EVEN IF IT HAS BEEN OR IS HEREAFTER ADVISED OF THE POSSIBILITY 
OF SUCH DAMAGES.
*/

#include "QueryEvaluationTreeNode.h"

#ifndef QueryEvaluationTreeSBTermJoinNode_H
#define QueryEvaluationTreeSBTermJoinNode_H

class QueryEvaluationTreeSBTermJoinNode: public QueryEvaluationTreeNode
{
public:
	QueryEvaluationTreeSBTermJoinNode(NREType assignedNRE, char* indexName,char* fileName,char *phrase, 
        int functionNum1, int functionNum2, int functionNum3, 
        int depth, bool simpleScore, int keywordSet,
        bool meetAlg, char *parentIndexName, int bufPoolSize);
	~QueryEvaluationTreeSBTermJoinNode();

	NREType getAssignedNRE();
	void setAssignedNRE(NREType assignedNRE);

    char *getFileName();
	void setFileName(char *fileName);

    char* getIndexName();
	void setIndexName(char* indexname);

	char* getPhrase();
	void setPhrase(char* phrase);

	int getFunctionNum1();
	void setFunctionNum1(int functionNum1);
	
	int getFunctionNum2();
	void setFunctionNum2(int functionNum2);
	
	int getFunctionNum3();
	void setFunctionNum3(int functionNum3);

	int getDepth();
	void setDepth(int depth);

	bool getSimpleScore();
	void setSimpleScore(bool simpleScore);

    int getKeywordSet();
    void setKeywordSet(int keywordSet);

    // deprecated methods
    bool getMeetAlg();
	void setMeetAlg(bool meetAlg);

	char* getParentIndexName();
	void setParentIndexName(char* parentIndexname);

	int getBufPoolSize();
	void setBufPoolSize(int bufPoolSize);
	void deleteStructures();

private:
	char *fileName;
    char *indexName;
	char *phrase;
	int functionNum1;
	int functionNum2;
	int functionNum3;
	int depth;
	bool simpleScore;
    int keywordSet;
	NREType assignedNRE;

    // deprecated variables
	bool meetAlg;
	char *parentIndexName;
	int bufPoolSize;

};


#endif