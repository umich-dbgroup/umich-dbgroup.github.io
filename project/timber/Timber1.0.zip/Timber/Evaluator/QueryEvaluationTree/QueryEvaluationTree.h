/*
COPYRIGHT  � 2000-2004 
THE REGENTS OF THE UNIVERSITY OF MICHIGAN
ALL RIGHTS RESERVED

PERMISSION IS GRANTED TO USE, COPY, CREATE DERIVATIVE WORKS AND REDISTRIBUTE THIS SOFTWARE AND SUCH DERIVATIVE WORKS FOR 
NONCOMMERCIAL EDUCATION AND RESEARCH PURPOSES, SO LONG AS NO FEE IS CHARGED, AND SO LONG AS THE COPYRIGHT NOTICE ABOVE, 
THIS GRANT OF PERMISSION, AND THE DISCLAIMER BELOW APPEAR IN ALL COPIES MADE; AND SO LONG AS THE NAME OF THE UNIVERSITY 
OF MICHIGAN IS NOT USED IN ANY ADVERTISING OR PUBLICITY PERTAINING TO THE USE OR DISTRIBUTION OF THIS SOFTWARE WITHOUT 
SPECIFIC, WRITTEN PRIOR AUTHORIZATION.

THIS SOFTWARE IS PROVIDED AS IS, WITHOUT REPRESENTATION FROM THE UNIVERSITY OF MICHIGAN AS TO ITS FITNESS FOR ANY PURPOSE, 
AND WITHOUT WARRANTY BY THE UNIVERSITY OF MICHIGAN OF ANY KIND, EITHER EXPRESS OR IMPLIED, INCLUDING WITHOUT LIMITATION THE 
IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE. THE REGENTS OF THE UNIVERSITY OF MICHIGAN SHALL 
NOT BE LIABLE FOR ANY DAMAGES, INCLUDING SPECIAL, INDIRECT, INCIDENTAL, OR CONSEQUENTIAL DAMAGES, WITH RESPECT TO ANY CLAIM 
ARISING OUT OF OR IN CONNECTION WITH THE USE OF THE SOFTWARE, EVEN IF IT HAS BEEN OR IS HEREAFTER ADVISED OF THE POSSIBILITY 
OF SUCH DAMAGES.
*/


#include "QueryEvaluationTreeNode.h"
#include "QueryEvaluationTreeSelectionNode.h"
#include "QueryEvaluationTreeDuplicateEliminatorNode.h"
#include "QueryEvaluationTreeStructuralJoinNode.h"
#include "QueryEvaluationTreeSortNode.h"
#include "QueryEvaluationTreeScanAccessNode.h"
#include "QueryEvaluationTreeIndexAccessNode.h"
#include "QueryEvaluationTreeUserDefinedSelectionNode.h"
#include "QueryEvaluationTreeSetOperationsNode.h"
#include "QueryEvaluationTreeValueJoinNode.h"
#include "QueryEvaluationTreeGroupByNode.h"
#include "QueryEvaluationTreeFunctionNode.h"
#include "QueryEvaluationTreeStructuralNonBinJoinNode.h"
#include "QueryEvaluationTreeValueSortNode.h"
#include "QueryEvaluationTreeChildChooserNode.h"
#include "QueryEvaluationTreeUpdateNode.h"
#include "QueryEvaluationTreeUpdatesNode.h"
#include "QueryEvaluationTreeConstructPartialMatcherNode.h"
#include "QueryEvaluationTreeProjectionNode.h"
#include "QueryEvaluationTreePhraseFinderNode.h"
#include "QueryEvaluationTreeSBTermJoinNode.h"
#include "QueryEvaluationTreeConstructNode.h"
#include "QueryEvaluationTreeNavigationalGetRelativeNode.h"
#include "QueryEvaluationTreeFileReaderNode.h"
#include "QueryEvaluationTreeFileWriterNode.h"
#include "QueryEvaluationTreePickNode.h"
#include "QueryEvaluationTreeMergeTreesNode.h"
#include "QueryEvaluationTreeDataInstantiationNode.h"
#include "QueryEvaluationTreeDataDiscardNode.h"
#include "QueryEvaluationTreeSortStopKNode.h"
#include "QueryEvaluationTreeMCCASNode.h"
#include "QueryEvaluationTreeUnivQuantNode.h"
#include "QueryEvaluationTreeOneSidedValueJoinNode.h"
#include "QueryEvaluationTreeIndexHashValueJoinNode.h"

#ifndef __QueryEvaluationTree_H
#define __QueryEvaluationTree_H

class QueryEvaluationTree
{
public:
	QueryEvaluationTree(QueryEvaluationTreeNode* root);
	~QueryEvaluationTree();

	QueryEvaluationTreeNode* getRoot();

	void printQueryEvaluationTree();
	
	char* toString();
	void exportToFile(char* filename);

private:
	QueryEvaluationTreeNode* root;
};

#endif