/*
COPYRIGHT  � 2000-2004 
THE REGENTS OF THE UNIVERSITY OF MICHIGAN
ALL RIGHTS RESERVED

PERMISSION IS GRANTED TO USE, COPY, CREATE DERIVATIVE WORKS AND REDISTRIBUTE THIS SOFTWARE AND SUCH DERIVATIVE WORKS FOR 
NONCOMMERCIAL EDUCATION AND RESEARCH PURPOSES, SO LONG AS NO FEE IS CHARGED, AND SO LONG AS THE COPYRIGHT NOTICE ABOVE, 
THIS GRANT OF PERMISSION, AND THE DISCLAIMER BELOW APPEAR IN ALL COPIES MADE; AND SO LONG AS THE NAME OF THE UNIVERSITY 
OF MICHIGAN IS NOT USED IN ANY ADVERTISING OR PUBLICITY PERTAINING TO THE USE OR DISTRIBUTION OF THIS SOFTWARE WITHOUT 
SPECIFIC, WRITTEN PRIOR AUTHORIZATION.

THIS SOFTWARE IS PROVIDED AS IS, WITHOUT REPRESENTATION FROM THE UNIVERSITY OF MICHIGAN AS TO ITS FITNESS FOR ANY PURPOSE, 
AND WITHOUT WARRANTY BY THE UNIVERSITY OF MICHIGAN OF ANY KIND, EITHER EXPRESS OR IMPLIED, INCLUDING WITHOUT LIMITATION THE 
IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE. THE REGENTS OF THE UNIVERSITY OF MICHIGAN SHALL 
NOT BE LIABLE FOR ANY DAMAGES, INCLUDING SPECIAL, INDIRECT, INCIDENTAL, OR CONSEQUENTIAL DAMAGES, WITH RESPECT TO ANY CLAIM 
ARISING OUT OF OR IN CONNECTION WITH THE USE OF THE SOFTWARE, EVEN IF IT HAS BEEN OR IS HEREAFTER ADVISED OF THE POSSIBILITY 
OF SUCH DAMAGES.
*/

#include "QueryEvaluationTreeNode.h"

#ifndef __QueryEvaluationTreeGroupByNode_H
#define __QueryEvaluationTreeGroupByNode_H

#define OP_NONE		0
#define OP_COUNT	1
#define OP_SUM		2
#define OP_AVG		3
#define OP_MIN		4
#define	OP_MAX		5

#define ON_ATTRIBUTE_NUM		1
#define ON_ATTRIBUTE_STR		2
#define ON_TEXT_NUM				3
#define ON_TEXT_STR				4
#define ON_FANOUT_LOCAL			5
#define ON_FANOUT_ACTUAL		6
#define ON_DEPTH_LOCAL			7
#define ON_DEPTH_ACTUAL			8
#define ON_TEXT_LOCAL_NUM		9
#define ON_TEXT_LOCAL_STR		10
#define ON_ATTR_LOCAL_NUM		11
#define ON_ATTR_LOCAL_STR		12
#define ON_VALUE_NUM			13

#define GROUPBY_ATTRIBUTE_NUM	2
#define GROUPBY_ATTRIBUTE_STR	3
#define GROUPBY_TEXT_NUM		4
#define GROUPBY_TEXT_STR		5
#define GROUPBY_STARTKEY		6
#define GROUPBY_VALUE_NUM		7
#define GROUPBY_VALUE_STR		8


class QueryEvaluationTreeGroupByNode: public QueryEvaluationTreeNode
{
public:
	QueryEvaluationTreeGroupByNode(QueryEvaluationTreeNode* operand,
		int estimatedSize,int groupByWhat, NREType groupbyNRE, char *groupbyAttrName, int num, int *operation, int *opOnWhat,
		char **attrNames, NREType *nre,NREType rootNRE, NREType valueNRE,NREType *operationNRE, bool sort, bool keepTrees);
	~QueryEvaluationTreeGroupByNode();

	int getEstimatedSize();
	void setEstimatedSize(int estimatedSize);

	int getGroupByWhat();
	void setGroupByWhat(int groupByWhat);


	NREType getGroupByNRE();
	void setGroupByNRE(NREType groupbyNRE);

	char *getGroupByAttrName();
	void setGroupByAttrName(char *attrName);

	int getNum();
	void setNum(int num);
	
	int *getOperation();
	void setOperation(int *operation);

	int *getOpOnWhat();
	void setOpOnWhat(int *opOnWhat);

	NREType *getNRE();
	void setNRE(NREType *nre);

	char **getAttrNames();
	void setAttrNames(char **attrNames);

	NREType getRootNRE();
	void setRootNRE(NREType rootNRE);

	NREType getValueNRE();
	void setValueNRE(NREType valueNRE);

	NREType *getOperationNRE();
	void setOperationNRE(NREType *operationNRE);

	bool getSort();
	void setSort(bool sort);

	bool getKeepTrees();
	void setKeepTrees(bool keepTrees);

	QueryEvaluationTreeNode *getOperand();
	void setOperand(QueryEvaluationTreeNode* operand);
	void deleteStructures();

private:
	QueryEvaluationTreeNode* operand;

	int estimatedSize;
	int groupByWhat; 
	NREType groupbyNRE; 
	char *groupbyAttrName; 
	int num; 
	int *operation; 
	int *opOnWhat;
	char **attrNames; 
	NREType *nre;
	NREType rootNRE; 
	NREType valueNRE;
	NREType *operationNRE; 
	bool sort; 
	bool keepTrees;

};



#endif
