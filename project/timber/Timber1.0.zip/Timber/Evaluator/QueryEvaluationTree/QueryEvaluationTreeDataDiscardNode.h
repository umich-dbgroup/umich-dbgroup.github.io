#ifndef __QueryEvaluationTreeDataDiscardNode_H
#define __QueryEvaluationTreeDataDiscardNode_H

//#include "c:\timber\optimizer\queryevaluationtree\queryevaluationtreenode.h"

#include "QueryEvaluationTreeNode.h"
#include "../../DataMng/DataMng.h"


class QueryEvaluationTreeDataDiscardNode :
	public QueryEvaluationTreeNode
{
public:
	QueryEvaluationTreeDataDiscardNode(QueryEvaluationTreeNode* operand,
		int nodeindex,
		DataInstantiationSpecification* diSpecification);
	
	~QueryEvaluationTreeDataDiscardNode(void);
	
	QueryEvaluationTreeNode* getOperand();
	int getNodeIndexInWitnessTree();
	DataInstantiationSpecification* getDISpecification();
	void deleteStructures();

private:
	QueryEvaluationTreeNode* operand;
	int nodeIndexInWitnessTree;
	DataInstantiationSpecification* diSpecification;
};

#endif