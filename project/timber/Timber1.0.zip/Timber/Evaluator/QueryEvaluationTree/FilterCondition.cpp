/*
COPYRIGHT  � 2000-2004 
THE REGENTS OF THE UNIVERSITY OF MICHIGAN
ALL RIGHTS RESERVED

PERMISSION IS GRANTED TO USE, COPY, CREATE DERIVATIVE WORKS AND REDISTRIBUTE THIS SOFTWARE AND SUCH DERIVATIVE WORKS FOR 
NONCOMMERCIAL EDUCATION AND RESEARCH PURPOSES, SO LONG AS NO FEE IS CHARGED, AND SO LONG AS THE COPYRIGHT NOTICE ABOVE, 
THIS GRANT OF PERMISSION, AND THE DISCLAIMER BELOW APPEAR IN ALL COPIES MADE; AND SO LONG AS THE NAME OF THE UNIVERSITY 
OF MICHIGAN IS NOT USED IN ANY ADVERTISING OR PUBLICITY PERTAINING TO THE USE OR DISTRIBUTION OF THIS SOFTWARE WITHOUT 
SPECIFIC, WRITTEN PRIOR AUTHORIZATION.

THIS SOFTWARE IS PROVIDED AS IS, WITHOUT REPRESENTATION FROM THE UNIVERSITY OF MICHIGAN AS TO ITS FITNESS FOR ANY PURPOSE, 
AND WITHOUT WARRANTY BY THE UNIVERSITY OF MICHIGAN OF ANY KIND, EITHER EXPRESS OR IMPLIED, INCLUDING WITHOUT LIMITATION THE 
IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE. THE REGENTS OF THE UNIVERSITY OF MICHIGAN SHALL 
NOT BE LIABLE FOR ANY DAMAGES, INCLUDING SPECIAL, INDIRECT, INCIDENTAL, OR CONSEQUENTIAL DAMAGES, WITH RESPECT TO ANY CLAIM 
ARISING OUT OF OR IN CONNECTION WITH THE USE OF THE SOFTWARE, EVEN IF IT HAS BEEN OR IS HEREAFTER ADVISED OF THE POSSIBILITY 
OF SUCH DAMAGES.
*/

#include "FilterCondition.h"


FilterPredicate::FilterPredicate()
{
	iterLeft = NULL;
	iterRight = NULL;
	strLeft = NULL;
	strRight = NULL;
	indexName = NULL;
	fileName = NULL;
	openFileIndex = -1;
	application = FILTER_APP_DEFAULT;
}

FilterPredicate::FilterPredicate(int application, int leftType, NREType nreLeft, double numLeft, char *strLeft, IteratorClass *iterLeft,
					int operation,
					int rightType, NREType nreRight, double numRight, char *strRight, IteratorClass *iterRight,
					char *indexName, char *fileName, int openFileIndex)
{
	this->application = application;
	this->leftType = leftType;
	this->nreLeft = nreLeft;
	this->numLeft = numLeft;
	this->setStrLeft(strLeft);

	this->setIteratorLeft(iterLeft);

	this->operation = operation;

	this->rightType = rightType;
	this->nreRight = nreRight;
	this->numRight = numRight;
	this->setStrRight(strRight);
	this->setIteratorRight(iterRight);

	this->indexName = indexName;
	this->fileName = fileName;
	this->openFileIndex= openFileIndex;
}
				
FilterPredicate::~FilterPredicate()
{
	if (iterLeft)
	{
		delete iterLeft;
		iterLeft = NULL;
	}

	if (iterRight)
	{
		delete iterRight;
		iterRight = NULL;
	}

	if (strLeft) delete [] strLeft;
	if (strRight) delete [] strRight;

	if (fileName) delete [] fileName;
	if (indexName) delete [] indexName;
}


void FilterPredicate::setLeftType(int leftType)
{
	this->leftType = leftType;
}

void FilterPredicate::setRightType(int rightType)
{
	this->rightType = rightType;
}

void FilterPredicate::setOperation(int operation)
{
	this->operation = operation;
}

void FilterPredicate::setApplication(int application)
{
	this->application = application;
}

void FilterPredicate::setNRELeft(NREType nreLeft)
{
	this->nreLeft = nreLeft;
}

void FilterPredicate::setNRERight(NREType nreRight)
{
	this->nreRight = nreRight;
}

void FilterPredicate::setNumLeft(double numLeft)
{
	this->numLeft = numLeft;
}

void FilterPredicate::setNumRight(double numRight)
{
	this->numRight = numRight;
}

void FilterPredicate::setStrLeft(char *strLeft)
{
	this->strLeft = strLeft;
}

void FilterPredicate::setStrRight(char *strRight)
{
	this->strRight = strRight;
}


void FilterPredicate::setOpenFileIndex(int openFileIndex)
{
	this->openFileIndex = openFileIndex;
}

int FilterPredicate::getOpenFileIndex()
{
	return openFileIndex;
}

char *FilterPredicate::getIndexName()
{
	return  indexName;
}

void FilterPredicate::setIndexName(char *indexName)
{
	this->indexName = indexName;
}

char *FilterPredicate::getFileName()
{
	return  fileName;
}

void FilterPredicate::setFileName(char *fileName)
{
	this->fileName = fileName;
}


int FilterPredicate::getLeftType()
{
	return this->leftType;
}

int FilterPredicate::getRightType()
{
	return this->rightType;
}

int FilterPredicate::getOperation()
{
	return this->operation;
}

int FilterPredicate::getApplication()
{
	return this->application;
}

NREType FilterPredicate::getNRELeft()
{
	return this->nreLeft;
}

NREType FilterPredicate::getNRERight()
{
	return this->nreRight;
}

double FilterPredicate::getNumLeft()
{
	return this->numLeft;
}

double FilterPredicate::getNumRight()
{
	return this->numRight;
}

char *FilterPredicate::getStrLeft()
{
	return this->strLeft;
}

IteratorClass *FilterPredicate::getIterRight()
{
	return this->iterRight;
}

IteratorClass *FilterPredicate::getIterLeft()
{
	return this->iterLeft;
}

char *FilterPredicate::getStrRight()
{
	return this->strRight;
}


void FilterPredicate::setIteratorLeft(IteratorClass *iterLeft)
{
	this->iterLeft = iterLeft;
	if (iterLeft)
	{
		WitnessTree *iterIn;
		iterLeft->next(iterIn);
		if (iterIn)
		{
			ComplexListNode *n = (ComplexListNode *)iterIn->findNodeNRE(nreLeft);
			if (n)
			{
				if (n->IsDummy())
					strcpy(this->strLeft, n->GetDummyName());
			}
			else
				strcpy(this->strLeft,"ERROR");
		}
		else
			strcpy(this->strLeft,"ERROR");
	}
}

void FilterPredicate::setIteratorRight(IteratorClass *iterRight)
{
	this->iterRight = iterRight;
	if (iterRight)
	{
		WitnessTree *iterIn;
		iterRight->next(iterIn);
		if (iterIn)
		{
			ComplexListNode *n = (ComplexListNode *)iterIn->findNodeNRE(nreRight);
			if (n)
			{
				if (n->IsDummy())
					strcpy(this->strRight, n->GetDummyName());
			}
			else
				strcpy(this->strRight,"ERROR");
		}
		else
			strcpy(this->strRight,"ERROR");
	}
}


FilterCondition::FilterCondition()
{
	num = 0;
	maxSize = 0;
	this->conds = NULL;
}

FilterCondition::~FilterCondition()
{
	if (conds) delete [] conds;
}

void FilterCondition::setMaxSize(int maxSize)
{
	this->maxSize = maxSize;
	if (conds) delete [] conds;
	conds = new FilterPredicate[maxSize];
}

int FilterCondition::InsertCondition(FilterPredicate *pred)
{
	if (num >= maxSize)
	{
		globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"Evaluator",__FILE__,"Insertion of pred failed in FilterCondition. Number of conditions exceeded limit.");
		return FAILURE;
	}
	conds[num] = *pred;
	num++;
	return SUCCESS;
}

int FilterCondition::InsertCondition(int application,
					int leftType, NREType nreLeft, double numLeft, char *strLeft, IteratorClass *iterLeft,
					int operation,
					int rightType, NREType nreRight, double numRight, char *strRight, IteratorClass *iterRight,
					char *indexName, char *fileName, int openFileIndex)
{
	if (num >= maxSize)
	{
		globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"Evaluator",__FILE__,"Insertion of pred failed in FilterCondition. Number of conditions exceeded limit.");
		return FAILURE;
	}
	conds[num].setApplication(application);
	conds[num].setLeftType(leftType);
	conds[num].setNRELeft(nreLeft);
	conds[num].setNumLeft(numLeft);
	conds[num].setStrLeft(strLeft);

	conds[num].setOperation(operation);
	
	conds[num].setRightType(rightType);
	conds[num].setNRERight(nreRight);
	conds[num].setNumRight(numRight);
	conds[num].setStrRight(strRight);
	conds[num].setIteratorLeft(iterLeft);
	conds[num].setIteratorRight(iterRight);

	conds[num].setIndexName(indexName);
	conds[num].setFileName(fileName);
	conds[num].setOpenFileIndex(openFileIndex);


	num++;
	return SUCCESS;
}

int FilterCondition::getNum()
{
	return num;
}

FilterPredicate *FilterCondition::getCondAt(int index)
{
	if (index >= num)
		return NULL;

	return &conds[index];
}