/*
COPYRIGHT  � 2000-2004 
THE REGENTS OF THE UNIVERSITY OF MICHIGAN
ALL RIGHTS RESERVED

PERMISSION IS GRANTED TO USE, COPY, CREATE DERIVATIVE WORKS AND REDISTRIBUTE THIS SOFTWARE AND SUCH DERIVATIVE WORKS FOR 
NONCOMMERCIAL EDUCATION AND RESEARCH PURPOSES, SO LONG AS NO FEE IS CHARGED, AND SO LONG AS THE COPYRIGHT NOTICE ABOVE, 
THIS GRANT OF PERMISSION, AND THE DISCLAIMER BELOW APPEAR IN ALL COPIES MADE; AND SO LONG AS THE NAME OF THE UNIVERSITY 
OF MICHIGAN IS NOT USED IN ANY ADVERTISING OR PUBLICITY PERTAINING TO THE USE OR DISTRIBUTION OF THIS SOFTWARE WITHOUT 
SPECIFIC, WRITTEN PRIOR AUTHORIZATION.

THIS SOFTWARE IS PROVIDED AS IS, WITHOUT REPRESENTATION FROM THE UNIVERSITY OF MICHIGAN AS TO ITS FITNESS FOR ANY PURPOSE, 
AND WITHOUT WARRANTY BY THE UNIVERSITY OF MICHIGAN OF ANY KIND, EITHER EXPRESS OR IMPLIED, INCLUDING WITHOUT LIMITATION THE 
IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE. THE REGENTS OF THE UNIVERSITY OF MICHIGAN SHALL 
NOT BE LIABLE FOR ANY DAMAGES, INCLUDING SPECIAL, INDIRECT, INCIDENTAL, OR CONSEQUENTIAL DAMAGES, WITH RESPECT TO ANY CLAIM 
ARISING OUT OF OR IN CONNECTION WITH THE USE OF THE SOFTWARE, EVEN IF IT HAS BEEN OR IS HEREAFTER ADVISED OF THE POSSIBILITY 
OF SUCH DAMAGES.
*/

#include "QueryEvaluationTreeNode.h"

#ifndef __QueryEvaluationTreeValueJoinNode_H
#define __QueryEvaluationTreeValueJoinNode_H

#define JOINBY_ATTRIBUTE			1
#define JOINBY_TEXT					2
#define JOINBY_NOTHING				3
#define JOINBY_STARTKEY				4
#define JOINBY_ENDKEY				5
#define JOINBY_LEVEL				6
#define JOINBY_VALUE				7
#define JOINBY_DESC_TEXT			8
#define JOINBY_TREE					9
#define JOINBY_TREE_WITHOUT_ROOT	10

#define JOINOP_EQ_NUM			1
#define JOINOP_NE_NUM			2
#define JOINOP_LT_NUM			3
#define JOINOP_GT_NUM			4
#define JOINOP_LE_NUM			5
#define JOINOP_GE_NUM			6
#define JOINOP_EQ_STR			7
#define JOINOP_NE_STR			8
#define JOINOP_LT_STR			9
#define JOINOP_GT_STR			10
#define JOINOP_LE_STR			11
#define JOINOP_GE_STR			12
#define JOINOP_CONTAINED_BY		13
#define JOINOP_CONTAINS			14



class QueryEvaluationTreeValueJoinNode: public QueryEvaluationTreeNode
{
public:
	QueryEvaluationTreeValueJoinNode(QueryEvaluationTreeNode* left,
		QueryEvaluationTreeNode* right, NREType rootNRE, NREType leftNRE, NREType rightNRE,int leftTag,
		int rightTag, int estimatedSize, char *attrNameLeft,char *attrNameRight,
		int operation, int joinByWhatLeft, int joinByWhatRight, bool sortedInput, bool nest, bool outer
		,char *indexName,char *fileName,
		bool atLeastOne = false);
	~QueryEvaluationTreeValueJoinNode();

	QueryEvaluationTreeNode *getLeft();
	void setLeft(QueryEvaluationTreeNode *left);

	QueryEvaluationTreeNode *getRight();
	void setRight(QueryEvaluationTreeNode *right);


	void setLeftNRE(NREType leftNRE);
	NREType getLeftNRE();
	
	void setRightNRE(NREType rightNRE);
	NREType getRightNRE();

	void setRootNRE(NREType rootNRE);
	NREType getRootNRE();

	void setLeftTag(int leftTag);
	int getLeftTag();

	void setRightTag(int rightTag);
	int getRightTag();

	void setEstimatedSize(int size);
	int getEstimatedSize();

	void setAttrNameLeft(char *attrNameLeft);
	char *getAttrNameLeft();

	void setAttrNameRight(char *attrNameRight);
	char *getAttrNameRight();
	
	void setOperation(int operation);
	int getOperation();
	
	void setJoinByWhatLeft(int joinByWhatLeft);
	int getJoinByWhatLeft();

	void setJoinByWhatRight(int joinByWhatRight);
	int getJoinByWhatRight();

	void setSortedInput(bool sortedInput);
	bool getSortedInput();

	void setNest(bool nest);
	bool getNest();

	void setOuter(bool outer);
	bool getOuter();
	void deleteStructures();

	void setAtLeastOne(bool atLeastOne);
	bool getAtLeastOne();

	void setIndexName(char *indexName);
	char *getIndexName();

	void setFileName(char *fileName);
	char *getFileName();
private:
	QueryEvaluationTreeNode* left;
	QueryEvaluationTreeNode* right;
	NREType leftNRE;
	NREType rightNRE;
	NREType rootNRE;
	int leftTag;
	int rightTag;
	int estimatedSize;
	char *attrNameLeft;
	char *attrNameRight;
	int operation;
	int joinByWhatLeft, joinByWhatRight;
	bool sortedInput;
	bool nest;
	bool outer;
	bool atLeastOne;
	char *indexName;
	char *fileName;
};


#endif
