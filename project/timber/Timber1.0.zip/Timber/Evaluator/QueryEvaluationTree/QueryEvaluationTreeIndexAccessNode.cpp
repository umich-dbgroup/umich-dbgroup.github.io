#include "QueryEvaluationTreeIndexAccessNode.h"


QueryEvaluationTreeIndexAccessNode::QueryEvaluationTreeIndexAccessNode(char* indexname, NREType nre,
																	   char* filename, 
																	   int indextype, 
																	   int indexservertype,
																	   Value* minval,
																	   Value* maxval)
																	   : QueryEvaluationTreeNode(EVALUATION_OP_INDEX_ACCESS)

{
	this->indexName =indexname;
	this->nre = nre;
	this->fileName =  filename;
	this->indexType = indextype;
	this->indexServerType = indexservertype;
	this->minIndexValue = minval;
	this->maxIndexValue = maxval;

	this->value = NULL;
	this->value2 = NULL;
	this->tagIdIndex = false;
}	



QueryEvaluationTreeIndexAccessNode::QueryEvaluationTreeIndexAccessNode(char* indexname, NREType nre,
																	   char *fileName,
										//SelectionCondition* selectcond, 
										void *value , 
										void *value2)
: QueryEvaluationTreeNode(EVALUATION_OP_INDEX_ACCESS)
{
	this->indexName =indexname;
	this->nre = nre;
	this->fileName =  fileName;
	this->value = value;
	this->value2 = value2;
	this->maxIndexValue = NULL;
	this->minIndexValue = NULL;
	fromFile = false;

	this->tagIdIndex = false;
}


QueryEvaluationTreeIndexAccessNode::~QueryEvaluationTreeIndexAccessNode()
{
/*	if (indexCondition)
		delete this->indexCondition;
*/
	//somehow delete value
	if (this->value)
		delete [] (char *)value;
	if (this->value2)
		delete [] (char *)value2;
	delete [] fileName;
}

char* QueryEvaluationTreeIndexAccessNode::getIndexName()
{
	return this->indexName;
}

/*
SelectionCondition* QueryEvaluationTreeIndexAccessNode::getIndexCondition()
{
	return this->indexCondition;
}
*/
void QueryEvaluationTreeIndexAccessNode::setIndexName(char* indexname)
{
	this->indexName= indexname;
}

/*
void QueryEvaluationTreeIndexAccessNode::setIndexCondition(SelectionCondition* indexcond)
{
	this->indexCondition = indexcond;
}
*/


void *QueryEvaluationTreeIndexAccessNode::getValue()
{
	return value;
}

void QueryEvaluationTreeIndexAccessNode::setValue(void *value)
{
	this->value = value;
}

void *QueryEvaluationTreeIndexAccessNode::getValue2()
{
	return value2;
}

void QueryEvaluationTreeIndexAccessNode::setValue2(void *value2)
{
	this->value2 = value2;
}

int QueryEvaluationTreeIndexAccessNode::getIndexType()
{
	return this->indexType;
}

void QueryEvaluationTreeIndexAccessNode::setIndexType(int indexType)
{
	this->indexType = indexType;
}

serial_t QueryEvaluationTreeIndexAccessNode::getFid()
{
	return this->fid;
}

void QueryEvaluationTreeIndexAccessNode::setFid(serial_t fid)
{
	this->fid = fid;
}


void QueryEvaluationTreeIndexAccessNode::setFromFile(bool fromFile)
{
	this->fromFile = fromFile;
}

bool QueryEvaluationTreeIndexAccessNode::isFromFile()
{
	return this->fromFile;
}


void QueryEvaluationTreeIndexAccessNode::setShoreOrGist(int shoreOrGist)
{
	this->shoreOrGist = shoreOrGist;
}

int QueryEvaluationTreeIndexAccessNode::getShoreOrGist()
{
	return shoreOrGist;
}

void QueryEvaluationTreeIndexAccessNode::setFileName(char *fileName)
{
	this->fileName= fileName;
}

char *QueryEvaluationTreeIndexAccessNode::getFileName()
{
	return this->fileName;
}

NREType QueryEvaluationTreeIndexAccessNode::getNRE()
{
	return nre;
}

void QueryEvaluationTreeIndexAccessNode::setNRE(NREType nre)
{
	this->nre = nre;
}
/*
void QueryEvaluationTreeIndexAccessNode::printQueryEvaluationTreeNode(bool recursive, int depth)
{
	char prefix[50];
	for (int i=0; i<depth; i++)
		for (int j=0; j<4; j++)
			prefix[i*4+j] = ' ';
	prefix[depth*4] = '\0';

	cout << prefix << "This is an Index Access Node:" << endl;
	cout << prefix << "File Name: " << this->fileName << endl;
	cout << prefix << "Index Name: " << this->indexName << endl;

	switch (this->indexType)
	{
	case INT_INDEX: cout << "INTEGER index" << endl; break;
	case STRING_INDEX: cout << "STRING index" << endl; break;
	case FLOAT_INDEX: cout << "FLOAT index" << endl; break;
	case DOUBLE_INDEX: cout << "DOUBLE index" << endl; break;
	default: cout << "error with index type" << endl; break;
	}
	
	cout << "index server type: ";
	switch (this->indexServerType)
	{
	case GIST_INDEX: cout << "GIST index" << endl; break;
	case SHORE_INDEX: cout << "SHORE index" << endl; break;
	case HASH_INDEX: cout << "HASH index" << endl; break;
	default: cout << "error with index server type" << endl; break;
	}

	cout << "Min Index Value: " << this->minIndexValue->valueToString();
	cout << "Max Index Value: " << this->maxIndexValue->valueToString();

	//	 	printf("%s  indexvalue = %s\n", prefix, this->value);
}

char* QueryEvaluationTreeIndexAccessNode::toString()
{
	char indexAccessString[1000]; // just use a magic number 100 here. it is hard to tell the size, because Shurug uses void* for value.

	strcpy(indexAccessString, "I,");
	strcat(indexAccessString, this->indexName);
	strcat(indexAccessString, ",");
	strcat(indexAccessString, this->fileName);
	strcat(indexAccessString, ",");
	
	switch (this->indexServerType)
	{
	case GIST_INDEX:	strcat(indexAccessString, "GIST,"); break;
	case SHORE_INDEX:	strcat(indexAccessString, "SHORE,"); break;
	default:			 cerr << "Warning: Invalid index server type...." << endl; return "";
	}

	switch (this->indexType)
	{
	case INT_INDEX:		strcat(indexAccessString, "INT,"); break;
	case STRING_INDEX:  strcat(indexAccessString, "STR,"); break;
	case FLOAT_INDEX:	strcat(indexAccessString, "FLT,"); break;
	case DOUBLE_INDEX:	strcat(indexAccessString, "FLT,"); break;
	default:			cout << "error with index type" << endl; break;
	}

	strcat(indexAccessString, this->minIndexValue->valueToString());

	if (this->minIndexValue->compareValue(VALUE_COMP_OP_NE, this->maxIndexValue))
	{
		strcat(indexAccessString, ",");
		strcat(indexAccessString, this->maxIndexValue->valueToString());
	}

	strcat(indexAccessString, "\n");

	char* outputStr = new char[strlen(indexAccessString)];
	strcpy(outputStr, indexAccessString);
	return outputStr;
}*/

void QueryEvaluationTreeIndexAccessNode::deleteStructures()
{
	if (indexName) delete [] indexName;
	//if (fileName) delete [] fileName;
	if (minIndexValue) delete minIndexValue;
	if (maxIndexValue) delete maxIndexValue;
	
/*	if (value) delete [] value;
	if (value2) delete [] value2;*/
}