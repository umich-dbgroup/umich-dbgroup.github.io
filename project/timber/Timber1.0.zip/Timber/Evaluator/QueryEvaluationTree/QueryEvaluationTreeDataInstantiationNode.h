#ifndef __QueryEvaluationTreeDataInstantiationNode_H
#define __QueryEvaluationTreeDataInstantiationNode_H

//#include "c:\timber\optimizer\queryevaluationtree\queryevaluationtreenode.h"

#include "QueryEvaluationTreeNode.h"
#include "../../DataMng/DataMng.h"


class QueryEvaluationTreeDataInstantiationNode :
	public QueryEvaluationTreeNode
{
public:
	QueryEvaluationTreeDataInstantiationNode(QueryEvaluationTreeNode* operand,
		int nodeindex,
		DataInstantiationSpecification* diSpecification);
	
	~QueryEvaluationTreeDataInstantiationNode(void);
	
	QueryEvaluationTreeNode* getOperand();
	int getNodeIndexInWitnessTree();
	DataInstantiationSpecification* getDISpecification();
	void deleteStructures();

private:
	QueryEvaluationTreeNode* operand;
	int nodeIndexInWitnessTree;
	DataInstantiationSpecification* diSpecification;
};

#endif