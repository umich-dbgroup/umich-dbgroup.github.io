/*
COPYRIGHT  � 2000-2004 
THE REGENTS OF THE UNIVERSITY OF MICHIGAN
ALL RIGHTS RESERVED

PERMISSION IS GRANTED TO USE, COPY, CREATE DERIVATIVE WORKS AND REDISTRIBUTE THIS SOFTWARE AND SUCH DERIVATIVE WORKS FOR 
NONCOMMERCIAL EDUCATION AND RESEARCH PURPOSES, SO LONG AS NO FEE IS CHARGED, AND SO LONG AS THE COPYRIGHT NOTICE ABOVE, 
THIS GRANT OF PERMISSION, AND THE DISCLAIMER BELOW APPEAR IN ALL COPIES MADE; AND SO LONG AS THE NAME OF THE UNIVERSITY 
OF MICHIGAN IS NOT USED IN ANY ADVERTISING OR PUBLICITY PERTAINING TO THE USE OR DISTRIBUTION OF THIS SOFTWARE WITHOUT 
SPECIFIC, WRITTEN PRIOR AUTHORIZATION.

THIS SOFTWARE IS PROVIDED AS IS, WITHOUT REPRESENTATION FROM THE UNIVERSITY OF MICHIGAN AS TO ITS FITNESS FOR ANY PURPOSE, 
AND WITHOUT WARRANTY BY THE UNIVERSITY OF MICHIGAN OF ANY KIND, EITHER EXPRESS OR IMPLIED, INCLUDING WITHOUT LIMITATION THE 
IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE. THE REGENTS OF THE UNIVERSITY OF MICHIGAN SHALL 
NOT BE LIABLE FOR ANY DAMAGES, INCLUDING SPECIAL, INDIRECT, INCIDENTAL, OR CONSEQUENTIAL DAMAGES, WITH RESPECT TO ANY CLAIM 
ARISING OUT OF OR IN CONNECTION WITH THE USE OF THE SOFTWARE, EVEN IF IT HAS BEEN OR IS HEREAFTER ADVISED OF THE POSSIBILITY 
OF SUCH DAMAGES.
*/

#include "QueryEvaluationTreeIndexHashValueJoinNode.h"
#include <string>

QueryEvaluationTreeIndexHashValueJoinNode::QueryEvaluationTreeIndexHashValueJoinNode(QueryEvaluationTreeNode* oper1, 
		QueryEvaluationTreeNode* oper2,
		int size,
		char *indexName,char *fileName,
		 NREType leftNRE, NREType rightNRE, NREType rootNRE,bool outer, bool atLeastOne)
: QueryEvaluationTreeNode(EVALUATION_OP_INDEXHASH_JOIN)
{
	this->oper1 = oper1;
	this->oper2 = oper2;
	this->size = size;
	this->leftNRE = leftNRE;
	this->rightNRE = rightNRE;
	this->rootNRE = rootNRE;
	
	this->atLeastOne = atLeastOne;
	this->outer = outer;
	this->indexName = indexName;
	this->fileName = fileName;
}



QueryEvaluationTreeIndexHashValueJoinNode::~QueryEvaluationTreeIndexHashValueJoinNode()
{
	if (oper1)
		delete oper1;

	if (oper2)
		delete oper2;
	
	if (fileName) delete [] fileName;
}


void QueryEvaluationTreeIndexHashValueJoinNode::setOper1(QueryEvaluationTreeNode *oper1)
{
	this->oper1 = oper1;
}

QueryEvaluationTreeNode *QueryEvaluationTreeIndexHashValueJoinNode::getOper1()
{
	return this->oper1;
}

void QueryEvaluationTreeIndexHashValueJoinNode::setOper2(QueryEvaluationTreeNode *oper2)
{
	this->oper2 = oper2;
}

QueryEvaluationTreeNode *QueryEvaluationTreeIndexHashValueJoinNode::getOper2()
{
	return this->oper2;
}


void QueryEvaluationTreeIndexHashValueJoinNode::setSize(int size)
{
	this->size = size;
}

int QueryEvaluationTreeIndexHashValueJoinNode::getSize()
{
	return this->size;
}


void QueryEvaluationTreeIndexHashValueJoinNode::setLeftNRE(NREType leftNRE)
{
	this->leftNRE = leftNRE;
}

NREType QueryEvaluationTreeIndexHashValueJoinNode::getLeftNRE()
{
	return this->leftNRE;
}

void QueryEvaluationTreeIndexHashValueJoinNode::setRightNRE(NREType rightNRE)
{
	this->rightNRE = rightNRE;
}

NREType QueryEvaluationTreeIndexHashValueJoinNode::getRightNRE()
{
	return this->rightNRE;
}

void QueryEvaluationTreeIndexHashValueJoinNode::setRootNRE(NREType rootNRE)
{
	this->rootNRE = rootNRE;
}

NREType QueryEvaluationTreeIndexHashValueJoinNode::getRootNRE()
{
	return this->rootNRE;
}



void QueryEvaluationTreeIndexHashValueJoinNode::setAtLeastOne(bool atLeastOne)
{
	this->atLeastOne = atLeastOne;
}

bool QueryEvaluationTreeIndexHashValueJoinNode::getAtLeastOne()
{
	return this->atLeastOne;
}

void QueryEvaluationTreeIndexHashValueJoinNode::setOuter(bool outer)
{
	this->outer = outer;
}

bool QueryEvaluationTreeIndexHashValueJoinNode::getOuter()
{
	return this->outer;
}

void QueryEvaluationTreeIndexHashValueJoinNode::setIndexName(char *indexName)
{
	this->indexName = indexName;
}

char *QueryEvaluationTreeIndexHashValueJoinNode::getIndexName()
{
	return this->indexName;
}

void QueryEvaluationTreeIndexHashValueJoinNode::setFileName(char *fileName)
{
	this->fileName = fileName;
}

char *QueryEvaluationTreeIndexHashValueJoinNode::getFileName()
{
	return this->fileName;
}

void QueryEvaluationTreeIndexHashValueJoinNode::deleteStructures()
{
	if (indexName) delete [] indexName;
	oper1->deleteStructures();
	oper2->deleteStructures();
}