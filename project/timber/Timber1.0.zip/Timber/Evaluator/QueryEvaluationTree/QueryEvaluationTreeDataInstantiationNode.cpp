#include "queryevaluationtreedatainstantiationnode.h"

QueryEvaluationTreeDataInstantiationNode
::QueryEvaluationTreeDataInstantiationNode(
	QueryEvaluationTreeNode* operand,
	int nodeindex,
	DataInstantiationSpecification* dispec): QueryEvaluationTreeNode(EVALUATION_OP_DATA_INSTANTIATION)
{
	this->operand = operand;
	this->nodeIndexInWitnessTree = nodeindex;
	this->diSpecification = dispec;
}

QueryEvaluationTreeDataInstantiationNode::~QueryEvaluationTreeDataInstantiationNode(void)
{
}

QueryEvaluationTreeNode* QueryEvaluationTreeDataInstantiationNode
::getOperand()
{
	return this->operand;
}

int QueryEvaluationTreeDataInstantiationNode
::getNodeIndexInWitnessTree()
{
	return this->nodeIndexInWitnessTree;
}

DataInstantiationSpecification* QueryEvaluationTreeDataInstantiationNode
::getDISpecification()
{
	return this->diSpecification;
}

void QueryEvaluationTreeDataInstantiationNode::deleteStructures()
{
	if (this->diSpecification)
		delete this->diSpecification;

	operand->deleteStructures();
}