/*
COPYRIGHT  � 2000-2004 
THE REGENTS OF THE UNIVERSITY OF MICHIGAN
ALL RIGHTS RESERVED

PERMISSION IS GRANTED TO USE, COPY, CREATE DERIVATIVE WORKS AND REDISTRIBUTE THIS SOFTWARE AND SUCH DERIVATIVE WORKS FOR 
NONCOMMERCIAL EDUCATION AND RESEARCH PURPOSES, SO LONG AS NO FEE IS CHARGED, AND SO LONG AS THE COPYRIGHT NOTICE ABOVE, 
THIS GRANT OF PERMISSION, AND THE DISCLAIMER BELOW APPEAR IN ALL COPIES MADE; AND SO LONG AS THE NAME OF THE UNIVERSITY 
OF MICHIGAN IS NOT USED IN ANY ADVERTISING OR PUBLICITY PERTAINING TO THE USE OR DISTRIBUTION OF THIS SOFTWARE WITHOUT 
SPECIFIC, WRITTEN PRIOR AUTHORIZATION.

THIS SOFTWARE IS PROVIDED AS IS, WITHOUT REPRESENTATION FROM THE UNIVERSITY OF MICHIGAN AS TO ITS FITNESS FOR ANY PURPOSE, 
AND WITHOUT WARRANTY BY THE UNIVERSITY OF MICHIGAN OF ANY KIND, EITHER EXPRESS OR IMPLIED, INCLUDING WITHOUT LIMITATION THE 
IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE. THE REGENTS OF THE UNIVERSITY OF MICHIGAN SHALL 
NOT BE LIABLE FOR ANY DAMAGES, INCLUDING SPECIAL, INDIRECT, INCIDENTAL, OR CONSEQUENTIAL DAMAGES, WITH RESPECT TO ANY CLAIM 
ARISING OUT OF OR IN CONNECTION WITH THE USE OF THE SOFTWARE, EVEN IF IT HAS BEEN OR IS HEREAFTER ADVISED OF THE POSSIBILITY 
OF SUCH DAMAGES.
*/

#ifndef __FilterCondition_h
#define __FilterCondition_h


#include "..\Evaluator\Evaluator_definitions.h"

#define MAX_FILTER_STR_LENGTH		1000

//Filter operation options
#define FILTER_EQ_NUM				1
#define FILTER_LT_NUM				2
#define FILTER_LE_NUM				3	
#define FILTER_NE_NUM				4
#define FILTER_GT_NUM				5
#define FILTER_GE_NUM				6

#define FILTER_EQ_STR				7
#define FILTER_LT_STR				8
#define FILTER_LE_STR				9	
#define FILTER_NE_STR				10
#define FILTER_GT_STR				11
#define FILTER_GE_STR				12

#define FILTER_STARTS_WITH			13
#define FILTER_IN_BEGINING			14
#define FILTER_CONTAINS				15
#define FILTER_CONTAINED			16
#define FILTER_CONTAINS_WITH_OFFSET	17
#define FILTER_NOT_START_WITH		18
#define FILTER_NOT_CONTAIN			19

//Filter left and right types options
#define FILTER_VALUE				1
#define FILTER_ATTR_VALUE			2
#define FILTER_LENGTH				3
#define FILTER_TEXT					4
#define FILTER_DESC_TEXT			34

#define	FILTER_LOCALCHILD_VALUE		5
#define FILTER_LOCALCHILD_ATTR_VAL	6
#define FILTER_LOCALCHILD_LENGTH	7
#define FILTER_LOCALCHILD_TEXT		8
#define FILTER_LOCALCHILD_DESC_TEXT	35

#define FILTER_ACTUALCHILD_VALUE	9
#define	FILTER_ACTUALCHILD_ATTR_VAL	10
#define FILTER_ACTUALCHILD_LENGTH	11
#define FILTER_ACTUALCHILD_TEXT		12
#define FILTER_ACTUALCHILD_DESC_TEXT	36

#define	FILTER_LOCALANCS_VALUE		13
#define FILTER_LOCALANCS_ATTR_VAL	14
#define FILTER_LOCALANCS_LENGTH		15
#define FILTER_LOCALANCS_TEXT		16
#define FILTER_LOCALANCS_DESC_TEXT	37

#define FILTER_ACTUALANCS_VALUE		17
#define	FILTER_ACTUALANCS_ATTR_VAL	18
#define FILTER_ACTUALANCS_LENGTH	19
#define FILTER_ACTUALANCS_TEXT		20
#define FILTER_ACTUALANCS_DESC_TEXT	38

#define FILTER_CONST				21
#define FILTER_CONST_FROM_ITER		22

#define FILTER_LOCAL_FANOUT			23
#define FILTER_ACTUAL_FANOUT		24

#define FILTER_LOCALSUBTREE_DEPTH	25
#define FILTER_ACTUALSUBTREE_DEPTH	26

#define FILTER_STARTKEY				27
#define FILTER_ENDKEY				28
#define FILTER_LEVEL				29

#define FILTER_HAS_ATTR				30
#define FILTER_HAS_CHILD			31
#define FILTER_HAS_ANCS				32
#define FILTER_HAS_TEXT				33

#define FILTER_APP_EVERY				1
#define FILTER_APP_AT_LEAST_ONE			2
#define FILTER_APP_EXACTLY_ONE			3
#define FILTER_APP_EXACTLY_ONE_EXISTS	4

#define FILTER_APP_DEFAULT			FILTER_APP_AT_LEAST_ONE



class FilterPredicate
{
public:
	FilterPredicate();
	FilterPredicate(int application,
					int leftType, NREType nreLeft, double numLeft, char *strLeft, IteratorClass *iterLeft,
					int operation,
					int rightType, NREType nreRight, double numRight, char *strRight, IteratorClass *iterRight,
					char *indexName, char *fileName, int openFileIndex);

	~FilterPredicate();

	void setApplication(int application);
	void setLeftType(int leftType);
	void setRightType(int rightType);
	void setOperation(int operation);
	void setNRELeft(NREType nreLeft);
	void setNRERight(NREType nreRight);
	void setNumLeft(double numLeft);
	void setNumRight(double numRight);
	void setStrLeft(char *strLeft);
	void setStrRight(char *strRight);
	void setIteratorLeft(IteratorClass *iterLeft);
	void setIteratorRight(IteratorClass *iterRight);


	int getApplication();
	int getLeftType();
	int getRightType();
	int getOperation();
	NREType getNRELeft();
	NREType getNRERight();
	double getNumLeft();
	double getNumRight();
	char *getStrLeft();
	char *getStrRight();
	IteratorClass *getIterLeft();
	IteratorClass *getIterRight();
	
	char *getIndexName();
	void setIndexName(char *indexName);

	char *getFileName();
	void setFileName(char *fileName);

	int getOpenFileIndex();
	void setOpenFileIndex(int openFileIndex);


private:
	int application;
	int leftType;
	int rightType;
	int operation;

	NREType nreLeft;
	double numLeft;
	char *strLeft;
	IteratorClass *iterLeft;

	NREType nreRight;
	double numRight;
	char *strRight;
	IteratorClass *iterRight;

	char *indexName;
	char *fileName;
	int openFileIndex;
};

/** 
@param leftType/rightType is the type of the operation to be done. it is one of the following:
FILTER_VALUE this means use in comparing the value of the indexed (leftIndex, rightIndex) node itself. The value is 
				tag name if the node is an element node.
				attribute value of attribute leftStr/rightStr if the node is an attribute node.
				text if it is a text node.
				document name if it is a document node.
FILTER_ATTR_VALUE	this means in comparing, get the attribute node of the indexed node. then, get the value of the
				attribute with the name leftStr/rightStr.
FILTER_LENGTH this is similar to FILTER_VALUE except that the length of the value is used.
FILTER_TEXT	this means in comparing, get the text children of indexed node and use text from them.

The following types are similar to the top four except that instead of using the node indexed by leftIndex/rightIndex,
				use the local/actual child or ancs of the indexed node. Local ancs/child means the child of the indexed
				node in the witness tree (may not be true in actual DB). Actual is the actual ancs/child in DB.
				leftNum/rightNum are used to decide the number of the child used (1 is first child, 2 second child...)
				in the case of the child. In case of Ancs, leftNum/rightNum are used to decide how many levels up the 
				ancs should be (1 is immidiate parent, 2 grand parent...).
FILTER_LOCALCHILD_VALUE	
FILTER_LOCALCHILD_ATTR_VAL
FILTER_LOCALCHILD_LENGTH
FILTER_LOCALCHILD_TEXT	

FILTER_ACTUALCHILD_VALUE
FILTER_ACTUALCHILD_ATTR_VAL	
FILTER_ACTUALCHILD_LENGTH
FILTER_ACTUALCHILD_TEXT	

FILTER_LOCALANCS_VALUE	
FILTER_LOCALANCS_ATTR_VAL
FILTER_LOCALANCS_LENGTH	
FILTER_LOCALANCS_TEXT

FILTER_ACTUALANCS_VALUE	
FILTER_ACTUALANCS_ATTR_VAL
FILTER_ACTUALANCS_LENGTH
FILTER_ACTUALANCS_TEXT


FILTER_CONST this means that in comparison use a const value (don't get it from tree). leftNum/rightNum should hold 
				this value if number comparison is used, leftStr/rightStr should hold this value if string comparison
				is used. usually leftType is not const and rightType is const. If you are comparing two nodes in the
				tree with each other, then neither left nor right type should be const.

FILTER_CONST_FROM_ITER this means that in comparison use a const value that is taken from an iterator 
				iterLeft/iterRight. indexLeft/indexRight should hold the index of the node in the output 
				tree of the iterator that has the value. Once the predicate is inserted in the condition,
				the iterator is called exactly once and the value obtained is stored in strLeft/strRight.

FILTER_LOCAL_FANOUT	this means get the number of children in the witness tree of the node indexed by 
				leftIndex/rightIndex. and use this number in comparison.
FILTER_ACTUAL_FANOUT this means get the number of children in the actual DB of the node indexed by 
				leftIndex/rightIndex. and use this number in comparison.

FILTER_LOCALSUBTREE_DEPTH this means get the depth of subtree in the witness tree of the node indexed by 
				leftIndex/rightIndex. and use this number in comparison.
FILTER_ACTUALSUBTREE_DEPTH this means get the depth of subtree in the actual DB of the node indexed by 
				leftIndex/rightIndex. and use this number in comparison.

FILTER_STARTKEY	uses in comparison the value of start key of node indexed by leftIndex/rightIndex. 
FILTER_ENDKEY uses in comparison the value of end key of node indexed by leftIndex/rightIndex.
FILTER_LEVEL uses in comparison the value of level of node indexed by leftIndex/rightIndex.

FILTER_HAS_ATTR	checks for existancs of an attribute. not implemented yet.
FILTER_HAS_CHILD checks for existancs of a child. not implemented yet.
FILTER_HAS_ANCS	checks for existancs of an ancs. not implemented yet.
FILTER_HAS_TEXT	checks for existancs of text. not implemented yet.
 
@param indexLeft/indexRight is index of the node in the tree involved with the left/right predicate.
@param numLeft/numRight are numbers needed in identifing the ancs or child. also as a value for const. read above.
@param strLeft/strRight are used are attr names or const value. read above.
@param iterLeft/iterRight are used when type is FILTER_CONST_FROM_ITER. read above.
@param operation is the operation performed between left and right sides. it is one of the following:
the following use number comparison:
FILTER_EQ_NUM tests for equality.
FILTER_LT_NUM tests for less than.
FILTER_LE_NUM tests for less than or equal.
FILTER_NE_NUM tests for non equality.
FILTER_GT_NUM tests for greater than.
FILTER_GE_NUM tests for greater than or equal.

the following use string comparison:
FILTER_EQ_STR tests for equality.
FILTER_LT_STR tests for less than.
FILTER_LE_STR tests for less than or equal.
FILTER_NE_STR tests for non equality.
FILTER_GT_STR tests for greater than.
FILTER_GE_STR tests for greater than or equal.

FILTER_STARTS_WITH tests whether or not left value starts with right value.
FILTER_IN_BEGINING	tests whether or not right value starts with right value.
FILTER_CONTAINS	tests whether or not left value contains right value.
FILTER_CONTAINED tests whether or not left value is contained in right value.

**/

class FilterCondition
{
public:
	FilterCondition();
	~FilterCondition();

	void setMaxSize(int maxSize);
	int InsertCondition(FilterPredicate *pred);
	int InsertCondition(int application,
					int leftType, NREType nreLeft, double numLeft, char *strLeft, IteratorClass *iterLeft,
					int operation,
					int rightType, NREType nreRight, double numRight, char *strRight, IteratorClass *iterRight,
					char *indexName, char *fileName, int openFileIndex);

	FilterPredicate *getCondAt(int index);
	int getNum();

private:
	FilterPredicate *conds;
	int maxSize;
	int num;
};



#endif