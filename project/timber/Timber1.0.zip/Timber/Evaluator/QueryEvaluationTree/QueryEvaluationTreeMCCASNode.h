#include "QueryEvaluationTreeNode.h"

#ifndef __QueryEvaluationMCCASNode_H
#define __QueryEvaluationMCCASNode_H
class QueryEvaluationTreeMCCASNode: public QueryEvaluationTreeNode
{
public:
	QueryEvaluationTreeMCCASNode(
		QueryEvaluationTreeNode** operands,
		int numInputs, 
		NREType *nre,
		NREType assignedNre,
		int expectedInputSize, 
		int expectedDepth);
	~QueryEvaluationTreeMCCASNode();

	int getInputs();
	void setInputs(IteratorClass **inputs);

	int getNumInputs();
	void setNumInputs(int numInputs);

	int getExpectedInputSize();
	void setExpectedInputSize(int expectedInputSize);

	int getExpectedDepth();
	void setExpectedDepth(int expectedDepth);

	char* getParentIndexName();
	void setParentIndexName(char* parentIndexname);

	QueryEvaluationTreeNode **getOperands();
	void setOperands(QueryEvaluationTreeNode** operands);

	NREType *getNRE();
	void setNRE(NREType *nre);

	NREType getAssignedNRE();
	void setAssignedNRE(NREType nre);
	void deleteStructures();

private:
	QueryEvaluationTreeNode** operands;
	int numInputs; 
	NREType *nre;
	NREType assignedNre;
	int expectedInputSize; 
	int expectedDepth;
	char *parentIndexName;
};
#endif
