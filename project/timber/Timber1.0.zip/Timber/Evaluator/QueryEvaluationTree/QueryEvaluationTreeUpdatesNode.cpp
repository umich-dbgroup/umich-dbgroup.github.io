#include "QueryEvaluationTreeUpdatesNode.h"

//QueryEvaluationTreeUpdatesNode::QueryEvaluationTreeUpdatesNode(
//	QueryEvaluationTreeNode* operand, int updateType, NREType nre, char* indexToUpdate)
//: QueryEvaluationTreeNode(EVALUATION_OP_UPDATES)
//{
//	this->operand = operand;
//	this->updateType = updateType;
//	this->nre = nre;
//	//this->indexToUpdate = new char[strlen(indexToUpdate)+1];
//	//strcpy(this->indexToUpdate, indexToUpdate);
//	this->setIndexToUpdate(indexToUpdate);
//}

QueryEvaluationTreeUpdatesNode::QueryEvaluationTreeUpdatesNode(QueryEvaluationTreeNode* operand, 
	int updateType, NREType nre, char* textValue1, char* textValue2, char* textValue3, char* textValue4)
	//, vector<AttributeInfo> repeated)
	:QueryEvaluationTreeNode(EVALUATION_OP_UPDATES)
{
	//this->QueryEvaluationTreeUpdatesNode(operand, updateType, nre, indexToUpdate)
	this->operand = operand;
	this->updateType = updateType;
	this->nre = nre;
	//this->setIndexToUpdate(indexToUpdate);

	this->setTextValue1(textValue1);
	this->setTextValue2(textValue2);
	this->setTextValue3(textValue3);
	this->setTextValue4(textValue4);

	//this->repeated = repeated;
	//this->repeated = *new vector<AttributeInfo>;
}

QueryEvaluationTreeUpdatesNode::~QueryEvaluationTreeUpdatesNode()
{
	if (operand)
		delete operand;

	//if (indexToUpdate)
	//	delete [] indexToUpdate;

	if (textValue1)
		delete [] textValue1;

	if (textValue2)
		delete [] textValue2;

	if (textValue3)
		delete [] textValue3;

	if (textValue4)
		delete [] textValue4;
	
	//repeated.clear();
	//vector<AttributeInfo>::iterator it;
	//for (it = repeated.begin(); it != repeated.end(); it++) {
	//	delete *it;
	//}
}


QueryEvaluationTreeNode *QueryEvaluationTreeUpdatesNode::getOperand()
{
	return this->operand;
}

void QueryEvaluationTreeUpdatesNode::setOperand(QueryEvaluationTreeNode *operand)
{
	this->operand = operand;
}

int QueryEvaluationTreeUpdatesNode::getUpdateType() {
	return this->updateType;
}
void QueryEvaluationTreeUpdatesNode::setUpdateType(int updateType) {
	this->updateType = updateType;
}

NREType QueryEvaluationTreeUpdatesNode::getNRE() {
	return this->nre;
}
void QueryEvaluationTreeUpdatesNode::setNRE(NREType nre) {
	this->nre = nre;
}

//char *QueryEvaluationTreeUpdatesNode::getIndexToUpdate() {
//	return this->indexToUpdate;
//}
//void QueryEvaluationTreeUpdatesNode::setIndexToUpdate(char * indexToUpdate) {
//	this->indexToUpdate = new char[strlen(indexToUpdate)+1];
//	strcpy(this->indexToUpdate, indexToUpdate);
//}


char *QueryEvaluationTreeUpdatesNode::getTextValue1() {
	return this->textValue1;
}
void QueryEvaluationTreeUpdatesNode::setTextValue1(char * textValue) {
	//should just use the string class... don't have to worry about freeing memory
	textValue1 = createString(textValue);
}

char *QueryEvaluationTreeUpdatesNode::getTextValue2() {
	return this->textValue2;
}
void QueryEvaluationTreeUpdatesNode::setTextValue2(char * textValue) {
	textValue2 = createString(textValue);
}

char *QueryEvaluationTreeUpdatesNode::getTextValue3() {
	return this->textValue3;
}
void QueryEvaluationTreeUpdatesNode::setTextValue3(char * textValue) {
	textValue3 = createString(textValue);
}

char *QueryEvaluationTreeUpdatesNode::getTextValue4() {
	return this->textValue4;
}
void QueryEvaluationTreeUpdatesNode::setTextValue4(char * textValue) {
	textValue4 = createString(textValue);
}

AttributeInfo QueryEvaluationTreeUpdatesNode::getRepeatedPair(int index) {
	return repeated.at(index);
}
void QueryEvaluationTreeUpdatesNode::setRepeatedPair(int index, AttributeInfo attrInfo) {
	repeated.at(index) = attrInfo;
}
void QueryEvaluationTreeUpdatesNode::addRepeatedPair(AttributeInfo attrInfo) {
	repeated.push_back(attrInfo);
}


vector<AttributeInfo> QueryEvaluationTreeUpdatesNode::getRepeated() {
	return repeated;
}
void QueryEvaluationTreeUpdatesNode::setRepeated(vector<AttributeInfo> repeated) {
	this->repeated = repeated;
}

int QueryEvaluationTreeUpdatesNode::getRepeatedSize() {
	return repeated.size();
}



char *QueryEvaluationTreeUpdatesNode::createString(char *in) {
	char *out;

	if (in == NULL)
		return NULL;
	else {
		out = new char[strlen(in)+1];
		strcpy(out, in);
	}

	return out;
}

void QueryEvaluationTreeUpdatesNode::deleteStructures()
{
	operand->deleteStructures();
}