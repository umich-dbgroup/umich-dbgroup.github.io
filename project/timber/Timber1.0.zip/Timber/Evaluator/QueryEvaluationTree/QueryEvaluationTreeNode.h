/*
COPYRIGHT  � 2000-2004 
THE REGENTS OF THE UNIVERSITY OF MICHIGAN
ALL RIGHTS RESERVED

PERMISSION IS GRANTED TO USE, COPY, CREATE DERIVATIVE WORKS AND REDISTRIBUTE THIS SOFTWARE AND SUCH DERIVATIVE WORKS FOR 
NONCOMMERCIAL EDUCATION AND RESEARCH PURPOSES, SO LONG AS NO FEE IS CHARGED, AND SO LONG AS THE COPYRIGHT NOTICE ABOVE, 
THIS GRANT OF PERMISSION, AND THE DISCLAIMER BELOW APPEAR IN ALL COPIES MADE; AND SO LONG AS THE NAME OF THE UNIVERSITY 
OF MICHIGAN IS NOT USED IN ANY ADVERTISING OR PUBLICITY PERTAINING TO THE USE OR DISTRIBUTION OF THIS SOFTWARE WITHOUT 
SPECIFIC, WRITTEN PRIOR AUTHORIZATION.

THIS SOFTWARE IS PROVIDED AS IS, WITHOUT REPRESENTATION FROM THE UNIVERSITY OF MICHIGAN AS TO ITS FITNESS FOR ANY PURPOSE, 
AND WITHOUT WARRANTY BY THE UNIVERSITY OF MICHIGAN OF ANY KIND, EITHER EXPRESS OR IMPLIED, INCLUDING WITHOUT LIMITATION THE 
IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE. THE REGENTS OF THE UNIVERSITY OF MICHIGAN SHALL 
NOT BE LIABLE FOR ANY DAMAGES, INCLUDING SPECIAL, INDIRECT, INCIDENTAL, OR CONSEQUENTIAL DAMAGES, WITH RESPECT TO ANY CLAIM 
ARISING OUT OF OR IN CONNECTION WITH THE USE OF THE SOFTWARE, EVEN IF IT HAS BEEN OR IS HEREAFTER ADVISED OF THE POSSIBILITY 
OF SUCH DAMAGES.
*/


#ifndef QueryEvaluationTreeNode_H
#define QueryEvaluationTreeNode_H

#include "../Evaluator/Evaluator_definitions.h"




#include <stdio.h>
#include <string>
#define EVALUATION_OP_STRUCTURALJOIN		1
#define EVALUATION_OP_SORT					2
#define EVALUATION_OP_SELECTION				3
#define EVALUATION_OP_PROJECTION			4
#define EVALUATION_OP_INDEX_ACCESS			5
#define EVALUATION_OP_SCAN_ACCESS			6
#define EVALUATION_OP_UD_SELECTION			7
#define EVALUATION_OP_SETOPERATIONS			8
#define EVALUATION_OP_VALUEJOIN				9
#define EVALUATION_OP_UPDATE				10
#define EVALUATION_OP_CONSTRUCT				11
#define EVALUATION_OP_GROUPBY				13
#define EVALUATION_OP_FUNCTION				14
#define EVALUATION_OP_STRUCTURALNONBINJOIN	15
#define EVALUATION_OP_DUPLICATE_ELIMINATOR  16
#define EVALUATION_OP_VALUE_SORT			17
#define EVALUATION_OP_CHILDCHOOSER			18
#define EVALUATION_OP_PARTIALMATCHER		19
#define EVALUATION_OP_PHRASEFINDER			20
#define EVALUATION_OP_SBTERMJOIN			21
#define EVALUATION_OP_NAVIGATIONAL_GET_RELATIVE 22
#define EVALUATION_OP_FILEREADER			23
#define EVALUATION_OP_FILEWRITER			24
#define EVALUATION_OP_PICK					25
#define EVALUATION_OP_MERGETREES			26
#define EVALUATION_OP_DATA_INSTANTIATION	27
#define EVALUATION_OP_DATA_DISCARD			28
#define EVALUATION_OP_SORT_STOP_K			29
#define EVALUATION_OP_UPDATES				30
/*Yunyao - Added 12-15-03 */
#define EVALUATION_OP_MCCAS      			31
#define EVALUATION_OP_UNIV_QUANT			32
#define EVALUATION_OP_ONESIDED_JOIN			33
#define EVALUATION_OP_INDEXHASH_JOIN		34

class QueryEvaluationTreeNode
{
public:
	QueryEvaluationTreeNode(int type);
	virtual ~QueryEvaluationTreeNode();

	int getQueryEvaluationTreeNodeType();
	void setQueryEvaluationTreeNodeType(int type);
	

	void setNodeNumber(int num);
	void setCost(int cost);
	void setAccumulatedCost(int cost);
	void setOrderbyPosition(int pos);

	int getNodeNumber();
	int getCost();
	int getAccumulatedCost();
	int getOrderbyPosition();
	
//	virtual void printQueryEvaluationTreeNode(bool recursive, int depth = 0) {}
//	virtual char* toString() {return "";}
	virtual void deleteStructures() {};


private:
	int queryEvaluationTreeNodeType;

	// the following are  used for query plan generatation
	// the number of node in the subpattern after this join
	int nodeNumber;
	// the offset of the node, which the join result is ordered by, 
	// in the list of node in the result
	int orderbyPosition;
	// the cost of this join itself. (not include the cost of other
	// opertions which is descendant of this node in the query 
	// evaluation tree. 
	int cost;

	// the cost for the sub-evaluationtree, rooted at this noon
	int accumulatedCost;
};



#endif
