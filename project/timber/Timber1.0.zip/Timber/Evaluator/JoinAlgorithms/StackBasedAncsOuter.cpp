/*
COPYRIGHT  � 2000-2004 
THE REGENTS OF THE UNIVERSITY OF MICHIGAN
ALL RIGHTS RESERVED

PERMISSION IS GRANTED TO USE, COPY, CREATE DERIVATIVE WORKS AND REDISTRIBUTE THIS SOFTWARE AND SUCH DERIVATIVE WORKS FOR 
NONCOMMERCIAL EDUCATION AND RESEARCH PURPOSES, SO LONG AS NO FEE IS CHARGED, AND SO LONG AS THE COPYRIGHT NOTICE ABOVE, 
THIS GRANT OF PERMISSION, AND THE DISCLAIMER BELOW APPEAR IN ALL COPIES MADE; AND SO LONG AS THE NAME OF THE UNIVERSITY 
OF MICHIGAN IS NOT USED IN ANY ADVERTISING OR PUBLICITY PERTAINING TO THE USE OR DISTRIBUTION OF THIS SOFTWARE WITHOUT 
SPECIFIC, WRITTEN PRIOR AUTHORIZATION.

THIS SOFTWARE IS PROVIDED AS IS, WITHOUT REPRESENTATION FROM THE UNIVERSITY OF MICHIGAN AS TO ITS FITNESS FOR ANY PURPOSE, 
AND WITHOUT WARRANTY BY THE UNIVERSITY OF MICHIGAN OF ANY KIND, EITHER EXPRESS OR IMPLIED, INCLUDING WITHOUT LIMITATION THE 
IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE. THE REGENTS OF THE UNIVERSITY OF MICHIGAN SHALL 
NOT BE LIABLE FOR ANY DAMAGES, INCLUDING SPECIAL, INDIRECT, INCIDENTAL, OR CONSEQUENTIAL DAMAGES, WITH RESPECT TO ANY CLAIM 
ARISING OUT OF OR IN CONNECTION WITH THE USE OF THE SOFTWARE, EVEN IF IT HAS BEEN OR IS HEREAFTER ADVISED OF THE POSSIBILITY 
OF SUCH DAMAGES.
*/

#include "StackBasedAncsOuter.h"

//-----------------------------------------------------------------------------------
//  This class represents the stack-based join algorithm used in evaluating pattern
//   trees. The result of this join is sorted by ancs.
//----------------------------------------------------------------------------------- 

StackBasedAncsOuter::StackBasedAncsOuter(IteratorClass *ancs,IteratorClass *desc,	int relation, NREType ancsNRE,
				NREType descNRE, NREType leftSiblingNRE, NREType rightSiblingNRE, 
					int expectedDepth, DataMng *dataMng, bool nest, serial_t fileID)
{
	this->ancs = ancs;
	this->desc = desc;
	this->relation = relation;
	this->dataMng = dataMng;
	this->ancsNRE = ancsNRE;
	this->descNRE = descNRE;
	this->leftSiblingNRE = leftSiblingNRE;
	this->rightSiblingNRE = rightSiblingNRE;
	this->volumeID = dataMng->getVolumeID();
	this->expectedDepth = expectedDepth;
	this->nest = nest;
	numWrites = 0;
	firstTimeHere = true;
	readStringSize = 0 ;
	outputtingStackBottomList = false;
	
	ancsStack = new stack<SBJoinAncsStackNode>(expectedDepth);

	readContainer = NULL;
		fileCreated = true;
	this->fileID = fileID;

	continueWithDescList = false;
	continueWithBottom = false;
	fromBuf = false;
	resultBuffer = NULL;

	tmpStr = NULL;
	readString = NULL;

	ancs->next(ancsTuple);
	if (ancsTuple)
	{
		if (ancsTuple->isSimple())
		{
			ancsListNodeSize = sizeof(ListNode);
			ancsNodeType = LIST_NODE;
		}
		else
		{
			ancsListNodeSize = sizeof(ComplexListNode);
			ancsNodeType = LIST_NODE_WITH_DATA;
		}
/*		rc = ss_m::create_file(volumeID, fileID,ss_m::t_regular);
		if (rc) 
		{
			strstream msg;
			msg<<rc<<'\0';
			globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"Evaluator",__FILE__,msg.rdbuf()->str());
			ancsTuple = NULL;
			descTuple = NULL;
			return;				
		}
		//cout<<"create file ID: "<<fileID<<endl;
		fileCreated = true;*/
		int maxIDs = gSettings->getIntegerValue("MAX_ID_PER_FILE_STRUCTURAL_JOINS",10000);
		rc = ss_m::create_id(volumeID,maxIDs,startID);

		if (rc) 
		{
			strstream msg;
			msg<<rc<<'\0';
			globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"Evaluator",__FILE__,msg.rdbuf()->str());
			ancsTuple = NULL;
			descTuple = NULL;			
			return;				
		}	
		numWrites = maxIDs;
		readContainer = new ContainerClass;
	}
	else
	{
		if (globalErrorInfo.doWeHaveAProblem())
		{
			descTuple = NULL;
			return;
		}
		ancsNodeType = LIST_NODE;
	}

	desc->next(descTuple);
	if (descTuple)
	{	
		if (descTuple->isSimple())
		{
			descListNodeSize = sizeof(ListNode);
			descNodeType = LIST_NODE;
		}
		else
		{
			descListNodeSize = sizeof(ComplexListNode);
			descNodeType = LIST_NODE_WITH_DATA;
		}
	}
	else
	{
		if (globalErrorInfo.doWeHaveAProblem())
		{
			ancsTuple = NULL;
			return;
		}
		descNodeType = LIST_NODE;
	}

	
	tmpStr = new char[gSettings->getIntegerValue("CONTAINER_SIZE",CONTAINER_SIZE_DEFAULT)];
	readString = new char[gSettings->getIntegerValue("CONTAINER_SIZE",CONTAINER_SIZE_DEFAULT)];
	
	if (ancsNodeType == LIST_NODE_WITH_DATA || descNodeType == LIST_NODE_WITH_DATA)
		resultBuffer = new WitnessTree(LIST_NODE_WITH_DATA,dataMng);
	else
		resultBuffer = new WitnessTree;
	
}

StackBasedAncsOuter::~StackBasedAncsOuter()
{
	delete ancsStack;

	if (resultBuffer) delete resultBuffer;

	if (tmpStr) delete [] tmpStr;

	if (readString) delete [] readString;

	if (readContainer) delete readContainer;
	
	if (fileCreated)
	{
//		cout<<"destroy file ID: "<<fileID<<endl;
		rc = ss_m::destroy_file(volumeID, fileID, true, numWrites);
		if (rc) 
		{
			strstream msg;
			msg<<rc<<'\0';
			globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"Evaluator",__FILE__,msg.rdbuf()->str());			
		}
	}
	
	delete desc;
	delete ancs;
}

void StackBasedAncsOuter::next(WitnessTree *&node)
{
#ifdef EVAL_TIME_OUT
	clock_t currTime = clock();
	double queryDuration = (double)(currTime - gQueryStartTime) / CLOCKS_PER_SEC;
	if (queryDuration >= gTimeOutAfter)
	{
		globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"Evaluator",__FILE__,"Query Timed Out.");
		node = NULL;
		return;
	}
#endif
	// this block will be entered only if there are lists to be output
	// meaning, we popped the last element in the stack and we want to
	// output its desc list. Since it is a pipeline, we need to have 
	// this block here
	if (outputtingStackBottomList)
	{
		int r = OutputtingLists();
		if (r == SUCCESS)
		{
			node = resultBuffer;
			return;
		}
		else if (r == EV_ERROR)
		{
			node  = NULL;
			return;
		}
	}

	
	// this is the main loop. When we are still having ancs and desc
	while (ancsTuple && descTuple)
	{
		int r = isAncsFirst();
		if (r == FAILURE)
		{
			globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"Evaluator",__FILE__,"Method isAncsFirst returned FAILURE.");
			node = NULL;
			return;
		}
		if (r)
		{// ancs comes first
			int res = HandleAncs();
			if (res == SUCCESS)
			{
				node = resultBuffer;
				return;
			}
			else if (res == EV_ERROR)
			{
				node = NULL;
				return;
			}
			ancs->next(ancsTuple);
		}
		else
		{// desc comes first
			int res = HandleDesc();
			if (res == SUCCESS)
			{
				node = resultBuffer;
				return;
			}
			else if (res == EV_ERROR)
			{
				node = NULL;
				return;
			}
			desc->next(descTuple);
		}
#ifdef EVAL_TIME_OUT
	clock_t currTime = clock();
	double queryDuration = (double)(currTime - gQueryStartTime) / CLOCKS_PER_SEC;
	if (queryDuration >= gTimeOutAfter)
	{
		globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"Evaluator",__FILE__,"Query Timed Out.");
		node = NULL;
		return;
	}
#endif
	}

	// if stack is empty, we are done... because we know that we are out of at
	// least one of the inputs (ancs or desc)... 
	if (ancsStack->IsEmpty())
	{
		if (ancsTuple)
		{
			resultBuffer->initialize();
			if (ancsTuple->isSimple())
				resultBuffer->appendList((ListNode *)ancsTuple->getBuffer(), ancsTuple->length());
			else
				resultBuffer->appendList((ComplexListNode *)ancsTuple->getBuffer(), dataMng,ancsTuple->length());
			ancs->next(ancsTuple);
			node = resultBuffer;
			return;
		}
		node = NULL;
		return;
	}


	// now we need to finish desc
	while (descTuple)
	{
		KeyType descStartKey = getStartKeyOf(descTuple,descNRE,"descendant.");

		if (descStartKey == FAILURE)
		{
			globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"Evaluator",__FILE__,"Unable to get key of descendant.");
			node = NULL;
			return;
		}
		if (HandleDesc() == SUCCESS)
		{
			node = resultBuffer;
			return;
		}
		else
		{
			// if handleDesc returned FAILURE, this might mean that the stack
			// is empty. If it is, we are done
			if (ancsStack->IsEmpty())
			{
				node = NULL;
				return;
			}
			else
				desc->next(descTuple);
		}
	}


	// now we need to finish output what's in the stack 
	// passing -1 pops all the stack
	int r = PopStack(-1);
	if (r == SUCCESS)
	{
		node = resultBuffer;
		return;
	}
	else if (r == EV_ERROR)
	{
		node = NULL;
		return;
	}
	
	if (ancsTuple)
	{
		resultBuffer->initialize();
		if (ancsTuple->isSimple())
			resultBuffer->appendList((ListNode *)ancsTuple->getBuffer(), ancsTuple->length());
		else
			resultBuffer->appendList((ComplexListNode *)ancsTuple->getBuffer(), dataMng,ancsTuple->length());
		ancs->next(ancsTuple);
		node = resultBuffer;
		return;
	}

	node = NULL;
}



int StackBasedAncsOuter::OutputtingLists()
{
	int res;

	if (nest && continueWithBottom)
	{
		res = handleBottom();
		if (res == SUCCESS)
			return SUCCESS;
		else if (res == EV_ERROR)
			return EV_ERROR;
	}

	if (nest && firstTimeHere)
	{
		firstTimeHere = false;
		res = FAILURE;
	}
	else
	{
	// mergeNodes will give us the output tree. it puts stuff in the resultBuffer.
		if (ancsNodeType == LIST_NODE)
			res = MergeNodes(&ancsData,NULL);
		else
			res = MergeNodes(NULL,&ancsDataComplex);
	}
	// res == SUCCESS means that all is fine and we have what we want in resultBuffer.
	if (res == SUCCESS)
		return SUCCESS;
	else
	{
		//we are outputting the lists of the bottom of the stack
		if (GetOneRecord(readContainer,readString, &readStringSize) == SUCCESS)
		{ //we got one string from readContainer successfully, now interpret it and put results in 
			//resultBuffer.
			int r = ProcessOneRecord(readString, readStringSize);
			if (r == SUCCESS)
				return SUCCESS;
			else if (r == EV_ERROR)
				return EV_ERROR;
			else
			{
				if (!(stackElement->EmptyListOfBuffers(stackElement->GetDescList())))
				{
					while (stackElement->GetDescList()->GetNext(readContainer) == SUCCESS)
					{
						if (GetOneRecord(readContainer,readString, &readStringSize) == SUCCESS)
						{
							r = ProcessOneRecord(readString, readStringSize);
							if (r == SUCCESS)
								return SUCCESS;
							else if (r == EV_ERROR)
								return EV_ERROR;
						}
					}
					stackElement->GetDescList()->Initialize();
				}
			}
		}
		else
		{ //readContainer doesn't have anymore strings. get the next container.
			if (!(stackElement->EmptyListOfBuffers(stackElement->GetDescList())))
			{ //we got it.
				while (stackElement->GetDescList()->GetNext(readContainer) == SUCCESS)
				{
					//again, get one string from readContainer and interpret it.
					if (GetOneRecord(readContainer,readString, &readStringSize) == SUCCESS)
					{
						int r = ProcessOneRecord(readString, readStringSize);
						if (r == SUCCESS)
							return SUCCESS;
						else if (r == EV_ERROR)
							return EV_ERROR;
					}
				}
				stackElement->GetDescList()->Initialize();
			}
		}
		if (getNewDesc)
			desc->next(descTuple); 
		
		if (continueWithDescList)
		{
			SBJoinAncsStackNode *popped = ancsStack->Pop();
			int res = StartOutputLists(popped);
			continueWithDescList = false;
			if (res == SUCCESS)
				return SUCCESS;	
			else if (res == EV_ERROR)
				return EV_ERROR;
		}
		getNewDesc = false;
		outputtingStackBottomList = false;
	}
	return FAILURE;
}

KeyType StackBasedAncsOuter::getStartKeyOf(WitnessTree *tree, NREType nre, char *str)
{
	KeyType sk = FAILURE;
	if (tree->moreThanOneMatch(nre))
	{
		char tmp[200];
		strcpy(tmp,"More than one node matched NRE of ");
		strcat(tmp,str);
		globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"Evaluator",__FILE__,tmp);
		return FAILURE;
	}
	if (tree->isSimple())
	{
		ListNode *n = (ListNode *)(tree->findNodeNRE(nre));
		if (!n)
		{
			char tmp[200];
			strcpy(tmp,"No node matched NRE of ");
			strcat(tmp,str);
			globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"Evaluator",__FILE__,tmp);
			return FAILURE;
		}
		sk = n->GetStartPos();
	}
	else
	{
		ComplexListNode *n = (ComplexListNode *)(tree->findNodeNRE(nre));
		if (!n)
		{
			char tmp[200];
			strcpy(tmp,"No node matched NRE of ");
			strcat(tmp,str);
			globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"Evaluator",__FILE__,tmp);
			return FAILURE;
		}
		sk = n->GetStartPos();
	}
	return sk;
}

int StackBasedAncsOuter::isAncsFirst()
{
	KeyType ancsStartKey;
	KeyType descStartKey;

	//get start key of ancestor
	ancsStartKey = getStartKeyOf(ancsTuple,ancsNRE,"ancestor.");

	if (ancsStartKey == FAILURE)
	{
		globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"Evaluator",__FILE__,"Unable to get key of ancestor.");
		return FAILURE;
	}

	//get start key of descendant
	descStartKey = getStartKeyOf(descTuple,descNRE,"descendant.");
	
	if (descStartKey == FAILURE)
	{
		globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"Evaluator",__FILE__,"Unable to get key of descendant.");
		return FAILURE;
	}


	// does the ancs come first?
	return (int)(ancsStartKey < descStartKey);
}





int StackBasedAncsOuter::HandleAncs()
{
	
	KeyType ancsStartKey ;

	if (ancsNodeType == LIST_NODE)
		ancsStartKey = ((ListNode *)(ancsTuple->findNodeNRE(ancsNRE)))->GetStartPos();
	else
		ancsStartKey = ((ComplexListNode *)(ancsTuple->findNodeNRE(ancsNRE)))->GetStartPos();

	// pop stack as needed. if this returns success, it means we popped the bottom 
	// element in the stack and we need to output its list.
	int r = PopStack(ancsStartKey) ;
	if (r == SUCCESS)
		return SUCCESS;
	else if (r == EV_ERROR)
		return EV_ERROR;


	// now, the more complex case... we have lists that are common between nodes 
	// exp. A1B1C1 and A1B2C1 , we need to keep A1 on stack and the rest in buffers
	if (ancsStack->IsEmpty())
	{ // if stack is empty, just push the new ancs and make sure to put additional
		// things in buffer
		if (PushAncs() == FAILURE)
			return EV_ERROR;
		return FAILURE;
	}

	SBJoinAncsStackNode *topOfStack = ancsStack->GetTop();

	// so, we found out that A1 is common between the newcomer and the top of the stack
	// we need to add Bs and Cs to the buffer of the top of the stack
	if (topOfStack->GetActualAncs()->GetStartPos() == ancsStartKey)
	{
		if (AddToTopOfStack() == FAILURE)
			return EV_ERROR;
	}
	else
		if (PushAncs() == FAILURE) return EV_ERROR;

	return FAILURE;
}

int StackBasedAncsOuter::HandleDesc()
{	
	KeyType descStartKey;

	if (descNodeType == LIST_NODE)
		descStartKey = ((ListNode *)(descTuple->findNodeNRE(descNRE)))->GetStartPos();
	else
		descStartKey = ((ComplexListNode *)(descTuple->findNodeNRE(descNRE)))->GetStartPos();

	// pop stack as needed. if this returns success, it means we popped the bottom 
	// element in the stack and we need to output its list.
	int r = PopStack(descStartKey) ;
	if (r == SUCCESS)
		return SUCCESS;
	else if (r == EV_ERROR)
		return EV_ERROR;


	// if stack is empty, no need to output anything
	if (ancsStack->IsEmpty())
		return FAILURE; 

	// if the relationship is parent-child, we need to worry about the top of the stack only
	if (relation == PARENT_CHILD) 
		return JoinWithTopOnly();
	else
		return JoinWithAllStack();
}


int StackBasedAncsOuter::PushAncs()
{
	if (ancsNodeType == LIST_NODE)
		ancsStack->Push((ListNode *)(ancsTuple->findNodeNRE(ancsNRE)));
	else
		ancsStack->Push((ComplexListNode *)(ancsTuple->findNodeNRE(ancsNRE)));
	
	ancsStack->GetTop()->SetListsVolumeAndFileIDs(volumeID,fileID);
	
	if (writeAncsTreeToBuffer(ancsStack->GetTop()->GetBuffer(),ancsTuple) == FAILURE)
	{
		strstream msg;
		int maxSz = 0;
		while (ancsTuple)
		{
			int currSz = calculateSizeOfAncsTree(ancsTuple);
			if (currSz > maxSz)
				maxSz = currSz;
			ancs->next(ancsTuple);
		}
		maxSz++;
		msg<<"A container cannot accomodate 1 witness tree... increase CONTAINER_SIZE parameter in settings file "<<
			"to at least "<<maxSz<<"..."<<'\0';
		globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"Evaluator",__FILE__,msg.rdbuf()->str());
		return FAILURE; 
	}
	return SUCCESS;
}


int StackBasedAncsOuter::AddToTopOfStack()
{
	SBJoinAncsStackNode *topOfStack = ancsStack->GetTop();

	// if the buffer has not enough space to carry more data, write it to shore
	if (!(topOfStack->EnoughSpace(topOfStack->GetBuffer(),this->calculateSizeOfAncsTree(ancsTuple))))    
			// in buffer
		if (WriteBufferToItsList(topOfStack->GetBuffer(),topOfStack->GetListOfBuffers()) == FAILURE)
			return FAILURE;

	if (writeAncsTreeToBuffer(topOfStack->GetBuffer(),ancsTuple) == FAILURE)
	{
		strstream msg;
		int maxSz = 0;
		while (ancsTuple)
		{
			int currSz = calculateSizeOfAncsTree(ancsTuple);
			if (currSz > maxSz)
				maxSz = currSz;
			ancs->next(ancsTuple);
		}
		maxSz++;
		msg<<"A container cannot accomodate 1 witness tree... increase CONTAINER_SIZE parameter in settings file "<<
			"to at least "<<maxSz<<"..."<<'\0';
		globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"Evaluator",__FILE__,msg.rdbuf()->str());
		return FAILURE; 
	}
	return SUCCESS;
}

int StackBasedAncsOuter::JoinWithAllStack()
{
	int res;

	// we join with all stack elements starting from top 
	// and finishing with bottom because we output it directly
	for (int i=ancsStack->Size()-1; i>0; i--)
		if (JoinWithStackElement(i) == FAILURE)
			return EV_ERROR;

	
	if (nest)
	{
		if (JoinWithStackElement(0) == FAILURE)
			return EV_ERROR;
		return FAILURE;
	}
	else
	{
		ancsStack->GetBottom()->setBeenJoined(true);
		if (OutputStackElement(0) == EV_ERROR)
			return EV_ERROR;
		
		if (writeDescTreeToBuffer(&selfCurrentOutput,descTuple) == FAILURE)
		{
			strstream msg;
			int maxSz = 0;
			while (descTuple)
			{
				int currSz = calculateSizeOfDescTree(descTuple);
				if (currSz > maxSz)
					maxSz = currSz;
				desc->next(descTuple);
			}
			maxSz++;
			msg<<"A container cannot accomodate 1 witness tree... increase CONTAINER_SIZE parameter in settings file "<<
				"to at least "<<maxSz<<"..."<<'\0';
			globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"Evaluator",__FILE__,msg.rdbuf()->str());
			return EV_ERROR; 
		}
		selfListExists = false;
		//merge nodes just sets the resultBuffer to output
		if (ancsNodeType == LIST_NODE)
			res = MergeNodes(&ancsData, NULL);
		else
			res = MergeNodes(NULL, &ancsDataComplex);
		return res;
	}
}

int StackBasedAncsOuter::OutputStackElement(int index)
{
	//here we are outputting stack element with index index
	if (index >= ancsStack->Size())
		return FAILURE;

	
	stackElement = ancsStack->GetByIndex(index);
	

	if (this->ancsNodeType == LIST_NODE)
		this->ancsData = *(stackElement->GetActualAncs());
	else
		this->ancsDataComplex = *(stackElement->GetActualAncsComplex());

	//initializing output buffers
	resultBuffer->initialize();
	bufferListOutput.Initialize();
	bufferCurrentOutput.Initialize();
	selfListOutput.Initialize();
	selfCurrentOutput.Initialize();
	selfListExists = false;

	//if we have a list with the ancs
	if (stackElement->BufferExistsAndNotEmpty(stackElement->GetBuffer()))
	{
		outputtingStackBottomList = true;
		getNewDesc = stackElement->hasBeenJoined()? true : false;
	}
	else
		outputtingStackBottomList = false;

	stackElement->setBeenJoined(true);
	if (stackElement->EmptyListOfBuffers(stackElement->GetListOfBuffers()))
	{ //if we don't have a list associated with this stack element, then just use the buffer
		bufferListExists = false;
		bufferCurrentOutput.CopyContainer(stackElement->GetBuffer());
	}
	else
	{
		//if we do have a list, then use the lists and read the first container into the buffer
		outputtingStackBottomList = true;
		getNewDesc = stackElement->hasBeenJoined()? true : false;
		bufferListExists = true;
		
		if (stackElement->BufferExistsAndNotEmpty(stackElement->GetBuffer()))
		{
			if (WriteBufferToItsList(stackElement->GetBuffer(),stackElement->GetListOfBuffers()) == FAILURE)
				return EV_ERROR;
		}
		bufferListOutput.SetHead(stackElement->GetListOfBuffers()->GetHead());
		bufferListOutput.SetTail(stackElement->GetListOfBuffers()->GetTail());
		bufferListOutput.SetVolumeID(volumeID);
		bufferListOutput.SetFileID(fileID);
		bufferListOutput.StartScan();
		bufferListOutput.GetNext(&bufferCurrentOutput);
	}
	//at this point, we have buffer list  bufferListOutput if we don't have a buffer list, then the buffer
	// itself is in bufferCurrentOutput
	return SUCCESS;
}


int StackBasedAncsOuter::JoinWithStackElement(int index)
{ 
	// join descTuple with stack element with index index.
	SBJoinAncsStackNode *stackElem = ancsStack->GetByIndex(index);

	stackElem->setBeenJoined(true);

	// if we are keeping both, then we should add descTuple to the selfBuffer of the stack element
	if (!(stackElem->GetSelfBuffer()->EnoughSpace(this->calculateSizeOfDescTree(descTuple))))
				//this means not enough space in selfBuffer
		if (WriteBufferToItsList(stackElem->GetSelfBuffer(),stackElem->GetSelfList()) == FAILURE)
			return FAILURE;

	if (this->writeDescTreeToBuffer(stackElem->GetSelfBuffer(),descTuple) == FAILURE)
	{
		strstream msg;
		int maxSz = 0;
		while (descTuple)
		{
			int currSz = calculateSizeOfDescTree(descTuple);
			if (currSz > maxSz)
				maxSz = currSz;
			desc->next(descTuple);
		}
		maxSz++;
		msg<<"A container cannot accomodate 1 witness tree... increase CONTAINER_SIZE parameter in settings file "<<
			"to at least "<<maxSz<<"..."<<'\0';
		globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"Evaluator",__FILE__,msg.rdbuf()->str());
		return FAILURE; 
	}
	return SUCCESS;
}

int StackBasedAncsOuter::JoinWithTopOnly()
{
	//checking to make sure that the top of stack and descTuple are one level apart
	if (ancsStack->GetTop()->GetActualAncs()->GetLevel() == 
		                  ((ListNode *)(descTuple->findNodeNRE(descNRE)))->GetLevel()-1)
	{
		if (nest)
		{
			if (JoinWithStackElement(ancsStack->Size() - 1) == FAILURE)
				return EV_ERROR;
			return FAILURE;
		}
		else
		{
			if (ancsStack->GetTop() == ancsStack->GetBottom())
			{ //in case the stack has only one element, then we output immediatly
				ancsStack->GetTop()->setBeenJoined(true);
				int r = OutputStackElement(0);
				if (r == FAILURE)
					return FAILURE;
				else if (r == EV_ERROR)
					return EV_ERROR;

				// if we are keeping both, then we add descTuple to selfCurrentOutput because in MergeNodes, it 
				// is expected that output is in selfCurrentOutput
				
				if (this->writeDescTreeToBuffer(&selfCurrentOutput,descTuple) == FAILURE)
				{
					strstream msg;
					int maxSz = 0;
					while (descTuple)
					{
						int currSz = calculateSizeOfDescTree(descTuple);
						if (currSz > maxSz)
							maxSz = currSz;
						desc->next(descTuple);
					}
					maxSz++;
					msg<<"A container cannot accomodate 1 witness tree... increase CONTAINER_SIZE parameter in settings file "<<
						"to at least "<<maxSz<<"..."<<'\0';
					globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"Evaluator",__FILE__,msg.rdbuf()->str());
					return EV_ERROR; 
				}

				int res;
				if (ancsNodeType == LIST_NODE)
					res = MergeNodes(&ancsData, NULL);
				else
					res = MergeNodes(NULL, &ancsDataComplex);
				if (!(stackElement->BufferExistsAndNotEmpty(stackElement->GetBuffer())) && res != FAILURE && !bufferListExists)
					desc->next(descTuple);
				return res;
			}
			else
				if (JoinWithStackElement(ancsStack->Size() - 1) == FAILURE)
					return EV_ERROR;
		}
	}
	else
		return FAILURE;
	return FAILURE;
}

int StackBasedAncsOuter::MergeNodes(ListNode *ancsData, ComplexListNode *ancsDataComplex)
{	
	//in this method, we actually write ancs-desc and other stuff to resultBuffer
	// at this point, the ancs is in ancsData or ancsDataComplex. ancsLists are in
	// bufferCurrentOutput/bufferListOutput. desc info are in selfCurrentOutput/selfListOutput.
	bool readyToOutput = false;
	double aScore,dScore;
	aScore = dScore = -1;
	while (!readyToOutput)
	{
		readyToOutput = true;
		resultBuffer->initialize();
	
		// from bufferCurrentOutput we get the ancsList
	
		if (bufferCurrentOutput.reachedEndOfContainer())
		{ //if we read the buffer already, we get next from list if it exists
			if (bufferListExists)
			{
				if (bufferListOutput.GetNext(&bufferCurrentOutput) == FAILURE)
				{
					//if we reached the end of the list and nest == true, we are done
					if (nest)
						return FAILURE;
					// if we reached the end of the list, we need to get the next desc from self list/buffer
					if (!(selfCurrentOutput.IsEmpty()))
					{
						//advancing to the next desc
						selfCurrentOutput.advanceScanCursor();
						if (selfCurrentOutput.reachedEndOfContainer())
						{
							if (selfListExists)
							{
								if (selfListOutput.GetNext(&selfCurrentOutput) == FAILURE)
									return FAILURE;
							}
							else
								return FAILURE;
						}
						//then we restart the buffer list traversal
						bufferListOutput.StartScan();
						bufferListOutput.GetNext(&bufferCurrentOutput);
					}
					else
						return FAILURE;
				}
			}
			else
			{
				if (nest)
					return FAILURE;
				if (!(selfCurrentOutput.IsEmpty()))
				{
					//advancing to the next desc
					selfCurrentOutput.advanceScanCursor();
					if (selfCurrentOutput.reachedEndOfContainer())
					{
						if (selfListExists)
						{
							if (selfListOutput.GetNext(&selfCurrentOutput) == FAILURE)
								return FAILURE;
						}
						else
							return FAILURE;
					}

					bufferCurrentOutput.SetScanCursor(0);
				}
				else
					return FAILURE;
			}
		}
	
		aScore = readAncsIntoResult(&bufferCurrentOutput,ancsData,ancsDataComplex);
		
		// adding desc and co.
		if (!(selfCurrentOutput.IsEmpty()))
		{
			if (nest)
			{
				int res = FAILURE;
				bool cont = true;
				while (cont)
				{
					if (selfCurrentOutput.reachedEndOfContainer())
					{
						if (selfListExists)
						{
							if (selfListOutput.GetNext(&selfCurrentOutput) == FAILURE)
							{
								selfListOutput.StartScan();
								selfListOutput.GetNext(&selfCurrentOutput);
								return res;
							}
						}
						else
						{
							selfCurrentOutput.SetScanCursor(0);
							return res;
						}
					}

					dScore = readDescIntoResult(&selfCurrentOutput);
					res = SUCCESS;
					//selfCurrentOutput.decrementScanCursor();
				}
			}
			else
			{
				if (selfCurrentOutput.reachedEndOfContainer())
				{
					if (selfListExists)
					{
						if (selfListOutput.GetNext(&selfCurrentOutput) == FAILURE)
							return FAILURE;
					}
					else
						return FAILURE;
				}

				dScore = readDescIntoResult(&selfCurrentOutput);

				selfCurrentOutput.decrementScanCursor();

				if (leftSiblingNRE != NULL_NRE)
				{
					KeyType leftSibEK;
					if (resultBuffer->moreThanOneMatch(leftSiblingNRE))
					{
						globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"Evaluator",__FILE__,"More than one node matched NRE of left sibling.");
						return EV_ERROR;
					}
					if (resultBuffer->isSimple())
					{
						if (((ListNode *)resultBuffer->findNodeNRE(leftSiblingNRE)))
							leftSibEK = ((ListNode *)resultBuffer->findNodeNRE(leftSiblingNRE))->GetEndPos();
						else
						{
							globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"Evaluator",__FILE__,"No node matched NRE of left sibling.");
							return EV_ERROR;
						}
					}
					else
					{
						if (((ComplexListNode *)resultBuffer->findNodeNRE(leftSiblingNRE)))
							leftSibEK = ((ComplexListNode *)resultBuffer->findNodeNRE(leftSiblingNRE))->GetEndPos();
						else
						{
							globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"Evaluator",__FILE__,"No node matched NRE of left sibling.");
							return EV_ERROR;
						}
					}
					KeyType sk = resultBuffer->isSimple()? 
						((ListNode *)resultBuffer->findNodeNRE(descNRE))->GetStartPos():
					((ComplexListNode *)resultBuffer->findNodeNRE(descNRE))->GetStartPos();
					if (leftSibEK > sk)
					{
						readyToOutput = false;
						continue;
					}
				}

				if (rightSiblingNRE != NULL_NRE)
				{
					KeyType rightSibSK;
					if (resultBuffer->moreThanOneMatch(rightSiblingNRE))
					{
						globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"Evaluator",__FILE__,"More than one node matched NRE of right sibling.");
						return EV_ERROR;
					}
					if (resultBuffer->isSimple())
					{
						if (((ListNode *)resultBuffer->findNodeNRE(rightSiblingNRE)))
							rightSibSK = ((ListNode *)resultBuffer->findNodeNRE(rightSiblingNRE))->GetEndPos();
						else
						{
							globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"Evaluator",__FILE__,"No node matched NRE of right sibling.");
							return EV_ERROR;
						}
					}
					else
					{
						if (((ComplexListNode *)resultBuffer->findNodeNRE(rightSiblingNRE)))
							rightSibSK = ((ComplexListNode *)resultBuffer->findNodeNRE(rightSiblingNRE))->GetEndPos();
						else
						{
							globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"Evaluator",__FILE__,"No node matched NRE of right sibling.");
							return EV_ERROR;
						}
					}
					KeyType ek = resultBuffer->isSimple()? 
						((ListNode *)resultBuffer->findNodeNRE(descNRE))->GetEndPos():
					((ComplexListNode *)resultBuffer->findNodeNRE(descNRE))->GetEndPos();
					if (rightSibSK < ek)
					{
						readyToOutput = false;
						continue;
					}
				}
			}
		}
	}
	resultBuffer->setScore(this->resScore(aScore,dScore));
	return SUCCESS;
}

int StackBasedAncsOuter::PopStack(KeyType startPosition)
{
	if (ancsStack->IsEmpty())
		return FAILURE;

	if (startPosition == -1)  // this means POP all
		startPosition = DBL_MAX;

	while (startPosition > ancsStack->GetTop()->GetActualAncs()->GetEndPos())
	{// pop top element in the stack
		if (ancsStack->Size() == 1)
		{
			//before that, call outputStackElement until done then start outputlists
			if (!(ancsStack->GetBottom()->hasBeenJoined()))
			{
				continueWithDescList = true;
				if (OutputStackElement(0) == EV_ERROR)
					return EV_ERROR;
				selfListExists = false;
				//merge nodes just sets the resultBuffer to output
				int res;
				if (ancsNodeType == LIST_NODE)
					res = MergeNodes(&ancsData, NULL);
				else
					res = MergeNodes(NULL, &ancsDataComplex);
				if (res == SUCCESS)
					return res;
			}
			SBJoinAncsStackNode *popped = ancsStack->Pop();
			return StartOutputLists(popped);
		}
		SBJoinAncsStackNode *popped = ancsStack->Pop();
		// otherwise, we cpoy lists of the popped element to the top of the stack
		if (CopyLists(popped,ancsStack->GetTop()) == FAILURE)
			return EV_ERROR;
	}
	return FAILURE;
}

int StackBasedAncsOuter::StartOutputLists(SBJoinAncsStackNode *node1)
{
	outputtingStackBottomList = true;
	getNewDesc = false;
	firstTimeHere = false;
	if (this->ancsNodeType == LIST_NODE)
		this->ancsData = *(node1->GetActualAncs());
	else
		this->ancsDataComplex = *(node1->GetActualAncsComplex());
	// node1 is always the deepest element in the stack and doesn't have self list unless nest == true
	//but it might have a desc list
	if (!nest || (nest && node1->hasBeenJoined() && !(node1->BufferExistsAndNotEmpty(node1->GetSelfBuffer()))))
			//no nodes joined with bottom of stack--> output desc list))
	{
		if (!(node1->EmptyListOfBuffers(node1->GetDescList())))
		{// if it does, we need to read records from the desc list and interpret them
			if (node1->BufferExistsAndNotEmpty(node1->GetDescBuffer()))
				if (WriteBufferToItsList(node1->GetDescBuffer(),node1->GetDescList()) == FAILURE)
					return EV_ERROR;
			node1->GetDescList()->StartScan();
			while (node1->GetDescList()->GetNext(readContainer) == SUCCESS)
			{
				if (GetOneRecord(readContainer,readString, &readStringSize) == SUCCESS)
					return ProcessOneRecord(readString, readStringSize);
			}
			node1->GetDescList()->Initialize();
			outputtingStackBottomList = false;
			return FAILURE;
		}
		else
		{// if we don't have a list, then just use the descBuffer
			if (!(node1->BufferExistsAndNotEmpty(node1->GetDescBuffer())))
			{
				outputtingStackBottomList = false;
				return FAILURE;
			}
			else
				readContainer->CopyContainer(node1->GetDescBuffer());
			if (GetOneRecord(readContainer,readString, &readStringSize) == SUCCESS)
				return ProcessOneRecord(readString, readStringSize);
		}
	}
	else
		//if nest == true, we need to output the bottom of the stack self list
	{
		double aScore = -1, dScore = -1;
		bool goToDescList;
		resultBuffer->initialize();
		if (!node1->EmptyListOfBuffers(node1->GetListOfBuffers()))
		{
			node1->GetListOfBuffers()->StartScan();
			node1->GetListOfBuffers()->GetNext(&bufferCurrentOutput);
			if (ancsNodeType == LIST_NODE)
				aScore = readAncsIntoResult(&bufferCurrentOutput,node1->GetActualAncs(),NULL);
			else
				aScore = readAncsIntoResult(&bufferCurrentOutput,NULL,node1->GetActualAncsComplex());
			goToDescList = false;
		}
		else 
		{
			bufferCurrentOutput.CopyContainer(node1->GetBuffer());

			if (ancsNodeType == LIST_NODE)
				aScore = readAncsIntoResult(&bufferCurrentOutput,node1->GetActualAncs(),NULL);
			else
				aScore = readAncsIntoResult(&bufferCurrentOutput,NULL,node1->GetActualAncsComplex());

			if (bufferCurrentOutput.reachedEndOfContainer())
				goToDescList = true;
			else
				goToDescList = false;
		}
		
	
		//here we are sure that bottom of stack has stuff joined with it
		if (!(node1->EmptyListOfBuffers(node1->GetSelfList())))
		{// if it does have a list, we need to read records from the self list
			node1->GetSelfList()->StartScan();
			dScore = 0;
			while (node1->GetSelfList()->GetNext(readContainer) == SUCCESS)
				dScore += writeContainerToResult(readContainer);
		}
	
		if (node1->BufferExistsAndNotEmpty(node1->GetSelfBuffer()))
		{
			if (dScore == -1) dScore = 0;
			dScore += writeContainerToResult(node1->GetSelfBuffer());
		}
		stackElement = node1;
		firstTimeHere = true;
		resultBuffer->setScore(resScore(aScore,dScore));
		if (goToDescList)
		{
			continueWithBottom = false;
			if (!node1->EmptyListOfBuffers(node1->GetDescList()))
			{
				if (node1->BufferExistsAndNotEmpty(node1->GetDescBuffer()))
					if (WriteBufferToItsList(node1->GetDescBuffer(),node1->GetDescList()) == FAILURE)
						return EV_ERROR;
				node1->GetDescList()->StartScan();
				node1->GetDescList()->GetNext(readContainer);
			}
			else if (node1->BufferExistsAndNotEmpty(node1->GetDescBuffer()))
				readContainer->CopyContainer(node1->GetDescBuffer());
		}
		else
			continueWithBottom = true;
		return SUCCESS;
	}
	return FAILURE;
}

int StackBasedAncsOuter::GetOneRecord(ContainerClass *cont, char *str, int *strSize)
{
	// getting size of record
	strSize = strSize;
	if (cont->GetNext(sizeof(int),(char *) strSize) == FAILURE)
		return FAILURE;

	// getting record itself
	if (cont->GetNext(*strSize,str) == FAILURE)
		return FAILURE;
	return SUCCESS;
}

int StackBasedAncsOuter::ProcessOneRecord(char *str, int strSize)
{
	strSize = strSize;
	ListNode ancsData;
	ComplexListNode ancsDataComplex;
	int strScanner = 0;

	if (GetActualAncs(str,strSize,&strScanner,&ancsData,&ancsDataComplex) == FAILURE)
	{ // we found a desc list head and tail
		ContainerClass tmpCont;
		ShoreList tmpList;
		//get the list's info
		GetList(str,strSize,&strScanner,&tmpList);	
		
		int start = readContainer->GetScanCursor();
		int sizeCopied = readContainer->GetAddCursor() - start;
		if(stackElement->EmptyListOfBuffers(stackElement->GetDescList()))
		{
			stackElement->GetDescList()->SetVolumeID(volumeID);
			stackElement->GetDescList()->SetFileID(fileID);
			if (stackElement->GetDescList()->copyList(&tmpList,startID) == FAILURE)
				return EV_ERROR;

			if (startID.increment(1) == true)
				//overflow of shore logical ids
			{
				globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"Evaluator",__FILE__,"Shore Logical ID overflow.");
				return EV_ERROR;
			}
			if (sizeCopied != 0)
			{
				readContainer->GetData(start,sizeCopied,tmpStr);
				tmpCont.AddData(tmpStr,sizeCopied);
				if (stackElement->GetDescList()->AddToList(&tmpCont,startID) == FAILURE)
					return EV_ERROR;
				if (startID.increment(1) == true)
					//overflow of shore logical ids
				{
					globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"Evaluator",__FILE__,"Shore Logical ID overflow.");
					return EV_ERROR;
				}
			}
		}
		else
		{
			if (sizeCopied == 0)
			{
				if (stackElement->GetDescList()->simplePrependToList(&tmpList,startID) == FAILURE)
					return EV_ERROR;
			}
			else
			{
				readContainer->GetData(start,sizeCopied,tmpStr);
				tmpCont.AddData(tmpStr,sizeCopied);
				if (stackElement->GetDescList()->complexPrependToList(&tmpList,
					&tmpCont,startID) == FAILURE)
					return EV_ERROR;
			}
			if (startID.increment(1) == true)
				//overflow of shore logical ids
			{
				globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"Evaluator",__FILE__,"Shore Logical ID overflow.");
				return EV_ERROR;
			}
		}
	//now, we have a ready list, scan it
		stackElement->GetDescList()->StartScan();
		while (stackElement->GetDescList()->GetNext(readContainer) == SUCCESS)	
		{
			//the recursiveness here might be a problem
			if (GetOneRecord(readContainer,readString, &readStringSize) == SUCCESS)
				return ProcessOneRecord(readString, readStringSize);
		}		
	}
	//  when we reach this point, we do have an ancestor. we need to check for buffer list and self list
	if (DoWeHaveAList(str, strSize, &strScanner))
	{   // initializing the buffer list
		bufferListExists = true;
		GetList(str,strSize,&strScanner,&bufferListOutput);	
	
		bufferListOutput.SetVolumeID(volumeID);
		bufferListOutput.SetFileID(fileID);
		bufferListOutput.StartScan();
		bufferListOutput.GetNext(&bufferCurrentOutput);
	}
	else
	{
		bufferListExists = false;
		GetBuffer(str, strSize, &strScanner, &bufferCurrentOutput);
	}

	if (DoWeHaveAList(str, strSize, &strScanner))
	{// initializing the self list
		selfListExists = true;
		GetList(str, strSize, &strScanner, &selfListOutput);	
		selfListOutput.SetVolumeID(volumeID);
		selfListOutput.SetFileID(fileID);
		selfListOutput.StartScan();
		selfListOutput.GetNext(&selfCurrentOutput);
	}
	else
	{
		selfListExists = false;
		GetBuffer(str, strSize, &strScanner, &selfCurrentOutput);
	}

	if (this->ancsNodeType == LIST_NODE)
	{
		this->ancsData = ancsData;
		return MergeNodes(&this->ancsData,NULL);
	}
	else
	{
		this->ancsDataComplex = ancsDataComplex;
		return MergeNodes(NULL,&this->ancsDataComplex);
	}
	
}

int StackBasedAncsOuter::GetActualAncs(char *str, int strSize, int *strScanner, 
								  ListNode *ancsData, ComplexListNode *ancsDataComplex)
{// here, we get the data of the ancs from the str.
	if (ancsNodeType == LIST_NODE)
	{
		if (strSize - *strScanner < sizeof(*ancsData))
			return FAILURE;

		memcpy(ancsData,str + *strScanner, sizeof(*ancsData));
		*strScanner += sizeof(*ancsData);
		return SUCCESS;
	}
	else
	{
		if (strSize - *strScanner < sizeof(*ancsDataComplex))
			return FAILURE;

		memcpy(ancsDataComplex,str + *strScanner, sizeof(*ancsDataComplex));
		*strScanner += sizeof(*ancsDataComplex);
		return SUCCESS;
	}
}

bool StackBasedAncsOuter::DoWeHaveAList(char *str, int strSize, int *strScanner)
{
	strSize = strSize;
	int subRecSize;
	memcpy(&subRecSize,str+(*strScanner),sizeof(int));
	if (subRecSize == 2*sizeof(serial_t))  
	{	// this means we have a list
		*strScanner += sizeof(int);
		return true;
	}
	else
		return false;

}

void StackBasedAncsOuter::GetList(char *str, int strSize, int *strScanner, ShoreList *target)
{ //if we have a list, it is read from str and written to target
	target->Initialize();
	strSize = strSize;
	serial_t listRid;
	memcpy(&listRid, str+(*strScanner), sizeof(serial_t));
	target->SetHead(listRid);
	*strScanner += sizeof(serial_t);

	memcpy(&listRid, str+(*strScanner), sizeof(serial_t));
	target->SetTail(listRid);
	*strScanner += sizeof(serial_t);

	// at least one
	target->setSize(1);
}

void StackBasedAncsOuter::GetBuffer(char *str, int strSize, int *strScanner, ContainerClass *target)
{
	//if we have a buffer written, then we need to read it from str into target container
	target->Initialize();
	strSize = strSize;
	int bufferSize;
	memcpy(&bufferSize,str+(*strScanner),sizeof(int));
	*strScanner += sizeof(int);
	
	if (bufferSize == -1)
		return;

	target->AddData(str+(*strScanner),bufferSize);
	*strScanner += bufferSize;
}
	
int StackBasedAncsOuter::CopyLists(SBJoinAncsStackNode *source, SBJoinAncsStackNode *target)
{
	int recSize;

//	if ( source->BufferExistsAndNotEmpty(source->GetSelfBuffer())
//		  || !(source->EmptyListOfBuffers(source->GetSelfList())))
//	{

	recSize = CalculateRecordSize(source);

	if (!(target->EnoughSpace(target->GetDescBuffer(),recSize + sizeof(int))))
		if (WriteBufferToItsList(target->GetDescBuffer(),target->GetDescList()) == FAILURE)
			return FAILURE;

	// writing total size of record
	target->AddToBuffer(target->GetDescBuffer(),(char *)&recSize,sizeof(int));
	// writing the ancs itself
	if (ancsNodeType == LIST_NODE)
		target->AddToBuffer(target->GetDescBuffer(),(char *)source->GetActualAncs(),
		sizeof(*(source->GetActualAncs())));
	else
		target->AddToBuffer(target->GetDescBuffer(),(char *)source->GetActualAncsComplex(),
		sizeof(*(source->GetActualAncsComplex())));

	//writing size of buffer 
	recSize = CalculateSubRecordSize(source->GetBuffer(),source->GetListOfBuffers());
	target->AddToBuffer(target->GetDescBuffer(),(char *)&recSize,sizeof(int));


	if (WriteBufferOrListRid(source->GetBuffer(),source->GetListOfBuffers(),
		target->GetDescBuffer(),target->GetDescList()) == FAILURE)
		return FAILURE;

	//writing size of self 
	recSize = CalculateSubRecordSize(source->GetSelfBuffer(),source->GetSelfList());
	if (recSize == 0)
		recSize = -1;
	target->AddToBuffer(target->GetDescBuffer(),(char *)&recSize,sizeof(int));
	// writing self buffer
	if (WriteBufferOrListRid(source->GetSelfBuffer(),source->GetSelfList(),
		target->GetDescBuffer(),target->GetDescList()) == FAILURE)
		return FAILURE;
	//	}
	recSize = CalculateSubRecordSize(source->GetDescBuffer(),source->GetDescList());
	if (recSize != 0)
	{
		// we are writing a list head and tail
		if (recSize == sizeof(serial_t) + sizeof(serial_t))
		{
			if (!(target->EnoughSpace(target->GetDescBuffer(),recSize + sizeof(int))))
				if (WriteBufferToItsList(target->GetDescBuffer(),target->GetDescList()) == FAILURE)
					return FAILURE;

			target->AddToBuffer(target->GetDescBuffer(),(char *)&recSize,sizeof(int));
		}
		else
		{
			if (!(target->EnoughSpace(target->GetDescBuffer(),recSize)))
				if (WriteBufferToItsList(target->GetDescBuffer(),target->GetDescList()) == FAILURE)
					return FAILURE;

		}

		if (WriteBufferOrListRid(source->GetDescBuffer(),source->GetDescList(),
								target->GetDescBuffer(),target->GetDescList()) == FAILURE)
								return FAILURE;
	}
	return SUCCESS;
}

int StackBasedAncsOuter::CalculateRecordSize(SBJoinAncsStackNode *node1)
{
	int recSize = 0;

	if (ancsNodeType == LIST_NODE)
		recSize += sizeof(*(node1->GetActualAncs())) ; 
	else
		recSize += sizeof(*(node1->GetActualAncsComplex())) ; 

//	int oldRecSize = recSize;
	recSize += CalculateSubRecordSize(node1->GetBuffer(), node1->GetListOfBuffers());
//	if (oldRecSize == recSize)
//		recSize += sizeof(double);
	recSize += sizeof(int);   // the size itself
	recSize += CalculateSubRecordSize(node1->GetSelfBuffer(), node1->GetSelfList());
	recSize += sizeof(int);   // the size itself
	return recSize; 
}

int StackBasedAncsOuter::CalculateSubRecordSize(ContainerClass *cont, ShoreList *list)
{
	int recSize = 0;

	if (list->IsEmpty())
		recSize += (cont->GetAddCursor());
	else
		recSize += (2*sizeof(serial_t));

	return recSize;
}

int StackBasedAncsOuter::WriteBufferOrListRid(ContainerClass *cont1, ShoreList *list1, 
										  ContainerClass *cont2, ShoreList *list2)
{
	if (!(list1->IsEmpty()))
	{
		if (WriteListRidToBuffer(cont1,list1,cont2) == FAILURE)
			return FAILURE;
	}
	else
		WriteContainerToBuffer(cont1,cont2,list2);
	return SUCCESS;
}


int StackBasedAncsOuter::WriteListRidToBuffer(ContainerClass *cont1, ShoreList *list,
											  ContainerClass *cont2)
{
	if (WriteBufferToItsList(cont1,list) == FAILURE)
		return FAILURE;

	serial_t h = list->GetHead();
	serial_t t = list->GetTail();
	SBJoinAncsStackNode::AddToBuffer(cont2,(char *) (&(h)),sizeof(list->GetHead()));
	SBJoinAncsStackNode::AddToBuffer(cont2,(char *) (&(t)),sizeof(list->GetTail()));
	return SUCCESS;
}

void StackBasedAncsOuter::WriteContainerToBuffer(ContainerClass *cont1,
											  ContainerClass *cont2,ShoreList *list)
{
	if (cont1->IsEmpty())
		return;

	list = list;
	int length = cont1->GetAddCursor();
	cont1->GetData(0,length,tmpStr);
	SBJoinAncsStackNode::AddToBuffer(cont2,tmpStr,length);
}

int StackBasedAncsOuter::WriteBufferToItsList(ContainerClass *cont, ShoreList *list)
{
	if (cont->IsEmpty())
		return SUCCESS;

	if (list->IsEmpty())
	{
		serial_t currRecID = startID;
		if (startID.increment(1) == true)
			//overflow of shore logical ids
		{
			globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"Evaluator",__FILE__,"Shore Logical ID overflow.");
			return FAILURE;
		}
		if (SBJoinAncsStackNode::WriteBufferToList(cont,list,fileID,volumeID,currRecID,startID) == FAILURE)
			return FAILURE;
		if (startID.increment(1) == true)
			//overflow of shore logical ids
		{
			globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"Evaluator",__FILE__,"Shore Logical ID overflow.");
			return FAILURE;
		}	
	}
	else
	{
		if (SBJoinAncsStackNode::WriteBufferToList(cont,list,startID) == FAILURE)
			return FAILURE;
		if (startID.increment(1) == true)
			//overflow of shore logical ids
		{
			globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"Evaluator",__FILE__,"Shore Logical ID overflow.");
			return FAILURE;
		}
	}
	cont->Initialize();
	return SUCCESS;
}

double StackBasedAncsOuter::resScore(double ancsScore, double descScore)
{
	if (ancsScore == -1 && descScore == -1)
		return -1;
	if (ancsScore == -1)
		return descScore;
	if (descScore == -1)
		return ancsScore;
	return ancsScore+descScore;
}

int StackBasedAncsOuter::calculateSizeOfAncsTree(WitnessTree *tree)
{
	int size = 0;

	//score
	size += sizeof(double);

	//tree size
	size += sizeof(int);

	if (tree->length() > 1)
	{
		//ancs index
		size += sizeof(int);

		//tree itself
		size += (tree->length()-1)*ancsListNodeSize;
	}

//	size += calculateSizeOfNRETable(tree->getNRETable());

	return size;
}

int StackBasedAncsOuter::calculateSizeOfNRETable(NRETable *tab)
{
	int size = 0;

	//num of entries in table
	size += sizeof(int);
	
	for (int i=0; i<tab->getCapacity(); i++)
	{
		if (tab->getEntryByNRE(i)->getSize() == 0)
			continue;

		//nre
		size += sizeof(NREType);

		//size of entry
		size += sizeof(int);
		
		int entrySz = tab->getEntryByNRE(i)->getSize();
		
		size += entrySz * sizeof(int);
	}
	return size;
}

int StackBasedAncsOuter::calculateSizeOfDescTree(WitnessTree *tree)
{
	int size = 0;
	//score
	size += sizeof(double);

	//tree size
	size += sizeof(int);

	//tree itself
	size += tree->length()*descListNodeSize;

//	size += calculateSizeOfNRETable(tree->getNRETable());
	return size;
}

int StackBasedAncsOuter::writeAncsTreeToBuffer(ContainerClass *buf, WitnessTree *tree)
{
	// a single tree in the buffer should look like:
	// score treeSize ancsIndex tree nreTableNumOfEntries nre nreEntrySz index1 index2 ... nre nreEntrySz index1...
	if (this->calculateSizeOfAncsTree(tree) >= buf->GetSize())
		return FAILURE;
	//adding score
	double sc = tree->getScore();
	buf->AddData((char *)&sc,sizeof(double));

	//adding the tree size
	int treeSz = tree->length() - 1;
	buf->AddData((char *)&treeSz,sizeof(int));

	// if the ancs has a list associated with it, add the list to the buffer.
	if (treeSz > 0)
	{
		int ancsIndex = tree->getIndexOfNRE(ancsNRE);
		buf->AddData((char *)&ancsIndex,sizeof(int));
		for (int i =0; i < ancsIndex; i++)
			buf->AddData((char *)tree->getNodeByIndex(i),ancsListNodeSize);
		
		for (i = ancsIndex+1; i < ancsTuple->length(); i++)
			buf->AddData((char *)tree->getNodeByIndex(i),ancsListNodeSize);
	}

	return SUCCESS;
	//adding nre table
	//WriteNRETableToBuffer(buf),tree->getNRETable());		
}

int StackBasedAncsOuter::writeDescTreeToBuffer(ContainerClass *buf, WitnessTree *tree)
{
	// a single tree in the buffer should look like:
	// score treeSize tree nreTableNumOfEntries nre nreEntrySz index1 index2 ... nre nreEntrySz index1...
	if (this->calculateSizeOfDescTree(tree) >= buf->GetSize())
		return FAILURE;
	//adding score
	double sc = tree->getScore();
	buf->AddData((char *)&sc,sizeof(double));

	//adding the tree size
	int treeSz = tree->length();
	buf->AddData((char *)&treeSz,sizeof(int));
	
	buf->AddData((char *)tree->getBuffer(),tree->length()*descListNodeSize);

	//adding nre table
	//WriteNRETableToBuffer(buf),tree->getNRETable());
	return SUCCESS;
}

void StackBasedAncsOuter::writeNRETableToBuffer(ContainerClass *buf, NRETable *nreTable)
{
	int numOfEntries = nreTable->getNumUsedEntries();
	buf->AddData((char *)&numOfEntries,sizeof(int));

	for (int i=0; i<nreTable->getCapacity(); i++)
	{
		if (nreTable->getEntryByNRE(i)->getSize() == 0)
			continue;
		NREType nre = (NREType) i;
		buf->AddData((char *)&nre,sizeof(NREType));
		int entrySz = nreTable->getEntryByNRE(i)->getSize();
		buf->AddData((char *)&entrySz,sizeof(int));
		nreTable->getEntryByNRE(i)->startScan();
		int ind = nreTable->getEntryByNRE(i)->getNextIndex();
		while (ind != FAILURE)
		{
			buf->AddData((char *)&ind,sizeof(int));
			ind  = nreTable->getEntryByNRE(i)->getNextIndex();
		}
	}
}

double StackBasedAncsOuter::writeContainerToResult(ContainerClass *cont)
{
	cont->SetScanCursor(0);
	double score = 0;
	while (!cont->reachedEndOfContainer())
		score += readDescIntoResult(cont); 
	return score;
}

int StackBasedAncsOuter::handleBottom()
{
	bool goToDescList;
	double aScore = -1,dScore = -1;
	//bool fromBuf = false;
	resultBuffer->initialize();

//	if (stackElement->GetActualAncs()->GetStartPos() == 87)
//		printf("hello");
	if (bufferCurrentOutput.reachedEndOfContainer())
	{
		if (!stackElement->EmptyListOfBuffers(stackElement->GetListOfBuffers()))
		{
			if (stackElement->GetListOfBuffers()->GetNext(&bufferCurrentOutput) == FAILURE)
			{
				if (stackElement->BufferExistsAndNotEmpty(stackElement->GetBuffer()))
				{
					bufferCurrentOutput.CopyContainer(stackElement->GetBuffer());
					goToDescList = false;
					fromBuf = true;
				}
				else
				{
					fromBuf = false;
					goToDescList = true;
				}
			}
			else
			{
				goToDescList = false;
				fromBuf = false;
			}
		}
		else
		{
			continueWithBottom = false;
			fromBuf = false;
			if (!stackElement->EmptyListOfBuffers(stackElement->GetDescList()))
			{
				if (stackElement->BufferExistsAndNotEmpty(stackElement->GetDescBuffer()))
					if (WriteBufferToItsList(stackElement->GetDescBuffer(),stackElement->GetDescList()) == FAILURE)
						return EV_ERROR;
				stackElement->GetDescList()->StartScan();
				stackElement->GetDescList()->GetNext(readContainer);
			}
			else if (stackElement->BufferExistsAndNotEmpty(stackElement->GetDescBuffer()))
				readContainer->CopyContainer(stackElement->GetDescBuffer());
			return FAILURE;
		}
	}

	if (ancsNodeType == LIST_NODE)
		aScore = readAncsIntoResult(&bufferCurrentOutput,stackElement->GetActualAncs(),NULL);
	else
		aScore = readAncsIntoResult(&bufferCurrentOutput,NULL,stackElement->GetActualAncsComplex());
		
	if (fromBuf && bufferCurrentOutput.reachedEndOfContainer())
	{
		fromBuf = false;
		goToDescList = true;
	}
	else
		goToDescList = false;
		
	
	//here we are sure that bottom of stack has stuff joined with it
	if (!(stackElement->EmptyListOfBuffers(stackElement->GetSelfList())))
	{// if it does have a list, we need to read records from the self list
		dScore = 0;
		stackElement->GetSelfList()->StartScan();
		while (stackElement->GetSelfList()->GetNext(readContainer) == SUCCESS)
			dScore += writeContainerToResult(readContainer);
	}

	if (stackElement->BufferExistsAndNotEmpty(stackElement->GetSelfBuffer()))
	{
		if (dScore == -1) dScore = 0;
		dScore += writeContainerToResult(stackElement->GetSelfBuffer());
	}

	resultBuffer->setScore(this->resScore(aScore,dScore));
	if (goToDescList)
	{
		continueWithBottom = false;
		if (!stackElement->EmptyListOfBuffers(stackElement->GetDescList()))
		{
			if (stackElement->BufferExistsAndNotEmpty(stackElement->GetDescBuffer()))
				if (WriteBufferToItsList(stackElement->GetDescBuffer(),stackElement->GetDescList()) == FAILURE)
					return EV_ERROR;
			stackElement->GetDescList()->StartScan();
			stackElement->GetDescList()->GetNext(readContainer);
		}
		else if (stackElement->BufferExistsAndNotEmpty(stackElement->GetDescBuffer()))
			readContainer->CopyContainer(stackElement->GetDescBuffer());
	}
	else
		continueWithBottom = true;
	return SUCCESS;
}


double StackBasedAncsOuter::readAncsIntoResult(ContainerClass *buf, ListNode *ancsData, ComplexListNode *ancsDataComplex)
{
		//getting ancs score
	double sc;
	buf->GetNext(sizeof(double),(char *)&sc,true,false);

	int sz;
	buf->GetNext(sizeof(int),(char *)&sz,false,true);

	if (sz > 0)
	{
		int ancsIndex;
		buf->GetNext(sizeof(int),(char *)&ancsIndex);

		// adding ancs and co.
		if (ancsNodeType == LIST_NODE)
		{
			resultBuffer->appendList((ListNode *)buf->GetNextPtr(ancsIndex*ancsListNodeSize,false,true),ancsIndex);
			if (ancsData)
				resultBuffer->appendList(ancsData,1);
			else
				resultBuffer->appendList(ancsDataComplex,dataMng,1);
			resultBuffer->appendList((ListNode *)buf->GetNextPtr((sz - ancsIndex)*ancsListNodeSize,false,true),sz - ancsIndex);
		}
		else
		{
			resultBuffer->appendList((ComplexListNode *)bufferCurrentOutput.GetNextPtr(ancsIndex*ancsListNodeSize,false,true),dataMng,ancsIndex);
			if (ancsDataComplex)
				resultBuffer->appendList(ancsDataComplex,dataMng,1);
			else
				resultBuffer->appendList(ancsData,1);
			resultBuffer->appendList((ComplexListNode *)bufferCurrentOutput.GetNextPtr((sz - ancsIndex)*ancsListNodeSize,false,true),dataMng,sz - ancsIndex);
		}
	}
	else
	{
		if (ancsData)
			resultBuffer->appendList(ancsData,1);
		else
			resultBuffer->appendList(ancsDataComplex,dataMng,1);
	}
	return sc;
}

double StackBasedAncsOuter::readDescIntoResult(ContainerClass *buf)
{
	double sc;
	buf->GetNext(sizeof(double),(char *)&sc,true,false);
				
	int sz;
	buf->GetNext(sizeof(int),(char *)&sz);

	if (descNodeType == LIST_NODE)
		resultBuffer->appendList((ListNode *)buf->GetNextPtr(descListNodeSize*sz,false,true),sz);
	else
		resultBuffer->appendList((ComplexListNode *)buf->GetNextPtr(descListNodeSize*sz,false,true),dataMng,sz);
	return sc;
}