/*
COPYRIGHT  ?2000-2004 
THE REGENTS OF THE UNIVERSITY OF MICHIGAN
ALL RIGHTS RESERVED

PERMISSION IS GRANTED TO USE, COPY, CREATE DERIVATIVE WORKS AND REDISTRIBUTE THIS SOFTWARE AND SUCH DERIVATIVE WORKS FOR 
NONCOMMERCIAL EDUCATION AND RESEARCH PURPOSES, SO LONG AS NO FEE IS CHARGED, AND SO LONG AS THE COPYRIGHT NOTICE ABOVE, 
THIS GRANT OF PERMISSION, AND THE DISCLAIMER BELOW APPEAR IN ALL COPIES MADE; AND SO LONG AS THE NAME OF THE UNIVERSITY 
OF MICHIGAN IS NOT USED IN ANY ADVERTISING OR PUBLICITY PERTAINING TO THE USE OR DISTRIBUTION OF THIS SOFTWARE WITHOUT 
SPECIFIC, WRITTEN PRIOR AUTHORIZATION.

THIS SOFTWARE IS PROVIDED AS IS, WITHOUT REPRESENTATION FROM THE UNIVERSITY OF MICHIGAN AS TO ITS FITNESS FOR ANY PURPOSE, 
AND WITHOUT WARRANTY BY THE UNIVERSITY OF MICHIGAN OF ANY KIND, EITHER EXPRESS OR IMPLIED, INCLUDING WITHOUT LIMITATION THE 
IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE. THE REGENTS OF THE UNIVERSITY OF MICHIGAN SHALL 
NOT BE LIABLE FOR ANY DAMAGES, INCLUDING SPECIAL, INDIRECT, INCIDENTAL, OR CONSEQUENTIAL DAMAGES, WITH RESPECT TO ANY CLAIM 
ARISING OUT OF OR IN CONNECTION WITH THE USE OF THE SOFTWARE, EVEN IF IT HAS BEEN OR IS HEREAFTER ADVISED OF THE POSSIBILITY 
OF SUCH DAMAGES.
*/


/**
 * This class is the Timber's query evaluator. Currently, this class reads its query plan tree from 
 * a text file. 
 * @author Shurug Al-Khalifa    
 * @version 1.0
 */



#define NRE_TABLE_DEFAULT_CAPACITY 50
int globalNRETableCapacity;
int globalTemp;
#include "../Iterators/ScanIterator.h"
#include "../Iterators/UnionIterator.h"
#include "../Iterators/IntersectionIterator.h"
#include "../Iterators/DifferenceIterator.h"
#include "../Iterators/SortIterator.h"
#include "../Iterators/GroupByIterator.h"
#include "../Iterators/ValueSortIterator.h"
#include "../Iterators/DuplicateEliminatorIterator.h"
#include "../Iterators/ValueJoinIterator.h"
#include "../Iterators/FunctionIterator.h"
#include "../Iterators/TreeLevelFunctionIterator.h"
#include "../Iterators/ChildChooserIterator.h" 
#include "../Iterators/FilterIterator.h"
#include "../Iterators/MergeTreesIterator.h"
#include "../Iterators/ProjectionIterator.h" 
#include "../Iterators/FileWriterIterator.h" // deprecated: dealing with Release problem
#include "../Iterators/FileReaderIterator.h"
#include "../Iterators/PhraseFinderIterator.h"
#include "../Iterators/ConstructIterator.h"
#include "../Iterators/NavigationalGetRelative.h"
#include "../Iterators/PickIterator.h" // Pick
#include "../Iterators/DataInstantiationIterator.h"
#include "../Iterators/DataDiscardIterator.h"
#include "../Iterators/SortStopKIterator.h"
#include "../Iterators/MeetIterator.h"
#include "../Iterators/ExternalSortIterator.h"
#include "../Iterators/ExternalValueSortIterator.h"
#include "../Iterators/UniversalQuantification.h"
#include "../Iterators/UpdatesIterator.h"
/* Yunyao - Added 12-15-2003*/
#include "../MCCAS/MeaningfulClosestCommonAncestorStructureIterator.h"
#include "../Iterators/OneSidedValueJoinIterator.h"
#include "../Iterators/IndexHashValueJoinIterator.h"

#include "../JoinAlgorithms/StackBasedAncs.h"
#include "../JoinAlgorithms/StackBasedAncsProjAncs.h"
#include "../JoinAlgorithms/StackBasedDesc.h"
#include "../JoinAlgorithms/StackBasedAncsOuter.h"
//#include "../JoinAlgorithms/StackBasedDescOuter.h"
#include "../JoinAlgorithms/StackBasedNegativeAncs.h"
#include "../JoinAlgorithms/StackBasedTermJoin.h"

#include "../IndexAccesses/GistIndexAccess.h"
//#include "../IndexAccesses/HashIndexAccess.h"
//ErrorInfoClass globalErrorInfo;
#include <fstream>
#include <strstream>
#include <string>

#include <vector>
using namespace std;

EvaluatorClass *gEvaluator;
FileIDType gFileID;
vector< pair<int, string> > gUpdatesArray;

//bool gUseTagIdIndex = false;
#ifdef EVAL_TIME_OUT
clock_t gQueryStartTime;
int gTimeOutAfter;
#endif

//FILE *shoreIDsFile;
// evaluator's static members
int EvaluatorClass::openFilesCount;
FileIDType EvaluatorClass::openFiles[MAX_FILENUMER];
char EvaluatorClass::openFilesNames[MAX_XMLFILE_NAME_LENGTH][MAX_FILENUMER];

// some global parameters
#define MAX_FILE_INTERFACE_LINE_SIZE  1000

/*****************************
 * External IR-XML routines: *
 *****************************/

extern double scoreFunction1(char *xmlDoc, int keywordSet);
extern double scoreFunction2(char *xmlDoc, int keywordSet);
extern bool ancsQual1(double score, int keywordSet);
extern int ancsLevel1(KeyType sk, int level, int keywordSet); /* what for? */
extern bool Select(PickStackNode *node, ListNode *standard, char *lastTag = NULL);
extern bool Qualify(WitnessTree *tree, char *tag = NULL);

double nullScoreFunction(char *xmlDoc, int keywordSet)
{
	keywordSet = keywordSet;
	xmlDoc = xmlDoc;
	return -1;
}
bool nullAncsQual(double score, int keywordSet)
{
	score = score;
	keywordSet = keywordSet;
	return true;
}
int nullAncsLevel(KeyType sk, int level, int keywordSet)
{
	sk = sk;
	level = level;
	keywordSet = keywordSet;
	return -1;
}

/*********************
 * Constructs & Misc *
 *********************/
EvaluatorClass::EvaluatorClass(DataMng *dataMng, IndexMng *indexMng)
{
    this->dataMng = dataMng;

    this->indexMng = indexMng;

    xmlOutput = NULL;
    openFilesCount = 0;
    constructOutput = true;

    // added by Melanie
    this->capacityChoice = -1;
    this->capacity = -1;
    this->replacementChoice = -1;
    this->replacementPercentage = -1;
	globalNRETableCapacity = NRE_TABLE_DEFAULT_CAPACITY;
	
	updatesCursor = 0;

#ifdef EVAL_TIME_OUT
	gTimeOutAfter = gSettings->getIntegerValue("EVAL_TIME_OUT_AFTER",DEFAULT_TIME_OUT);
#endif
	ShoreList::tempBuf = new char[gSettings->getIntegerValue("CONTAINER_SIZE",CONTAINER_SIZE_DEFAULT) + sizeof(serial_t) + 5];
	fileIDsArray = NULL;
	fileIDsArraySize = 0;

	//globalTemp = 0;
	//shoreIDsFile = fopen("shoreIDs.txt","w");
}

EvaluatorClass::~EvaluatorClass()
{
    if (xmlOutput)
        delete [] xmlOutput;

	delete [] ShoreList::tempBuf;
	if (this->fileIDsArray)
		delete [] fileIDsArray;
		gUpdatesArray.clear();

//	cout<<"num shore writes:"<<globalTemp<<endl;
//	fclose(shoreIDsFile);
}

IndexMng *EvaluatorClass::getIndexMng()
{
    return this->indexMng;
}


/*****************************
 * Query Tree Methods        *
 *****************************/
QueryEvaluationTree *EvaluatorClass::getQueryEvalTree(void *queryInput)
{
	char line[MAX_FILE_INTERFACE_LINE_SIZE];
	QueryEvaluationTree *tree = NULL;
	this->maxNRE = 1;
	this->fileIDsArraySize = 0;
//	gNumUpdates = 0;

	if (((std::iostream *)queryInput)->eof() == 0)
	{

		((std::iostream *)queryInput)->getline(line,MAX_FILE_INTERFACE_LINE_SIZE);
		tree = NULL;

		gUpdatesArray.clear();
		tree = new QueryEvaluationTree(getQueryEvalNode(line,queryInput));
		globalNRETableCapacity = maxNRE + 1;
		
	}
	return tree;

}

QueryEvaluationTree *EvaluatorClass::getTreeFromFile(char *fullPathFileName)
{
    std::fstream queryFile;
    queryFile.open(fullPathFileName, std::ios::in);
    // FILE *queryFile = fopen(fullPathFileName,"r");
    if (queryFile.is_open() == 0)
    {
		ostringstream oss;
		oss << "File " << fullPathFileName << " could not be opened";
		globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"Evaluator",__FILE__,oss.str().c_str());
		this->closeFiles(dataMng);
		return NULL;              
    }
    QueryEvaluationTree *qtree = getQueryEvalTree(&queryFile);
    queryFile.close();
    return qtree;
}

QueryEvaluationTreeNode *EvaluatorClass::getQueryEvalNode(char *line, void *queryInput)
{
    QueryEvaluationTreeNode *curr = NULL;
    while (line[0] == '*')
    {
        if (((std::iostream *)queryInput)->eof() == 0)
            ((std::iostream *)queryInput)->getline(line,MAX_FILE_INTERFACE_LINE_SIZE);
        else
            return NULL;
    }
    switch (line[0])
    {
	/*
	case 'O': // index access with "tagname, id" pair index...
		// :KLUDGE:
		gUseTagIdIndex = true;

		//explicit fallthrough...  no break here.
	*/
    case 'I': // index access
    {
        // the index name
        char *token = strtok(line+2,",");

		 if (token == NULL)
        {
			globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"Evaluator",__FILE__,"Expecting NRE in Index Access Line.");
            return NULL;
        }
		NREType nre = (NREType)atoi(token);
		if (nre < 1)
		{
			globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"Evaluator",__FILE__,"NRE should be positive.");
            return NULL;
        }
		if (nre > maxNRE)
			maxNRE = nre;

		token = strtok(NULL,",");
        if (token == NULL)
        {
			globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"Evaluator",__FILE__,"Expecting Index Name in Index Access Line.");
            return NULL;
        }
		char *indexName = new char[strlen(token)+1];
        strcpy(indexName,token);

        // the index file name
        token = strtok(NULL,",");
        char *fileName;
        if (token == NULL)
        {
			globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"Evaluator",__FILE__,"Expecting XML File Name in Index Access Line.");
			delete [] indexName;           
			return NULL;
        }
        fileName = new char[strlen(token)+1];
        strcpy(fileName,token);

        //Hash or GIST index
        token = strtok(NULL,",");
        if (token == NULL)
        {
			globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"Evaluator",__FILE__,"Expecting HASH or GIST in Index Access Line.");
            delete [] indexName;
			delete [] fileName;
			return NULL;
        }
        int shoreOrGist;
		if (strcmp(token,"GIST") == 0)
			shoreOrGist = GIST_INDEX;
		else if (strcmp(token,"HASH") == 0)
			shoreOrGist = HASH_INDEX;
		else if (strcmp(token,"SHORE") == 0)
		{
			globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"Evaluator",__FILE__,"Shore indices are not supported.");
            delete [] indexName;
			delete [] fileName;
			return NULL;
		}
		else
		{
			globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"Evaluator",__FILE__,"Unrecognizable index source.");
            delete [] indexName;
			delete [] fileName; 
			return NULL;
		}

        // Index Type: INT, STR, FLT
        token = strtok(NULL,",");
        if (token == NULL)
        {
			globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"Evaluator",__FILE__,"Expecting Index Type in Index Access Line.");
            delete [] indexName;
			delete [] fileName; 
			return NULL;
        }
        int indexType;
        if (strcmp(token,"INT") == 0)
            indexType = INT_INDEX;
        else if (strcmp(token,"FLT") == 0)
            indexType = FLOAT_INDEX;
        else if (strcmp(token,"STR") == 0)
            indexType = STRING_INDEX;
        else if (strcmp(token,"DBL") == 0)
            indexType = DOUBLE_INDEX;
		else
		{
			globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"Evaluator",__FILE__,"Unrecognizable index type.");
            delete [] indexName;
			delete [] fileName; 
			return NULL;
		}

		if (strstr(indexName,"elementtag"))
			indexType = INT_INDEX;

		bool useTagIdIndex = false;
		//make sure indexName has tagid in it if using indices with concatenated <string,id> keys... for updates.
		if (strstr(indexName, "tagid")) {
			useTagIdIndex = true;
		}
		// value
        token = strtok(NULL,",");
        if (token == NULL)
        {
			globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"Evaluator",__FILE__,"Expecting string, float, double or integer value in Index Access Line.");
            delete [] indexName;
			delete [] fileName;  
			return NULL;
        }
       char *strVal;
		if (strstr(indexName,"elementtag"))
		{
			int tagCode = dataMng->getPhysicalDataMng()->getXMLNameTable()->getCodeByName(token);
		/*	if (tagCode == -1)
			{
				globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"Evaluator",__FILE__,"Tag name does not exist in Timber. in Index Access Line.");
				delete [] indexName;
				delete [] fileName;  
				return NULL;
			}*/
			strVal = new char[6];
			sprintf(strVal,"%d",tagCode);
		}
		else
		{
		    strVal = new char[strlen(token)+1];
			strcpy(strVal , token);
		}

        // create the new QueryEvaluationTreeNode
        token = strtok(NULL,",");
        if (token == NULL)
        {
            curr = new QueryEvaluationTreeIndexAccessNode(indexName,nre,fileName,strVal,NULL);
            ((QueryEvaluationTreeIndexAccessNode *)curr)->setIndexType(indexType);
            ((QueryEvaluationTreeIndexAccessNode *)curr)->setShoreOrGist(shoreOrGist);
        }
        else
        {
            // the second optional value 
            char *strVal2  = NULL;
            if (strcmp(token,"-1") != 0)
            {
				if (strstr(indexName,"elementtag"))
				{
					int tagCode = dataMng->getPhysicalDataMng()->getXMLNameTable()->getCodeByName(token);
				/*	if (tagCode == -1)
					{
						globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"Evaluator",__FILE__,"Tag name does not exist in Timber. in Index Access Line.");
						delete [] indexName;
						delete [] fileName;  
						return NULL;
					}*/
					strVal2 = new char[6];
					sprintf(strVal2,"%d",tagCode);
				}
				else
				{
					strVal2 = new char[strlen(token)+1];
					strcpy(strVal2,token);
				}
            }

            curr = new QueryEvaluationTreeIndexAccessNode(indexName,nre,fileName,strVal,strVal2);
            ((QueryEvaluationTreeIndexAccessNode *)curr)->setIndexType(indexType);
            ((QueryEvaluationTreeIndexAccessNode *)curr)->setShoreOrGist(shoreOrGist);     
        }

		((QueryEvaluationTreeIndexAccessNode *)curr)->tagIdIndex = useTagIdIndex;
    }
	//((QueryEvaluationTreeIndexAccessNode *)curr)->tagIdIndex = gUseTagIdIndex;
	//gUseTagIdIndex = false;
    break;

    case 's': // construct iterator
    {
        char *token = strtok(line+2,",");
        if (token == NULL)
        {
			globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"Evaluator",__FILE__,"Expecting number of construct specifications in Construct Line.");
            return NULL;
        }
        int num = atoi(token);
        ConstructSpecification *spec;
        if (num > 0)
            spec = new ConstructSpecification(num);
        else
		{
			spec = NULL;
			globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"Evaluator",__FILE__,"You should have at least one construct specification.");
            return NULL;
        }
            
        for (int i=0; i<num; i++)
        {
            SingleConstructSpec ss;
            token = strtok(NULL,",");
            if (token == NULL)
            {
				globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"Evaluator",__FILE__,"Expecting level of construct spec in Construct Line.");
                delete spec;
				return NULL;
            }
            int level = atoi(token);
			if (level < 0)
            {
				globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"Evaluator",__FILE__,"Level should be positive or 0 in Construct Line.");
                 delete spec;
				return NULL;
            }
            ss.setLevel(level);
            //type
            token = strtok(NULL,",");
            if (token == NULL)
            {
                globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"Evaluator",__FILE__,"Expecting type of construct spec in Construct Line.");
                 delete spec;
				return NULL;
            }
            int type;
            if (strcmp(token,"E") == 0)
                type = CONSTRUCT_TYPE_ELEMENT;
            else if (strcmp(token,"A") == 0)
                type = CONSTRUCT_TYPE_ATTRIBUTE;
			else if (strcmp(token,"OA") == 0)
                type = CONSTRUCT_TYPE_OPTIONAL_ATTR;
            else if (strcmp(token,"C") == 0)
                type = CONSTRUCT_TYPE_CONTENT;
			else
			{
				globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"Evaluator",__FILE__,"Unrecognizable construct type.");
				delete spec;
				return NULL;
			}
            ss.setType(type);

            //source
            token = strtok(NULL,",");
            if (token == NULL)
            {
                globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"Evaluator",__FILE__,"Expecting source of construct spec in Construct Line.");
                delete spec;
				return NULL;
            }
            int source;
            if (strcmp(token,"C") == 0)
                source = CONSTRUCT_SRC_CONST;
            else if (strcmp(token,"R") == 0)
                source = CONSTRUCT_SRC_REFERENCE;
			else
			{
				globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"Evaluator",__FILE__,"Unrecognizable construct source.");
				delete spec;
				return NULL;
			}

            ss.setSource(source);

			token = strtok(NULL,",");
			if (token == NULL)
			{
				globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"Evaluator",__FILE__,"Expecting assigned NRE in Construct Line.");
				delete spec;
				return NULL;
			}
			NREType assignedNRE = (NREType)atoi(token);
			if (assignedNRE < 1)
			{
				globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"Evaluator",__FILE__,"NRE should be positive.");
				delete spec;
				return NULL;
			}
			ss.setAssignedNRE(assignedNRE);
			if (assignedNRE > maxNRE)
				maxNRE = assignedNRE;
            if (source == CONSTRUCT_SRC_CONST)
            {//constant source
				
                if (type == CONSTRUCT_TYPE_ELEMENT)
                {
                    token = strtok(NULL,",");
                    if (token == NULL)
                    {
                        globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"Evaluator",__FILE__,"Expecting constant element name in Construct Line.");
						delete spec;                       
						return NULL;
                    }
                    char *str = new char[strlen(token)+1];
                    strcpy(str,token);
                    ss.setStr1(str);
                }
                else if (type == CONSTRUCT_TYPE_ATTRIBUTE || type == CONSTRUCT_TYPE_OPTIONAL_ATTR)
                {
                    token = strtok(NULL,",");
                    if (token == NULL)
                    {
                        globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"Evaluator",__FILE__,"Expecting constant attribute name in Construct Line.");
                        delete spec;
						return NULL;
                    }
                    char *str1 = new char[strlen(token)+1];
                    strcpy(str1,token);
                    ss.setStr1(str1);

                    token = strtok(NULL,",");
                    if (token == NULL)
                    {
                        globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"Evaluator",__FILE__,"Expecting constant attribute value in Construct Line.");
                        delete spec;
						return NULL;
                    }
                    char *str2 = new char[strlen(token)+1];
                    strcpy(str2,token);
                    ss.setStr2(str2);
                }
                else
                {
                    token = strtok(NULL,",");
                    if (token == NULL)
                    {
                        globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"Evaluator",__FILE__,"Expecting constant content in Construct Line.");
                        delete spec;
						return NULL;
                    }
                    char *str = new char[strlen(token)+1];
                    strcpy(str,token);
                    ss.setStr1(str);
                }
            }
            else
            { //reference source
                if (type == CONSTRUCT_TYPE_ATTRIBUTE || type == CONSTRUCT_TYPE_OPTIONAL_ATTR)
                {
                    token = strtok(NULL,",");
                    if (token == NULL)
                    {
                        globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"Evaluator",__FILE__,"Expecting constant attribute name in Construct Line.");
                        delete spec;
						return NULL;
                    }
                    char *str1 = new char[strlen(token)+1];
                    strcpy(str1,token);
                    ss.setStr1(str1);
                }
                token = strtok(NULL,",");
                if (token == NULL)
                {
                    globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"Evaluator",__FILE__,"Expecting root NRE in Construct Line.");
					delete spec;                   
					return NULL;
                }
                NREType rootNRE = (NREType)atoi(token);
				if (rootNRE < 1)
				{
					globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"Evaluator",__FILE__,"NRE should be positive.");
					delete spec;
					return NULL;
				}
				if (rootNRE > maxNRE)
					maxNRE = rootNRE;
                ss.setPatternRootNRE(rootNRE);
                token = strtok(NULL,",");
                if (token == NULL)
                {
                    globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"Evaluator",__FILE__,"Expecting number of nodes in pattern in Construct Line.");
                    delete spec;
					return NULL;
                }
                int num1 = atoi(token);

                int *relation;
                ExecArrayType *pattern;
                int lev;
                int *getWhat;
                char **attrNames;
                int *tagNames;
                if (num1 > 1)
                {
                    pattern = new ExecArrayType;
                    relation = new int[num1];
                    getWhat = new int[num1];
                    attrNames = new char *[num1];
                    token = strtok(NULL,",");
                    if (token == NULL)
                    {
                        globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"Evaluator",__FILE__,"Expecting source of nodes in pattern in Construct Line.");
                        delete spec;
						delete [] pattern;
						delete [] relation;
						delete [] getWhat;
						delete [] attrNames;
						return NULL;
                    }
                    int nodeSource;
					if (strcmp(token,"W") == 0)
						nodeSource = CPM_NODE_SRC_WITNESS;
					else if (strcmp(token,"I") == 0)
						nodeSource = CPM_NODE_SRC_INDEX;
					else
					{
						globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"Evaluator",__FILE__,"Unrecognizable node source in construct.");
						   delete spec;
						delete [] pattern;
						delete [] relation;
						delete [] getWhat;
						delete [] attrNames;
						return NULL;
					}
                    ss.setNodeSource(nodeSource);
                    if (nodeSource == CPM_NODE_SRC_WITNESS)
                        tagNames = new int[num1];
                    else
                        tagNames = NULL;
                }
                else
                {
                    num1 = 0;
                    pattern = NULL;
                    relation = NULL;
                    getWhat = NULL;
                    attrNames = NULL;
                    tagNames = NULL;
                    token = strtok(NULL,",");
                    if (token == NULL)
                    {
                        globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"Evaluator",__FILE__,"Expecting getWhat of root in Construct Line.");
						delete spec;                       
						return NULL;
                    }
                    int rootGetWhat;
                    if (strcmp(token, "S") == 0)
                        rootGetWhat = CPM_GET_SUBTREE;
                    else if (strcmp(token,"A") == 0)
                        rootGetWhat = CPM_GET_ATTR;
                    else if (strcmp(token,"I") == 0)
                        rootGetWhat = CPM_GET_ITSELF;
                    else if (strcmp(token,"L") == 0)
						rootGetWhat = CPM_GET_LOCAL_SUBTREE;
					else if (strcmp(token,"V") == 0)
						rootGetWhat = CPM_GET_VALUE;
					else if (strcmp(token,"T") == 0)
                        rootGetWhat = CPM_GET_TEXT;
					else
					{
						globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"Evaluator",__FILE__,"Unrecognizable rootGetWhat in construct.");
						   delete spec;
						return NULL;
					}
                    ss.setRootGetWhat(rootGetWhat);
                    ss.setNodeSource(CPM_NODE_SRC_INDEX);
                    if (rootGetWhat == CPM_GET_ATTR || rootGetWhat == CPM_GET_VALUE)
                    {
                        token = strtok(NULL,",");
                        if (token == NULL)
                        {
                            globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"Evaluator",__FILE__,"Expecting attribute name of root in Construct Line.");
                            delete spec; 
							return NULL;
                        }
                        char *attrName = new char[strlen(token) +1];
                        strcpy(attrName,token);
                        ss.setRootAttrName(attrName);
                    }
                }

                for (int j=0; j<num1; j++)
                {
                    if (j!=0)
                    {
                        token = strtok(NULL,",");
                        if (token == NULL)
                        {
                            globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"Evaluator",__FILE__,"Expecting level of pattern node in Construct Line.");
							if (ss.getNodeSource() == CPM_NODE_SRC_WITNESS)
								delete [] tagNames;
							
							delete spec;
							delete [] pattern;
							delete [] relation;
							delete [] getWhat;
							for (int l=0; l<j; l++)
								if (attrNames[l]) delete [] attrNames[l];
							delete [] attrNames;
							return NULL;
						}
						lev = atoi(token);
						if (lev < 0)
						{
							globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"Evaluator",__FILE__,"Level should be positive or 0 in Construct Line.");
							if (ss.getNodeSource() == CPM_NODE_SRC_WITNESS)
								delete [] tagNames;
						
							delete spec;
							delete [] pattern;
							delete [] relation;
							delete [] getWhat;
							for (int l=0; l<j; l++)
								if (attrNames[l]) delete [] attrNames[l];
							delete [] attrNames;
							return NULL;
						}
						pattern->InsertNodeInArray(NULL,lev);

						if (ss.getNodeSource() == CPM_NODE_SRC_WITNESS)
						{
							token = strtok(NULL,",");
							if (token == NULL)
							{
								globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"Evaluator",__FILE__,"Expecting tag name in pattern in Construct Line.");

								delete [] tagNames;

								delete spec;
								delete [] pattern;
								delete [] relation;
								delete [] getWhat;
								for (int l=0; l<j; l++)
									if (attrNames[l]) delete [] attrNames[l];
								delete [] attrNames;
								return NULL;
							}
							
							tagNames[j] = dataMng->getPhysicalDataMng()->getXMLNameTable()->getCodeByName(token);
                        }

                        token = strtok(NULL,",");
                        if (token == NULL)
                        {
                            globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"Evaluator",__FILE__,"Expecting relation in pattern in Construct Line.");
                            if (ss.getNodeSource() == CPM_NODE_SRC_WITNESS)
								delete [] tagNames;
							
							delete spec;
							delete [] pattern;
							delete [] relation;
							delete [] getWhat;
							for (int l=0; l<j; l++)
								if (attrNames[l]) delete [] attrNames[l];
							delete [] attrNames;
							return NULL;
                        }
                        if (strcmp(token,"A") == 0) 
							relation[j] = ANCS_DESC;
						else if (strcmp(token,"P") == 0)
							relation[j] = PARENT_CHILD;
						else
						{
							globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"Evaluator",__FILE__,"Expecting relation in pattern in Construct Line.");
							if (ss.getNodeSource() == CPM_NODE_SRC_WITNESS)
								delete [] tagNames;
							
							delete spec;
							delete [] pattern;
							delete [] relation;
							delete [] getWhat;
							for (int l=0; l<j; l++)
								if (attrNames[l]) delete [] attrNames[l];
							delete [] attrNames;
							return NULL;
						}
                        token = strtok(NULL,",");
                        if (token == NULL)
                        {
                            globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"Evaluator",__FILE__,"Expecting getWhat of pattern node in Construct Line.");
                            if (ss.getNodeSource() == CPM_NODE_SRC_WITNESS)
								delete [] tagNames;
							
							delete spec;
							delete [] pattern;
							delete [] relation;
							delete [] getWhat;
							for (int l=0; l<j; l++)
								if (attrNames[l]) delete [] attrNames[l];
							delete [] attrNames;
							return NULL;
                        }
                        if (strcmp(token, "S") == 0)
                            getWhat[j] = CPM_GET_SUBTREE;
                        else if (strcmp(token,"A") == 0)
                            getWhat[j] = CPM_GET_ATTR;
                        else if (strcmp(token,"I") == 0)
                            getWhat[j] = CPM_GET_ITSELF;
						else if (strcmp(token,"L") == 0)
							getWhat[j] = CPM_GET_LOCAL_SUBTREE;
                        else if (strcmp(token,"T") == 0)
                            getWhat[j] = CPM_GET_TEXT;
						else
						{
							globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"Evaluator",__FILE__,"Unrecognized getWhat of pattern node in Construct Line.");
                            if (ss.getNodeSource() == CPM_NODE_SRC_WITNESS)
								delete [] tagNames;
							
							delete spec;
							delete [] pattern;
							delete [] relation;
							delete [] getWhat;
							for (int l=0; l<j; l++)
								if (attrNames[l]) delete [] attrNames[l];
							delete [] attrNames;
							return NULL;
						}

                        if (getWhat[j] == CPM_GET_ATTR || getWhat[j] == CPM_GET_VALUE)
                        {
                            token = strtok(NULL,",");
                            if (token == NULL)
                            {
                                globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"Evaluator",__FILE__,"Expecting attribute name in pattern in Construct Line.");
								if (ss.getNodeSource() == CPM_NODE_SRC_WITNESS)
									delete [] tagNames;
								
								delete spec;
								delete [] pattern;
								delete [] relation;
								delete [] getWhat;
								for (int l=0; l<j; l++)
									if (attrNames[l]) delete [] attrNames[l];
								delete [] attrNames;
								return NULL;
                            }
                            attrNames[j] = new char[strlen(token) +1];
                            strcpy(attrNames[j],token);
						}
						else
                            attrNames[j] = NULL;
                    }
                    else
                    {
                        attrNames[j] = NULL;
                        if (ss.getNodeSource() == CPM_NODE_SRC_WITNESS)
                            tagNames[j] = -1;
                        pattern->InsertNodeInArray(NULL,0);
                    }
                }
                ss.setPattern(pattern);
                ss.setRelation(relation);
                ss.setGetWhat(getWhat);
                ss.setAttrNames(attrNames);
                ss.setTagNames(tagNames);

            }
            spec->appendSpec(&ss);
            ss.setPattern(NULL,false);
            ss.setRelation(NULL,false);
            ss.setGetWhat(NULL,false);
            ss.setAttrNames(NULL,false);
            ss.setTagNames(NULL,false);
            ss.setStr1(NULL,false);
            ss.setStr2(NULL,false);
            ss.setRootAttrName(NULL,false);
        }

        for (i=0; i<num; i++)
        {
            if (spec->getSpecByIndex(i)->getPattern())
            {
                if (spec->getSpecByIndex(i)->getNodeSource() == CPM_NODE_SRC_INDEX)
                {
                    for (int j=0; j<spec->getSpecByIndex(i)->getPattern()->GetSize(); j++)
                    {
                        if (j!=0)
                        {
                            char newLine[MAX_FILE_INTERFACE_LINE_SIZE];
                            if (((std::iostream *)queryInput)->eof() == 0)
                                ((std::iostream *)queryInput)->getline(newLine,MAX_FILE_INTERFACE_LINE_SIZE);
                            else
                            {
                                globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"Evaluator",__FILE__,"Unexpected end of file while trying to read index accesses following Construct Line.");
                                delete spec;
								return NULL;
                            }
                            // this should return 1 index access/scan node.
                            spec->getSpecByIndex(i)->getPattern()->GetEntryByIndex(j)->SetQueryEvalNode(getQueryEvalNode(newLine,queryInput));
                        }
                    }
                }
            }
        }
        char newLine[MAX_FILE_INTERFACE_LINE_SIZE];
        if (((std::iostream *)queryInput)->eof() == 0)
            ((std::iostream *)queryInput)->getline(newLine,MAX_FILE_INTERFACE_LINE_SIZE);
        else
        {
            globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"Evaluator",__FILE__,"Unexpected end of file in Construct Line.");
            delete spec;
			return NULL;
        }
        QueryEvaluationTreeNode *oper = getQueryEvalNode(newLine,queryInput);
        if (oper == NULL)
        {
            globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"Evaluator",__FILE__,"Unexpected operand returned (NULL) for Construct Line.");
            delete spec;
			return NULL;
        }
        curr = new QueryEvaluationTreeConstructNode(oper,spec);
    }
    break;

    case 'S': // scan
    {
        // data file name
        char *token = strtok(line+2,",");
		if (token == NULL)
        {
			globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"Evaluator",__FILE__,"Error input from file... expecting NRE... Scan Access line...");
            return NULL;
        }
		NREType nre = (NREType)atoi(token);

		if (nre < 1)
		{
			globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"Evaluator",__FILE__,"NRE should be positive.");
			return NULL;
		}
		if (nre > maxNRE)
				maxNRE = nre;
		token = strtok(NULL,",");
        char fileName[MAX_XMLFILE_NAME_LENGTH];
        if (token == NULL)
        {
			globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"Evaluator",__FILE__,"Error input from file... expecting file name... Scan Access line...");
            return NULL;
        }
        strcpy(fileName,token);
        
        // rootKey of the scan
        token = strtok(NULL,",");
        if (token == NULL)
        {
			globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"Evaluator",__FILE__,"Error input from file... expecting scan root key... Scan Access line...");
            return NULL;
        }
        KeyType rootKey = (KeyType)(atoi(token));
        
        // prepare the selection condition
        SelectionCondition *selCond = new SelectionCondition;

        // scan type: ALL_NODES, ELEMENT_NODE, etc.
        token = strtok(NULL,",");
        if (token == NULL)
        {
			globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"Evaluator",__FILE__,"Error input from file... expecting node Type... Scan Access line...");
            delete selCond;
			return NULL;
        }
        if (strcmp(token,"ALL_NODES") == 0)
            selCond->setNodeType(SCAN_ALLNODES);
        else if (strcmp(token,"DOCUMENT_NODE") == 0)
            selCond->setNodeType(DOCUMENT_NODE);
        else if (strcmp(token,"ELEMENT_NODE") == 0)
            selCond->setNodeType(ELEMENT_NODE);
        else if (strcmp(token,"ATTRIBUTE_NODE") == 0)
            selCond->setNodeType(ATTRIBUTE_NODE);
        else if (strcmp(token,"TEXT_NODE") == 0)
            selCond->setNodeType(TEXT_NODE);
        else if (strcmp(token,"COMMENT_NODE") == 0)
            selCond->setNodeType(COMMENT_NODE);
		else
		{
			globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"Evaluator",__FILE__,"Unrecognized node Type... Scan Access line...");
            delete selCond;
			return NULL;
		}
        
        // return type: THISNODE, PARENTNODE, etc.
        token = strtok(NULL,",");
        if (token == NULL)
        {
			globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"Evaluator",__FILE__,"Error input from file... expecting return Type... Scan Access line...");
            delete selCond;
			return NULL;
        }
        if (strcmp(token,"THISNODE") == 0)
            selCond->setReturnType(SCAN_RETURN_THISNODE);
        else if (strcmp(token,"PARENTNODE") == 0)
            selCond->setReturnType(SCAN_RETURN_PARENTNODE);
        else if (strcmp(token,"ELEMENTNODE") == 0)
            selCond->setReturnType(SCAN_RETURN_ELEMENTNODE);
        else if (strcmp(token,"ATTRIBUTENODE") == 0)
            selCond->setReturnType(SCAN_RETURN_ATTRIBUTENODE);
        else if (strcmp(token,"SUBTREE") == 0)
            selCond->setReturnType(SCAN_RETURN_SUBTREE);
		else
		{
			globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"Evaluator",__FILE__,"Unrecognized return Type... Scan Access line...");
            delete selCond;
			return NULL;
		}

        // number of disjunction conditions
        token = strtok(NULL,",");
        if (token == NULL)
        {
			globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"Evaluator",__FILE__,"Error input from file... expecting number of disjunctive conds... Scan Access line...");
            delete selCond;
			return NULL;
        }
        int numDis = atoi(token);

		if (numDis < 0)
		{
			globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"Evaluator",__FILE__,"Error input from file... number of disjunctive conds should be positive or 0... Scan Access line...");
            delete selCond;
			return NULL;
        }
        DisjunctiveCondition *disCond = new DisjunctiveCondition(numDis);

        // number of conjunctive conditions in each disjunctive condition
        int numCon;
        ConjunctiveCondition *conCond;
        PredicateCondition *pred;

        // grab the conditions
        for (int i=0; i<numDis; i++)
        {
            token = strtok(NULL,",");
            if (token == NULL)
            {
				globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"Evaluator",__FILE__,"Error input from file... expecting number of conjunctive conds... Scan Access line...");
                delete selCond;
				delete disCond;
				return NULL;
            }
            numCon = atoi(token);
			if (numCon < 0)
			{
				globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"Evaluator",__FILE__,"Error input from file... number of conjunctive conds should be positive or 0... Scan Access line...");
				delete selCond;
				delete disCond;
				return NULL;
			}
            conCond = new ConjunctiveCondition(numCon);
            for (int j=0; j<numCon; j++)
            {
                token = strtok(NULL,",");
                if (token == NULL)
                {
					globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"Evaluator",__FILE__,"Error input from file... expecting Left predicate value... Scan Access line...");
                    delete selCond;
					delete disCond;
					delete conCond;
					return NULL;
                }
                pred = new PredicateCondition;
                if (strcmp(token,"VALUE") == 0)
                    pred->setLeftValue(SCAN_LEFTVALUE_VALUE);
                else if (strcmp(token,"LENGTH") == 0)
                    pred->setLeftValue(SCAN_LEFTVALUE_LENGTH);
                else if (strcmp(token,"XMLFILENAME") == 0)
                    pred->setLeftValue(SCAN_LEFTVALUE_XMLFILENAME);
                else if (strcmp(token,"NODETAG") == 0)
                    pred->setLeftValue(SCAN_LEFTVALUE_NODETAG);
                else if (strcmp(token,"CHILDNUMBER") == 0)
                    pred->setLeftValue(SCAN_LEFTVALUE_CHILDNUMBER);
                else if (strcmp(token,"ATTRIBUTENUMBER") == 0)
                    pred->setLeftValue(SCAN_LEFTVALUE_ATTRIBUTENUMBER);
                else if (strcmp(token,"HAS_CHILD") == 0)
                    pred->setLeftValue(SCAN_LEFTVALUE_HASCHILD);
                else if (strcmp(token,"HAS_ATTRIBUTE") == 0)
                    pred->setLeftValue(SCAN_LEFTVALUE_HASATTRIBUTE);
				else if (strcmp(token,"ELEMENTCONTENT") == 0)
                    pred->setLeftValue(SCAN_LEFTVALUE_ELEMENTCONTENT);
				else if (strcmp(token,"ATTRIBUTE_VALUE") == 0)
				{
					token = strtok(NULL,",");
					if (token == NULL)
					{
						globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"Evaluator",__FILE__,"Error input from file... expecting attribute name... Scan Access line...");
						delete selCond;
						delete disCond;
						delete conCond;
						delete pred;
						return NULL;
					}
					char *tmp = new char[strlen(token) + 1];
					strcpy(tmp,token);
					pred->setLeftValue((int) tmp);
				}
				else
				{
					globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"Evaluator",__FILE__,"Error input from file... unrecognized left predicate type... Scan Access line...");
					delete selCond;
					delete disCond;
					delete conCond;
					delete pred;
					return NULL;
				}

                token = strtok(NULL,",");
                if (token == NULL)
                {
					globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"Evaluator",__FILE__,"Error input from file... expecting predicate operator... Scan Access line...");
                    delete selCond;
					delete disCond;
					delete conCond;
					delete pred;
					return NULL;
                }
                if (strcmp(token,"GT") == 0)
                    pred->setOperator(SCAN_OP_GT);
                else if (strcmp(token,"GE") == 0)
                    pred->setOperator(SCAN_OP_GE);
                else if (strcmp(token,"LT") == 0)
                    pred->setOperator(SCAN_OP_LT);
                else if (strcmp(token,"LE") == 0)
                    pred->setOperator(SCAN_OP_LE);
                else if (strcmp(token,"EQ") == 0)
                    pred->setOperator(SCAN_OP_EQ);
                else if (strcmp(token,"NE") == 0)
                    pred->setOperator(SCAN_OP_NE);
                else if (strcmp(token,"CONTAIN") == 0)
                    pred->setOperator(SCAN_OP_CONTAINS);
                else if (strcmp(token,"CONTAINEDBY") == 0)
                    pred->setOperator(SCAN_OP_CONTAINEDBY);
                else if (strcmp(token,"STARTWITH") == 0)
                    pred->setOperator(SCAN_OP_STARTWITH);
				else
				{
					globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"Evaluator",__FILE__,"Error input from file... unrecognized operation... Scan Access line...");
					delete selCond;
					delete disCond;
					delete conCond;
					delete pred;
					return NULL;
				}
                
				if (pred->getLeftValue() == SCAN_LEFTVALUE_NODETAG && pred->getOperator() != SCAN_OP_EQ
					&& pred->getOperator() != SCAN_OP_NE)
				{
					globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"Evaluator",__FILE__,"Error input from file... Equality and inequality are the only operations allowed with node tag... Scan Access line...");
					delete selCond;
					delete disCond;
					delete conCond;
					delete pred;
					return NULL;
				}

                token = strtok(NULL,",");
                if (token == NULL)
                {
					globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"Evaluator",__FILE__,"Error input from file... expecting right predicate type... Scan Access line...");
                    delete selCond;
					delete disCond;
					delete conCond;
					delete pred;
					return NULL;
                }

                Value *val = new Value;
                if (strcmp(token,"INT") == 0)
                    val->setValueType(INT_VALUE);
                else if (strcmp(token,"STR") == 0)
                    val->setValueType(STRING_VALUE);
                else if (strcmp(token,"FLT") == 0)
                    val->setValueType(REAL_VALUE);
				else
				{
					globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"Evaluator",__FILE__,"Error input from file... unrecognized right value type... Scan Access line...");
					delete selCond;
					delete disCond;
					delete conCond;
					delete pred;
					delete val;
					return NULL;
				}

				if (pred->getLeftValue() == SCAN_LEFTVALUE_NODETAG)
					val->setValueType(INT_VALUE);

                token = strtok(NULL,",");
                if (token == NULL)
                {
					globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"Evaluator",__FILE__,"Error input from file... expecting right predicate value... Scan Access line...");
                    delete selCond;
					delete disCond;
					delete conCond;
					delete pred;
					delete val;
					return NULL;
                }

                if (val->getValueType() == INT_VALUE)
				{
					if (pred->getLeftValue() == SCAN_LEFTVALUE_NODETAG)
						val->setIntValue(dataMng->getPhysicalDataMng()->getXMLNameTable()->getCodeByName(token));
					else
						val->setIntValue(atoi(token));
				}
                else if (val->getValueType() == STRING_VALUE)
				{
					if (strcmp(token,"<EMPTY>") == 0)
						val->setStrValue("");
					else
						val->setStrValue(token);
				}
                else
                    val->setRealValue(atof(token));

                pred->setRightValue(val);

                conCond->insertCond(pred);
            }
            disCond->insertCond(conCond);
        }
        selCond->setCondition(disCond);

        // scan ranges
        token = strtok(NULL,",");
        if (token == NULL)
        {
			globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"Evaluator",__FILE__,"Error input from file... expecting number of scan ranges... Scan Access line...");
            delete selCond;
			return NULL;
        }
        int numScanRanges = atoi(token);
		ScanRange *scanRange = NULL;
		if (numScanRanges < 0)
        {
			globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"Evaluator",__FILE__,"Error input from file... number of scan ranges should be positive or 0... Scan Access line...");
            delete selCond;
			return NULL;
        } 
		else if (numScanRanges > 0)
			scanRange = new ScanRange(numScanRanges);

        for (i=0; i<numScanRanges; i++)
        {
            token = strtok(NULL,",");
            if (token == NULL)
            {
				globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"Evaluator",__FILE__,"Error input from file... expecting start pos... Scan Access line...");
                delete selCond;
				delete scanRange;
				return NULL;
            }

            ScanRangeType s;
            s.startPos = (KeyType) atof(token);
            
            token = strtok(NULL,",");
            if (token == NULL)
            {
				globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"Evaluator",__FILE__,"Error input from file... expecting end pos... Scan Access line...");
                 delete selCond;
				delete scanRange;
				return NULL;
            }
            s.endPos = (KeyType) atof(token);
            scanRange->setScanRangeAt(i, &s);
        }
       

        curr = new QueryEvaluationTreeScanAccessNode(fileName,nre,rootKey, selCond, scanRange);
    }
    break;

    case 'V': // navigational get relative
    {
        char *token = strtok(line+2,",");                    
        if (token == NULL)
        {
			globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"Evaluator",__FILE__,"Error input from file... expecting NRE... navigational get relative line...");
            return NULL;
        }
        NREType nre = (NREType)atoi(token);
			if (nre < 1)
		{
			globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"Evaluator",__FILE__,"NRE should be positive.");
            return NULL;
        }
		if (nre > maxNRE)
				maxNRE = nre;
        token = strtok(NULL,",");
        if (token == NULL)
        {
			globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"Evaluator",__FILE__,"Error input from file... expecting relation... navigational get relative line...");
            return NULL;
        }
        int relation; 

        if (strcmp(token,"1A") == 0)
            relation = N_GET_ONE_ANCS;
        else if (strcmp(token,"1C") == 0)
            relation = N_GET_ONE_CHILD;
        else if (strcmp(token,"AAO") == 0)
            relation = N_GET_ALL_ANCS_ONEBYONE;
        else if (strcmp(token,"ACO") == 0)
            relation = N_GET_ALL_CHILDREN_ONEBYONE;
        else if (strcmp(token,"ADO") == 0)
            relation = N_GET_ALL_DESC_ONEBYONE;
        else if (strcmp(token,"AAOI") == 0)
            relation = N_GET_ALL_ANCS_ONEBYONE_INCL;
        else if (strcmp(token,"ACOI") == 0)
            relation = N_GET_ALL_CHILDREN_ONEBYONE_INCL;
        else if (strcmp(token,"ADOI") == 0)
            relation = N_GET_ALL_DESC_ONEBYONE_INCL;
        else if (strcmp(token,"AAT") == 0)
            relation = N_GET_ALL_ANCS_TOGETHER;
        else if (strcmp(token,"ACT") == 0)
            relation = N_GET_ALL_CHILDREN_TOGETHER;
        else if (strcmp(token,"ADT") == 0)
            relation = N_GET_ALL_DESC_TOGETHER;
        else if (strcmp(token,"AT") == 0)
            relation = N_GET_DESC_TEXT;
        else if (strcmp(token,"CT") == 0)
            relation = N_GET_CHILD_TEXT;
        else if (strcmp(token,"DP") == 0)
            relation = N_GET_DEPTH;
        else if (strcmp(token,"A") == 0)
            relation = N_GET_ATTR;
		else
		 {
			globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"Evaluator",__FILE__,"Error input from file... unrecognized relation... navigational get relative line...");
            return NULL;
        }
        token = strtok(NULL,",");
        if (token == NULL)
        {
			globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"Evaluator",__FILE__,"Error input from file... expecting num... navigational get relative line...");
            return NULL;
        }
        int num = atoi(token);

		token = strtok(NULL,",");
		if (token == NULL)
        {
			globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"Evaluator",__FILE__,"Error input from file... expecting assigned NRE... navigational get relative line...");
            return NULL;
        }
        NREType assignedNRE = (NREType)atoi(token);
		if (assignedNRE < 1)
		{
			globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"Evaluator",__FILE__,"NRE should be positive.");
            return NULL;
        }
		if (assignedNRE > maxNRE)
				maxNRE = assignedNRE;

        char newLine[MAX_FILE_INTERFACE_LINE_SIZE];
        if (((std::iostream *)queryInput)->eof() == 0)
            ((std::iostream *)queryInput)->getline(newLine,MAX_FILE_INTERFACE_LINE_SIZE);
        else
        {
			globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"Evaluator",__FILE__,"Unexpected end of file... navigational get relative line...");
            return NULL;
        }
        QueryEvaluationTreeNode *oper = getQueryEvalNode(newLine,queryInput);
        if (oper == NULL)
        {
			globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"Evaluator",__FILE__,"Unexpected operand returned... navigational get relative line...");
            return NULL;
        }
        curr = new QueryEvaluationTreeNavigationalGetRelativeNode(oper,nre,relation,num,assignedNRE);
    }
    break;

    case 'c': // child chooser
    {
        char *token = strtok(line+2,",");                    
        if (token == NULL)
        {
			globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"Evaluator",__FILE__,"Error input from file... expecting whichChild... childChooser line...");
            return NULL;
        }
        int whichChild = atoi(token);
       
		if (whichChild == 0 || whichChild < -1)
		{
			globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"Evaluator",__FILE__,"Error input from file... whichChild should be positive or -1 (for last child)... childChooser line...");
            return NULL;
        }
        token = strtok(NULL,",");
		 if (token == NULL)
        {
			globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"Evaluator",__FILE__,"Error input from file... expecting number... childChooser line...");
            return NULL;
        }
        int num = atoi(token);
       
		if (num < 1)
		{
			globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"Evaluator",__FILE__,"Error input from file... num of parents should be at least 1)... childChooser line...");
            return NULL;
        }
		NREType *parentNRE;
		if (num > 0)
			parentNRE = new NREType[num];
		else
			parentNRE = NULL;
		for (int i=0; i<num; i++)
		{
			token = strtok(NULL,",");
			if (token == NULL)
			{
				globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"Evaluator",__FILE__,"Error input from file... expecting parentNRE... childChooser line...");
				delete [] parentNRE;
				return NULL;
			}
			parentNRE[i] = (NREType)atoi(token);
			if (parentNRE[i] < 1)
			{
				globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"Evaluator",__FILE__,"NRE should be positive.");
				delete [] parentNRE;
				return NULL;
			}
			if (parentNRE[i] > maxNRE)
				maxNRE = parentNRE[i];
		}
        char newLine[MAX_FILE_INTERFACE_LINE_SIZE];
        if (((std::iostream *)queryInput)->eof() == 0)
            ((std::iostream *)queryInput)->getline(newLine,MAX_FILE_INTERFACE_LINE_SIZE);
        else
        {
			globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"Evaluator",__FILE__,"Unexpected end of file... childChooser line...");
            if (parentNRE)
				delete [] parentNRE;
			return NULL;
        }
        QueryEvaluationTreeNode *oper = getQueryEvalNode(newLine,queryInput);
        if (oper == NULL)
        {
			globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"Evaluator",__FILE__,"Unexpected operand returned... childChooser line...");
            if (parentNRE)
				delete [] parentNRE;
			return NULL;
        }
        curr = new QueryEvaluationTreeChildChooserNode(oper,whichChild,num,parentNRE);
    }
    break;

    case 'r': // value sort
    {
        char *token = strtok(line+2,",");                    
        if (token == NULL)
        {
			globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"Evaluator",__FILE__,"Error input from file... expecting expected size... ValSort line...");
            return NULL;
        }
        int exSize = atoi(token);

		token = strtok(NULL,",");
        if (token == NULL)
        {
			globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"Evaluator",__FILE__,"Error input from file... expecting num... ValSort line...");
            return NULL;
        }
        int num = atoi(token);


		int *sortBy;
		NREType *nre;
		char **attrName;
        int *orderBy;
		int *whereEmptyGoes;
        if (num > 0)
        {
			sortBy = new int[num];
			nre = new NREType[num];
            attrName= new char *[num];
            orderBy = new int[num];
			whereEmptyGoes = new int[num];
        }
        else
        {
            sortBy = NULL;
			nre = NULL;
            attrName= NULL;
            orderBy = NULL;
			whereEmptyGoes = NULL;
			globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"Evaluator",__FILE__,"Error input from file... num needs to be at least 1... ValSort line...");
			return NULL;
        }
        for (int i=0; i<num; i++)
		{
			token = strtok(NULL,",");
			if (token == NULL)
			{
				globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"Evaluator",__FILE__,"Error input from file... expecting sort by what... ValSort line...");
				return NULL;
			}
			if (strcmp(token,"AN") == 0)
				sortBy[i] = SORTBY_ATTRIBUTE_NUM;
			else if (strcmp(token,"AS") == 0)
				sortBy[i] = SORTBY_ATTRIBUTE_STR;
			else if (strcmp(token,"TN") == 0)
				sortBy[i] = SORTBY_TEXT_NUM;
			else if (strcmp(token,"TS") == 0)
				sortBy[i] = SORTBY_TEXT_STR;
			else if (strcmp(token,"TG") == 0)
				sortBy[i] = SORTBY_TAGNAME;
			else if (strcmp(token,"VN") == 0)
				sortBy[i] = SORTBY_VALUE_NUM;
			else if (strcmp(token,"SK") == 0)
				sortBy[i] = SORT_BY_START_KEY;
			else if (strcmp(token,"VS") == 0)
				sortBy[i] = SORTBY_VALUE_STR;
			else
			{
				globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"Evaluator",__FILE__,"Error input from file... unrecognized sort by what... ValSort line...");
				delete [] sortBy;
				delete [] nre;
				for (int j=0; j<i; j++)
					if (attrName[j]) delete [] attrName[j];
				delete [] attrName;
				delete [] orderBy ;
				delete [] whereEmptyGoes;
				return NULL;
			}

			token = strtok(NULL,",");
			if (token == NULL)
			{
				globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"Evaluator",__FILE__,"Expecting NRE in ValSort line.");
				delete [] sortBy;
				delete [] nre;
				for (int j=0; j<i; j++)
					if (attrName[j]) delete [] attrName[j];
				delete [] attrName;
				delete [] orderBy ;
				delete [] whereEmptyGoes;				
				return NULL;
			}
			nre[i] = (NREType)atoi(token);

			if (nre[i] < 1)
			{
				globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"Evaluator",__FILE__,"NRE should be positive.");
				delete [] sortBy;
				delete [] nre;
				for (int j=0; j<i; j++)
					if (attrName[j]) delete [] attrName[j];
				delete [] attrName;
				delete [] orderBy ;
				delete [] whereEmptyGoes;		
				return NULL;
			}
			if (nre[i] > maxNRE)
				maxNRE = nre[i];
			token = strtok(NULL,",");
            if (token == NULL)
            {
				globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"Evaluator",__FILE__,"Error input from file... expecting orderBy... ValSort line...");
				delete [] sortBy;
				delete [] nre;
				for (int j=0; j<i; j++)
					if (attrName[j]) delete [] attrName[j];
				delete [] attrName;
				delete [] orderBy ;
				delete [] whereEmptyGoes;               
				return NULL;
            }

            if (strcmp(token,"A") == 0)
                orderBy[i] = ASCENDING;
            else if (strcmp(token,"D") == 0)
                orderBy[i] = DESCENDING;
			else
			{
				globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"Evaluator",__FILE__,"Error input from file... unrecognized order... ValSort line...");
				delete [] sortBy;
				delete [] nre;
				for (int j=0; j<i; j++)
					if (attrName[j]) delete [] attrName[j];
				delete [] attrName;
				delete [] orderBy ;
				delete [] whereEmptyGoes;
				return NULL;
			}
			token = strtok(NULL,",");
			if (token == NULL)
			{
				globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"Evaluator",__FILE__,"Error input from file... expecting attrName... ValSort line...");
				delete [] sortBy;
				delete [] nre;
				for (int j=0; j<i; j++)
					if (attrName[j]) delete [] attrName[j];
				delete [] attrName;
				delete [] orderBy ;
				delete [] whereEmptyGoes;
				return NULL;
			}
			
	/*		if (strcmp(token,"NULL") == 0)
				attrName[i] = NULL;
			else
			{*/
				attrName[i] = new char[strlen(token)+1];
				strcpy(attrName[i],token);
		//	}
			token = strtok(NULL,",");
			if (token == NULL)
			{
				globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"Evaluator",__FILE__,"Error input from file... expecting whereEmptyGoes... ValSort line...");
				delete [] sortBy;
				delete [] nre;
				for (int j=0; j<=i; j++)
					if (attrName[j]) delete [] attrName[j];
				delete [] attrName;
				delete [] orderBy ;
				delete [] whereEmptyGoes;				
				return NULL;
			}
			if (strcmp(token,"B") == 0)
				whereEmptyGoes[i] = EMPTY_AT_BEGINNING;
			else if (strcmp(token,"E") == 0)
				whereEmptyGoes[i] = EMPTY_AT_END;
			else
			{
				//FIX THIS after talking to Melanie. she outputs L instead of E for end.
				//currently, we will accept it
				whereEmptyGoes[i] = EMPTY_AT_END;
			/*	globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"Evaluator",__FILE__,"Error input from file... unrecognized where empty goes... ValSort line...");
				delete [] sortBy;
				delete [] nre;
				for (int j=0; j<i; j++)
					if (attrName[j]) delete [] attrName[j];
				delete [] attrName;
				delete [] orderBy ;
				delete [] whereEmptyGoes;
				return NULL;*/
			}
		}

		bool ext = false;
		token = strtok(NULL,",");
		if (token != NULL)
		{
			if (strcmp(token,"X") == 0)
				ext = true;
		}
        char newLine[MAX_FILE_INTERFACE_LINE_SIZE];
        if (((std::iostream *)queryInput)->eof() == 0)
            ((std::iostream *)queryInput)->getline(newLine,MAX_FILE_INTERFACE_LINE_SIZE);
        else
        {
			globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"Evaluator",__FILE__,"Unexpected end of file... valSort line...");
            delete [] sortBy;
			delete [] nre;
			for (int j=0; j<i; j++)
				if (attrName[j]) delete [] attrName[j];
			delete [] attrName;
			delete [] orderBy ;
			delete [] whereEmptyGoes;
			return NULL;
        }
        QueryEvaluationTreeNode *oper = getQueryEvalNode(newLine,queryInput);
        if (oper == NULL)
        {
			globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"Evaluator",__FILE__,"Unexpected operand returned... valSort line...");
			delete [] sortBy;
			delete [] nre;
			for (int j=0; j<i; j++)
				if (attrName[j]) delete [] attrName[j];
			delete [] attrName;
			delete [] orderBy ;
			delete [] whereEmptyGoes;
			return NULL;
        }
        curr = new QueryEvaluationTreeValueSortNode(exSize,num,sortBy,nre,attrName,orderBy, oper, whereEmptyGoes,ext);
		if (ext)
			this->fileIDsArraySize++;
    }
    break;

    case 'R': // Sort
    {
        // expected size
        char *token = strtok(line+2,",");                    
        if (token == NULL)
        {
			globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"Evaluator",__FILE__,"Error input from file... expecting expected size... Sort line...");
            return NULL;
        }
        int exSize = atoi(token);

        // sort type: by startkey or by score
        token = strtok(NULL,",");
        if (token == NULL)
        {
			globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"Evaluator",__FILE__,"Error input from file... expecting sortBy what... Sort line...");
            return NULL;
        }
        int sortByWhat;
        if (strcmp(token,"K") == 0)
            sortByWhat = SORT_BY_START_KEY;
        else if (strcmp(token,"T") == 0)
			sortByWhat = SORT_BY_TREE;
		else if (strcmp(token,"S") == 0)
            sortByWhat = SORT_BY_SCORE;
		else
		{
			globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"Evaluator",__FILE__,"Error input from file... unrecognized sortBy what... Sort line...");
            return NULL;
        }
        // instantiate sort conditions
        int num;
        NREType *sortBy;
        int *order;
		int *whereEmptyGoes ;
        if (sortByWhat == SORT_BY_START_KEY)
        {
            // number of nodes to sort
            token = strtok(NULL,",");
            if (token == NULL)
            {
				globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"Evaluator",__FILE__,"Error input from file... expecting size of sort array... Sort line...");
                return NULL;
            }
            num = atoi(token);
                
            if (num > 0)
			{
                sortBy = new NREType[num];
                order = new int[num];
				whereEmptyGoes = new int[num];
            }
			else
            {
                sortBy = NULL;
                order = NULL;
				whereEmptyGoes = NULL;
				globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"Evaluator",__FILE__,"Error input from file... num should be at least 1... Sort line...");
                return NULL;
            }
            
            for (int i=0; i<num; i++)
            {
                token = strtok(NULL,",");
                if (token == NULL)
                {
					globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"Evaluator",__FILE__,"Error input from file... expecting nre... Sort line...");
                    delete [] sortBy;
					delete [] order;
					delete [] whereEmptyGoes;
					return NULL;
                }
                sortBy[i] = (NREType)atoi(token);
				if (sortBy[i] < 1)
				{
					globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"Evaluator",__FILE__,"NRE should be positive.");
					delete [] sortBy;
					delete [] order;
					delete [] whereEmptyGoes;
					return NULL;
				}
				if (sortBy[i] > maxNRE)
					maxNRE = sortBy[i];
                token = strtok(NULL,",");
                if (token == NULL)
                {
					globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"Evaluator",__FILE__,"Error input from file... expecting A or D... Sort line...");
                    delete [] sortBy;
					delete [] order;
					delete [] whereEmptyGoes;
					return NULL;
                }
				if (strcmp(token,"A") == 0)
					order[i] = ASCENDING;
				else if (strcmp(token,"D") == 0)
					order[i] = DESCENDING;
				else
				{
					globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"Evaluator",__FILE__,"Error input from file... unrecognized order... Sort line...");
					delete [] sortBy;
					delete [] order;
					delete [] whereEmptyGoes;
					return NULL;
				}
				token = strtok(NULL,",");
				if (token == NULL)
				{
					globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"Evaluator",__FILE__,"Error input from file... expecting whereEmptyGoes... Sort line...");
                    delete [] sortBy;
					delete [] order;
					delete [] whereEmptyGoes;					
					return NULL;
				}
				if (strcmp(token,"B") == 0)
					whereEmptyGoes[i] = EMPTY_AT_BEGINNING;
				else if (strcmp(token,"E") == 0)
					whereEmptyGoes[i] = EMPTY_AT_END;
				else
				{
					//FIX THIS after talking to Melanie. she outputs L instead of E for end.
					//currently, we will accept it
					whereEmptyGoes[i] = EMPTY_AT_END;
				/*	globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"Evaluator",__FILE__,"Error input from file... unrecognized where empty goes... Sort line...");
					delete [] sortBy;
					delete [] order;
					delete [] whereEmptyGoes;		
					return NULL;*/
				}
        }

		}
        else // sort by score or tree
        {
            sortBy = NULL;
            order = NULL;
			whereEmptyGoes = NULL;

            // ascending or descending
            token = strtok(NULL,",");
            if (token == NULL)
            {
				globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"Evaluator",__FILE__,"Error input from file... expecting A or D... Sort line...");
                return NULL;
            }

			if (strcmp(token,"A") == 0)
				num = ASCENDING;
			else if (strcmp(token,"D") == 0)
				num = DESCENDING;
			else
			{
				globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"Evaluator",__FILE__,"Error input from file... unrecognized order... Sort line...");
				return NULL;
			}
		}

		bool ext = false;
		token = strtok(NULL,",");
		if (token != NULL)
		{
			if (strcmp(token,"X") == 0)
				ext = true;
		}
		
		
        char newLine[MAX_FILE_INTERFACE_LINE_SIZE];
        if (((std::iostream *)queryInput)->eof() == 0)
            ((std::iostream *)queryInput)->getline(newLine,MAX_FILE_INTERFACE_LINE_SIZE);
        else
        {
			globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"Evaluator",__FILE__,"Unexpected end of file... Sort line...");
			if (sortBy) delete [] sortBy;
			if (order) delete [] order;
			if (whereEmptyGoes) delete [] whereEmptyGoes;		            
			return NULL;
        }
        QueryEvaluationTreeNode *oper = getQueryEvalNode(newLine,queryInput);
        if (oper == NULL)
        {
			globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"Evaluator",__FILE__,"Unexpected operand returned... Sort line...");
			if (sortBy) delete [] sortBy;
			if (order) delete [] order;
			if (whereEmptyGoes) delete [] whereEmptyGoes;	 
			return NULL;
        }
        curr = new QueryEvaluationTreeSortNode(oper,num,sortBy,order, exSize, sortByWhat,whereEmptyGoes ,ext);
		if (ext)
			this->fileIDsArraySize++;
    }
    break;

    case 'f': // filter
    {
        char newLine[MAX_FILE_INTERFACE_LINE_SIZE];
        char origline[MAX_FILE_INTERFACE_LINE_SIZE];
        strcpy(origline,line+2);
        int readNum = 0;
        char *token = strtok(line+2,",");
        if (token == NULL)
        {
			globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"Evaluator",__FILE__,"Error input from file... expecting number of disjunctive conditions... Filter line...");
            return NULL;
        }
        
        int num1 = atoi(token);
        
        readNum += strlen(token)+1;
        FilterCondition *filtCond;
        if (num1 >0)
            filtCond = new FilterCondition[num1]; 
		else 
		{
			filtCond = NULL;
			globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"Evaluator",__FILE__,"Error input from file... number of disjunctive conditions should be at least 1... Filter line...");
            return NULL;
		}
        bool startOver = false;
        for (int i=0; i<num1; i++)
        {
            if (startOver)
            {
                token = strtok(line,",");
                startOver = false;
            }
            else
                token = strtok(NULL,",");
            if (token == NULL)
            {
				globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"Evaluator",__FILE__,"Error input from file... expecting number of conjunctive conditions in disjunctive... Filter line...");
                return NULL;
            }
            int num2 = atoi(token);
            readNum += strlen(token)+1;
			if (num2 <= 0) 
			{
				delete [] filtCond;
				globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"Evaluator",__FILE__,"Error input from file... number of conjunctive conditions should be at least 1... Filter line...");
				return NULL;
			}
			filtCond[i].setMaxSize(num2);
            for (int j=0; j<num2; j++)
            {
                int leftType, rightType,  opr, application;
				NREType nreLeft, nreRight;
                float numLeft, numRight;
                char *strLeft = NULL;
                char *strRight = NULL;
                if (startOver)
                {
                    token = strtok(line,",");
                    startOver = false;
                }
                else
                    token = strtok(NULL,",");
				if (token == NULL)
                {
					delete [] filtCond;
					globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"Evaluator",__FILE__,"Error input from file... expecting application in predicate... Filter line...");
                    return NULL;
                }
				readNum += strlen(token)+1;
				if (strcmp(token,"E") == 0)
					application = FILTER_APP_EVERY;
				else if (strcmp(token,"AO") == 0)
					application = FILTER_APP_AT_LEAST_ONE;
				else if (strcmp(token,"EO") == 0)
					application = FILTER_APP_EXACTLY_ONE;
				else if (strcmp(token,"EX") == 0)
					application = FILTER_APP_EXACTLY_ONE_EXISTS;
				else
				{
					delete [] filtCond;
					globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"Evaluator",__FILE__,"Error input from file... unrecognized application... Filter line...");
                    return NULL;
				}
			
				token = strtok(NULL,",");
                if (token == NULL)
                {
					delete [] filtCond;
					globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"Evaluator",__FILE__,"Error input from file... expecting leftType in predicate... Filter line...");
                    return NULL;
                }
                
                readNum += strlen(token)+1;
                
                if (strcmp(token,"V") == 0)
                    leftType = FILTER_VALUE;
                else if (strcmp(token,"A") == 0)
                    leftType = FILTER_ATTR_VALUE;
                else if (strcmp(token,"T") == 0)
                    leftType = FILTER_TEXT;
				else if (strcmp(token,"DT") == 0)
                    leftType = FILTER_DESC_TEXT;
                else if (strcmp(token,"L") == 0)
                    leftType = FILTER_LENGTH;
                else if (strcmp(token,"LCV") == 0)
                    leftType = FILTER_LOCALCHILD_VALUE;
                else if (strcmp(token,"LCA") == 0)
                    leftType = FILTER_LOCALCHILD_ATTR_VAL;
                else if (strcmp(token,"LCT") == 0)
                    leftType = FILTER_LOCALCHILD_TEXT;
				else if (strcmp(token,"LCDT") == 0)
                    leftType = FILTER_LOCALCHILD_DESC_TEXT;
                else if (strcmp(token,"LCL") == 0)
                    leftType = FILTER_LOCALCHILD_LENGTH;
                else if (strcmp(token,"ACV") == 0)
                    leftType = FILTER_ACTUALCHILD_VALUE;
                else if (strcmp(token,"ACA") == 0)
                    leftType = FILTER_ACTUALCHILD_ATTR_VAL;
                else if (strcmp(token,"ACT") == 0)
                    leftType = FILTER_ACTUALCHILD_TEXT;
				else if (strcmp(token,"ACDT") == 0)
                    leftType = FILTER_ACTUALCHILD_DESC_TEXT;
                else if (strcmp(token,"ACL") == 0)
                    leftType = FILTER_ACTUALCHILD_LENGTH;
                else if (strcmp(token,"LAV") == 0)
                    leftType = FILTER_LOCALANCS_VALUE;
                else if (strcmp(token,"LAA") == 0)
                    leftType = FILTER_LOCALANCS_ATTR_VAL;
                else if (strcmp(token,"LAT") == 0)
                    leftType = FILTER_LOCALANCS_TEXT;
				else if (strcmp(token,"LADT") == 0)
                    leftType = FILTER_LOCALANCS_DESC_TEXT;
                else if (strcmp(token,"LAL") == 0)
                    leftType = FILTER_LOCALANCS_LENGTH;
                else if (strcmp(token,"AAV") == 0)
                    leftType = FILTER_ACTUALANCS_VALUE;
                else if (strcmp(token,"AAA") == 0)
                    leftType = FILTER_ACTUALANCS_ATTR_VAL;
                else if (strcmp(token,"AAT") == 0)
                    leftType = FILTER_ACTUALANCS_TEXT;
				else if (strcmp(token,"AADT") == 0)
                    leftType = FILTER_ACTUALANCS_DESC_TEXT;
                else if (strcmp(token,"AAL") == 0)
                    leftType = FILTER_ACTUALANCS_LENGTH;
                else if (strcmp(token,"C") == 0)
                    leftType = FILTER_CONST;
                else if (strcmp(token,"CI") == 0)
                    leftType = FILTER_CONST_FROM_ITER;
                else if (strcmp(token,"LF") == 0)
                    leftType = FILTER_LOCAL_FANOUT;
                else if (strcmp(token,"AF") == 0)
                    leftType = FILTER_ACTUAL_FANOUT;
                else if (strcmp(token,"LD") == 0)
                    leftType = FILTER_LOCALSUBTREE_DEPTH;
                else if (strcmp(token,"AD") == 0)
                    leftType = FILTER_ACTUALSUBTREE_DEPTH;    
                else if (strcmp(token,"SK") == 0)
                    leftType = FILTER_STARTKEY;
                else if (strcmp(token,"EK") == 0)
                    leftType = FILTER_ENDKEY;
                else if (strcmp(token,"LEV") == 0)
                    leftType = FILTER_LEVEL;
				else
				{
					delete [] filtCond;
					globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"Evaluator",__FILE__,"Error input from file... unrecognized left type... Filter line...");
                    return NULL;
				}

                token = strtok(NULL,",");
                if (token == NULL)
                {
					delete [] filtCond;
					globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"Evaluator",__FILE__,"Error input from file... expecting leftnre in predicate... Filter line...");
					return NULL;
                }

                nreLeft = (NREType)atoi(token);
				if (nreLeft > maxNRE)
					maxNRE = nreLeft;
                readNum += strlen(token)+1;

                token = strtok(NULL,",");
                if (token == NULL)
                {
					delete [] filtCond;
					globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"Evaluator",__FILE__,"Error input from file... expecting left num in predicate... Filter line...");
                    return NULL;
                }
                readNum += strlen(token) +1;

                numLeft = (float) atof(token);

                token = strtok(NULL,",");
                if (token == NULL)
                {
					delete [] filtCond;
					globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"Evaluator",__FILE__,"Error input from file... expecting left str in predicate... Filter line...");
                    return NULL;
                }
                readNum += strlen(token) +1;

				if (strcmp(token,"<EMPTY>") == 0)
				{
					strLeft = new char[1];
					strcpy(strLeft,"");
				}
				else
				{
					strLeft = new char[strlen(token)+1];
					strcpy(strLeft,token);
				}
                QueryEvaluationTreeNode *leftOper;
                IteratorClass *leftIter= NULL;
                if (leftType == FILTER_CONST_FROM_ITER)
                {
                    char l[MAX_FILE_INTERFACE_LINE_SIZE];
                    if ((int)strlen(origline) < readNum)
						l[0] = '\0';
					else
						strcpy(l,origline+readNum);
                    ((std::iostream *)queryInput)->getline(newLine,MAX_FILE_INTERFACE_LINE_SIZE);
                    if (((std::iostream *)queryInput)->eof() != 0)
                    {
						delete [] filtCond;
						delete [] strLeft;
						globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"Evaluator",__FILE__,"Unexpected end of file... filter line...");
                        return NULL;
                    }
                    leftOper = getQueryEvalNode(newLine,queryInput);
                    leftIter = processQueryEvalNode(leftOper);
					delete leftOper;
                    strcpy(line,l);
                    readNum = 0;
                    token = strtok(line,",");
                
                }
                else
                {
                    leftIter = NULL;
                    token = strtok(NULL,",");
                }

                //        token = strtok(NULL,",");
                if (token == NULL)
                {
					delete [] strLeft;
					delete [] filtCond;
					globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"Evaluator",__FILE__,"Expecting operation in Filter Line.");
                    return NULL;
                }

                readNum += strlen(token) +1;

                if (strcmp(token,"EQN") == 0)
                    opr = FILTER_EQ_NUM;
                else if (strcmp(token,"NEN") == 0)
                    opr = FILTER_NE_NUM;
                else if (strcmp(token,"LTN") == 0)
                    opr = FILTER_LT_NUM;
                else if (strcmp(token,"LEN") == 0)
                    opr = FILTER_LE_NUM;
                else if (strcmp(token,"GTN") == 0)
                    opr = FILTER_GT_NUM;
                else if (strcmp(token,"GEN") == 0)
                    opr = FILTER_GE_NUM;
                else if (strcmp(token,"EQS") == 0)
                    opr = FILTER_EQ_STR;
                else if (strcmp(token,"NES") == 0)
                    opr = FILTER_NE_STR;
                else if (strcmp(token,"LTS") == 0)
                    opr = FILTER_LT_STR;
                else if (strcmp(token,"LES") == 0)
                    opr = FILTER_LE_STR;
                else if (strcmp(token,"GTS") == 0)
                    opr = FILTER_GT_STR;
                else if (strcmp(token,"GES") == 0)
                    opr = FILTER_GE_STR; 
                else if (strcmp(token,"S") == 0)
                    opr = FILTER_STARTS_WITH;
                else if (strcmp(token,"B") == 0)
                    opr = FILTER_IN_BEGINING;
                else if (strcmp(token,"C") == 0)
                    opr = FILTER_CONTAINS;
                else if (strcmp(token,"D") == 0)
                    opr = FILTER_CONTAINED; 
                else if (strcmp(token,"NS") == 0)
					opr = FILTER_NOT_START_WITH;
				else if (strcmp(token,"NC") == 0)
					opr = FILTER_NOT_CONTAIN;
				else if (strcmp(token,"CO") == 0)
                    opr = FILTER_CONTAINS_WITH_OFFSET;
                else
				{
					delete [] filtCond;
					delete [] strLeft;
					globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"Evaluator",__FILE__,"Error input from file... unrecognized operation... Filter line...");
                    return NULL;
				}        

                token = strtok(NULL,",");
                if (token == NULL)
                {
					delete [] filtCond;
					delete [] strLeft;
					globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"Evaluator",__FILE__,"Expecting right type in filter Line.");
                    return NULL;
                }
                readNum += strlen(token) +1;

                    
                if (strcmp(token,"V") == 0)
                    rightType = FILTER_VALUE;
                else if (strcmp(token,"A") == 0)
                    rightType = FILTER_ATTR_VALUE;
                else if (strcmp(token,"T") == 0)
                    rightType = FILTER_TEXT;
				else if (strcmp(token,"DT") == 0)
                    rightType = FILTER_DESC_TEXT;
                else if (strcmp(token,"L") == 0)
                    rightType = FILTER_LENGTH;
                else if (strcmp(token,"LCV") == 0)
                    rightType = FILTER_LOCALCHILD_VALUE;
                else if (strcmp(token,"LCA") == 0)
                    rightType = FILTER_LOCALCHILD_ATTR_VAL;
                else if (strcmp(token,"LCT") == 0)
                    rightType = FILTER_LOCALCHILD_TEXT;
				else if (strcmp(token,"LCDT") == 0)
                    rightType = FILTER_LOCALCHILD_DESC_TEXT;
                else if (strcmp(token,"LCL") == 0)
                    rightType = FILTER_LOCALCHILD_LENGTH;
                else if (strcmp(token,"ACV") == 0)
                    rightType = FILTER_ACTUALCHILD_VALUE;
                else if (strcmp(token,"ACA") == 0)
                    rightType = FILTER_ACTUALCHILD_ATTR_VAL;
                else if (strcmp(token,"ACT") == 0)
                    rightType = FILTER_ACTUALCHILD_TEXT;
				else if (strcmp(token,"ACDT") == 0)
                    rightType = FILTER_ACTUALCHILD_DESC_TEXT;
                else if (strcmp(token,"ACL") == 0)
                    rightType = FILTER_ACTUALCHILD_LENGTH;
                else if (strcmp(token,"LAV") == 0)
                    rightType = FILTER_LOCALANCS_VALUE;
                else if (strcmp(token,"LAA") == 0)
                    rightType = FILTER_LOCALANCS_ATTR_VAL;
                else if (strcmp(token,"LAT") == 0)
                    rightType = FILTER_LOCALANCS_TEXT;
				else if (strcmp(token,"LADT") == 0)
                    rightType = FILTER_LOCALANCS_DESC_TEXT;
                else if (strcmp(token,"LAL") == 0)
                    rightType = FILTER_LOCALANCS_LENGTH;
                else if (strcmp(token,"AAV") == 0)
                    rightType = FILTER_ACTUALANCS_VALUE;
                else if (strcmp(token,"AAA") == 0)
                    rightType = FILTER_ACTUALANCS_ATTR_VAL;
                else if (strcmp(token,"AAT") == 0)
                    rightType = FILTER_ACTUALANCS_TEXT;
				 else if (strcmp(token,"AADT") == 0)
                    rightType = FILTER_ACTUALANCS_DESC_TEXT;
                else if (strcmp(token,"AAL") == 0)
                    rightType = FILTER_ACTUALANCS_LENGTH;
                else if (strcmp(token,"C") == 0)
                    rightType = FILTER_CONST;
                else if (strcmp(token,"CI") == 0)
                    rightType = FILTER_CONST_FROM_ITER;
                else if (strcmp(token,"LF") == 0)
                    rightType = FILTER_LOCAL_FANOUT;
                else if (strcmp(token,"AF") == 0)
                    rightType = FILTER_ACTUAL_FANOUT;
                else if (strcmp(token,"LD") == 0)
                    rightType = FILTER_LOCALSUBTREE_DEPTH;
                else if (strcmp(token,"AD") == 0)
                    rightType = FILTER_ACTUALSUBTREE_DEPTH;    
                else if (strcmp(token,"SK") == 0)
                    rightType = FILTER_STARTKEY;
                else if (strcmp(token,"EK") == 0)
                    rightType = FILTER_ENDKEY;
                else if (strcmp(token,"LEV") == 0)
                    rightType = FILTER_LEVEL;
				else
				{
					delete [] filtCond;
					delete [] strLeft;
					globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"Evaluator",__FILE__,"Error input from file... unrecognized right type... Filter line...");
                    return NULL;
				}        

                token = strtok(NULL,",");
                if (token == NULL)
                {
					delete [] filtCond;
					delete [] strLeft;
					globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"Evaluator",__FILE__,"Expecting right NRE in filter Line.");
                    return NULL;
                }

                nreRight = (NREType)atoi(token);
				if (nreRight > maxNRE)
					maxNRE = nreRight;
                readNum += strlen(token) +1;

                token = strtok(NULL,",");
                if (token == NULL)
                {
					delete [] filtCond;
					delete [] strLeft;
					globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"Evaluator",__FILE__,"Expecting right num in filter Line.");
                    return NULL;
                }
                readNum += strlen(token) +1;

                numRight = (float) atof(token);

                token = strtok(NULL,",");
                if (token == NULL)
                {
					delete [] filtCond;
					delete [] strLeft;
					globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"Evaluator",__FILE__,"Expecting right str in filter Line.");
                    return NULL;
                }
                readNum += strlen(token) +1;

				if (strcmp(token,"<EMPTY>") == 0)
				{
					strRight = new char[1];
					strcpy(strRight,"");
				}
				else
				{
					strRight = new char[strlen(token)+1];
					strcpy(strRight,token);
				}

				token = strtok(NULL,",");
				char *indexName = NULL;
				char *fileName = NULL;
				if (token == NULL)
				{
					delete [] filtCond;
					delete [] strLeft;
					delete [] strRight;
					globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"Evaluator",__FILE__,"Expecting join index name or NULL in filter Line.");
					return NULL;
				}
				if (strcmp(token,"NULL") != 0)
				{
					indexName = new char[strlen(token)+1];
					strcpy(indexName,token);
				}

				token = strtok(NULL,",");
				if (token == NULL)
				{
					delete [] filtCond;
					delete [] strLeft;
					delete [] strRight;
					if (indexName) delete [] indexName;
					globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"Evaluator",__FILE__,"Expecting xml file name or NULL in filter Line.");
					return NULL;
				}
				if (strcmp(token,"NULL") != 0)
				{
					fileName = new char[strlen(token)+1];
					strcpy(fileName,token);
				}
				else if (indexName != NULL)
				{
					delete [] filtCond;
					delete [] strLeft;
					delete [] strRight;
					globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"Evaluator",__FILE__,"Expecting xml file name or NULL in filter Line. you specified index name, then you have to specify file name. both NULL or both there.");
					return NULL;
				}

                QueryEvaluationTreeNode *rightOper;
                IteratorClass *rightIter;
                if (rightType == FILTER_CONST_FROM_ITER)
                {
                    char l[MAX_FILE_INTERFACE_LINE_SIZE];
					if ((int)strlen(origline) < readNum)
						l[0] = '\0';
					else
						strcpy(l,origline+readNum);
                    ((std::iostream *)queryInput)->getline(newLine,MAX_FILE_INTERFACE_LINE_SIZE);
                    if (((std::iostream *)queryInput)->eof() != 0)
                    {
						delete [] filtCond;
						delete [] strLeft;
						delete [] strRight;
						if (indexName) delete [] indexName;
						if (fileName) delete [] fileName;
						globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"Evaluator",__FILE__,"Unexpected end of file... filter line...");
                        return NULL;
                    }
                    rightOper = getQueryEvalNode(newLine,queryInput);
                    rightIter = processQueryEvalNode(rightOper);
					delete rightOper;
                    strcpy(line,l);
                    readNum = 0;
                    startOver = true;
                }
                else
                    rightIter = NULL;
    
                if (leftType != FILTER_CONST_FROM_ITER)
                    leftIter = NULL;
                filtCond[i].InsertCondition(application,leftType,nreLeft,numLeft,strLeft,leftIter,opr,rightType,nreRight,numRight,strRight,rightIter,indexName,fileName,-1);
            }
                
        }

        if (((std::iostream *)queryInput)->eof() == 0)
            ((std::iostream *)queryInput)->getline(newLine,MAX_FILE_INTERFACE_LINE_SIZE);
        else
        {
			delete [] filtCond;
			globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"Evaluator",__FILE__,"Unexpected end of file... filter line...");
            return NULL;
        }
        QueryEvaluationTreeNode *oper = getQueryEvalNode(newLine,queryInput);
		if (oper == NULL)
        {
			delete [] filtCond;
			globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"Evaluator",__FILE__,"Unexpected operand returned... Filter line...");
            return NULL;
        }
        curr = new QueryEvaluationTreeSelectionNode(filtCond,num1,oper);
    }
    break;

    case 'J': // structural join
    {
        // which algorithm
        char *token = strtok(line+2,",");
        if (token == NULL)
        {
			globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"Evaluator",__FILE__,"Error input from file... expecting Algorithm... SJoin line...");
            return NULL;
        }
        curr = new QueryEvaluationTreeStructuralJoinNode();
        if (strcmp(token,"A") == 0)
            ((QueryEvaluationTreeStructuralJoinNode *)curr)->setAlgorithmChoice(JOIN_ALGORITHM_STACK_ANCS);
        else if (strcmp(token,"D") == 0)
            ((QueryEvaluationTreeStructuralJoinNode *)curr)->setAlgorithmChoice(JOIN_ALGORITHM_STACK_DESC);
        else if (strcmp(token,"N") == 0)
            ((QueryEvaluationTreeStructuralJoinNode *)curr)->setAlgorithmChoice(JOIN_ALGORITHM_STACK_NEGATIVE);
        else if (strcmp(token,"a") == 0)
            ((QueryEvaluationTreeStructuralJoinNode *)curr)->setAlgorithmChoice(JOIN_ALGORITHM_STACK_OUTERANCS);
        else
            //((QueryEvaluationTreeStructuralJoinNode *)curr)->setAlgorithmChoice(JOIN_ALGORITHM_STACK_OUTERDESC);
		{
			globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"Evaluator",__FILE__,"Unexpected algorithm... SJoin line...");
            delete curr;
			return NULL;
		}

        // ancestor position
        token = strtok(NULL,",");
        if (token == NULL)
        {
			globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"Evaluator",__FILE__,"Error input from file... expecting Ancestor NRE... SJoin line...");
			delete curr;           
			return NULL;
        }
		NREType ancsNRE = (NREType) atoi(token);
		if (ancsNRE < 1)
		{
			globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"Evaluator",__FILE__,"NRE should be positive.");
			delete curr;
			return NULL;
		}
        ((QueryEvaluationTreeStructuralJoinNode *)curr)->setAncsNRE(ancsNRE);
		if (ancsNRE > maxNRE)
				maxNRE = ancsNRE;

        // descendent position
        token = strtok(NULL,",");
        if (token == NULL)
        {
			globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"Evaluator",__FILE__,"Error input from file... expecting Desc NRE... SJoin line...");
            delete curr;
			return NULL;
        }
		NREType descNRE = (NREType) atoi(token);
			if (descNRE < 1)
		{
			globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"Evaluator",__FILE__,"NRE should be positive.");
			delete curr;
			return NULL;
		}
        ((QueryEvaluationTreeStructuralJoinNode *)curr)->setDescNRE(descNRE);
		if (descNRE > maxNRE)
				maxNRE = descNRE;
        // left sibling position: -1
        token = strtok(NULL,",");
        if (token == NULL)
        {
			globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"Evaluator",__FILE__,"Error input from file... expecting Left Sibling NRE... SJoin line...");
            delete curr;
			return NULL;
        }
		int leftNRE = atoi(token);
		if (leftNRE > maxNRE)
				maxNRE = leftNRE;
		if (leftNRE == -1)
			leftNRE =  NULL_NRE;
        ((QueryEvaluationTreeStructuralJoinNode *)curr)->setLeftNRE((NREType)leftNRE);
		

        // right sibling position: -1
        token = strtok(NULL,",");
        if (token == NULL)
        {
			globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"Evaluator",__FILE__,"Error input from file... expecting Right Sibling NRE... SJoin line...");
			delete curr;           
			return NULL;
        }
		int rightNRE = atoi(token);
		if (rightNRE > maxNRE)
				maxNRE = rightNRE;
		if (rightNRE == -1)
			rightNRE = NULL_NRE;
        ((QueryEvaluationTreeStructuralJoinNode *)curr)->setRightNRE((NREType)rightNRE);
		

        if (leftNRE == NULL_NRE && rightNRE == NULL_NRE)
            ((QueryEvaluationTreeStructuralJoinNode *)curr)->setOrderingSemantics(false);

        // expected depth: -1
        token = strtok(NULL,",");
        if (token == NULL)
        {
			globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"Evaluator",__FILE__,"Error input from file... expecting Expected Depth... SJoin line...");
            delete curr;
			return NULL;
        }
        int depth = atoi(token);
   
        ((QueryEvaluationTreeStructuralJoinNode *)curr)->setEstimatedDepth(depth);

        // relationship: ancs-desc or parent-child
        token = strtok(NULL,",");
        if (token == NULL)
        {
			globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"Evaluator",__FILE__,"Error input from file... expecting Relationship... SJoin line...");
            delete curr;
			return NULL;
        }
        if (strcmp(token,"A") == 0)
            ((QueryEvaluationTreeStructuralJoinNode *)curr)->setRelationship(JOIN_NODE_RELATION_DESCENDANT);
        else if (strcmp(token,"P") == 0)
            ((QueryEvaluationTreeStructuralJoinNode *)curr)->setRelationship(JOIN_NODE_RELATION_CHILD);
		else
		{
			globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"Evaluator",__FILE__,"Unrecognized relation... SJoin line...");
            delete curr;
			return NULL;
		}
	
        // keep which
        token = strtok(NULL,",");
        if (token == NULL)
        {
			globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"Evaluator",__FILE__,"Error input from file... expecting ProjectWhich... SJoin line...");
            delete curr;
			return NULL;
        }
        if (strcmp(token,"A") == 0)
		{
            ((QueryEvaluationTreeStructuralJoinNode *)curr)->setProjectWhich(ANCESTOR);
			if (((QueryEvaluationTreeStructuralJoinNode *)curr)->getAlgorithmChoice() != JOIN_ALGORITHM_STACK_ANCS)
			{
				globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"Evaluator",__FILE__,"Error input from file... Cannot project ancs unless using stack based ancs algorithm... SJoin line...");
				delete curr;
				return NULL;
			}
		}
        else if (strcmp(token,"D") == 0)
		{
            ((QueryEvaluationTreeStructuralJoinNode *)curr)->setProjectWhich(DESCENDANT);
			if (((QueryEvaluationTreeStructuralJoinNode *)curr)->getAlgorithmChoice() != JOIN_ALGORITHM_STACK_DESC)
			{
				globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"Evaluator",__FILE__,"Error input from file... Cannot project desc unless using stack based desc algorithm... SJoin line...");
				delete curr;
				return NULL;
			}
		}
        else if (strcmp(token,"B") == 0)
            ((QueryEvaluationTreeStructuralJoinNode *)curr)->setProjectWhich(BOTH);
        else
		{
			globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"Evaluator",__FILE__,"Unrecognized project which... SJoin line...");
            delete curr;
			return NULL;
		}

		token = strtok(NULL,",");
		bool nest = false;
        if (token != NULL)
        {
			if (strcmp(token,"N") == 0)
				nest = true;
        }
		((QueryEvaluationTreeStructuralJoinNode *)curr)->setNest(nest);

        // grab the ansc node
        char newLine[MAX_FILE_INTERFACE_LINE_SIZE];
        if (((std::iostream *)queryInput)->eof() == 0)
            ((std::iostream *)queryInput)->getline(newLine,MAX_FILE_INTERFACE_LINE_SIZE);
        else
        {
			globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"Evaluator",__FILE__,"Unexpected end of file... Sjoin line...");
            delete curr;
			return NULL;
        }
        QueryEvaluationTreeNode *ancs = getQueryEvalNode(newLine,queryInput);
        if (ancs == NULL)
        {
			globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"Evaluator",__FILE__,"Unexpected ancs returned... Sjoin line...");
            delete curr;
			return NULL;
        }

        // grab the desc node
        if (((std::iostream *)queryInput)->eof() == 0)
            ((std::iostream *)queryInput)->getline(newLine,MAX_FILE_INTERFACE_LINE_SIZE);
        else
        {
			globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"Evaluator",__FILE__,"Unexpected end of file... Sjoin line...");
            delete curr;
			delete ancs;
			return NULL;
        }
        QueryEvaluationTreeNode *desc = getQueryEvalNode(newLine,queryInput);
        if (desc == NULL)
        {
			globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"Evaluator",__FILE__,"Unexpected desc returned... Sjoin line...");
            delete curr;
			delete ancs;
			return NULL;
        }
        ((QueryEvaluationTreeStructuralJoinNode *)curr)->setAncestor(ancs);
        ((QueryEvaluationTreeStructuralJoinNode *)curr)->setDescendant(desc);
		this->fileIDsArraySize++;
    }
    break;

 

    case 'T': // set operations
    {
        int which;
        int length = -1;

        // types of set operation
        char *token = strtok(line+2,",");                    
        if (token == NULL)
        {
			globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"Evaluator",__FILE__,"Error input from file... expecting which set operation... Set operations line...");
            return NULL;
        }
        if (strcmp(token,"U") == 0)
            which = UNION_OPERATOR;
        else if (strcmp(token,"I") == 0)
            which = INTERSECTION_OPERATOR;
        else if (strcmp(token,"D") == 0)
            which = DIFFERENCE_OPERATOR;
		else
		{
			globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"Evaluator",__FILE__,"Error input from file... unrecognized set operation... Set operations line...");
            return NULL;
        }


        // length
        token = strtok(NULL,",");
        if (token == NULL)
            length = -1;
        else
		{
            length = atoi(token);
          
			if (length <= 0)
			{
				globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"Evaluator",__FILE__,"Error input from file... length should be positive... Set operations line...");
				return NULL;
			}
		}
        // grab the set operands
        char newLine[MAX_FILE_INTERFACE_LINE_SIZE];
        if (((std::iostream *)queryInput)->eof() == 0)
            ((std::iostream *)queryInput)->getline(newLine,MAX_FILE_INTERFACE_LINE_SIZE);
        else
        {
			globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"Evaluator",__FILE__,"Unexpected end of file... set op line...");
            return NULL;
        }
        QueryEvaluationTreeNode *oper1 = getQueryEvalNode(newLine,queryInput);
        if (oper1 == NULL)
        {
			globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"Evaluator",__FILE__,"Unexpected operand1 returned... set op line...");
            return NULL;
        }
        if (((std::iostream *)queryInput)->eof() == 0)
            ((std::iostream *)queryInput)->getline(newLine,MAX_FILE_INTERFACE_LINE_SIZE);
        else
        {
			globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"Evaluator",__FILE__,"Unexpected end of file... set op line...");
            delete oper1;
			return NULL;
        }
        QueryEvaluationTreeNode *oper2 = getQueryEvalNode(newLine,queryInput);
        if (oper2 == NULL)
        {
			globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"Evaluator",__FILE__,"Unexpected operand2 returned... set op line...");
            delete oper1;
			return NULL;
        }
        curr = new QueryEvaluationTreeSetOperationsNode(oper1,oper2,which, length);
    }
    break;

    case 'P': // Projections
    {
        char *token = strtok(line+2,",");                    
        if (token == NULL)
        {
			globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"Evaluator",__FILE__,"Error input from file... expecting list length... projection line...");
            return NULL;
        }
        int num = atoi(token);    

        NREType *nre;
        if (num <= 0)
		{
            nre = NULL;
			globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"Evaluator",__FILE__,"Error input from file... list length should be positive... projection line...");
			return NULL;
		}
        else
            nre = new NREType[num];

        for (int i=0; i<num; i++)
        {
            token = strtok(NULL,",");
            if (token == NULL)
            {
				globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"Evaluator",__FILE__,"Error input from file... expecting an nre... projection line...");
                delete [] nre;
				return NULL;
            }
			nre[i] = atoi(token);
			if (nre[i] < 1)
			{
				globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"Evaluator",__FILE__,"NRE should be positive.");
				return NULL;
			}
			if (nre[i] > maxNRE)
				maxNRE = nre[i];

        }
		token = strtok(NULL,",");
        if (token == NULL)
        {
			globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"Evaluator",__FILE__,"Error input from file... expecting preserve node order bool... projection line...");
            delete nre;
			return NULL;
        }
		if (atoi(token) != 0 && atoi(token) != 1)
		{
			globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"Evaluator",__FILE__,"Error input from file... preserve node order should be 0 or 1... projection line...");
            delete nre;
			return NULL;
		}
        bool preserveNodeOrder = (bool) atoi(token);

        char newLine[MAX_FILE_INTERFACE_LINE_SIZE];
        if (((std::iostream *)queryInput)->eof() == 0)
            ((std::iostream *)queryInput)->getline(newLine,MAX_FILE_INTERFACE_LINE_SIZE);
        else
        {
			globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"Evaluator",__FILE__,"Unexpected end of file... projection line...");
            delete nre;
			return NULL;
        }
        QueryEvaluationTreeNode *oper = getQueryEvalNode(newLine,queryInput);
        if (oper == NULL)
        {
			globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"Evaluator",__FILE__,"Unexpected operand returned... projection line...");
            delete nre;
			return NULL;
        }
        curr = new QueryEvaluationTreeProjectionNode(oper, num, nre, preserveNodeOrder);
    }
    break;

   
    case 'G': // groupby
    {
        char *token = strtok(line+2,",");                    
        if (token == NULL)
        {
			globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"Evaluator",__FILE__,"Error input from file... expecting estimated Size... group by line...");
            return NULL;
        }
        int size = atoi(token);
        token = strtok(NULL,",");
        if (token == NULL)
        {
			globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"Evaluator",__FILE__,"Error input from file... expecting groupby what... group by line...");
            return NULL;
        }
        int groupByWhat;
        if (strcmp(token,"AN") == 0)
            groupByWhat = GROUPBY_ATTRIBUTE_NUM;
        else if (strcmp(token,"AS") == 0)
            groupByWhat = GROUPBY_ATTRIBUTE_STR;
        else if (strcmp(token,"TN") == 0)
            groupByWhat = GROUPBY_TEXT_NUM;
        else if (strcmp(token,"TS") == 0)
            groupByWhat = GROUPBY_TEXT_STR;
        else if (strcmp(token,"SK") == 0)
            groupByWhat = GROUPBY_STARTKEY;
		else if (strcmp(token,"VN") == 0)
			groupByWhat = GROUPBY_VALUE_NUM;
		else if (strcmp(token,"VS") == 0)
			groupByWhat = GROUPBY_VALUE_STR;
		else
		{
			globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"Evaluator",__FILE__,"Error input from file... unrecognized groupby what... group by line...");
            return NULL;
        }

        token = strtok(NULL,",");
        if (token == NULL)
        {
			globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"Evaluator",__FILE__,"Error input from file... expecting group by nre... group by line...");
            return NULL;
        }
        NREType groupbyNRE = (NREType)atoi(token);
		if (groupbyNRE < 1)
		{
			globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"Evaluator",__FILE__,"NRE should be positive.");
			return NULL;
		}
		if (groupbyNRE > maxNRE)
				maxNRE = groupbyNRE;
        
        token = strtok(NULL,",");
        if (token == NULL)
        {
			globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"Evaluator",__FILE__,"Error input from file... expecting group by attr name... group by line...");
            return NULL;
        }
        char *groupbyAttrName;
	/*	if (strcmp(token,"NULL") == 0)
			groupbyAttrName = NULL;
		else
		{*/
			groupbyAttrName = new char[strlen(token)+1];
			strcpy(groupbyAttrName,token);
		//}

        token = strtok(NULL,",");
        if (token == NULL)
        {
			globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"Evaluator",__FILE__,"Error input from file... expecting boolean keepTrees value... group by line...");
            if (groupbyAttrName) delete [] groupbyAttrName;
			return NULL;
        }
        

		if (atoi(token) != 0 && atoi(token) != 1)
		{
			globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"Evaluator",__FILE__,"Error input from file... keep trees should be 0 or 1... group by line...");
            if (groupbyAttrName) delete [] groupbyAttrName;
			return NULL;
		}
		bool keepTrees = (bool)atoi(token);

        token = strtok(NULL,",");
        if (token == NULL)
        {
			globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"Evaluator",__FILE__,"Error input from file... expecting num of operations... group by line...");
            if (groupbyAttrName) delete [] groupbyAttrName;            
			return NULL;
        }
        int num = atoi(token);

        int *operation;
        int *onWhat;
        NREType *nre;
        char **attrName;
		NREType *operationNRE;

        if (num > 0)
        {
            operation = new int[num];
            onWhat = new int[num];
            attrName = new char *[num];
            nre = new NREType[num];
			operationNRE = new NREType[num];
        }
        else
        {
            operation = NULL;
            onWhat = NULL;
            attrName = NULL;
            nre = NULL;
			operationNRE = NULL;
        }

        for (int i=0; i<num; i++)
        {
            token = strtok(NULL,",");
            if (token == NULL)
            {
				globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"Evaluator",__FILE__,"Error input from file... expecting operation... group by line...");
                if (groupbyAttrName) delete [] groupbyAttrName;
				delete [] operation;
				delete [] onWhat;
				for (int j=0; j<i; j++)
					if (attrName) delete [] attrName;
				delete [] attrName;
				delete [] nre;
				delete [] operationNRE;
				return NULL;
            }
                
            if (strcmp(token,"C") == 0)
                operation[i] = OP_COUNT;
            else if (strcmp(token,"A") == 0)
                operation[i] = OP_AVG;
            else if (strcmp(token,"S") == 0)
                operation[i] = OP_SUM;
            else if (strcmp(token,"M") == 0)
                operation[i] = OP_MAX;
            else if (strcmp(token,"m") == 0)
                operation[i] = OP_MIN;
            else 
            {
				globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"Evaluator",__FILE__,"Error input from file... unrecognized operation... group by line...");
                if (groupbyAttrName) delete [] groupbyAttrName;
				delete [] operation;
				delete [] onWhat;
				for (int j=0; j<i; j++)
					if (attrName) delete [] attrName;
				delete [] attrName;
				delete [] nre;
				delete [] operationNRE;
				return NULL;
            }
                
            token = strtok(NULL,",");
            if (token == NULL)
            {
				globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"Evaluator",__FILE__,"Error input from file... expecting oper on what... group by line...");
                if (groupbyAttrName) delete [] groupbyAttrName;
				delete [] operation;
				delete [] onWhat;
				for (int j=0; j<i; j++)
					if (attrName) delete [] attrName;
				delete [] attrName;
				delete [] nre;
				delete [] operationNRE;               
				return NULL;
            }
                
            if (strcmp(token,"A") == 0)
                onWhat[i] = ON_ATTRIBUTE_NUM;
            else if (strcmp(token,"LA") == 0)
                onWhat[i] = ON_ATTR_LOCAL_NUM;
            else if (strcmp(token,"T") == 0)
                onWhat[i] = ON_TEXT_NUM;
            else if (strcmp(token,"LT") == 0)
                onWhat[i] = ON_TEXT_LOCAL_NUM;
            else if (strcmp(token,"LF") == 0)
                onWhat[i] = ON_FANOUT_LOCAL;
            else if (strcmp(token,"AF") == 0)
                onWhat[i] = ON_FANOUT_ACTUAL;
            else if (strcmp(token,"LD") == 0)
                onWhat[i] = ON_DEPTH_LOCAL;
            else if (strcmp(token,"AD") == 0)
                onWhat[i] = ON_DEPTH_ACTUAL;
			else if (strcmp(token,"V") == 0)
                onWhat[i] = ON_VALUE_NUM;
			else
			{
				globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"Evaluator",__FILE__,"Error input from file... unrecognized operation on what... group by line...");
                if (groupbyAttrName) delete [] groupbyAttrName;
				delete [] operation;
				delete [] onWhat;
				for (int j=0; j<i; j++)
					if (attrName) delete [] attrName;
				delete [] attrName;
				delete [] nre;
				delete [] operationNRE;				
				return NULL;
			}
            token = strtok(NULL,",");
            if (token == NULL)
            {
				globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"Evaluator",__FILE__,"Error input from file... expecting attrName... group by line...");
                if (groupbyAttrName) delete [] groupbyAttrName;
				delete [] operation;
				delete [] onWhat;
				for (int j=0; j<i; j++)
					if (attrName) delete [] attrName;
				delete [] attrName;
				delete [] nre;
				delete [] operationNRE;          
				return NULL;
            }
	/*		if (strcmp(token,"NULL") == 0)
				attrName[i] = NULL;
			else
			{*/
				attrName[i] = new char[strlen(token)+1];
				strcpy(attrName[i],token);
		//	}
			token = strtok(NULL,",");
            if (token == NULL)
            {
				globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"Evaluator",__FILE__,"Error input from file... expecting nre... group by line...");
                if (groupbyAttrName) delete [] groupbyAttrName;
				delete [] operation;
				delete [] onWhat;
				for (int j=0; j<i; j++)
					if (attrName) delete [] attrName;
				delete [] attrName;
				delete [] nre;
				delete [] operationNRE;               
				return NULL;
            }

            nre[i] = atoi(token);
			if (nre[i] < 1)
			{
				globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"Evaluator",__FILE__,"NRE should be positive.");
				 if (groupbyAttrName) delete [] groupbyAttrName;
				delete [] operation;
				delete [] onWhat;
				for (int j=0; j<i; j++)
					if (attrName) delete [] attrName;
				delete [] attrName;
				delete [] nre;
				delete [] operationNRE;    
				return NULL;
			}
			if (nre[i] > maxNRE)
				maxNRE = nre[i];
			token = strtok(NULL,",");
            if (token == NULL)
            {
				globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"Evaluator",__FILE__,"Error input from file... expecting operation nre... group by line...");
                if (groupbyAttrName) delete [] groupbyAttrName;
				delete [] operation;
				delete [] onWhat;
				for (int j=0; j<i; j++)
					if (attrName) delete [] attrName;
				delete [] attrName;
				delete [] nre;
				delete [] operationNRE;                
				return NULL;
            }

            operationNRE[i] = atoi(token);
			if (operationNRE[i] < 1)
			{
				globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"Evaluator",__FILE__,"NRE should be positive.");
				 if (groupbyAttrName) delete [] groupbyAttrName;
				delete [] operation;
				delete [] onWhat;
				for (int j=0; j<i; j++)
					if (attrName) delete [] attrName;
				delete [] attrName;
				delete [] nre;
				delete [] operationNRE;    
				return NULL;
			}
			if (operationNRE[i] > maxNRE)
				maxNRE = operationNRE[i];
        }
		token = strtok(NULL,",");
        if (token == NULL)
        {
			globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"Evaluator",__FILE__,"Error input from file... expecting root nre... group by line...");
			if (groupbyAttrName) delete [] groupbyAttrName;
			if (operation) delete [] operation;
			if (onWhat) delete [] onWhat;
			if (attrName)
			{
			for (int j=0; j<i; j++)
				if (attrName) delete [] attrName;
			delete [] attrName;
			}
			if (nre) delete [] nre;
			if (operationNRE) delete [] operationNRE;            
			return NULL;
        }
        NREType rootNRE = (NREType)atoi(token);

		if (rootNRE < 1)
		{
			globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"Evaluator",__FILE__,"NRE should be positive.");
			if (groupbyAttrName) delete [] groupbyAttrName;
			if (operation) delete [] operation;
			if (onWhat) delete [] onWhat;
			if (attrName)
			{
				for (int j=0; j<i; j++)
					if (attrName) delete [] attrName;
				delete [] attrName;
			}
			if (nre) delete [] nre;
			if (operationNRE) delete [] operationNRE; 
			return NULL;
		}
		if (rootNRE > maxNRE)
			maxNRE = rootNRE;
		token = strtok(NULL,",");
        if (token == NULL)
        {
			globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"Evaluator",__FILE__,"Error input from file... expecting value nre... group by line...");
			if (groupbyAttrName) delete [] groupbyAttrName;
			if (operation) delete [] operation;
			if (onWhat) delete [] onWhat;
			if (attrName)
			{
			for (int j=0; j<i; j++)
				if (attrName) delete [] attrName;
			delete [] attrName;
			}
			if (nre) delete [] nre;
			if (operationNRE) delete [] operationNRE;                  
			return NULL;
        }
        NREType valueNRE = (NREType)atoi(token);
		if (valueNRE < 1)
		{
			globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"Evaluator",__FILE__,"NRE should be positive.");
			if (groupbyAttrName) delete [] groupbyAttrName;
			if (operation) delete [] operation;
			if (onWhat) delete [] onWhat;
			if (attrName)
			{
				for (int j=0; j<i; j++)
					if (attrName) delete [] attrName;
				delete [] attrName;
			}
			if (nre) delete [] nre;
			if (operationNRE) delete [] operationNRE; 
			return NULL;
		}
		if (valueNRE > maxNRE)
			maxNRE = valueNRE;


		token = strtok(NULL,",");
        if (token == NULL)
        {
			globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"Evaluator",__FILE__,"Error input from file... expecting sort bool... group by line...");
			if (groupbyAttrName) delete [] groupbyAttrName;
			if (operation) delete [] operation;
			if (onWhat) delete [] onWhat;
			if (attrName)
			{
			for (int j=0; j<i; j++)
				if (attrName) delete [] attrName;
			delete [] attrName;
			}
			if (nre) delete [] nre;
			if (operationNRE) delete [] operationNRE;           
			return NULL;
        }
		if (atoi(token) != 0 && atoi(token) != 1)
		{
			globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"Evaluator",__FILE__,"Error input from file... sort should be 0 or 1... group by line...");
            if (groupbyAttrName) delete [] groupbyAttrName;
			if (operation) delete [] operation;
			if (onWhat) delete [] onWhat;
			if (attrName)
			{
			for (int j=0; j<i; j++)
				if (attrName) delete [] attrName;
			delete [] attrName;
			}
			if (nre) delete [] nre;
			if (operationNRE) delete [] operationNRE; 			
			return NULL;
		}
        bool sort = (bool) atoi(token);
        char newLine[MAX_FILE_INTERFACE_LINE_SIZE];
        if (((std::iostream *)queryInput)->eof() == 0)
            ((std::iostream *)queryInput)->getline(newLine,MAX_FILE_INTERFACE_LINE_SIZE);
        else
        {
			globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"Evaluator",__FILE__,"Unexpected end of file... group by line...");
			if (groupbyAttrName) delete [] groupbyAttrName;
			if (operation) delete [] operation;
			if (onWhat) delete [] onWhat;
			if (attrName)
			{
			for (int j=0; j<i; j++)
				if (attrName) delete [] attrName;
			delete [] attrName;
			}
			if (nre) delete [] nre;
			if (operationNRE) delete [] operationNRE;            
			return NULL;
        }
        QueryEvaluationTreeNode *oper = getQueryEvalNode(newLine,queryInput);
        if (oper == NULL)
        {
			globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"Evaluator",__FILE__,"Unexpected operand1 returned... group by line...");
			if (groupbyAttrName) delete [] groupbyAttrName;
			if (operation) delete [] operation;
			if (onWhat) delete [] onWhat;
			if (attrName)
			{
			for (int j=0; j<i; j++)
				if (attrName) delete [] attrName;
			delete [] attrName;
			}
			if (nre) delete [] nre;
			if (operationNRE) delete [] operationNRE;           
			return NULL;
        }
        curr = new QueryEvaluationTreeGroupByNode(oper,size,groupByWhat,groupbyNRE,groupbyAttrName,num,operation,onWhat,attrName,nre,rootNRE,valueNRE,operationNRE,sort,keepTrees);
    }
    break;

    case 'F': // function
    {
        char *token = strtok(line+2,",");                    
        if (token == NULL)
        {
			globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"Evaluator",__FILE__,"Error input from file... expecting num of operations... function line...");
            return NULL;
        }
        int num = atoi(token);

        int *operation;
        int *onWhat;
        NREType *nre;
        char **attrNames;
		NREType *assignedNRE;

        if (num > 0)
        {
            operation = new int[num];
            onWhat = new int[num];
            attrNames = new char *[num];
			for (int i=0; i<num; i++)
				attrNames[i] = NULL;
            nre = new NREType[num];
			assignedNRE = new NREType[num];
        }
        else
        {
            operation = NULL;
            onWhat = NULL;
            attrNames = NULL;
            nre = NULL;
			assignedNRE = NULL;
			globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"Evaluator",__FILE__,"Error input from file... num of operations should be positive... function line...");
            return NULL;
        }

        for (int i=0; i<num; i++)
        {
            token = strtok(NULL,",");
            if (token == NULL)
            {
				globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"Evaluator",__FILE__,"Error input from file... expecting operation type... function line...");
				delete [] operation;
				delete [] onWhat;
				for (int j=0; j<i; j++)
					if (attrNames[j]) delete [] attrNames[j];
				delete [] attrNames;

				delete [] nre;
				delete [] assignedNRE;     
                return NULL;
            }
                
            if (strcmp(token,"C") == 0)
                operation[i] = OP_COUNT;
            else if (strcmp(token,"A") == 0)
                operation[i] = OP_AVG;
            else if (strcmp(token,"S") == 0)
                operation[i] = OP_SUM;
            else if (strcmp(token,"M") == 0)
                operation[i] = OP_MAX;
            else if (strcmp(token,"m") == 0)
                operation[i] = OP_MIN;
			else
			{
				globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"Evaluator",__FILE__,"Error input from file... unrecognized operation type... function line...");
				delete [] operation;
				delete [] onWhat;
				for (int j=0; j<i; j++)
					if (attrNames[j]) delete [] attrNames[j];
				delete [] attrNames;

				delete [] nre;
				delete [] assignedNRE;     
                return NULL;
            }
                
            token = strtok(NULL,",");
            if (token == NULL)
            {
				globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"Evaluator",__FILE__,"Error input from file... expecting oper on what... function line...");
				delete [] operation;
				delete [] onWhat;
				for (int j=0; j<i; j++)
					if (attrNames[j]) delete [] attrNames[j];
				delete [] attrNames;

				delete [] nre;
				delete [] assignedNRE;   
				return NULL;
            }
                
            if (strcmp(token,"A") == 0)
                onWhat[i] = ON_ATTRIBUTE_NUM;
            else if (strcmp(token,"LA") == 0)
                onWhat[i] = ON_ATTR_LOCAL_NUM;
            else if (strcmp(token,"T") == 0)
                onWhat[i] = ON_TEXT_NUM;
            else if (strcmp(token,"LT") == 0)
                onWhat[i] = ON_TEXT_LOCAL_NUM;
            else if (strcmp(token,"LF") == 0)
                onWhat[i] = ON_FANOUT_LOCAL;
            else if (strcmp(token,"AF") == 0)
                onWhat[i] = ON_FANOUT_ACTUAL;
            else if (strcmp(token,"LD") == 0)
                onWhat[i] = ON_DEPTH_LOCAL;
            else if (strcmp(token,"AD") == 0)
                onWhat[i] = ON_DEPTH_ACTUAL;
			else if (strcmp(token,"V") == 0)
                onWhat[i] = ON_VALUE_NUM;
			else
			{
				globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"Evaluator",__FILE__,"Error input from file... unrecognized operation on what... function line...");
				delete [] operation;
				delete [] onWhat;
				for (int j=0; j<i; j++)
					if (attrNames[j]) delete [] attrNames[j];
				delete [] attrNames;

				delete [] nre;
				delete [] assignedNRE;   
				return NULL;
			}
                
            token = strtok(NULL,",");
            if (token == NULL)
            {
				globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"Evaluator",__FILE__,"Error input from file... expecting attrName... function line...");
				delete [] operation;
				delete [] onWhat;
				for (int j=0; j<i; j++)
					if (attrNames[j]) delete [] attrNames[j];
				delete [] attrNames;

				delete [] nre;
				delete [] assignedNRE;                  
				return NULL;
            }
        /*   if (strcmp(token,"NULL") == 0)
                attrNames[i] = NULL;
            else
			{*/
				attrNames[i] = new char[strlen(token)+1];
                strcpy(attrNames[i],token);
			//}

            token = strtok(NULL,",");
            if (token == NULL)
            {
				globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"Evaluator",__FILE__,"Error input from file... expecting nre... function line...");
				delete [] operation;
				delete [] onWhat;
				for (int j=0; j<=i; j++)
					if (attrNames[j]) delete [] attrNames[j];
				delete [] attrNames;

				delete [] nre;
				delete [] assignedNRE;                  
				return NULL;
            }

            nre[i] = (NREType) atoi(token);
			if (nre[i] < 1)
			{
				globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"Evaluator",__FILE__,"NRE should be positive.");
				delete [] operation;
				delete [] onWhat;
				for (int j=0; j<=i; j++)
					if (attrNames[j]) delete [] attrNames[j];
				delete [] attrNames;

				delete [] nre;
				delete [] assignedNRE;    
				return NULL;
			}
			if (nre[i] > maxNRE)
				maxNRE = nre[i];

			token = strtok(NULL,",");
            if (token == NULL)
            {
				globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"Evaluator",__FILE__,"Error input from file... expecting assigned nre... function line...");
				delete [] operation;
				delete [] onWhat;
				for (int j=0; j<=i; j++)
					if (attrNames[j]) delete [] attrNames[j];
				delete [] attrNames;

				delete [] nre;
				delete [] assignedNRE;                   
				return NULL;
            }

            assignedNRE[i] = (NREType) atoi(token);
			if (assignedNRE[i] < 1)
			{
				globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"Evaluator",__FILE__,"NRE should be positive.");
				delete [] operation;
				delete [] onWhat;
				for (int j=0; j<=i; j++)
					if (attrNames[j]) delete [] attrNames[j];
				delete [] attrNames;

				delete [] nre;
				delete [] assignedNRE;    
				return NULL;
			}
			if (assignedNRE[i] > maxNRE)
				maxNRE = assignedNRE[i];
        }

		token = strtok(NULL,",");
        if (token == NULL)
        {
			globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"Evaluator",__FILE__,"Error input from file... expecting treeLevel bool... function line...");
			delete [] operation;
			delete [] onWhat;
			for (int j=0; j<num; j++)
				if (attrNames[j]) delete [] attrNames[j];
			delete [] attrNames;

			delete [] nre;
			delete [] assignedNRE;              
			return NULL;
        }
		if (atoi(token) != 0 && atoi(token) != 1)
		{
			globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"Evaluator",__FILE__,"Error input from file... Tree level should be 0 or 1... group by line...");
 			delete [] operation;
			delete [] onWhat;
			for (int j=0; j<num; j++)
				if (attrNames[j]) delete [] attrNames[j];
			delete [] attrNames;

			delete [] nre;
			delete [] assignedNRE;    
			return NULL;
		}
        bool treeLevel = (bool) atoi(token);

        char newLine[MAX_FILE_INTERFACE_LINE_SIZE];
        if (((std::iostream *)queryInput)->eof() == 0)
            ((std::iostream *)queryInput)->getline(newLine,MAX_FILE_INTERFACE_LINE_SIZE);
        else
        {
			globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"Evaluator",__FILE__,"Unexpected end of file... function line...");
			delete [] operation;
			delete [] onWhat;
			for (int j=0; j<num; j++)
				if (attrNames[j]) delete [] attrNames[j];
			delete [] attrNames;

			delete [] nre;
			delete [] assignedNRE;               
			return NULL;
        }
        QueryEvaluationTreeNode *oper = getQueryEvalNode(newLine,queryInput);
        if (oper == NULL)
        {
			globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"Evaluator",__FILE__,"Unexpected operand returned... function line...");
            delete [] operation;
			delete [] onWhat;
			for (int j=0; j<num; j++)
				if (attrNames[j]) delete [] attrNames[j];
			delete [] attrNames;

			delete [] nre;
			delete [] assignedNRE;    
			return NULL;
        }
        curr = new QueryEvaluationTreeFunctionNode(oper,assignedNRE,num,operation,onWhat,nre,attrNames,treeLevel);
    }
    break;
    
    case 'D': // Duplicate Eliminator
    {
        // elminate by what
        char *token = strtok(line+2,",");                    
        if (token == NULL)
        {
			globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"Evaluator",__FILE__,"Error input from file... expecting eliminate by what... DuplicateEliminator line...");
            return NULL;
        }
        int elimByWhat;
        if (strcmp(token,"SK") == 0)
            elimByWhat = ELIMINATE_DUPLICATES_STARTKEY;
        else if (strcmp(token,"TS") == 0)
            elimByWhat = ELIMINATE_DUPLICATES_TEXT_STR;
        else if (strcmp(token,"TN") == 0)
            elimByWhat = ELIMINATE_DUPLICATES_TEXT_NUM;
        else if (strcmp(token,"AS") == 0)
            elimByWhat = ELIMINATE_DUPLICATES_ATTR_STR;
        else if (strcmp(token,"AN") == 0)
            elimByWhat = ELIMINATE_DUPLICATES_ATTR_NUM;
		else if (strcmp(token,"VS") == 0)
            elimByWhat = ELIMINATE_DUPLICATES_VAL_STR;
        else if (strcmp(token,"VN") == 0)
            elimByWhat = ELIMINATE_DUPLICATES_VAL_NUM;
		else if (strcmp(token,"TR") == 0)
			elimByWhat = ELIMINATE_DUPLICATES_TREE;
		else
		{
			globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"Evaluator",__FILE__,"Error input from file... unrecognized eliminate by what value... DuplicateEliminator line...");
            return NULL;
		}
        
        token = strtok(NULL,",");
        if (token == NULL)
        {
			globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"Evaluator",__FILE__,"Error input from file... expecting nre... DuplicateEliminator line...");
            return NULL;
        }
        NREType nre = (NREType)atoi(token);
		if (nre < 1)
		{
			globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"Evaluator",__FILE__,"NRE should be positive.");   
			return NULL;
		}
		if (nre > maxNRE)
				maxNRE = nre;

        // expected size
        token = strtok(NULL,",");
        if (token == NULL)
        {
			globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"Evaluator",__FILE__,"Error input from file... expecting expected size... DuplicateEliminator line...");
            return NULL;
        }
        int size = atoi(token);

        // attribute name
        token = strtok(NULL,",");
        if (token == NULL)
        {
			globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"Evaluator",__FILE__,"Error input from file... expecting attribute name or NULL... DuplicateEliminator line...");
			return NULL;
        }
        char *attrName;
     /*   if (strcmp(token,"NULL") == 0)
            attrName = NULL;
        else
		{*/
			attrName = new char[strlen(token)+1];
            strcpy(attrName,token);
	//	}

        // sort or not
        token = strtok(NULL,",");
        if (token == NULL)
        {
			globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"Evaluator",__FILE__,"Error input from file... expecting sort bool... DuplicateEliminator line...");
            if (attrName) delete [] attrName;
			return NULL;
        }
		if (atoi(token) != 0 && atoi(token) != 1)
		{
			globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"Evaluator",__FILE__,"Error input from file... sort should be 0 or 1... DuplicateEliminator line...");
            if (attrName) delete [] attrName;
			return NULL;
		}
        bool sort = (bool)atoi(token);
    
		bool ext = false;
		token = strtok(NULL,",");
		if (token != NULL)
		{
			if (strcmp(token,"X") == 0)
				ext = true;
		}
        // grab the operand
        char newLine[MAX_FILE_INTERFACE_LINE_SIZE];
        if (((std::iostream *)queryInput)->eof() == 0)
            ((std::iostream *)queryInput)->getline(newLine,MAX_FILE_INTERFACE_LINE_SIZE);
        else
        {
			globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"Evaluator",__FILE__,"Unexpected end of file... duplicate eliminator line...");
            if (attrName) delete [] attrName;
			return NULL;
        }
        QueryEvaluationTreeNode *oper = getQueryEvalNode(newLine,queryInput);

		 if (oper == NULL)
        {
			globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"Evaluator",__FILE__,"Unexpected operand returned in DuplicateElimination.");
            if (attrName) delete [] attrName;
			return NULL;
        }
        curr  = new QueryEvaluationTreeDuplicateEliminatorNode(elimByWhat,nre,size,attrName,sort,ext,oper);
		if (ext)
			this->fileIDsArraySize++;
    }
    break;

    case 'j': // value join
    {
        char *token = strtok(line+2,",");  
		if (token == NULL)
        {
			globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"Evaluator",__FILE__,"Error input from file... expecting root NRE... Value join line...");
            return NULL;
        }
		NREType rootNRE = (NREType)atoi(token);
		if (rootNRE < 1)
		{
			globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"Evaluator",__FILE__,"NRE should be positive.");   
			return NULL;
		}
		if (rootNRE > maxNRE)
				maxNRE = rootNRE;

		token = strtok(NULL,",");
        if (token == NULL)
        {
			globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"Evaluator",__FILE__,"Error input from file... expecting left nre... join line...");
            return NULL;
        }
		NREType  leftNRE;
		if (atoi(token) < 0)
			leftNRE = NULL_NRE;
		else
		{
			leftNRE = (NREType)atoi(token);
		if (leftNRE > maxNRE)
				maxNRE = leftNRE;
		}
		
        token = strtok(NULL,",");
        if (token == NULL)
        {
			globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"Evaluator",__FILE__,"Error input from file... expecting left tag... join line...");
            return NULL;
        }
        int leftTag;
        if (strcmp(token,"NULL") == 0)
            leftTag = -1;
        else
			leftTag = dataMng->getPhysicalDataMng()->getXMLNameTable()->getCodeByName(token);
        token = strtok(NULL,",");
        if (token == NULL)
        {
			globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"Evaluator",__FILE__,"Error input from file... expecting right nre... join line...");
			return NULL;
        }
        NREType  rightNRE;
		if (atoi(token) < 0)
			rightNRE = NULL_NRE;
		else
		{
			rightNRE = (NREType)atoi(token);
		if (rightNRE > maxNRE)
				maxNRE = rightNRE;
		}

        token = strtok(NULL,",");
        if (token == NULL)
        {
			globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"Evaluator",__FILE__,"Error input from file... expecting right tag... join line...");
			return NULL;
        }
        int rightTag;
        if (strcmp(token,"NULL") == 0)
            rightTag = -1;
        else
      		rightTag = dataMng->getPhysicalDataMng()->getXMLNameTable()->getCodeByName(token);


        token = strtok(NULL,",");
        if (token == NULL)
        {
			globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"Evaluator",__FILE__,"Error input from file... expecting size... join line...");
			return NULL;
        }
        int size = atoi(token);
        token = strtok(NULL,",");
        if (token == NULL)
        {
			globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"Evaluator",__FILE__,"Error input from file... expecting left attribute Name... join line...");
            return NULL;
        }
        char *attrNameLeft;

   /*     if (strcmp(token,"NULL") == 0)
            attrNameLeft = NULL;
        else
        {*/
            attrNameLeft = new char[strlen(token)+1];
            strcpy(attrNameLeft,token);
       // }

        token = strtok(NULL,",");
        if (token == NULL)
        {
			globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"Evaluator",__FILE__,"Error input from file... expecting right attribute Name... join line...");
			if (attrNameLeft) delete [] attrNameLeft;
			return NULL;
        }
        char *attrNameRight;

  /*      if (strcmp(token,"NULL") == 0)
            attrNameRight = NULL;
        else
        {*/
            attrNameRight = new char[strlen(token)+1];
            strcpy(attrNameRight,token);
     //   }


        token = strtok(NULL,",");
        if (token == NULL)
        {
			globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"Evaluator",__FILE__,"Error input from file... expecting operation... value join line...");
  
			if (attrNameLeft) delete [] attrNameLeft;
			if (attrNameRight) delete [] attrNameRight;
			return NULL;
        }

        int opr;

        if (strcmp(token,"EQN") == 0)
            opr = JOINOP_EQ_NUM;
        else if (strcmp(token,"NEN") == 0)
            opr = JOINOP_NE_NUM;
        else if (strcmp(token,"LEN") == 0)
            opr = JOINOP_LE_NUM;
        else if (strcmp(token,"LTN") == 0)
            opr = JOINOP_LT_NUM;
        else if (strcmp(token,"GEN") == 0)
            opr = JOINOP_GE_NUM;
		else if (strcmp(token,"GTN") == 0)
            opr = JOINOP_GT_NUM;
		else if (strcmp(token,"EQS") == 0)
            opr = JOINOP_EQ_STR;
        else if (strcmp(token,"NES") == 0)
            opr = JOINOP_NE_STR;
        else if (strcmp(token,"LES") == 0)
            opr = JOINOP_LE_STR;
        else if (strcmp(token,"LTS") == 0)
            opr = JOINOP_LT_STR;
        else if (strcmp(token,"GES") == 0)
            opr = JOINOP_GE_STR;
		else if (strcmp(token,"GTS") == 0)
            opr = JOINOP_GT_STR;
        else if (strcmp(token,"C") == 0)
            opr = JOINOP_CONTAINS;
        else if (strcmp(token,"CB") == 0)
            opr = JOINOP_CONTAINED_BY;
		else
		{
			globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"Evaluator",__FILE__,"Error input from file... unrecognized operation... value join line...");

			if (attrNameLeft) delete [] attrNameLeft;
			if (attrNameRight) delete [] attrNameRight;
			return NULL;
        }

        token = strtok(NULL,",");
        if (token == NULL)
        {
			globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"Evaluator",__FILE__,"Error input from file... expecting joinByWhat left... value join line...");

			if (attrNameLeft) delete [] attrNameLeft;
			if (attrNameRight) delete [] attrNameRight;            
			return NULL;
        }

        int joinByWhatLeft;
        if (strcmp(token,"A") == 0)
            joinByWhatLeft = JOINBY_ATTRIBUTE;
        else if (strcmp(token,"T") == 0)
            joinByWhatLeft = JOINBY_TEXT;
		else if (strcmp(token,"DT") == 0)
            joinByWhatLeft = JOINBY_DESC_TEXT;
        else if (strcmp(token,"S") == 0)
            joinByWhatLeft = JOINBY_STARTKEY;
		else if (strcmp(token,"E") == 0)
            joinByWhatLeft = JOINBY_ENDKEY;
        else if (strcmp(token,"L") == 0)
            joinByWhatLeft = JOINBY_LEVEL;
        else if (strcmp(token,"N") == 0)
            joinByWhatLeft = JOINBY_NOTHING;
		else if (strcmp(token,"TR") == 0)
            joinByWhatLeft = JOINBY_TREE;
		else if (strcmp(token,"TNR") == 0)
            joinByWhatLeft = JOINBY_TREE_WITHOUT_ROOT;
		else if (strcmp(token,"V") == 0)
			joinByWhatLeft = JOINBY_VALUE;
		else
		{
			globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"Evaluator",__FILE__,"Error input from file... unrecognized left join by what... value join line...");

			if (attrNameLeft) delete [] attrNameLeft;
			if (attrNameRight) delete [] attrNameRight;
			return NULL;
        }


		 token = strtok(NULL,",");
        if (token == NULL)
        {
			globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"Evaluator",__FILE__,"Error input from file... expecting joinByWhatRight... value join line...");

			if (attrNameLeft) delete [] attrNameLeft;
			if (attrNameRight) delete [] attrNameRight;        
			return NULL;
        }

        int joinByWhatRight;
        if (strcmp(token,"A") == 0)
            joinByWhatRight = JOINBY_ATTRIBUTE;
        else if (strcmp(token,"T") == 0)
            joinByWhatRight = JOINBY_TEXT;
		else if (strcmp(token,"DT") == 0)
            joinByWhatRight = JOINBY_DESC_TEXT;
        else if (strcmp(token,"S") == 0)
            joinByWhatRight = JOINBY_STARTKEY;
        else if (strcmp(token,"L") == 0)
            joinByWhatRight = JOINBY_LEVEL;
        else if (strcmp(token,"N") == 0)
            joinByWhatRight = JOINBY_NOTHING;
		else if (strcmp(token,"TR") == 0)
            joinByWhatRight = JOINBY_TREE;
		else if (strcmp(token,"TNR") == 0)
            joinByWhatRight = JOINBY_TREE_WITHOUT_ROOT;
		else if (strcmp(token,"V") == 0)
			joinByWhatRight = JOINBY_VALUE;
		else
		{
			globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"Evaluator",__FILE__,"Error input from file... unrecognized right join by what... value join line...");

			if (attrNameLeft) delete [] attrNameLeft;
			if (attrNameRight) delete [] attrNameRight;
			return NULL;
        }
        token = strtok(NULL,",");
        if (token == NULL)
        {
			globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"Evaluator",__FILE__,"Error input from file... expecting sorted input... value join line...");
   
			if (attrNameLeft) delete [] attrNameLeft;
			if (attrNameRight) delete [] attrNameRight;      
			return NULL;
        }

		if (atoi(token) != 0 && atoi(token) != 1)
		{
			globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"Evaluator",__FILE__,"Error input from file... sorted input should be 0 or 1... value join line...");
	
			if (attrNameLeft) delete [] attrNameLeft;
			if (attrNameRight) delete [] attrNameRight;      
			return NULL;
        }
        bool sortedInput = (bool)atoi(token);

		char *indexName = NULL;
		char *fileName = NULL;
		token = strtok(NULL,",");
        if (token == NULL)
        {
			globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"Evaluator",__FILE__,"Error input from file... expecting index name... value join line...");

			if (attrNameLeft) delete [] attrNameLeft;
			if (attrNameRight) delete [] attrNameRight;      
			return NULL;
		}

		if (strcmp(token,"NULL") != 0)
		{
			if (sortedInput)
			{
			//	globalErrorInfo.insertProblem(ERR_TYPE_WARNING,__LINE__,"Evaluator",__FILE__,"Cannot use value join index with sort-merge join. switching to nested-loops join... value join line...");
				sortedInput = false;
			}
			indexName = new char[strlen(token)+1];
			strcpy(indexName,token);	
		}

		token = strtok(NULL,",");
		if (token == NULL)
		{
			globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"Evaluator",__FILE__,"Error input from file... expecting xml file name... value join line...");

			if (attrNameLeft) delete [] attrNameLeft;
			if (attrNameRight) delete [] attrNameRight;      
			if (indexName) delete [] indexName;
			return NULL;
		}

		if (strcmp(token,"NULL") != 0)
		{
			fileName = new char[strlen(token)+1];
			strcpy(fileName,token);
		}
		else if (indexName != NULL)
		{
			globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"Evaluator",__FILE__,"Error input from file... you either pass values for both indexName and fileName or you pass NULL for both... value join line...");

			if (attrNameLeft) delete [] attrNameLeft;
			if (attrNameRight) delete [] attrNameRight;      
			if (indexName) delete [] indexName;
			return NULL;
		}

		bool nest = false;
		bool outer = false;
		bool atLeastOne = false;
		token = strtok(NULL,",");
		if (token != NULL)
		{
			if (strcmp(token,"N") == 0)
			{
				nest = true;
				token = strtok(NULL,",");
				if (token != NULL)
				{
					if (strcmp(token,"O") == 0)
					{
						outer = true;
						token = strtok(NULL,",");
						if (token != NULL)
						{
							if (strcmp(token,"A") == 0)
							{
								atLeastOne = true;
								if (sortedInput)
								{
									globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"Evaluator",__FILE__,"Error input from file... sorted input is not supported with at least one... value join line...");

									if (attrNameLeft) delete [] attrNameLeft;
									if (attrNameRight) delete [] attrNameRight;   
									if (indexName) delete [] indexName;
									if (fileName) delete [] fileName;
									return NULL;
								}
							}
							else
							{
								globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"Evaluator",__FILE__,"Error input from file... unrecognized optional parameter... value join line...");

								if (attrNameLeft) delete [] attrNameLeft;
								if (attrNameRight) delete [] attrNameRight;    
								if (indexName) delete [] indexName;
								if (fileName) delete [] fileName;
								return NULL;
							}
						}
					}
					else if (strcmp(token,"A") == 0)
					{
						atLeastOne = true;
						if (sortedInput)
						{
							globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"Evaluator",__FILE__,"Error input from file... sorted input is not supported with at least one... value join line...");

							if (attrNameLeft) delete [] attrNameLeft;
							if (attrNameRight) delete [] attrNameRight;  
							if (indexName) delete [] indexName;
							if (fileName) delete [] fileName;
							return NULL;
						}
					}
					else
					{
						globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"Evaluator",__FILE__,"Error input from file... unrecognized optional parameter... value join line...");

						if (attrNameLeft) delete [] attrNameLeft;
						if (attrNameRight) delete [] attrNameRight;  
						if (indexName) delete [] indexName;
						if (fileName) delete [] fileName;
						return NULL;
					}
				}
			}
			else if (strcmp(token,"O") == 0)
			{
				outer = true;
				token = strtok(NULL,",");
				if (token != NULL)
				{
					if (strcmp(token,"A") == 0)
					{
						atLeastOne = true;
						if (sortedInput)
						{
							globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"Evaluator",__FILE__,"Error input from file... sorted input is not supported with at least one... value join line...");

							if (attrNameLeft) delete [] attrNameLeft;
							if (attrNameRight) delete [] attrNameRight;  
							if (indexName) delete [] indexName;
							if (fileName) delete [] fileName;
							return NULL;
						}
					}
					else
					{
						globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"Evaluator",__FILE__,"Error input from file... unrecognized optional parameter... value join line...");

						if (attrNameLeft) delete [] attrNameLeft;
						if (attrNameRight) delete [] attrNameRight;  
						if (indexName) delete [] indexName;
						if (fileName) delete [] fileName;
						return NULL;
					}
				}
			}
			else if (strcmp(token,"A") == 0)
			{
				atLeastOne = true;
				if (sortedInput)
				{
					globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"Evaluator",__FILE__,"Error input from file... sorted input is not supported with at least one... value join line...");

					if (attrNameLeft) delete [] attrNameLeft;
					if (attrNameRight) delete [] attrNameRight;   
					if (indexName) delete [] indexName;
					if (fileName) delete [] fileName;
					return NULL;
				}
			}
			else
			{
				globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"Evaluator",__FILE__,"Error input from file... unrecognized optional parameter... value join line...");

				if (attrNameLeft) delete [] attrNameLeft;
				if (attrNameRight) delete [] attrNameRight;  
				if (indexName) delete [] indexName;
				if (fileName) delete [] fileName;
				return NULL;
			}
		}

		char newLine[MAX_FILE_INTERFACE_LINE_SIZE];
		if (((std::iostream *)queryInput)->eof() == 0)
			((std::iostream *)queryInput)->getline(newLine,MAX_FILE_INTERFACE_LINE_SIZE);
		else
		{
			globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"Evaluator",__FILE__,"Unexpected end of file... val join line...");

			if (attrNameLeft) delete [] attrNameLeft;
			if (attrNameRight) delete [] attrNameRight;
			if (indexName) delete [] indexName;
			if (fileName) delete [] fileName;
			return NULL;
		}
		QueryEvaluationTreeNode *oper1 = getQueryEvalNode(newLine,queryInput);
		if (oper1 == NULL)
		{
			globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"Evaluator",__FILE__,"Unexpected operand1 returned... val join line...");

			if (attrNameLeft) delete [] attrNameLeft;
			if (attrNameRight) delete [] attrNameRight;
			if (indexName) delete [] indexName;
			if (fileName) delete [] fileName;
			return NULL;
		}
		if (((std::iostream *)queryInput)->eof() == 0)
			((std::iostream *)queryInput)->getline(newLine,MAX_FILE_INTERFACE_LINE_SIZE);
		else
		{
			globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"Evaluator",__FILE__,"Unexpected end of file... val join line...");

			if (attrNameLeft) delete [] attrNameLeft;
			if (attrNameRight) delete [] attrNameRight;
			if (indexName) delete [] indexName;
			if (fileName) delete [] fileName;
			delete oper1;
			return NULL;
		}
		QueryEvaluationTreeNode *oper2 = getQueryEvalNode(newLine,queryInput);
		if (oper2 == NULL)
		{
			globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"Evaluator",__FILE__,"Unexpected operand2 returned... val join line...");

			if (attrNameLeft) delete [] attrNameLeft;
			if (attrNameRight) delete [] attrNameRight; 
			if (indexName) delete [] indexName;
			if (fileName) delete [] fileName;
			delete oper1;
			return NULL;
		}
		curr = new QueryEvaluationTreeValueJoinNode(oper1,oper2,rootNRE,leftNRE,rightNRE,leftTag,rightTag,size,attrNameLeft,
			attrNameRight,opr,joinByWhatLeft,joinByWhatRight,sortedInput,nest,outer,indexName,fileName
			,atLeastOne);
	}
	break;

    case 'd': // file reader
    {
        char *token = strtok(line+2,",");
        char *fileName;
        if (token == NULL)
        {
			globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"Evaluator",__FILE__,"Error input from file... expecting fileName... file reader line...");
            return NULL;
        }
        fileName = new char[strlen(token)+1];
        strcpy(fileName,token);
        curr = new QueryEvaluationTreeFileReaderNode(fileName);
    }
    break;

    case 'w': // file writer
    {
        char *token = strtok(line+2,",");
        char *fileName;
        if (token == NULL)
        {
			globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"Evaluator",__FILE__,"Error input from file... expecting fileName... file writer line...");
            return NULL;
        }
        fileName = new char[strlen(token)+1];
        strcpy(fileName,token);
        char newLine[MAX_FILE_INTERFACE_LINE_SIZE];
        if (((std::iostream *)queryInput)->eof() == 0)
            ((std::iostream *)queryInput)->getline(newLine,MAX_FILE_INTERFACE_LINE_SIZE);
        else
        {
			globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"Evaluator",__FILE__,"Unexpected end of file... val join line...");
            return NULL;
        }
        QueryEvaluationTreeNode *oper = getQueryEvalNode(newLine,queryInput);
        if (oper == NULL)
        {
			globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"Evaluator",__FILE__,"Unexpected operand returned... fileWriter line...");
            return NULL;
        }
        curr = new QueryEvaluationTreeFileWriterNode(oper,fileName);
    }
    break;

    case 't': // termjoin 
    {
        // index name
        char *token = strtok(line+2,",");
		if (token == NULL)
        {
			globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"Evaluator",__FILE__,"Error input from file... expecting assigned NRE... Index Access line...");
            return NULL;
        }
		NREType assignedNRE = (NREType)atoi(token);
			if (assignedNRE < 1)
		{
			globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"Evaluator",__FILE__,"NRE should be positive.");   
			return NULL;
		}
		if (assignedNRE > maxNRE)
				maxNRE = assignedNRE;

		token = strtok(NULL,",");
        char *indexName;
        if (token == NULL)
        {
			globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"Evaluator",__FILE__,"Error input from file... expecting index name... term join line...");
            return NULL;
        }
        indexName = new char[strlen(token)+1];
        strcpy(indexName,token);

        // index file name
        token = strtok(NULL,",");
        char *fileName;
        if (token == NULL)
        {
			globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"Evaluator",__FILE__,"Error input from file... expecting xml fileName... term join line...");
            delete [] indexName;
			return NULL;
        }
        fileName = new char[strlen(token)+1];
        strcpy(fileName,token);
        
        // phrases
        token = strtok(NULL,",");
        if (token == NULL)
        {
			globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"Evaluator",__FILE__,"Error input from file... expecting phrase... term join line...");
            delete [] indexName;
			delete [] fileName;
			return NULL;
        }
        char *phrase = new char[strlen(token)+1];
        strcpy(phrase,token);

        // score function
        token = strtok(NULL,",");
        if (token == NULL)
        {
			globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"Evaluator",__FILE__,"Error input from file... expecting function 1 number... term join line...");
            delete [] phrase;
			delete [] indexName;
			delete [] fileName;
			return NULL;
        }
        int f1 = atoi(token);

        // ancestor depth function
        token = strtok(NULL,",");
        if (token == NULL)
        {
			globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"Evaluator",__FILE__,"Error input from file... expecting function 2 number... term join line...");
            delete [] phrase; 
			delete [] indexName;
			delete [] fileName;
			return NULL;
        }
        int f2 = atoi(token);

        // ancetor qualifcations function
        token = strtok(NULL,",");
        if (token == NULL)
        {
			globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"Evaluator",__FILE__,"Error input from file... expecting function 3 number... term join line...");
            delete [] phrase; 
			delete [] indexName;
			delete [] fileName;
			return NULL;
        }
        int f3 = atoi(token);

        // expected depth of the document
        token = strtok(NULL,",");
        if (token == NULL)
        {
			globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"Evaluator",__FILE__,"Error input from file... expecting depth... term join line...");
            delete [] phrase;  
			delete [] indexName;
			delete [] fileName;
			return NULL;
        }
        int depth = atoi(token);

        // score type
        token = strtok(NULL,",");
        if (token == NULL)
        {
			globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"Evaluator",__FILE__,"Error input from file... expecting simple score or not... term join line...");
            delete [] phrase;  
			delete [] indexName;
			delete [] fileName;
			return NULL;
        }
		if (atoi(token) != 0 && atoi(token) != 1)
		{
			globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"Evaluator",__FILE__,"Error input from file... expecting simple score should be 0 or 1... term join line...");
            delete [] phrase;  
			delete [] indexName;
			delete [] fileName;
			return NULL;
		}
        bool simpleScore = (bool)atoi(token);

        // identifier for keyword set
        // it there is further argument, it must be present
        token = strtok(NULL,",");
        if (token == NULL)
        {
			globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"Evaluator",__FILE__,"Error input from file... expecting id for keyword set ... term join line...");
            delete [] phrase; 
			delete [] indexName;
			delete [] fileName;
			return NULL;
        }
        int keywordSet = atoi(token);

        //// algorithm type: meet or termjoin
        
        token = strtok(NULL,",");
        if (token == NULL)
        {
			globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"Evaluator",__FILE__,"Error input from file... expecting using meet alg or not... term join line...");
			delete [] indexName;
			delete [] fileName;
			delete [] phrase;
			return NULL;
        }
		if (atoi(token) != 0 && atoi(token) != 1)
		{
			globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"Evaluator",__FILE__,"Error input from file... meet algorithm should be 0 or 1... term join line...");
            delete [] phrase; 
			delete [] indexName;
			delete [] fileName;
			return NULL;
		}
        bool meetAlg = (bool)atoi(token);

        //// index access the parent
        token = strtok(NULL,",");
        char *parentIndexName = NULL;
        int bufPoolSize = 10;
        if (token != NULL)
        {
            parentIndexName = new char[strlen(token)+1];
            strcpy(parentIndexName,token);
            token = strtok(NULL,",");
            if (token != NULL)
                bufPoolSize = atoi(token);
        }
		
        curr  = new QueryEvaluationTreeSBTermJoinNode(assignedNRE,indexName, fileName, phrase, f1,f2,f3,
                                                      depth, simpleScore, keywordSet,
                                                      meetAlg, parentIndexName, bufPoolSize);
    }
    break;
    
    case 'n': // phrase finder
    {
        // index name
        char *token = strtok(line+2,",");
		if (token == NULL)
        {
			globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"Evaluator",__FILE__,"Error input from file... expecting assigned NRE... Phrase finder line...");
            return NULL;
        }
		NREType assignedNRE = (NREType)atoi(token);
			if (assignedNRE < 1)
		{
			globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"Evaluator",__FILE__,"NRE should be positive.");   
			return NULL;
		}
		if (assignedNRE > maxNRE)
				maxNRE = assignedNRE;

		token = strtok(NULL,",");
        char *indexName;
        if (token == NULL)
        {
			globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"Evaluator",__FILE__,"Error input from file... expecting index name... phrase finder line...");
            return NULL;
        }
        indexName = new char[strlen(token)+1];
        strcpy(indexName,token);

        // index file name
        token = strtok(NULL,",");
        char *fileName;
        if (token == NULL)
        {
			globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"Evaluator",__FILE__,"Error input from file... expecting xml fileName... phrase finder line...");
			delete [] indexName;      
			return NULL;
        }
        fileName = new char[strlen(token)+1];
        strcpy(fileName,token);
 
        // phrases
        token = strtok(NULL,",");
        if (token == NULL)
        {
			globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"Evaluator",__FILE__,"Error input from file... expecting phrase... phrase finder line...");
            delete [] indexName;
			delete [] fileName;
			return NULL;
        }
        char *phrase = new char[strlen(token)+1];
        strcpy(phrase,token);

        curr  = new QueryEvaluationTreePhraseFinderNode(assignedNRE,indexName,fileName,phrase);
    }
    break;
    
  

    case 'K': // pick iterator
    {
        char *token = strtok(line+2,",");
        if (token == NULL)
        {
			globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"Evaluator",__FILE__,"Error input from file... expecting function 1 number... pick line...");
            return NULL;
        }
        int f1 = atoi(token);

        token = strtok(NULL,",");
        if (token == NULL)
        {
			globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"Evaluator",__FILE__,"Error input from file... expecting function 2 number... pick line...");
            return NULL;
        }
        int f2 = atoi(token);

        token = strtok(NULL,",");
        if (token == NULL)
        {
			globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"Evaluator",__FILE__,"Error input from file... expecting sort or not (1/0)... pick line...");
            return NULL;
        }
		if (atoi(token) != 0 && atoi(token) != 1)
		{
			globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"Evaluator",__FILE__,"Error input from file... sort should be 0 or 1... pick line...");
			return NULL;
		}
        bool sort = (bool)atoi(token);

        char newLine[MAX_FILE_INTERFACE_LINE_SIZE];
        if (((std::iostream *)queryInput)->eof() == 0)
            ((std::iostream *)queryInput)->getline(newLine,MAX_FILE_INTERFACE_LINE_SIZE);
        else
        {
			globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"Evaluator",__FILE__,"Unexpected end of file... pick line...");
            return NULL;
        }
        QueryEvaluationTreeNode *oper = getQueryEvalNode(newLine,queryInput);
        if (oper == NULL)
        {
			globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"Evaluator",__FILE__,"Unexpected operand returned... pick line...");
            return NULL;
        }
        curr  = new QueryEvaluationTreePickNode(oper,f1,f2,sort);
    }
    break;

    case 'M': // merge trees
    {
        char *token = strtok(line+2,",");
        if (token == NULL)
        {
			globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"Evaluator",__FILE__,"Error input from file... expecting number of inputs... MergeTrees line...");
            return NULL;
        }
        int num = atoi(token);

        QueryEvaluationTreeNode **operands;

        if (num == 0)
            operands = NULL;
        else
            operands = new QueryEvaluationTreeNode *[num];

        char newLine[MAX_FILE_INTERFACE_LINE_SIZE];
        for (int i=0; i<num; i++)
        {
            if (((std::iostream *)queryInput)->eof() == 0)
                ((std::iostream *)queryInput)->getline(newLine,MAX_FILE_INTERFACE_LINE_SIZE);
            else
            {
				globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"Evaluator",__FILE__,"Unexpected end of file... mergeTrees line...");
                return NULL;
            }
            operands[i] = getQueryEvalNode(newLine,queryInput);
            if (operands[i] == NULL)
            {
				globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"Evaluator",__FILE__,"Unexpected operand returned... mergeTRees line...");
                return NULL;
            }
        }
        curr = new QueryEvaluationTreeMergeTreesNode(operands,num);
    }
    break;

		case 'm': // calculate mccas for input trees
    {
        char *token = strtok(line+2,",");
        if (token == NULL)
        {
			globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"Evaluator",__FILE__,"Error input from file... expecting number of inputs... MeaningfulClosestCommonAncestorStructure line...");
			return NULL;
        }
        int num = atoi(token);

		NREType *nre;
		
        if (num > 0)
			nre = new NREType[num];
        else
            nre = NULL;
       
        for (int i=0; i<num; i++)
		{
			token = strtok(NULL,",");
			if (token == NULL)
			{
				globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"Evaluator",__FILE__,"Error input from file... expecting NRE... MeaningfulClosestCommonAncestorStructure line...");
				if (nre) delete [] nre;
				return NULL;
			}
		
			nre[i] = (NREType)atoi(token);
		}
		
		token = strtok(NULL,",");
        if (token == NULL)
        {
			globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"Evaluator",__FILE__,"Error input from file... expecting assignedNre... MeaningfulClosestCommonAncestorStructure line...");
            if (nre) delete [] nre;
			return NULL;
        }		

		NREType assignedNre = atoi(token);

		token = strtok(NULL,",");
        if (token == NULL)
        {
			globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"Evaluator",__FILE__,"Error input from file... expecting size of inputs... MeaningfulClosestCommonAncestorStructure line...");
            if (nre) delete [] nre;
			return NULL;
        }

		int size = atoi(token);
		
		token = strtok(NULL,",");
        if (token == NULL)
        {
			globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"Evaluator",__FILE__,"Error input from file... expecting depth of stack... MeaningfulClosestCommonAncestorStructure line...");
            if (nre) delete [] nre;
			return NULL;
        }
		int depth = atoi(token);

        QueryEvaluationTreeNode **operands;

        if (num > 0)
			operands = new QueryEvaluationTreeNode *[num];
		else
			operands = NULL;

        char newLine[MAX_FILE_INTERFACE_LINE_SIZE];
        for (int i=0; i<num; i++)
        {
            if (((std::iostream *)queryInput)->eof() == 0)
                ((std::iostream *)queryInput)->getline(newLine,MAX_FILE_INTERFACE_LINE_SIZE);
            else
            {
				globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"Evaluator",__FILE__,"Unexpected end of file... MeaningfulClosestCommonAncestorStructure line...");
                if (nre) delete [] nre;
				for (int j =0; j<i; j++)
					delete operands[j];
				delete [] operands;
				return NULL;
            }

			operands[i] = getQueryEvalNode(newLine,queryInput);

            if (operands[i] == NULL)
            {
				globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"Evaluator",__FILE__,"Unexpected operand returned... MeaningfulClosestCommonAncestorStructure line...");
                if (nre) delete [] nre;
				for (int j =0; j<i; j++)
					delete operands[j];
				delete [] operands;
				return NULL;
            }
        }
        curr = new QueryEvaluationTreeMCCASNode(operands, num, nre, assignedNre, size, depth);
		this->fileIDsArraySize++;
    }
    break;

    case 'i': // data instantiation
    {
        char *token = strtok(line+2,",");
        if (token == NULL)
        {
			globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"Evaluator",__FILE__,"Error input from file... expecting index... data instantiation line...");
            return NULL;
        }
        int index = atoi(token);

        token = strtok(NULL,",");
        if (token == NULL)
        {
			globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"Evaluator",__FILE__,"Error input from file... expecting scope... data instantiation line...");
            return NULL;
        }
        int scope;
        if (strcmp(token,"I") == 0)
            scope = DI_SPEC_THENODE;
        else if (strcmp(token,"S") == 0)
            scope = DI_SPEC_SUBTREE;
        else
            scope = DI_SPEC_SUBTREEWITHCUT;
        
        token = strtok(NULL,",");
        if (token == NULL)
        {
			globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"Evaluator",__FILE__,"Error input from file... expecting cutting depth... data instantiation line...");
            return NULL;
        }
        int cuttingDepth = atoi(token);

        token = strtok(NULL,",");
        if (token == NULL)
        {
			globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"Evaluator",__FILE__,"Error input from file... expecting get Element... data instantiation line...");
            return NULL;
        }
        bool getElement = (strcmp(token,"1") == 0);

        token = strtok(NULL,",");
        if (token == NULL)
        {
			globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"Evaluator",__FILE__,"Error input from file... expecting get Attr... data instantiation line...");
            return NULL;
        }
        bool getAttr = (strcmp(token,"1") == 0);

        token = strtok(NULL,",");
        if (token == NULL)
        {
			globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"Evaluator",__FILE__,"Error input from file... expecting get Content... data instantiation line...");
            return NULL;
        }
        bool getContent = (strcmp(token,"1") == 0);
        DataInstantiationSpecification *diSpec= new DataInstantiationSpecification;
        diSpec->scope = scope;
        diSpec->cutDepth = cuttingDepth;
        diSpec->element = getElement;
        diSpec->attribute = getAttr;
        diSpec->content = getContent;

        char newLine[MAX_FILE_INTERFACE_LINE_SIZE];
        if (((std::iostream *)queryInput)->eof() == 0)
            ((std::iostream *)queryInput)->getline(newLine,MAX_FILE_INTERFACE_LINE_SIZE);
        else
        {
			globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"Evaluator",__FILE__,"Unexpected end of file... data instantiation line...");
            return NULL;
        }
        QueryEvaluationTreeNode *oper = getQueryEvalNode(newLine,queryInput);
        if (oper == NULL)
        {
			globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"Evaluator",__FILE__,"Unexpected operand returned... data instantiation line...");
            return NULL;
        }
        curr  = new QueryEvaluationTreeDataInstantiationNode(oper,index,diSpec);
    }
    break;

    case 'b': // data discard
    {
        char *token = strtok(line+2,",");
        if (token == NULL)
        {
			globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"Evaluator",__FILE__,"Error input from file... expecting index... data discard line...");
            return NULL;
        }
        int index = atoi(token);

        token = strtok(NULL,",");
        if (token == NULL)
        {
			globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"Evaluator",__FILE__,"Error input from file... expecting scope... data discard line...");
            return NULL;
        }
        int scope;
        if (strcmp(token,"I") == 0)
            scope = DI_SPEC_THENODE;
        else if (strcmp(token,"S") == 0)
            scope = DI_SPEC_SUBTREE;
        else
            scope = DI_SPEC_SUBTREEWITHCUT;
        
        token = strtok(NULL,",");
        if (token == NULL)
        {
			globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"Evaluator",__FILE__,"Error input from file... expecting cutting depth... data discard line...");
            return NULL;
        }
        int cuttingDepth = atoi(token);

        token = strtok(NULL,",");
        if (token == NULL)
        {
			globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"Evaluator",__FILE__,"Error input from file... expecting get Element... data discard line...");
            return NULL;
        }
        bool getElement = (strcmp(token,"1") == 0);

        token = strtok(NULL,",");
        if (token == NULL)
        {
            globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"Evaluator",__FILE__,"Error input from file... expecting get Attr... data discard line...");
            return NULL;
        }
        bool getAttr = (strcmp(token,"1") == 0);

        token = strtok(NULL,",");
        if (token == NULL)
        {
			globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"Evaluator",__FILE__,"Error input from file... expecting get Content... data discard line...");
            return NULL;
        }
        bool getContent = (strcmp(token,"1") == 0);
        DataInstantiationSpecification *diSpec= new DataInstantiationSpecification;
        diSpec->scope = scope;
        diSpec->cutDepth = cuttingDepth;
        diSpec->element = getElement;
        diSpec->attribute = getAttr;
        diSpec->content = getContent;

        char newLine[MAX_FILE_INTERFACE_LINE_SIZE];
        if (((std::iostream *)queryInput)->eof() == 0)
            ((std::iostream *)queryInput)->getline(newLine,MAX_FILE_INTERFACE_LINE_SIZE);
        else
        {
			globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"Evaluator",__FILE__,"Unexpected end of file... data discard line...");
            return NULL;
        }
        QueryEvaluationTreeNode *oper = getQueryEvalNode(newLine,queryInput);
        if (oper == NULL)
        {
			globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"Evaluator",__FILE__,"Unexpected operand returned... data discard line...");
            return NULL;
        }
        curr  = new QueryEvaluationTreeDataDiscardNode(oper,index,diSpec);
    }
    break;

    case 'k': // sortStopKIterator
    {
        char *token = strtok(line+2,",");
        if (token == NULL)
        {
			globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"Evaluator",__FILE__,"Error input from file... expecting k... sort-stop k line...");
            return NULL;
        }
        int k = atoi(token);
        token = strtok(NULL,",");
        if (token == NULL)
        {
			globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"Evaluator",__FILE__,"Error input from file... expecting inSize... sort-stop k line...");
            return NULL;
        }
        int inSize = atoi(token);

        char newLine[MAX_FILE_INTERFACE_LINE_SIZE];
        if (((std::iostream *)queryInput)->eof() == 0)
            ((std::iostream *)queryInput)->getline(newLine,MAX_FILE_INTERFACE_LINE_SIZE);
        else
        {
			globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"Evaluator",__FILE__,"Unexpected end of file... sort-stop k line...");
            return NULL;
        }
        QueryEvaluationTreeNode *oper = getQueryEvalNode(newLine,queryInput);
        if (oper == NULL)
        {
			globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"Evaluator",__FILE__,"Unexpected operand returned... sort-stop k line...");
            return NULL;
        }

        curr = new QueryEvaluationTreeSortStopKNode(oper,k,inSize);

    }
    break;

	case 'u':   // universal quantification
	{
		char *token = strtok(line+2,",");
        if (token == NULL)
        {
			globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"Evaluator",__FILE__,"Expecting rootNRE in UnivQuant Line.");
            return NULL;
        }
		NREType rootNRE = (NREType)atoi(token);
		if (rootNRE > maxNRE)
				maxNRE = rootNRE;

		token = strtok(NULL,",");
		if (token == NULL)
        {
			globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"Evaluator",__FILE__,"Expecting number of nodes in pattern in UnivQuant Line.");
            return NULL;
        }
        int num = atoi(token);

		int *relation;
		if (num > 0)
			relation = new int[num];
		else
			relation = NULL;

		for (int i=0; i<num; i++)
		{
			token = strtok(NULL,",");
			if (token == NULL)
			{
				globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"Evaluator",__FILE__,"Expecting relation in UnivQuant Line.");
				return NULL;
			}
			relation[i] = (strcmp(token,"P") == 0? PARENT_CHILD : ANCS_DESC);
		}

		UnivQuantCondition *cond = new UnivQuantCondition;
		token = strtok(NULL,",");
		if (token == NULL)
        {
			globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"Evaluator",__FILE__,"Expecting compareWhat in UnivQuant Line.");
            return NULL;
        }

		int compareWhat = (strcmp(token,"T") == 0? UQC_COMPARE_TEXT : UQC_COMPARE_ATTR);
		cond->setCompareWhat(compareWhat);

		token = strtok(NULL,",");
		if (token == NULL)
		{
			globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"Evaluator",__FILE__,"Expecting attribute name in UnivQuant Line.");
			return NULL;
		}
		char *attrName;
	/*	if (strcmp(token,"NULL") == 0)
			attrName = NULL;
		else
		{*/
			attrName = new char[strlen(token) +1];
			strcpy(attrName,token);
	//	}
		cond->setAttrName(attrName);

		token = strtok(NULL,",");
		if (token == NULL)
		{
			globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"Evaluator",__FILE__,"Expecting operation in UnivQuant Line.");
			return NULL;
		}
		int opr;
		if (strcmp(token,"EQN") == 0)
			opr = UQC_EQ_NUM;
		else if (strcmp(token,"NEN") == 0)
			opr = UQC_NE_NUM;
		else if (strcmp(token,"LTN") == 0)
			opr = UQC_LT_NUM;
		else if (strcmp(token,"LEN") == 0)
			opr = UQC_LE_NUM;
		else if (strcmp(token,"GTN") == 0)
			opr = UQC_GT_NUM;
		else if (strcmp(token,"GEN") == 0)
			opr = UQC_GE_NUM;
		else if (strcmp(token,"EQS") == 0)
			opr = UQC_EQ_STR;
		else if (strcmp(token,"NES") == 0)
			opr = UQC_NE_STR;
		else if (strcmp(token,"LTS") == 0)
			opr = UQC_LT_STR;
		else if (strcmp(token,"LES") == 0)
			opr = UQC_LE_STR;
		else if (strcmp(token,"GTS") == 0)
			opr = UQC_GT_STR;
		else if (strcmp(token,"GES") == 0)
			opr = UQC_GE_STR; 
		else if (strcmp(token,"S") == 0)
			opr = UQC_STARTS_WITH;
		else
			opr = UQC_CONTAINS;
		cond->setOperation(opr);

		token = strtok(NULL,",");
		if (token == NULL)
        {
			globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"Evaluator",__FILE__,"Expecting number in UnivQuant Line.");
            return NULL;
        }
        double number = atof(token);
		cond->setNum(number);

		token = strtok(NULL,",");
		if (token == NULL)
		{
			globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"Evaluator",__FILE__,"Expecting str in UnivQuant Line.");
			return NULL;
		}
		char *str;
		if (strcmp(token,"NULL") == 0)
			str = NULL;
		else
		{
			str = new char[strlen(token) +1];
			strcpy(str,token);
		}
		cond->setStr(str);

		IteratorClass **pattern;
		if (num > 0)
			pattern = new IteratorClass *[num];
		else
			pattern = NULL;
		if (pattern == NULL)
		{
			globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"Evaluator",__FILE__,"Pattern cannot be NULL in UnivQuant Line.");
			return NULL;
		}
		for (i=0; i<num; i++)
        {  
			char newLine[MAX_FILE_INTERFACE_LINE_SIZE];
			if (((std::iostream *)queryInput)->eof() == 0)
				((std::iostream *)queryInput)->getline(newLine,MAX_FILE_INTERFACE_LINE_SIZE);
			else
			{
				globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"Evaluator",__FILE__,"Unexpected end of file in UnivQuant Line.");
				return NULL;
			}
			// this should return 1 index access/scan node.
			QueryEvaluationTreeNode *n = getQueryEvalNode(newLine,queryInput);
			QueryEvaluationTree *nt = new QueryEvaluationTree(n);
			pattern[i] = getExecTree(nt);
			delete nt;

			if (pattern[i] == NULL)
			{
				globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"Evaluator",__FILE__,"Pattern cannot be NULL in UnivQuant Line.");
				return NULL;
			}
        }


        char newLine[MAX_FILE_INTERFACE_LINE_SIZE];
        if (((std::iostream *)queryInput)->eof() == 0)
            ((std::iostream *)queryInput)->getline(newLine,MAX_FILE_INTERFACE_LINE_SIZE);
        else
        {
            globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"Evaluator",__FILE__,"Unexpected end of file in UnivQuant Line.");
            return NULL;
        }
        QueryEvaluationTreeNode *oper = getQueryEvalNode(newLine,queryInput);
        if (oper == NULL)
        {
            globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"Evaluator",__FILE__,"Unexpected operand returned (NULL) in UnivQuant Line.");
            return NULL;
        }
        curr = new QueryEvaluationTreeUnivQuantNode(oper,rootNRE, num, pattern, relation, cond);
	}
	break;

	case 'U': //Update Iterators
	{
		//gNumUpdates++;

		//this should be put in a helper function:
		char newLine[MAX_FILE_INTERFACE_LINE_SIZE];
        if (((std::iostream *)queryInput)->eof() == 0)
            ((std::iostream *)queryInput)->getline(newLine,MAX_FILE_INTERFACE_LINE_SIZE);
        else
        {
			globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"Evaluator",__FILE__,"Unexpected end of file... Updates line...");
            return NULL;
        }
        QueryEvaluationTreeNode *oper = getQueryEvalNode(newLine, queryInput);
        if (oper == NULL)
        {
			globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"Evaluator",__FILE__,"Unexpected operand returned... Updates line...");
            return NULL;
        }
		//
		
		if (strlen(line) <= 2) {
			globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"Evaluator",__FILE__,"Input file formatting error... no parameters included after 'U'" );
			return NULL;
		}

		char *updateOperation = strtok(line+2,",");
		if (updateOperation == NULL) {
			globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"Evaluator",__FILE__,"Input file formatting error... expecting value for x in line -> 'U,x,...'");
			return NULL;
		}

		NREType nre = (NREType)atoi(strtok(NULL,","));
		if (nre == NULL) {
			globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"Evaluator",__FILE__,"Input file formatting error... expecting an integer value for x in line -> 'U,UpdateOp,x,...'");
			return NULL;
		}

		//char *indexToUpdate = strtok(NULL,",");
		//if (indexToUpdate == NULL) {
		//	globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"Evaluator",__FILE__,"Input file formatting error... expecting value for x in line -> 'U,UpdateOp,NRE,x,...'");
		//	return NULL;
		//}

		char *textValue1 = strtok(NULL,",");
		char *textValue2 = NULL;//strtok(NULL,",");
		char *textValue3 = NULL;//strtok(NULL,",");
		char *textValue4 = NULL;

		if (strcmp(updateOperation, "ModTNode") == 0) {

			if (textValue1 == NULL) {
				globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"Evaluator",__FILE__,"Unexpected input in Updates line... expecting either CONST or REF for x in line -> 'U,ModTNode,NRE,x,...");
				return NULL;
			}

			//do not allow an empty value for textValue2.   Text Node deletions are performed with DelTNode, not ModTNode
			textValue2 = strtok(NULL,",");
			if (textValue2 == NULL) {
				if (strcmp(textValue1, "CONST") == 0)
					globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"Evaluator",__FILE__,"Unexpected input in Updates line... expecting a constant value for x in line -> 'U,ModTNode,NRE,CONST,x");
				else if (strcmp(textValue1, "REF") == 0)
					globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"Evaluator",__FILE__,"Unexpected input in Updates line... expecting a reference (an LCL) for x in line -> 'U,ModTNode,NRE,REF,x");
				else
					globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"Evaluator",__FILE__,"Unexpected input in Updates line... expecting a value for x in line -> 'U,ModTNode,NRE,CONSTorREF,x");
				return NULL;
			}

			//if REF, check to make sure the ref (LCL) is actually an integer, and is > 0:
			if (strcmp(textValue1, "REF") == 0) {
				errno = 0;
				char *suffixPtr;

				long tempResult = strtol(textValue2, &suffixPtr, 10);
				if (errno || tempResult < 0 || suffixPtr[0] != '\0') {
					globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"Evaluator",__FILE__,"Unexpected input in Updates line... The input (LCL) should be a positive integer -> 'U,ModTNode,NRE,REF,LCL");
					return NULL;
				}
			}

			//textValue3 is used if textValue1==REF, and the NRE in textValue2 is an attribute node:
			textValue3 = strtok(NULL,",");

			gUpdatesArray.push_back(pair<int, string>(0, "Text Node Modification"));
			curr = new QueryEvaluationTreeUpdatesNode(oper,
				QueryEvaluationTreeUpdatesNode::MODIFY_TEXT_NODE, nre,
					textValue1, textValue2, textValue3, textValue4);
		}
		else if (strcmp(updateOperation, "DelTNode") == 0) {
			gUpdatesArray.push_back(pair<int, string>(0, "Text Node Deletion"));
			curr = new QueryEvaluationTreeUpdatesNode(oper,
				QueryEvaluationTreeUpdatesNode::DELETE_TEXT_NODE, nre,
					textValue1, textValue2, textValue3, textValue4);
		}
		else if (strcmp(updateOperation, "DelTree") == 0) {
			gUpdatesArray.push_back(pair<int, string>(0, "Subtree Deletion"));
			curr = new QueryEvaluationTreeUpdatesNode(oper,
				QueryEvaluationTreeUpdatesNode::DELETE_TREE, nre,
					textValue1, textValue2, textValue3, textValue4);
		}
		else if (strcmp(updateOperation, "DelAttr") == 0) {
			if (textValue1 == NULL) {
				globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"Evaluator",__FILE__,"Unexpected input in Updates line... expecting an attributeName for x in line -> 'U,DelAttr,AttributeNRE,x");
				return NULL;
			}

			gUpdatesArray.push_back(pair<int, string>(0, "Attribute Deletion"));
			curr = new QueryEvaluationTreeUpdatesNode(oper,
				QueryEvaluationTreeUpdatesNode::DELETE_ATTRIBUTE, nre,
					textValue1, textValue2, textValue3, textValue4);
		}
		else if (strcmp(updateOperation, "DelAttrValue") == 0) {
			if (textValue1 == NULL) {
				globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"Evaluator",__FILE__,"Unexpected input in Updates line... expecting an attributeName for x in line -> 'U,DelAttrValue,AttributeNRE,x");
				return NULL;
			}

			gUpdatesArray.push_back(pair<int, string>(0, "Attribute Value Deletion"));
			curr = new QueryEvaluationTreeUpdatesNode(oper,
				QueryEvaluationTreeUpdatesNode::DELETE_ATTRIBUTE_VALUE, nre,
					textValue1, textValue2, textValue3, textValue4);
		}
		//else if (strcmp(updateOperation, "InsAttr") == 0) {
		//}
		else if (strcmp(updateOperation, "ModANode") == 0) {
			if (textValue1 == NULL) {
				globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"Evaluator",__FILE__,"Unexpected input in Updates line... expecting an attributeName for x in line -> 'U,ModANode,AttributeNRE,x");
				return NULL;
			}

			//textValue2 (CONST or REF) and textValue3 is required for ModANode
			//(if the attribute value is to be deleted DelAttrValue will be used, not textValue3 = NULL)
			textValue2 = strtok(NULL,",");
			if (textValue2 == NULL) {
				globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"Evaluator",__FILE__,"Unexpected input in Updates line... expecting CONST or REF for x in line -> 'U,ModANode,AttributeNRE,AttributeName,x");
				return NULL;
			}
			
			textValue3 = strtok(NULL,",");
			if (textValue3 == NULL) {
				globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"Evaluator",__FILE__,"Unexpected input in Updates line... expecting value for x in line -> 'U,ModANode,AttributeNRE,AttributeName,CONSTorREF,x");
				return NULL;
			}

			//if REF, check to make sure the ref (LCL) is actually an integer, and is > 0:
			if (textValue2 != NULL && strcmp(textValue2, "REF") == 0) {
				errno = 0;
				char *suffixPtr;

				long tempResult = strtol(textValue3, &suffixPtr, 10);
				if (errno || tempResult < 0 || suffixPtr[0] != '\0') {
					globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"Evaluator",__FILE__,"Unexpected input in Updates line... The input (LCL) should be a positive integer -> 'U,ModANode,AttributeNRE,AttributeName,REF,LCL,...");
					return NULL;
				}
			}

			//textValue4 is used if textValue2==REF, and the NRE in textValue3 is an attribute node:
			textValue4 = strtok(NULL,",");

			gUpdatesArray.push_back(pair<int, string>(0, "Attribute Value Modification"));
			curr = new QueryEvaluationTreeUpdatesNode(oper,
				QueryEvaluationTreeUpdatesNode::MODIFY_ATTRIBUTE_VALUE, nre,
					textValue1, textValue2, textValue3, textValue4);
			
		}
		else if (strcmp(updateOperation, "InsAttr") == 0) {
			if (textValue1 == NULL) {
				globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"Evaluator",__FILE__,"Unexpected input in Updates line... expecting an attributeName for x in line -> 'U,InsAttr,AttributeNRE,x");
				return NULL;
			}

			//the CONST (and the following) arguments can be left off for InsAttr
			textValue2 = strtok(NULL,",");
			
			textValue3 = strtok(NULL,",");
			//if REF, check to make sure the ref (LCL) is actually an integer, and is > 0:
			if (textValue2 != NULL && strcmp(textValue2, "REF") == 0) {
				errno = 0;
				char *suffixPtr;

				long tempResult = strtol(textValue3, &suffixPtr, 10);
				if (errno || tempResult < 0 || suffixPtr[0] != '\0') {
					globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"Evaluator",__FILE__,"Unexpected input in Updates line... The input (LCL) should be a positive integer -> 'U,updateOp,AttributeNRE,REF,LCL,...");
					return NULL;
				}
			}

			//if textValue2 is CONST or REF, then textValue3 is required
			if (textValue2 != NULL && strcmp(textValue2, "<NOVAL>") != 0) {
				if (textValue3 == NULL) {
					globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"Evaluator",__FILE__,"Unexpected input in Updates line... expecting a reference (an LCL) for x in line -> 'U,updateOp,AttributeNRE,REF,x");
					return NULL;
				}
			}

			//textValue4 is used if textValue2==REF, and the NRE in textValue3 is an attribute node:
			textValue4 = strtok(NULL,",");

			gUpdatesArray.push_back(pair<int, string>(0, "Attribute Insertion"));
			curr = new QueryEvaluationTreeUpdatesNode(oper,
			QueryEvaluationTreeUpdatesNode::INSERT_ATTRIBUTE, nre,
					textValue1, textValue2, textValue3, textValue4);

		}
		else if (strcmp(updateOperation, "InsENode") == 0) {
			if (textValue1 == NULL) {
				globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"Evaluator",__FILE__,"Unexpected input in Updates line... expecting the new element's tagname for x in line -> 'U,InsENode,elementNRE,x");
				return NULL;
			}
											//textValue1 == newElementTag
			textValue2 = strtok(NULL,",");	//textValue2 == constOrRef
			//textValue3 = strtok(NULL,",");	//textValue3 == constValueOrNRE
			//textValue4 = strtok(NULL,",");	//textValue4 == possibleAttributeName (if constValueOrNRE refers to an attribute node)

			if (textValue2 == NULL) {
				globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"Evaluator",__FILE__,"Unexpected input in Updates line... expecting one of CONST, REF, or <NOVAL> for x in line -> 'U,InsENode,elementNRE,newElementName,x");
				return NULL;
			}

			if (strcmp(textValue2, "<NOVAL>") != 0) {
				textValue3 = strtok(NULL,",");	//textValue3 == constValueOrNRE

				if (strcmp(textValue2, "REF") == 0) {
					errno = 0;
					char *suffixPtr;

					long tempResult = strtol(textValue3, &suffixPtr, 10);
					if (errno || tempResult < 0 || suffixPtr[0] != '\0') {
						globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"Evaluator",__FILE__,"Unexpected input in Updates line... x (the NRE) should be a positive integer in the line -> 'U,InsENode,ElementNRE,newChildTag,REF,x,...");
						return NULL;
					}
					
					//might be a "placeholder" (have the user enter a dummy value of -1 or something):
					textValue4 = strtok(NULL,",");	//textValue4 == possibleAttributeName (if constValueOrNRE refers to an attribute node)
				}
			}

			gUpdatesArray.push_back(pair<int, string>(0, "Element Insertion"));
			curr = new QueryEvaluationTreeUpdatesNode(oper,
				QueryEvaluationTreeUpdatesNode::INSERT_ELEMENT_NODE, nre,
					textValue1, textValue2, textValue3, textValue4);

			//read in the attribute pairs and add them to the QueryEvaluationTreeUpdatesNode
			//<attributeName, constOrRef, valueOrNRE, attributeNameIfNreIsAttribute>
			char * attributeName = strtok(NULL, ",");
			while (attributeName) {

				char *constOrRef = NULL;
				char *valueOrNRE = NULL;
				char *attributeNameIfNreIsAttribute = NULL;


				constOrRef = strtok(NULL, ",");
				if (constOrRef == NULL) {
					globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"Evaluator",__FILE__,"Unexpected input in Updates line... expecting one of CONST, REF, or <NOVAL> for attribute in InsENode line");
					return NULL;
				}

				if (strcmp(constOrRef, "<NOVAL>") != 0) {
					valueOrNRE = strtok(NULL,",");	//textValue3 == constValueOrNRE

					if (strcmp(constOrRef, "REF") == 0) {
						errno = 0;
						char *suffixPtr;

						long tempResult = strtol(valueOrNRE, &suffixPtr, 10);
						if (errno || tempResult < 0 || suffixPtr[0] != '\0') {
							globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"Evaluator",__FILE__,"Unexpected input in Updates line... attribute NRE should be a positive integer");
							return NULL;
						}
						
						//might be a "placeholder" (have the user enter a dummy value of -1 or something):
						attributeNameIfNreIsAttribute = strtok(NULL,",");	//(actual value if constValueOrNRE refers to an attribute node)
					}
				}

				AttributeInfo attributeInfo(attributeName, constOrRef, valueOrNRE, attributeNameIfNreIsAttribute);

				//downcasts are usually not a good idea, but putting virtual functions into
				//QueryEvaluationTreeNode is not that clean either...
				static_cast<QueryEvaluationTreeUpdatesNode*>(curr)->addRepeatedPair(attributeInfo);

				attributeName = strtok(NULL, ",");
			} //while attributeName
		}
		else if (strcmp(updateOperation, "InsFile") == 0) {
			globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"Evaluator",__FILE__,"The InsFile update operator is not currently supported. You can use the 'append' mode from the command line to append an XML file to an existing document");
			return NULL;
		}
		else {
			globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"Evaluator",__FILE__, "The update operation (UpdateOp) does not match any supported operation names -> U,UpdateOp,..." );
			curr = NULL;
		}

	} //case 'U'

	break;

	case 'O': //one sided join
	{
		char *token = strtok(line+2,",");
		char *indexName;
        if (token == NULL)
        {
			globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"Evaluator",__FILE__,"Error input from file... expecting join index name... one sided join line...");
            return NULL;
        }
        indexName = new char[strlen(token)+1];
        strcpy(indexName,token);

		token = strtok(NULL,",");
		char *fileName;
        if (token == NULL)
        {
			globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"Evaluator",__FILE__,"Error input from file... expecting file name... one sided join line...");
            delete [] indexName;
			return NULL;
        }
        fileName = new char[strlen(token)+1];
        strcpy(fileName,token);

		token = strtok(NULL,",");
		if (token == NULL)
		{
			globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"Evaluator",__FILE__,"Error input from file... expecting left nre... join line...");
			delete [] indexName;
			delete [] fileName;
			return NULL;
		}
		NREType  leftNRE;
		if (atoi(token) < 1)
		{
			globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"Evaluator",__FILE__,"left NRE should be positive.");
			delete [] indexName;
			delete [] fileName;
			return NULL;
		}
		else
		{
			leftNRE = (NREType)atoi(token);
			if (leftNRE > maxNRE)
				maxNRE = leftNRE;
		}

		token = strtok(NULL,",");
		if (token == NULL)
		{
			globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"Evaluator",__FILE__,"Error input from file... expecting right nre... join line...");
			delete [] indexName;
			delete [] fileName;
			return NULL;
		}
		NREType  rightNRE;
		if (atoi(token) < 1)
		{
			globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"Evaluator",__FILE__,"right NRE should be positive.");
			delete [] indexName;
			delete [] fileName;
			return NULL;
		}
		else
		{
			rightNRE = (NREType)atoi(token);
			if (rightNRE > maxNRE)
				maxNRE = rightNRE;
		}

		token = strtok(NULL,",");
		if (token == NULL)
        {
			globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"Evaluator",__FILE__,"Error input from file... expecting root NRE... one sided join line...");
            delete [] indexName;
			delete [] fileName;
			return NULL;
        }
		NREType rootNRE = (NREType)atoi(token);
		if (rootNRE < 1)
		{
			globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"Evaluator",__FILE__,"NRE should be positive.");
			delete [] indexName;
			delete [] fileName;
			return NULL;
		}
		if (rootNRE > maxNRE)
			maxNRE = rootNRE;

		bool nest = false;
		bool outer = false;

		token = strtok(NULL,",");
		if (token != NULL)
		{
			if (strcmp(token,"N") == 0)
			{
				nest = true;
				token = strtok(NULL,",");
				if (token != NULL)
				{
					if (strcmp(token,"O") == 0)
						outer = true;
					else
					{
						globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"Evaluator",__FILE__,"Error input from file... unrecognized optional parameter... one sided join line...");

						if (indexName) delete [] indexName;
						if (fileName) delete [] fileName;
						return NULL;	
					}
				}
			}
			else
			{
				if (strcmp(token,"O") == 0)
					outer = true;
				else
				{
					globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"Evaluator",__FILE__,"Error input from file... unrecognized optional parameter... one sided join line...");

					if (indexName) delete [] indexName;
					if (fileName) delete [] fileName;
					return NULL;	
				}
			}
		}
					

		char newLine[MAX_FILE_INTERFACE_LINE_SIZE];
        if (((std::iostream *)queryInput)->eof() == 0)
            ((std::iostream *)queryInput)->getline(newLine,MAX_FILE_INTERFACE_LINE_SIZE);
		else
		{
			globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"Evaluator",__FILE__,"Unexpected end of file... one sided join line...");
			if (indexName) delete [] indexName;
			if (fileName) delete [] fileName;           
			return NULL;
		}
        QueryEvaluationTreeNode *oper = getQueryEvalNode(newLine,queryInput);
        if (oper == NULL)
        {
			globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"Evaluator",__FILE__,"Unexpected operand returned... one sided join line...");
            if (indexName) delete [] indexName;
			if (fileName) delete [] fileName;
			return NULL;
        }

        curr  = new QueryEvaluationTreeOneSidedValueJoinNode(oper,indexName,fileName,leftNRE,rightNRE,rootNRE,nest,outer);
	}
	break;

	case 'H': //index hash join
	{
		char *token = strtok(line+2,",");
		
        if (token == NULL)
        {
			globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"Evaluator",__FILE__,"Error input from file... expecting expected size... inex hash join line...");
			return NULL;
        }
        int size = atoi(token);

		char *indexName;
		token = strtok(NULL,",");
        if (token == NULL)
        {
			globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"Evaluator",__FILE__,"Error input from file... expecting join index name... index hash join line...");
            return NULL;
        }
        indexName = new char[strlen(token)+1];
        strcpy(indexName,token);

		token = strtok(NULL,",");
		char *fileName;
        if (token == NULL)
        {
			globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"Evaluator",__FILE__,"Error input from file... expecting file name... index hash join line...");
            delete [] indexName;
			return NULL;
        }
        fileName = new char[strlen(token)+1];
        strcpy(fileName,token);

		token = strtok(NULL,",");
		if (token == NULL)
		{
			globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"Evaluator",__FILE__,"Error input from file... expecting left nre... index hash join line...");
			delete [] indexName;
			delete [] fileName;
			return NULL;
		}
		NREType  leftNRE;
		if (atoi(token) < 1)
		{
			globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"Evaluator",__FILE__,"left NRE should be positive.");
			delete [] indexName;
			delete [] fileName;
			return NULL;
		}
		else
		{
			leftNRE = (NREType)atoi(token);
			if (leftNRE > maxNRE)
				maxNRE = leftNRE;
		}

		token = strtok(NULL,",");
		if (token == NULL)
		{
			globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"Evaluator",__FILE__,"Error input from file... expecting right nre... index hash join line...");
			delete [] indexName;
			delete [] fileName;
			return NULL;
		}
		NREType  rightNRE;
		if (atoi(token) < 1)
		{
			globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"Evaluator",__FILE__,"right NRE should be positive.");
			delete [] indexName;
			delete [] fileName;
			return NULL;
		}
		else
		{
			rightNRE = (NREType)atoi(token);
			if (rightNRE > maxNRE)
				maxNRE = rightNRE;
		}

		token = strtok(NULL,",");
		if (token == NULL)
        {
			globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"Evaluator",__FILE__,"Error input from file... expecting root NRE... index hash join line...");
            delete [] indexName;
			delete [] fileName;
			return NULL;
        }
		NREType rootNRE = (NREType)atoi(token);
		if (rootNRE < 1)
		{
			globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"Evaluator",__FILE__,"NRE should be positive.");
			delete [] indexName;
			delete [] fileName;
			return NULL;
		}
		if (rootNRE > maxNRE)
			maxNRE = rootNRE;

		
		bool outer = false;
		bool atLeastOne = false;

		token = strtok(NULL,",");
		if (token != NULL)
		{
			if (strcmp(token,"O") == 0)
			{
				outer = true;
				token = strtok(NULL,",");
				if (token != NULL)
				{
					if (strcmp(token,"A") == 0)
						atLeastOne = true;
					else
					{
						globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"Evaluator",__FILE__,"Error input from file... unrecognized optional parameter... index hash join line...");

						if (indexName) delete [] indexName;
						if (fileName) delete [] fileName;
						return NULL;	
					}
				}
			}
			else
			{
				if (strcmp(token,"A") == 0)
					atLeastOne = true;
				else
				{
					globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"Evaluator",__FILE__,"Error input from file... unrecognized optional parameter... index hash join line...");

					if (indexName) delete [] indexName;
					if (fileName) delete [] fileName;
					return NULL;	
				}
			}
		}
					

		char newLine[MAX_FILE_INTERFACE_LINE_SIZE];
        if (((std::iostream *)queryInput)->eof() == 0)
            ((std::iostream *)queryInput)->getline(newLine,MAX_FILE_INTERFACE_LINE_SIZE);
		else
		{
			globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"Evaluator",__FILE__,"Unexpected end of file... index hash join line...");
			if (indexName) delete [] indexName;
			if (fileName) delete [] fileName;           
			return NULL;
		}
        QueryEvaluationTreeNode *oper1 = getQueryEvalNode(newLine,queryInput);
        if (oper1 == NULL)
        {
			globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"Evaluator",__FILE__,"Unexpected operand 1 returned... index hash join line...");
            if (indexName) delete [] indexName;
			if (fileName) delete [] fileName;
			return NULL;
        }

		if (((std::iostream *)queryInput)->eof() == 0)
            ((std::iostream *)queryInput)->getline(newLine,MAX_FILE_INTERFACE_LINE_SIZE);
		else
		{
			globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"Evaluator",__FILE__,"Unexpected end of file... index hash join line...");
			if (indexName) delete [] indexName;
			if (fileName) delete [] fileName; 
			delete oper1;
			return NULL;
		}
        QueryEvaluationTreeNode *oper2 = getQueryEvalNode(newLine,queryInput);
        if (oper2 == NULL)
        {
			globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"Evaluator",__FILE__,"Unexpected operand 2 returned... index hash join line...");
            if (indexName) delete [] indexName;
			if (fileName) delete [] fileName;
			delete oper1;
			return NULL;
        }

        curr  = new QueryEvaluationTreeIndexHashValueJoinNode(oper1,oper2,size,indexName,fileName,leftNRE,rightNRE,rootNRE,outer,atLeastOne);
		}
		break;

    default: 
        return NULL;
    }

    return curr;
}


IteratorClass *EvaluatorClass::getExecTree(QueryEvaluationTree *evalTree)
{
	updatesCursor = 0;
	if (!evalTree)
    {
        globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"Evaluator",__FILE__,"Evaluation Tree is NULL.");
        return NULL;
    }
    QueryEvaluationTreeNode *root = evalTree->getRoot();
    if (root == NULL)
        return NULL;

	if (createShoreFiles() == FAILURE)
		return NULL;
    return processQueryEvalNode(root);
}

IteratorClass *EvaluatorClass::processQueryEvalNode(QueryEvaluationTreeNode *node)
{
    IteratorClass *curr = NULL;
    switch (node->getQueryEvaluationTreeNodeType())
    {
    case EVALUATION_OP_STRUCTURALJOIN: 
    {
        QueryEvaluationTreeStructuralJoinNode *newNode = (QueryEvaluationTreeStructuralJoinNode *)node;
        IteratorClass *ancs = processQueryEvalNode(newNode->getAncestor());
        if (ancs == NULL)
		{
			globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"Evaluator",__FILE__, "ancs returned is NULL. structural join process eval node..." );
            return NULL;
		}
		IteratorClass *desc = processQueryEvalNode(newNode->getDescendant());
		if (desc == NULL)
		{
			globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"Evaluator",__FILE__, "desc returned is NULL. structural join process eval node..." );
			delete ancs;
			return NULL;
		}
        int relation = (newNode->getRelationship() == JOIN_NODE_RELATION_CHILD? PARENT_CHILD : ANCS_DESC);
		serial_t fileID = fileIDsArray[fileIDsArrayPtr];
		fileIDsArrayPtr++;
        switch (newNode->getAlgorithmChoice())
        {
        case JOIN_ALGORITHM_STACK_ANCS: 
			if (newNode->getProjectWhich() == ANCESTOR)
				curr = new StackBasedAncsProjAncs(ancs,desc,relation,newNode->getAncsNRE(),
				newNode->getDescNRE(),newNode->getLeftNRE(),
                                      newNode->getRightNRE(),
                                      newNode->getEstimatedDepth(),dataMng,fileID);
			else
				curr = new StackBasedAncs(ancs,desc,relation,newNode->getAncsNRE(),
					newNode->getDescNRE(),newNode->getLeftNRE(),
                                      newNode->getRightNRE(),
                                      newNode->getEstimatedDepth(),dataMng,newNode->getNest(),fileID);
            break;
        case JOIN_ALGORITHM_STACK_DESC:
            curr = new StackBasedDesc(ancs,desc,relation,newNode->getAncsNRE(),
				newNode->getDescNRE(),newNode->getLeftNRE(),
                                      newNode->getRightNRE(),newNode->getProjectWhich(),
									  newNode->getEstimatedDepth(),dataMng,fileID);
            
            break;
        case JOIN_ALGORITHM_STACK_NEGATIVE:
			curr = new StackBasedNegativeAncs(ancs,desc,relation,newNode->getAncsNRE(),
                                              newNode->getEstimatedDepth(),dataMng,fileID);
            
            break;
        case JOIN_ALGORITHM_STACK_OUTERANCS: 
            curr = new StackBasedAncsOuter(ancs,desc,relation,newNode->getAncsNRE(),
				newNode->getDescNRE(),newNode->getLeftNRE(),
                                      newNode->getRightNRE(),
									  newNode->getEstimatedDepth(),dataMng,newNode->getNest(),fileID);
           
            break;
		default:
			globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"Evaluator",__FILE__, "unrecognized algorithm. structural join process eval node..." );
            return NULL;
		}
    }
    break;
  
    case EVALUATION_OP_SORT: 
    {
        QueryEvaluationTreeSortNode *newNode = (QueryEvaluationTreeSortNode *)node;
		serial_t fileID = 0;
		serial_t recID = 0;
		int numWrites = 0;
		if (newNode->getExt())
		{
			fileID = fileIDsArray[fileIDsArrayPtr];
			fileIDsArrayPtr++;
			numWrites = this->createRecID(recID);
			if (numWrites == FAILURE)
			{
				globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"Evaluator",__FILE__, "operand returned is NULL. sort process eval node..." );
				return NULL;
			}
		}
        IteratorClass *opr = processQueryEvalNode(newNode->getOperand());
        if (opr == NULL)
		{
			globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"Evaluator",__FILE__, "operand returned is NULL. sort process eval node..." );
            return NULL;
		}
		if (newNode->getExt())
		{	
			if (newNode->getSortByWhat() == SORT_BY_START_KEY)
				curr = new ExternalSortIterator(opr,newNode->getSortNum(),newNode->getNRE(),newNode->getOrder(),dataMng,newNode->getWhereEmptyGoes()
				,fileID,recID,numWrites);
			else if (newNode->getSortByWhat() == SORT_BY_TREE)
			{
				int *sortOrder = new int[1];
				sortOrder[0] = newNode->getSortNum();
				curr = new ExternalSortIterator(opr,0,NULL,sortOrder,dataMng,NULL,fileID,recID,numWrites);
			}
			else if (newNode->getSortByWhat() == SORT_BY_SCORE)
				curr = new ExternalSortIterator(opr,newNode->getSortNum(),dataMng,fileID,recID,numWrites);
			else
			{
				globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"Evaluator",__FILE__, "unrecognized sort by value. sort process eval node..." );
				return NULL;
			}
		}
		else
		{
			if (newNode->getSortByWhat() == SORT_BY_START_KEY)
				curr = new SortIterator(opr,newNode->getExpectedSize(),newNode->getSortNum(),newNode->getNRE(),newNode->getOrder(),dataMng,newNode->getWhereEmptyGoes());
			else if (newNode->getSortByWhat() == SORT_BY_TREE)
			{
				int *sortOrder = new int[1];
				sortOrder[0] = newNode->getSortNum();
				curr = new SortIterator(opr,newNode->getExpectedSize(),0,NULL,sortOrder,dataMng,NULL);
			}
			else if (newNode->getSortByWhat() == SORT_BY_SCORE)
				curr = new SortIterator(opr,newNode->getExpectedSize(),newNode->getSortNum(),dataMng);
			else
			{
				globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"Evaluator",__FILE__, "unrecognized sort by value. sort process eval node..." );
				return NULL;
			}
		}
		newNode->setNRE(NULL);
		newNode->setWhereEmptyGoes(NULL);
		newNode->setOrder(NULL);
    }
    break;

    case EVALUATION_OP_NAVIGATIONAL_GET_RELATIVE:
    {
        QueryEvaluationTreeNavigationalGetRelativeNode *newNode = (QueryEvaluationTreeNavigationalGetRelativeNode *)node;
        IteratorClass *opr = processQueryEvalNode(newNode->getOperand());
        if (opr == NULL)
		{
			globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"Evaluator",__FILE__, "operand returned is NULL. navigational get relative process eval node..." );
			return NULL;
		}
		curr = new NavigationalGetRelative(opr,newNode->getNRE(),newNode->getRelation(),newNode->getNum(),newNode->getAssignedNRE()
                                           ,dataMng);
    }
    break;

    case EVALUATION_OP_VALUE_SORT: 
    {
        QueryEvaluationTreeValueSortNode *newNode = (QueryEvaluationTreeValueSortNode *)node;
		serial_t fileID = 0;
		serial_t recID = 0;
		int numWrites = 0;
		if (newNode->getExt())
		{
			fileID = fileIDsArray[fileIDsArrayPtr];
			fileIDsArrayPtr++;
			numWrites = this->createRecID(recID);
			if (numWrites == FAILURE)
			{
				globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"Evaluator",__FILE__, "operand returned is NULL. sort process eval node..." );
				return NULL;
			}
		}
        IteratorClass *opr = processQueryEvalNode(newNode->getOperand());
        if (opr == NULL)
		{
			globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"Evaluator",__FILE__, "operand returned is NULL. value sort process eval node..." );
			return NULL;
		}
		if (newNode->getExt())
			curr = new ExternalValueSortIterator(opr,newNode->getNum(),newNode->getSortBy(),newNode->getNRE(),
                                     newNode->getAttrName(),newNode->getOrder(),dataMng,newNode->getWhereEmptyGoes()
									 ,fileID,recID,numWrites);
		else
			curr = new ValueSortIterator(opr,newNode->getNumExpected(),newNode->getNum(),newNode->getSortBy(),newNode->getNRE(),
                                     newNode->getAttrName(),newNode->getOrder(),dataMng,newNode->getWhereEmptyGoes());
        newNode->setNRE(NULL);
		newNode->setSortBy(NULL);
		newNode->setAttrName(NULL);
		newNode->setWhereEmptyGoes(NULL);
		newNode->setOrder(NULL);
    }
    break;

    case EVALUATION_OP_SELECTION:  
    {
        QueryEvaluationTreeSelectionNode *newNode = (QueryEvaluationTreeSelectionNode *)node;
		for (int i=0; i<newNode->getNum(); i++)
		{
			for (int j=0; j<newNode->getSelectionCondition()[i].getNum(); j++)
			{
				if (newNode->getSelectionCondition()[i].getCondAt(j)->getFileName())
				{
					int openFileIndex = this->openFile(newNode->getSelectionCondition()[i].getCondAt(j)->getFileName(),dataMng,
						this->capacityChoice, this->capacity, this->replacementChoice, this->replacementPercentage);
					if (openFileIndex == -1)
					{
						globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"Evaluator",__FILE__,"File is unloaded in Timber.");
						return NULL;
					} 
					
					newNode->getSelectionCondition()[i].getCondAt(j)->setOpenFileIndex(openFileIndex);
				}
			}
		}
		
        IteratorClass *opr = processQueryEvalNode(newNode->getOperand());
        if (opr == NULL)
        {
			globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"Evaluator",__FILE__, "operand returned is NULL. filter process eval node..." );
			return NULL;
		}

        curr = new FilterIterator(opr,newNode->getNum(),newNode->getSelectionCondition(),dataMng);
        newNode->setSelectionCondition(NULL);    
    }
    break;

    case EVALUATION_OP_CONSTRUCT:  
    {
        QueryEvaluationTreeConstructNode *newNode = (QueryEvaluationTreeConstructNode *)node;
        IteratorClass *opr = processQueryEvalNode(newNode->getOperand());
        if (opr == NULL)
        {
			globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"Evaluator",__FILE__, "operand returned is NULL. construct process eval node..." );
			return NULL;
		}
        curr = new ConstructIterator(opr,newNode->getSpec(),dataMng);
		newNode->setSpec(NULL);
    }
    break;

    case EVALUATION_OP_CHILDCHOOSER:  
    {
        QueryEvaluationTreeChildChooserNode *newNode = (QueryEvaluationTreeChildChooserNode *)node;
        IteratorClass *opr = processQueryEvalNode(newNode->getOperand());
        if (opr == NULL)
        {
			globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"Evaluator",__FILE__, "operand returned is NULL. child chooser process eval node..." );
			return NULL;
		}
		curr = new ChildChooserIterator(opr,newNode->getWhichChild(),newNode->getNum(),newNode->getParentNRE(),dataMng);
		newNode->setParentNRE(NULL);
    }
    break;

    case EVALUATION_OP_FILEWRITER:  
    {
        QueryEvaluationTreeFileWriterNode *newNode = (QueryEvaluationTreeFileWriterNode *)node;
        IteratorClass *opr = processQueryEvalNode(newNode->getOperand());
        if (opr == NULL)
        {
			globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"Evaluator",__FILE__, "operand returned is NULL. file writer process eval node..." );
			return NULL;
		}
        curr = new FileWriterIterator(opr,newNode->getFileName(),dataMng);
		newNode->setFileName(NULL);
    }
    break;

    case EVALUATION_OP_FILEREADER:  
    {
        QueryEvaluationTreeFileReaderNode *newNode = (QueryEvaluationTreeFileReaderNode *)node;
        curr = new FileReaderIterator(newNode->getFileName(),dataMng);
		newNode->setFileName(NULL);
    }
    break;

    case EVALUATION_OP_INDEX_ACCESS:  
    {
        QueryEvaluationTreeIndexAccessNode *newNode = (QueryEvaluationTreeIndexAccessNode *)node;
        if (newNode->isFromFile())
            curr = NULL;//new ShoreFile(&(dataMng->getVolumeID()),&(newNode->getFid()));
        else
        {

            if (newNode->getShoreOrGist() == SHORE_INDEX)
            {
                curr = NULL;//indexMng->openIndex(newNode->getIndexName(),newNode->getValue());
            }
            else if (newNode->getShoreOrGist() == GIST_INDEX)
            {
                   int openFileIndex = this->openFile(newNode->getFileName(),dataMng,
                                                   this->capacityChoice, this->capacity, this->replacementChoice, this->replacementPercentage);
                if (openFileIndex == -1)
                {
                    globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"Evaluator",__FILE__,"File is unloaded in Timber.");
                    return NULL;
                } 
                // memcpy(&val,newNode->getValue(),sizeof(int));
                bt_query_t *pred;
                
                if (newNode->getIndexType() == INT_INDEX)
                {
                    int val;
                    val = atoi((char *)newNode->getValue());
                    if (newNode->getValue2() != NULL)
                    {
                        int val2 = atoi((char *)newNode->getValue2());
                        pred = new bt_query_t(bt_query_t::bt_betw, new int(val), new int(val2));
                    }
                    else
                        pred = new bt_query_t(bt_query_t::bt_eq, new int(val), NULL);
                }
                else if (newNode->getIndexType() == FLOAT_INDEX)
                {
                    float val;
                    val = (float) atof((char *)newNode->getValue());
                    if (newNode->getValue2() != NULL)
                    {
                        float val2 = (float) atof((char *)newNode->getValue2());
                        pred = new bt_query_t(bt_query_t::bt_betw, new float(val), new float(val2));
                    }
                    else
                        pred = new bt_query_t(bt_query_t::bt_eq, new float(val), NULL);
                }
				else if (newNode->getIndexType() == DOUBLE_INDEX)
                {
                    double val;
                    val = (double) atof((char *)newNode->getValue());
                    if (newNode->getValue2() != NULL)
                    {
                        double val2 = (double) atof((char *)newNode->getValue2());
                        pred = new bt_query_t(bt_query_t::bt_betw, new double(val), new double(val2));
                    }
                    else
                        pred = new bt_query_t(bt_query_t::bt_eq, new double(val), NULL);
                }
                else
                {
                    char *val = new char[strlen((char *)newNode->getValue())+1];
                    strcpy(val,(char *)newNode->getValue());
                    if (newNode->getValue2() != NULL)
                    {
                        char *val2 = new char[strlen((char *)newNode->getValue2())+1];
                        strcpy(val2,(char *)newNode->getValue2());

						if (newNode->tagIdIndex)
							// create equality query that will find a single node (given its tag,id pair)
							pred = TagNameAndNodeIdIndex::getTagNameAndNodeIdQuery(val, atof(val2));
						else
							pred = new bt_query_t(bt_query_t::bt_betw, val, val2);

                   //     delete [] val2; // Cong: memory leak fix 05/28/2004
                    }
					else {
						if (newNode->tagIdIndex)
							// return all of the nodes with a name=val
							// (implemented as a range query for this <name,ID> index)
							pred = TagNameAndNodeIdIndex::getTagNameQuery(val);
						else
							pred = new bt_query_t(bt_query_t::bt_eq, val, NULL);
					}
                  //  delete [] val; // Cong: memory leak fix 05/28/2004
                }

                
				curr = new GistIndexAccess(newNode->getIndexName(),pred,newNode->getIndexType(),(char)openFileIndex,newNode->getNRE());

            }
            else
            {
                int openFileIndex = this->openFile(newNode->getFileName(),dataMng);
                if (openFileIndex == -1)
                {
                    globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"Evaluator",__FILE__,"File is unloaded in Timber.");
                    return NULL;
                }
				curr = new HashIndexAccess(newNode->getIndexName(),(char)openFileIndex,newNode->getIndexType(),newNode->getNRE());
            }
        }
		newNode->setIndexName(NULL);
    }
    break;

	case EVALUATION_OP_MCCAS:
	{
		QueryEvaluationTreeMCCASNode *newNode =	(QueryEvaluationTreeMCCASNode *)node;
		if (newNode->getNumInputs() == 0)
            return NULL;
        IteratorClass **opr = new IteratorClass *[newNode->getNumInputs()];
        for (int i=0; i<newNode->getNumInputs(); i++)
        {
            opr[i] = processQueryEvalNode(newNode->getOperands()[i]);
            if (opr[i] == NULL)
                return NULL;
        }
		serial_t fileID = fileIDsArray[fileIDsArrayPtr];
		fileIDsArrayPtr++;
		curr = new MeaningfulClosestCommonAncestorStructureIterator(
			opr,newNode->getNumInputs(), newNode->getNRE(), newNode->getAssignedNRE(), newNode->getExpectedInputSize(),dataMng, newNode->getExpectedDepth(),fileID);
	}
	break;

    case EVALUATION_OP_SBTERMJOIN:
    {
        QueryEvaluationTreeSBTermJoinNode *newNode = (QueryEvaluationTreeSBTermJoinNode *)node;
        double (__cdecl *f1)(char *xmlDoc, int keywordSet);
        int (__cdecl *f2)(KeyType sk, int lev, int keywordSet);
        bool (__cdecl *f3)(double score, int keywordSet);
        switch (newNode->getFunctionNum1())
        {
        case 1:
            f1 = scoreFunction1;
            break;
        case 2:
            f1 = scoreFunction2;
            break;
		case 3:
			f1 = nullScoreFunction;
			break;
		default: 
			globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"Evaluator",__FILE__, "unrecognized function number 1. term join process eval node..." );
			return NULL;
        }
        switch (newNode->getFunctionNum2())
        {
        case 1:
            f2 = ancsLevel1;
            break;
		case 3:
			f2 = nullAncsLevel;
			break;
		default:  
			globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"Evaluator",__FILE__, "unrecognized function number 2. term join process eval node..." );
			return NULL;
        }
        switch (newNode->getFunctionNum3())
        {
        case 1:
            f3 = ancsQual1;
            break;
		case 3:
			f3 = nullAncsQual;
			break;
		default:
			globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"Evaluator",__FILE__, "unrecognized function number 3. term join process eval node..." );
			return NULL;
		}
        int openFileIndex = this->openFile(newNode->getFileName(),dataMng);
        if (openFileIndex == -1)
        {
			globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"Evaluator",__FILE__,"File is unloaded in Timber.");
			return NULL;
        }
		if (newNode->getMeetAlg())
			curr = new MeetIterator(newNode->getPhrase(),newNode->getIndexName(),(char)openFileIndex,
					f1,f2,f3,newNode->getParentIndexName(),
					newNode->getBufPoolSize(), newNode->getKeywordSet(),newNode->getAssignedNRE(),dataMng,newNode->getSimpleScore());
		else
			curr = new StackBasedTermJoin(newNode->getPhrase(), newNode->getIndexName(), (char)openFileIndex,
                                      f1, f2, f3, newNode->getDepth(), newNode->getParentIndexName(), 
									  newNode->getBufPoolSize(), newNode->getAssignedNRE(), dataMng, newNode->getSimpleScore(), 
                                      newNode->getKeywordSet());
		newNode->setIndexName(NULL);
		newNode->setParentIndexName(NULL);
		newNode->setPhrase(NULL);
    }
    break;

    case EVALUATION_OP_SCAN_ACCESS:  
    {
        QueryEvaluationTreeScanAccessNode *newNode = (QueryEvaluationTreeScanAccessNode *)node;
        int openFileIndex = this->openFile(newNode->getFileName(),dataMng);
        if (openFileIndex == -1)
        {
			globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"Evaluator",__FILE__,"File is unloaded in Timber.");
			return NULL;
		}
        FileIDType fid = this->getFileID(openFileIndex);
        curr = new ScanIterator(newNode->getScanRoot(),newNode->getScanRange(),newNode->getScanCondition(),
			(char)openFileIndex,newNode->getNRE(),dataMng,fid);
		newNode->setScanCondition(NULL);
		newNode->setScanRange(NULL);
   
    }
    break;

    case EVALUATION_OP_PHRASEFINDER:  
    {
        QueryEvaluationTreePhraseFinderNode *newNode = (QueryEvaluationTreePhraseFinderNode *)node;
        int openFileIndex = this->openFile(newNode->getFileName(),dataMng);
        if (openFileIndex == -1)
        {
			globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"Evaluator",__FILE__,"File is unloaded in Timber.");
			return NULL;
		}
		curr = new PhraseFinderIterator(newNode->getPhrase(), newNode->getIndexName(), (char)openFileIndex,newNode->getAssignedNRE());
		newNode->setIndexName(NULL);
		newNode->setPhrase(NULL);
    }
    break;

    case EVALUATION_OP_PROJECTION:
    {
        QueryEvaluationTreeProjectionNode *newNode = (QueryEvaluationTreeProjectionNode *)node;
        IteratorClass *opr = processQueryEvalNode(newNode->getOperand());
        if (opr == NULL)
        {
			globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"Evaluator",__FILE__, "operand returned is NULL. projection process eval node..." );
			return NULL;
		}
		curr = new ProjectionIterator(opr, newNode->getNum(),newNode->getNRE(), newNode->getPreserveNodeOrder(),dataMng);
		newNode->setNRE(NULL);
    }
    break;

    case EVALUATION_OP_SETOPERATIONS:
    {
        QueryEvaluationTreeSetOperationsNode *newNode = (QueryEvaluationTreeSetOperationsNode *)node;
        IteratorClass *opr1 = processQueryEvalNode(newNode->getOperand1());
        
        if (opr1 == NULL)
        {
			globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"Evaluator",__FILE__, "operand1 returned is NULL. set operations process eval node..." );
			return NULL;
		}
		IteratorClass *opr2 = processQueryEvalNode(newNode->getOperand2());
		if (opr2 == NULL)
        {
			globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"Evaluator",__FILE__, "operand2 returned is NULL. set operations process eval node..." );
			delete opr1;
			return NULL;
		}
        switch (newNode->getWhichOperator())
        {
        case UNION_OPERATOR: curr = new UnionIterator(opr1,opr2,dataMng,newNode->getLength()); break;
        case INTERSECTION_OPERATOR: curr = new IntersectionIterator(opr1,opr2,dataMng,newNode->getLength()); break;
        case DIFFERENCE_OPERATOR: curr = new DifferenceIterator(opr1,opr2,dataMng,newNode->getLength()); break;
		default:
			globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"Evaluator",__FILE__, "unrecognized set operation. set operations process eval node..." );
			return NULL;
        }
    }
    break;

    case EVALUATION_OP_VALUEJOIN:
    {
        QueryEvaluationTreeValueJoinNode *newNode = (QueryEvaluationTreeValueJoinNode *)node;
		int openFileIndex = -1;
		if (newNode->getFileName() != NULL)
		{
			openFileIndex= this->openFile(newNode->getFileName(),dataMng);
			if (openFileIndex == -1)
			{
				globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"Evaluator",__FILE__,"File is unloaded in Timber.");
				return NULL;
			}
		}
        IteratorClass *opr1 = processQueryEvalNode(newNode->getLeft());
       
		if (opr1 == NULL)
        {
			globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"Evaluator",__FILE__, "operand1 returned is NULL. value join process eval node..." );
			return NULL;
		}
		IteratorClass *opr2 = processQueryEvalNode(newNode->getRight());
		if (opr2 == NULL)
        {
			globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"Evaluator",__FILE__, "operand2 returned is NULL. value join process eval node..." );
			delete opr1;
			return NULL;
		}
        curr = new ValueJoinIterator(opr1,opr2,newNode->getLeftNRE(),newNode->getRightNRE(),
                                     newNode->getLeftTag(),newNode->getRightTag(),
                                     newNode->getEstimatedSize(),newNode->getAttrNameLeft(),newNode->getAttrNameRight(),
                                     dataMng, newNode->getOperation(),
                                     newNode->getJoinByWhatLeft(),
									 newNode->getJoinByWhatRight(),newNode->getSortedInput()
									 ,newNode->getNest(),newNode->getOuter(),newNode->getRootNRE(), newNode->getIndexName(),
									 openFileIndex,newNode->getAtLeastOne());
		newNode->setAttrNameLeft(NULL);
		newNode->setAttrNameRight(NULL);
		newNode->setIndexName(NULL);
    }
    break;

	case EVALUATION_OP_ONESIDED_JOIN:
    {
        QueryEvaluationTreeOneSidedValueJoinNode *newNode = (QueryEvaluationTreeOneSidedValueJoinNode *)node;
		int openFileIndex= this->openFile(newNode->getFileName(),dataMng);
		if (openFileIndex == -1)
		{
			globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"Evaluator",__FILE__,"File is unloaded in Timber.");
			return NULL;
		}
        IteratorClass *opr = processQueryEvalNode(newNode->getOper());
       
		if (opr == NULL)
        {
			globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"Evaluator",__FILE__, "operand returned is NULL. one sided value join process eval node..." );
			return NULL;
		}
		
        curr = new OneSidedValueJoinIterator(opr,newNode->getIndexName(),(char)openFileIndex,newNode->getLeftNRE(),newNode->getRightNRE(),
			newNode->getNest(),newNode->getOuter(),newNode->getRootNRE(),dataMng);
		newNode->setIndexName(NULL);
    }
    break;

	case EVALUATION_OP_INDEXHASH_JOIN:
    {
        QueryEvaluationTreeIndexHashValueJoinNode *newNode = (QueryEvaluationTreeIndexHashValueJoinNode *)node;
		int openFileIndex= this->openFile(newNode->getFileName(),dataMng);
		if (openFileIndex == -1)
		{
			globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"Evaluator",__FILE__,"File is unloaded in Timber.");
			return NULL;
		}
        IteratorClass *opr1 = processQueryEvalNode(newNode->getOper1());
       
		if (opr1 == NULL)
        {
			globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"Evaluator",__FILE__, "operand 1 returned is NULL. index hash value join process eval node..." );
			return NULL;
		}
		
		IteratorClass *opr2 = processQueryEvalNode(newNode->getOper2());
       
		if (opr2 == NULL)
        {
			globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"Evaluator",__FILE__, "operand 2 returned is NULL. index hash value join process eval node..." );
			delete opr1;
			return NULL;
		}

        curr = new IndexHashValueJoinIterator(opr1,opr2,newNode->getLeftNRE(),newNode->getRightNRE(),newNode->getSize(),dataMng,
			newNode->getOuter(),newNode->getRootNRE(),newNode->getIndexName(),(char)openFileIndex,newNode->getAtLeastOne());
		newNode->setIndexName(NULL);
    }
    break;
    case EVALUATION_OP_GROUPBY:
    {
        QueryEvaluationTreeGroupByNode *newNode = (QueryEvaluationTreeGroupByNode *)node;
        IteratorClass *opr = processQueryEvalNode(newNode->getOperand());
        if (opr == NULL)
        {
			globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"Evaluator",__FILE__, "operand returned is NULL. group by process eval node..." );
			return NULL;
		}
        curr = new GroupByIterator(opr,newNode->getEstimatedSize(),newNode->getGroupByWhat(),
			newNode->getGroupByNRE(),newNode->getGroupByAttrName(),newNode->getKeepTrees(),
                                   newNode->getNum(),newNode->getOperation(),newNode->getOpOnWhat(),
								   newNode->getAttrNames(),newNode->getNRE(),newNode->getRootNRE(),
								   newNode->getValueNRE(),newNode->getOperationNRE(),dataMng,newNode->getSort());
		
		newNode->setOperationNRE(NULL);
		newNode->setNRE(NULL);
		newNode->setOperation(NULL);
		newNode->setOpOnWhat(NULL);
		 newNode->setAttrNames(NULL);
		 newNode->setGroupByAttrName(NULL);
    }
    break;

    case EVALUATION_OP_FUNCTION:
    {
        QueryEvaluationTreeFunctionNode *newNode = (QueryEvaluationTreeFunctionNode *)node;
        IteratorClass *opr = processQueryEvalNode(newNode->getOperand());
        if (opr == NULL)
        {
			globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"Evaluator",__FILE__, "operand returned is NULL. function process eval node..." );
			return NULL;
		}
		if (newNode->getTreeLevel())
			curr = new TreeLevelFunctionIterator(opr,newNode->getNum(),newNode->getOperation(),newNode->getOnWhat(),
                                    newNode->getNRE(),
									newNode->getAttrName(),newNode->getAssignedNRE(),dataMng);
		else
			curr = new FunctionIterator(opr,newNode->getNum(),newNode->getOperation(),newNode->getOnWhat(),
                                    newNode->getNRE(),
									newNode->getAttrName(),newNode->getAssignedNRE(),dataMng);
		newNode->setOperation(NULL);
		newNode->setOnWhat(NULL);
		newNode->setNRE(NULL);
		newNode->setAttrName(NULL);
    }
    break;

    case EVALUATION_OP_DUPLICATE_ELIMINATOR:
    {
        QueryEvaluationTreeDuplicateEliminatorNode *newNode = (QueryEvaluationTreeDuplicateEliminatorNode *)node;
		serial_t fileID = 0;
		serial_t recID = 0;
		int numWrites = 0;
		if (newNode->getSort() && newNode->getExternalSort())
		{
			fileID = fileIDsArray[fileIDsArrayPtr];
			fileIDsArrayPtr++;
			numWrites = this->createRecID(recID);
			if (numWrites == FAILURE)
			{
				globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"Evaluator",__FILE__, "operand returned is NULL. duplicate elminator process eval node..." );
				return NULL;
			}
		}
        IteratorClass *opr = processQueryEvalNode(newNode->getOperand());
          if (opr == NULL)
        {
			globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"Evaluator",__FILE__, "operand returned is NULL. duplicate elimination process eval node..." );
			return NULL;
		}
		curr = new DuplicateEliminatorIterator(opr,newNode->getElimByWhat(), newNode->getNRE(), newNode->getAttrName()
			,dataMng,newNode->getSort(),newNode->getExpectedSize(),fileID,recID,numWrites,newNode->getExternalSort());
		newNode->setAttrName(NULL);
    }
    break;

    case EVALUATION_OP_PICK:
    {
        QueryEvaluationTreePickNode *newNode = (QueryEvaluationTreePickNode *)node;
		IteratorClass *opr = processQueryEvalNode(newNode->getOperand());
		if (opr == NULL)
        {
			globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"Evaluator",__FILE__, "operand returned is NULL. pick process eval node..." );
			return NULL;
		}
        bool (__cdecl *f1)(PickStackNode *node, ListNode *standard, char *lastTag); 
        bool (__cdecl *f2)(WitnessTree *tree, char *tag);
        switch (newNode->getFunctionNum1())
        {
        case 1:
            f1 = Select;
            break;
		default:
           	globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"Evaluator",__FILE__, "unrecognized function1 number. pick process eval node..." );
			return NULL;
        }
        switch (newNode->getFunctionNum2())
        {
        case 1:
            f2 = Qualify;
            break;
		default:
           	globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"Evaluator",__FILE__, "unrecognized function2 number. pick process eval node..." );
			return NULL;
        }
        
        curr = new PickIterator(opr,f1,f2,dataMng,newNode->getSort());
    }
    break;

    case EVALUATION_OP_MERGETREES:
    {
        QueryEvaluationTreeMergeTreesNode *newNode = (QueryEvaluationTreeMergeTreesNode *)node;
        if (newNode->getNumInputs() == 0)
            return NULL;
        IteratorClass **opr = new IteratorClass *[newNode->getNumInputs()];
        for (int i=0; i<newNode->getNumInputs(); i++)
        {
            opr[i] = processQueryEvalNode(newNode->getOperands()[i]);
            if (opr[i] == NULL)
                return NULL;
        }
        curr = new MergeTreesIterator(opr,newNode->getNumInputs(),  dataMng);
    }
    break;

    case EVALUATION_OP_DATA_INSTANTIATION:
    {
        QueryEvaluationTreeDataInstantiationNode *newNode = (QueryEvaluationTreeDataInstantiationNode *)node;
        IteratorClass *opr = processQueryEvalNode(newNode->getOperand());
        if (opr == NULL)
            return NULL;
        curr = new DataInstantiationIterator(opr,newNode->getNodeIndexInWitnessTree(),newNode->getDISpecification(),dataMng);
    }
    break;

    case EVALUATION_OP_DATA_DISCARD:
    {
        QueryEvaluationTreeDataDiscardNode *newNode = (QueryEvaluationTreeDataDiscardNode *)node;
        IteratorClass *opr = processQueryEvalNode(newNode->getOperand());
        if (opr == NULL)
            return NULL;
        curr = new DataDiscardIterator(opr,newNode->getNodeIndexInWitnessTree(),newNode->getDISpecification(),dataMng);
    }
    break;

    case EVALUATION_OP_SORT_STOP_K:
    {
        QueryEvaluationTreeSortStopKNode *newNode = (QueryEvaluationTreeSortStopKNode *)node;
        IteratorClass *opr = processQueryEvalNode(newNode->getOperand());
        if (opr == NULL)
            return NULL;
        curr = new SortStopKIterator(opr,newNode->getK(),newNode->getInSize(),dataMng);
    }
    break;

	case EVALUATION_OP_UNIV_QUANT:
    {
        QueryEvaluationTreeUnivQuantNode *newNode = (QueryEvaluationTreeUnivQuantNode *)node;
        IteratorClass *opr = processQueryEvalNode(newNode->getOperand());
        if (opr == NULL)
            return NULL;
		curr = new UniversalQuantification(opr,newNode->getRootNRE(),newNode->getCondition(),newNode->getNum(),newNode->getPattern(),
			newNode->getRelation(),dataMng);
    }
    break;

	case EVALUATION_OP_UPDATES:
	{
		QueryEvaluationTreeUpdatesNode *newNode = static_cast<QueryEvaluationTreeUpdatesNode*>(node);
		IteratorClass *opr = processQueryEvalNode(newNode->getOperand());
		if (opr == NULL)
			return NULL;
		curr = new UpdatesIterator(opr, dataMng, new IndexIncrementalUpdate(indexMng), 
			newNode->getUpdateType(), newNode->getNRE(), //newNode->getIndexToUpdate(), 
			newNode->getTextValue1(), newNode->getTextValue2(), newNode->getTextValue3(), newNode->getTextValue4(),
			newNode->getRepeated(), updatesCursor);
		updatesCursor++;
	}
	break;

    default: 
        return NULL;
    }
    return curr;
}

/*****************************
 * Query Evaluation Method   *
 *****************************/
double EvaluatorClass::runQuery(char *query, int *count)
{
    *count = -1;
    dataMng->beginTransaction();
    clock_t starttime, finishtime;   
    double  duration;
    fileid = gFileID;
	globalErrorInfo.reset();
    std::strstream queryStream(query,strlen(query));

    QueryEvaluationTree *qtree = this->getQueryEvalTree(&queryStream);
	if (qtree == NULL || qtree->getRoot() == NULL)
    {
        this->closeFiles(dataMng);
        dataMng->abortTransaction();
		if (this->xmlOutput)
		{
			delete [] xmlOutput; 
			xmlOutput = NULL;
		}
        return -1;
    }
#ifdef EVAL_TIME_OUT
	gQueryStartTime = clock();
#endif
	starttime = clock();
	IteratorClass *iter = this->getExecTree(qtree);
    if (iter == NULL)
    {
		qtree->getRoot()->deleteStructures();
        delete qtree;
        this->closeFiles(dataMng);
        dataMng->abortTransaction();
		if (this->xmlOutput)
		{
			delete [] xmlOutput; 
			xmlOutput = NULL;
		}
        return -1;
    }

    WitnessTree *res;
    int c = 0;
    if (!this->xmlOutput)
    {
		xmlOutput = new char[gSettings->getIntegerValue("INITIAL_OUTPUT_SIZE_WHOLE",10000)];
        xmlOutputBufferSz = gSettings->getIntegerValue("INITIAL_OUTPUT_SIZE_WHOLE",10000);
    }
	
	//xmlOutputPtr = xmlOutput;
	curXmlSize = 0;
	//xmlOutputPtr[0] = '\0';
	xmlOutput[0] = '\0';

//	strcpy(ltStr,"&lt;");
//	strcpy(gtStr,"&gt;");
	strcpy(ltStr,"<");
	strcpy(gtStr,">");
	int lastAdded = 0;
	 bool updatesPerformed = false;
/*	if (qtree->getRoot()->getQueryEvaluationTreeNodeType() == EVALUATION_OP_UPDATES ||
		(qtree->getRoot()->getQueryEvaluationTreeNodeType() == EVALUATION_OP_CONSTRUCT
		&& ((QueryEvaluationTreeConstructNode *)qtree->getRoot())->getOperand()->getQueryEvaluationTreeNodeType() == EVALUATION_OP_UPDATES))
		updatesPerformed = true;*/
	 if (gUpdatesArray.size() > 0)
		updatesPerformed = true;
    if (this->constructOutput && !updatesPerformed)
	{
		copyToXMLOutput(ltStr);
        copyToXMLOutput("results");
		copyToXMLOutput(gtStr);
		copyToXMLOutput("\n");
		lastAdded = LAST_ADDED_FIRST_START_TAG;
	}

    iter->next(res);
    while (res)
    {
        if (this->constructOutput && !updatesPerformed)
        {
            res->switchToComplex(dataMng);
			int len;
			int r;
             r = appendTreeToResult(res,0,1,len,lastAdded);
			 while (r != FAILURE && len < res->length())
				r = appendTreeToResult(res,len,1,len,lastAdded);
        }
        c++;
        iter->next(res);
    }

    finishtime = clock();
	if (globalErrorInfo.doWeHaveAProblem())
	{
		delete qtree;
		delete iter;

		this->closeFiles(dataMng);
		dataMng->abortTransaction();
		if (this->xmlOutput)
		{
			delete [] xmlOutput; 
			xmlOutput = NULL;
		}
		return -1;
	}
    if (this->constructOutput && !updatesPerformed)
    {
 		copyToXMLOutput(ltStr);
        copyToXMLOutput("/results");
		copyToXMLOutput(gtStr);
		copyToXMLOutput("\n");
    }
    
	for (unsigned int i = 0; i < gUpdatesArray.size(); i++) {
		int updatesOfThisType = gUpdatesArray.at(i).first;
		string updateType = gUpdatesArray.at(i).second;
		string s = (updatesOfThisType!=1)?"s":""; //make the phrase plural for 0 and >= 1 updates :)

		ostringstream oss;
		oss << "Update " << i+1 << ": " << updatesOfThisType << " " << updateType << s << "." << endl;
		//cout << "Update " << i+1 << ": " << updatesOfThisType << " " << updateType << s << "." << endl;
		copyToXMLOutput(oss.str().c_str());
	}
    duration = (double)(finishtime - starttime) / CLOCKS_PER_SEC;
    delete qtree;
	delete iter;

    this->closeFiles(dataMng);
    dataMng->endTransaction();
    *count = c;
    return duration;
}

/*****************************
 * XML Output Methods        *
 *****************************/

int EvaluatorClass::appendTreeToResult(WitnessTree *in, int index, int numTabs, int &length, int &lastAdded)
{
	if (in->length() == 0)
		return FAILURE;
    short i;
	length = index + 1;
    ComplexListNode *n = (ComplexListNode *)in->getNodeByIndex(index);

    if (n->GetStartPos()  == -1 && !(n->IsDummy()))
        return 0;
  
    if (!n)
        return FAILURE;

    char temp[500];
    
    if (n->IsDummy())
    {
        if (n->GetDummyName()[0] == '@')
        {	
			//if (strlen(xmlOutput) >= 2)
			if (curXmlSize >= 2)
			{
				removeLastChars(strlen(gtStr)+1);
				copyToXMLOutput(" ");
				copyToXMLOutput(n->GetDummyName()+1);
				copyToXMLOutput(gtStr);
				copyToXMLOutput("\n");
				lastAdded = LAST_ADDED_ATTR;
				return 0;
			}
			else
			{
				copyToXMLOutput(n->GetDummyName()+1);
				copyToXMLOutput("\n");
				lastAdded = LAST_ADDED_ATTR;
				return 0;
			}
        }
        else 
        {	
			if (n->GetDummyName()[0]== '<')
			{ //element
				memset(temp,'\t',numTabs);
				temp[numTabs] = '\0';
				copyToXMLOutput(temp);
				copyToXMLOutput(ltStr);
				copyToXMLOutput(n->GetDummyName()+1,strlen(n->GetDummyName()) - 2);
				copyToXMLOutput(gtStr);
				copyToXMLOutput("\n");
				if (index == 0 && in->getScore() > -1)
				{
					sprintf(temp," score=\"%0.3lf\"%s\n",in->getScore(),gtStr);
					copyToXMLOutput(temp);
					removeLastChars(strlen(gtStr)+1);
					copyToXMLOutput(temp);
				}
				lastAdded = LAST_ADDED_START_TAG;
			}
			else //text
			{
				if (curXmlSize == 0)
				//if (strlen(xmlOutput) == 0)
				{
					memset(temp,'\t',numTabs);
					temp[numTabs] = '\0';
					copyToXMLOutput(temp);
				}
				else
				{
					if (lastAdded == LAST_ADDED_START_TAG ||
						lastAdded == LAST_ADDED_ATTR)
						removeLastChars(1);
					else
					{
						memset(temp,'\t',numTabs);
						temp[numTabs] = '\0';
						copyToXMLOutput(temp);
					}
				}
				copyToXMLOutput(n->GetDummyName());
		      
				copyToXMLOutput("\n");
				lastAdded = LAST_ADDED_TEXT;
                return 0;
			}
        }
    }
    else
    {
        if (n->GetData() == NULL)
			return FAILURE;

        	int flag = n->GetData()->getFlag();
        switch (flag)
        {
        case ELEMENT_NODE:

            memset(temp,'\t',numTabs);
            temp[numTabs] = '\0';
            copyToXMLOutput(temp);
			sprintf(temp,"%s%s%s\n",ltStr,dataMng->getPhysicalDataMng()->getXMLNameTable()->getNameByCode(n->GetData()->getTag()),gtStr);
            copyToXMLOutput(temp);

            if (index == 0 && in->getScore() > -1)
            {
                sprintf(temp," score=\"%0.3lf\"%s\n",in->getScore(),gtStr);
                copyToXMLOutput(temp);
                removeLastChars(strlen(gtStr)+1);
                copyToXMLOutput(temp);
            }
			lastAdded = LAST_ADDED_START_TAG;
            break;

        case ATTRIBUTE_NODE:
        {
            short attNum = ((DM_AttributeNode *)n->GetData())->getAttributeNumber();
			if (curXmlSize >= 2) 
			//if (strlen(xmlOutput) >= 2)
			{
				removeLastChars(strlen(gtStr)+1);
				for (i=0;i<attNum;i++)
				{
					//char attrName[MAX_ATTRIBUTE_NAME_LENGTH];
					char* attrName = NULL;

					Value *val = ((DM_AttributeNode *)n->GetData())->getAttr(i,attrName);
					if (val)
					{
						sprintf(temp," %s=\"%s\"",attrName,val->getStrValue());
						copyToXMLOutput(temp);
					}
					else
						return FAILURE;
				}
				copyToXMLOutput(gtStr);
				copyToXMLOutput("\n");
				lastAdded = LAST_ADDED_ATTR;
			}
			else
			{
				for (i=0;i<attNum;i++)
				{
					//char attrName[MAX_ATTRIBUTE_NAME_LENGTH];
					char* attrName = NULL;

					Value *val = ((DM_AttributeNode *)n->GetData())->getAttr(i,attrName);
					if (val)
					{
						sprintf(temp," %s=\"%s\"",attrName,val->getStrValue());
						copyToXMLOutput(temp);
					}
					else
						return FAILURE;
				}
				copyToXMLOutput("\n");
				lastAdded = LAST_ADDED_ATTR;
			}
        }
        return 0;

        case TEXT_NODE:
		case DOCUMENT_NODE:
			{
				if (curXmlSize == 0) 
				//if (strlen(xmlOutput) == 0)
				{
					memset(temp,'\t',numTabs);
					temp[numTabs] = '\0';
					copyToXMLOutput(temp);
				}
				else
				{
					if (lastAdded == LAST_ADDED_START_TAG ||
						lastAdded == LAST_ADDED_ATTR)
						removeLastChars(1);
					else
					{
						memset(temp,'\t',numTabs);
						temp[numTabs] = '\0';
						copyToXMLOutput(temp);
					}
				}
				if (flag == TEXT_NODE)
					copyToXMLOutput(((DM_CharNode *)n->GetData())->getCharValue());
				else
					copyToXMLOutput(((DM_DocumentNode *)n->GetData())->getXMLFileName());
		      
				copyToXMLOutput("\n");
				lastAdded = LAST_ADDED_TEXT;
			}
            return 0;
        }
    }

    int childNum = 1; 
    int child = in->GetLocalChild(index,childNum,true);
    int returnedSkip = 0;
    while (child != -1)
    {
        returnedSkip++;
        int skip = appendTreeToResult(in,child,numTabs+1,length,lastAdded);
        if (skip == FAILURE)
            return FAILURE;
        childNum++;
        childNum += skip;
        returnedSkip += skip;
        // child  = in->GetNextLocalSibling(child,true);
        child = in->GetLocalChild(index,childNum,true);
    }

	//if (xmlOutput[strlen(xmlOutput)-1] == '\n')
	if (xmlOutput[curXmlSize-1] == '\n')
	{
		if (lastAdded == LAST_ADDED_END_TAG) 
		{
			memset(temp,'\t',numTabs);
			temp[numTabs] = '\0';
			copyToXMLOutput(temp);
		}
		else
			removeLastChars(1);
	}

	
    if (n->IsDummy())
    {
		sprintf(temp,"%s/%s",ltStr,n->GetDummyName()+1);
		copyToXMLOutput(temp, strlen(temp)-1);
		copyToXMLOutput(gtStr);
		copyToXMLOutput("\n");
		lastAdded = LAST_ADDED_END_TAG;
    }
    else
    {
        sprintf(temp,"%s/%s%s\n",ltStr,dataMng->getPhysicalDataMng()->getXMLNameTable()->getNameByCode(n->GetData()->getTag()),gtStr);
        copyToXMLOutput(temp);
		lastAdded = LAST_ADDED_END_TAG;
    }
	
    return returnedSkip;
}

void EvaluatorClass::copyToXMLOutput(const char *str, int howMany)
{
	if (howMany == -1)
	{
		accomodate(strlen(str));
		strcpy(xmlOutput+curXmlSize,str);
		curXmlSize += strlen(str);
	}
	else
	{
		accomodate(howMany);
		strncpy(xmlOutput+curXmlSize,str,howMany);
		curXmlSize += howMany;
		xmlOutput[curXmlSize] = '\0';
	}
}

void EvaluatorClass::removeLastChars(int howMany)
{
	curXmlSize -= howMany;
	xmlOutput[curXmlSize] = '\0';
}

char *EvaluatorClass::getXMLoutput()
{
    return this->xmlOutput;
}
void EvaluatorClass::accomodate(int howMany)
{
    int size = howMany + curXmlSize;
    size++;
    while (size >= xmlOutputBufferSz)
        this->doubleXMLoutputBuffer();
}
void EvaluatorClass::doubleXMLoutputBuffer()
{
    char *tmp = xmlOutput;
    xmlOutputBufferSz *= 2;
    xmlOutput = new char[xmlOutputBufferSz];
    //memcpy(xmlOutput,tmp,strlen(tmp)+1);
	memcpy(xmlOutput, tmp, curXmlSize+1);
	//xmlOutputPtr = xmlOutput + strlen(xmlOutput);
    delete [] tmp;
}
void EvaluatorClass::increaseSizeOfXMLoutputBuffer(int by)
{
    char *tmp = xmlOutput;
    xmlOutputBufferSz += by;
    xmlOutput = new char[xmlOutputBufferSz];
    //memcpy(xmlOutput,tmp,strlen(tmp)+1);
	memcpy(xmlOutput, tmp, curXmlSize+1);
	//xmlOutputPtr = xmlOutput + strlen(xmlOutput);
    delete [] tmp;
}
void EvaluatorClass::setConstructOutput(bool constructOutput)
{
    this->constructOutput = constructOutput;
}

bool EvaluatorClass::getConstructOutput()
{
    return this->constructOutput;
}


/*****************************
 * File Related Methods      *
 *****************************/

int EvaluatorClass::openFile(char *fileName, DataMng *dataMng, int cpChoice,
                             int cp, int rpChoice, float rpRate)
{
    for (int i=0; i<openFilesCount; i++)
        if (strcmp(openFilesNames[i],fileName) == 0)
            return i;
    if (openFilesCount >= MAX_FILENUMER)
        return -1;
    KeyType rootIndex;

    // medified by Melanie 
    openFiles[openFilesCount] = dataMng->openFile(fileName,&rootIndex,
                                                  cpChoice, cp, rpChoice, rpRate);
                                                  
    if (openFiles[openFilesCount] == -1)
        return -1;
    strcpy(openFilesNames[openFilesCount],fileName);
    openFilesCount++;
    return openFilesCount-1;
}

char *EvaluatorClass::getOpenFileName(int openFileIndex)
{
    if (openFileIndex >= openFilesCount || openFileIndex < 0)
        return NULL;
    return openFilesNames[openFileIndex];
}
void EvaluatorClass::closeFiles(DataMng *dataMng, int* size, int* rpTimes)
{
    for (int i=0; i<openFilesCount; i++)
        dataMng->closeFile(openFiles[i], size, rpTimes);
    openFilesCount = 0;
}                        
void EvaluatorClass::setFileID(FileIDType fid)
{
    this->fileid = fid;
}
FileIDType EvaluatorClass::getFileID(int fileIndex)
{
    if (fileIndex >= openFilesCount || fileIndex < 0)
        return -1;
    return openFiles[fileIndex];
}


/*****************************
 * Data Access Method        *
 *****************************/
int EvaluatorClass::findNode(WitnessTree *in, int tag, DataMng *dataMng)
{
    in->switchToComplex(dataMng);
    for (int i=0; i<in->length(); i++)
    {
        FileIDType fileid;
        fileid = getFileID(((ComplexListNode *)in->getNodeByIndex(i))->getFileIndex());
        if (fileid == -1)
            return FAILURE;
		if (((ComplexListNode *)(in->getNodeByIndex(i)))->GetData() == NULL)
            return FAILURE;
        if (((ComplexListNode *)in->getNodeByIndex(i))->GetData()->getFlag() != ELEMENT_NODE)
            continue;

        if (((ComplexListNode *)in->getNodeByIndex(i))->GetData()->getTag() == tag)
            return i;
    }
    return FAILURE;
}




char *EvaluatorClass::findText(WitnessTree *in, int index, int &newInd)
{
	int s=1;
	int i;
	while ((i=in->GetChild(index, s)) > -1)
	{
		if (!(((ComplexListNode *)(in->getNodeByIndex(i)))->GetData()))
			return NULL;
		if (((ComplexListNode *)(in->getNodeByIndex(i)))->GetData()->getFlag() == TEXT_NODE)
		{
			newInd = i;
			return ((DM_CharNode *)((ComplexListNode *)(in->getNodeByIndex(i)))->GetData())->getCharValue();
		}
		s++;
	}
	return NULL;
}


char *EvaluatorClass::returnText(WitnessTree *in, int index, DataMng *dataMng, FileIDType fid, bool desc)
{
	
    in->switchToComplex(dataMng);
	ComplexListNode *n1 = (ComplexListNode *)in->getNodeByIndex(index);
	if (n1->IsDummy())
	{
		char *txt = new char[strlen(n1->GetDummyName())+1];
		strcpy(txt,n1->GetDummyName());
		return txt;
	}
	int res;

	char *txt = NULL;
	if (!desc)
	{
		if (findText(in,index,res) == NULL)
		{
			res= GetText(in,index,dataMng,fid);
			if (res == 0)
			{
				txt = new char[1];
				strcpy(txt,"");
				return txt;
			}
			else if (res == FAILURE)
				return NULL;

		}

		//getting text
		ComplexListNode *n=(ComplexListNode *)in->getNodeByIndex(res);

		if (n->GetData() == NULL)
			return NULL;
		txt = new char[strlen(((DM_CharNode *)n->GetData())->getCharValue()) + 1];
		strcpy(txt,((DM_CharNode *)n->GetData())->getCharValue());

		res = in->GetNextSibling(res);
		DM_DataNode *dn;
		while (res != -1)
		{
			n = (ComplexListNode *)in->getNodeByIndex(res);
			dn = n->GetData();
			if (dn == NULL)
			{
				delete [] txt;
				return NULL;
			}
			if (dn->getFlag() == TEXT_NODE)
			{
				char *tmp = txt;
				txt = new char [strlen(tmp) + strlen(((DM_CharNode *)dn)->getCharValue()) + 1];
				strcpy(txt,tmp);
				strcat(txt,((DM_CharNode *)dn)->getCharValue());
				delete [] tmp;
			}
			res = in->GetNextSibling(res);
		}
	}
	else
	{	
		//getting text
		ComplexListNode *n=(ComplexListNode *)in->getNodeByIndex(index);

		if (n->GetData() == NULL)
			return NULL;
		KeyType sk = n->GetStartPos();
		DM_DataNode *dataNode = dataMng->getChild(fid,sk,0);
		
		while (dataNode)
		{
			if (dataNode->getFlag() == ELEMENT_NODE)
			{
				ComplexListNode child;
				child.SetStartPos(dataNode->getKey());
				WitnessTree tmpTree(LIST_NODE_WITH_DATA);
				tmpTree.appendList(&child,dataMng,1);
				char *retText = returnText(&tmpTree,0,dataMng,fid,desc);
				if (retText)
				{
					if (txt)
					{
						char *tmp = txt;
						txt = new char [strlen(tmp) + strlen(retText) + 1];
						strcpy(txt,tmp);
						strcat(txt,retText);
						delete [] tmp;
						delete [] retText;
					}
					else
						txt = retText;
					
				}
			}
			else if (dataNode->getFlag() == TEXT_NODE)
			{
				if (txt)
				{
					char *tmp = txt;
					txt = new char [strlen(tmp) + strlen(((DM_CharNode *)dataNode)->getCharValue()) + 1];
					strcpy(txt,tmp);
					strcat(txt,((DM_CharNode *)dataNode)->getCharValue());
					delete [] tmp;
				}
				else
				{
					txt = new char [strlen(((DM_CharNode *)dataNode)->getCharValue()) + 1];
					strcpy(txt,((DM_CharNode *)dataNode)->getCharValue());
				}
			}
			sk = dataNode->getKey();
			dataNode = dataMng->getNextSibling(fid,sk);
		}
	}
    return txt;

}


int EvaluatorClass::GetChildren(WitnessTree *in, int index, DataMng *dataMng, FileIDType fid, NREType nre)
{
    DM_DataNode *data_node = dataMng->getChild(fid,((ComplexListNode *)in->getNodeByIndex(index))->GetStartPos(),0,true);
	KeyType parentkey = ((ComplexListNode *)in->getNodeByIndex(index))->GetStartPos(); //Nuwee added 07/28/03
    int firstChild = 0;
    char fileIndex = ((ComplexListNode *)in->getNodeByIndex(index))->getFileIndex();
    bool childrenFound = false;
    while (data_node)
    {
        ComplexListNode node;
        node.SetStartPos(data_node->getKey());
        node.SetEndPos(data_node->getEndKey());
        node.SetLevel(data_node->getLevel());
		node.setNRE(nre);
//        node.setSkipNode(skipChildren);
        node.setFileIndex(fileIndex);
//        addDMNode(data_node,&node);
        int i = in->sortedInsertNode((ComplexListNode *)&node,dataMng,index+1);
        if (!childrenFound)
            firstChild = i;
        index++;
        childrenFound = true;
		//Nuwee changed interface 07/01/03, need parent key for Multicolor
        data_node = dataMng->getNextSibling(fid,data_node->getKey(),parentkey,true);
    }
    return (childrenFound? firstChild : FAILURE);
}

int EvaluatorClass::GetChildrenText(WitnessTree *in, int index, DataMng *dataMng, FileIDType fid, NREType nre)
{
    DM_DataNode *data_node = dataMng->getChild(fid,((ComplexListNode *)in->getNodeByIndex(index))->GetStartPos(),0,true);
	//Nuwee added 07/28/03
	KeyType parentkey = ((ComplexListNode *)in->getNodeByIndex(index))->GetStartPos();

    int firstChild = 0;
    char fileIndex = ((ComplexListNode *)in->getNodeByIndex(index))->getFileIndex();
    bool childrenFound = false;
    while (data_node)
    {
        if (data_node->getFlag() == TEXT_NODE)
        {
            ComplexListNode node;
            node.SetStartPos(data_node->getKey());
            node.SetEndPos(data_node->getEndKey());
            node.SetLevel(data_node->getLevel());
			node.setNRE(nre);
//            node.setSkipNode(skipChildren);
            node.setFileIndex(fileIndex);
            int i = in->sortedInsertNode((ComplexListNode *)&node,dataMng,index+1);
            if (!childrenFound)
                firstChild = i;
            index++;
            childrenFound = true;
        }
		//Nuwee changed interface 07/01/03, need parent key for Multicolor
        data_node = dataMng->getNextSibling(fid,data_node->getKey(),parentkey,true);
    }
    return (childrenFound? firstChild : FAILURE);
}

int EvaluatorClass::GetNumChildren(WitnessTree *in, int index, DataMng *dataMng, FileIDType fid)
{
    if (in->isSimple())
        return dataMng->getNumChildren(fid,((ListNode *)in->getNodeByIndex(index))->GetStartPos(),true);
    return dataMng->getNumChildren(fid,((ComplexListNode *)in->getNodeByIndex(index))->GetStartPos(),true);
}

int EvaluatorClass::GetSubtreeDepth(WitnessTree *in, int index, DataMng *dataMng, FileIDType fid)
{
    if (in->isSimple())
        return dataMng->getSubtreeDepth(fid,((ListNode *)in->getNodeByIndex(index))->GetStartPos(),true);
    return dataMng->getSubtreeDepth(fid,((ComplexListNode *)in->getNodeByIndex(index))->GetStartPos(),true);
}


int EvaluatorClass::GetChild(WitnessTree *in, int index, int childIndex, DataMng *dataMng, FileIDType fid, NREType nre)
{
    DM_DataNode *data_node = dataMng->getChild(fid,((ComplexListNode *)in->getNodeByIndex(index))->GetStartPos(),childIndex,true);
    char fileIndex = ((ComplexListNode *)in->getNodeByIndex(index))->getFileIndex();
    if (data_node)
    {
        ComplexListNode node;
        node.SetStartPos(data_node->getKey());
        node.SetEndPos(data_node->getEndKey());
        node.SetLevel(data_node->getLevel());
        node.setFileIndex(fileIndex);
//        node.setSkipNode(true);
		node.setNRE(nre);
        return in->sortedInsertNode((ComplexListNode *)&node, dataMng,index+1);
    }    
    return FAILURE;

}


int EvaluatorClass::getAncs(WitnessTree *in, int index, int levelsUp, DataMng *dataMng, FileIDType fid, NREType nre)
{
    DM_DataNode *data_node;

    if (levelsUp <= 0)
        return FAILURE;
    int levels = 1;
    // CONG YU: May 27, 2003, NodeIDMap has problems?
    // data_node = dataMng->getParent(fid,((ComplexListNode *)in->getNodeByIndex(index))->GetStartPos(),true);
    data_node = dataMng->getParent(fid,((ComplexListNode *)in->getNodeByIndex(index))->GetStartPos(),true);
    char fileIndex = ((ComplexListNode *)in->getNodeByIndex(index))->getFileIndex();
    while (data_node && levels < levelsUp)
    {
        // dataMng->getNodeMap(fid)->deleteNode(data_node->getKey());
        data_node = dataMng->getParent(fid,data_node->getKey(),true);
        levels++;
    }

    if (data_node)
    {
        ComplexListNode node;
        node.SetStartPos(data_node->getKey());
        node.SetEndPos(data_node->getEndKey());
        node.SetLevel(data_node->getLevel());
//        node.setSkipNode(true);
        node.setFileIndex(fileIndex);
		node.setNRE(nre);
        return in->sortedInsertNode(&node,dataMng);
    }
    return FAILURE;
}

void EvaluatorClass::GetAllDesc(WitnessTree *in, int &index, DataMng *dataMng, 
                                FileIDType fid, short localLevel, NREType nre)
{
    short l = (short)(localLevel == -1 ? localLevel : localLevel+1);
    GetAttributes(in,index,dataMng,fid,l,nre);
    DM_DataNode *data_node = dataMng->getChild(fid,((ComplexListNode *)in->getNodeByIndex(index))->GetStartPos(),0,true);
	
	KeyType parentkey = ((ComplexListNode *)in->getNodeByIndex(index))->GetStartPos();//Nuwee added 07/28/03 multicolor

    char fileIndex = ((ComplexListNode *)in->getNodeByIndex(index))->getFileIndex();
    while (data_node)
    {
        ComplexListNode node;
        node.SetStartPos(data_node->getKey());
        node.SetEndPos(data_node->getEndKey());
        node.SetLevel(data_node->getLevel());
		node.setNRE(nre);
        node.SetLocalLevel(l);
        node.setFileIndex(fileIndex);
        int ind = in->sortedInsertNode(&node,dataMng, index+1);
        
        short lev = l;//(l == -1 ? l : l+1);
		if (data_node->getFlag() == ELEMENT_NODE || data_node->getFlag() == DOCUMENT_NODE)
			GetAllDesc(in,ind,dataMng,fid,lev,nre);

		//Nuwee changed interface 07/01/03, need parent key for Multicolor
        data_node = dataMng->getNextSibling(fid,data_node->getKey(),parentkey,true);
        if (data_node)
            index++;
    }
}

void EvaluatorClass::GetAllDescText(WitnessTree *in, int &index, DataMng *dataMng, FileIDType fid, 
                                    short localLevel, NREType nre)
{
    short l = (short)(localLevel == -1 ? localLevel : localLevel+1);
    DM_DataNode *data_node = dataMng->getChild(fid,((ComplexListNode *)in->getNodeByIndex(index))->GetStartPos(),0,true);

	//Nuwee added 07/28/03
	KeyType parentkey = ((ComplexListNode *)in->getNodeByIndex(index))->GetStartPos();
    char fileIndex = ((ComplexListNode *)in->getNodeByIndex(index))->getFileIndex();
    while (data_node)
    {
        int ind;
		short lev;
        ComplexListNode node;
        node.SetStartPos(data_node->getKey());
        node.SetEndPos(data_node->getEndKey());
        node.SetLevel(data_node->getLevel());
		node.setNRE(nre);
        node.SetLocalLevel(l);
//        node.setSkipNode(skipDesc);
        node.setFileIndex(fileIndex);
        ind = in->sortedInsertNode(&node, dataMng,index+1);
        int oldInd = ind;
        lev = (short)(l == -1 ? l : l+1);
        if (data_node->getFlag() != TEXT_NODE)
        {
            GetAllDescText(in,ind,dataMng,fid,lev,nre);
            in->deleteNode(oldInd);
        }
		//Nuwee changed interface 07/01/03, need parent key for Multicolor
        data_node = dataMng->getNextSibling(fid,data_node->getKey(),parentkey,true);
        if (data_node)
            index++;
    }
}





int EvaluatorClass::GetAttributes(WitnessTree *in, int index, DataMng *dataMng, FileIDType fid, 
                                  short localLevel, NREType nre)
{
    in->switchToComplex(dataMng);
    int actualIndex = index;//in->getActualIndex(index);
    if (actualIndex == -1)
        return FAILURE;
    if (in->getNodeByIndex(actualIndex+1))
    {
        if (((ComplexListNode *)in->getNodeByIndex(actualIndex+1))->GetData())
        {
            if (((ComplexListNode *)in->getNodeByIndex(actualIndex+1))->GetData()->getFlag() == ATTRIBUTE_NODE)
                return SUCCESS;
        }
    }

    // Modified by Cong: to avoid warning message of "getting attributes of a non-element node"
    // it may be less efficient due to the fetching of the data??
    DM_DataNode *data_node = NULL;
    if ( ((ComplexListNode *)in->getNodeByIndex(index))->GetData()->getFlag() == ELEMENT_NODE )
    {
        data_node = dataMng->getAttributes(fid,((ComplexListNode *)in->getNodeByIndex(index))->GetStartPos(),true);
    }
    //data_node = dataMng->getAttributes(fid,((ComplexListNode *)in->getNodeByIndex(index))->GetStartPos(),true);
    char fileIndex = ((ComplexListNode *)in->getNodeByIndex(index))->getFileIndex();
    if (data_node)
    {
        actualIndex = index;//in->getActualIndex(index);
        if (actualIndex == -1)
            return FAILURE;
        if (in->getNodeByIndex(actualIndex+1) && 
            data_node->getKey() == ((ComplexListNode *)in->getNodeByIndex(actualIndex+1))->GetStartPos())
        {
           // addDMNode(data_node,(ComplexListNode *)in->getNodeByIndex(actualIndex+1));
            return SUCCESS;
        }
        ComplexListNode node;
        node.SetStartPos(data_node->getKey());
        node.SetEndPos(data_node->getEndKey());
        node.SetLevel(data_node->getLevel());
        node.SetLocalLevel(localLevel);
//        node.setSkipNode(skipAttr);
        node.setFileIndex(fileIndex);
		node.setNRE(nre);
        in->insertNode(index+1,&node,dataMng);
        return SUCCESS;
    }
    return FAILURE;

}

int EvaluatorClass::GetText(WitnessTree *in, int index, DataMng *dataMng, FileIDType fid, short localLevel, NREType nre)
{
    int newInd;
	
    if (findText(in,index,newInd) != NULL)
        return newInd;
    bool textFound = false;
	bool emptyText = true;
    int firstFound = 0;
    DM_DataNode *data_node = dataMng->getChild(fid,((ComplexListNode *)in->getNodeByIndex(index))->GetStartPos(),0,true);

	//Nuwee added 07/28/03
	KeyType parentkey = ((ComplexListNode *)in->getNodeByIndex(index))->GetStartPos();

    char fileIndex = ((ComplexListNode *)in->getNodeByIndex(index))->getFileIndex();
    while (data_node)
    {
		emptyText = false;
        KeyType sk = data_node->getKey();
        if (data_node->getFlag() == TEXT_NODE)
        {
            ComplexListNode node;
            node.SetStartPos(data_node->getKey());
            node.SetEndPos(data_node->getEndKey());
            node.SetLevel(data_node->getLevel());
            node.SetLocalLevel(localLevel);
//            node.setSkipNode(true);
            node.setFileIndex(fileIndex);
			node.setNRE(nre);
            int i = in->sortedInsertNode(&node, dataMng,index+1);
            if (!textFound)
                firstFound = i;
            index++;
            textFound = true;
        }
       
		//Nuwee changed interface 07/01/03, need parent key for Multicolor
        data_node = dataMng->getNextSibling(fid,sk,parentkey,true);
    }
	if (emptyText) return 0;
    return (textFound? firstFound : FAILURE);
}


void EvaluatorClass::setBufPara(int cpChoice, int cp, int rpChoice, float rpRate)
{
    this->capacityChoice = cpChoice;
    this->capacity = cp;
    this->replacementChoice = rpChoice;
    this->replacementPercentage = rpRate;
}

int EvaluatorClass::createRecID(serial_t &recID)
{
/*	rc_t rc = ss_m::create_file(dataMng->getVolumeID(), fileID,ss_m::t_regular);
	if (rc) 
	{
		strstream msg;
		msg<<rc<<'\0';
		globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"Evaluator",__FILE__,msg.rdbuf()->str());
		return FAILURE;				
	}*/
//	cout<<"create file ID: "<<fileID<<endl;
	int maxIDs = gSettings->getIntegerValue("MAX_ID_PER_FILE_EXTERNAL_SORT",1000000);
	rc_t rc = ss_m::create_id(dataMng->getVolumeID(),maxIDs,recID);

	if (rc) 
	{
		strstream msg;
		msg<<rc<<'\0';
		globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"Evaluator",__FILE__,msg.rdbuf()->str());	
		return FAILURE;				
	}
	return maxIDs;
}

int EvaluatorClass::createShoreFiles()
{
	this->fileIDsArrayPtr = 0;
	if (this->fileIDsArray)
		delete [] this->fileIDsArray;

	if (this->fileIDsArraySize == 0)
	{
		this->fileIDsArray = NULL;
		return SUCCESS;
	}

	
	this->fileIDsArray = new serial_t[this->fileIDsArraySize];

	for (int i=0; i<this->fileIDsArraySize; i++)
	{
		rc_t rc = ss_m::create_file(dataMng->getVolumeID(), fileIDsArray[i],ss_m::t_regular);
		if (rc) 
		{
			strstream msg;
			msg<<rc<<'\0';
			globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"Evaluator",__FILE__,msg.rdbuf()->str());
			return FAILURE;				
		}
	}

	return SUCCESS;
}
