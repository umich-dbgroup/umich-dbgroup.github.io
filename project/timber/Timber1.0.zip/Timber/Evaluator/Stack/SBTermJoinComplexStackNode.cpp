/*
COPYRIGHT  � 2000-2004 
THE REGENTS OF THE UNIVERSITY OF MICHIGAN
ALL RIGHTS RESERVED

PERMISSION IS GRANTED TO USE, COPY, CREATE DERIVATIVE WORKS AND REDISTRIBUTE THIS SOFTWARE AND SUCH DERIVATIVE WORKS FOR 
NONCOMMERCIAL EDUCATION AND RESEARCH PURPOSES, SO LONG AS NO FEE IS CHARGED, AND SO LONG AS THE COPYRIGHT NOTICE ABOVE, 
THIS GRANT OF PERMISSION, AND THE DISCLAIMER BELOW APPEAR IN ALL COPIES MADE; AND SO LONG AS THE NAME OF THE UNIVERSITY 
OF MICHIGAN IS NOT USED IN ANY ADVERTISING OR PUBLICITY PERTAINING TO THE USE OR DISTRIBUTION OF THIS SOFTWARE WITHOUT 
SPECIFIC, WRITTEN PRIOR AUTHORIZATION.

THIS SOFTWARE IS PROVIDED AS IS, WITHOUT REPRESENTATION FROM THE UNIVERSITY OF MICHIGAN AS TO ITS FITNESS FOR ANY PURPOSE, 
AND WITHOUT WARRANTY BY THE UNIVERSITY OF MICHIGAN OF ANY KIND, EITHER EXPRESS OR IMPLIED, INCLUDING WITHOUT LIMITATION THE 
IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE. THE REGENTS OF THE UNIVERSITY OF MICHIGAN SHALL 
NOT BE LIABLE FOR ANY DAMAGES, INCLUDING SPECIAL, INDIRECT, INCIDENTAL, OR CONSEQUENTIAL DAMAGES, WITH RESPECT TO ANY CLAIM 
ARISING OUT OF OR IN CONNECTION WITH THE USE OF THE SOFTWARE, EVEN IF IT HAS BEEN OR IS HEREAFTER ADVISED OF THE POSSIBILITY 
OF SUCH DAMAGES.
*/

#include "SBTermJoinComplexStackNode.h"

SBTermJoinComplexStackNode::SBTermJoinComplexStackNode()
{
	SBJoinDescStackNode::SBJoinDescStackNode();
	this->matchCount = NULL;
	this->initialize();
}

SBTermJoinComplexStackNode::~SBTermJoinComplexStackNode()
{
	if (this->matchCount)
	{
		delete [] this->matchCount;
		matchCount = NULL;
	}
}

int SBTermJoinComplexStackNode::getCounterAt(int i)
{
	if (this->matchCount)
	{
		if (i < size) 
			return this->matchCount[i];
	}
	return -1;
}

void SBTermJoinComplexStackNode::setCounterAt(int i, int x)
{
	if (this->matchCount)
	{
		if (i < size) 
		{
			this->matchCount[i] = x;
			if (x > 0)
				this->countersAllZero = false;
		}
	}
}

void SBTermJoinComplexStackNode::incrementCounterAt(int i, int by)
{
	if (this->matchCount)
	{
		if (i < size) 
		{
			this->matchCount[i] += by;
			if (by > 0)
				this->countersAllZero = false;
		}
	}
}

void SBTermJoinComplexStackNode::initialize()
{
	SBJoinDescStackNode::initialize();
	if (this->matchCount)
		memset(matchCount,0,sizeof(int)*size);
	else
		size = 0;
	this->countersAllZero = true;
	isAncs = false;
}

void SBTermJoinComplexStackNode::setIsAncs(bool isAncs)
{
	this->isAncs = isAncs;
}

bool SBTermJoinComplexStackNode::nodeIsAncs()
{
	return isAncs;
}

void SBTermJoinComplexStackNode::setSize(int size)
{
	this->size = size;
	if (this->matchCount)
		delete [] this->matchCount;
	if (size == 0)
		matchCount = NULL;
	else
	{
		matchCount = new int[size];
		memset(matchCount,0,size*sizeof(int));
	}
	this->countersAllZero = true;
}

int SBTermJoinComplexStackNode::getSize()
{
	return this->size;
}

bool SBTermJoinComplexStackNode::areAllCountersZeros()
{
	return this->countersAllZero;
}

void SBTermJoinComplexStackNode::mergeCounters(int *counters)
{
	for (int i=0; i<size; i++)
		this->matchCount[i] += counters[i];
}

int *SBTermJoinComplexStackNode::getCounters()
{
	return this->matchCount;
}

void SBTermJoinComplexStackNode::setCounters(int *counters, bool deleteOld)
{
	if (deleteOld)
		delete [] matchCount;
	matchCount = counters;
}

void SBTermJoinComplexStackNode::prepareToCopyDelete()
{
	this->matchCount = NULL;
	SBJoinDescStackNode::prepareToCopyDelete();
}