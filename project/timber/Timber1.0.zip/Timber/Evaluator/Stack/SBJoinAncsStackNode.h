/*
COPYRIGHT  � 2000-2004 
THE REGENTS OF THE UNIVERSITY OF MICHIGAN
ALL RIGHTS RESERVED

PERMISSION IS GRANTED TO USE, COPY, CREATE DERIVATIVE WORKS AND REDISTRIBUTE THIS SOFTWARE AND SUCH DERIVATIVE WORKS FOR 
NONCOMMERCIAL EDUCATION AND RESEARCH PURPOSES, SO LONG AS NO FEE IS CHARGED, AND SO LONG AS THE COPYRIGHT NOTICE ABOVE, 
THIS GRANT OF PERMISSION, AND THE DISCLAIMER BELOW APPEAR IN ALL COPIES MADE; AND SO LONG AS THE NAME OF THE UNIVERSITY 
OF MICHIGAN IS NOT USED IN ANY ADVERTISING OR PUBLICITY PERTAINING TO THE USE OR DISTRIBUTION OF THIS SOFTWARE WITHOUT 
SPECIFIC, WRITTEN PRIOR AUTHORIZATION.

THIS SOFTWARE IS PROVIDED AS IS, WITHOUT REPRESENTATION FROM THE UNIVERSITY OF MICHIGAN AS TO ITS FITNESS FOR ANY PURPOSE, 
AND WITHOUT WARRANTY BY THE UNIVERSITY OF MICHIGAN OF ANY KIND, EITHER EXPRESS OR IMPLIED, INCLUDING WITHOUT LIMITATION THE 
IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE. THE REGENTS OF THE UNIVERSITY OF MICHIGAN SHALL 
NOT BE LIABLE FOR ANY DAMAGES, INCLUDING SPECIAL, INDIRECT, INCIDENTAL, OR CONSEQUENTIAL DAMAGES, WITH RESPECT TO ANY CLAIM 
ARISING OUT OF OR IN CONNECTION WITH THE USE OF THE SOFTWARE, EVEN IF IT HAS BEEN OR IS HEREAFTER ADVISED OF THE POSSIBILITY 
OF SUCH DAMAGES.
*/


#ifndef __SBJoinAncsStackNode_h
#define __SBJoinAncsStackNode_h

#include "SBJoinDescStackNode.h"

/**
* A stack node used in StackBasedAncs Class. Derived from SBJoinDescStackNode class.
* Contains a flag, two memory buffers, and two disk lists of buffers.
* @see ContainerClass
* @see ShoreList
* @see SBJoinDescStackNode
* @see SimpleStackNode
* @see stack
* @see StackBasedAncs
* @author Shurug Al-Khalifa 
* @version 1.0
*/

class SBJoinAncsStackNode : public SBJoinDescStackNode
{
public:
	/**
	Constructor.
	Initializes data members.
	**/
	SBJoinAncsStackNode();

	/**
	Destructor.
	**/
	~SBJoinAncsStackNode();

	/**
	Process Method.
	Initializes data members.
	**/
	void initialize();

	/**
	Access Method.
	@returns a pointer to self buffer.
	**/
	ContainerClass *GetSelfBuffer();

	/**
	Access Method.
	@returns a pointer to descendant buffer.
	**/
	ContainerClass *GetDescBuffer();

	/**
	Access Method.
	@returns a pointer to self list.
	**/
	ShoreList *GetSelfList();

	/**
	Access Method.
	@returns a pointer to descendant list.
	**/
	ShoreList *GetDescList();

	/**
	Process Method.
	Sets the value of the volume id and the file id used in shore lists.
	@param volumeID is the volume id.
	@param fileID is the current file id.
	**/
	void SetListsVolumeAndFileIDs(lvid_t volumeID,serial_t fileID);

	bool hasBeenJoined();
	void setBeenJoined(bool beenJoined);

	bool IsMarkedForOutput();
	void SetMarkedForOutput(bool markedForOutput);
	void prepareToCopyDelete();
private:
	/**
	a memory buffer 
	**/
	ContainerClass selfBuffer;

	/**
	a memory buffer 
	**/
	ContainerClass descBuffer;

	/**
	a disk list
	**/
	ShoreList selfList;

	/**
	a disk list
	**/
	ShoreList descList;

	bool markedForOutput;

};


#endif