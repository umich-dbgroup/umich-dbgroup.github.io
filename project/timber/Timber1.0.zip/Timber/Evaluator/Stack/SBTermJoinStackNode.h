/*
COPYRIGHT  � 2000-2004 
THE REGENTS OF THE UNIVERSITY OF MICHIGAN
ALL RIGHTS RESERVED

PERMISSION IS GRANTED TO USE, COPY, CREATE DERIVATIVE WORKS AND REDISTRIBUTE THIS SOFTWARE AND SUCH DERIVATIVE WORKS FOR 
NONCOMMERCIAL EDUCATION AND RESEARCH PURPOSES, SO LONG AS NO FEE IS CHARGED, AND SO LONG AS THE COPYRIGHT NOTICE ABOVE, 
THIS GRANT OF PERMISSION, AND THE DISCLAIMER BELOW APPEAR IN ALL COPIES MADE; AND SO LONG AS THE NAME OF THE UNIVERSITY 
OF MICHIGAN IS NOT USED IN ANY ADVERTISING OR PUBLICITY PERTAINING TO THE USE OR DISTRIBUTION OF THIS SOFTWARE WITHOUT 
SPECIFIC, WRITTEN PRIOR AUTHORIZATION.

THIS SOFTWARE IS PROVIDED AS IS, WITHOUT REPRESENTATION FROM THE UNIVERSITY OF MICHIGAN AS TO ITS FITNESS FOR ANY PURPOSE, 
AND WITHOUT WARRANTY BY THE UNIVERSITY OF MICHIGAN OF ANY KIND, EITHER EXPRESS OR IMPLIED, INCLUDING WITHOUT LIMITATION THE 
IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE. THE REGENTS OF THE UNIVERSITY OF MICHIGAN SHALL 
NOT BE LIABLE FOR ANY DAMAGES, INCLUDING SPECIAL, INDIRECT, INCIDENTAL, OR CONSEQUENTIAL DAMAGES, WITH RESPECT TO ANY CLAIM 
ARISING OUT OF OR IN CONNECTION WITH THE USE OF THE SOFTWARE, EVEN IF IT HAS BEEN OR IS HEREAFTER ADVISED OF THE POSSIBILITY 
OF SUCH DAMAGES.
*/

#ifndef __SBTermJoinStackNode_h
#define __SBTermJoinStackNode_h

#include "SimpleStackNode.h"
#include "../Common/ShoreList.h"
/**
* A stack node used in StackBasedTermJoin Class. Derived from SimpleStackNode class.
* Contains a score for this node.
* @see SimpleStackNode
* @see stack
* @see StackBasedTermJoin
* @author Shurug Al-Khalifa 
* @version 1.0
*/
class SBTermJoinStackNode : public SimpleStackNode
{
public:
	/**
	Constructor.
	Initializes data members.
	**/
	SBTermJoinStackNode();
	
	/**
	Destructor.
	**/
	virtual ~SBTermJoinStackNode();

	/**
	Process Method.
	initializes the data members.
	**/
	void initialize();

	/**
	Process Method.
	sets the size of the count array.
	@param size is the size of the count array.
	**/
	void setSize(int size);

	/**
	Access Method.
	@returns the size of the count array.
	**/
	int getSize();

	/**
	Access Method.
	@returns the counter at index i.
	**/
	int getCounterAt(int i);

	/**
	Process Method.
	sets the count at index i in the array to value x.
	@param i is the index of the counter in the array.
	@param x is the new value for the counter.
	**/
	void setCounterAt(int i, int x);

	/**
	Process Method.
	increments the counter at index i in the array.
	@param i is the index of the counter to be incemented.
	@param by is the amount for the counter to be incremented by
	**/
	void incrementCounterAt(int i, int by = 1);

	/**
	Access Method.
	@returns true if all counters are zeros, returns false otherwise.
	**/
	bool areAllCountersZeros();

	bool nodeIsAncs();
	void setIsAncs(bool isAncs);

	ContainerClass *GetBuffer(){return NULL;};
	ShoreList *GetListOfBuffers(){return NULL;};

//	void mergeBuffersAndLists(ContainerClass *buffer, ShoreList *listOfBuffers, serial_t &id, serial_t fileID,
//		lvid_t volumeID){};

	void mergeCounters(int *counters);

	int *getCounters();
	void setCounters(int *counters, bool deleteOld = true);
	void prepareToCopyDelete();
private:
	int *matchCount;
	int size;
	bool countersAllZero;
	bool isAncs;
};

#endif