/*
COPYRIGHT  (c) 2000-2004 
THE REGENTS OF THE UNIVERSITY OF MICHIGAN
ALL RIGHTS RESERVED

PERMISSION IS GRANTED TO USE, COPY, CREATE DERIVATIVE WORKS AND
REDISTRIBUTE THIS SOFTWARE AND SUCH DERIVATIVE WORKS FOR NONCOMMERCIAL
EDUCATION AND RESEARCH PURPOSES, SO LONG AS NO FEE IS CHARGED, AND SO LONG
AS THE COPYRIGHT NOTICE ABOVE, THIS GRANT OF PERMISSION, AND THE
DISCLAIMER BELOW APPEAR IN ALL COPIES MADE; AND SO LONG AS THE NAME OF THE
UNIVERSITY OF MICHIGAN IS NOT USED IN ANY ADVERTISING OR PUBLICITY
PERTAINING TO THE USE OR DISTRIBUTION OF THIS SOFTWARE WITHOUT SPECIFIC,
WRITTEN PRIOR AUTHORIZATION.

THIS SOFTWARE IS PROVIDED AS IS, WITHOUT REPRESENTATION FROM THE
UNIVERSITY OF MICHIGAN AS TO ITS FITNESS FOR ANY PURPOSE, AND WITHOUT
WARRANTY BY THE UNIVERSITY OF MICHIGAN OF ANY KIND, EITHER EXPRESS OR
IMPLIED, INCLUDING WITHOUT LIMITATION THE IMPLIED WARRANTIES OF
MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE. THE REGENTS OF THE
UNIVERSITY OF MICHIGAN SHALL NOT BE LIABLE FOR ANY DAMAGES, INCLUDING
SPECIAL, INDIRECT, INCIDENTAL, OR CONSEQUENTIAL DAMAGES, WITH RESPECT TO
ANY CLAIM ARISING OUT OF OR IN CONNECTION WITH THE USE OF THE SOFTWARE,
EVEN IF IT HAS BEEN OR IS HEREAFTER ADVISED OF THE POSSIBILITY OF SUCH
DAMAGES.
*/

/**
 * @author Yuqing (Melanie) Wu
 */

#ifndef __NodeIDMap_H
#define __NodeIDMap_H

#include <map>
#include "DoublyLinkedList.h"

//Global settings class
#include "../Utilities/Settings.h"
extern Settings* gSettings;

//Global error handling class
#include "../Utilities/ErrorInfoClass.h"
extern ErrorInfoClass globalErrorInfo;

// the choice for capacity
#define NODE_NUMBER_CAPACITY		0
#define BUFFER_SIZE_CAPACITY		1

// the choice for replacement policy 
#define REPLACEMENT_POLICY_DUMMY	0
#define REPLACEMENT_POLICY_LRU		1

typedef std::map <KeyType, NodeIDMapItem*, ltKeyType> KeyItemMapType;

/**
* class NodeIDMap
* 
* NodeIDMap acts as a buffer in timber. It keeps the nodes that have been bought from the disk for later fetching and
* controls the number/size of nodes in memory.
* 
* Currently, the replacement policy implemented is LRU. A doubly linked list is used to keep the LRU order of
* the nodes, according to the time when the node is fetched/accessed. 
*
* A map is used to map the key of a node to a pointer that point to the in-memory locate where the content of the node is. 
* This is used to achieve fast key-based access.
* 
* @see NodeIDMapItem
* @see DataMng
* @see DoublyLinkedList
*/

class NodeIDMap
{
public:
	/**
	* Constructor
	* 
	* Initialize the NodeIDMap with the the management choices, including how the capacity is measured
	* and how the replacement is to be done. 
	* 
	* @param capacityChoice The choice on how the capacity of the NodeIDMap is measured, by the number of nodes or the size of nodes.
	* @param capacity The capacity of the NodeIDMap, in node count (for NODE_NUMBER_CAPACITY) and in bytes for (BUFFER_SIZE_CAPACITY).
	* @param rpPolicy The choice of the replacement policy (The one currently implemented is LRU).
	* @param LRURemove The ratio of nodes to be removed on one LRU replacement. A number between 0 and 1. 
	* 
	* For each of these parameters, if the value given is less than 0, the default value will be used. 
	*/	
	NodeIDMap(int capacityChoice,
		int capacity, 
		int rpPolicy, 
		float LRURemove);
	
	/**
	* Destructor
	* Release the keyMap and the doubly-linked list
	*/
	~NodeIDMap(void);

	/**
	* Process Method
	* Given the node key, get the node from NodeIDMap, return NULL if it is not in there.
	* 
	* @param key The key of the node to be looked for
	* @returns The node with the given key, NULL if the node is not in the NodeIDMap
	*/	
	DM_DataNode* getNode(KeyType key);

	/**
	* Process Method
	* Insert a node to the NodeIDMap.  
	* It may cause timestamp increase (if the current timestamp already has a certain number of nodes
	* It may also cause buffer replacement, if the buffer is full.
	* 
	* @param pNode The point to the node to be inserted to the NodeIDMap
	*/
	void insertNode(DM_DataNode* pNode);

	/**
	* Process Method
	* Remove a node from the NodeIDMap
	*
	* @param key The key of the node  to be removed.
	*/
	void deleteNode(KeyType key);

	/** 
	* Process Method
	* 
	* Get a list of nodes within the key range. The nodes picked are put in nodelist.
	* 
	* @param start/end The boundary of the nodes to be picked.
	* @param nodelist A list that is prepared to hold the nodes. Nodes that are picked will be put into the list as return value. 
	* @param listLen The length of the list. This gives the boundary of the number of list to be picked at a time. 
	* @returns The number of nodes picked, upto listLen. 
	*/
	int getNodesInRange(KeyType start, KeyType end, DM_DataNode** nodelist, int listLen);	
	
	
	/**
	* Debug Method
	* Print the content of the NodeIDMap
	*/
	void printContent();

	/**
	* Debug Methods
	* The following methods are used to get the statistical information about the NodeIDMap. It has nothing to do with
	* how the NodeIDMap works. It is just to monitor the performance of the the NodeIDMap. 
	*/
	int getSizeRequirement();
	int getReplacementTimes();


private:
	/**
	* The choice on how the capacity of the NodeIDMap is measured, by the number of nodes or the size of nodes.
	*/
	int capacityChoice;

	/**
	* The capacity of the NodeIDMap, in node count (for NODE_NUMBER_CAPACITY) and in bytes for (BUFFER_SIZE_CAPACITY).
	*/
	int capacity;

	/**
	* The choice of the replacement policy (The one currently implemented is LRU).
	*/
	int replacementPolicy;

	/**
	* The ratio of nodes to be removed on one LRU replacement. A number between 0 and 1. 
	*/ 
	float LRURemovePercentage;

	/**
	* A map that maps the key of a node to the information about the node, in support of fast node access. 
	*/
	KeyItemMapType* keyMap;

	/**
	* A doubly linked list that keep the LRU order of nodes, based on the time they are inserted/visited. 
	*/
	DoublyLinkedList* dList;

	/**
	* crtSize is uused to keep track the current status of the buffer (to help determine whether it is full).
	* It maybe the node count, or node size accumulation.
	*/
	int crtSize;

	/**
	* Process Method
	* Check whether the buffer is full after a new node is in. 
	* 
	* Whether the buffer is full depends on the capacity choice (how the size is messured) and the
	* actual space taken by the nodes. 
	*
	* @param nodeSize The size of the node to be inserted to the buffer. 
	* @returns A  boolean value which indicate whether the buffer will be full after the node is in. 
	*/
	bool bufferIsFull(int nodeSize);

	/**
	* Process Method
	* Handles buffer replacement
	* 
	* The currently implemented replacement strategy is LRU. Instead of replace nodes one at a time, I choose
	* to swap out a portion of  the buffer (given by the replacement rate) when the buffer is full. 
	*/
	void bufferReplacement();

	/**
	* The following are for the statistical information related to the buffer control.
	*/
	int crtSizeRequirement;
	int peakSizeRequirement;
	int replacementTimes;

};

#endif
