/*
COPYRIGHT  (c) 2000-2004 
THE REGENTS OF THE UNIVERSITY OF MICHIGAN
ALL RIGHTS RESERVED

PERMISSION IS GRANTED TO USE, COPY, CREATE DERIVATIVE WORKS AND
REDISTRIBUTE THIS SOFTWARE AND SUCH DERIVATIVE WORKS FOR NONCOMMERCIAL
EDUCATION AND RESEARCH PURPOSES, SO LONG AS NO FEE IS CHARGED, AND SO LONG
AS THE COPYRIGHT NOTICE ABOVE, THIS GRANT OF PERMISSION, AND THE
DISCLAIMER BELOW APPEAR IN ALL COPIES MADE; AND SO LONG AS THE NAME OF THE
UNIVERSITY OF MICHIGAN IS NOT USED IN ANY ADVERTISING OR PUBLICITY
PERTAINING TO THE USE OR DISTRIBUTION OF THIS SOFTWARE WITHOUT SPECIFIC,
WRITTEN PRIOR AUTHORIZATION.

THIS SOFTWARE IS PROVIDED AS IS, WITHOUT REPRESENTATION FROM THE
UNIVERSITY OF MICHIGAN AS TO ITS FITNESS FOR ANY PURPOSE, AND WITHOUT
WARRANTY BY THE UNIVERSITY OF MICHIGAN OF ANY KIND, EITHER EXPRESS OR
IMPLIED, INCLUDING WITHOUT LIMITATION THE IMPLIED WARRANTIES OF
MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE. THE REGENTS OF THE
UNIVERSITY OF MICHIGAN SHALL NOT BE LIABLE FOR ANY DAMAGES, INCLUDING
SPECIAL, INDIRECT, INCIDENTAL, OR CONSEQUENTIAL DAMAGES, WITH RESPECT TO
ANY CLAIM ARISING OUT OF OR IN CONNECTION WITH THE USE OF THE SOFTWARE,
EVEN IF IT HAS BEEN OR IS HEREAFTER ADVISED OF THE POSSIBILITY OF SUCH
DAMAGES.
*/

/**
 * @author Yuqing (Melanie) Wu
 */

#include "StdAfx.h"
#include "DoublyLinkedList.h"

/**
* class DoublyLinkedList
* 
* This doubly linked list has NodeIDMapItem as the unit in the list. It helps maintain 
* the LRU order of the items. 
* 
* This class provide some basic functions of doubly linked list, like get from head, insert from tail,
* delete from middle.... etc. 
* 
* @see NodeIDMapItem
* @see NodeIDMap
*/

/**
* Constructor
* Initialize an empty list
*/
DoublyLinkedList::DoublyLinkedList(void)
{
	head = NULL;
	tail = NULL;
}

DoublyLinkedList::~DoublyLinkedList(void)
{
	// Yunyao - 04-27-04 - Added to avoid memory leak
	while(this->head != NULL)
		delete this->deleteAtHead();
}

/**
* Access Method
* Get the item at the head of the list
*/
NodeIDMapItem* DoublyLinkedList::getHead()
{
	return this->head;
}

/**
* Process Method
* Insert a new item at the tail.
* @param newitem The item to be inserted
*/

void DoublyLinkedList::insertAtTail(NodeIDMapItem* newitem)
{
	newitem->setNext(NULL);

	if (this->head == NULL)
	{
		this->head = newitem;
		this->tail = newitem;
		newitem->setPrev(NULL);
	}
	else
	{
		newitem->setPrev(tail);
		this->tail->setNext(newitem);
		this->tail = newitem;
	}
}

/**
* Process Method
* Delete the item at the head
* @returns The item at the head of the list, which is to be deleted. 
*/
NodeIDMapItem* DoublyLinkedList::deleteAtHead()
{
   NodeIDMapItem* toreturn = this->head;
	if (this->head != NULL)
	{
		if (this->head == this->tail)
		{
			this->head = NULL;
			this->tail = NULL;
		}
		else
		{
			NodeIDMapItem* nextItem = this->head->getNext();
			nextItem->setPrev(NULL);
			this->head = nextItem;
		}
	}

	return toreturn;
}

/**
* Process Method
* Move a node from anywhere in the list to the tail of the list. 
* This is done by removing it from its current place and insert it at the tail
*/
void DoublyLinkedList::moveToTail(NodeIDMapItem* item)
{
	this->deleteItem(item);
	this->insertAtTail(item);
}

/**
* Process Method
* Given an item, remove it from the list
* @param item The item to be removed. 
*/
void DoublyLinkedList::deleteItem(NodeIDMapItem* item)
{
	NodeIDMapItem* prev = item->getPrev();
	NodeIDMapItem* next = item->getNext();

	if ((prev != NULL) && (next != NULL))
	{
		prev->setNext(next);
		next->setPrev(prev);
	}
	else if ((prev == NULL) && (next != NULL))
	{
		next->setPrev(prev);
		this->head = next;
	}
	else if ((prev != NULL) && (next == NULL))
	{
		prev->setNext(next);
		this->tail = prev;
	}
	else
	{
		this->head = NULL;
		this->tail = NULL;
	}
}

/**
* Debug Method
* Print the content of the list
*/
void DoublyLinkedList::printContent()
{
	cout << endl << endl << endl;
	if (this->head == NULL)
	{
		cout << "the list is empty" << endl;
		return;
	}

	NodeIDMapItem* crtItem = head;
	while (crtItem != NULL)
	{
		cout << "	key = " << crtItem->getKey().toString() << endl;
		crtItem = crtItem->getNext();
	}
}