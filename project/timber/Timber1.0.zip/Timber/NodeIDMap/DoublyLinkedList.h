/*
COPYRIGHT  (c) 2000-2004 
THE REGENTS OF THE UNIVERSITY OF MICHIGAN
ALL RIGHTS RESERVED

PERMISSION IS GRANTED TO USE, COPY, CREATE DERIVATIVE WORKS AND
REDISTRIBUTE THIS SOFTWARE AND SUCH DERIVATIVE WORKS FOR NONCOMMERCIAL
EDUCATION AND RESEARCH PURPOSES, SO LONG AS NO FEE IS CHARGED, AND SO LONG
AS THE COPYRIGHT NOTICE ABOVE, THIS GRANT OF PERMISSION, AND THE
DISCLAIMER BELOW APPEAR IN ALL COPIES MADE; AND SO LONG AS THE NAME OF THE
UNIVERSITY OF MICHIGAN IS NOT USED IN ANY ADVERTISING OR PUBLICITY
PERTAINING TO THE USE OR DISTRIBUTION OF THIS SOFTWARE WITHOUT SPECIFIC,
WRITTEN PRIOR AUTHORIZATION.

THIS SOFTWARE IS PROVIDED AS IS, WITHOUT REPRESENTATION FROM THE
UNIVERSITY OF MICHIGAN AS TO ITS FITNESS FOR ANY PURPOSE, AND WITHOUT
WARRANTY BY THE UNIVERSITY OF MICHIGAN OF ANY KIND, EITHER EXPRESS OR
IMPLIED, INCLUDING WITHOUT LIMITATION THE IMPLIED WARRANTIES OF
MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE. THE REGENTS OF THE
UNIVERSITY OF MICHIGAN SHALL NOT BE LIABLE FOR ANY DAMAGES, INCLUDING
SPECIAL, INDIRECT, INCIDENTAL, OR CONSEQUENTIAL DAMAGES, WITH RESPECT TO
ANY CLAIM ARISING OUT OF OR IN CONNECTION WITH THE USE OF THE SOFTWARE,
EVEN IF IT HAS BEEN OR IS HEREAFTER ADVISED OF THE POSSIBILITY OF SUCH
DAMAGES.
*/

/**
 * @author Yuqing (Melanie) Wu
 */

#ifndef __DoublyLinkedList_H
#define __DoublyLinkedList_H

#include "NodeIDMapItem.h"

/**
* class DoublyLinkedList
* 
* This doubly linked list has NodeIDMapItem as the unit in the list. It helps maintain 
* the LRU order of the items. 
* 
* This class provide some basic functions of doubly linked list, like get from head, insert from tail,
* delete from middle.... etc. 
* 
* @see NodeIDMapItem
* @see NodeIDMap
*/

class DoublyLinkedList
{
public:
	/**
	* Constructor
	* Initialize an empty list
	*/
	DoublyLinkedList(void);
	~DoublyLinkedList(void);

	/**
	* Access Method
	* Get the item at the head of the list
	*/
	NodeIDMapItem* getHead();

	/**
	* Process Method
	* Insert a new item at the tail.
	* @param newitem The item to be inserted
	*/
	void insertAtTail(NodeIDMapItem* newitem);

	/**
	* Process Method
	* Delete the item at the head
	* @returns The item at the head of the list, which is to be deleted. 
	*/
	NodeIDMapItem* deleteAtHead();

	/**
	* Process Method
	* Move a node from anywhere in the list to the tail of the list. 
	* This is done by removing it from its current place and insert it at the tail
	*/
	void moveToTail(NodeIDMapItem* item);

	/**
	* Process Method
	* Given an item, remove it from the list
	* @param item The item to be removed. 
	*/
	void deleteItem(NodeIDMapItem* item);

	/**
	* Debug Method
	* Print the content of the list
	*/	
	void printContent();

private:
	/**
	* The head of the list
	*/
	NodeIDMapItem* head;

	/** 
	* The tail of the  ilst
	*/
	NodeIDMapItem* tail;
};

#endif
