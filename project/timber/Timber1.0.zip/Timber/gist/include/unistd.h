/* Empty file needed for some generated files. */
