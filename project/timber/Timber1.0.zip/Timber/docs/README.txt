OPTION #1:

1. Install doxygen
	- visit http://www.stack.nl/~dimitri/doxygen/ and get the most recent
	windows installer of the "binaries" download page
	(currently, the setup program doxygen-1.3-setup.exe is on our server)

2. install graphviz (this is used by doxygen to draw the graphs/trees, etc)
	- download the windows installer from
	http://www.research.att.com/sw/tools/graphviz/ 
	(currently, the setup program graphviz-1.9.exe is on our server)

3. install perl for windows (so that you can run the perl script in 3)
	http://www.activestate.com/

4. install Greg Engelstad perl script to create documentation by parsing 
the solution (.sln) file
	- download a zip file at
	http://www.stack.nl/~dimitri/doxygen/dl/sln_reader.zip
	(currently, this zip file is sln_reader.zip on our server)

	take a look at the readme file for this script (as indicated there, you'll
	need to download msxsl.exe and msxml4 if you don't already have them)
	(currently, the setup program msxml.msi is on our server.
	this is MSXML 4.0 Service Pack 2 (Microsoft XML Core Services))
	(also, msxsl.exe is currently on our server. put this in
	C:\Program Files\Microsoft\MSXSL\)

5. run the perl script to generate documentation
	for example: MakeDox.pl D:\Timber\Timber.sln D:\Timber-Docs
	(where D:\Timber-Docs already exists... also, I would suggest providing
	the full path to the solution file, as with D:\Timber\Timber.sln, otherwise
	the perl script needs to be in the same directory as the solution file)

	(note: check your <project_name>.err files to find out any mistakes you've
	made in your documentation)

	if the script is run again, it checks the timestamps of files before
	trying to update the documentation.

	UPDATE: use MakeDox-andy.pl rather than MakeDox.pl, the html
	created will be more portable (MakeDox-andy.pl uses relative URLs, 
	whereas MakeDox.pl uses absolute paths in the TIMBERIndex.html page.
	This would create problems if you were to move the documentation to another 
	machine/location). You can always run this after creating the documentation
	repository with MakeDox.pl, and it will just update the TIMBERIndex.html page.

##########

OPTION #2
(potentially much easier & more convenient than OPTION #1, but I haven't tried it yet)

you can also take a look at Steve King's add-ins for visual studio .net
(this gives you convenient access to doxygen functionality from with visual studio)
	- download the windows installer from
	http://www.codeproject.com/macro/KingsTools.asp
	(currently, the setup program KingsSetup.msi is on our server, but you
	should probably still visit the web page above to read about the add-in)

	this installer contains doxygen and dot (part of graphviz) so you won't
	need to install those separately if you use this.

##########

AUTOMATION NOTES (you probably don't care about this):

	the easiest way to do sourcesafe automation is to write/register a visual
	basic DLL.  info is on the microsoft web site at:
	http://msdn.microsoft.com/library/default.asp?url=/library/en-us/dnvss/html/vssauto.asp
	(an older document is here:
	http://msdn.microsoft.com/library/default.asp?url=/library/en-us/dnvss/html/msdn_vssole.asp
	)

	NOTE:
	either the server share directory path will have to have spaces removed from
	it (since the automated documentation creation programs don't seem to like 
	spaces), or a virtual directory will have to be used for IIS, where the 
	actual documentation is kept some place like D:\Timber-Docs, and the virtual
	directory Timber-Docs just points to it...
