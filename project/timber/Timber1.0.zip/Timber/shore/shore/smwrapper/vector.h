#ifndef VECTOR_H
#define VECTOR_H

#include<assert.h>
#include<new>

template<class T> class Vector {
public:
	
	// Default constructor
	Vector(int init_cnt=16);
	// Destructor
	~Vector();
	
	// Operators
	T& operator[](unsigned index) const;
	
	// Clear all elements
	void clear();
	
	// Return the number of elements in the vector.
	unsigned count() const;

	// Return the current size of the vector

	unsigned size() const;
	
	// Add the item to the end of the vector
	void push_back(const T& item);
	
	// Remove the last item in the vector
	void pop_back();

	// Quicksort the elements in the vector
	void quickSort(int (*compare)(const void *arg1, const void *arg2));

	void flatten(char * buffer) const; // Flatten the tuple's members into the buffer

	void unflatten(const char * buffer); // Read attributes from buffer

	unsigned int getFlattenedSize() const; // Returns the size in bytes of the flattened structure

	void copyArray(T * destination); // Copies the array to the destination address
protected:
private:
	// Hide the copy constructor for now
	Vector(const Vector&);

	// Hide the assignment operator for now
	unsigned& operator=(Vector& vec);
	
	// Enlarge the contiguous memory area
	void ExpandMem();

private:
	// Store the metadata at the starting address of the page.
	// the data vector is immediately after it
	char* mpBlock;
	size_t mBlockSz;
	T* mpVecData;
	unsigned mCount;
	unsigned mCountMax;
};

// Inline methods
template<class T>
inline
Vector<T>::Vector(int init_cnt) {
	// Create the initial memory block
	mBlockSz = init_cnt*sizeof(T);
	if (mBlockSz > 0) {
		mpBlock = new char[mBlockSz];
	}
	else {
		mpBlock = 0;
	}
	mpVecData = reinterpret_cast<T*>(mpBlock);
	mCount = 0;
	mCountMax = init_cnt;
}

template<class T>
inline
Vector<T>::~Vector() {
	delete [] mpBlock;
}

template<class T>
inline
T& Vector<T>::operator[](unsigned index) const {
	assert(index < mCount);
	return mpVecData[index];
}

template<class T>
inline
void Vector<T>::clear() {
	mCount = 0;
}


template<class T>

inline 

unsigned Vector<T>::count() const {

	return mCount;

}


template<class T> 
inline 
unsigned Vector<T>::size() const {
	return mCountMax;
}

template<class T>
inline
void Vector<T>::push_back(const T& item) {
	assert(mCount <= mCountMax);
	// If full, we must allocate another page and copy the elements into
	// the new page
	if (mCount >= mCountMax) {
		ExpandMem();
	}
	// At this point, there must be enough room to store the element
	assert(mCount < mCountMax);
	// mpVecData[mCount] = new T(item);
	new (mpVecData+mCount) T(item);
	mCount++;
}

template<class T>
inline
void Vector<T>::pop_back() {
	assert(mCount <= mCountMax);
	--mCount;
}

template<class T>
inline
void Vector<T>::ExpandMem() {
	// Create a block that is twice the size of the original
	size_t new_blk_sz = 2*mBlockSz;
	char* new_blk = new char[new_blk_sz];
	assert(new_blk);
	// Copy all elements over to new space
	memcpy(new_blk, mpBlock, mBlockSz);
	mBlockSz = new_blk_sz;
	delete [] mpBlock;
	mpBlock = new_blk;
	mpVecData = reinterpret_cast<T*>(mpBlock);
	mCountMax *= 2;
}



// Flatten the tuple's members into the buffer
template<class T>
inline
void Vector<T>::flatten(char * buffer) const {
	char * tempPtr = buffer;

	memcpy(tempPtr, &mCount, sizeof(mCount));
	tempPtr+=sizeof(mCount);

	memcpy(tempPtr, &mCountMax, sizeof(mCountMax));
	tempPtr+=sizeof(mCountMax);

	memcpy(tempPtr, mpBlock, mBlockSz);
}



// Read attributes from buffer
template<class T>
inline
void Vector<T>::unflatten(const char * buffer) {

	// Delete old block

	if (mpBlock)
		delete [] mpBlock;

	const char * tempPtr = buffer;

	memcpy(&mCount, tempPtr, sizeof(mCount));
	tempPtr+=sizeof(mCount);

	memcpy(&mCountMax, tempPtr, sizeof(mCountMax));
	tempPtr+=sizeof(mCountMax);

	// Allocate the memory block
	mBlockSz = mCountMax*sizeof(T);
	mpBlock = new char[mBlockSz];
	mpVecData = reinterpret_cast<T*>(mpBlock);

	memcpy(mpBlock, tempPtr, mBlockSz);
}

// Returns the size in bytes of the flattened structure
template<class T>
inline
unsigned int Vector<T>::getFlattenedSize() const {
	return (sizeof(mCount) + sizeof(mCountMax) + mBlockSz);
}

template<class T>
inline
// Copies the array to the destination address
void Vector<T>::copyArray(T * destination) {
	if (destination) {
		memcpy(destination, mpVecData, sizeof(T) * mCount);
	}
}

#endif
