
#ifndef _MY_TIMER_H_ 
#define _MY_TIMER_H_ 

#include <time.h>

#ifndef _MSC_VER
#include <sys/resource.h>
#endif

#include <sys/types.h>
#include <sys/timeb.h>

// Measures the time in milliseconds (the finest resolution on NT)
class MilliTimer
{
public:
   MilliTimer() {reset();}
   void reset() 
   { 
#ifdef _MSC_VER
      _ftime(&start); 
#else
      getrusage(RUSAGE_SELF, &start); 
#endif
   }
   
   // Returns the time in milli seconds
   double stop() 
   { 
#ifdef _MSC_VER
      _ftime(&finish); 
      return (finish.time - start.time)*1000.0 + 
         (finish.millitm - start.millitm);
#else
      getrusage(RUSAGE_SELF, &finish); 
      struct rusage diff;
      diff.ru_utime.tv_sec = finish.ru_utime.tv_sec-start.ru_utime.tv_sec;
      diff.ru_utime.tv_usec = finish.ru_utime.tv_usec-start.ru_utime.tv_usec;
      diff.ru_stime.tv_sec = finish.ru_stime.tv_sec-start.ru_stime.tv_sec;
      diff.ru_stime.tv_usec = finish.ru_stime.tv_usec-start.ru_stime.tv_usec;
      
      double user_time =
         (double)diff.ru_utime.tv_sec*1000.0+(double)diff.ru_utime.tv_usec/1000.0;
      double sys_time =
         (double)diff.ru_stime.tv_sec*1000.0+(double)diff.ru_stime.tv_usec/1000.0;
      return user_time + sys_time;
#endif
   }
   
private:
#ifdef _MSC_VER
   struct _timeb start, finish;
#else
   struct rusage start, finish;
#endif
};

#endif
