#ifndef  TBTREE_H
#define  TBTREE_H

#include "geometry.h"
#include "smwrapper.h"


const int NUM_SPLIT_NODES = 2;

class LeafNode;
class NonLeafNode;
class ShorePointer;

class ShorePointer
{

 public: 
  
  void setPointer( LeafNode* Pointer ); // Used for setting the ptr value 
  // for in-memory version
  void setPointer( NonLeafNode* Pointer );

  LeafNode*    DereferenceLeafNode() const;
  NonLeafNode* DereferenceNonLeafNode() const;

 private: 
  char *ptr;            // this is a pointer to a node in the in-memory version
  // LeafNode *ptr;     // this is a pointer to a node in the in-memory version
  // NonLeafNode *ptr;  // this is a pointer to a node in the in-memory version
  // page_t pid; // shore page id.
};


// Entry that's stored in NonLeafNodes
struct IndexEntry {
  MBB mbb;
  ShorePointer child;
};


const int PageSize = 8192;
const int LeafNodeFanout = (PageSize - sizeof(unsigned)*3 -
			    sizeof (ShorePointer)*3)/sizeof (Trajectory);
const int MaxNonLeafNodeFanout = (PageSize - sizeof(unsigned)*3 -
			    sizeof (ShorePointer))/sizeof (IndexEntry);



class LeafNode {

  friend class DebugTBTree;
  friend class QuerySupport;

 public:
  LeafNode();
  ~LeafNode();
  
  bool insertEntry(const Trajectory & NewEntry);
  bool getEntry(const unsigned int index, Trajectory & entry) const;
  unsigned int getNumEntries() const;
  bool calculateBoundingBox(MBB & mbb) const; 	// Calculates the mbb for all entries
  
  void setPreviousPage(LeafNode * previous);
  void setNextPage    (LeafNode * next);
  void setParentNode  (NonLeafNode * parentNode );
  NonLeafNode* getParentNode() const;
  
  
 private:
  Trajectory entries[LeafNodeFanout];    // Array of Trajectories
  unsigned int capacity;                 // Remeber our capacity
  unsigned int numEntries;               // Number of children currently stored
  ShorePointer PreviousPage;
  ShorePointer NextPage;
  
  ShorePointer Parent;     // This really only exists because
                           // insertions require MBB 
                           // adjustments up through the whole tree
};


class NonLeafNode {

  friend class DebugTBTree;
  friend class QuerySupport;

 public:
  NonLeafNode(const unsigned int size, const unsigned int _level);
  ~NonLeafNode();
  
  bool insertEntry(LeafNode    * entry);
  bool insertEntry(NonLeafNode * entry);
  bool getEntry(const unsigned int index, LeafNode    * entryPointer) const;
  bool getEntry(const unsigned int index, NonLeafNode * entryPointer) const;
  bool calculateBoundingBox(MBB & mbb) const; // Calculates the mbb for all entries
	
  unsigned int getNumEntries() const;
  
  void setParentNode(NonLeafNode * parentNode);
  void adjustMBB ();

  NonLeafNode* getParentNode() const;
  unsigned int getLevel()      const;


  LeafNode* FindTrajectory ( const STPoint & point, const int & object_id ) const;
  
 private:
  unsigned int level;      // Holds the level that this node is at in the tree
  unsigned int capacity;   // Remeber the capacity of this node
  unsigned int numEntries; // Number of children
  
  IndexEntry   entries[MaxNonLeafNodeFanout];    // Holds our entries
  ShorePointer Parent;                        // Pointer back up the tree
};


// Linked list node describing results of a query
struct QueryResultNode {
  Trajectory trj;
  QueryResultNode *next;
};

// Stores query results
class QueryResults {
 public:
  QueryResults();
  ~QueryResults();
  bool push(const Trajectory trj); // Pushes result onto result stack
  bool pop(Trajectory & trj);      // Pops result off top of result stack
  void clear();                    // Clears all results
  
  bool resetIterator();                    // Point to first entry
  bool advanceIterator();                  // Advance iterator
  bool getIterator(Trajectory & trj);      // Get current value

 private:
  bool acceptDuplicates; // True if results accepts duplicate entries
  
  QueryResultNode *head;
  QueryResultNode *iterator;
};

// TBTree Structure
class TBTree {

  friend class DebugTBTree;

 public:
  TBTree(const unsigned int _fanout=2);
  ~TBTree();
  
  bool insert(const Trajectory & trj); // Insert a new entry
  void destroy();                      // Destroys the tree
 
  // Will return Results loaded with all Trajectories that
  // overlap the range given by mbb
  bool rangeQuery( const MBB & mbb, QueryResults & Results ) const;
 
 private:
  
  bool increaseHeight();   // Increases the height of the tree by one level
  NonLeafNode* extendNode( NonLeafNode & Node, unsigned int level=1 ); 
  
  LeafNode*    FindTrajectory ( Trajectory & trj ) const;
  NonLeafNode* FindEmptyNode ( NonLeafNode & Node );
  LeafNode*    CreateNewLeafNode ();
  
  
  /* NOTE: Due to the design of a TB-Tree, the tree only grows
     up and to the right. This means that any one time, there
     is at most one level 1 NonLeafNode with room for more
     LeafNodes under it. All new leaf nodes will be inserted
     at this location
  */
  
  NonLeafNode * RootPointer;             // Root of TB-Tree
  NonLeafNode * CurrentOpenNodePointer;  // Current place for updates
  
  unsigned int height;    // Height of TB-Tree
  unsigned int fanout;    // Fan out at each node
  unsigned int pagesize;  // Number of nodes that can fit on a leaf page
  
  
  BError::Status writeToDisk(stid_t& idxFile); 
  
};

// Friend class of the Leaf/NonLeaf Nodes that add
// functionality required for supporting various queries
// implemented as a friend class so as not to obscure basic
// functionality of Leaf/NonLeaf Nodes with the various different
// functions required by queries
class QuerySupport {

 public:
  
  // Support for Range Queries
  bool RangeQuery ( QueryResults & Results, const MBB & range, NonLeafNode & Node ) const;
  bool RangeQuery ( QueryResults & Results, const MBB & range, LeafNode & Node ) const;


};


#endif


