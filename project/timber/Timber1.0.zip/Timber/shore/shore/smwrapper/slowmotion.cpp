/////////////////////////////////////////////////////////////////
// smboot.cpp
/////////////////////////////////////////////////////////////////

#include "smboot.h"
#include "slowmotion.h"
#include "smwrapper.h"
#include "smstats.h"

#include "tbtree.h"
//#include "debug-tbtree.h"
//#include <iostream.h>
#include <iostream>
using namespace std;

// global generator
int __mycounter__ = 0; 
static const unsigned ArrSize = 5; // Size of the array (for TestPersistentType).
static const char* FileName = "test";

/************* Is this needed anymore -jmp ****************
#ifdef _WINDOWS
#include "getopt.h"
#endif

#if defined(__GNUG__) && __GNUC_MINOR__ < 6 && defined(Sparc)
    extern "C" int getopt(int argc, char** argv, char* optstring);
#endif

#if defined(__GNUG__) && defined(Sparc)
    extern char *optarg;
    extern int optind, opterr;
#endif
**********************************************************/

// list of options intialized based on parsing the command line arguments
struct CommandLineOptions
{
   bool InitDevice;    // initialize (format) device, and create file/indices
   bool ScanFile;      // Scan the data file that is created
   unsigned NumRecs;   // Cardinality of the data file.
   unsigned PrintGran; // Print Granualarity

   CommandLineOptions()
   {
      InitDevice = false;
      ScanFile = false;
      NumRecs = 10000;
      PrintGran = NumRecs/10;
   }

};

CommandLineOptions ParsedOptions;

// Simple test class for persistent types.
class TestPersistentType : public PersistentType
{

public:
   TestPersistentType()
   {
      id = __mycounter__ / ArrSize;

      unsigned idx;
      for (idx=0; idx<ArrSize; idx++) values[idx] = __mycounter__++;
      memset(&prevRid,0, sizeof(SMinterface::RecID));
      rank = 0;
   }

   // output print method
   ostream& Print(ostream& os) const
   {
      os << "ID: " << id << ", rank: " << rank << ", [";
      unsigned idx;
      for (idx=0; idx<ArrSize-1; idx++) 
         if (idx==0 || idx == ArrSize-1) os << values[idx];
         else os << ".";
      
      os << values[idx] << "]" << endl;
      return os;
   }

   //
   // Convert to a SHORE byte representation. 
   // Quick and dirty "shallow" implementation, which only works if the structure being 
   // Serialized has no pointers.
   // TODO: Fix this with a cleaner implementation! - jmp
   //
   virtual BError::Status Serialize(char*& buffer,          // O- set to the output buffer
                                    unsigned& length) const // O- set to the length of the output buffer
   {
      // Ugly hack - clean up later. 
      buffer = (char*) this;
      length = sizeof (TestPersistentType);
      return BError::OK;
   }

   // Conservatively Estimate the length of the serialized representation in bytes
   virtual BError::Status SerialzedLength(unsigned& length) // O- estimated length
   {
      length = sizeof (TestPersistentType);
      return BError::OK;
   }

   //
   // Convert from a SHORE record to an in-memory representation. 
   // Once again, this works only if the structure being stored has no pointers
   // 
   virtual BError::Status UnSerialize(const char* buffer,     // I- the buffer returned from Serialize
                                      const unsigned length)  // I- the length of the serialized representation
   {
      memcpy(this, buffer, length);

      return BError::OK;
   }

   void SetRank (unsigned _rank) {rank = _rank;}
   void SetRid  (SMinterface::RecID& _prevRid) { prevRid = _prevRid;}

   unsigned GetRank () const {return rank;}
   const SMinterface::RecID& GetRid () const {return prevRid;}

private:
   int values[ArrSize];
   float id; 

   // implement a simple linked list
   unsigned rank;               // rank in the list (head = 0)
   SMinterface::RecID prevRid;  // pointer to the previous record id;
};

// overload the output operator
inline ostream& operator << (ostream& os, const TestPersistentType& s)
{
   return s.Print(os);
}


// Test Create File
BError::Status CreateFile(SMinterface& sm) 
{
   SMinterface::FileID fid;
   SMinterface::RecID rid; 
   MilliTimer tm; 

   // Create a file and insert some tuples into the file
   B_INT_CALL(sm.CreateFile(FileName, fid));

   cout << "CREATE RECORDS ... " <<  endl;
   tm.reset();
   unsigned recnum;
   for (recnum=0; recnum<ParsedOptions.NumRecs; recnum++)
   {
      TestPersistentType rec;

      // Set up the link list element
      rec.SetRank(recnum);
      rec.SetRid(rid);

      B_INT_CALL(sm.InsertTuple(fid, rec, rid));
      if (!(recnum%ParsedOptions.PrintGran)) 
      {
         cout << "    >> Time: " << tm.stop() << " ms, Inserted Record " << recnum << ": " << rec;
         tm.reset();
      }
   }

   return BError::OK;
}


// Test Scan File
BError::Status ScanFile(SMinterface& sm) 
{
   // Now read tuples from the file
   cout << "SCAN ENTIRE FILE" <<  endl;
   SMinterface::FileScanCursor* cursor = 0; 
   SMinterface::PinHandle* pin = 0;
   bool	eof = false;
   SMinterface::FileID fid;
   SMinterface::RecID rid; 
   unsigned recnum;

   // look up catalogs 
   B_INT_CALL(sm.RecallCatalogAssociation(FileName, fid));
   B_INT_CALL(sm.InitializeScan(fid, cursor));       // Start a scan
   B_INT_CALL(sm.NextTuple(cursor, rid, pin, eof));  // Get the next (first) tuple
   recnum = 0;

   MilliTimer tm;
   tm.reset();
   while (!eof) 
   {
      TestPersistentType readRec;
      const char *data = 0;
      unsigned length = 0;

      B_INT_CALL(sm.GetTupleContents(pin, data, length));
      B_INT_CALL(readRec.UnSerialize(data, length));  // Reconstruct the tuple

      if (!(recnum%ParsedOptions.PrintGran)) 
      {
         cout << "    >> Time: " << tm.stop() << " ms, Read Record " << recnum << ": " << readRec;
         tm.reset();
      }

      B_INT_CALL(sm.NextTuple(cursor, rid, pin, eof));  // Get the next tuple

      recnum++;
   }

   B_INT_CALL(sm.EndScan(cursor));
   return BError::OK;
}

// Test Scan File
BError::Status ScanFileForwardsAndBackwards(SMinterface& sm) 
{
   // Now read tuples from the file
   cout << "SCAN ENTIRE FILE" <<  endl;
   SMinterface::FileScanCursor* cursor = 0; 
   SMinterface::PinHandle* pin = 0;
   bool	eof = false;
   SMinterface::FileID fid;
   SMinterface::RecID rid; 
   unsigned recnum;

   // look up catalogs 
   B_INT_CALL(sm.RecallCatalogAssociation(FileName, fid));
   B_INT_CALL(sm.InitializeScan(fid, cursor));       // Start a scan
   B_INT_CALL(sm.NextTuple(cursor, rid, pin, eof));  // Get the next (first) tuple
   recnum = 0;

   MilliTimer tm;
   tm.reset();
   while (!eof) 
   {
      TestPersistentType readRec;
      const char *data = 0;
      unsigned length = 0;

      B_INT_CALL(sm.GetTupleContents(pin, data, length));
      B_INT_CALL(readRec.UnSerialize(data, length));  // Reconstruct the tuple

      if (!(recnum%ParsedOptions.PrintGran)) 
      {
         cout << "    >> Time: " << tm.stop() << " ms, Read Record " << recnum << ": " << readRec;
         tm.reset();
      }

      B_INT_CALL(sm.NextTuple(cursor, rid, pin, eof));  // Get the next tuple

      recnum++;
   }

   B_INT_CALL(sm.EndScan(cursor));

   // Now scan the list backwards. rid has the last record id! 
   cout << "SCAN LIST BACKWARDS, START WITH LAST RECORD, RID: " << rid << endl;
   B_INT_CALL(sm.BeginStatsMeasurements()); // start gathering statistics

   const TestPersistentType* listElement;
   const char* bufPtr;
   SMinterface::PinHandle scanHandle;
   unsigned recLen = 0;

   tm.reset();
   // pin the tuple in the buffer pool
   B_INT_CALL(sm.ReadTuple(rid, scanHandle));

   // now get a pointer to the pinned tuple's contents
   // Note how it is set to the listElement, to avoid a memory copy (which can be very expensive)
   B_INT_CALL(sm.GetTupleContents(&scanHandle, bufPtr, recLen));
   assert(recLen == sizeof(TestPersistentType));
   listElement = (const TestPersistentType *) bufPtr;

   while (listElement->GetRank() != 0)
   {
      recnum--;
      if (!(recnum%ParsedOptions.PrintGran)) 
      {
         cout << "    >> Time: " << tm.stop() << " ms, Back Read Record " << recnum << ": " << *listElement;
         tm.reset();
      }

      // Get the pervious record      
      rid = listElement->GetRid();

      // pin the tuple in the buffer pool
      B_INT_CALL(sm.ReadTuple(rid, scanHandle));
      
      // now get a pointer to the pinned tuple's contents, again avoid memcpy
      B_INT_CALL(sm.GetTupleContents(&scanHandle, bufPtr, recLen));
      assert(recLen == sizeof(TestPersistentType));
      listElement = (const TestPersistentType *) bufPtr;
   }

   cout << "    >> Time: " << tm.stop() << " ms, Back Read Record " << recnum << ": " << *listElement;
   scanHandle.unpin(); // unpin the last record.

   return BError::OK;
}


// Test the shore functions 
BError::Status TestShoreInterface(SMinterface& sm) 
{
   if (ParsedOptions.InitDevice)
   {
      ///////////////////// PART 1: Create Records ////////////////////////
      B_INT_CALL(sm.BeginTransaction());
      B_INT_CALL(sm.BeginStatsMeasurements()); // start gathering statistics
      B_INT_CALL(CreateFile(sm));
      B_INT_CALL(sm.CommitTransaction());    // must commit the transaction before printing stats
      B_INT_CALL(sm.StopStatsMeasurements()); // stop gathering statistics
      B_INT_CALL(sm.PrintStatsMeasurements("Loading data")); // print statistics
   }
   
   if (ParsedOptions.ScanFile)
   {
      ////////////////////////////// PART 2: Scan //////////////////////////
      B_INT_CALL(sm.BeginTransaction());
      B_INT_CALL(sm.BeginStatsMeasurements()); // start gathering statistics
      B_INT_CALL(ScanFile(sm));
      B_INT_CALL(sm.CommitTransaction());    // must commit the transaction before printing stats
      B_INT_CALL(sm.StopStatsMeasurements()); // stop gathering statistics
      B_INT_CALL(sm.PrintStatsMeasurements("Loading data")); // print statistics
   }

   return BError::OK;
}

// print 
void usage()
{
    cerr << "Usage: server [-i] -s p|l|s -l r|f [options]" << endl;
    cerr << "       -i initialize device/volume and create file" << endl;
    cerr << "       -s scan file"  << endl;
    cerr << "       -n [numRecs]"  << endl;
}

BError::Status parseOptions (int argc, char* argv[]) 
{
   int option;
   while ((option = getopt(argc, argv, "hisn:")) != -1)
   {
      switch (option) 
      {
      case 'h' :
         usage();
         break;
         
      case 'i' :
         {           
            if (ParsedOptions.InitDevice) 
            {
               cerr << "Error only one -i parameter allowed" << endl;
               usage();
               return BError::B_INVALID_CL_OPTIONS;
            }
            ParsedOptions.InitDevice = true;
         }
         break;

      case 's':
         {
            ParsedOptions.ScanFile = true;
         }
         break;
      
      case 'n':
         {
            ParsedOptions.NumRecs = atoi(optarg);
            ParsedOptions.PrintGran = ParsedOptions.NumRecs/10;
         }
         break;
      
      default:
         usage();
         break;
      }
   }

   return BError::OK;

}

// Called when thread is forked
void smthread_user_t::run() 
{
   const char* ConfigFile = "exampleconfig"; // file for reading in shore parameters.

	BError::ErrorNo::Initialize(); // Initialize error handler

   // Parse options and set the options in the global class ParsedOptions;
   B_CALL(parseOptions (argc, argv));

   MilliTimer tm; 
   tm.reset();

   SMinterface storageManager; // Storage manager object
   B_CALL(storageManager.Create(ConfigFile, ParsedOptions.InitDevice)); // Create the storage manager
   
   // Call the TestShoreInterface function and time it.
   B_CALL(TestShoreInterface(storageManager));
   cout << " Total Test Time: " << tm.stop() << " ms" << endl;

	BError::ErrorNo::ShutDown(); // Shut down error handler
	// cout << "Shutting down error manager" << endl;
	cout.flush();
}
