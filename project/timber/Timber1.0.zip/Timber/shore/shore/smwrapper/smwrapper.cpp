#include "smwrapper.h"
// using namespace std;

const int OPTION_LEVEL_COUNT = 3; 

// Constructor initializes pointer to NULL
SMinterface::SMinterface() 
{
   options = 0;
   ssm = 0;
}

// Shuts down storage manager
SMinterface::~SMinterface() 
{
   delete ssm;
   delete options;
}

// Sets up the Shore storage manager
BError::Status SMinterface::Create(const string& optionFileName, // I- read the shore configuration options from the options file
                                   bool          formatDevice)   // I- If true, format device
{
   
   B_INT_CALL(setupOptions(optionFileName)); // Set the options
   
   B_INT_CALL(setupDevice(formatDevice)); // Set the device
   
   return BError::OK;
}

// Returns a pointer to the storage manager object
ss_m * SMinterface::get_ssm() 
{
   return ssm;
}

// Returns the volume ID
lvid_t SMinterface::get_lvid() 
{
   return lvid;
}

/////////////////////////////////////////////////////////////
//
// Support for Transactions
//
/////////////////////////////////////////////////////////////
// Begin a new transaction
BError::Status SMinterface::BeginTransaction() 
{
   if (!ssm)
      return BError::B_NULL_POINTER;
   
   B_CALL_SHORE(ssm->begin_xct());
   
   return BError::OK;
}

// Commit the current transaction
BError::Status SMinterface::CommitTransaction() 
{
   
   if (!ssm)
      B_RETURN_ERROR(BError::B_NULL_POINTER);
   
   B_CALL_SHORE(ssm->commit_xct());
   
   return BError::OK;
}

#define BEACON_FORCE_BUFFERS

BError::Status SMinterface::FlushBufferPool() 
{
   
#ifdef BEACON_FORCE_BUFFERS

   // force out all the pages from the buffer pool
   ssm->force_buffers(true);

#endif // BEACON_FORCE_BUFFERS

	return BError::OK;
}


/////////////////////////////////////////////////////////////
//
// Statistics gather and display methods
//
/////////////////////////////////////////////////////////////
BError::Status SMinterface::BeginStatsMeasurements() 
{

	B_INT_CALL(FlushBufferPool()); // force pages from the buffer pool
   
   // Gather the statistics and reset the internal shore statistics counts
   ssm->gather_stats(smstats, true);
   timer.reset(); // reset the timer.

	return BError::OK;
}


BError::Status SMinterface::StopStatsMeasurements() 
{    
	B_INT_CALL(FlushBufferPool()); // force pages from the buffer pool

   // Gather the statistics and reset the internal shore statistics counts
   ssm->gather_stats(smstats, true);
   elapsedTime = timer.stop();  // stop the timer. 

	return BError::OK;
}


BError::Status SMinterface::PrintStatsMeasurements(const string displayMsg) // I- message to be displayed
{      
   std::cout << "--IOSTATS for " << displayMsg << "-- "
             << " Reads: " << smstats.sm.vol_reads
             << " Num Write Calls: " << smstats.sm.vol_writes
             << " Writes: " << smstats.sm.vol_blks_written << " ";
//             << std::endl;

   /* 
   SmVolumeMetaStats volumeStats;

   B_CALL_SHORE(ssm->begin_xct());
   B_CALL_SHORE(ss_m::get_volume_meta_stats(ss_m::get_vid(lvid), volumeStats));
   B_CALL_SHORE(ssm->commit_xct());

   std::cout << "Volume stats for " << displayMsg << "-- "
             << " Num Allocated Pages: " << (int)volumeStats.numAllocPages << std::endl;
   */

   std::cout.setf(std::ios::fixed); 
   std::cout.precision(2);
   std::cout << "Elapsed Time: " << elapsedTime << " ms" << std::endl;

//   cout << smstats << endl;

	return BError::OK;
}


/////////////////////////////////////////////////////////////
//
// Supporting Device/Volume setup/initialization methods
//
/////////////////////////////////////////////////////////////
// Sets the options using the Shore options file names optionFilename
BError::Status SMinterface::setupOptions(string optionFilename)  // I- Options file name
{
   
   options = new option_group_t(OPTION_LEVEL_COUNT);
   if (!options)
      B_RETURN_ERROR(BError::B_NULL_POINTER);
   
   // Set option pointers to NULL
   option_t* optDeviceName = 0;
   option_t* optDeviceQuota = 0;
   
   // Set the name of the device as a required option
   B_CALL_SHORE(options->add_option("device_name", "device/file name",
      "./volumes/dev1", "device containing volume holding files to scan",
      false, option_t::set_value_charstr, optDeviceName));
   
   // Set the quota of the device as an option
   B_CALL_SHORE(options->add_option("device_quota", "# > 1000",
      "2000", "quota for device",
      false, option_t::set_value_long, optDeviceQuota));
   
   // Add SSM options to the group
   B_CALL_SHORE(ss_m::setup_options(options));
   
   B_CALL_SHORE(options->add_class_level("perf"));	// for all performance tests 
   B_CALL_SHORE(options->add_class_level("server"));	// server or client
   B_CALL_SHORE(options->add_class_level("beacon"));	// program name
   
   // Read the options file to set options
   ostrstream err_stream;
   
   option_file_scan_t opt_scan(optionFilename.c_str(), options);
   
   // Scan the file and override any current option settings
   // Options names must be spelled correctly
   B_CALL_SHORE(opt_scan.scan(true /*override*/, err_stream, true));
   
   // Assign acquired options to variables
   deviceName = optDeviceName->value();
   quota = strtol(optDeviceQuota->value(), 0, 0);
   
   B_CALL_SHORE(options->check_required(&err_stream));
   
   return BError::OK;
}

// Sets the device for the Shore storage manager
BError::Status SMinterface::setupDevice(bool formatDevice) // I- If true, format device
{
	ssm = new ss_m(); // Allocate memory for storage manager
	if (!ssm)
		B_RETURN_ERROR(BError::B_NULL_POINTER);

   u_int volCount;
   devid_t	deviceID;
   
   if (formatDevice)
   {
      B_CALL_SHORE(ss_m::format_dev(deviceName.c_str(), quota, true)); // Format the device
      
      // Mount the device
      B_CALL_SHORE(ss_m::mount_dev(deviceName.c_str(), volCount, deviceID)); // Mount the device
           
      B_CALL_SHORE(ss_m::generate_new_lvid(lvid)); // Generate volume ID for new volume
      
      B_CALL_SHORE(ss_m::create_vol(deviceName.c_str(), lvid, quota)); // Create new volume for the device
      
      B_CALL_SHORE(ss_m::add_logical_id_index(lvid, 0, 0)); // Create the logical ID index on the volume
   }
   else
   {
      // Mount the device
      B_CALL_SHORE(ss_m::mount_dev(deviceName.c_str(), volCount, deviceID)); // Mount the device

      // find ID of the volume on the device
      lvid_t* lvid_list;
      u_int   lvid_cnt;
      B_CALL_SHORE(ssm->list_volumes(deviceName.c_str(), lvid_list, lvid_cnt));
      if (lvid_cnt == 0) 
      {
         // cerr << "Error, device has no volumes" << endl;
         B_RETURN_ERROR(BError::B_STORAGE_MANAGER);
      }
      lvid = lvid_list[0];
      delete [] lvid_list;
   }

   B_CALL_SHORE(ss_m::vol_root_index(lvid, rootiid)); // Rememeber the root index id. 
   
   vid = ss_m::get_vid(lvid);  // remember the physical volume id.    
   
   return BError::OK;
}
   
/////////////////////////////////////////////////////////////
//
// Create and Destroy Shore Files
//
/////////////////////////////////////////////////////////////
BError::Status SMinterface::CreateFile(FileID& fid) // O- File ID of table
{
   // Create a file to store records
   B_CALL_SHORE(ssm->create_file(vid, fid, smlevel_3::t_regular));
   
   return BError::OK;
}
  
BError::Status SMinterface::DestroyFile(const FileID& fid) // I- File ID of table
{
   // Destroy file
   B_CALL_SHORE(ssm->destroy_file(fid));

   return BError::OK;
}

BError::Status SMinterface::CreateFile(const char* filename, // I- name of the file
                                       FileID&     fid)      // O- retuned shore file id
{
   B_INT_CALL(CreateFile(fid));
   B_INT_CALL(CreateCatalogAssociation(filename, fid));

   return BError::OK;
}

BError::Status SMinterface::DestroyFile(const char* filename) // I- name of the file
{
   FileID fid;
   B_INT_CALL(RecallCatalogAssociation(filename, fid));
   B_INT_CALL(DestroyFile(fid));

   return BError::OK;
}

/////////////////////////////////////////////////////////////
//
// Methods for inserting, updating, and deleting tuples from a file
//
/////////////////////////////////////////////////////////////
BError::Status SMinterface::InsertTuple(const FileID& fid,            // I- shore file id in which tuple is created
                                        const PersistentType & tuple, // I- tuple to insert
                                        RecID & rid)                  // O- returned record id
{  
   // Buffer to store flattened tuple
   char *buffer=0;
   unsigned length=0;

   B_INT_CALL(tuple.Serialize(buffer, length));
   
   // Prepare a shore vector structure to store the flattened tuple. 
   vec_t data(buffer, length);
   vec_t hdr; // empty header
   
   // Create the record and insert it into the table
   B_CALL_SHORE(ssm->create_rec(fid, hdr, length, data, rid));
   
   return BError::OK;
}

BError::Status SMinterface::UpdateTuple(const RecID & rid,            // I- Record id of the tuple being updated
                                        const PersistentType & tuple) // I- The new value for the updated tuple 
{
   // Buffer to store flattened tuple
   char *buffer=0;
   unsigned length=0;

   B_INT_CALL(tuple.Serialize(buffer, length));

   // Prepare a shore vector structure to store the flattened tuple. 
   vec_t data(buffer, length);
   vec_t hdr; // empty header
   
   pin_i handle;
   
   B_CALL_SHORE(handle.pin(rid, 0)); // Pin the record in the buffer pool at rid
   
   B_CALL_SHORE(handle.update_rec(0, data)); // Update the record
   
   handle.unpin(); // Unpin the record
   
   return BError::OK;
}

BError::Status SMinterface::RemoveTuple(const RecID & rid) // I- Record id of the tuyple being deleted
{
	B_CALL_SHORE(ssm->destroy_rec(rid)); // Destroy the record

   return BError::OK;
}


/////////////////////////////////////////////////////////////
//
// Fetch a tuple given its record id. Note this is an expensive
// operation as the tuple is copied out the the PersistentType Structure
//
/////////////////////////////////////////////////////////////
BError::Status SMinterface::ReadTuple(const RecID & rid,      // I- the record id of the record being read
                                      PersistentType & tuple) // O- the value of the record
{
   pin_i handle;
   
   B_CALL_SHORE(handle.pin(rid, 0)); // Pin the record at rid
   
   if (!handle.is_small()) 
   {
      char * totalBody = new char[handle.body_size()];
      if (!totalBody) {
         B_RETURN_ERROR(BError::B_MALLOC_FAILED);
      }
      char * curByte = totalBody;
      
      for (bool eof = false; !eof; handle.next_bytes(eof)) 
      {
         memcpy(curByte, handle.body(), handle.length());
         curByte+=handle.length();
      }

      B_INT_CALL(tuple.UnSerialize(totalBody, handle.body_size()));
      delete [] totalBody;
   }
   else 
   {
      B_INT_CALL(tuple.UnSerialize(handle.body(), handle.body_size())); // Retrieve the flattened data
   }
   
   handle.unpin(); // Unpin the record
   
   return BError::OK;
}

/////////////////////////////////////////////////////////////
//
// Scan a SHORE file using a cursor mechanism
//
/////////////////////////////////////////////////////////////

// Initializes the file scan, and return a file cursor
BError::Status SMinterface::InitializeScan(FileID& fid,           // I- File being scanned 
                                           FileScanCursor*& scan) // O- The scan cursor
{
   if (scan)
      delete scan; // Delete old scan object if one exists
   
   scan = new scan_file_i(fid, ss_m::t_cc_file);
   if (!scan)
      B_RETURN_ERROR(BError::B_MALLOC_FAILED);
   
   return BError::OK;
}

// Retrieves the next tuple from the heap file (successive calls to this 
// method with the same handle instance, will unpin the previous record in the scan)
BError::Status SMinterface::NextTuple(FileScanCursor*&       scan,  // I/O- the file cursor (created by InitializeScan)
                                      RecID &                rid,   // O- the next record id 
                                      PinHandle*&            handle,// O- handle to the tuple in the buffer pool (allocated and deallocated by SHORE in the destructor for scan)
                                      bool &                 eof)   // O- indicator if reached end of file.
{
	B_CALL_SHORE(scan->next(handle, 0, eof));

	if (eof) 
   {
		delete scan;
		scan = 0;
		return BError::OK;
	}

	rid = handle->rid(); // Retrieve the rid

	return BError::OK;
}

// Initializes the file scan, and return a file cursor
BError::Status SMinterface::EndScan(FileScanCursor*& scan) // O- The scan cursor
{
   if (scan) delete scan;
   scan = 0;

   return BError::OK;
}

                                           /////////////////////////////////////////////////////////////
//
// Cataloging functions to persistently remember a FileID with a string (key)
//
/////////////////////////////////////////////////////////////
BError::Status SMinterface::CreateCatalogAssociation(const char* key,   // I- the key (filename) for the catalog entry
                                                     const FileID& fid) // I- the file id for the key (filename)
{
   // Store table in the root index (the catalog) protein table info
   cout << "Storing in Root Index -> Key: " << key << ", value: " << fid << endl;
   B_CALL_SHORE(ssm->create_assoc(rootiid,
      vec_t(key, strlen(key)),
      vec_t(&fid, sizeof(fid))));
   
   return BError::OK;
}

BError::Status SMinterface::RecallCatalogAssociation(const char* key, // I- the key (filename) for the catalog entry
                                                     FileID&     fid) // O- The file id for the key (filename)
{
   smsize_t infoLen;
   
   // Look up the entry for sName in the root index.
   bool found;
   
   B_CALL_SHORE(ssm->find_assoc(rootiid, 
      vec_t(key, strlen(key)), 
      &fid, 
      infoLen, 
      found));
   
   // check that the data is of the expected length
   assert (infoLen == sizeof(FileID));
   
   if (!found) B_RETURN_ERROR(BError::B_MISSING_CATALOG_ENTRY);;
   
   return BError::OK;
}

