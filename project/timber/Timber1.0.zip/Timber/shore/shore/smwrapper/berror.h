#ifndef BERROR_H
#define BERROR_H

// Local includes
#include <iostream>
#include <sstream>
#include <fstream>
#include <string>
#include "vector.h"

// Macro for an internal call from one Beacon method (with return type Status)
// to another Beacon method (also with a return type of Status)
// Macro takes as argument the function being called.
#define B_INT_CALL(f)                                                \
   do {                                                               \
         BError::Status err = (f);                                   \
         if (err != BError::OK) {                                    \
            BError::ErrorNo::en->pushTrace(err, __FILE__, __LINE__); \
               return err;                                            \
         }                                                            \
   } while (0)


// Macro for calling a Beacon method at the top-level. 
#define B_CALL(f)                                                      \
   do {                                                                 \
         BError::Status err = (f);                                     \
         if (err != BError::OK) {                                      \
            BError::ErrorNo::en->pushTrace(err, __FILE__, __LINE__);   \
            BError::ErrorNo::en->printTrace();                         \
            abort();                                                    \
         }                                                              \
   } while (0)

// Macro for returning an error code from a function.
#define B_RETURN_ERROR(err)                                    \
   do {                                                            \
      BError::ErrorNo::en->reset();                            \
      BError::ErrorNo::en->pushTrace(err, __FILE__, __LINE__); \
      return err;                                               \
   } while (0)

/*  old call with displayError, removed to compile on linux -jmp 
#ifdef _WINDOWS
#define B_CALL_SHORE(f)  		\
do {							\
    w_rc_t __e = (f);			\
    if (__e)  {					\
	__e.displayError();        \
	B_RETURN_ERROR(BError::B_STORAGE_MANAGER);				\
	}																\
} while (0)

#else
*/
#define B_CALL_SHORE(f)  		\
do {							\
    w_rc_t __e = (f);			\
    if (__e)  {					\
    cout << __e << endl;   \
	B_RETURN_ERROR(BError::B_STORAGE_MANAGER);				\
	}																\
} while (0)

// #endif _WINDOWS

// The Beacon error namespace
namespace BError {

    extern std::ofstream LHCout;
    extern std::ofstream LHCerr;
   // If you add an error message here, please add a error description in 
   // getDesc (BError.cpp) 
   enum Status {
	   OK = 0,
		   BENCHMARK_BAD_PARAMS,

		   INDEX_NOT_INITIALIZED,
		 
		   // General System errors
         B_INVALID_CL_OPTIONS,
		   B_STORAGE_MANAGER,
		   B_MALLOC_FAILED,
		   B_NULL_POINTER,
		   B_FATAL,
		   B_NOT_IMPLEMENTED,
         B_MISSING_CATALOG_ENTRY,
		   B_DUMMY_MARKER   // Do not add any error codes beyond this marker
   };

   class ErrorNo
   {
       public:
           static ErrorNo* en;
           static void Initialize();
           static void ShutDown();

           // Get the short description of the error
           static std::string getDesc(Status stat);

           ErrorNo();
           ~ErrorNo();

           // Get the trace of the error
           std::string getTrace() const;

           // Print the error trace
           void printTrace() const; 

           // Reset the class
           void reset();

           // Add string to the trace
           void pushTrace(Status stat, const std::string& file, int line);

       private:
           Vector<std::string> mvTrace;
   };   
}
#endif

