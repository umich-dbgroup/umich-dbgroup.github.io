#include "tbtree.h"
#include "debug-tbtree.h"
//#include <iostream.h>
#include <iostream>

void main() {

  Trajectory trj1(1, .75, 0, 2, 2, 1, 10);
  Trajectory trj2(2, 2, 1, 2, 3, 3, 10);
  Trajectory trj3(2, 3, 3, 1, 1, 4, 10);
  Trajectory trj4(1, 1, 4, 3, 1, 5, 10);
  Trajectory trj5(3, 1, 5, 6, 7, 6, 10);
  Trajectory trj6(1.5, 7.9, 8, 9, 3, 11, 10);
  Trajectory trj7(9, 3, 11, 3.3333, 4.908, 12, 10);
  
  Trajectory trj8(1, .75, 0, 2, 2, 1, 11);
  Trajectory trj9(2, 2, 1, 2, 3, 3, 11);
  Trajectory trj10(2, 3, 3, 1, 1, 4, 11);
  Trajectory trj11(1, 1, 4, 3, 1, 5, 15);
  Trajectory trj12(3, 1, 5, 6, 7, 6, 15);
  Trajectory trj13(6, 7, 6, 9, 3, 11, 15);
  Trajectory trj14(9, 3, 11, 3.3333, 4.908, 12, 15);
  Trajectory trj15(1, 4, 7, 1, 4, 9, 16);
  
  Trajectory TRJS[] = 
  { trj1, trj2, trj3, trj4, trj5,
    trj6, trj7, trj8, trj9, trj10,
    trj11, trj12, trj13, trj14, trj15
 };
  
  // Create an index with a fanout of 4
  TBTree Index ( 4 );

  // Put our trajectories into the index
  for ( int i=0; i<15; i++) {
    Index.insert( TRJS[i] );
  }
  
  QueryResults Results; // Simple interface for storing the the results
  DebugTBTree  db;      // Simple class with useful printing utilities
  

  /* This is a MBB with 
     bottom = 2, top   = 3,
     left   = 1, right = 2,
     start  = 0, end   = 20
   */
  MBB range ( 2, 3, 1, 2, 0, 20 );

  // Query for all segments that overlap our range
  bool rv = Index.rangeQuery ( range, Results );

  if ( !rv )
    cerr << "Error reported during query!\n";

  db.printQueryResults ( Results );
  

}

