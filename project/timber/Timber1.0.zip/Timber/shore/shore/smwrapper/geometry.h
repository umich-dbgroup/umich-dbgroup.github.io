#ifndef GEOMETRY_H
#define GEOMETRY_H

struct MBB;
struct Trajectory;
struct STPoint;

// Structure for a Minimum Bouding Box
struct MBB {
  MBB (const float b = 0, const float t = 0, const float l = 0, 
       const float r = 0, const float s = 0, const float e = 0 );
  bool overlapsMBB(const MBB & mbb) const;  // True if a given MBB overlaps this MBB
  bool overlapsMBB(const STPoint & point) const;
  float top, bottom, left, right, start, end;
};

bool operator!= (MBB a, MBB b);
bool operator== (MBB a, MBB b);


// Structure for a Space-Time Point
struct STPoint {
  STPoint (const float x_pos=0, const float y_pos=0, const float time=0);
  float x, y, t;
};

// Structure for a Trajectory
struct Trajectory {
Trajectory::Trajectory(const float sx=0, const float sy=0, const float st=0,
		       const float ex=0, const float ey=0, const float et=0,
		       const int id=0);
  Trajectory (const STPoint start_point, const STPoint end_point,
	      const int id = 0);
  STPoint start, end;
  int object_id;
};


float getMin(const float a, const float b); // Simple minimum function
float getMax(const float a, const float b); // Simple maximum function

int getMin(const int a, const int b); // Simple minimum function
int getMax(const int a, const int b); // Simple maximum function

// Calculates smallest bounding Box that encloses both MBB1 and MBB2
void getBoundingBox(const MBB & mbb1, const MBB & mbb2, MBB & boundingBox);

// Calculates smallest bounding Box that encloses a trajectory
void getBoundingBox(const Trajectory & trj, MBB & boundingBox);



// Returns a random number between min and max
int uniformInt(const int min, const int max);
double uniformDouble(const double min, const double max);

#endif
