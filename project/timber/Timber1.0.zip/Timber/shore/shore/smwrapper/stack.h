#ifndef STACK_H
#define STACK_H

#include "berror.h"

// Stack node
template <class T>
struct StackNode {
	T value;
	StackNode<T> *next;
};

// Stack class
template <class T>
class Stack {
public:
	Stack();
	~Stack();
	
	BError::Status push(const T & value); // Pushes value onto stack
	BError::Status pop(T & value, bool & eof); // Pops value off top of stack
	BError::Status clear(); // Clears all entries

	BError::Status resetIterator(); // Point to first entry
	BError::Status advanceIterator(); // Advance iterator
	BError::Status getIterator(T & value, bool & eof); // Get current value
private:
	StackNode<T> *head;
	StackNode<T> *iterator;
};

// Constructs the stack
template <class T>
inline
Stack<T>::Stack() {
	// Initialize head and iterator to NULL
	head = 0;
	iterator = 0;
}

// Destroys stack elements
template <class T>
inline
Stack<T>::~Stack() {

	B_CALL(clear()); // Clears all elements
}

// Pushes element onto stack
template <class T>
inline
BError::Status Stack<T>::push(const T & value) {

	// Allocates the new node
	StackNode<T> *newNode = new StackNode<T>;
	if (!newNode)
		B_RETURN_ERROR(BError::B_MALLOC_FAILED);

	newNode->value = value;
	newNode->next = head;
	head = newNode;

	return BError::OK;
}

// Pops result off top of stack
template <class T>
inline
BError::Status Stack<T>::pop(T & value, bool & eof) {

	if (!head) {
		eof = true;
		return BError::OK;
	}

	// Advance iterator if necessary
	if (iterator == head)
		iterator = head->next;

	// Get value of first entry in list and delete node
	value = head->value;
	StackNode<T> *delNode = head;
	head = head->next;
	delete delNode;

	eof = false;
	return BError::OK;
}

// Clears all elements
template <class T>
inline
BError::Status Stack<T>::clear() {

	// Removes all elements
	while (head) {
		StackNode<T> *delNode = head;
		head = head->next;
		delete delNode;
	}

	iterator = 0;
	return BError::OK;
}

// Point to first entry
template <class T>
inline
BError::Status Stack<T>::resetIterator() {

	iterator = head;

	return BError::OK;
}

// Advance iterator
template <class T>
inline
BError::Status Stack<T>::advanceIterator() {

	if (!iterator) {
		iterator = head;
	}
	else {
		iterator = iterator->next;
	}
	return BError::OK;
}

// Get current value
template <class T>
inline
BError::Status Stack<T>::getIterator(T & value, bool & eof) {

	if (!iterator) {
		eof = true;
	}
	else {
		value = iterator->value;
		eof = false;
	}
	return BError::OK;
}

#endif