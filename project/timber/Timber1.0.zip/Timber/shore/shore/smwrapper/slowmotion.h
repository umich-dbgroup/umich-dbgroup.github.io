#include "w_defines.h"

#include <w_stream.h>
#include <sys/types.h>
#include <memory.h>
#include <assert.h>
#include "sm_vas.h"

#include "berror.h"

#ifdef _WINDOWS
#include "getopt.h"
#endif

#if defined(__GNUG__) && __GNUC_MINOR__ < 6 && defined(Sparc)
extern "C" int getopt(int argc, char** argv, char* optstring);
#endif

#if defined(__GNUG__) && defined(Sparc)
extern char *optarg;
extern int optind, opterr;
#endif

#include <iostream>
#include <string>
// using namespace std;

