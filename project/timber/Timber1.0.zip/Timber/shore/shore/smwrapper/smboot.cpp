/////////////////////////////////////////////////////////////////
//
// smboot.cpp: Supporting code to initialize the run time SHORE threads 
//
/////////////////////////////////////////////////////////////////

#include "smboot.h"
#include <iostream>

// Main creates Shore storage manager and forks thread
int main(int argc, char* argv[]) 
{
   
   smthread_user_t *smtu = new smthread_user_t(argc, argv); // Allocates working thread
   if (!smtu)
      W_FATAL(fcOUTOFMEMORY);
   
   w_rc_t e = smtu->fork(); // Forks thread
   if(e) {
      std::cerr << "error forking thread: " << e << endl;
      return 1;
   }
   e = smtu->wait(); // Waits for thread to complete
   if(e) {
      std::cerr << "error forking thread: " << e << endl;
      return 1;
   }
   
   int rv = smtu->retval;
   delete smtu;
   
   return rv;
}

