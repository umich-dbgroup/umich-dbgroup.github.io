/////////////////////////////////////////////////////////////////
//
// smboot.h: Supporting code to initialize the run time SHORE threads 
//
/////////////////////////////////////////////////////////////////

#ifndef _SM_BOOT_H
#define _SM_BOOT_H

#include "sm_vas.h"

// Defines an smthread based class for all sm-related work
class smthread_user_t : public smthread_t 
{
   int	argc;
   char	**argv;

public:
   int	retval;
   
   smthread_user_t(int ac, char **av) 
      : smthread_t(t_regular, "smthread_user_t"),
      argc(ac), argv(av), retval(0) { }
   ~smthread_user_t()  {}

   // the program main, transfers control to this function.
   void run();
};


#endif /* _SM_BOOT_H */
