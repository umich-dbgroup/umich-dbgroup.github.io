#include "tbtree.h"
#include <string.h>
//#include <iostream.h>
#include <iostream>
using namespace std;

void ShorePointer::setPointer( LeafNode* Pointer ) { ptr = (char*) Pointer; }
void ShorePointer::setPointer( NonLeafNode* Pointer ) { ptr = (char*) Pointer; }
LeafNode*    ShorePointer::DereferenceLeafNode()    const { return (LeafNode*)ptr; }
NonLeafNode* ShorePointer::DereferenceNonLeafNode() const { return (NonLeafNode*)ptr; }


LeafNode::LeafNode() {

	numEntries = 0; // Initially we have no entries
	capacity   = LeafNodeFanout;

	// Start the doubly linked list with no connections
	PreviousPage.setPointer ( (LeafNode*)    0 );
	NextPage.setPointer     ( (LeafNode*)    0 );
	Parent.setPointer       ( (NonLeafNode*) 0 );
}

// Destroy LeafNode
LeafNode::~LeafNode() {

  // Leaf Nodes now contain only statically 
  // allocated members, so no clean up is necessary
  

}

// Inserts a new child entry into the array
bool LeafNode::insertEntry(const Trajectory & NewEntry) {
	if ( entries == 0  ||
	     numEntries >= capacity )
		return false;

	entries[numEntries] = NewEntry;
	numEntries++;
	return true;
}

bool LeafNode::getEntry(const unsigned int index, Trajectory & entry) const {
	if (entries == 0 || index >= numEntries)
		return false;
	else {
		entry = entries[index];
		return true;
	}
}

unsigned int LeafNode::getNumEntries() const {
	return numEntries;
}

// Calculates the mbb for all entries
bool LeafNode::calculateBoundingBox(MBB & mbb) const {
	MBB TempMBB; // Temporary mbb for each trajectory in the comparison

	if (entries == 0)
		return false;

	getBoundingBox(entries[0], mbb);

	for (unsigned int i=1; i<numEntries && i<capacity; i++) {
		getBoundingBox( entries[i], TempMBB);
		getBoundingBox( TempMBB, mbb, mbb);
	}

	return true;
}


void LeafNode::setPreviousPage(LeafNode * previous) {
  PreviousPage.setPointer( previous );
}

void LeafNode::setNextPage    (LeafNode * next) {
  NextPage.setPointer( next );
}

void LeafNode::setParentNode(NonLeafNode * parentNode) {
  Parent.setPointer( parentNode );
}

NonLeafNode* LeafNode::getParentNode() const {
  return Parent.DereferenceNonLeafNode();
}


// Create a new NonLeafNode
NonLeafNode::NonLeafNode(const unsigned int size, const unsigned int _level) {

  numEntries = 0; // Initially we have no entries
  
  if ( _level < 1 ||
       size   < 1 ) {
    cerr << "Cannot create NLNode: Size and Level must be appropriate values\n";
    return;
  }

  // Make sure our NonLeafNode will still fit within a single page
  if ( size > MaxNonLeafNodeFanout ) {
    cerr << "Cannot create NLNode: Size is greater than maximum size "
	 << "(to fit on a single page )\n";
    return;
  }
  
   
  capacity = size;       // Remember our capacity
  level    = _level;     // And what level we are
  Parent.setPointer( (NonLeafNode*)  0 );  // Start with no initial parent node
}


NonLeafNode::~NonLeafNode() {

  // Start by destroying all children
  for (unsigned int i = 0; i < numEntries; i++) {
    if ( level == 1 &&
         entries[i].child.DereferenceLeafNode() )
      delete entries[i].child.DereferenceLeafNode();

    if ( level > 1 &&
         entries[i].child.DereferenceLeafNode() )
      delete entries[i].child.DereferenceNonLeafNode();
  }

}

// Inserts a new child entry into this Node
bool NonLeafNode::insertEntry(LeafNode * NewEntry) {

  if ( level != 1 )
    return false;

  if ( !NewEntry ) {
    cerr << "NonLeafNode::Insert- Cannot index Empty LeafNode pointer\n";
    return false;
  }

  bool rv; // Store a return value

  if ( entries == 0 ||
       numEntries >= capacity )
    return false;

  rv = NewEntry->calculateBoundingBox ( entries[numEntries].mbb );
  if (!rv) {
    cerr << "NonLeafNode::Insert- Could not calculate Minimum "
	 << "Bounding Box for LeafNode\n";
    return false;
  }

  entries[numEntries].child.setPointer( NewEntry );

  numEntries++;
  return true;
}

// Inserts a new child entry into this Node
bool NonLeafNode::insertEntry(NonLeafNode * NewEntry) {

  if (level == 1) {
    cerr << "NonLeafNode::insertEntry- Cannot insert NonLeafNode into a level 1 node\n";
    return false;
  }

  if ( !NewEntry ) {
    cerr << "NonLeafNode::Insert- Cannot index Empty NonLeafNode pointer\n";
    return false;
  }

  bool rv; // Store a return value

  if ( entries == 0 ||
       numEntries >= capacity )
    return false;

  rv = NewEntry->calculateBoundingBox ( entries[numEntries].mbb );
  if (!rv) {
    cerr << "NonLeafNode::Insert- Could not calculate Minimum Bounding Box for NonLeafNode\n";
    return false;
  }

  entries[numEntries].child.setPointer( NewEntry );

  numEntries++;

  return true;

}

bool NonLeafNode::getEntry(const unsigned int index, LeafNode * entry) const {

  if (level != 1)
    return false;

  if (entries == 0 || index >= numEntries)
    return false;

  entry = entries[index].child.DereferenceLeafNode();
  return true;
}

bool NonLeafNode::getEntry(const unsigned int index, NonLeafNode * entry) const {
  if (level==1)
    return false;

  if (entries == 0 || index >= numEntries)
    return false;

  entry = entries[index].child.DereferenceNonLeafNode();
  return true;
}

unsigned int NonLeafNode::getNumEntries() const {
  return numEntries;
}

void NonLeafNode::setParentNode(NonLeafNode * parentNode) {
  Parent.setPointer( parentNode );
}

NonLeafNode* NonLeafNode::getParentNode() const {
  return Parent.DereferenceNonLeafNode();
}


// Calculates the mbb for all entries
bool NonLeafNode::calculateBoundingBox(MBB & mbb) const {

  if (entries == 0)
    return false;

  // Start with the mbb set to the first value
  mbb = entries[0].mbb;

  for (unsigned int i=1; i < numEntries && i<capacity; i++) {
    getBoundingBox( entries[i].mbb, mbb, mbb);
  }

  return true;
}

// Try to find the LeafNode where the last segment
// of this trajectory is stored
LeafNode* NonLeafNode::FindTrajectory
( const STPoint & point, const int & object_id ) const {

  if (!entries)
    return 0;

  // If this is a level 1 node, then scan our entries for this trajectory
  if ( level == 1 ) {

    // Scan backward so we get the latest entry
    for ( int i=numEntries-1; i>=0; i-- ){

      // If our point falls within the MBB of this page
      // then let's take a closer look
      if ( entries[i].mbb.overlapsMBB ( point ) ) {

        Trajectory possibleMatch;

        // Get the last entry stored in the LeafNode
        bool rv = entries[i].child.DereferenceLeafNode()->getEntry
          ( entries[i].child.DereferenceLeafNode()->getNumEntries()-1,
            possibleMatch );

        if (!rv) {
          cerr << "NonLeafNode::FindTrajectory- Could not retrieve last "
               << "entry in LeafNode\n";
          return 0;
        }

        // Find out if our point matches the last point of the segment
        if ( possibleMatch.end.x     == point.x  &&
             possibleMatch.end.y     == point.y  &&
             possibleMatch.end.t     == point.t  &&
             possibleMatch.object_id == object_id ) {
          return entries[i].child.DereferenceLeafNode();
        }

      } // if ( point falls within LeafNode's MBB

    } // for each ( entry in the index )

    return 0;

  } else {

    // Scan backwards through the rest of the tree
    // underneath us
    for ( int i=numEntries-1; i>=0; i-- ) {

      if ( entries[i].mbb.overlapsMBB ( point ) ) {

        LeafNode* rv =
          entries[i].child.DereferenceNonLeafNode()->FindTrajectory( point, object_id );

        if ( rv ) return rv;

      } // if ( point falls with node's MBB )

    } // For each ( index entry )

    return 0;

  }

}

unsigned int NonLeafNode::getLevel() const {
  return level;
}


// Adjust our current MBB and propogate changes up
// through the tree if necessary
void NonLeafNode::adjustMBB () {

  // Stash our original MBB for comparison
  MBB OldMBB;
  calculateBoundingBox( OldMBB );

  // Refresh all of our entries
  for (unsigned int i=0; i < numEntries && i<capacity; i++) {
    if (level == 1)
      entries[i].child.DereferenceLeafNode()->calculateBoundingBox( entries[i].mbb );

    else
      entries[i].child.DereferenceNonLeafNode()->calculateBoundingBox( entries[i].mbb );

  }

  MBB NewMBB;
  calculateBoundingBox( NewMBB );

  // If there has been any overall change to our MBB,
  // then propogate those changes up through the tree
  if ( OldMBB != NewMBB
       && Parent.DereferenceNonLeafNode() )
    Parent.DereferenceNonLeafNode()->adjustMBB();

}


TBTree::TBTree(const unsigned int _fanout) 
{

  RootPointer            = 0;
  CurrentOpenNodePointer = 0;

  // Make sure our NonLeafNode size
  // fits within one page
  if ( _fanout > MaxNonLeafNodeFanout ) {
    cerr << "TBTree::TBTree- Cannot create TB-Tree with fanout larger than " 
	 << MaxNonLeafNodeFanout << endl;
    return;
  }

  height   = 0;
  fanout   = _fanout;
  pagesize = LeafNodeFanout;

}


TBTree::~TBTree() { destroy(); }

void TBTree::destroy() { if ( RootPointer ) delete RootPointer; }

// Insert a new entry into the TB-Tree
bool TBTree::insert(const Trajectory & trj) {
  
  if (!RootPointer) {
    increaseHeight();
  }

  // Since Trajectories are bundled into the same leaf pages
  // First we determine if this trajectory is a continuation
  // of another Trajectory that's already been inserted into the
  // the TB-Tree
  // We're looking for another trajectory with the same id, which
  // ends where this trajectory starts
  LeafNode* Page = RootPointer->FindTrajectory ( trj.start, trj.object_id );

  if (!Page) {
    // No previous trajectory exists, so start off on a new page
    Page = CreateNewLeafNode();

    if (!Page) {
      cerr << "TBTree::insert- CreateNewLeafNode failed to create page, "
	   << "returned a null pointer\n";
      return false;
    }
  }

  // Otherwise, we found a page containing this trajectory
  // Peek to see if there is any room
  if ( Page->getNumEntries() >= pagesize ) {

    // Page is full, so create a page and link them together
    LeafNode* OldPage = Page;
    Page = CreateNewLeafNode();

    if (!Page) {
      cerr << "TBTree::insert- CreateNewLeafNode failed to create page, "
	   << "returned a null pointer\n";
      return false;
    }

    // Link the pages together
    Page->setPreviousPage ( OldPage );
    OldPage->setNextPage ( Page );

  } // if ( Page was full )


  // Insert the trajectory into the page
  bool rv = Page->insertEntry( trj );
  
  if (!rv) {
    cerr << "TBTree::insert- LeafNode failed to insert trajectory\n";
    return false;
  }

  // Adjust the MBB
  NonLeafNode* Parent = Page->getParentNode();
  if (!Parent) {
    cerr << "TBTree::insert- LeafNode with parent pointer unset\n";
    return false;
  }

  Parent->adjustMBB();
  
  return true;

}


// Increases the height of the tree by one level
bool TBTree::increaseHeight() {

  if ( RootPointer ) {

    NonLeafNode* OldRoot = RootPointer;
    RootPointer = new NonLeafNode ( fanout, height+1 );
    
    OldRoot->setParentNode ( RootPointer );
    bool rv = RootPointer->insertEntry ( OldRoot );

    if (!rv ) {
      cerr << "TBTree::increaseHeight- Failed to insert old tree into new root node\n";
      return false;
    }

  } else {
  
    // If no root node exists, create one
    RootPointer = new NonLeafNode ( fanout, 1 );

  }

    height++;
    return true;

}

// Given any node, finds the first empty node on the path
// between this node and the root
// i.e. If the TB-Tree remembers the leftmost node at any time
// FindEmptyNode( leftmost node ) is guaranteed to return
// any empty slots in the treee (if any exist)
NonLeafNode* TBTree::FindEmptyNode ( NonLeafNode & Node ) {

  // Check to see if this node has any empty space
  if ( Node.getNumEntries() < fanout )
    return &Node;

  // If this is the root node and we don't
  // hav any spaces, then give up
  if ( &Node == RootPointer )
    return false;

  NonLeafNode* ParentNode = Node.getParentNode();

  if (!ParentNode) {
    cerr << "TBTree::FindEmptyNode- Empty parent node found in non-root node!\n";
    return false;
  }

  // Otherwise, trace the path from here to the root
  return FindEmptyNode( *ParentNode );


}

// Given any NonLeafNode, extend it down (by adding children) to the specified
// level. The Node being extended must have room for children
NonLeafNode* TBTree::extendNode( NonLeafNode & Node, unsigned int level) 
{

  if ( level < 1 ) {
    cerr << "TBTree::extendNode- Can't extend Node to level " << level
	 << ". TBTree only extends to level 1\n";
    return false;
  }

  // Verify that the node has room for children
  if ( Node.getNumEntries() >= fanout ) {
    cerr << "TBTree::extendNode- Node being extended doesn't have room "
	 << "for children\n";
    return false;
  }

  if ( Node.getLevel() <= level ) {
    cerr << "TBTree::extendNode- Can't extend Node to level " << level 
	 << ". Node is currently at level " << Node.getLevel() << endl;
    return false;
  }


  // Create a new NonLeafNode and insert it 
  NonLeafNode* NewNode = new NonLeafNode( fanout, Node.getLevel()-1 );
  if (!NewNode) {
    cerr << "TBTree::extendNode- Couldn't allocate memory for new node\n";
    return false;
  }

  bool rv = Node.insertEntry( NewNode );

  if (!rv) {
    cerr << "TBTree::extendNode- Failed to insert new LeafNode\n";
    return false;
  }

  NewNode->setParentNode ( &Node );

  // Check to see if we're finished
  if ( NewNode->getLevel() == level ) 
    return NewNode;

  // Otherwise extend the new child node
  return extendNode ( *NewNode, level );

}


// Function to create a new leaf node at the rightmost open spot in the
// tree. This is the only function that has to deal with adding new nonleafnodes
// to the tree, so it is the sole user and maintainer of CurrentOpenNodePointer
// which it keeps around to avoid doing Rightmost DFS traversals everytime it 
// is called
LeafNode* TBTree::CreateNewLeafNode () {

  // Check to see if this tree has any nodes at all
  if (!RootPointer) {
    increaseHeight();

    if (!RootPointer) {
      cerr << "TBTree::CreateNewLeafNode- increaseHeight failed to "
	   << "properly set up tree- null RootPointer\n";
      return false;
    }
      
    CurrentOpenNodePointer = RootPointer;
  } 
  
  else {

    // Otherwise we rely on FindEmptyNode to find the node for us
    if (!CurrentOpenNodePointer)
      CurrentOpenNodePointer = RootPointer;

    CurrentOpenNodePointer = FindEmptyNode ( *CurrentOpenNodePointer );

    // If no open slots were found then the tree is full
    // so we need to increase the height
    if (!CurrentOpenNodePointer) {
      increaseHeight();

      if (!RootPointer) {
	cerr << "TBTree::CreateNewLeafNode- increaseHeight failed to "
	     << "properly set up tree- null RootPointer\n";
	return false;
      }
      
      CurrentOpenNodePointer = RootPointer;
    }

  } // else ( use FindEmptyNode to find empty slot )

  // No matter what path is taken, at this point CurrentOpenNode
  // should have a node with an empty slot available
  if ( !CurrentOpenNodePointer ) {
    cerr << "TBTree::CreateNewLeafNode- Assertion failed, expected "
	 << "CurrentOpenNodePointer to be non null pointer\n";
    return false;
  }

  if ( CurrentOpenNodePointer->getNumEntries() >= fanout ) {
    cerr << "TBTree::CreateNewLeafNode- Assertion failed, expected "
	 << "CurrentOpenNodePointer to have empty slot\n";
    return false;
  }


  // If this node isn't at level 1, we need to create children
  // under this node at level 1
  if ( CurrentOpenNodePointer->getLevel() > 1 ) {
    CurrentOpenNodePointer = extendNode( *CurrentOpenNodePointer, 1 );

    if (!CurrentOpenNodePointer) {
      cerr << "TBTree::CreateNewLeafNode- ExtendNode returned null pointer\n";
      return false;
    }

    if (CurrentOpenNodePointer->getLevel() != 1) {
      cerr << "TBTree::CreateNewLeafNode- ExtendNode failed to extend node to level 1\n";
      return false;
    }
  } // if ( CurrentOpenNode is not at level 1 )


  // Here we have a level 1 node with an empty slot
  LeafNode* Page = new LeafNode();
  if (!Page) {
    cerr << "TBTree::CreateNewLeafNode- Couldn't allocate memory for LeafNode\n";
    return false;
  }

  bool rv = CurrentOpenNodePointer->insertEntry( Page );

  if (!rv) {
    cerr << "TBTree::CreateNewLeafNode- inserting new LeafNode into "
	 << "CurrentOpenNode failed\n";
    return false;
  }

  Page->setParentNode ( CurrentOpenNodePointer );

  return Page;

}

// Will return Results loaded with all Trajectories
// that overlap the range given by mbb
bool TBTree::rangeQuery( const MBB & mbb, QueryResults & Results ) const {

  // Start fresh
  Results.clear();

  if (!RootPointer) 
    return true;
  
  QuerySupport QS;

  return QS.RangeQuery( Results, mbb, *RootPointer);
}


// RangeQuery on NonLeafNodes
bool QuerySupport::RangeQuery 
( QueryResults & Results, const MBB & range, NonLeafNode & Node ) const {

  bool return_value = true;

  // Scan through all the entries, and perform the range query
  // on them if they overlap with the given range
  for (unsigned int i=0; i<Node.numEntries && i<Node.capacity; i++) {
    // Check to see if this entry falls within our range
    if ( Node.entries[i].mbb.overlapsMBB ( range ) ) {
      bool rv;

      if (Node.level == 1) {
	if (!(Node.entries[i].child.DereferenceLeafNode()) ) {
	  cerr << "QuerySupport::RangeQuery- Entry " << i << " has empty "
	       << "child pointer. Cannot continue\n";
	  return false;
	}
	rv = RangeQuery ( Results, range, 
			  *(Node.entries[i].child.DereferenceLeafNode()) );
      } // if ( level 1 )

      if (Node.level > 1) {
	if (!(Node.entries[i].child.DereferenceNonLeafNode()) ) {
	  cerr << "QuerySupport::RangeQuery- Entry " << i << " has empty "
	       << "child pointer. Cannot continue\n";
	  return false;
	}
	rv = RangeQuery ( Results, range, 
			  *(Node.entries[i].child.DereferenceNonLeafNode()) );
      } // if ( level > 1 )

      // Keep track of any accumulating errors
      return_value = return_value & rv;


    } // if ( entry overlaps )
  } // foreach ( entry )
  
  return return_value;

}

// Scan LeafNodes for matching segments
bool QuerySupport::RangeQuery 
( QueryResults & Results, const MBB & range, LeafNode & Node ) const {

  bool return_value;

  // Scan through all the entries, add them to the results if
  // they overlap the given range
  for (unsigned int i=0; i<Node.numEntries && i<Node.capacity; i++) {
    MBB mbb;
    getBoundingBox ( Node.entries[i], mbb );

    // Check to see if this entry falls within our range
    if ( mbb.overlapsMBB ( range ) ) {
      bool rv = Results.push ( Node.entries[i] );
      if (!rv) {
	cerr << "QuerySupport::RangeQuery- Entry " << i << " failed to push "
	     << "onto results list\n";
      }

      return_value = return_value & rv;

    } // if ( entry overlaps )
  } // foreach ( entry )
  
  return return_value;

}



// Constructs the query results linked list
QueryResults::QueryResults() {

	// Initialize head and iterator to 0
	head     = 0;
	iterator = 0;
}

// Destroys query results
QueryResults::~QueryResults() {

	clear(); // Clear all results	
}

// Pushes result onto result stack
bool QueryResults::push(const Trajectory trj) {

	// Allocate the new node
	QueryResultNode *newNode = new QueryResultNode;
	if (newNode == 0)
		return false;

	newNode->trj = trj;
	newNode->next = head;
	head = newNode;

	return true;
}

// Pops result off top of result stack
bool QueryResults::pop(Trajectory & trj) {

	if (head == 0)
		return false;

	// Advance iterator if necessary
	if (iterator == head)
		iterator = head->next;

	// Get value of first entry in list and delete node
	trj = head->trj;
	QueryResultNode *delNode = head;
	head = head->next;
	delete delNode;

	return true;
}

// Clears all results
void QueryResults::clear() {

	// Remove all results
	while (head != 0) {
		QueryResultNode *delNode = head;
		head = head->next;
		delete delNode;
	}

	iterator = 0;
}

// Point to first entry
bool QueryResults::resetIterator() {
	iterator = head;
	if (iterator == 0)
		return false;
	else
		return true;
}

// Advance iterator
bool QueryResults::advanceIterator() {
  
  if (iterator == 0)
    return false;
  
  iterator = iterator->next;
  if (iterator == 0)
    return false;
  else
    return true;
}

// Get current trj
bool QueryResults::getIterator(Trajectory & trj) {
  if (iterator == 0)
    return false;
  else {
    trj = iterator->trj;
    return true;
  }
}


BError::Status TBTree::writeToDisk(stid_t& idxFile)
{
   return BError::OK;
}



