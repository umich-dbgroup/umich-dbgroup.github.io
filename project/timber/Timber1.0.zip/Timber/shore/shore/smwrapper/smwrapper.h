/////////////////////////////////////////////////////////////////
//
// smwrapper.h: Wrapper for the SHORE Storage Manager
// 
/////////////////////////////////////////////////////////////////

#ifndef __SM_WRAPPER_H
#define __SM_WRAPPER_H

#include "w_defines.h"

#include <w_stream.h>
#include <sys/types.h>
#include <memory.h>
#include <assert.h>
#include "sm_vas.h"
#include "berror.h"
#include "myTimer.h"

#ifdef _WINDOWS
#include "getopt.h"
#endif

#if defined(__GNUG__) && __GNUC_MINOR__ < 6 && defined(Sparc)
extern "C" int getopt(int argc, char** argv, char* optstring);
#endif

#if defined(__GNUG__) && defined(Sparc)
extern char *optarg;
extern int optind, opterr;
#endif

#include <iostream>
#include <string>
// using namespace std;

using std::string;

// Shorten type name
typedef	smlevel_0::smksize_t smksize_t;

////////////////////////////////////////////////////////////////////////
// 
// PersistentType: The root of the class hierarchy of classes whose instances can
//                 be stored persistently as SHORE records
//
////////////////////////////////////////////////////////////////////////
class PersistentType
{
public:

   //
   // Convert to a SHORE byte representation. 
   //
   virtual BError::Status Serialize(char*& buffer,               // O- set to the output buffer
                                    unsigned& length) const = 0; // O- set to the length of the output buffer

   // Conservatively Estimate the length of the serialized representation in bytes
   virtual BError::Status SerialzedLength(unsigned& length) = 0; // O- estimated length

   //
   // Convert from a SHORE record to an in-memory representation. 
   // 
   virtual BError::Status UnSerialize(const char* buffer,     // I- the buffer returned from Serialize
                                      const unsigned length) = 0;  // I- the length of the serialized representation
};

////////////////////////////////////////////////////////////////////////
//
// SMinterface: An wrapper/abstraction for the SHORE Storage Manager.
//
////////////////////////////////////////////////////////////////////////
class SMinterface 
{
public:

   ///////////////////////////////////////////////////////
   // Abstract out shore types using our typedefs
   ///////////////////////////////////////////////////////
   typedef stid_t       FileID;           // typedef for a SHORE File id
   typedef rid_t        RecID;            // typedef for a SHORE Record id
   typedef pin_i        PinHandle;        // handle to a record pinned in the buffer pool 
   typedef scan_file_i  FileScanCursor;   // typedef for a SHORE File scan cursor.

   ///////////////////////////////////////////////////////
   // Constructor and Destructor methods
   ///////////////////////////////////////////////////////
	SMinterface();
	~SMinterface();

   ///////////////////////////////////////////////////////
   // Initialize the Storage Manager
   ///////////////////////////////////////////////////////
	BError::Status Create(const string& optionFilename, // Initializes the storage manager
                         bool formatDevice = false);   // I- If true, format device
//	BError::Status Destroy();                     // Destroys the storage manager

   ///////////////////////////////////////////////////////
   // Supporting methods to return internal structures
   // TODO: remove these - jmp
   ///////////////////////////////////////////////////////
   ss_m * get_ssm();
	lvid_t get_lvid();

   ///////////////////////////////////////////////////////
   // Transaction support
   ///////////////////////////////////////////////////////
   BError::Status BeginTransaction();   // Start a transaction
	BError::Status CommitTransaction();  // Commit the transaction

   ///////////////////////////////////////////////////////
   // Flush the buffer pool; useful for measuring "cold" performance numbers
   ///////////////////////////////////////////////////////
   BError::Status FlushBufferPool();

   ///////////////////////////////////////////////////////
   // Measure shore buffer pool statistics
   ///////////////////////////////////////////////////////
   BError::Status BeginStatsMeasurements(); // Start the statistics counters
   BError::Status StopStatsMeasurements();  // Stop the counters
   BError::Status PrintStatsMeasurements(const string displayMsg); // Display gathered statistics

   ///////////////////////////////////////////////////////
   // Create and Destroy Shore Files
   ///////////////////////////////////////////////////////
   BError::Status CreateFile(FileID& fid);        // O- File ID of table
   BError::Status DestroyFile(const FileID& fid); // I- File ID of table

   ///////////////////////////////////////////////////////
   // Similar create and destroy functions, but using file names. 
   // Internally these functions create shore files, and remember the 
   // association between filename and the FileID. 
   // NOTE: filenames must be unique
   ///////////////////////////////////////////////////////
   BError::Status CreateFile(const char* filename,   // I- name of the file
                             FileID& fid);           // O- retuned shore file id
   BError::Status DestroyFile(const char* filename); // I- name of the file

   ///////////////////////////////////////////////////////
   // insert/update/delete Tuples
   ///////////////////////////////////////////////////////
   BError::Status InsertTuple(const FileID& fid,            // I- shore file id in which tuple is created
                              const PersistentType & tuple, // I- tuple to insert
                              RecID & rid);                 // O- returned record id
	BError::Status UpdateTuple(const RecID & rid,            // I- Record id of the tuple being updated
                              const PersistentType & tuple);// I- The new value for the updated tuple 
	BError::Status RemoveTuple(const RecID & rid);           // I- Record id of the tuyple being deleted

   ///////////////////////////////////////////////////////
   // Fetch a tuple given its record id
   ///////////////////////////////////////////////////////
	BError::Status ReadTuple(const RecID & rid,       // I- the record id of the record being read
                            PersistentType & tuple); // O- the value of the record

   // Pin a tuple in the buffer pool (WARNING: the caller of this function must call unpin later!)
   BError::Status ReadTuple(const RecID& rid,   // I- the record id of the record being read
                            PinHandle& handle); // O- the pin handle
   
   // unpin a tuple
   BError::Status UnpinTuple(/*const*/ PinHandle& handle); // I- the pin handle

   // returns a pointer to the tuple contents.
   // WARNING: this pointer points to data in the buffer pool, so 
   // use the contents very carefully.
   BError::Status GetTupleContents(/*const*/ PinHandle* handle, // I- the pin handle
                                   const char*& data,           // O- the tuple data
                                   unsigned& length);           // O- the length of the data

   ///////////////////////////////////////////////////////
   // Scan a SHORE file using a cursor mechanism
   ///////////////////////////////////////////////////////
   // initialize the scan
   BError::Status InitializeScan(FileID& fid,           // I- File being scanned 
                                 FileScanCursor*& scan);// O- The scan cursor
   // fetch the next tuple (successive calls to this method with the same handle instance, will 
   // unpin the previous record in the scan)
	BError::Status NextTuple(FileScanCursor*&       scan,  // I/O- the file cursor (created by InitializeScan)
                            RecID &                rid,   // O- the next record id 
                            PinHandle*&            handle,// O- handle to the tuple in the buffer pool (allocated and deallocated by SHORE in the destructor for scan)
                            bool &                 eof);  // O- indicator if reached end of file.
   // end the scan
   BError::Status EndScan(FileScanCursor*& scan);// O- The scan cursor

   ///////////////////////////////////////////////////////
   // Cataloging functions to persistently remember a FileID with a string (key)
   ///////////////////////////////////////////////////////
   BError::Status CreateCatalogAssociation(const char* key,    // I- the key (filename) for the catalog entry
                                           const FileID& fid); // I- the file id for the key (filename)

   BError::Status RecallCatalogAssociation(const char* key,    // I- the key (filename) for the catalog entry
                                           FileID& fid);       // O- The file id for the key (filename)

private:
	BError::Status setupOptions(const string optionFilename);  // I- Options file name

	BError::Status setupDevice(bool formatDevice = false);    // I- If true, format device

	ss_m*             ssm;        // Pointer to storage manager
	option_group_t*   options;    // Options structure
	string            deviceName; // Name of device
   smksize_t         quota;      // Device and volume quota in kilobytes
	lvid_t            lvid;       // Logical Volume ID
   vid_t             vid;        // Physical Volume ID (TODO: phase out the logical volume id)
   stid_t            rootiid;    // the root index of the volume

   sm_stats_info_t   smstats;    // measure shore statistics.
   MilliTimer        timer;      // measure elapsed time 
   double            elapsedTime;// record elapsed time.
};


/////////////////////////////////////////////////////////////
//
// Pin a tuple in the buffer pool 
//
/////////////////////////////////////////////////////////////
inline BError::Status SMinterface::ReadTuple(const RecID & rid, // I- the record id of the record being read
                                             PinHandle& handle) // O- a pin handle on the record in the buffer pool
{  
   B_CALL_SHORE(handle.pin(rid, 0)); // Pin the record at rid

   return BError::OK;
}

/////////////////////////////////////////////////////////////
//
// unpin a tuple
//
/////////////////////////////////////////////////////////////
inline BError::Status SMinterface::UnpinTuple(/*const*/ PinHandle& handle) // I- the pin handle
{  
   handle.unpin(); 
   return BError::OK;
}

// returns a pointer to the tuple contents.
// WARNING: this pointer points to data in the buffer pool, so 
// use the contents very carefully.
inline BError::Status SMinterface::GetTupleContents(/*const*/ PinHandle* handle, // I- the pin handle
                                                    const char*& data,           // O- the tuple data
                                                    unsigned& length)            // O- the length of the data
{
   if (!handle->is_small()) B_RETURN_ERROR(BError::B_NOT_IMPLEMENTED);
   data = handle->body();
   length = handle->body_size(); 
   return BError::OK;
}

#endif // __SM_WRAPPER_H
