#include "geometry.h"
#include <stdlib.h>

// Constructor sets up a Space-Time Point
STPoint::STPoint (const float x_pos, const float y_pos, const float time) {
  x = x_pos;
  y = y_pos;
  t = time;
}

// Constructor sets the coordinates for a Trajectory
Trajectory::Trajectory(const float sx, const float sy, const float st,
		       const float ex, const float ey, const float et,
		       const int id) {
  start.x = sx;
  start.y = sy;
  start.t = st;
  
  end.x = ex;
  end.y = ey;
  end.t = et;
  
  object_id = id;
}

// Constructor sets the coordinates for a Trajectory
Trajectory::Trajectory (const STPoint start_point, const STPoint end_point,
			const int id) {

  start.x = start_point.x;
  start.y = start_point.y;
  start.t = start_point.t;
  
  end.x = end_point.x;
  end.y = end_point.y;
  end.t = end_point.t;
  
  object_id = id;
}


// Constructor sets the coordinates for the Minimum Bounding Box
MBB::MBB(const float b, const float t, 
	 const float l, const float r, 
	 const float s, const float e) {
  top    = t;
  bottom = b;
  
  left   = l;
  right  = r;
  
  start  = s;
  end    = e;
}

// Returns true if a given MBB overlaps this MBB
bool MBB::overlapsMBB(const MBB & mbb) const {
  
  if (left   > mbb.right || right < mbb.left   ||
      bottom > mbb.top   || top   < mbb.bottom ||
      start  > mbb.end   || end   < mbb.start )  
    return false;
  
  else
    return true;
}

// Returns true if a given Space-Time point overlaps this MBB
// Technically, this in withinMBB
bool MBB::overlapsMBB(const STPoint & point) const {
  
  if ( point.x > right || point.x < left   ||
       point.y > top   || point.y < bottom ||
       point.t > end   || point.t < start )
    return false;
  
  else
    return true;
}

// Operators to compare two MBBs
bool operator!= (MBB a, MBB b) {
  return !(a == b );
}

bool operator== (MBB a, MBB b) {
  if ( a.right == b.right && a.left   == b.left &&
       a.top   == b.top   && a.bottom == b.bottom &&
       a.end   == b.end   && a.start  == b.start )
    return true;

  else
    return false;
}


// Simple minimum function
float getMin(const float a, const float b) {
  if (a <= b)
    return a;
  else
    return b;
}

// Simple maximum function
float getMax(const float a, const float b) {
  if (a >= b)
    return a;
  else
    return b;
}

// Simple minimum function
int getMin(const int a, const int b) {
  if (a <= b)
    return a;
  else
    return b;
}

// Simple maximum function
int getMax(const int a, const int b) {
  if (a >= b)
    return a;
  else
    return b;
}


// Calculates smallest bounding Box that encloses both MBB1 and MBB2
void getBoundingBox(const MBB & mbb1, const MBB & mbb2, MBB & boundingBox) {
  
  boundingBox.bottom = getMin(mbb1.bottom, mbb2.bottom);
  boundingBox.top    = getMax(mbb1.top,    mbb2.top);
  
  boundingBox.left   = getMin(mbb1.left,   mbb2.left);
  boundingBox.right  = getMax(mbb1.right,  mbb2.right);
  
  boundingBox.start  = getMin(mbb1.start,  mbb2.start);
  boundingBox.end    = getMax(mbb1.end,    mbb2.end);
  
}

// Calculates smallest bounding Box that encloses a trajectory
void getBoundingBox(const Trajectory & trj, MBB & boundingBox) {
  
  boundingBox.bottom = getMin(trj.start.y, trj.end.y);
  boundingBox.top    = getMax(trj.start.y, trj.end.y);
  
  boundingBox.left   = getMin(trj.start.x, trj.end.x);
  boundingBox.right  = getMax(trj.start.x, trj.end.x);
  
  // This should be a no brainer, but it doesn't hurt to sanity check the data
  // i.e. What do I care if you want to run your trajectories backward?
  boundingBox.start  = getMin(trj.start.t, trj.end.t);
  boundingBox.end    = getMax(trj.start.t, trj.end.t);
  
}


// Returns a random number between min and max
int uniformInt(const int min, const int max) {
  
  double x;
  
  x = ((double)rand()) / RAND_MAX; //  x is now between 0 and 1
  
  //  Scale x so it is between min and max
  x = ((max+1) - min) * x + min;
  if (x > max)
    x = max;
  
  return (int)x;
}

double uniformDouble(const double min, const double max) {
  
  double x;
  
  x = ((double) rand()) / RAND_MAX; //  x is now between 0 and 1
  
  //  Scale x so it is between x1 and x2
  x = ((max+1) - min) * x + min;
  if (x > max)
    x = max;
  
  return x;
}
