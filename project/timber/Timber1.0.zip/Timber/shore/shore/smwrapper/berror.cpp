#include "berror.h"

using std::string;
using std::cerr;
using std::endl;
using std::ostream;
using std::ostringstream;
using std::ofstream;

namespace BError {
   
   ErrorNo* ErrorNo::en = 0;
   
   ErrorNo::ErrorNo()
   {
   }
   
   ErrorNo::~ErrorNo()
   {
   }
   
   void ErrorNo::Initialize()
   {
      if (!en) {
         ErrorNo::en = new ErrorNo();
      }
   }
   
   void ErrorNo::ShutDown()
   {
      delete ErrorNo::en;
      ErrorNo::en = 0;
   }
   
   // Again, only one global error variable
   void ErrorNo::pushTrace(Status stat, const std::string& file, int line)
   {
      std::ostringstream str;

      // Print out the error code message only for the first error entered
      if (mvTrace.size() == 0) 
      {
         std::ostringstream errMsg;
         errMsg << "BEACON ERROR: " << ErrorNo::en->getDesc(stat);
         mvTrace.push_back(errMsg.str());
      }

      // Remember the file and the line number
      str << " (" << file << "," << line << ")";
      mvTrace.push_back(str.str());
   }
   
   void ErrorNo::reset()
   {
      mvTrace.clear();
   }
   
   string ErrorNo::getTrace() const
   {
      string ret = "-- ";
      
      if (mvTrace.size() > 0) 
      {
         ret += mvTrace[0];    // This is the error message
         ret += "\n";
      }

      ret += "-- Reverse Call Stack (with FILE, LINE trace): ";
      ret += "\n";
      for (unsigned i = 1; i < mvTrace.count(); i++) 
      {
         ret += "--   ";
         ret += mvTrace[i];
         ret += "\n";
      }
      return ret;
   }

   // Print the error trace
   void ErrorNo::printTrace() const
   {
	   // Print error message to std err
	   std::cerr << BError::ErrorNo::en->getTrace() << std::endl;
   }
   
   
   // Text message describing the error codes
   string ErrorNo::getDesc(Status stat)
   {
      string ret;
      switch(stat){

      case OK:
		  ret = "OK";
		  break;
	  case BENCHMARK_BAD_PARAMS:
		  ret = "Bad benchmark parameters";
		  break;
	  case INDEX_NOT_INITIALIZED:
		  ret = "Index not initialized";
		  break;
     case B_INVALID_CL_OPTIONS:
        ret = "Invalid Command Line Options";
		  break;
	  case B_STORAGE_MANAGER:
		  ret = "Storage manager error";
		  break;
      case B_MALLOC_FAILED:
		  ret = "Could not allocate new memory";
		  break;
	  case B_NULL_POINTER:
		  ret = "NULL pointer error";
		  break;
      case B_FATAL:
		  ret = "Fatal system error";
		  break;
      case B_NOT_IMPLEMENTED:
		  ret = "Functionality not yet implemented";
		  break;
      case B_DUMMY_MARKER:
		  ret = "Dummy error code to test the error manager";
		  break;
      case B_MISSING_CATALOG_ENTRY:
		  ret = "Catalog entry missing";
		  break;

      default:
         {
            std::ostringstream str;
            str << "Unregistered Error Code. Code number: " << stat;
            return str.str();
		 }
		 break;
	  }
	  return ret;
   }
};