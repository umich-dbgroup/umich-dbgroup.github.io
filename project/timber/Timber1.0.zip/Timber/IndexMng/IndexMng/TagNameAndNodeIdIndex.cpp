/*
COPYRIGHT  (c) 2000-2004 
THE REGENTS OF THE UNIVERSITY OF MICHIGAN
ALL RIGHTS RESERVED

PERMISSION IS GRANTED TO USE, COPY, CREATE DERIVATIVE WORKS AND
REDISTRIBUTE THIS SOFTWARE AND SUCH DERIVATIVE WORKS FOR NONCOMMERCIAL
EDUCATION AND RESEARCH PURPOSES, SO LONG AS NO FEE IS CHARGED, AND SO LONG
AS THE COPYRIGHT NOTICE ABOVE, THIS GRANT OF PERMISSION, AND THE
DISCLAIMER BELOW APPEAR IN ALL COPIES MADE; AND SO LONG AS THE NAME OF THE
UNIVERSITY OF MICHIGAN IS NOT USED IN ANY ADVERTISING OR PUBLICITY
PERTAINING TO THE USE OR DISTRIBUTION OF THIS SOFTWARE WITHOUT SPECIFIC,
WRITTEN PRIOR AUTHORIZATION.

THIS SOFTWARE IS PROVIDED AS IS, WITHOUT REPRESENTATION FROM THE
UNIVERSITY OF MICHIGAN AS TO ITS FITNESS FOR ANY PURPOSE, AND WITHOUT
WARRANTY BY THE UNIVERSITY OF MICHIGAN OF ANY KIND, EITHER EXPRESS OR
IMPLIED, INCLUDING WITHOUT LIMITATION THE IMPLIED WARRANTIES OF
MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE. THE REGENTS OF THE
UNIVERSITY OF MICHIGAN SHALL NOT BE LIABLE FOR ANY DAMAGES, INCLUDING
SPECIAL, INDIRECT, INCIDENTAL, OR CONSEQUENTIAL DAMAGES, WITH RESPECT TO
ANY CLAIM ARISING OUT OF OR IN CONNECTION WITH THE USE OF THE SOFTWARE,
EVEN IF IT HAS BEEN OR IS HEREAFTER ADVISED OF THE POSSIBILITY OF SUCH
DAMAGES.
*/

#include "TagNameAndNodeIdIndex.h"

#include "gist.h"
#include "gist_btree.h"
#include "gist_cursor.h"
#include "gist_defs.h"

#include <string>
#include <iomanip>
#include <iostream>
#include <sstream>


//TagNameAndNodeIdIndex::TagNameAndNodeIdIndex(gist* gistIndex) { }

//TagNameAndNodeIdIndex::~TagNameAndNodeIdIndex(void) { }

bool TagNameAndNodeIdIndex::insertNode(const char* tagName, double nodeId, void* data,
										int dataSize, gist* gistIndex)
{
	if (gistIndex == NULL) {
		globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"TagNameAndNodeIdIndex::insertNode",__FILE__,"Gist index handler equals NULL");
		return false;
	}

	//TODO: make sure tagName does not contain DELIMITER

	// concatenate tag name and node id to create key
	string keyString = createKeyString(tagName, nodeId);
	char* key = new char[keyString.length()+1];
	strcpy(key, keyString.c_str());

	// insert key into b-tree
	rc_tGist success = gistIndex->insert(key,
										sizeof(*key)*(keyString.length()+1),
										data,
										dataSize);
	return (success == RCOKGist);
}

bool TagNameAndNodeIdIndex::deleteNode(const char* tagName, double nodeId, gist* gistIndex)
{
	if (gistIndex == NULL) {
		globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"TagNameAndNodeIdIndex::deleteNode",__FILE__,"Gist index handler equals NULL");
		return false;
	}

	// concatenate tag name and node id to create key
	string keyString = createKeyString(tagName, nodeId);
	char* key = new char[keyString.length()+1];
	strcpy(key, keyString.c_str());

	// create equality query that will find the exact key
	bt_query_t query(bt_query_t::bt_eq, (void*) key, NULL);

	// remove key from b-tree
	rc_tGist success = gistIndex->remove(&query);

	return (success == RCOKGist);
}


bt_query_t* TagNameAndNodeIdIndex::getTagNameQuery(const char* tagNamePrefix)
{
	int len = strlen(tagNamePrefix);

	// the bt_query_t destructor will free these strings (but not using delete[])

	// lower bound for range query
	char* key1 = new char[len+2];
	strcpy(key1, tagNamePrefix);
	// add the delimiter
	key1[len] = DELIMITER;
	key1[len+1] = '\0';

	// upper bound for range query
	char* key2 = new char[len+3];
	strcpy(key2, key1);
	// add a high ascii value as the last character
	key2[len+1] = 127;
	key2[len+2] = '\0';

	// create "between" query that looks for all keys between
	// the prefix and the prefix+(high ascii character) - should
	// be equivalent to a "prefix" query
	//bt_query_t* query = new bt_query_t(bt_query_t::bt_betw, (void*) key1, (void*) key2);
	bt_query_t* query = new bt_query_t(bt_query_t::bt_betw_unique_keys, (void*) key1, (void*) key2);

	return query;
}

bt_query_t* TagNameAndNodeIdIndex::getTagNameAndNodeIdQuery(const char* tagName, double nodeId)
{
	// concatenate tag name and node id to create key
	string keyString = createKeyString(tagName, nodeId);

	// the bt_query_t destructor will free this string (but not using delete[])
	char* key = new char[keyString.length()+1];
	strcpy(key, keyString.c_str());

	// create equality query that will find the exact key
	bt_query_t* query = new bt_query_t(bt_query_t::bt_eq, (void*) key, NULL);

	return query;
}

void TagNameAndNodeIdIndex::parseKey(const char* key, char** tagName, double* nodeId)
{
	//TODO: error checking isn't very good in this method yet
	*tagName = NULL;
	*nodeId = 0;

	// delimiters - just the single DELIMITER
	char* delims = new char[2];
	delims[0] = DELIMITER;
	delims[1] = '\0';

	if (key != NULL) {
		// copy the key so we can strtok it
		char* keyCopy = new char[strlen(key)+1];
		strcpy(keyCopy, key);

		char *tag = strtok(keyCopy, delims);
		if (tag != NULL) {
			*tagName = new char[strlen(tag)+1];
			strcpy(*tagName, tag);

			char *id = strtok(NULL, delims);
			if (id != NULL) {
				sscanf(id, "%lf", nodeId);
			}
		}

		delete[] keyCopy;
	}
	delete[] delims;

}

string TagNameAndNodeIdIndex::createKeyString(const char* tagName, double nodeId)
{
	// <tagName><DELIMITER><nodeId><DELIMITER>
	stringstream ss;
	// the following ensures that trailing zeros are preserved
	// (that's important for formatting later)
	ss << setiosflags(ios::fixed);
	ss << tagName;
	ss << DELIMITER;
	// the following adds leading zeros to the node id (it sets
	// the width to the # of digits to the left of the decimal
	// point + the # of digits to the right of the decimal point +
	// 1 (for the decimal point) and pads the left with 0's.  the
	// right side will always have NUM_RIGHT_DIGITS since ios::fixed
	// was set earlier)

	//NOTE:
	//setprecision does one of two things: 
	//if the fixed flag HAS NOT been set, the value num specifies the total number of digits to display 
	//if the fixed flag HAS been set, the value num specifies the number of digits to display after the decimal point 

	ss << setw(NUM_LEFT_DIGITS + NUM_RIGHT_DIGITS + 1) << setfill('0')
		<< setprecision(NUM_RIGHT_DIGITS) << nodeId;
	ss << DELIMITER;

	string str = ss.str();
	return str;
}

int TagNameAndNodeIdIndex::getKeyLength(const char* tagName) {
	string s = createKeyString(tagName, 0.0);
	return s.size();
}