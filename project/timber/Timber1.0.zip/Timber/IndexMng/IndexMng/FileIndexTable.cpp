/*
COPYRIGHT  (c) 2000-2004 
THE REGENTS OF THE UNIVERSITY OF MICHIGAN
ALL RIGHTS RESERVED

PERMISSION IS GRANTED TO USE, COPY, CREATE DERIVATIVE WORKS AND
REDISTRIBUTE THIS SOFTWARE AND SUCH DERIVATIVE WORKS FOR NONCOMMERCIAL
EDUCATION AND RESEARCH PURPOSES, SO LONG AS NO FEE IS CHARGED, AND SO LONG
AS THE COPYRIGHT NOTICE ABOVE, THIS GRANT OF PERMISSION, AND THE
DISCLAIMER BELOW APPEAR IN ALL COPIES MADE; AND SO LONG AS THE NAME OF THE
UNIVERSITY OF MICHIGAN IS NOT USED IN ANY ADVERTISING OR PUBLICITY
PERTAINING TO THE USE OR DISTRIBUTION OF THIS SOFTWARE WITHOUT SPECIFIC,
WRITTEN PRIOR AUTHORIZATION.

THIS SOFTWARE IS PROVIDED AS IS, WITHOUT REPRESENTATION FROM THE
UNIVERSITY OF MICHIGAN AS TO ITS FITNESS FOR ANY PURPOSE, AND WITHOUT
WARRANTY BY THE UNIVERSITY OF MICHIGAN OF ANY KIND, EITHER EXPRESS OR
IMPLIED, INCLUDING WITHOUT LIMITATION THE IMPLIED WARRANTIES OF
MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE. THE REGENTS OF THE
UNIVERSITY OF MICHIGAN SHALL NOT BE LIABLE FOR ANY DAMAGES, INCLUDING
SPECIAL, INDIRECT, INCIDENTAL, OR CONSEQUENTIAL DAMAGES, WITH RESPECT TO
ANY CLAIM ARISING OUT OF OR IN CONNECTION WITH THE USE OF THE SOFTWARE,
EVEN IF IT HAS BEEN OR IS HEREAFTER ADVISED OF THE POSSIBILITY OF SUCH
DAMAGES.
*/

#include "FileIndexTable.h"

/**
* FileIndexTable
* 
* This class is an index catalog given an xml document name
* return the index info associated with
* 
* @version 1.0
*/

/**
* Constructor
*
* @param volumeID The device volume id (handler)
*/
FileIndexTable::FileIndexTable(lvid_t volumeID)
{
	this->volumeID = volumeID;
	serial_t root_iid;

	// find the root index of SHORE

	rc_t rc = ss_m::vol_root_index(this->volumeID, root_iid);
	if (rc)
	{
		globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"FileIndexTable::FileIndexTable",__FILE__,"After looking for root index");
		return;
	}
	
	// look for the FileIndexTable file in SHORE
	char* name = "FileIndexTable";
	int namesize = strlen(name);
	smsize_t size = sizeof(serial_t);
	bool found = false;
	rc = ss_m::find_assoc(this->volumeID, root_iid,
				vec_t(name, namesize),
 				&(this->FileIndexTable_IndexID), 
				size,
				found);
	if (rc)
	{
		globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"FileIndexTable::FileIndexTable",__FILE__,"After looking for FileIndexTable in root index");
		return;
	}

	if (!found)
	{
		// if the FileIndexTable can not be found, this means, it is
		// the first run of the database

		// create a FileIndexTable Index
		
		char index_t[10] = "b*";
		char size[10];
		itoa(MAX_XMLFILE_NAME_LENGTH, size, 10);
		strcpy(index_t+2, size);

		rc = ss_m::create_index(this->volumeID, 
								ss_m::t_btree, 
								ss_m::t_regular,
								index_t, 0, 
								this->FileIndexTable_IndexID);
		if (rc)
		{
			globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"FileIndexTable::FileIndexTable",__FILE__,"After creating a new index");
			return;
		}

		// Create association of the file and its name in root index of SHORE

		rc = ss_m::create_assoc(this->volumeID, root_iid,
					vec_t("FileIndexTable", strlen("FileIndexTable")),
 					vec_t(&(this->FileIndexTable_IndexID), sizeof(serial_t)));
		if (rc)
		{
			globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"FileIndexTable::FileIndexTable",__FILE__,"After creating entry in root index");
			return;
		}
	}

	return;

}

/**
* Process method
* Insert new index association due to a creation
*
* @param filename The XML document file name
* @param indexinfo The index description of IndexInfoType
* @returns Error code
*/
int	FileIndexTable::insertIndex(char* filename,
		IndexInfoType* indexinfo)
{
	// duplication allowed:
	// one file can have more than one index built on it.

	rc_t rc = ss_m::create_assoc(this->volumeID, this->FileIndexTable_IndexID,
				vec_t(filename, strlen(filename)),
				vec_t(indexinfo, sizeof(IndexInfoType)));
	if (rc)
	{
		globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"FileIndexTable::insertIndex",__FILE__,"After create an entry in the index");
		return -1;
	}

	return 0;
}

/**
* Process method
* Delete new index associated with an XML file
*
* @param filename The XML document file name
* @param indexname The name of index built on this file
* @returns Error code
*/
int FileIndexTable::deleteIndex(char* filename, char* indexname)
{
	rc_t rc;
	IndexInfoType* indexinfo;

	//scan all indexs associated with this file
	startScanIndex(filename);
	indexinfo = getNextIndexInfo(); 
	while (indexinfo)
	{
		//match only the index name in need
		if (strcmp(indexinfo->indexName, indexname) == 0)
		{
			rc = ss_m::destroy_assoc(this->volumeID, 
				this->FileIndexTable_IndexID,
				vec_t(filename, strlen(filename)),
				vec_t(indexinfo, sizeof(IndexInfoType)));
			
			if (rc) {
				delete indexinfo;
				closeScanIndex();
				globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"FileIndexTable::deleteIndex",__FILE__,"After delete index");
				return -1;
			}
			delete indexinfo;
			closeScanIndex();
			return 0;
		}
		delete indexinfo;
		indexinfo = getNextIndexInfo();
	}
	
	closeScanIndex();
	globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"FileIndexTable::deleteIndex",__FILE__,"File does not have index with name");
	return -1;
}

/**
* Scan method
* Start scan of all index of particular document
*
* @param filename The XML document file name
*/
void FileIndexTable::startScanIndex(char* filename)
{
	this->keySize = strlen(filename);
	this->key = new vec_t(filename, this->keySize);
	scanIndex = new scan_index_i(this->volumeID, 
								 this->FileIndexTable_IndexID, 
								 ss_m::eq, 			
								 *this->key,
								 ss_m::eq, 
								 *this->key);

	if (scanIndex->error_code()){
		scanIndex->finish();
		globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"FileIndexTable::startScanIndex",__FILE__,"After scan index");
		this->eof = true;
		return;
	}

	this->eof = false;
	return;
}

/**
* Scan method
* Get next matching index of the current scan
*
* @returns Index info of the matching index
*/
IndexInfoType* FileIndexTable::getNextIndexInfo()
{
	rc_t rc = scanIndex->next(eof);
	if (rc)
	{
		scanIndex->finish();
		globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"FileIndexTable::getNextIndexInfo",__FILE__,"After fetching next index from FileIndexTable");
		return NULL;
	}

	if (eof)
	{
		scanIndex->finish();
		return NULL;
	}

	unsigned long dataSize = sizeof(IndexInfoType);
	IndexInfoType* indexinfo = new IndexInfoType;//(dataSize];
	vec_t* vec_ptr = new vec_t(indexinfo, dataSize);

	rc = scanIndex->curr(this->key,
						 (unsigned long &)this->keySize,
						 vec_ptr,
						 dataSize);
	
	delete vec_ptr;
	if (rc)
	{
		scanIndex->finish();
		globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"FileIndexTable::getNextIndexInfo",__FILE__,"After fetching next index using current function from FileIndexTable");
		return NULL;
	}

	return indexinfo;
}

/**
* Scan method
* Close and finish the scan index iterator
*/
void FileIndexTable::closeScanIndex()
{
	scanIndex->finish();
	delete this->key;
	delete scanIndex;
}

