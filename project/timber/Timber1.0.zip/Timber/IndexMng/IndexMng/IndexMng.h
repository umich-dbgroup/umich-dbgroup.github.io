/*
COPYRIGHT  (c) 2000-2004 
THE REGENTS OF THE UNIVERSITY OF MICHIGAN
ALL RIGHTS RESERVED

PERMISSION IS GRANTED TO USE, COPY, CREATE DERIVATIVE WORKS AND
REDISTRIBUTE THIS SOFTWARE AND SUCH DERIVATIVE WORKS FOR NONCOMMERCIAL
EDUCATION AND RESEARCH PURPOSES, SO LONG AS NO FEE IS CHARGED, AND SO LONG
AS THE COPYRIGHT NOTICE ABOVE, THIS GRANT OF PERMISSION, AND THE
DISCLAIMER BELOW APPEAR IN ALL COPIES MADE; AND SO LONG AS THE NAME OF THE
UNIVERSITY OF MICHIGAN IS NOT USED IN ANY ADVERTISING OR PUBLICITY
PERTAINING TO THE USE OR DISTRIBUTION OF THIS SOFTWARE WITHOUT SPECIFIC,
WRITTEN PRIOR AUTHORIZATION.

THIS SOFTWARE IS PROVIDED AS IS, WITHOUT REPRESENTATION FROM THE
UNIVERSITY OF MICHIGAN AS TO ITS FITNESS FOR ANY PURPOSE, AND WITHOUT
WARRANTY BY THE UNIVERSITY OF MICHIGAN OF ANY KIND, EITHER EXPRESS OR
IMPLIED, INCLUDING WITHOUT LIMITATION THE IMPLIED WARRANTIES OF
MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE. THE REGENTS OF THE
UNIVERSITY OF MICHIGAN SHALL NOT BE LIABLE FOR ANY DAMAGES, INCLUDING
SPECIAL, INDIRECT, INCIDENTAL, OR CONSEQUENTIAL DAMAGES, WITH RESPECT TO
ANY CLAIM ARISING OUT OF OR IN CONNECTION WITH THE USE OF THE SOFTWARE,
EVEN IF IT HAS BEEN OR IS HEREAFTER ADVISED OF THE POSSIBILITY OF SUCH
DAMAGES.
*/

#ifndef __IndexManagement_H
#define __IndexManagement_H

#include "../IndexOperation/ShoreIndexUpdate.h"
#include "../IndexOperation/HashIndexUpdate.h"
#include "../IndexOperation/GistIndexUpdate.h"
#include "IndexNameTable.h"
#include "FileIndexTable.h"
#include "../../PhysicalDataMng/SystemCatalog/XMLNameTable.h"

#include "TagNameAndNodeIdIndex.h"

/**
* This class is for Index Management
* 
* This class interpret the index description, build index and help access 
* the indexes
* 
*/

class IndexMng
{
	friend class IndexMatching;
	friend class IndexIncrementalUpdate;
public:
	/**
	* Constructor
	* Build the Index Management based on the current Data Management.
	* @param pDataMng The current Data Management
	*/
	IndexMng(PhysicalDataMng* pDataMng);

	/**
	* Default destructore
	*/
	~IndexMng();

	/** 
	* Access  Method
	* Get the Timber configuration instance
	*/
	//Settings* getSettings();

	/**
	* Process Method
	*
	* Build value index with given name, based on the data from a file 
	* (xml document), and satisfy the index description and predicates.
	*
	* @param filename The name of the file (xml document) the index is going to built on.
	* @param index_description The description of the value index. value can be
	* <pre>
	*@@	VALUEINDEX_ELEMENTTAG			build index on element tag (using tag encoding)
	*@@	VALUEINDEX_ELEMENTTAGSTR		build index on element tag (using tag name)
	*@@	VALUEINDEX_CHILDNUMBER			build index on element node, based on number of children
	*@@	VALUEINDEX_ATTRIBUTENUMBER		build index on element node, based on number of attribute
	*@@	VALUEINDEX_ATTRIBUTENAME		build index on attribute node, based on each of the attribute name
	*@@	VALUEINDEX_ATTRIBUTEVALUE		build index on attribute node, based on each of the attribute value.
	*@@	VALUEINDEX_TEXTVALUE			build index on text node, based on the contend of the node
	*@@	VALUEINDEX_ATTRIBUTECONTENT		build index on element node, based on the value of the attribute of a given value
	*@@	VALUEINDEX_ELEMENTCONTENT		build index on the element node (with given tag), based on the value of the textnode which is its direct child
	*@@	VALUEINDEX_INVERTEDINDEX_ELEM	build index on element node, based on words in its text.	
	*@@	VALUEINDEX_INVERTEDINDEX_TEXT   build index on text node, based on words in its text.	
	*@@ VALUEINDEX_TAGNAME_ID_PAIR		build index on a combined element tag and tag node id, for updatable operations
	*@@ VALUEINDEX_ATTRIBUTENAME_ID_PAIR	build index on a combined attribute name and node id, for updatable operations
	* <\pre>
	* @param strval The string value that is used for some type of index, e.g. VALUEINDEX_ATTRIBUTECONTENT, VALUEINDEX_ELEMENTCONTENT
	* @param indexSource is either SHORE_INDEX or GIST_INDEX or HASH_INDEX. If it is SHORE_INDEX, it builds a shore index. Otherwise, it 
	*			builds a GIST_INDEX.
	* @param indexType is either INT_INDEX, FLOAT_INDEX, or STRING_INDEX. In some indices, the type is determined by the system by default.
	* @param indexName The name of the index created (return value)
	* @param colorName Optional value for the name suffix of multicolor index (for Multicolor XML)
	* @param rootColor The key of the root of the color tree (for Multicolor XML)
	* @returns Whether the index is created successfully. 
	*/
	bool buildValueIndex(
		char* filename,
		int index_description,
		// the name is used for some indextype, e.g. elementcontent
		char* strval,
		int indexSource,
		int indexType, 
		char *indexName = NULL, 
		char *colorName = NULL,
		KeyType rootColor = 0);

	/**
	* Process Method
	*
	* Build value join index with given name, based on the data from a file 
	* (xml document), and satisfy the index description.
	* It reads witness tree results from a file generated by the evaluator.
	* It assume that the witness node with nre =1 is the left side, nre = 2 is the right side
	*
	* @param filename The name of the file (xml document) the index is going to built on.
	* @param witnessFile The name of the witness tree file produced by evaluator evaluated the join conditions.
	* @param indexSource is assumed to be only GIST_INDEX.
	* @param leftSide The value of th left side (key side) that the index built on
	* @param leftSideIndexType The type of the left side predicate (key), either JOININDEX_ELEMENTCONTENT, JOININDEX_ATTRIBUTEVALUE or JOININDEX_ATTRIBUTECONTENT
	* @param rightSide The value of th right side (return side) that the index built on
	* @param rightSideIndexType The type of the right side predicate (return), either JOININDEX_ELEMENTCONTENT, JOININDEX_ATTRIBUTEVALUE or JOININDEX_ATTRIBUTECONTENT
	* @returns Whether the index is created successfully. 
	*/
	bool buildJoinIndex(
		char* filename,
		char* witnessFileName,
		int indexSource,
		char* leftSide, 
		int leftSideIndexType,
		char* rightSide,
		int rightSideIndexType);

	/**
	* Process Method
	*
	* Create a value join query plan from 2-side predicates given
	* It assume that the plan created will have witness node with nre =1 as the left side, nre = 2 as the right side
	*
	* @param filename The name of the file (xml document) the index is going to built on.
	* @param planFileName The name of the plan tree file to be written to. (return value)
	* @param witnessFileName The name of the witness tree file to be produced by evaluator. (return value)
	* @param indexSource is assumed to be only GIST_INDEX.
	* @param leftSide The value of th left side (key side) that the index built on
	* @param leftSideIndexType The type of the left side predicate (key), either JOININDEX_ELEMENTCONTENT, JOININDEX_ATTRIBUTEVALUE or JOININDEX_ATTRIBUTECONTENT
	* @param rightSide The value of th right side (return side) that the index built on
	* @param rightSideIndexType The type of the right side predicate (return), either JOININDEX_ELEMENTCONTENT, JOININDEX_ATTRIBUTEVALUE or JOININDEX_ATTRIBUTECONTENT
	* @returns Whether the index is created successfully. 
	*/
	bool createJoinIndexQueryPlan(
		char* filename,
		char* planFileName, //return value
		char* witnessFileName, //return value
		char* leftSide, 
		int leftSideIndexType,
		char* rightSide,
		int rightSideIndexType);


	/**
	* Process Method
	* Delete index from Timber
	*
	* @param filename The name of the XML document
	* @param indexDescription The description of the value index. 
	* @param strval The string value that is used for some type of index, e.g. VALUEINDEX_ATTRIBUTECONTENT, VALUEINDEX_ELEMENTCONTENT
		* @param indexSource is assumed to be only GIST_INDEX.
	* @param indexType is either INT_INDEX, FLOAT_INDEX, or STRING_INDEX.	
	* * for join index
	* @param leftSide The value of th left side (key side) that the index built on
	* @param leftSideIndexType The type of the left side predicate (key), either JOININDEX_ELEMENTCONTENT, JOININDEX_ATTRIBUTEVALUE or JOININDEX_ATTRIBUTECONTENT
	* @param rightSide The value of th right side (return side) that the index built on
	* @param rightSideIndexType The type of the right side predicate (return), either JOININDEX_ELEMENTCONTENT, JOININDEX_ATTRIBUTEVALUE or JOININDEX_ATTRIBUTECONTENT
	* * for multicolor xml
	* @param colorName Optional value for the name suffix of multicolor index
	* @param rootColor The key of the root of the color tree
	* @returns Whether the index is deleted successfully. 
	*/
	bool deleteIndex(char* filename, int indexDescription, char* strval,int indexSource,int indexType, 
		char* leftSide = NULL,int leftSideIndexType = 0,char* rightSide = NULL,	int rightSideIndexType = 0,	
		char *colorName = NULL,	KeyType rootColor = 0);

	/**
	* Process Method
	* Delete an index from Timber
	*
	* @param indexname The name of the index to be deleted
	* @returns Whether the deletion is done successfully
	*/
	bool deleteIndex(char* indexname);


	/**
	* Metainfo Retrieval Method
	*
	* Check whether the index of the name given exists in the database
	* @param indexName the name of the index
	* @returns Boolean value whether an index exists 
	*/
	bool existIndex(char* indexName);

	/*
	* Metainfo Retrieval Method
	*
	* Find the index that match the description and value predicate
	* @param filename The name of the XML document
	* @param indexDescription The index that want to find its existent in the system
	* @param v Right Value of a predicate condition that the index built on
	* @param valueType the type of the value
	* @returns IndexInfoType of the index that matched the tvalue and description
	*/
	IndexInfoType* getMatchingIndex(char *filename, int indexDescription,	Value *v=NULL, int valueType = -1);

	/*
	* Metainfo Retrieval Method
	*
	* Find the index that match the description and value predicate
	* @param filename The name of the XML document
	* @param indexDescription The index that want to find its existent in the system (expect JOININDEX)
	* @param leftSide Value of a left side (key side) that the index built on
	* @param leftSideType Type of a left side (key side) that the index built on see IndexMng_definitions.h
	* @param rightSide Value of a right side (return side) that the index built on
	* @param rightSideType Type of a right side (return side) that the index built on see IndexMng_definitions.h
	* @returns IndexInfoType of the index that matched the value and description
	*/
	IndexInfoType* getMatchingIndex(char *filename, int indexDescription,
		char* leftSide, int leftSideType, char* rightSide, int rightSideType);

	//----------Debugging method------------//

	/**
	* Debugging method
	* Dump everything from a gist index file into standard cout
	* 
	* @param indexName Index file name
	*/
	void dumpIndex(char* indexName);

	/**
	* Debugging method
	* Get all indices built on the system with all information
	* concatenated in a string
	* 
	* @param num Counting number of indices (return value)
	* @returns Verbose index description, with file name, and other descriptions
	*/
	char **getIndexNamesAndInfo(int *num);

	/**
	* Debugging method
	* Get all indices built on given filename with all information
	* concatenated in a string
	* 
	* @param filename The name of the document
	* @param num Counting number of indices (return value)
	* @returns Verbose index description, with file name, and other descriptions
	*/
	char **getIndexNamesAndInfoForFile(char *fileName, int *num);


private:

	/**
	* Internal method
	* Construct standard index name from the properties of the index
	* Usually index_filename_description_type_optionalvalues
	* or joinindex_filename_lefttype_left_righttype_right
	*
	* @param filename The name of the file (xml document) the index is going to built on.
	* @param indexName The name of the index created (return value)
	* @param indexDescription The description of the value index. 
	* @param strval The string value that is used for some type of index, e.g. VALUEINDEX_ATTRIBUTECONTENT, VALUEINDEX_ELEMENTCONTENT
	* @param indexType is either INT_INDEX, FLOAT_INDEX, or STRING_INDEX.	
	* * for join index
	* @param leftSide The value of th left side (key side) that the index built on
	* @param leftSideIndexType The type of the left side predicate (key), either JOININDEX_ELEMENTCONTENT, JOININDEX_ATTRIBUTEVALUE or JOININDEX_ATTRIBUTECONTENT
	* @param rightSide The value of th right side (return side) that the index built on
	* @param rightSideIndexType The type of the right side predicate (return), either JOININDEX_ELEMENTCONTENT, JOININDEX_ATTRIBUTEVALUE or JOININDEX_ATTRIBUTECONTENT
	* * for multicolor xml
	* @param colorName Optional value for the name suffix of multicolor index
	* @param rootColor The key of the root of the color tree
	* @returns Whether the name is constructed properly. 
	*/
	bool constructIndexName(char* fileName,	char* indexName, int indexDescription,	char* strval,int indexType, 
		char* leftSide = NULL,	int leftSideIndexType = 0,	char* rightSide = NULL,	int rightSideIndexType = 0,	
		char *colorName = NULL,	KeyType rootColor = 0);

	//---------Debugging method----------//

	/**
	* Debug Method
	* Get the string description of an index from index infotype
	*
	* @param indexInfo The index information
	* @param description The string description (return value)
	* @param size String length (return value)
	*/
	void getIndexDescription(IndexInfoType *indexInfo,char *description,int &size);
	

	/**
	* Debug Method
	* Write node information into a text file
	* 
	* @param textIndexName Text file name
	* @param in The input in ListNode type
	*/
	void buildTextFile(char *textIndexName,ListNode *in);

	//---------Private object----------//

	/**
	* The Data Management which this class may access when retrieving data
	*/
	PhysicalDataMng* pDataMng;

	/**
	* Shore's volume ID
	*/
	lvid_t volumeID;

	IndexNameTable* indexNameTable;

	FileIndexTable* fileIndexTable;

	XMLNameTable* xmlNameTable;
};

#endif