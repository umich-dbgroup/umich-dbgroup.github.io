/*
COPYRIGHT  (c) 2000-2004 
THE REGENTS OF THE UNIVERSITY OF MICHIGAN
ALL RIGHTS RESERVED

PERMISSION IS GRANTED TO USE, COPY, CREATE DERIVATIVE WORKS AND
REDISTRIBUTE THIS SOFTWARE AND SUCH DERIVATIVE WORKS FOR NONCOMMERCIAL
EDUCATION AND RESEARCH PURPOSES, SO LONG AS NO FEE IS CHARGED, AND SO LONG
AS THE COPYRIGHT NOTICE ABOVE, THIS GRANT OF PERMISSION, AND THE
DISCLAIMER BELOW APPEAR IN ALL COPIES MADE; AND SO LONG AS THE NAME OF THE
UNIVERSITY OF MICHIGAN IS NOT USED IN ANY ADVERTISING OR PUBLICITY
PERTAINING TO THE USE OR DISTRIBUTION OF THIS SOFTWARE WITHOUT SPECIFIC,
WRITTEN PRIOR AUTHORIZATION.

THIS SOFTWARE IS PROVIDED AS IS, WITHOUT REPRESENTATION FROM THE
UNIVERSITY OF MICHIGAN AS TO ITS FITNESS FOR ANY PURPOSE, AND WITHOUT
WARRANTY BY THE UNIVERSITY OF MICHIGAN OF ANY KIND, EITHER EXPRESS OR
IMPLIED, INCLUDING WITHOUT LIMITATION THE IMPLIED WARRANTIES OF
MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE. THE REGENTS OF THE
UNIVERSITY OF MICHIGAN SHALL NOT BE LIABLE FOR ANY DAMAGES, INCLUDING
SPECIAL, INDIRECT, INCIDENTAL, OR CONSEQUENTIAL DAMAGES, WITH RESPECT TO
ANY CLAIM ARISING OUT OF OR IN CONNECTION WITH THE USE OF THE SOFTWARE,
EVEN IF IT HAS BEEN OR IS HEREAFTER ADVISED OF THE POSSIBILITY OF SUCH
DAMAGES.
*/

#include "IndexMatching.h"
#include <list>
#include <map>
#include <set>
#include <vector>
#include <iostream>

using namespace std;

/*
* Template function
*
* Returns the duplicated list
*/
template <class T>
list<T>* duplicateList(list<T> *l)
{
	list<T> *nl = new list<T>;
	for (list<T>::iterator it = l->begin(); it != l->end(); ++it) {
		nl->push_back(*it);
	}
	return nl;
}

/**
* This class is for Index Matching
* 
* This class try to match index created with condition specified
* currently only either full match or superset match
*
* @author Rushi Dasai et al
* @author Nuwee Wiwatwattana 
* @version 1.0
*/

/**
* Default Constructor
*/
IndexMatching::IndexMatching(IndexMng* indexMng)
{
	this->indexMng = indexMng;
	this->pDataMng = indexMng->pDataMng;
	this->volumeID = pDataMng->getVolumeID();
}

/*
* Process Method
*
* Match each conjunctive condition
*
* Find a set of combination of index that match particular conjunctive condition.
* Process is classified by the type of the node in the selection condition.
* In each type, we try to find either an index or combination of them that can fully answer
* or partially answer the query (conjunct). For partial match, the filtering conditions
* that need to be further apply on are also given in each combination information.
*
* @param fileName The name of the XML document
* @param nodeType The node type of the selection condition
* @param conj Conjunctive condition break down from disjunctive conditions
* @param icFullSet Index Combination Set that can fully answer this conjunctive condition (return value)
* @param icPartialSet Index Combination Set that can partially answer this conjunctive condition (return value)
* @returns Whether it has any errors
*/
int IndexMatching::matchIndex(char* fileName, 
							  int nodeType,
							  ConjunctiveCondition* ccond,
							  IndexCombSet& icFullSet,
							  IndexCombSet& icPartialSet) 
{
	int retval = 0;

	//switch process according to node type in the selection condition
	switch (nodeType) {
  case TEXT_NODE:
	  retval = matchTextIndex(fileName, ccond, icFullSet);
	  break;
  case ELEMENT_NODE:
	  retval = matchElementIndex(fileName, ccond, icFullSet, icPartialSet);
	  break;
  case ATTRIBUTE_NODE:
	  retval = matchAttributeIndex(fileName, ccond, icFullSet, icPartialSet);
	  break;
  default:
	  retval = 0;
	}
	
	return retval;
}

/*
* Internal Method
*
* Match text index for text node type in the selection condition
* This can only match VALUEINDEX_TEXTVALUE
* @param fileName The name of the XML document
* @param conjunct Conjunctive condition
* @param icFullSet The index combination set that can fully answer the given conjunctive condition (return value)
* @returns Whether there is an error
*/
int IndexMatching::matchTextIndex(char *fileName, 
								  ConjunctiveCondition* ccond,
								  IndexCombSet& icFullSet) 
{
	// If this is a text lookup, there can only be one PredicateCondition
	if (ccond->getNumber() != 1) {
		//std::cout << "error: Ccond can only have one text value selection";
		globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"IndexMatching::matchTextIndex",__FILE__,"A Conjunct can only have one text value selection.");
		return -1;
	}

	// This is that PredicateCondition
	PredicateCondition* cond = ccond->getCondAt(0);
	IndexInfoType* indexinfo = NULL;
	
	if ((cond->getRightValue()->getValueType() != STRING_VALUE) ||
			((cond->getRightValue()->getValueType() == STRING_VALUE) &&
			(strcmp(cond->getRightValue()->getStrValue(),"") != 0) &&
			(strcmp(cond->getRightValue()->getStrValue()," ") != 0)))
		{

			indexinfo = this->indexMng->getMatchingIndex(fileName, VALUEINDEX_TEXTVALUE, NULL, cond->getRightValue()->getValueType());
		}
		// If we found a text value index, let's use it
	if (indexinfo != NULL) {
		IndexMatchingType *imt = new IndexMatchingType(indexinfo,cond);
		// Create an index combination
		IndexCombination* ic = new IndexCombination();
		ic->ilist.push_back(imt);
		ic->filter = NULL; //no filter needed
		//Pack it
		push_back_unique(icFullSet, ic);
	}
	return 0;
}

/*
* Internal Method
*
* Match element index for element node type in the selection condition
* This can only match VALUEINDEX_ELEMENTCONTENT and VALUEINDEX_ELEMENTTAG
* @param fileName The name of the XML document
* @param conjunct Conjunctive condition
* @param icFullSet The index combination set that can fully answer the given conjunctive condition (return value)
* @param icPartialSet The index combination set that can partially answer the given conjunctive condition (return value)
* @returns Whether there is an error
*/
int IndexMatching::matchElementIndex(char *fileName, 
									 ConjunctiveCondition* ccond, 
									 IndexCombSet& icFullSet,
									 IndexCombSet& icPartialSet) 

{
	PredicateCondition *elemNameCond = NULL, *elemContCond = NULL;

	// Let's pick our key and value conditions from the conjuct
	for (int i = 0; i < ccond->getNumber(); i++) {
		PredicateCondition *cond = ccond->getCondAt(i);

		if (cond->getLeftValue() == SCAN_LEFTVALUE_NODETAG && elemNameCond == NULL)
			elemNameCond = cond;
		else if (cond->getLeftValue() == SCAN_LEFTVALUE_ELEMENTCONTENT && elemContCond == NULL)
			elemContCond = cond;
		else {
			globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"IndexMatching::matchElementIndex",__FILE__,"A Conjunct can only have one element tag and element content selection.");
			return -1;
		}
	}

	IndexMatchingType *imtPair=0, *imtKey1=0, *imtKey2=0;
	IndexInfoType *indexinfo;

	// Pair match?
	// we need ELEMENTCONTENT index that built on the element name in the condition
	// only if content != ""
	if (elemNameCond != NULL && elemContCond != NULL)   // we are interested in key & val
	{
		if ((elemContCond->getRightValue()->getValueType() != STRING_VALUE) ||
			((elemContCond->getRightValue()->getValueType() == STRING_VALUE) &&
			(strcmp(elemContCond->getRightValue()->getStrValue(),"") != 0) &&
			(strcmp(elemContCond->getRightValue()->getStrValue()," ") != 0)))
		{
			Value* tagVal = elemNameCond->getRightValue();
			//convert text string value to int value;
			Value* tagInt = new Value(INT_VALUE);
			tagInt->setIntValue(this->pDataMng->getXMLNameTable()->getCodeByName(tagVal->getStrValue()));
			if ((indexinfo = this->indexMng->getMatchingIndex(fileName, VALUEINDEX_ELEMENTCONTENT, tagInt, elemContCond->getRightValue()->getValueType())) != NULL) {
				// Lets create an IndexMatchingType for this match
				// The key to retrieve this index is identified by the content value
				imtPair = new IndexMatchingType(indexinfo, elemContCond);
				delete indexinfo;
			}
			delete tagInt;
		}
	}

	// Key match only?
	// we need ELEMENTTAG, TAGNAMEID(UPDATABLE) index for full match if the given conjunct need only element name
	// but if it wants both content and element name, ELEMENTTAG can answer partially
	if (elemNameCond != NULL &&                                     // we want the key
		(indexinfo = this->indexMng->getMatchingIndex(fileName, VALUEINDEX_ELEMENTTAG)) != NULL) 
	{
		// Lets create an IndexMatchingType for this match
		// The key to retrieve is the element name
		imtKey1 = new IndexMatchingType(indexinfo, elemNameCond);
		delete indexinfo;
	}

	if (elemNameCond != NULL &&                                     // we want the key
		(indexinfo = this->indexMng->getMatchingIndex(fileName, VALUEINDEX_TAGNAME_ID_PAIR)) != NULL) 
	{
		// Lets create an IndexMatchingType for this match
		// The key to retrieve is the element name
		imtKey2 = new IndexMatchingType(indexinfo, elemNameCond);
		delete indexinfo;
	}

	// Q?? Should TEXTVALUE index help in matching content (partial match)?

	// Generate combinations
	// Only pair, this is a full match, with no filter needed
	if (imtPair != 0) {
		IndexCombination *ic = new IndexCombination;
		ic->ilist.push_back(imtPair);
		ic->filter = NULL;
		push_back_unique(icFullSet, ic);
	}

	// Just key
	if (imtKey1 != 0) {
		IndexCombination *ic = new IndexCombination;
		ic->ilist.push_back(imtKey1);

		// Since ELEMENTTAG can answer partially
		// We need to filter using the content of the element as value
		if (elemContCond != 0) {
			//elemContCond->getRightValue()->printValue();
			PredicateCondition *pc = new PredicateCondition;
			pc->setLeftValue(elemContCond->getLeftValue());
			pc->setOperator(elemContCond->getOperator());
			Value* rValue = new Value(elemContCond->getRightValue());
			pc->setRightValue(rValue);
			ic->filter = new ConjunctiveCondition;
			ic->filter->setNumber(1);
			ic->filter->setCond(0, pc);
		}
		if (ic->filter == NULL) push_back_unique(icFullSet, ic);
		else push_back_unique(icPartialSet, ic);
	}

	//for TAGNAMEID (UPDATABLE)
	if (imtKey2 != 0) {
		IndexCombination *ic = new IndexCombination;
		ic->ilist.push_back(imtKey2);

		// Since TAGNAMEID can answer partially
		// We need to filter using the content of the element as value
		if (elemContCond != 0) {
			//elemContCond->getRightValue()->printValue();
			PredicateCondition *pc = new PredicateCondition;
			pc->setLeftValue(elemContCond->getLeftValue());
			pc->setOperator(elemContCond->getOperator());
			Value* rValue = new Value(elemContCond->getRightValue());
			pc->setRightValue(rValue);
			ic->filter = new ConjunctiveCondition;
			ic->filter->setNumber(1);
			ic->filter->setCond(0, pc);
		}
		if (ic->filter == NULL) push_back_unique(icFullSet, ic);
		else push_back_unique(icPartialSet, ic);
	}
	return 0;
}


/*
* Internal Method
*
* Match attribute index for attribute node type in the selection condition
* This can only match VALUEINDEX_ATTRIBUTECONTENT, VALUEINDEX_ATTRIBUTENAME and VALUEINDEX_ATTRIBUTEVALUE
* @param fileName The name of the XML document
* @param conjunct Conjunctive condition
* @param icFullSet The index combination set that can fully answer the given conjunctive condition (return value)
* @param icPartialSet The index combination set that can partially answer the given conjunctive condition (return value)
* @returns Whether there is an error
*/
int IndexMatching::matchAttributeIndex(char *fileName, 
									   ConjunctiveCondition* ccond, 
									   IndexCombSet& icFullSet,
									   IndexCombSet& icPartialSet) 
{
	//Allocate a vector of array type of IndexMatching with size equals to number of conjunct
	vector<IndexMatchingType **> L(ccond->getNumber());
	L[0] = NULL;

	//Find individual index that cover each conjunct, do not care whether it is full or partial yet
	findCoveringIndexes(fileName, ccond, L);

	// bitmap is a bit vector for choosing a combination of predicates to use
	// it is 2^size[conjunct] possible combination to check
	for (unsigned int bitmap = 1; bitmap < (unsigned)(1<<ccond->getNumber()); bitmap++) {
		list<IndexMatchingType*> *imt_list = new list<IndexMatchingType*>; //list of indexmatching
		list<PredicateCondition*> *pc_list = new list<PredicateCondition*>; //list of unmatched condition (filters)

		// Recursive generation
		generateCombination(bitmap, L, ccond, icFullSet, icPartialSet, 0, imt_list, pc_list);

		delete imt_list;
		delete pc_list;
	}
	//should delete L and cover from Findcovering, otherwise memory leak
	for (unsigned int i = 0 ; i < L.size() ; i++){
		IndexMatchingType** cover  = L[i];
		if (cover != NULL) {
			for (unsigned int j = 0 ; j < 4 ; j++) { //each cover has size 4 array see FindCoveringIndexes
				if (cover[j] != NULL){
					delete cover[j];
				}
			}
		}
		delete [] L[i];
	}
	return 0;
}


/*
* Internal Method
*
* For each predicate in the conjunct, determine whether any 4 indexes built on attribute exist and
* could be able to answer, put that in the  position-determined array
* [0] for ATTRNAME, [1] for ATTRVALUE, [2] for ATTRCONTENT, [3] for ATTRNAME_ID_PAIR
* without having to care whether it is a partial or full match.
* @param fileName The name of the XML document
* @param ccond A conjunctive condition to find the covering
* @param L An array vector of size equals to number of conjuncts, 
*		    each contains an array size 4 of indexMatchingType for ATTRNAME,ATTRVALUE,ATTRCONTENT,ATTRNAME_ID_PAIR index 
*/
void IndexMatching::findCoveringIndexes(char *fileName,
										ConjunctiveCondition *ccond,
										vector<IndexMatchingType**>& L)
{
	IndexInfoType *indexinfo;
	IndexMatchingType *imt;

	// Let's pick our key and value conditions from the conjuct
	for (int i = 0; i < ccond->getNumber(); i++) {
		PredicateCondition *cond = ccond->getCondAt(i);

		// If this is of type ATTR_NAME, or ATTRNAME_ID_PAIR
		// The query ask for only having an attribute name
		// So, VALUEINDEX_ATTRIBUTENAME would help, VALUEINDEX_ATTRIBUTEVALUE would not
		// Q?? Will VALUEINDEX_ATTRIBUTECONTENT of this @name help? (just scan all) 
		if (cond->getLeftValue() == SCAN_LEFTVALUE_HASATTRIBUTE) {
			IndexMatchingType **cover = new IndexMatchingType*[4];

			// cover[0] contains ATTR_NAME, cover[1] contains ATTR_VALUE, cover[2] contains ATTR_CONT
			// cover[3] contains ATTRNAME_ID_PAIR
			cover[0] = cover[1] = cover[2] = cover[3] = NULL;

			// If there is an ATTR_NAME index, use it
			if ((indexinfo = this->indexMng->getMatchingIndex(fileName, VALUEINDEX_ATTRIBUTENAME)) != NULL) {
				imt = new IndexMatchingType(indexinfo, cond);
				cover[0] = imt;
				delete indexinfo;
			}

			// If there is an ATTRNAME_ID_PAIR index, use it
			if ((indexinfo = this->indexMng->getMatchingIndex(fileName, VALUEINDEX_ATTRIBUTENAME_ID_PAIR)) != NULL) {
				imt = new IndexMatchingType(indexinfo, cond);
				cover[3] = imt;
				delete indexinfo;
			}
			
			if (cover[0] != NULL || cover[3] != NULL) {
				L[i] = cover;
			}
			// Otherwise no indexes
			else {
				delete[] cover;
				L[i] = NULL;
			}
		}

		// If this is of type ATTR_CONT
		else if (cond->getLeftValue() < SCAN_LEFTVALUE_VALUE ||
			cond->getLeftValue() > SCAN_LEFTVALUE_ELEMENTCONTENT) {
				Value *vtmp = new Value(STRING_VALUE, (char*) cond->getLeftValue());
				PredicateCondition *ptmp = NULL;
				IndexMatchingType **cover = new IndexMatchingType*[4];
				cover[0] = cover[1] = cover[2] = cover[3] = NULL;

				// If there is an ATTR_NAME index, use it
				if ((indexinfo = this->indexMng->getMatchingIndex(fileName, VALUEINDEX_ATTRIBUTENAME)) != NULL) {
					ptmp = new PredicateCondition(SCAN_LEFTVALUE_HASATTRIBUTE,
						VALUE_COMP_OP_EQ,
						vtmp);
					//the key for retrieval is the attribute name
					imt = new IndexMatchingType(indexinfo, ptmp);
					cover[0] = imt;
					delete indexinfo;
				}

				// If there is an VALUEINDEX_ATTRIBUTENAME_ID_PAIR index, use it
				if ((indexinfo = this->indexMng->getMatchingIndex(fileName, VALUEINDEX_ATTRIBUTENAME_ID_PAIR)) != NULL) {
					ptmp = new PredicateCondition(SCAN_LEFTVALUE_HASATTRIBUTE,
						VALUE_COMP_OP_EQ,
						vtmp);
					//the key for retrieval is the attribute name
					imt = new IndexMatchingType(indexinfo, ptmp);
					cover[3] = imt;
					delete indexinfo;
				}

				//for content != "" only value index can answer
				if ((cond->getRightValue()->getValueType() != STRING_VALUE) ||
					((cond->getRightValue()->getValueType() == STRING_VALUE) &&
					(strcmp(cond->getRightValue()->getStrValue(),"") != 0) &&
					(strcmp(cond->getRightValue()->getStrValue()," ") != 0)))
				{
					// If there is an ATTR_VALUE index, use it
					if ((indexinfo = this->indexMng->getMatchingIndex(fileName, VALUEINDEX_ATTRIBUTEVALUE, NULL, cond->getRightValue()->getValueType())) != NULL) {
						//the key for retrieval is the rightvalue, which is the attribute value
						imt = new IndexMatchingType(indexinfo, cond);
						cover[1] = imt;
						delete indexinfo;
					}
				}

				// If there is an ATTR_CONT index on the required attribute name, use it
				// not support by optmizer for node type of attribute
				//if ((indexinfo = this->indexMng->getMatchingIndex(fileName, VALUEINDEX_ATTRIBUTECONTENT, vtmp, cond->getRightValue()->getValueType())) != NULL) {
				//	//the key for retrieval is the attribute value
				//	imt = new IndexMatchingType(indexinfo, cond);
				//	cover[2] = imt;
				//	delete indexinfo;
				//}

				if (cover[0] != NULL || cover[1] != NULL || cover[2] != NULL || cover[3] != NULL) {
					L[i] = cover;
				}
				else {
					delete [] cover;
					L[i] = NULL;
				}

				if (ptmp) delete ptmp;
				else delete vtmp;
			}
		else {
			globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"IndexMatching::findCoveringIndexes",__FILE__,"Non-attribute predicate found.");
			break;
		}
	}
}

/*
* Internal Method
*
* Generate valid combination of indices and leave-up filter for partial match, 
* 2^size[conjunct] are possible. (Recursive Function)
* @param bitmap The bitmap vector to control the generation
* @param L The vector of an array of IndexMatchingType covering indexes found
* @param ccond A conjunctive condition on working
* @param icFullSet The index combination set that can fully answer this conjunct  (return value)
* @param icPartialSet The index combination set that can partially answer this conjunct (return value)
* @param i Current value of the round
* @param imt_list List of IndexmatchingType matched the predicates
* @param pc_list List of filter need to be applied on for partial match
*/
void IndexMatching::generateCombination(unsigned int bitmap, 
										vector<IndexMatchingType**>& L,
										ConjunctiveCondition *ccond,
										IndexCombSet& icFullSet,
										IndexCombSet& icPartialSet,
										unsigned int i,
										list<IndexMatchingType*>  *imt_list, //index match
										list<PredicateCondition*> *pc_list //predicate need to be in the filter
										)
{
	// Have we finished going over all the PredicateConditions?
	if (i >= L.size()) {
		if(imt_list->size() != 0) { //if at least a partial or full match, if nothing match, do not push into the set
			IndexCombination *ic = new IndexCombination();

			//recopy the matching, because each combination will reuse the matching
			//this will have to be individual copy, otherwise while final destructor doing, it will error
			for (list<IndexMatchingType*>::const_iterator it = imt_list->begin();
				it != imt_list->end(); ++it) {
					IndexMatchingType* imm = *it;
					IndexMatchingType* new_imm = new IndexMatchingType(imm);
					ic->ilist.push_back(new_imm);
				}
			//ic->ilist = *imt_list;
			// if there's no filter, put it in fullset 
			if (pc_list->size() == 0) {
				push_back_unique(icFullSet, ic);
			}
			else {
				ic->filter = new ConjunctiveCondition(pc_list->size());
				int count = 0;
				for (list<PredicateCondition*>::iterator it = pc_list->begin();
					it != pc_list->end(); ++it) {
						PredicateCondition *pc = new PredicateCondition(*it);
						ic->filter->setCond(count++, pc);
					}
					push_back_unique(icPartialSet, ic);
			}
		}
	}

	else {
		// Are we supposed to include i^th PredicateCondition?
		if ((bitmap & 1<<i) && (L[i] != NULL)) {
			//if (L[i] != NULL) { //at least there's something to match
				IndexMatchingType **imt = L[i];
				// If there is a ATTR_CONT index
				if (imt[2] != NULL) {
					list<IndexMatchingType*> *nimt_list = duplicateList(imt_list);
					push_back_unique(nimt_list, imt[2]);
					generateCombination(bitmap, L, ccond, icFullSet, icPartialSet, i+1, nimt_list, pc_list);
					delete nimt_list;
				}

				// If there is ATTR_NAME index
				if (imt[0] != NULL) {
					list<IndexMatchingType*> *nimt_list = duplicateList(imt_list);
					list<PredicateCondition*> *npc_list = duplicateList(pc_list);
					push_back_unique(nimt_list, imt[0]);

					// And the Predicate condition is ATTR_CONT
					if (ccond->getCondAt(i)->getLeftValue() < SCAN_LEFTVALUE_VALUE || 
						ccond->getCondAt(i)->getLeftValue() > SCAN_LEFTVALUE_ELEMENTCONTENT) {
							npc_list->push_back(ccond->getCondAt(i));
						}
						generateCombination(bitmap, L, ccond, icFullSet, icPartialSet, i+1, nimt_list, npc_list);

						// If there is an ATTR_VALUE index as well
						// we could use both at the same time, but beware of false positive
						// false positive are taken care of the if clause above, so it's fine
						if (imt[1] != NULL) {
							push_back_unique(nimt_list, imt[1]);
							generateCombination(bitmap, L, ccond, icFullSet, icPartialSet, i+1, nimt_list, npc_list);
						}
						delete nimt_list;
						delete npc_list;
				}

				// If there is ATTR_NAME_ID_PAIR index
				if (imt[3] != NULL) {
					list<IndexMatchingType*> *nimt_list = duplicateList(imt_list);
					list<PredicateCondition*> *npc_list = duplicateList(pc_list);
					push_back_unique(nimt_list, imt[3]);

					// And the Predicate condition is ATTR_CONT
					if (ccond->getCondAt(i)->getLeftValue() < SCAN_LEFTVALUE_VALUE || 
						ccond->getCondAt(i)->getLeftValue() > SCAN_LEFTVALUE_ELEMENTCONTENT) {
							npc_list->push_back(ccond->getCondAt(i));
						}
						generateCombination(bitmap, L, ccond, icFullSet, icPartialSet, i+1, nimt_list, npc_list);

						// If there is an ATTR_VALUE index as well
						// we could use both at the same time, but beware of false positive
						// false positive are taken care of the if clause above, so it's fine
						if (imt[1] != NULL) {
							push_back_unique(nimt_list, imt[1]);
							generateCombination(bitmap, L, ccond, icFullSet, icPartialSet, i+1, nimt_list, npc_list);
						}
						delete nimt_list;
						delete npc_list;
				}

				// If there is an ATTR_VALUE index
				if (imt[1] != NULL) {
					list<IndexMatchingType*> *nimt_list = duplicateList(imt_list);
					list<PredicateCondition*> *npc_list = duplicateList(pc_list);
					push_back_unique(nimt_list, imt[1]);

					// And the Predicate condition is ATTR_CONT
					if (ccond->getCondAt(i)->getLeftValue() < SCAN_LEFTVALUE_VALUE || 
						ccond->getCondAt(i)->getLeftValue() > SCAN_LEFTVALUE_ELEMENTCONTENT) {
							npc_list->push_back(ccond->getCondAt(i));
						}
						generateCombination(bitmap, L, ccond, icFullSet, icPartialSet, i+1, nimt_list, npc_list);
						delete nimt_list;
						delete npc_list;
				}
		}
		// We are not including the i^th PredicateCondition
		else {
			list<PredicateCondition*> *npc_list = duplicateList(pc_list);
			npc_list->push_back(ccond->getCondAt(i));
			generateCombination(bitmap, L, ccond, icFullSet, icPartialSet, i+1, imt_list, npc_list);
			delete npc_list;
		}
	}
}

//bool IndexMatching::isDominated(map<IndexMatchingType*, set<PredicateCondition*> >& L,
//								IndexCombination *c)
//{
//	for (list<IndexMatchingType*>::iterator it1 = c->ilist.begin(); it1 != c->ilist.end();) {
//		IndexMatchingType* first = (*it1);
//		for (list<IndexMatchingType*>::iterator it2 = ++it1; it2 != c->ilist.end(); ++it2) {
//			IndexMatchingType* second = (*it2);
//
//			set<PredicateCondition*> s1 = L[first];
//			set<PredicateCondition*> s2 = L[second];
//
//			if (includes(s1.begin(), s1.end(), s2.begin(), s2.end()) ||
//				includes(s2.begin(), s2.end(), s1.begin(), s1.end()))
//				return true;
//		}
//	}
//	return false;
//}


/*
* Utility Function
*
* Given the Index combination set 
* Try to append one more to the set by retaining uniqueness
*
* @param icSet Pointer to the set of pointer to IndexMatchingType
* @param ic New IndexCombination to be appened to, if unique
*/
void push_back_unique(IndexCombSet &icSet,
					  IndexCombination *ic)
{
	for (IndexCombSet::iterator it = icSet.begin();
		it != icSet.end(); ++it) {
			IndexCombination* cur = (*it);
			if (cur->equals(ic))
				return;
		}
		icSet.push_back(ic);
}

/*
* Utility Function
*
* Given the list of Index Matching Type
* Try to append one more to the list by retaining uniqueness
*
* @param imt_list Pointer to the list of pointer to IndexMatchingType
* @param imt New IndexMatchingType to be appened to, if unique
*/
void push_back_unique(list<IndexMatchingType*>  *imt_list,
					  IndexMatchingType *imt)
{
	for (list<IndexMatchingType*>::iterator it = imt_list->begin();
		it != imt_list->end(); ++it) {

			IndexMatchingType *cur = (*it);
			if (cur->equals(*imt))
				return;
		}
		imt_list->push_back(imt);
}

/**
* Process Method
*
* Match join index
*
* @param fileName The name of the xml file to find the corresponding index
* @param leftSide Value of a left side (key side) that the index built on
* @param leftSideType Type of a left side (key side) that the index built on see IndexMng_definitions.h
* @param rightSide Value of a right side (return side) that the index built on
* @param rightSideType Type of a right side (return side) that the index built on see IndexMng_definitions.h
* @param iMatchInfo Index Matching Type of the join index matched, NULL otherwise (return value)
* @return Whether it has any errors.
*/
int IndexMatching::matchJoinIndex(char* fileName, char* leftSide, int leftSideType, char* rightSide, int rightSideType,IndexMatchingType*& iMatchInfo)
{
	IndexInfoType *iInfo;

	//construct a designated join pair index from the argument pass
	iInfo = this->indexMng->getMatchingIndex(fileName,JOININDEX,leftSide,leftSideType,rightSide,rightSideType);
	
	//construct index matching type
	//left side is always the key, return the right side's list node
	if (iInfo == NULL)
		iMatchInfo = NULL;
	else {
		iMatchInfo = new IndexMatchingType(iInfo->indexName,iInfo->indexType,iInfo->indexDescription
		,iInfo->indexSource,false,false);
		delete iInfo;
	}

	return 0;
}

/**
* Process Method
*
* Find condtions left from a given join index
*
* @param indexName The name of the join index file
* @param indexInfo The index info type of the join index (optional, can provide only indexName)
* @param cond Conditions given to be filtered
* @param condLeft Conjunctive condition left from the join index (return value)
* @return Whether it has any errors.
*/
int IndexMatching::conditionLeftFromJoinIndex(char* indexName, IndexInfoType* indexInfo, ConjunctiveCondition* cond, ConjunctiveCondition*& condLeft)
{
	if (indexInfo == NULL) {
		//from index name get index info
		indexInfo = this->indexMng->indexNameTable->getIndexInfo(indexName);
		if (indexInfo == NULL) {
			globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"IndexMatching::conditionLeftFromJoinIndex",__FILE__,"Join index specified not found.");
			return -1;
		}
	}

	PredicateCondition* leftCond = NULL;
	PredicateCondition* rightCond = NULL;
	Value* leftVal = new Value(STRING_VALUE,indexInfo->leftSide);
	Value* rightVal = new Value(STRING_VALUE,indexInfo->rightSide);

	//construct standard predicate condition from left and right side of index
	switch (indexInfo->leftSideType) {
		case JOININDEX_ELEMENTCONTENT:
			leftCond = new PredicateCondition(SCAN_LEFTVALUE_NODETAG,VALUE_COMP_OP_EQ,leftVal);
			break;
		case JOININDEX_ATTRIBUTEVALUE:
			leftCond = new PredicateCondition(SCAN_LEFTVALUE_HASATTRIBUTE,VALUE_COMP_OP_EQ,leftVal);
			break;
		case JOININDEX_ATTRIBUTECONTENT:
			leftCond = new PredicateCondition(SCAN_LEFTVALUE_HASATTRIBUTE,VALUE_COMP_OP_EQ,leftVal);
			break;
		default:
			break;
	}
	switch (indexInfo->rightSideType) {
		case JOININDEX_ELEMENTCONTENT:
			rightCond = new PredicateCondition(SCAN_LEFTVALUE_NODETAG,VALUE_COMP_OP_EQ,rightVal);
			break;
		case JOININDEX_ATTRIBUTEVALUE:
			rightCond = new PredicateCondition(SCAN_LEFTVALUE_HASATTRIBUTE,VALUE_COMP_OP_EQ,rightVal);
			break;
		case JOININDEX_ATTRIBUTECONTENT:
			rightCond = new PredicateCondition(SCAN_LEFTVALUE_HASATTRIBUTE,VALUE_COMP_OP_EQ,rightVal);
			break;
		default:
			break;
	}



	condLeft = NULL;
	//match each predicate condition with left or right side of the condition on index
	for (int i = 0 ; i < cond->getNumber() ; i++){
		if ((cond->getCondAt(i)->matchPredicateCondition(leftCond) == SELECTION_COND_FULL_MATCH) ||
			(cond->getCondAt(i)->matchPredicateCondition(rightCond) == SELECTION_COND_FULL_MATCH)){
				//match
				//do nothing
			}
		else {
			//else push into condLeft
			if (condLeft == NULL)
				condLeft = new ConjunctiveCondition();
			condLeft->insertCond(cond->getCondAt(i));
		}
	}
	delete indexInfo;
	indexInfo = NULL;
	if (leftCond) delete leftCond; //already perform delete leftVal
	if (rightCond) delete rightCond;
	return 0;
}