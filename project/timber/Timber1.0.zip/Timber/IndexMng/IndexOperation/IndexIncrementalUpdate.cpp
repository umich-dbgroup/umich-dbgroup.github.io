/*
COPYRIGHT  (c) 2000-2004 
THE REGENTS OF THE UNIVERSITY OF MICHIGAN
ALL RIGHTS RESERVED

PERMISSION IS GRANTED TO USE, COPY, CREATE DERIVATIVE WORKS AND
REDISTRIBUTE THIS SOFTWARE AND SUCH DERIVATIVE WORKS FOR NONCOMMERCIAL
EDUCATION AND RESEARCH PURPOSES, SO LONG AS NO FEE IS CHARGED, AND SO LONG
AS THE COPYRIGHT NOTICE ABOVE, THIS GRANT OF PERMISSION, AND THE
DISCLAIMER BELOW APPEAR IN ALL COPIES MADE; AND SO LONG AS THE NAME OF THE
UNIVERSITY OF MICHIGAN IS NOT USED IN ANY ADVERTISING OR PUBLICITY
PERTAINING TO THE USE OR DISTRIBUTION OF THIS SOFTWARE WITHOUT SPECIFIC,
WRITTEN PRIOR AUTHORIZATION.

THIS SOFTWARE IS PROVIDED AS IS, WITHOUT REPRESENTATION FROM THE
UNIVERSITY OF MICHIGAN AS TO ITS FITNESS FOR ANY PURPOSE, AND WITHOUT
WARRANTY BY THE UNIVERSITY OF MICHIGAN OF ANY KIND, EITHER EXPRESS OR
IMPLIED, INCLUDING WITHOUT LIMITATION THE IMPLIED WARRANTIES OF
MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE. THE REGENTS OF THE
UNIVERSITY OF MICHIGAN SHALL NOT BE LIABLE FOR ANY DAMAGES, INCLUDING
SPECIAL, INDIRECT, INCIDENTAL, OR CONSEQUENTIAL DAMAGES, WITH RESPECT TO
ANY CLAIM ARISING OUT OF OR IN CONNECTION WITH THE USE OF THE SOFTWARE,
EVEN IF IT HAS BEEN OR IS HEREAFTER ADVISED OF THE POSSIBILITY OF SUCH
DAMAGES.
*/

#include "IndexIncrementalUpdate.h"
#include "gist.h"
#include "gist_btree.h"
#include "gist_cursor.h"

#include "../IndexMng/TagNameAndNodeIdIndex.h"
#include "../Common/ListNode.h"
class gist;

/**
* Default Constructor
*/
IndexIncrementalUpdate::IndexIncrementalUpdate(IndexMng *idxMng)
{
	this->indexMng = idxMng;
	this->index = new gist;
	strcpy(indexNamePath,gSettings->getStringValue("GIST_DEFAULT_FILEPATH").c_str());
}

/**
* Default Destructor
*/
IndexIncrementalUpdate::~IndexIncrementalUpdate()
{
	delete this->index;
}

/**
* Process Method
*
* Perform relevant incremental index update in case of node deletion
* Node can be element or text or attribute node.
*
* @param fileinfo The file info type of the xml file to perform incremental index update
* @param parentNode The data node pointer of the parent
* @param nodeToDelete The data node pointer of the node to be deleted
* @return Whether it has any errors.
*/
bool IndexIncrementalUpdate::nodeDeletion(FileInfoType* fileinfo, DM_ElementNode* parentNode, DM_DataNode* nodeToDelete)
{
	if (nodeToDelete->getFlag() == ELEMENT_NODE){
		return elementNodeDeletion(fileinfo,(DM_ElementNode*)nodeToDelete);
	}
	else if (nodeToDelete->getFlag()== TEXT_NODE) {
		return textNodeDeletion(fileinfo,parentNode,NULL,(DM_TextNode*)nodeToDelete);
	}
	else if (nodeToDelete->getFlag() == ATTRIBUTE_NODE) {
		return attributeNodeDeletion(fileinfo,parentNode,NULL,(DM_AttributeNode*)nodeToDelete);
	}
	else {
		globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"IndexIncrementalUpdate::nodeDeletion",__FILE__,"Node type not support for deletion.");
		return false;
	}
}

/**
* Process Method
*
* Perform relevant incremental index update in case of node deletion
* Node can be element or text or attribute node.
*
* @param fileinfo The file info type of the xml file to perform incremental index update
* @param parentKey The key of the parent node
* @param nodeToDelete The data node pointer of the node to be deleted
* @return Whether it has any errors.
*/
bool IndexIncrementalUpdate::nodeDeletion(FileInfoType* fileinfo, KeyType parentKey, DM_DataNode* nodeToDelete)
{
	bool ret = false;
	if (nodeToDelete->getFlag() == ELEMENT_NODE){
		ret = elementNodeDeletion(fileinfo,(DM_ElementNode*)nodeToDelete);
	}
	else if (nodeToDelete->getFlag()== TEXT_NODE) {
		ret = textNodeDeletion(fileinfo,NULL,parentKey,(DM_TextNode*)nodeToDelete);
	}
	else if (nodeToDelete->getFlag() == ATTRIBUTE_NODE) {
		ret = attributeNodeDeletion(fileinfo,NULL,parentKey,(DM_AttributeNode*)nodeToDelete);
	}
	else {
		globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"IndexIncrementalUpdate::nodeDeletion",__FILE__,"Node type not support for deletion.");
	}
	return ret;
}

/**
* Process Method
*
* Perform relevant incremental index update in case of element node deletion
*
* @param fileinfo The file info type of the xml file to perform incremental index update
* @param nodeToDelete The data node pointer of the node to be deleted
* @return Whether it has any errors.
*/
bool IndexIncrementalUpdate::elementNodeDeletion(FileInfoType* fileinfo, DM_ElementNode* nodeToDelete) 
{

	IndexInfoType *iInfo;
	ListNode* lnode;
	bt_query_t* qDel;
	int keyInt;
	//float keyFloat;
	//double keyDouble;
	char* keyChar;
	char* indexName;
	rc_tGist ret;

	//scan for all concerned indices
	this->indexMng->fileIndexTable->startScanIndex(fileinfo->key);
	while ((iInfo = this->indexMng->fileIndexTable->getNextIndexInfo()) != NULL) {

		switch (iInfo->indexDescription) {

case VALUEINDEX_ELEMENTTAG:
	{
		//get index name concat with path, and open it
		indexName = new char[strlen(this->indexNamePath) + strlen(iInfo->indexName) + 1];
		strcpy(indexName,this->indexNamePath);
		strcpy(indexName + strlen(this->indexNamePath), iInfo->indexName);

		ret = index->open(indexName);
		if (ret != RCOKGist) {
			globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"IndexIncrementalUpdate::elementNodeDeletion",__FILE__,"Cannot open gist index file.");
			delete indexName;
			delete iInfo;
			this->indexMng->fileIndexTable->closeScanIndex();
			return false;
		}

		//remove tag + key
		keyInt = nodeToDelete->getTag();
		lnode = new ListNode();
		lnode->SetStartPos(nodeToDelete->getKey());
		lnode->SetEndPos(nodeToDelete->getEndKey());
		lnode->SetLevel(nodeToDelete->getLevel());
		qDel = new bt_query_t(bt_query_t::bt_eq,new int(keyInt),NULL,lnode,NULL);
		ret = index->remove(qDel);

		if (ret != RCOKGist) {
			globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"IndexIncrementalUpdate::elementNodeDeletion",__FILE__,"Cannot remove an entry from the gist index file.");
			delete indexName;
			delete qDel;
			delete iInfo;
			index->close();
			this->indexMng->fileIndexTable->closeScanIndex();
			return false;
		}

		index->close();
		delete qDel;
		delete indexName;
	}
	break;
case VALUEINDEX_ELEMENTTAGSTR:
	{
		//get index name concat with path, and open it
		indexName = new char[strlen(this->indexNamePath) + strlen(iInfo->indexName) + 1];
		strcpy(indexName,this->indexNamePath);
		strcpy(indexName + strlen(this->indexNamePath), iInfo->indexName);

		ret = index->open(indexName);
		if (ret != RCOKGist) {
			globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"IndexIncrementalUpdate::elementNodeDeletion",__FILE__,"Cannot open gist index file.");
			delete indexName;
			delete iInfo;
			this->indexMng->fileIndexTable->closeScanIndex();
			return false;
		}

		//remove tag + key
		keyChar = new char[strlen(nodeToDelete->getTag(this->indexMng->pDataMng->getXMLNameTable()))+1];
		strcpy(keyChar,nodeToDelete->getTag(this->indexMng->pDataMng->getXMLNameTable()));

		lnode = new ListNode();
		lnode->SetStartPos(nodeToDelete->getKey());
		lnode->SetEndPos(nodeToDelete->getEndKey());
		lnode->SetLevel(nodeToDelete->getLevel());
		qDel = new bt_query_t(bt_query_t::bt_eq,keyChar,NULL,lnode,NULL);
		ret = index->remove(qDel);

		if (ret != RCOKGist) {
			globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"IndexIncrementalUpdate::elementNodeDeletion",__FILE__,"Cannot remove an entry from the gist index file.");
			delete indexName;
			delete qDel;
			delete iInfo;
			index->close();
			this->indexMng->fileIndexTable->closeScanIndex();
			return false;
		}

		index->close();
		delete qDel;
		delete indexName;
	}
	break;
case VALUEINDEX_TAGNAME_ID_PAIR:
	{
		//get index name concat with path, and open it
		indexName = new char[strlen(this->indexNamePath) + strlen(iInfo->indexName) + 1];
		strcpy(indexName,this->indexNamePath);
		strcpy(indexName + strlen(this->indexNamePath), iInfo->indexName);

		ret = index->open(indexName);
		if (ret != RCOKGist) {
			globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"IndexIncrementalUpdate::elementNodeDeletion",__FILE__,"Cannot open gist index file.");
			delete indexName;
			delete iInfo;
			this->indexMng->fileIndexTable->closeScanIndex();
			return false;
		}

		tagIdIndex = new TagNameAndNodeIdIndex();

		//remove tag&key
		bool tRet = this->tagIdIndex->deleteNode(nodeToDelete->getTag(this->indexMng->pDataMng->getXMLNameTable()),nodeToDelete->getKey().toDouble(),index);

		if (tRet != true) {
			globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"IndexIncrementalUpdate::elementNodeDeletion",__FILE__,"Cannot remove an entry from the gist index file.");
			delete indexName;
			delete iInfo;
			delete tagIdIndex;
			index->close();
			this->indexMng->fileIndexTable->closeScanIndex();
			return false;
		}

		delete tagIdIndex;
		index->close();
		delete indexName;
	}
	break;
case VALUEINDEX_ATTRIBUTECONTENT:
	{
		//do nothing, assume we will subsequently remove all children incl. attribute and text
	}
	break;
case VALUEINDEX_ELEMENTCONTENT:
	{
		//do nothing, assume we will subsequently remove all children incl. attribute and text
	}
	break;
default:
	break;
		} //switch

		delete iInfo;
	}//while scan fileindex
	this->indexMng->fileIndexTable->closeScanIndex();
	return true;
}

/**
* Process Method
*
* Perform relevant incremental index update in case of text node deletion
*
* @param fileinfo The file info type of the xml file to perform incremental index update
* @param parentNode The data node pointer of the parent
* @param parentKey The key of the parent node (if parentNode = null, use this to get data node)
* @param nodeToDelete The data node pointer of the node to be deleted
* @return Whether it has any errors.
*/
bool IndexIncrementalUpdate::textNodeDeletion(FileInfoType* fileinfo, DM_ElementNode* parentNode, KeyType parentKey, DM_TextNode* nodeToDelete) 
{
	IndexInfoType *iInfo;
	ListNode* lnode;
	bt_query_t* qDel;
	int keyInt;
	float keyFloat;
	double keyDouble;
	char* keyChar;
	char* indexName;
	bool getParentNode = false; //if we get our own data node, we have to clean it
	rc_tGist ret;

	//scan for all concerned indices
	this->indexMng->fileIndexTable->startScanIndex(fileinfo->key);
	while ((iInfo = this->indexMng->fileIndexTable->getNextIndexInfo()) != NULL) {

		switch (iInfo->indexDescription) {

case VALUEINDEX_TEXTVALUE:
	{
		//get index name concat with path, and open it
		indexName = new char[strlen(this->indexNamePath) + strlen(iInfo->indexName) + 1];
		strcpy(indexName,this->indexNamePath);
		strcpy(indexName + strlen(this->indexNamePath), iInfo->indexName);


		ret = index->open(indexName);
		if (ret != RCOKGist) {
			globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"IndexIncrementalUpdate::textNodeDeletion",__FILE__,"Cannot open gist index file.");
			delete indexName;
			delete iInfo;
			this->indexMng->fileIndexTable->closeScanIndex();
			return false;
		}

		if(iInfo->indexType == STRING_INDEX){
			//remove textvalue + oldkey
			keyChar = new char[strlen(nodeToDelete->getCharValue())+1];
			strcpy(keyChar,nodeToDelete->getCharValue());

			lnode = new ListNode();
			lnode->SetStartPos(nodeToDelete->getKey());
			lnode->SetEndPos(nodeToDelete->getEndKey());
			lnode->SetLevel(nodeToDelete->getLevel());
			qDel = new bt_query_t(bt_query_t::bt_eq,keyChar,NULL,lnode,NULL);
			ret = index->remove(qDel);

			if (ret != RCOKGist) {
				globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"IndexIncrementalUpdate::textNodeDeletion",__FILE__,"Cannot remove an entry from the gist index file.");
				delete indexName;
				delete qDel;
				delete iInfo;
				index->close();
				this->indexMng->fileIndexTable->closeScanIndex();
				return false;
			}
			delete qDel;
		}
		else if (iInfo->indexType == INT_INDEX){
			//remove textvalue + oldkey
			keyInt = atoi(nodeToDelete->getCharValue());

			lnode = new ListNode();
			lnode->SetStartPos(nodeToDelete->getKey());
			lnode->SetEndPos(nodeToDelete->getEndKey());
			lnode->SetLevel(nodeToDelete->getLevel());
			qDel = new bt_query_t(bt_query_t::bt_eq,new int(keyInt),NULL,lnode,NULL);
			ret = index->remove(qDel);

			if (ret != RCOKGist) {
				globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"IndexIncrementalUpdate::textNodeDeletion",__FILE__,"Cannot remove an entry from the gist index file.");
				delete indexName;
				delete qDel;
				delete iInfo;
				index->close();
				this->indexMng->fileIndexTable->closeScanIndex();
				return false;
			}
			delete qDel;
		}
		else if (iInfo->indexType == FLOAT_INDEX){
			//remove textvalue + oldkey
			keyFloat = (float)atof(nodeToDelete->getCharValue());

			lnode = new ListNode();
			lnode->SetStartPos(nodeToDelete->getKey());
			lnode->SetEndPos(nodeToDelete->getEndKey());
			lnode->SetLevel(nodeToDelete->getLevel());
			qDel = new bt_query_t(bt_query_t::bt_eq,new float(keyFloat),NULL,lnode,NULL);
			ret = index->remove(qDel);

			if (ret != RCOKGist) {
				globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"IndexIncrementalUpdate::textNodeDeletion",__FILE__,"Cannot remove an entry from the gist index file.");
				delete indexName;
				delete qDel;
				delete iInfo;
				index->close();
				this->indexMng->fileIndexTable->closeScanIndex();
				return false;
			}
			delete qDel;
		}
		else if (iInfo->indexType == DOUBLE_INDEX){
			//remove textvalue + oldkey
			keyDouble = (double)atof(nodeToDelete->getCharValue());

			lnode = new ListNode();
			lnode->SetStartPos(nodeToDelete->getKey());
			lnode->SetEndPos(nodeToDelete->getEndKey());
			lnode->SetLevel(nodeToDelete->getLevel());
			qDel = new bt_query_t(bt_query_t::bt_eq,new double(keyDouble),NULL,lnode,NULL);
			ret = index->remove(qDel);

			if (ret != RCOKGist) {
				globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"IndexIncrementalUpdate::textNodeDeletion",__FILE__,"Cannot remove an entry from the gist index file.");
				delete indexName;
				delete qDel;
				delete iInfo;
				index->close();
				this->indexMng->fileIndexTable->closeScanIndex();
				return false;
			}

			delete qDel;
		}

		index->close();
		delete indexName;
	}
	break;

case VALUEINDEX_ELEMENTCONTENT:
	{

		//get parent data node if the pointer passed is null
		if (parentNode == NULL) {
			parentNode = (DM_ElementNode*)this->indexMng->pDataMng->fetchDataNodeFromDBFile((const FileInfoType)*fileinfo,parentKey);
			getParentNode = true;
			if (parentNode == NULL) {
				globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"IndexIncrementalUpdate::nodeDeletion",__FILE__,"Parent cannot be fetched by the key given.");
				return false;
			}
		}

		int tagInt = parentNode->getTag();
		//check whether the index is built on this node tag
		SelectionCondition* idxcond = new SelectionCondition(iInfo->selectionCondition);
		PredicateCondition* idxpred = idxcond->getCondition()->getCondAt(0)->getCondAt(0);
		Value* val = new Value(INT_VALUE);
		val->setIntValue(tagInt);
		if (!idxpred->getRightValue()->compareValue(VALUE_COMP_OP_EQ,val)) {
			//if tagname built != this modified node tag name, ignore
			delete idxcond;
			delete val;
			break;
		}

		delete idxcond;
		delete val;


		//get index name concat with path, and open it
		indexName = new char[strlen(this->indexNamePath) + strlen(iInfo->indexName) + 1];
		strcpy(indexName,this->indexNamePath);
		strcpy(indexName + strlen(this->indexNamePath), iInfo->indexName);


		ret = index->open(indexName);
		if (ret != RCOKGist) {
			globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"IndexIncrementalUpdate::textNodeDeletion",__FILE__,"Cannot open gist index file.");
			delete indexName;
			delete iInfo;
			this->indexMng->fileIndexTable->closeScanIndex();
			return false;
		}

		if(iInfo->indexType == STRING_INDEX){
			//remove content + parent key
			keyChar = new char[strlen(nodeToDelete->getCharValue())+1];
			strcpy(keyChar,nodeToDelete->getCharValue());

			lnode = new ListNode();
			lnode->SetStartPos(parentNode->getKey());
			lnode->SetEndPos(parentNode->getEndKey());
			lnode->SetLevel(parentNode->getLevel());
			qDel = new bt_query_t(bt_query_t::bt_eq,keyChar,NULL,lnode,NULL);
			ret = index->remove(qDel);

			if (ret != RCOKGist) {
				globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"IndexIncrementalUpdate::textNodeDeletion",__FILE__,"Cannot remove an entry from the gist index file.");
				delete indexName;
				delete qDel;
				delete iInfo;
				index->close();
				this->indexMng->fileIndexTable->closeScanIndex();
				return false;
			}
			delete qDel;
		}
		else if (iInfo->indexType == INT_INDEX) {

			//remove content + parentkey
			keyInt = atoi(((DM_TextNode*)nodeToDelete)->getCharValue());

			lnode = new ListNode();
			lnode->SetStartPos(parentNode->getKey());
			lnode->SetEndPos(parentNode->getEndKey());
			lnode->SetLevel(parentNode->getLevel());
			qDel = new bt_query_t(bt_query_t::bt_eq,new int(keyInt),NULL,lnode,NULL);
			ret = index->remove(qDel);

			if (ret != RCOKGist) {
				globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"IndexIncrementalUpdate::textNodeDeletion",__FILE__,"Cannot remove an entry from the gist index file.");
				delete indexName;
				delete qDel;
				delete iInfo;
				index->close();
				this->indexMng->fileIndexTable->closeScanIndex();
				return false;
			}
			delete qDel;
		}
		else if (iInfo->indexType == FLOAT_INDEX) {
			//remove content + parentkey
			keyFloat = (float)atof(((DM_TextNode*)nodeToDelete)->getCharValue());

			lnode = new ListNode();
			lnode->SetStartPos(parentNode->getKey());
			lnode->SetEndPos(parentNode->getEndKey());
			lnode->SetLevel(parentNode->getLevel());
			qDel = new bt_query_t(bt_query_t::bt_eq,new float(keyFloat),NULL,lnode,NULL);
			ret = index->remove(qDel);

			if (ret != RCOKGist) {
				globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"IndexIncrementalUpdate::textNodeDeletion",__FILE__,"Cannot remove an entry from the gist index file.");
				delete indexName;
				delete qDel;
				delete iInfo;
				index->close();
				this->indexMng->fileIndexTable->closeScanIndex();
				return false;
			}
			delete qDel;
		}
		else if (iInfo->indexType == DOUBLE_INDEX) {
			//remove content + parentkey
			keyDouble = (double)atof(((DM_TextNode*)nodeToDelete)->getCharValue());

			lnode = new ListNode();
			lnode->SetStartPos(parentNode->getKey());
			lnode->SetEndPos(parentNode->getEndKey());
			lnode->SetLevel(parentNode->getLevel());
			qDel = new bt_query_t(bt_query_t::bt_eq,new double(keyDouble),NULL,lnode,NULL);
			ret = index->remove(qDel);

			if (ret != RCOKGist) {
				globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"IndexIncrementalUpdate::textNodeDeletion",__FILE__,"Cannot remove an entry from the gist index file.");
				delete indexName;
				delete qDel;
				delete iInfo;
				index->close();
				this->indexMng->fileIndexTable->closeScanIndex();
				return false;
			}
			delete qDel;
		}
		if (getParentNode) delete parentNode;
		index->close();
		delete indexName;
	}
	break;
case JOININDEX:
	{
		bool mirror = false, same = false; //whether mirror index exist, and successfully opened for operation
		char* indexName2;
		gist* index2 = new gist;
		//check only if it is left side, since we can retrieve/del the entry only if it's the key (left side)
		//since we assume there will be a mirror index, we will automatically try to update both
		if (iInfo->leftSideType == JOININDEX_ELEMENTCONTENT) {
			//try to delete from it the parent key as leftside key
			//get parent data node if the pointer passed is null
			if (parentNode == NULL) {
				getParentNode = true;
				parentNode = (DM_ElementNode*)this->indexMng->pDataMng->fetchDataNodeFromDBFile((const FileInfoType)*fileinfo,parentKey);
				if (parentNode == NULL) {
					globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"IndexIncrementalUpdate::textNodeDeletion",__FILE__,"Parent cannot be fetched by the key given.");
					return false;
				}
			}
			int tagInt = parentNode->getTag();
			//check whether left side = parent tag
			if (this->indexMng->xmlNameTable->getCodeByName(iInfo->leftSide) == tagInt) {
				//get index name concat with path, and open it
				indexName = new char[strlen(this->indexNamePath) + strlen(iInfo->indexName) + 1];
				strcpy(indexName,this->indexNamePath);
				strcpy(indexName + strlen(this->indexNamePath), iInfo->indexName);

					

				ret = index->open(indexName);
				if (ret != RCOKGist) {
					globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"IndexIncrementalUpdate::textNodeDeletion",__FILE__,"Cannot open gist index file.");
					delete indexName;
					delete iInfo;
					this->indexMng->fileIndexTable->closeScanIndex();
					return false;
				}

				//get mirror only if mirror name is different than this name
				char indexMirror[MAX_INDEX_NAME_LENGTH];
				bool rc = this->indexMng->constructIndexName(iInfo->fileName,indexMirror,JOININDEX,NULL,DOUBLE_INDEX,iInfo->rightSide,iInfo->rightSideType,iInfo->leftSide,iInfo->leftSideType);
				if (strcmp(indexMirror,iInfo->indexName) != 0) {
					if (rc && this->indexMng->existIndex(indexMirror)) {
						indexName2 = new char[strlen(this->indexNamePath) + strlen(indexMirror) + 1];
						strcpy(indexName2,this->indexNamePath);
						strcpy(indexName2 + strlen(this->indexNamePath), indexMirror);

						ret = index2->open(indexName2);
						if (ret == RCOKGist) {
							mirror = true;
						}
						delete indexName2;
					}
				}
				else { //ec_author_ec_author
					same = true;
				}

				bt_query_t *qGet, *qDel;
				gist_cursor_t cursor;
				bool eof = false, match = false;
				unsigned long keysz, datasz;
				double key;
				ListNode lnode;
				ListNode* lnodeDel;

				qGet = new bt_query_t(bt_query_t::bt_eq,new double(parentNode->getKey().toDouble()),NULL);
				cursor.k = 0;
				cursor.io = 0;
				cursor.query = NULL;
				cursor.ext = NULL;
				cursor.cext = NULL;
				cursor.iter = NULL;
				cursor.state = NULL;
				index->fetch_init(cursor, qGet);


				//retrieve key,data pair
				while (!eof) {
					ret = index->fetch(cursor, &key, keysz, (void *)&lnode, datasz, eof);
					if (!ret && !eof){

						//if (key != lnode.GetStartPos().toDouble()) {
							//check whether the lnode data node's text value equal this text value
							//to prevent false positive in case that there is one text node under element node
							//it might equal the other one, not this one we are deleting
							//cout << key << "-" << lnode.GetStartPos().toDouble() << endl;
							DM_ElementNode* dataNode = (DM_ElementNode*)this->indexMng->pDataMng->fetchDataNodeFromDBFile((const FileInfoType)*fileinfo,lnode.GetStartPos());
							if (dataNode == NULL) {
								globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"IndexIncrementalUpdate::textNodeDeletion",__FILE__,"Data node cannot be fetched by the key given.");
								index->close();
								delete qGet;
								return false;
							}

							KeyType childkey1 = ((DM_ElementNode*) parentNode)->getFirstChild();
							while (childkey1 >= 0)
							{
								DM_DataNode* childnode1 = this->indexMng->pDataMng->fetchDataNodeFromDBFile((const FileInfoType)*fileinfo, childkey1);
								if (childnode1 == NULL) {
									break;
								}

								if (childnode1->getFlag() == TEXT_NODE)
								{
									KeyType childkey2 = ((DM_ElementNode*) dataNode)->getFirstChild();
									while (childkey2 >= 0)
									{
										DM_DataNode* childnode2 = this->indexMng->pDataMng->fetchDataNodeFromDBFile((const FileInfoType)*fileinfo, childkey2);
										if (childnode2 == NULL) {
											break;
										}

										if (childnode2->getFlag() == TEXT_NODE)
										{
											if (strcmp(((DM_TextNode*)childnode1)->getCharValue(),((DM_TextNode*)childnode2)->getCharValue()) ==0 )
											{
												match = true;
												delete childnode1;
												delete childnode2;
												goto matchLine;
											}
										}

										childkey2 = childnode2->getNextSibling();

										delete childnode2;
									} //while childkey2 >=0
								}
								delete childnode1;
							}//while childkey1 >=0
matchLine:
							if (match) {
								lnodeDel = new ListNode(lnode);
								qDel = new bt_query_t(bt_query_t::bt_eq,new double(key),NULL,lnodeDel,NULL);
								ret = index->remove(qDel);
								if (ret != RCOKGist) {
									globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"IndexIncrementalUpdate::textNodeDeletion",__FILE__,"Cannot remove an entry from the gist index file.");
									delete indexName;
									delete qDel;
									delete qGet;
									delete iInfo;
									index->close();
									this->indexMng->fileIndexTable->closeScanIndex();
									return false;
								}
								delete qDel;
								//then delete the mirror index if found one
								if (mirror) {
									lnodeDel = new ListNode();
									lnodeDel->SetStartPos(parentNode->getKey());
									lnodeDel->SetEndPos(parentNode->getEndKey());
									lnodeDel->SetLevel(parentNode->getLevel());
									qDel = new bt_query_t(bt_query_t::bt_eq,new double(lnode.GetStartPos().toDouble()),NULL,lnodeDel,NULL);
									ret = index2->remove(qDel);
									if (ret != RCOKGist) {
										globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"IndexIncrementalUpdate::textNodeDeletion",__FILE__,"Cannot remove an entry from the gist index file.");
										delete indexName;
										delete qDel;
										delete qGet;
										delete iInfo;
										index->close();
										index2->close();
										this->indexMng->fileIndexTable->closeScanIndex();
										return false;
									}
									delete qDel;
								}
								else if (same) { 
									//if ec_author_ec_author, do not need another opened index, b/c it's the same file
									//we want to delete lnode -> key (which is different)
									//for lnode = key , it fall in the below else clause
									lnodeDel = new ListNode();
									lnodeDel->SetStartPos(parentNode->getKey());
									lnodeDel->SetEndPos(parentNode->getEndKey());
									lnodeDel->SetLevel(parentNode->getLevel());
									qDel = new bt_query_t(bt_query_t::bt_eq,new double(lnode.GetStartPos().toDouble()),NULL,lnodeDel,NULL);
									ret = index->remove(qDel);
									if (ret != RCOKGist) {
										globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"IndexIncrementalUpdate::textNodeDeletion",__FILE__,"Cannot remove an entry from the gist index file.");
										delete indexName;
										delete qDel;
										delete qGet;
										delete iInfo;
										index->close();
										this->indexMng->fileIndexTable->closeScanIndex();
										return false;
									}
									delete qDel;
								}
							} //match
						//} // if (key != data.key)
						/*else { //key == data.key, usually in case of joining itself
							//can immediately delete without checking false positive
							lnodeDel = new ListNode(lnode);
							qDel = new bt_query_t(bt_query_t::bt_eq,new double(key),NULL,lnodeDel,NULL);
							ret = index->remove(qDel);
							if (ret != RCOKGist) {
								globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"IndexIncrementalUpdate::textNodeDeletion",__FILE__,"Cannot remove an entry from the gist index file.");
								delete indexName;
								delete qDel;
								delete qGet;
								delete iInfo;
								index->close();
								this->indexMng->fileIndexTable->closeScanIndex();
								return false;
							}
							delete qDel;
						}*/
					}//if (!ret && !eof)
				} //while !eof
				delete qGet;
				index->close();
				if (mirror){
					index2->close();
					delete index2;
				}
			} // if joinindex == elementcontent


		}
		if (getParentNode) delete parentNode;
	}
	break;
default:
	break;
		} //switch

		delete iInfo;
		getParentNode = false;
	}//while scan fileindex
	this->indexMng->fileIndexTable->closeScanIndex();
	return true;
}

/**
* Process Method
*
* Perform relevant incremental index update in case of attribute node deletion
*
* @param fileinfo The file info type of the xml file to perform incremental index update
* @param parentNode The data node pointer of the parent
* @param parentKey The key of the parent node (if parentNode = null, use this to get data node)
* @param nodeToDelete The data node pointer of the node to be deleted
* @return Whether it has any errors.
*/
bool IndexIncrementalUpdate::attributeNodeDeletion(FileInfoType* fileinfo, DM_ElementNode* parentNode, KeyType parentKey, DM_AttributeNode* nodeToDelete) 
{
	IndexInfoType *iInfo;
	ListNode* lnode;
	bt_query_t* qDel;
	int keyInt;
	float keyFloat;
	double keyDouble;
	char* keyChar;
	char* indexName;
	bool getParentNode = false;
	rc_tGist ret;

	//scan for all concerned indices
	this->indexMng->fileIndexTable->startScanIndex(fileinfo->key);
	while ((iInfo = this->indexMng->fileIndexTable->getNextIndexInfo()) != NULL) {

		switch (iInfo->indexDescription) {

case VALUEINDEX_ATTRIBUTENAME:
	{
		//get index name concat with path, and open it
		indexName = new char[strlen(this->indexNamePath) + strlen(iInfo->indexName) + 1];
		strcpy(indexName,this->indexNamePath);
		strcpy(indexName + strlen(this->indexNamePath), iInfo->indexName);

		ret = index->open(indexName);
		if (ret != RCOKGist) {
			globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"IndexIncrementalUpdate::attributeNodeDeletion",__FILE__,"Cannot open gist index file.");
			delete indexName;
			delete iInfo;
			this->indexMng->fileIndexTable->closeScanIndex();
			return false;
		}

		//for each attribute name in the node
		for (short i = 0; i < nodeToDelete->getAttributeNumber() ; i++){
			
			//remove attrname + attribute node key
			keyChar = new char[strlen(nodeToDelete->getAttributeNameAt(i))+1];
			strcpy(keyChar,nodeToDelete->getAttributeNameAt(i));

			lnode = new ListNode();
			lnode->SetStartPos(nodeToDelete->getKey());
			lnode->SetEndPos(nodeToDelete->getEndKey());
			lnode->SetLevel(nodeToDelete->getLevel());
			qDel = new bt_query_t(bt_query_t::bt_eq,keyChar,NULL,lnode,NULL);
			ret = index->remove(qDel);

			if (ret != RCOKGist) {
				globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"IndexIncrementalUpdate::attributeNodeDeletion",__FILE__,"Cannot remove an entry from the gist index file.");
				delete indexName;
				delete qDel;
				delete iInfo;
				index->close();
				this->indexMng->fileIndexTable->closeScanIndex();
				return false;
			}

			delete qDel;
		
		}//for
		index->close();
		delete indexName;
	}
	break;
case VALUEINDEX_ATTRIBUTENAME_ID_PAIR:
	{
		//get index name concat with path, and open it
		indexName = new char[strlen(this->indexNamePath) + strlen(iInfo->indexName) + 1];
		strcpy(indexName,this->indexNamePath);
		strcpy(indexName + strlen(this->indexNamePath), iInfo->indexName);

		ret = index->open(indexName);
		if (ret != RCOKGist) {
			globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"IndexIncrementalUpdate::attributeNodeDeletion",__FILE__,"Cannot open gist index file.");
			delete indexName;
			delete iInfo;
			this->indexMng->fileIndexTable->closeScanIndex();
			return false;
		}
		tagIdIndex = new TagNameAndNodeIdIndex();
		//for each attribute name in the node
		for (short i = 0; i < nodeToDelete->getAttributeNumber() ; i++){
			
			//remove attrname + attribute node key
			bool tRet = this->tagIdIndex->deleteNode(nodeToDelete->getAttributeNameAt(i),nodeToDelete->getKey().toDouble(),index);

			if (tRet != true) {
				globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"IndexIncrementalUpdate::attributeNodeDeletion",__FILE__,"Cannot remove an entry from the gist index file.");
				delete indexName;
				delete iInfo;
				delete tagIdIndex;
				index->close();
				this->indexMng->fileIndexTable->closeScanIndex();
				return false;
			}
		
		}//for
		delete tagIdIndex;
		index->close();
		delete indexName;
	}
	break;
case VALUEINDEX_ATTRIBUTEVALUE:
	{
		//get index name concat with path, and open it
		indexName = new char[strlen(this->indexNamePath) + strlen(iInfo->indexName) + 1];
		strcpy(indexName,this->indexNamePath);
		strcpy(indexName + strlen(this->indexNamePath), iInfo->indexName);

		ret = index->open(indexName);
		if (ret != RCOKGist) {
			globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"IndexIncrementalUpdate::attributeNodeDeletion",__FILE__,"Cannot open gist index file.");
			delete indexName;
			delete iInfo;
			this->indexMng->fileIndexTable->closeScanIndex();
			return false;
		}

		//for each attribute value in the node
		for (short i = 0; i < nodeToDelete->getAttributeNumber() ; i++){
			
			if(iInfo->indexType == STRING_INDEX){
				//remove attrvalue + attribute node key
				keyChar = new char[strlen(nodeToDelete->getAttrAt(i)->getStrValue())+1];
				strcpy(keyChar,nodeToDelete->getAttrAt(i)->getStrValue());

				lnode = new ListNode();
				lnode->SetStartPos(nodeToDelete->getKey());
				lnode->SetEndPos(nodeToDelete->getEndKey());
				lnode->SetLevel(nodeToDelete->getLevel());
				qDel = new bt_query_t(bt_query_t::bt_eq,keyChar,NULL,lnode,NULL);
				ret = index->remove(qDel);

				if (ret != RCOKGist) {
					globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"IndexIncrementalUpdate::attributeNodeDeletion",__FILE__,"Cannot remove an entry from the gist index file.");
					delete indexName;
					delete qDel;
					delete iInfo;
					index->close();
					this->indexMng->fileIndexTable->closeScanIndex();
					return false;
				}
				delete qDel;
			}
			else if(iInfo->indexType == INT_INDEX){
				//remove attrvalue + attribute node key
				keyInt = atoi(nodeToDelete->getAttrAt(i)->getStrValue());

				lnode = new ListNode();
				lnode->SetStartPos(nodeToDelete->getKey());
				lnode->SetEndPos(nodeToDelete->getEndKey());
				lnode->SetLevel(nodeToDelete->getLevel());
				qDel = new bt_query_t(bt_query_t::bt_eq,new int(keyInt),NULL,lnode,NULL);
				ret = index->remove(qDel);

				if (ret != RCOKGist) {
					globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"IndexIncrementalUpdate::attributeNodeDeletion",__FILE__,"Cannot remove an entry from the gist index file.");
					delete indexName;
					delete qDel;
					delete iInfo;
					index->close();
					this->indexMng->fileIndexTable->closeScanIndex();
					return false;
				}
				delete qDel;
			}
			else if(iInfo->indexType == FLOAT_INDEX){
				//remove attrvalue + attribute node key
				keyFloat = (float)atof(nodeToDelete->getAttrAt(i)->getStrValue());

				lnode = new ListNode();
				lnode->SetStartPos(nodeToDelete->getKey());
				lnode->SetEndPos(nodeToDelete->getEndKey());
				lnode->SetLevel(nodeToDelete->getLevel());
				qDel = new bt_query_t(bt_query_t::bt_eq,new float(keyFloat),NULL,lnode,NULL);
				ret = index->remove(qDel);

				if (ret != RCOKGist) {
					globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"IndexIncrementalUpdate::attributeNodeDeletion",__FILE__,"Cannot remove an entry from the gist index file.");
					delete indexName;
					delete qDel;
					delete iInfo;
					index->close();
					this->indexMng->fileIndexTable->closeScanIndex();
					return false;
				}
				delete qDel;
			}
			else if(iInfo->indexType == DOUBLE_INDEX){
				//remove attrvalue + attribute node key
				keyDouble = (double)atof(nodeToDelete->getAttrAt(i)->getStrValue());

				lnode = new ListNode();
				lnode->SetStartPos(nodeToDelete->getKey());
				lnode->SetEndPos(nodeToDelete->getEndKey());
				lnode->SetLevel(nodeToDelete->getLevel());
				qDel = new bt_query_t(bt_query_t::bt_eq,new double(keyDouble),NULL,lnode,NULL);
				ret = index->remove(qDel);

				if (ret != RCOKGist) {
					globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"IndexIncrementalUpdate::attributeNodeDeletion",__FILE__,"Cannot remove an entry from the gist index file.");
					delete indexName;
					delete qDel;
					delete iInfo;
					index->close();
					this->indexMng->fileIndexTable->closeScanIndex();
					return false;
				}
				delete qDel;
			}
		
		}//for
		index->close();
		delete indexName;
	}
	break;
case VALUEINDEX_ATTRIBUTECONTENT:
	{
		//get parent data node if the pointer passed is null
		if (parentNode == NULL) {
			getParentNode = true;
			parentNode = (DM_ElementNode*)this->indexMng->pDataMng->fetchDataNodeFromDBFile((const FileInfoType)*fileinfo,parentKey);
			if (parentNode == NULL) {
				globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"IndexIncrementalUpdate::nodeDeletion",__FILE__,"Parent cannot be fetched by the key given.");
				return false;
			}
		}

		for (short i = 0 ; i < nodeToDelete->getAttributeNumber() ; i++){
			//check whether this index is built on this attribute name
			//if not continue the for loop
			char* attrname = nodeToDelete->getAttributeNameAt(i);
			Value* attrnameval =  new Value(STRING_VALUE,attrname);
			//if the index is built on this attrname, modify key
			SelectionCondition* idxcond = new SelectionCondition(iInfo->selectionCondition);
			PredicateCondition* idxpred = idxcond->getCondition()->getCondAt(0)->getCondAt(0);

			if (!idxpred->getRightValue()->compareValue(VALUE_COMP_OP_EQ,attrnameval)) {
				//if attrname built != this attrname, ignore
				delete idxcond;
				delete attrnameval;
				continue;
			}

			delete idxcond;
			delete attrnameval;

			//get index name concat with path, and open it
			indexName = new char[strlen(this->indexNamePath) + strlen(iInfo->indexName) + 1];
			strcpy(indexName,this->indexNamePath);
			strcpy(indexName + strlen(this->indexNamePath), iInfo->indexName);

			//get parent data node if the pointer passed is null
			if (parentNode == NULL) {
				parentNode = (DM_ElementNode*)this->indexMng->pDataMng->fetchDataNodeFromDBFile((const FileInfoType)*fileinfo,parentKey);
				if (parentNode == NULL) {
					globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"IndexIncrementalUpdate::nodeDeletion",__FILE__,"Parent cannot be fetched by the key given.");
					return false;
				}
			}

			if(iInfo->indexType == STRING_INDEX){
				//remove attrval + parent element key
				keyChar = new char[strlen(nodeToDelete->getAttrAt(i)->getStrValue())+1];
				strcpy(keyChar,nodeToDelete->getAttrAt(i)->getStrValue());

				lnode = new ListNode();
				lnode->SetStartPos(parentNode->getKey());
				lnode->SetEndPos(parentNode->getEndKey());
				lnode->SetLevel(parentNode->getLevel());
				qDel = new bt_query_t(bt_query_t::bt_eq,keyChar,NULL,lnode,NULL);
				ret = index->remove(qDel);

				if (ret != RCOKGist) {
					globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"IndexIncrementalUpdate::attributeNodeDeletion",__FILE__,"Cannot remove an entry from the gist index file.");
					delete indexName;
					delete qDel;
					delete iInfo;
					index->close();
					this->indexMng->fileIndexTable->closeScanIndex();
					return false;
				}
				delete qDel;

			}
			else if (iInfo->indexType == INT_INDEX) {
				//remove attrval + parent element key
				keyInt = atoi(nodeToDelete->getAttrAt(i)->getStrValue());

				lnode = new ListNode();
				lnode->SetStartPos(parentNode->getKey());
				lnode->SetEndPos(parentNode->getEndKey());
				lnode->SetLevel(parentNode->getLevel());
				qDel = new bt_query_t(bt_query_t::bt_eq,new int(keyInt),NULL,lnode,NULL);
				ret = index->remove(qDel);

				if (ret != RCOKGist) {
					globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"IndexIncrementalUpdate::attributeNodeDeletion",__FILE__,"Cannot remove an entry from the gist index file.");
					delete indexName;
					delete qDel;
					delete iInfo;
					index->close();
					this->indexMng->fileIndexTable->closeScanIndex();
					return false;
				}
				delete qDel;

			}
			else if (iInfo->indexType == FLOAT_INDEX) {
				//remove attrval + parent element key
				keyFloat = (float)atof(nodeToDelete->getAttrAt(i)->getStrValue());

				lnode = new ListNode();
				lnode->SetStartPos(parentNode->getKey());
				lnode->SetEndPos(parentNode->getEndKey());
				lnode->SetLevel(parentNode->getLevel());
				qDel = new bt_query_t(bt_query_t::bt_eq,new float(keyFloat),NULL,lnode,NULL);
				ret = index->remove(qDel);

				if (ret != RCOKGist) {
					globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"IndexIncrementalUpdate::attributeNodeDeletion",__FILE__,"Cannot remove an entry from the gist index file.");
					delete indexName;
					delete qDel;
					delete iInfo;
					index->close();
					this->indexMng->fileIndexTable->closeScanIndex();
					return false;
				}
				delete qDel;

			}
			else if (iInfo->indexType == DOUBLE_INDEX) {
				//remove attrval + parent element key
				keyDouble = (double)atof(nodeToDelete->getAttrAt(i)->getStrValue());

				lnode = new ListNode();
				lnode->SetStartPos(parentNode->getKey());
				lnode->SetEndPos(parentNode->getEndKey());
				lnode->SetLevel(parentNode->getLevel());
				qDel = new bt_query_t(bt_query_t::bt_eq,new double(keyDouble),NULL,lnode,NULL);
				ret = index->remove(qDel);

				if (ret != RCOKGist) {
					globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"IndexIncrementalUpdate::attributeNodeDeletion",__FILE__,"Cannot remove an entry from the gist index file.");
					delete indexName;
					delete qDel;
					delete iInfo;
					index->close();
					this->indexMng->fileIndexTable->closeScanIndex();
					return false;
				}
				delete qDel;
			}

			index->close();
			delete indexName;
			break; //at least one match, should not be more
		}//for all attribute name
		if (getParentNode) delete parentNode;
	}
	break;

case JOININDEX:
	{
		bool mirror = false, same = false; //whether mirror index exist, and successfully opened for operation
		char* indexName2;
		gist* index2 = new gist;
		//check only if it is left side, since we can retrieve/del the entry only if it's the key (left side)
		//since we assume there will be a mirror index, we will automatically try to update both
		if ((iInfo->leftSideType == JOININDEX_ATTRIBUTECONTENT) ||
			(iInfo->leftSideType == JOININDEX_ATTRIBUTEVALUE)) {
			//try to delete from it the parent key as leftside key (for content type) or attrkey (for value type)
			//get parent data node if it is the content type and the pointer passed is null
			if ((iInfo->leftSideType == JOININDEX_ATTRIBUTECONTENT) && (parentNode == NULL)) {
				getParentNode = true;
				parentNode = (DM_ElementNode*)this->indexMng->pDataMng->fetchDataNodeFromDBFile((const FileInfoType)*fileinfo,parentKey);
				if (parentNode == NULL) {
					globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"IndexIncrementalUpdate::attributeNodeDeletion",__FILE__,"Parent cannot be fetched by the key given.");
					return false;
				}
			}

			short attrat = -1;

			//for each attribute name, value pair, find matching attrname == the left side of this index
			for (short i = 0 ; i < nodeToDelete->getAttributeNumber() ; i++) {
				if (strcmp(nodeToDelete->getAttributeNameAt(i),iInfo->leftSide) == 0) {
					attrat = i;
					break;
				}
			}


			//check whether left side = this attrname
			if (attrat != -1) {
				//get index name concat with path, and open it
				indexName = new char[strlen(this->indexNamePath) + strlen(iInfo->indexName) + 1];
				strcpy(indexName,this->indexNamePath);
				strcpy(indexName + strlen(this->indexNamePath), iInfo->indexName);

					

				ret = index->open(indexName);
				if (ret != RCOKGist) {
					globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"IndexIncrementalUpdate::attributeNodeDeletion",__FILE__,"Cannot open gist index file.");
					delete indexName;
					delete iInfo;
					this->indexMng->fileIndexTable->closeScanIndex();
					return false;
				}

				//get mirror only if mirror name is different than this name
				char indexMirror[MAX_INDEX_NAME_LENGTH];
				bool rc = this->indexMng->constructIndexName(iInfo->fileName,indexMirror,JOININDEX,NULL,DOUBLE_INDEX,iInfo->rightSide,iInfo->rightSideType,iInfo->leftSide,iInfo->leftSideType);
				if (strcmp(indexMirror,iInfo->indexName) != 0) {
					if (rc && this->indexMng->existIndex(indexMirror)) {
						indexName2 = new char[strlen(this->indexNamePath) + strlen(indexMirror) + 1];
						strcpy(indexName2,this->indexNamePath);
						strcpy(indexName2 + strlen(this->indexNamePath), indexMirror);

						ret = index2->open(indexName2);
						if (ret == RCOKGist) {
							mirror = true;
						}
						delete indexName2;
					}
				}
				else { //ac_id_ac_id
					same = true;
				}

				bt_query_t *qGet, *qDel;
				gist_cursor_t cursor;
				bool eof = false;
				unsigned long keysz, datasz;
				double key;
				ListNode lnode;
				ListNode* lnodeDel;

				if (iInfo->leftSideType == JOININDEX_ATTRIBUTECONTENT)
					qGet = new bt_query_t(bt_query_t::bt_eq,new double(parentNode->getKey().toDouble()),NULL);
				else
					qGet = new bt_query_t(bt_query_t::bt_eq,new double(nodeToDelete->getKey().toDouble()),NULL);

				cursor.k = 0;
				cursor.io = 0;
				cursor.query = NULL;
				cursor.ext = NULL;
				cursor.cext = NULL;
				cursor.iter = NULL;
				cursor.state = NULL;
				index->fetch_init(cursor, qGet);


				//retrieve key,data pair
				while (!eof) {
					ret = index->fetch(cursor, &key, keysz, (void *)&lnode, datasz, eof);
					if (!ret && !eof){

						//if (key != lnode.GetStartPos().toDouble()) {
							//no false positive b/c one attrname only for one attrnode
							//cout << key << "-" << lnode.GetStartPos().toDouble() << endl;
							lnodeDel = new ListNode(lnode);
							qDel = new bt_query_t(bt_query_t::bt_eq,new double(key),NULL,lnodeDel,NULL);
							ret = index->remove(qDel);
							if (ret != RCOKGist) {
								globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"IndexIncrementalUpdate::attributeNodeDeletion",__FILE__,"Cannot remove an entry from the gist index file.");
								delete indexName;
								delete qDel;
								delete qGet;
								delete iInfo;
								index->close();
								this->indexMng->fileIndexTable->closeScanIndex();
								return false;
							}
							delete qDel;
							//then delete the mirror index if found one
							if (mirror) {
								lnodeDel = new ListNode();
								if (iInfo->leftSideType == JOININDEX_ATTRIBUTECONTENT) {
									lnodeDel->SetStartPos(parentNode->getKey());
									lnodeDel->SetEndPos(parentNode->getEndKey());
									lnodeDel->SetLevel(parentNode->getLevel());
								}
								else {
									lnodeDel->SetStartPos(nodeToDelete->getKey());
									lnodeDel->SetEndPos(nodeToDelete->getEndKey());
									lnodeDel->SetLevel(nodeToDelete->getLevel());
								}
								qDel = new bt_query_t(bt_query_t::bt_eq,new double(lnode.GetStartPos().toDouble()),NULL,lnodeDel,NULL);
								ret = index2->remove(qDel);
								if (ret != RCOKGist) {
									globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"IndexIncrementalUpdate::attributeNodeDeletion",__FILE__,"Cannot remove an entry from the gist index file.");
									delete indexName;
									delete qDel;
									delete qGet;
									delete iInfo;
									index->close();
									index2->close();
									this->indexMng->fileIndexTable->closeScanIndex();
									return false;
								}
								delete qDel;
							}
							else if (same) { 
								//if ac_id_ac_id, do not need another opened index, b/c it's the same file
								//we want to delete lnode -> key (which is different)
								//for lnode = key , it fall in the below else clause
								lnodeDel = new ListNode();
								if (iInfo->leftSideType == JOININDEX_ATTRIBUTECONTENT) {
									lnodeDel->SetStartPos(parentNode->getKey());
									lnodeDel->SetEndPos(parentNode->getEndKey());
									lnodeDel->SetLevel(parentNode->getLevel());
								}
								else {
									lnodeDel->SetStartPos(nodeToDelete->getKey());
									lnodeDel->SetEndPos(nodeToDelete->getEndKey());
									lnodeDel->SetLevel(nodeToDelete->getLevel());
								}
								qDel = new bt_query_t(bt_query_t::bt_eq,new double(lnode.GetStartPos().toDouble()),NULL,lnodeDel,NULL);
								ret = index->remove(qDel);
								if (ret != RCOKGist) {
									globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"IndexIncrementalUpdate::attributeNodeDeletion",__FILE__,"Cannot remove an entry from the gist index file.");
									delete indexName;
									delete qDel;
									delete qGet;
									delete iInfo;
									index->close();
									this->indexMng->fileIndexTable->closeScanIndex();
									return false;
								}
								delete qDel;
							}
						//} // if (key != data.key)
						/*else { //key == data.key, usually in case of joining itself
							lnodeDel = new ListNode(lnode);
							qDel = new bt_query_t(bt_query_t::bt_eq,new double(key),NULL,lnodeDel,NULL);
							ret = index->remove(qDel);
							if (ret != RCOKGist) {
								globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"IndexIncrementalUpdate::attributeNodeDeletion",__FILE__,"Cannot remove an entry from the gist index file.");
								delete indexName;
								delete qDel;
								delete qGet;
								delete iInfo;
								index->close();
								this->indexMng->fileIndexTable->closeScanIndex();
								return false;
							}
							delete qDel;
						}*/
					}//if (!ret && !eof)
				} //while !eof
				delete qGet;
				index->close();
				if (mirror){
					index2->close();
					delete index2;
				}
			} // if joinindex == elementcontent


		}
		if (getParentNode) delete parentNode;
	}
	break;
default:
	break;
		} //switch
		getParentNode = false;
		delete iInfo;
	}//while scan fileindex
	this->indexMng->fileIndexTable->closeScanIndex();
	return true;
}

/**
* Process Method
*
* Perform relevant incremental index update in case of node insertion
* Node can be element or text or attribute
*
* @param fileinfo The file info type of the xml file to perform incremental index update
* @param parentNode The data node pointer of the parent
* @param nodeToInsert The data node pointer of the node to be inserted
* @return Whether it has any errors.
*/
bool IndexIncrementalUpdate::nodeInsertion(FileInfoType* fileinfo,  DM_ElementNode* parentNode, DM_DataNode* nodeToInsert)
{

	if (nodeToInsert->getFlag() == ELEMENT_NODE){
		return elementNodeInsertion(fileinfo,(DM_ElementNode*)nodeToInsert);
	}
	else if (nodeToInsert->getFlag()== TEXT_NODE) {
		return textNodeInsertion(fileinfo,parentNode,NULL,(DM_TextNode*)nodeToInsert);
	}
	else if (nodeToInsert->getFlag() == ATTRIBUTE_NODE) {
		return attributeNodeInsertion(fileinfo,parentNode,NULL,(DM_AttributeNode*)nodeToInsert);
	}
	else {
		globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"IndexIncrementalUpdate::nodeInsertion",__FILE__,"Node type not support for insertion.");
		return false;
	}

}

/**
* Process Method
*
* Perform relevant incremental index update in case of node insertion
* Node can be element or text or attribute
*
* @param fileinfo The file info type of the xml file to perform incremental index update
* @param parentKey The parent key
* @param nodeToInsert The data node pointer of the node to be inserted
* @return Whether it has any errors.
*/
bool IndexIncrementalUpdate::nodeInsertion(FileInfoType* fileinfo, KeyType parentKey, DM_DataNode* nodeToInsert)
{
	bool ret = false;

	if (nodeToInsert->getFlag() == ELEMENT_NODE){
		ret = elementNodeInsertion(fileinfo,(DM_ElementNode*)nodeToInsert);
	}
	else if (nodeToInsert->getFlag()== TEXT_NODE) {
		ret = textNodeInsertion(fileinfo,NULL,parentKey,(DM_TextNode*)nodeToInsert);
	}
	else if (nodeToInsert->getFlag() == ATTRIBUTE_NODE) {
		ret = attributeNodeInsertion(fileinfo,NULL,parentKey,(DM_AttributeNode*)nodeToInsert);
	}
	else {
		globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"IndexIncrementalUpdate::nodeInsertion",__FILE__,"Node type not support for insertion.");
	}
	return ret;
}

/**
* Process Method
*
* Perform relevant incremental index update in case of element node insertion
*
* @param fileinfo The file info type of the xml file to perform incremental index update
* @param nodeToInsert The data node pointer of the node to be inserted
* @return Whether it has any errors.
*/
bool IndexIncrementalUpdate::elementNodeInsertion(FileInfoType* fileinfo, DM_ElementNode* nodeToInsert)
{
	IndexInfoType *iInfo;
	ListNode* lnode;
	int keyInt;
	//float keyFloat;
	//double keyDouble;
	char* keyChar;
	char* indexName;
	rc_tGist ret;
	
	//scan for all concerned indices
	this->indexMng->fileIndexTable->startScanIndex(fileinfo->key);
	while ((iInfo = this->indexMng->fileIndexTable->getNextIndexInfo()) != NULL) {

		switch (iInfo->indexDescription) {

case VALUEINDEX_ELEMENTTAG:
	{
		//get index name concat with path, and open it
		indexName = new char[strlen(this->indexNamePath) + strlen(iInfo->indexName) + 1];
		strcpy(indexName,this->indexNamePath);
		strcpy(indexName + strlen(this->indexNamePath), iInfo->indexName);

		ret = index->open(indexName);
		if (ret != RCOKGist) {
			globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"IndexIncrementalUpdate::elementNodeInsertion",__FILE__,"Cannot open gist index file.");
			delete indexName;
			delete iInfo;
			this->indexMng->fileIndexTable->closeScanIndex();
			return false;
		}

		//add tag + newkey
		keyInt = nodeToInsert->getTag();
		lnode = new ListNode();
		lnode->SetStartPos(nodeToInsert->getKey());
		lnode->SetEndPos(nodeToInsert->getEndKey());
		lnode->SetLevel(nodeToInsert->getLevel());
		ret = index->insert(&keyInt,sizeof(int),lnode,sizeof(ListNode));

		if (ret != RCOKGist) {
			globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"IndexIncrementalUpdate::elementNodeInsertion",__FILE__,"Cannot insert an entry from the gist index file.");
			delete lnode;
			delete indexName;
			delete iInfo;
			index->close();
			this->indexMng->fileIndexTable->closeScanIndex();
			return false;
		}

		delete lnode;
		index->close();
		delete indexName;
	}
	break;

case VALUEINDEX_TAGNAME_ID_PAIR:
	{
		//get index name concat with path, and open it
		indexName = new char[strlen(this->indexNamePath) + strlen(iInfo->indexName) + 1];
		strcpy(indexName,this->indexNamePath);
		strcpy(indexName + strlen(this->indexNamePath), iInfo->indexName);

		ret = index->open(indexName);
		if (ret != RCOKGist) {
			globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"IndexIncrementalUpdate::elementNodeInsertion",__FILE__,"Cannot open gist index file.");
			delete indexName;
			delete iInfo;
			this->indexMng->fileIndexTable->closeScanIndex();
			return false;
		}
	
		lnode = new ListNode();
		lnode->SetStartPos(nodeToInsert->getKey());
		lnode->SetEndPos(nodeToInsert->getEndKey());
		lnode->SetLevel(nodeToInsert->getLevel());
		tagIdIndex = new TagNameAndNodeIdIndex();

		//remove tag&key
		bool tRet = this->tagIdIndex->insertNode(nodeToInsert->getTag(this->indexMng->pDataMng->getXMLNameTable()),nodeToInsert->getKey().toDouble(),lnode,sizeof(ListNode),index);

		if (tRet != true) {
			globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"IndexIncrementalUpdate::elementNodeInsertion",__FILE__,"Cannot remove an entry from the gist index file.");
			delete indexName;
			delete iInfo;
			delete lnode;
			delete tagIdIndex;
			index->close();
			this->indexMng->fileIndexTable->closeScanIndex();
			return false;
		}
		delete lnode;
		delete tagIdIndex;
		index->close();
		delete indexName;
	}
	break;

case VALUEINDEX_ELEMENTTAGSTR:
	{
		//get index name concat with path, and open it
		indexName = new char[strlen(this->indexNamePath) + strlen(iInfo->indexName) + 1];
		strcpy(indexName,this->indexNamePath);
		strcpy(indexName + strlen(this->indexNamePath), iInfo->indexName);

		ret = index->open(indexName);
		if (ret != RCOKGist) {
			globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"IndexIncrementalUpdate::elementNodeInsertion",__FILE__,"Cannot open gist index file.");
			delete indexName;
			delete iInfo;
			this->indexMng->fileIndexTable->closeScanIndex();
			return false;
		}

		//add tag + newkey
		keyChar = new char[strlen(nodeToInsert->getTag(this->indexMng->pDataMng->getXMLNameTable()))+1];
		strcpy(keyChar,nodeToInsert->getTag(this->indexMng->pDataMng->getXMLNameTable()));

		lnode = new ListNode();
		lnode->SetStartPos(nodeToInsert->getKey());
		lnode->SetEndPos(nodeToInsert->getEndKey());
		lnode->SetLevel(nodeToInsert->getLevel());
		ret = index->insert(keyChar,(int)(strlen((char *)keyChar))+1,lnode,sizeof(ListNode));

		if (ret != RCOKGist) {
			globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"IndexIncrementalUpdate::elementNodeInsertion",__FILE__,"Cannot insert an entry from the gist index file.");
			delete indexName;
			delete iInfo;
			delete lnode;
			delete keyChar;
			index->close();
			this->indexMng->fileIndexTable->closeScanIndex();
			return false;
		}

		delete lnode;
		delete keyChar;
		index->close();
		delete indexName;
	}
	break;
default:
	break;
		} //switch

		delete iInfo;
	}//while scan fileindex
	this->indexMng->fileIndexTable->closeScanIndex();
	return true;
}

/**
* Process Method
*
* Perform relevant incremental index update in case of text node insertion
*
* @param fileinfo The file info type of the xml file to perform incremental index update
* @param parentNode The data node pointer of the parent
* @param parentKey The parent key (if parentNode = NULL, use this to get parentNode)
* @param nodeToInsert The data node pointer of the node to be inserted
* @return Whether it has any errors.
*/
bool IndexIncrementalUpdate::textNodeInsertion(FileInfoType* fileinfo, DM_ElementNode* parentNode, KeyType parentKey, DM_TextNode* nodeToInsert)
{
	IndexInfoType *iInfo;
	ListNode* lnode;
	int keyInt;
	float keyFloat;
	double keyDouble;
	char* keyChar;
	char* indexName;
	bool getParentNode = false;
	rc_tGist ret;

	//scan for all concerned indices
	this->indexMng->fileIndexTable->startScanIndex(fileinfo->key);
	while ((iInfo = this->indexMng->fileIndexTable->getNextIndexInfo()) != NULL) {

		switch (iInfo->indexDescription) {

case VALUEINDEX_TEXTVALUE:
	{
		//get index name concat with path, and open it
		indexName = new char[strlen(this->indexNamePath) + strlen(iInfo->indexName) + 1];
		strcpy(indexName,this->indexNamePath);
		strcpy(indexName + strlen(this->indexNamePath), iInfo->indexName);


		ret = index->open(indexName);
		if (ret != RCOKGist) {
			globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"IndexIncrementalUpdate::textNodeInsertion",__FILE__,"Cannot open gist index file.");
			delete indexName;
			delete iInfo;
			this->indexMng->fileIndexTable->closeScanIndex();
			return false;
		}

		if(iInfo->indexType == STRING_INDEX){
			//add textvalue + newkey
			keyChar = new char[strlen(nodeToInsert->getCharValue())+1];
			strcpy(keyChar,nodeToInsert->getCharValue());

			lnode = new ListNode();
			lnode->SetStartPos(nodeToInsert->getKey());
			lnode->SetEndPos(nodeToInsert->getEndKey());
			lnode->SetLevel(nodeToInsert->getLevel());
			ret = index->insert(keyChar,(int)(strlen((char *)keyChar))+1,lnode,sizeof(ListNode));

			if (ret != RCOKGist) {
				globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"IndexIncrementalUpdate::textNodeInsertion",__FILE__,"Cannot insert an entry from the gist index file.");
				delete indexName;
				delete iInfo;
				delete lnode;
				delete keyChar;
				index->close();
				this->indexMng->fileIndexTable->closeScanIndex();
				return false;
			}
			delete keyChar;
			delete lnode;
		}
		else if (iInfo->indexType == INT_INDEX){
			//add textvalue + newkey
			keyInt = atoi(nodeToInsert->getCharValue());

			lnode = new ListNode();
			lnode->SetStartPos(nodeToInsert->getKey());
			lnode->SetEndPos(nodeToInsert->getEndKey());
			lnode->SetLevel(nodeToInsert->getLevel());
			ret = index->insert(&keyInt,sizeof(int),lnode,sizeof(ListNode));

			if (ret != RCOKGist) {
				globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"IndexIncrementalUpdate::textNodeInsertion",__FILE__,"Cannot insert an entry from the gist index file.");
				delete indexName;
				delete iInfo;
				delete lnode;
				index->close();
				this->indexMng->fileIndexTable->closeScanIndex();
				return false;
			}
			delete lnode;
		}
		else if (iInfo->indexType == FLOAT_INDEX){
			//add textvalue + oldkey
			keyFloat = (float)atof(nodeToInsert->getCharValue());

			lnode = new ListNode();
			lnode->SetStartPos(nodeToInsert->getKey());
			lnode->SetEndPos(nodeToInsert->getEndKey());
			lnode->SetLevel(nodeToInsert->getLevel());
			ret = index->insert(&keyFloat,sizeof(float),lnode,sizeof(ListNode));

			if (ret != RCOKGist) {
				globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"IndexIncrementalUpdate::textNodeInsertion",__FILE__,"Cannot insert an entry from the gist index file.");
				delete indexName;
				delete iInfo;
				delete lnode;
				index->close();
				this->indexMng->fileIndexTable->closeScanIndex();
				return false;
			}
			delete lnode;
		}
		else if (iInfo->indexType == DOUBLE_INDEX){
			//remove textvalue + oldkey
			keyDouble = (double)atof(nodeToInsert->getCharValue());

			lnode = new ListNode();
			lnode->SetStartPos(nodeToInsert->getKey());
			lnode->SetEndPos(nodeToInsert->getEndKey());
			lnode->SetLevel(nodeToInsert->getLevel());
			ret = index->insert(&keyDouble,sizeof(double),lnode,sizeof(ListNode));

			if (ret != RCOKGist) {
				globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"IndexIncrementalUpdate::textNodeInsertion",__FILE__,"Cannot insert an entry from the gist index file.");
				delete indexName;
				delete iInfo;
				delete lnode;
				index->close();
				this->indexMng->fileIndexTable->closeScanIndex();
				return false;
			}
			delete lnode;
		}

		index->close();
		delete indexName;
	}
	break;

case VALUEINDEX_ELEMENTCONTENT:
	{
		//get parent data node if the pointer passed is null
		if (parentNode == NULL) {
			getParentNode = true;
			parentNode = (DM_ElementNode*)this->indexMng->pDataMng->fetchDataNodeFromDBFile((const FileInfoType)*fileinfo,parentKey);
			if (parentNode == NULL) {
				globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"IndexIncrementalUpdate::nodeDeletion",__FILE__,"Parent cannot be fetched by the key given.");
				return false;
			}
		}

		int tagInt = parentNode->getTag();
		//check whether the index is built on this node tag
		SelectionCondition* idxcond = new SelectionCondition(iInfo->selectionCondition);
		PredicateCondition* idxpred = idxcond->getCondition()->getCondAt(0)->getCondAt(0);
		Value* val = new Value(INT_VALUE);
		val->setIntValue(tagInt);
		if (!idxpred->getRightValue()->compareValue(VALUE_COMP_OP_EQ,val)) {
			//if tagname built != this modified node tag name, ignore
			delete idxcond;
			delete val;
			break;
		}

		delete idxcond;
		delete val;


		//get index name concat with path, and open it
		indexName = new char[strlen(this->indexNamePath) + strlen(iInfo->indexName) + 1];
		strcpy(indexName,this->indexNamePath);
		strcpy(indexName + strlen(this->indexNamePath), iInfo->indexName);

		ret = index->open(indexName);
		if (ret != RCOKGist) {
			globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"IndexIncrementalUpdate::textNodeInsertion",__FILE__,"Cannot open gist index file.");
			delete indexName;
			delete iInfo;
			this->indexMng->fileIndexTable->closeScanIndex();
			return false;
		}

		if(iInfo->indexType == STRING_INDEX){
			//add content + parent key
			keyChar = new char[strlen(nodeToInsert->getCharValue())+1];
			strcpy(keyChar,nodeToInsert->getCharValue());

			lnode = new ListNode();
			lnode->SetStartPos(parentNode->getKey());
			lnode->SetEndPos(parentNode->getEndKey());
			lnode->SetLevel(parentNode->getLevel());
			ret = index->insert(keyChar,(int)(strlen((char *)keyChar))+1,lnode,sizeof(ListNode));

			if (ret != RCOKGist) {
				globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"IndexIncrementalUpdate::textNodeInsertion",__FILE__,"Cannot insert an entry from the gist index file.");
				delete indexName;
				delete iInfo;
				delete lnode;
				delete keyChar;
				index->close();
				this->indexMng->fileIndexTable->closeScanIndex();
				return false;
			}
			delete lnode;
			delete keyChar;
		}
		else if (iInfo->indexType == INT_INDEX) {

			//add content + parentkey
			keyInt = atoi(nodeToInsert->getCharValue());

			lnode = new ListNode();
			lnode->SetStartPos(parentNode->getKey());
			lnode->SetEndPos(parentNode->getEndKey());
			lnode->SetLevel(parentNode->getLevel());
			ret = index->insert(&keyInt,sizeof(int),lnode,sizeof(ListNode));

			if (ret != RCOKGist) {
				globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"IndexIncrementalUpdate::textNodeInsertion",__FILE__,"Cannot insert an entry from the gist index file.");
				delete indexName;
				delete iInfo;
				delete lnode;
				index->close();
				this->indexMng->fileIndexTable->closeScanIndex();
				return false;
			}
			delete lnode;
		}
		else if (iInfo->indexType == FLOAT_INDEX) {
			//add content + parentkey
			keyFloat = (float)atof(nodeToInsert->getCharValue());

			lnode = new ListNode();
			lnode->SetStartPos(parentNode->getKey());
			lnode->SetEndPos(parentNode->getEndKey());
			lnode->SetLevel(parentNode->getLevel());
			ret = index->insert(&keyFloat,sizeof(float),lnode,sizeof(ListNode));

			if (ret != RCOKGist) {
				globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"IndexIncrementalUpdate::textNodeInsertion",__FILE__,"Cannot insert an entry from the gist index file.");
				delete indexName;
				delete iInfo;
				delete lnode;
				index->close();
				this->indexMng->fileIndexTable->closeScanIndex();
				return false;
			}
			delete lnode;

		}
		else if (iInfo->indexType == DOUBLE_INDEX) {
			//add content + parentkey
			keyDouble = (double)atof(nodeToInsert->getCharValue());

			lnode = new ListNode();
			lnode->SetStartPos(parentNode->getKey());
			lnode->SetEndPos(parentNode->getEndKey());
			lnode->SetLevel(parentNode->getLevel());
			ret = index->insert(&keyDouble,sizeof(double),lnode,sizeof(ListNode));

			if (ret != RCOKGist) {
				globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"IndexIncrementalUpdate::textNodeInsertion",__FILE__,"Cannot insert an entry from the gist index file.");
				delete indexName;
				delete iInfo;
				delete lnode;
				index->close();
				this->indexMng->fileIndexTable->closeScanIndex();
				return false;
			}
			delete lnode;

		}
		
		if (getParentNode) delete parentNode;
		index->close();
		delete indexName;
	}
	break;
case JOININDEX:
	{
		if ((iInfo->leftSideType == JOININDEX_ELEMENTCONTENT) || 
			(iInfo->rightSideType == JOININDEX_ELEMENTCONTENT)) 
		{
			//get parent data node if the pointer passed is null
			if (parentNode == NULL) {
				getParentNode = true;
				parentNode = (DM_ElementNode*)this->indexMng->pDataMng->fetchDataNodeFromDBFile((const FileInfoType)*fileinfo,parentKey);
				if (parentNode == NULL) {
					globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"IndexIncrementalUpdate::textNodeInsertion",__FILE__,"Parent cannot be fetched by the key given.");
					return false;
				}
			}
			int tagInt = parentNode->getTag();
			if (iInfo->leftSideType == JOININDEX_ELEMENTCONTENT)
			{
				//check whether the tag built is this node's parent tag
				if (this->indexMng->xmlNameTable->getCodeByName(iInfo->leftSide) == tagInt){
					//not support, and inefficient to update the join index for this case
					globalErrorInfo.insertProblem(ERR_TYPE_WARNING,__LINE__,"IndexIncrementalUpdate::textNodeInsertion",__FILE__,"Some of join indices are not supported to the update. Please rebuild accordingly");  
					cout << "Please drop and rebuild join index: " << iInfo->indexName  << endl;
				}
			}

			if (iInfo->rightSideType == JOININDEX_ELEMENTCONTENT)
			{
				//check whether the tag built is this node's parent tag
				if (this->indexMng->xmlNameTable->getCodeByName(iInfo->rightSide) == tagInt){
					//not support, and inefficient to update the join index for this case
					globalErrorInfo.insertProblem(ERR_TYPE_WARNING,__LINE__,"IndexIncrementalUpdate::textNodeInsertion",__FILE__,"Some of join indices are not supported to the update. Please rebuild accordingly");  
					cout << "Please drop and rebuild join index: " << iInfo->indexName  << endl;
				}
			}
			if (getParentNode) delete parentNode;
		}
	}
	break;
default:
	break;
		} //switch

		delete iInfo;
		getParentNode = false;
	}//while scan fileindex
	this->indexMng->fileIndexTable->closeScanIndex();
	return true;
}

/**
* Process Method
*
* Perform relevant incremental index update in case of attribute node insertion
*
* @param fileinfo The file info type of the xml file to perform incremental index update
* @param parentNode The data node pointer of the parent
* @param parentKey The parent key (if parentNode = NULL, use this to get parentNode)
* @param nodeToInsert The data node pointer of the node to be inserted
* @return Whether it has any errors.
*/
bool IndexIncrementalUpdate::attributeNodeInsertion(FileInfoType* fileinfo, DM_ElementNode* parentNode, KeyType parentKey, DM_AttributeNode* nodeToInsert)
{
	IndexInfoType *iInfo;
	ListNode* lnode;
	int keyInt;
	float keyFloat;
	double keyDouble;
	char* keyChar;
	char* indexName;
	bool getParentNode = false;
	rc_tGist ret;
	
	//scan for all concerned indices
	this->indexMng->fileIndexTable->startScanIndex(fileinfo->key);
	while ((iInfo = this->indexMng->fileIndexTable->getNextIndexInfo()) != NULL) {

		switch (iInfo->indexDescription) {

case VALUEINDEX_ATTRIBUTENAME:
	{
		//get index name concat with path, and open it
		indexName = new char[strlen(this->indexNamePath) + strlen(iInfo->indexName) + 1];
		strcpy(indexName,this->indexNamePath);
		strcpy(indexName + strlen(this->indexNamePath), iInfo->indexName);


		ret = index->open(indexName);
		if (ret != RCOKGist) {
			globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"IndexIncrementalUpdate::attributeNodeInsertion",__FILE__,"Cannot open gist index file.");
			delete indexName;
			delete iInfo;
			this->indexMng->fileIndexTable->closeScanIndex();
			return false;
		}

		for (short i = 0 ; i < nodeToInsert->getAttributeNumber() ; i++){
			//add attrname+ key
			keyChar = new char[strlen(nodeToInsert->getAttributeNameAt(i))+1];
			strcpy(keyChar,nodeToInsert->getAttributeNameAt(i));

			lnode = new ListNode();
			lnode->SetStartPos(nodeToInsert->getKey());
			lnode->SetEndPos(nodeToInsert->getEndKey());
			lnode->SetLevel(nodeToInsert->getLevel());
			ret = index->insert(keyChar,(int)(strlen((char *)keyChar))+1,lnode,sizeof(ListNode));

			if (ret != RCOKGist) {
				globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"IndexIncrementalUpdate::attributeNodeInsertion",__FILE__,"Cannot insert an entry from the gist index file.");
				delete indexName;
				delete iInfo;
				delete lnode;
				delete keyChar;
				index->close();
				this->indexMng->fileIndexTable->closeScanIndex();
				return false;
			}
			delete lnode;
			delete keyChar;
		}
		index->close();
		delete indexName;
	}
	break;
case VALUEINDEX_ATTRIBUTENAME_ID_PAIR:
	{
		//get index name concat with path, and open it
		indexName = new char[strlen(this->indexNamePath) + strlen(iInfo->indexName) + 1];
		strcpy(indexName,this->indexNamePath);
		strcpy(indexName + strlen(this->indexNamePath), iInfo->indexName);

		ret = index->open(indexName);
		if (ret != RCOKGist) {
			globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"IndexIncrementalUpdate::attributeNodeInsertion",__FILE__,"Cannot open gist index file.");
			delete indexName;
			delete iInfo;
			this->indexMng->fileIndexTable->closeScanIndex();
			return false;
		}
		tagIdIndex = new TagNameAndNodeIdIndex();
		//for each attribute name in the node
		for (short i = 0; i < nodeToInsert->getAttributeNumber() ; i++){
			
			lnode = new ListNode();
			lnode->SetStartPos(nodeToInsert->getKey());
			lnode->SetEndPos(nodeToInsert->getEndKey());
			lnode->SetLevel(nodeToInsert->getLevel());

			//remove attrname + attribute node key
			bool tRet = this->tagIdIndex->insertNode(nodeToInsert->getAttributeNameAt(i),nodeToInsert->getKey().toDouble(),lnode,sizeof(ListNode),index);

			if (tRet != true) {
				globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"IndexIncrementalUpdate::attributeNodeInsertion",__FILE__,"Cannot remove an entry from the gist index file.");
				delete indexName;
				delete iInfo;
				delete lnode;
				delete tagIdIndex;
				index->close();
				this->indexMng->fileIndexTable->closeScanIndex();
				return false;
			}
			delete lnode;
		}//for
		delete tagIdIndex;
		index->close();
		delete indexName;
	}
	break;
case VALUEINDEX_ATTRIBUTEVALUE:
	{
		//get index name concat with path, and open it
		indexName = new char[strlen(this->indexNamePath) + strlen(iInfo->indexName) + 1];
		strcpy(indexName,this->indexNamePath);
		strcpy(indexName + strlen(this->indexNamePath), iInfo->indexName);


		ret = index->open(indexName);
		if (ret != RCOKGist) {
			globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"IndexIncrementalUpdate::attributeNodeInsertion",__FILE__,"Cannot open gist index file.");
			delete indexName;
			delete iInfo;
			this->indexMng->fileIndexTable->closeScanIndex();
			return false;
		}

		for (short i = 0 ; i < nodeToInsert->getAttributeNumber() ; i++){
			if(iInfo->indexType == STRING_INDEX){

				keyChar = new char[strlen(nodeToInsert->getAttrAt(i)->getStrValue())+1];
				strcpy(keyChar,nodeToInsert->getAttrAt(i)->getStrValue());

				//add attrval + attrkey
				lnode = new ListNode();
				lnode->SetStartPos(nodeToInsert->getKey());
				lnode->SetEndPos(nodeToInsert->getEndKey());
				lnode->SetLevel(nodeToInsert->getLevel());
				ret = index->insert(keyChar,(int)(strlen((char *)keyChar))+1,lnode,sizeof(ListNode));

				if (ret != RCOKGist) {
					globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"IndexIncrementalUpdate::attributeNodeInsertion",__FILE__,"Cannot insert an entry from the gist index file.");
					delete indexName;
					delete iInfo;
					delete lnode;
					delete keyChar;
					index->close();
					this->indexMng->fileIndexTable->closeScanIndex();
					return false;
				}
				delete lnode;
				delete keyChar;
			}
			else if (iInfo->indexType == INT_INDEX){

				//add attrval + attrkey
				keyInt = atoi(nodeToInsert->getAttrAt(i)->getStrValue());

				lnode = new ListNode();
				lnode->SetStartPos(nodeToInsert->getKey());
				lnode->SetEndPos(nodeToInsert->getEndKey());
				lnode->SetLevel(nodeToInsert->getLevel());
				ret = index->insert(&keyInt,sizeof(int),lnode,sizeof(ListNode));

				if (ret != RCOKGist) {
					globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"IndexIncrementalUpdate::attributeNodeInsertion",__FILE__,"Cannot insert an entry from the gist index file.");
					delete indexName;
					delete iInfo;
					delete lnode;
					index->close();
					this->indexMng->fileIndexTable->closeScanIndex();
					return false;
				}
				delete lnode;

			}
			else if (iInfo->indexType == FLOAT_INDEX){
				//add attrval + attrkey
				keyFloat = (float)atof(nodeToInsert->getAttrAt(i)->getStrValue());

				lnode = new ListNode();
				lnode->SetStartPos(nodeToInsert->getKey());
				lnode->SetEndPos(nodeToInsert->getEndKey());
				lnode->SetLevel(nodeToInsert->getLevel());
				ret = index->insert(&keyFloat,sizeof(float),lnode,sizeof(ListNode));

				if (ret != RCOKGist) {
					globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"IndexIncrementalUpdate::attributeNodeInsertion",__FILE__,"Cannot insert an entry from the gist index file.");
					delete indexName;
					delete iInfo;
					delete lnode;
					index->close();
					this->indexMng->fileIndexTable->closeScanIndex();
					return false;
				}
				delete lnode;

			}
			else if (iInfo->indexType == DOUBLE_INDEX){
				//add attrval + attrkey
				keyDouble = (double)atof(nodeToInsert->getAttrAt(i)->getStrValue());

				lnode = new ListNode();
				lnode->SetStartPos(nodeToInsert->getKey());
				lnode->SetEndPos(nodeToInsert->getEndKey());
				lnode->SetLevel(nodeToInsert->getLevel());
				ret = index->insert(&keyDouble,sizeof(double),lnode,sizeof(ListNode));

				if (ret != RCOKGist) {
					globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"IndexIncrementalUpdate::attributeNodeInsertion",__FILE__,"Cannot insert an entry from the gist index file.");
					delete indexName;
					delete iInfo;
					delete lnode;
					index->close();
					this->indexMng->fileIndexTable->closeScanIndex();
					return false;
				}
				delete lnode;

			}
		}//for all attribute name
		index->close();
		delete indexName;
	}
	break;
case VALUEINDEX_ATTRIBUTECONTENT:
	{

		//get parent data node if the pointer passed is null
		if (parentNode == NULL) {
			getParentNode = true;
			parentNode = (DM_ElementNode*)this->indexMng->pDataMng->fetchDataNodeFromDBFile((const FileInfoType)*fileinfo,parentKey);
			if (parentNode == NULL) {
				globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"IndexIncrementalUpdate::nodeDeletion",__FILE__,"Parent cannot be fetched by the key given.");
				return false;
			}
		}
		for(short i = 0 ; i < nodeToInsert->getAttributeNumber(); i++)
		{
			Value* attrnameval =  new Value(STRING_VALUE,nodeToInsert->getAttributeNameAt(i));
			//if the index is built on this attrname, add key
			SelectionCondition* idxcond = new SelectionCondition(iInfo->selectionCondition);
			PredicateCondition* idxpred = idxcond->getCondition()->getCondAt(0)->getCondAt(0);

			if (!idxpred->getRightValue()->compareValue(VALUE_COMP_OP_EQ,attrnameval)) {
				//if attrname built != this attrname, ignore this attrname
				delete idxcond;
				delete attrnameval;
				continue;
			}

			delete idxcond;
			delete attrnameval;

			//get index name concat with path, and open it
			indexName = new char[strlen(this->indexNamePath) + strlen(iInfo->indexName) + 1];
			strcpy(indexName,this->indexNamePath);
			strcpy(indexName + strlen(this->indexNamePath), iInfo->indexName);


			ret = index->open(indexName);
			if (ret != RCOKGist) {
				globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"IndexIncrementalUpdate::attributeNodeInsertion",__FILE__,"Cannot open gist index file.");
				delete indexName;
				delete iInfo;
				this->indexMng->fileIndexTable->closeScanIndex();
				return false;
			}

			if(iInfo->indexType == STRING_INDEX){
				//add attr value + elem key
				keyChar = new char[strlen(nodeToInsert->getAttrAt(i)->getStrValue())+1];
				strcpy(keyChar,nodeToInsert->getAttrAt(i)->getStrValue());

				lnode = new ListNode();
				lnode->SetStartPos(parentNode->getKey());
				lnode->SetEndPos(parentNode->getEndKey());
				lnode->SetLevel(parentNode->getLevel());
				ret = index->insert(keyChar,(int)(strlen((char *)keyChar))+1,lnode,sizeof(ListNode));

				if (ret != RCOKGist) {
					globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"IndexIncrementalUpdate::attributeNodeInsertion",__FILE__,"Cannot insert an entry from the gist index file.");
					delete indexName;
					delete iInfo;
					delete lnode;
					delete keyChar;
					index->close();
					this->indexMng->fileIndexTable->closeScanIndex();
					return false;
				}
				delete lnode;
				delete keyChar;
			}
			else if (iInfo->indexType == INT_INDEX) {
				//add attr value + elem key
				keyInt = atoi(nodeToInsert->getAttrAt(i)->getStrValue());

				lnode = new ListNode();
				lnode->SetStartPos(parentNode->getKey());
				lnode->SetEndPos(parentNode->getEndKey());
				lnode->SetLevel(parentNode->getLevel());
				ret = index->insert(&keyInt,sizeof(int),lnode,sizeof(ListNode));

				if (ret != RCOKGist) {
					globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"IndexIncrementalUpdate::attributeNodeInsertion",__FILE__,"Cannot insert an entry from the gist index file.");
					delete indexName;
					delete iInfo;
					delete lnode;
					index->close();
					this->indexMng->fileIndexTable->closeScanIndex();
					return false;
				}
				delete lnode;

			}
			else if (iInfo->indexType == FLOAT_INDEX) {
				//add attr value + elem key
				keyFloat = (float)atof(nodeToInsert->getAttrAt(i)->getStrValue());

				lnode = new ListNode();
				lnode->SetStartPos(parentNode->getKey());
				lnode->SetEndPos(parentNode->getEndKey());
				lnode->SetLevel(parentNode->getLevel());
				ret = index->insert(&keyFloat,sizeof(float),lnode,sizeof(ListNode));

				if (ret != RCOKGist) {
					globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"IndexIncrementalUpdate::attributeNodeInsertion",__FILE__,"Cannot insert an entry from the gist index file.");
					delete indexName;
					delete iInfo;
					delete lnode;
					index->close();
					this->indexMng->fileIndexTable->closeScanIndex();
					return false;
				}
				delete lnode;

			}
			else if (iInfo->indexType == DOUBLE_INDEX) {
				//add attr value + elem key
				keyDouble = (double)atof(nodeToInsert->getAttrAt(i)->getStrValue());

				lnode = new ListNode();
				lnode->SetStartPos(parentNode->getKey());
				lnode->SetEndPos(parentNode->getEndKey());
				lnode->SetLevel(parentNode->getLevel());
				ret = index->insert(&keyDouble,sizeof(double),lnode,sizeof(ListNode));

				if (ret != RCOKGist) {
					globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"IndexIncrementalUpdate::attributeNodeInsertion",__FILE__,"Cannot insert an entry from the gist index file.");
					delete indexName;
					delete lnode;			
					delete iInfo;
					index->close();
					this->indexMng->fileIndexTable->closeScanIndex();
					return false;
				}
				delete lnode;

			}

			index->close();
			delete indexName;
			break; //an index should match only one, and done
		}//for all attribute 
		if (getParentNode) delete parentNode;
	}
	break;
case JOININDEX:
	{
		if ((iInfo->leftSideType == JOININDEX_ATTRIBUTECONTENT) ||
			(iInfo->rightSideType == JOININDEX_ATTRIBUTECONTENT) |
			(iInfo->leftSideType == JOININDEX_ATTRIBUTEVALUE) ||
			(iInfo->rightSideType == JOININDEX_ATTRIBUTEVALUE)) 
		{
			if ((iInfo->leftSideType == JOININDEX_ATTRIBUTECONTENT) || 
				(iInfo->leftSideType == JOININDEX_ATTRIBUTEVALUE))
			{
				//check whether one of the attribute name from node inserted is the left side
				for (short i = 0 ; i < nodeToInsert->getAttributeNumber() ; i++)
				{
					if (strcmp(iInfo->leftSide,nodeToInsert->getAttributeNameAt(i)) == 0){
						//not support, and inefficient to update the join index for this case
						globalErrorInfo.insertProblem(ERR_TYPE_WARNING,__LINE__,"IndexIncrementalUpdate::attributeNodeInsertion",__FILE__,"Some of join indices are not supported to the update. Please rebuild accordingly");  
						cout << "Please drop and rebuild join index: " << iInfo->indexName  << endl;
						break;
					}
				}
			}

			if ((iInfo->rightSideType == JOININDEX_ATTRIBUTECONTENT) ||
				(iInfo->rightSideType == JOININDEX_ATTRIBUTEVALUE))
			{
				//check whether one of the attribute name from node inserted is the right side
				for (short i = 0 ; i < nodeToInsert->getAttributeNumber() ; i++)
				{
					if (strcmp(iInfo->rightSide,nodeToInsert->getAttributeNameAt(i)) == 0){
						//not support, and inefficient to update the join index for this case
						globalErrorInfo.insertProblem(ERR_TYPE_WARNING,__LINE__,"IndexIncrementalUpdate::attributeNodeInsertion",__FILE__,"Some of join indices are not supported to the update. Please rebuild accordingly");  
						cout << "Please drop and rebuild join index: " << iInfo->indexName  << endl;
						break;
					}
				}
			}

		} //if 4
	}
	break;
default:
	break;
		} //switch
		getParentNode = false;
		delete iInfo;
	}//while scan fileindex
	this->indexMng->fileIndexTable->closeScanIndex();
	return true;
}

/**
* Process Method
*
* Perform relevant incremental index update in case of attribute deletion
*
* @param fileinfo The file info type of the xml file to perform incremental index update
* @param parentNode The data node pointer of the parent
* @param attributeKey The attribute key of that to be deleted its attribute name, data
* @param attributeName The string contains attributename to be deleted
* @param attributeValue The value of the attribute value to be deleted in Value type
* @return Whether it has any errors.
*/
bool IndexIncrementalUpdate::attributeDeletion(FileInfoType* fileinfo, DM_ElementNode* parentNode, KeyType attributeKey, char* attributeName, Value* attributeValue) 
{
	IndexInfoType *iInfo;
	ListNode* lnode;
	bt_query_t* qDel;
	int keyInt;
	float keyFloat;
	double keyDouble;
	char* keyChar;
	char* indexName;
	rc_tGist ret;
	
	//scan for all concerned indices
	this->indexMng->fileIndexTable->startScanIndex(fileinfo->key);
	while ((iInfo = this->indexMng->fileIndexTable->getNextIndexInfo()) != NULL) {

		switch (iInfo->indexDescription) {

case VALUEINDEX_ATTRIBUTENAME:
	{
		//get index name concat with path, and open it
		indexName = new char[strlen(this->indexNamePath) + strlen(iInfo->indexName) + 1];
		strcpy(indexName,this->indexNamePath);
		strcpy(indexName + strlen(this->indexNamePath), iInfo->indexName);


		ret = index->open(indexName);
		if (ret != RCOKGist) {
			globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"IndexIncrementalUpdate::attributeDeletion",__FILE__,"Cannot open gist index file.");
			delete indexName;
			delete iInfo;
			this->indexMng->fileIndexTable->closeScanIndex();
			return false;
		}


		//remove
		keyChar = new char[strlen(attributeName)+1];
		strcpy(keyChar,attributeName);

		lnode = new ListNode();
		lnode->SetStartPos(attributeKey);
		lnode->SetEndPos(attributeKey);
		lnode->SetLevel(parentNode->getLevel()+1);
		qDel = new bt_query_t(bt_query_t::bt_eq,keyChar,NULL,lnode,NULL);
		ret = index->remove(qDel);

		if (ret != RCOKGist) {
			globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"IndexIncrementalUpdate::attributeDeletion",__FILE__,"Cannot remove an entry from the gist index file.");
			delete indexName;
			delete qDel;
			delete iInfo;
			index->close();
			this->indexMng->fileIndexTable->closeScanIndex();
			return false;
		}
		delete qDel;
		index->close();
		delete indexName;
	}
	break;
case VALUEINDEX_ATTRIBUTENAME_ID_PAIR:
	{
		//get index name concat with path, and open it
		indexName = new char[strlen(this->indexNamePath) + strlen(iInfo->indexName) + 1];
		strcpy(indexName,this->indexNamePath);
		strcpy(indexName + strlen(this->indexNamePath), iInfo->indexName);

		ret = index->open(indexName);
		if (ret != RCOKGist) {
			globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"IndexIncrementalUpdate::attributeDeletion",__FILE__,"Cannot open gist index file.");
			delete indexName;
			delete iInfo;
			this->indexMng->fileIndexTable->closeScanIndex();
			return false;
		}
		tagIdIndex = new TagNameAndNodeIdIndex();

		//remove attrname + attribute node key
		bool tRet = this->tagIdIndex->deleteNode(attributeName,attributeKey.toDouble(),index);

		if (tRet != true) {
			globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"IndexIncrementalUpdate::attributeDeletion",__FILE__,"Cannot remove an entry from the gist index file.");
			delete indexName;
			delete iInfo;
			delete tagIdIndex;
			index->close();
			this->indexMng->fileIndexTable->closeScanIndex();
			return false;
		}


		delete tagIdIndex;
		index->close();
		delete indexName;
	}
	break;
case VALUEINDEX_ATTRIBUTEVALUE:
	{
		//get index name concat with path, and open it
		indexName = new char[strlen(this->indexNamePath) + strlen(iInfo->indexName) + 1];
		strcpy(indexName,this->indexNamePath);
		strcpy(indexName + strlen(this->indexNamePath), iInfo->indexName);

		ret = index->open(indexName);
		if (ret != RCOKGist) {
			globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"IndexIncrementalUpdate::attributeDeletion",__FILE__,"Cannot open gist index file.");
			delete indexName;
			delete iInfo;
			this->indexMng->fileIndexTable->closeScanIndex();
			return false;
		}


		if(iInfo->indexType == STRING_INDEX){
			//remove attrvalue + attribute node key
			keyChar = new char[strlen(attributeValue->getStrValue())+1];
			strcpy(keyChar,attributeValue->getStrValue());

			lnode = new ListNode();
			lnode->SetStartPos(attributeKey);
			lnode->SetEndPos(attributeKey);
			lnode->SetLevel(parentNode->getLevel()+1);
			qDel = new bt_query_t(bt_query_t::bt_eq,keyChar,NULL,lnode,NULL);
			ret = index->remove(qDel);

			if (ret != RCOKGist) {
				globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"IndexIncrementalUpdate::attributeDeletion",__FILE__,"Cannot remove an entry from the gist index file.");
				delete indexName;
				delete qDel;
				delete iInfo;
				index->close();
				this->indexMng->fileIndexTable->closeScanIndex();
				return false;
			}
			delete qDel;
		}
		else if(iInfo->indexType == INT_INDEX){
			//remove attrvalue + attribute node key
			keyInt = atoi(attributeValue->getStrValue());

			lnode = new ListNode();
			lnode->SetStartPos(attributeKey);
			lnode->SetEndPos(attributeKey);
			lnode->SetLevel(parentNode->getLevel()+1);
			qDel = new bt_query_t(bt_query_t::bt_eq,new int(keyInt),NULL,lnode,NULL);
			ret = index->remove(qDel);

			if (ret != RCOKGist) {
				globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"IndexIncrementalUpdate::attributeDeletion",__FILE__,"Cannot remove an entry from the gist index file.");
				delete indexName;
				delete qDel;
				delete iInfo;
				index->close();
				this->indexMng->fileIndexTable->closeScanIndex();
				return false;
			}
			delete qDel;
		}
		else if(iInfo->indexType == FLOAT_INDEX){
			//remove attrvalue + attribute node key
			keyFloat = (float)atof(attributeValue->getStrValue());

			lnode = new ListNode();
			lnode->SetStartPos(attributeKey);
			lnode->SetEndPos(attributeKey);
			lnode->SetLevel(parentNode->getLevel()+1);
			qDel = new bt_query_t(bt_query_t::bt_eq,new float(keyFloat),NULL,lnode,NULL);
			ret = index->remove(qDel);

			if (ret != RCOKGist) {
				globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"IndexIncrementalUpdate::attributeDeletion",__FILE__,"Cannot remove an entry from the gist index file.");
				delete indexName;
				delete qDel;
				delete iInfo;
				index->close();
				this->indexMng->fileIndexTable->closeScanIndex();
				return false;
			}
			delete qDel;
		}
		else if(iInfo->indexType == DOUBLE_INDEX){
			//remove attrvalue + attribute node key
			keyDouble = (double)atof(attributeValue->getStrValue());

			lnode = new ListNode();
			lnode->SetStartPos(attributeKey);
			lnode->SetEndPos(attributeKey);
			lnode->SetLevel(parentNode->getLevel()+1);
			qDel = new bt_query_t(bt_query_t::bt_eq,new double(keyDouble),NULL,lnode,NULL);
			ret = index->remove(qDel);

			if (ret != RCOKGist) {
				globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"IndexIncrementalUpdate::attributeDeletion",__FILE__,"Cannot remove an entry from the gist index file.");
				delete indexName;
				delete qDel;
				delete iInfo;
				index->close();
				this->indexMng->fileIndexTable->closeScanIndex();
				return false;
			}
			delete qDel;
		}
		
		index->close();
		delete indexName;
	}
	break;
case VALUEINDEX_ATTRIBUTECONTENT:
	{
		//check whether this index is built on this attribute name
		//if not get next indexinfo
		Value* attrnameval =  new Value(STRING_VALUE,attributeName);
		//if the index is built on this attrname, modify key
		SelectionCondition* idxcond = new SelectionCondition(iInfo->selectionCondition);
		PredicateCondition* idxpred = idxcond->getCondition()->getCondAt(0)->getCondAt(0);

		if (!idxpred->getRightValue()->compareValue(VALUE_COMP_OP_EQ,attrnameval)) {
			//if attrname built != this attrname, ignore
			delete idxcond;
			delete attrnameval;
			break;
		}

		delete idxcond;
		delete attrnameval;

		//get index name concat with path, and open it
		indexName = new char[strlen(this->indexNamePath) + strlen(iInfo->indexName) + 1];
		strcpy(indexName,this->indexNamePath);
		strcpy(indexName + strlen(this->indexNamePath), iInfo->indexName);


		ret = index->open(indexName);
		if (ret != RCOKGist) {
			globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"IndexIncrementalUpdate::attributeDeletion",__FILE__,"Cannot open gist index file.");
			delete indexName;
			delete iInfo;
			this->indexMng->fileIndexTable->closeScanIndex();
			return false;
		}

		if(iInfo->indexType == STRING_INDEX){
			//remove attrval + parent element key
			keyChar = new char[strlen(attributeValue->getStrValue())+1];
			strcpy(keyChar,attributeValue->getStrValue());

			lnode = new ListNode();
			lnode->SetStartPos(parentNode->getKey());
			lnode->SetEndPos(parentNode->getEndKey());
			lnode->SetLevel(parentNode->getLevel());
			qDel = new bt_query_t(bt_query_t::bt_eq,keyChar,NULL,lnode,NULL);
			ret = index->remove(qDel);

			if (ret != RCOKGist) {
				globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"IndexIncrementalUpdate::attributeDeletion",__FILE__,"Cannot remove an entry from the gist index file.");
				delete indexName;
				delete qDel;
				delete iInfo;
				index->close();
				this->indexMng->fileIndexTable->closeScanIndex();
				return false;
			}
			delete qDel;

		}
		else if (iInfo->indexType == INT_INDEX) {
			//remove attrval + parent element key
			keyInt = atoi(attributeValue->getStrValue());

			lnode = new ListNode();
			lnode->SetStartPos(parentNode->getKey());
			lnode->SetEndPos(parentNode->getEndKey());
			lnode->SetLevel(parentNode->getLevel());
			qDel = new bt_query_t(bt_query_t::bt_eq,new int(keyInt),NULL,lnode,NULL);
			ret = index->remove(qDel);

			if (ret != RCOKGist) {
				globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"IndexIncrementalUpdate::attributeDeletion",__FILE__,"Cannot remove an entry from the gist index file.");
				delete indexName;
				delete qDel;
				delete iInfo;
				index->close();
				this->indexMng->fileIndexTable->closeScanIndex();
				return false;
			}
			delete qDel;

		}
		else if (iInfo->indexType == FLOAT_INDEX) {
			//remove attrval + parent element key
			keyFloat = (float)atof(attributeValue->getStrValue());

			lnode = new ListNode();
			lnode->SetStartPos(parentNode->getKey());
			lnode->SetEndPos(parentNode->getEndKey());
			lnode->SetLevel(parentNode->getLevel());
			qDel = new bt_query_t(bt_query_t::bt_eq,new float(keyFloat),NULL,lnode,NULL);
			ret = index->remove(qDel);

			if (ret != RCOKGist) {
				globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"IndexIncrementalUpdate::attributeDeletion",__FILE__,"Cannot remove an entry from the gist index file.");
				delete indexName;
				delete qDel;
				delete iInfo;
				index->close();
				this->indexMng->fileIndexTable->closeScanIndex();
				return false;
			}
			delete qDel;

		}
		else if (iInfo->indexType == DOUBLE_INDEX) {
			//remove attrval + parent element key
			keyDouble = (double)atof(attributeValue->getStrValue());

			lnode = new ListNode();
			lnode->SetStartPos(parentNode->getKey());
			lnode->SetEndPos(parentNode->getEndKey());
			lnode->SetLevel(parentNode->getLevel());
			qDel = new bt_query_t(bt_query_t::bt_eq,new double(keyDouble),NULL,lnode,NULL);
			ret = index->remove(qDel);

			if (ret != RCOKGist) {
				globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"IndexIncrementalUpdate::attributeDeletion",__FILE__,"Cannot remove an entry from the gist index file.");
				delete indexName;
				delete qDel;
				delete iInfo;
				index->close();
				this->indexMng->fileIndexTable->closeScanIndex();
				return false;
			}
			delete qDel;
		}

		index->close();
		delete indexName;

	}
	break;
case JOININDEX:
	{
		bool mirror = false, same = false; //whether mirror index exist, and successfully opened for operation
		char* indexName2;
		gist* index2 = new gist;
		//check only if it is left side, since we can retrieve/del the entry only if it's the key (left side)
		//since we assume there will be a mirror index, we will automatically try to update both
		if ((iInfo->leftSideType == JOININDEX_ATTRIBUTECONTENT) ||
			(iInfo->leftSideType == JOININDEX_ATTRIBUTEVALUE)) {
			//try to delete from it the parent key as leftside key (for content type) or attrkey (for value type)

			//check whether left side = this attrname
			if (strcmp(attributeName,iInfo->leftSide) == 0) {
				//get index name concat with path, and open it
				indexName = new char[strlen(this->indexNamePath) + strlen(iInfo->indexName) + 1];
				strcpy(indexName,this->indexNamePath);
				strcpy(indexName + strlen(this->indexNamePath), iInfo->indexName);

				ret = index->open(indexName);
				if (ret != RCOKGist) {
					globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"IndexIncrementalUpdate::attributeDeletion",__FILE__,"Cannot open gist index file.");
					delete indexName;
					delete iInfo;
					this->indexMng->fileIndexTable->closeScanIndex();
					return false;
				}

				//get mirror only if mirror name is different than this name
				char indexMirror[MAX_INDEX_NAME_LENGTH];
				bool rc = this->indexMng->constructIndexName(iInfo->fileName,indexMirror,JOININDEX,NULL,DOUBLE_INDEX,iInfo->rightSide,iInfo->rightSideType,iInfo->leftSide,iInfo->leftSideType);
				if (strcmp(indexMirror,iInfo->indexName) != 0) {
					if (rc && this->indexMng->existIndex(indexMirror)) {
						indexName2 = new char[strlen(this->indexNamePath) + strlen(indexMirror) + 1];
						strcpy(indexName2,this->indexNamePath);
						strcpy(indexName2 + strlen(this->indexNamePath), indexMirror);

						ret = index2->open(indexName2);
						if (ret == RCOKGist) {
							mirror = true;
						}
						delete indexName2;
					}
				}
				else { //ac_id_ac_id
					same = true;
				}

				bt_query_t *qGet, *qDel;
				gist_cursor_t cursor;
				bool eof = false;
				unsigned long keysz, datasz;
				double key;
				ListNode lnode;
				ListNode* lnodeDel;

				if (iInfo->leftSideType == JOININDEX_ATTRIBUTECONTENT)
					qGet = new bt_query_t(bt_query_t::bt_eq,new double(parentNode->getKey().toDouble()),NULL);
				else
					qGet = new bt_query_t(bt_query_t::bt_eq,new double(attributeKey.toDouble()),NULL);

				cursor.k = 0;
				cursor.io = 0;
				cursor.query = NULL;
				cursor.ext = NULL;
				cursor.cext = NULL;
				cursor.iter = NULL;
				cursor.state = NULL;
				index->fetch_init(cursor, qGet);


				//retrieve key,data pair
				while (!eof) {
					ret = index->fetch(cursor, &key, keysz, (void *)&lnode, datasz, eof);
					if (!ret && !eof){

						//if (key != lnode.GetStartPos().toDouble()) {
							//no false positive b/c one attrname only for one attrnode

							lnodeDel = new ListNode(lnode);
							qDel = new bt_query_t(bt_query_t::bt_eq,new double(key),NULL,lnodeDel,NULL);
							ret = index->remove(qDel);
							if (ret != RCOKGist) {
								globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"IndexIncrementalUpdate::attributeDeletion",__FILE__,"Cannot remove an entry from the gist index file.");
								delete indexName;
								delete qDel;
								delete qGet;
								delete iInfo;
								index->close();
								this->indexMng->fileIndexTable->closeScanIndex();
								return false;
							}
							delete qDel;
							//then delete the mirror index if found one
							if (mirror) {
								lnodeDel = new ListNode();
								if (iInfo->leftSideType == JOININDEX_ATTRIBUTECONTENT) {
									lnodeDel->SetStartPos(parentNode->getKey());
									lnodeDel->SetEndPos(parentNode->getEndKey());
									lnodeDel->SetLevel(parentNode->getLevel());
								}
								else {
									lnodeDel->SetStartPos(attributeKey);
									lnodeDel->SetEndPos(attributeKey);
									lnodeDel->SetLevel(parentNode->getLevel()+1);
								}
								qDel = new bt_query_t(bt_query_t::bt_eq,new double(lnode.GetStartPos().toDouble()),NULL,lnodeDel,NULL);
								ret = index2->remove(qDel);
								if (ret != RCOKGist) {
									globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"IndexIncrementalUpdate::attributeDeletion",__FILE__,"Cannot remove an entry from the gist index file.");
									delete indexName;
									delete qDel;
									delete qGet;
									delete iInfo;
									index->close();
									index2->close();
									this->indexMng->fileIndexTable->closeScanIndex();
									return false;
								}
								delete qDel;
							}
							else if (same) { 
								//if ac_id_ac_id, do not need another opened index, b/c it's the same file
								//we want to delete lnode -> key (which is different)
								//for lnode = key , it fall in the below else clause
								lnodeDel = new ListNode();
								if (iInfo->leftSideType == JOININDEX_ATTRIBUTECONTENT) {
									lnodeDel->SetStartPos(parentNode->getKey());
									lnodeDel->SetEndPos(parentNode->getEndKey());
									lnodeDel->SetLevel(parentNode->getLevel());
								}
								else {
									lnodeDel->SetStartPos(attributeKey);
									lnodeDel->SetEndPos(attributeKey);
									lnodeDel->SetLevel(parentNode->getLevel());
								}
								qDel = new bt_query_t(bt_query_t::bt_eq,new double(lnode.GetStartPos().toDouble()),NULL,lnodeDel,NULL);
								ret = index->remove(qDel);
								if (ret != RCOKGist) {
									globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"IndexIncrementalUpdate::attributeDeletion",__FILE__,"Cannot remove an entry from the gist index file.");
									delete indexName;
									delete qDel;
									delete qGet;
									delete iInfo;
									index->close();
									this->indexMng->fileIndexTable->closeScanIndex();
									return false;
								}
								delete qDel;
							}
						//} // if (key != data.key)
						/*else { //key == data.key, usually in case of joining itself
							lnodeDel = new ListNode(lnode);
							qDel = new bt_query_t(bt_query_t::bt_eq,new double(key),NULL,lnodeDel,NULL);
							ret = index->remove(qDel);
							if (ret != RCOKGist) {
								globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"IndexIncrementalUpdate::attributeDeletion",__FILE__,"Cannot remove an entry from the gist index file.");
								delete indexName;
								delete qDel;
								delete qGet;
								delete iInfo;
								index->close();
								this->indexMng->fileIndexTable->closeScanIndex();
								return false;
							}
							delete qDel;
						}*/
					}//if (!ret && !eof)
				} //while !eof
				delete qGet;
				index->close();
				if (mirror){
					index2->close();
					delete index2;
				}
			} // strcmp(attributeName,iInfo->leftSide) == 0

		}
	}
	break;
default:
	break;
		} //switch

		delete iInfo;
	}//while scan fileindex
	this->indexMng->fileIndexTable->closeScanIndex();
	return true;
}

/**
* Process Method
*
* Perform relevant incremental index update in case of attribute insertion
*
* @param fileinfo The file info type of the xml file to perform incremental index update
* @param parentNode The data node pointer of the parent
* @param attributeKey The attribute key of that to be inserted its attribute name, data
* @param attributeName The string contains attributename to be inserted
* @param attributeValue The value of the attribute value to be inserted in Value type
* @return Whether it has any errors.
*/
bool IndexIncrementalUpdate::attributeInsertion(FileInfoType* fileinfo, DM_ElementNode* parentNode, KeyType attributeKey, char* attributeName, Value* attributeValue) 
{
	IndexInfoType *iInfo;
	ListNode* lnode;
	int keyInt;
	float keyFloat;
	double keyDouble;
	char* keyChar;
	char* indexName;
	rc_tGist ret;
	
	//scan for all concerned indices
	this->indexMng->fileIndexTable->startScanIndex(fileinfo->key);
	while ((iInfo = this->indexMng->fileIndexTable->getNextIndexInfo()) != NULL) {

		switch (iInfo->indexDescription) {

case VALUEINDEX_ATTRIBUTENAME:
	{
		//get index name concat with path, and open it
		indexName = new char[strlen(this->indexNamePath) + strlen(iInfo->indexName) + 1];
		strcpy(indexName,this->indexNamePath);
		strcpy(indexName + strlen(this->indexNamePath), iInfo->indexName);


		ret = index->open(indexName);
		if (ret != RCOKGist) {
			globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"IndexIncrementalUpdate::attributeInsertion",__FILE__,"Cannot open gist index file.");
			delete indexName;
			delete iInfo;
			this->indexMng->fileIndexTable->closeScanIndex();
			return false;
		}


		//add attrname+ key
		keyChar = new char[strlen(attributeName)+1];
		strcpy(keyChar,attributeName);

		lnode = new ListNode();
		lnode->SetStartPos(attributeKey);
		lnode->SetEndPos(attributeKey);
		lnode->SetLevel(parentNode->getLevel()+1);
		ret = index->insert(keyChar,(int)(strlen((char *)keyChar))+1,lnode,sizeof(ListNode));

		if (ret != RCOKGist) {
			globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"IndexIncrementalUpdate::attributeInsertion",__FILE__,"Cannot insert an entry from the gist index file.");
			delete indexName;
			delete iInfo;
			delete lnode;
			delete keyChar;
			index->close();
			this->indexMng->fileIndexTable->closeScanIndex();
			return false;
		}

		delete lnode;
		delete keyChar;
		index->close();
		delete indexName;
	}
	break;
case VALUEINDEX_ATTRIBUTENAME_ID_PAIR:
	{
		//get index name concat with path, and open it
		indexName = new char[strlen(this->indexNamePath) + strlen(iInfo->indexName) + 1];
		strcpy(indexName,this->indexNamePath);
		strcpy(indexName + strlen(this->indexNamePath), iInfo->indexName);

		ret = index->open(indexName);
		if (ret != RCOKGist) {
			globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"IndexIncrementalUpdate::attributeInsertion",__FILE__,"Cannot open gist index file.");
			delete indexName;
			delete iInfo;
			this->indexMng->fileIndexTable->closeScanIndex();
			return false;
		}
		tagIdIndex = new TagNameAndNodeIdIndex();

		lnode = new ListNode();
		lnode->SetStartPos(attributeKey);
		lnode->SetEndPos(attributeKey);
		lnode->SetLevel(parentNode->getLevel()+1);

		//remove attrname + attribute node key
		bool tRet = this->tagIdIndex->insertNode(attributeName,attributeKey.toDouble(),lnode,sizeof(ListNode),index);

		if (tRet != true) {
			globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"IndexIncrementalUpdate::attributeInsertion",__FILE__,"Cannot remove an entry from the gist index file.");
			delete indexName;
			delete iInfo;
			delete lnode;
			delete tagIdIndex;
			index->close();
			this->indexMng->fileIndexTable->closeScanIndex();
			return false;
		}
		delete lnode;
		delete tagIdIndex;
		index->close();
		delete indexName;
	}
	break;
case VALUEINDEX_ATTRIBUTEVALUE:
	{
		//get index name concat with path, and open it
		indexName = new char[strlen(this->indexNamePath) + strlen(iInfo->indexName) + 1];
		strcpy(indexName,this->indexNamePath);
		strcpy(indexName + strlen(this->indexNamePath), iInfo->indexName);


		ret = index->open(indexName);
		if (ret != RCOKGist) {
			globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"IndexIncrementalUpdate::attributeInsertion",__FILE__,"Cannot open gist index file.");
			delete indexName;
			delete iInfo;
			this->indexMng->fileIndexTable->closeScanIndex();
			return false;
		}

		if(iInfo->indexType == STRING_INDEX){

			keyChar = new char[strlen(attributeValue->getStrValue())+1];
			strcpy(keyChar,attributeValue->getStrValue());

			//add attrval + attrkey
			lnode = new ListNode();
			lnode->SetStartPos(attributeKey);
			lnode->SetEndPos(attributeKey);
			lnode->SetLevel(parentNode->getLevel()+1);
			ret = index->insert(keyChar,(int)(strlen((char *)keyChar))+1,lnode,sizeof(ListNode));

			if (ret != RCOKGist) {
				globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"IndexIncrementalUpdate::attributeInsertion",__FILE__,"Cannot insert an entry from the gist index file.");
				delete indexName;
				delete iInfo;
				delete lnode;
				delete keyChar;
				index->close();
				this->indexMng->fileIndexTable->closeScanIndex();
				return false;
			}
			delete lnode;
			delete keyChar;
		}
		else if (iInfo->indexType == INT_INDEX){

			//add attrval + attrkey
			keyInt = atoi(attributeValue->getStrValue());

			lnode = new ListNode();
			lnode->SetStartPos(attributeKey);
			lnode->SetEndPos(attributeKey);
			lnode->SetLevel(parentNode->getLevel()+1);
			ret = index->insert(&keyInt,sizeof(int),lnode,sizeof(ListNode));

			if (ret != RCOKGist) {
				globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"IndexIncrementalUpdate::attributeInsertion",__FILE__,"Cannot insert an entry from the gist index file.");
				delete indexName;
				delete iInfo;
				delete lnode;
				index->close();
				this->indexMng->fileIndexTable->closeScanIndex();
				return false;
			}
			delete lnode;

		}
		else if (iInfo->indexType == FLOAT_INDEX){
			//add attrval + attrkey
			keyFloat = (float)atof(attributeValue->getStrValue());

			lnode = new ListNode();
			lnode->SetStartPos(attributeKey);
			lnode->SetEndPos(attributeKey);
			lnode->SetLevel(parentNode->getLevel()+1);
			ret = index->insert(&keyFloat,sizeof(float),lnode,sizeof(ListNode));

			if (ret != RCOKGist) {
				globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"IndexIncrementalUpdate::attributeInsertion",__FILE__,"Cannot insert an entry from the gist index file.");
				delete indexName;
				delete lnode;
				delete iInfo;
				index->close();
				this->indexMng->fileIndexTable->closeScanIndex();
				return false;
			}
			delete lnode;

		}
		else if (iInfo->indexType == DOUBLE_INDEX){
			//add attrval + attrkey
			keyDouble = (double)atof(attributeValue->getStrValue());

			lnode = new ListNode();
			lnode->SetStartPos(attributeKey);
			lnode->SetEndPos(attributeKey);
			lnode->SetLevel(parentNode->getLevel()+1);
			ret = index->insert(&keyDouble,sizeof(double),lnode,sizeof(ListNode));

			if (ret != RCOKGist) {
				globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"IndexIncrementalUpdate::attributeInsertion",__FILE__,"Cannot insert an entry from the gist index file.");
				delete indexName;
				delete iInfo;
				delete lnode;
				index->close();
				this->indexMng->fileIndexTable->closeScanIndex();
				return false;
			}
			delete lnode;

		}
		index->close();
		delete indexName;
	}
	break;
case VALUEINDEX_ATTRIBUTECONTENT:
	{
		Value* attrnameval =  new Value(STRING_VALUE,attributeName);
		//if the index is built on this attrname, add key
		SelectionCondition* idxcond = new SelectionCondition(iInfo->selectionCondition);
		PredicateCondition* idxpred = idxcond->getCondition()->getCondAt(0)->getCondAt(0);

		if (!idxpred->getRightValue()->compareValue(VALUE_COMP_OP_EQ,attrnameval)) {
			//if attrname built != this attrname, ignore this index
			delete idxcond;
			delete attrnameval;
			break;
		}

		delete idxcond;
		delete attrnameval;

		//get index name concat with path, and open it
		indexName = new char[strlen(this->indexNamePath) + strlen(iInfo->indexName) + 1];
		strcpy(indexName,this->indexNamePath);
		strcpy(indexName + strlen(this->indexNamePath), iInfo->indexName);


		ret = index->open(indexName);
		if (ret != RCOKGist) {
			globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"IndexIncrementalUpdate::attributeInsertion",__FILE__,"Cannot open gist index file.");
			delete indexName;
			delete iInfo;
			this->indexMng->fileIndexTable->closeScanIndex();
			return false;
		}

		if(iInfo->indexType == STRING_INDEX){
			//add attr value + elem key
			keyChar = new char[strlen(attributeValue->getStrValue())+1];
			strcpy(keyChar,attributeValue->getStrValue());

			lnode = new ListNode();
			lnode->SetStartPos(parentNode->getKey());
			lnode->SetEndPos(parentNode->getEndKey());
			lnode->SetLevel(parentNode->getLevel());
			ret = index->insert(keyChar,(int)(strlen((char *)keyChar))+1,lnode,sizeof(ListNode));

			if (ret != RCOKGist) {
				globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"IndexIncrementalUpdate::attributeInsertion",__FILE__,"Cannot insert an entry from the gist index file.");
				delete indexName;
				delete iInfo;
				delete keyChar;
				delete lnode;
				index->close();
				this->indexMng->fileIndexTable->closeScanIndex();
				return false;
			}
			delete lnode;
			delete keyChar;
		}
		else if (iInfo->indexType == INT_INDEX) {
			//add attr value + elem key
			keyInt = atoi(attributeValue->getStrValue());

			lnode = new ListNode();
			lnode->SetStartPos(parentNode->getKey());
			lnode->SetEndPos(parentNode->getEndKey());
			lnode->SetLevel(parentNode->getLevel());
			ret = index->insert(&keyInt,sizeof(int),lnode,sizeof(ListNode));

			if (ret != RCOKGist) {
				globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"IndexIncrementalUpdate::attributeInsertion",__FILE__,"Cannot insert an entry from the gist index file.");
				delete indexName;
				delete iInfo;
				delete lnode;
				index->close();
				this->indexMng->fileIndexTable->closeScanIndex();
				return false;
			}
			delete lnode;
			
		}
		else if (iInfo->indexType == FLOAT_INDEX) {
			//add attr value + elem key
			keyFloat = (float)atof(attributeValue->getStrValue());

			lnode = new ListNode();
			lnode->SetStartPos(parentNode->getKey());
			lnode->SetEndPos(parentNode->getEndKey());
			lnode->SetLevel(parentNode->getLevel());
			ret = index->insert(&keyFloat,sizeof(float),lnode,sizeof(ListNode));

			if (ret != RCOKGist) {
				globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"IndexIncrementalUpdate::attributeInsertion",__FILE__,"Cannot insert an entry from the gist index file.");
				delete indexName;
				delete iInfo;
				delete lnode;
				index->close();
				this->indexMng->fileIndexTable->closeScanIndex();
				return false;
			}
			delete lnode;

		}
		else if (iInfo->indexType == DOUBLE_INDEX) {
			//add attr value + elem key
			keyDouble = (double)atof(attributeValue->getStrValue());

			lnode = new ListNode();
			lnode->SetStartPos(parentNode->getKey());
			lnode->SetEndPos(parentNode->getEndKey());
			lnode->SetLevel(parentNode->getLevel());
			ret = index->insert(&keyDouble,sizeof(double),lnode,sizeof(ListNode));

			if (ret != RCOKGist) {
				globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"IndexIncrementalUpdate::attributeInsertion",__FILE__,"Cannot insert an entry from the gist index file.");
				delete indexName;
				delete iInfo;
				delete lnode;
				index->close();
				this->indexMng->fileIndexTable->closeScanIndex();
				return false;
			}
			delete lnode;
			
		}

		index->close();
		delete indexName;
	}
	break;
case JOININDEX:
	{
		if ((iInfo->leftSideType == JOININDEX_ATTRIBUTECONTENT) ||
			(iInfo->rightSideType == JOININDEX_ATTRIBUTECONTENT) |
			(iInfo->leftSideType == JOININDEX_ATTRIBUTEVALUE) ||
			(iInfo->rightSideType == JOININDEX_ATTRIBUTEVALUE)) 
		{
			if ((iInfo->leftSideType == JOININDEX_ATTRIBUTECONTENT) || 
				(iInfo->leftSideType == JOININDEX_ATTRIBUTEVALUE))
			{
				//check whether the attribute name inserted is the left side
				if (strcmp(iInfo->leftSide,attributeName) == 0){
					//not support, and inefficient to update the join index for this case
					globalErrorInfo.insertProblem(ERR_TYPE_WARNING,__LINE__,"IndexIncrementalUpdate::attributeInsertion",__FILE__,"Some of join indices are not supported to the update. Please rebuild accordingly");  
					cout << "Please drop and rebuild join index: " << iInfo->indexName  << endl;

					break;
				}

			}

			if ((iInfo->rightSideType == JOININDEX_ATTRIBUTECONTENT) ||
				(iInfo->rightSideType == JOININDEX_ATTRIBUTEVALUE))
			{
				//check whether the attribute name inserted is the right side
				if (strcmp(iInfo->rightSide,attributeName) == 0){
					//not support, and inefficient to update the join index for this case
					globalErrorInfo.insertProblem(ERR_TYPE_WARNING,__LINE__,"IndexIncrementalUpdate::attributeInsertion",__FILE__,"Some of join indices are not supported to the update. Please rebuild accordingly");  
					cout << "Please drop and rebuild join index: " << iInfo->indexName  << endl;
					break;
				}
			}

		} //if 4
	}
	break;
default:
	break;
		} //switch

		delete iInfo;
	}//while scan fileindex
	this->indexMng->fileIndexTable->closeScanIndex();
	return true;
}

/**
* Process Method
*
* Perform relevant incremental index update in case of attribute value modification of a particular attribute name
*
* @param fileinfo The file info type of the xml file to perform incremental index update
* @param parentNode The data node pointer of the parent
* @param attributeKey The attribute key of that to be modified its attribute value
* @param attributeName The string contains attributename
* @param oldAttributeValue The old value of the attribute value
* @param newAttributeValue The new value of the attribute value
* @return Whether it has any errors.
*/
bool IndexIncrementalUpdate::attributeValueModification(FileInfoType* fileinfo, DM_ElementNode* parentNode, KeyType attributeKey, char* attributeName, Value* oldAttributeValue, Value* newAttributeValue) 
{ 
	IndexInfoType *iInfo;
	ListNode* lnode;
	bt_query_t* qDel;
	int keyInt;
	float keyFloat;
	double keyDouble;
	char* keyChar;
	char* indexName;
	rc_tGist ret;
	
	//scan for all concerned indices
	this->indexMng->fileIndexTable->startScanIndex(fileinfo->key);
	while ((iInfo = this->indexMng->fileIndexTable->getNextIndexInfo()) != NULL) {

		switch (iInfo->indexDescription) {

case VALUEINDEX_ATTRIBUTEVALUE:
	{
		//get index name concat with path, and open it
		indexName = new char[strlen(this->indexNamePath) + strlen(iInfo->indexName) + 1];
		strcpy(indexName,this->indexNamePath);
		strcpy(indexName + strlen(this->indexNamePath), iInfo->indexName);


		ret = index->open(indexName);
		if (ret != RCOKGist) {
			globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"IndexIncrementalUpdate::attributeValueModification",__FILE__,"Cannot open gist index file.");
			delete indexName;
			delete iInfo;
			this->indexMng->fileIndexTable->closeScanIndex();
			return false;
		}

		if(iInfo->indexType == STRING_INDEX){

			//remove attrvalue
			keyChar = new char[strlen(oldAttributeValue->getStrValue())+1];
			strcpy(keyChar,oldAttributeValue->getStrValue());

			lnode = new ListNode();
			lnode->SetStartPos(attributeKey);
			lnode->SetEndPos(attributeKey);
			lnode->SetLevel(parentNode->getLevel()+1);
			qDel = new bt_query_t(bt_query_t::bt_eq,keyChar,NULL,lnode,NULL);
			ret = index->remove(qDel);

			if (ret != RCOKGist) {
				globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"IndexIncrementalUpdate::attributeValueModification",__FILE__,"Cannot remove an entry from the gist index file.");
				delete indexName;
				delete qDel;
				delete iInfo;
				index->close();
				this->indexMng->fileIndexTable->closeScanIndex();
				return false;
			}

			delete qDel;
			keyChar = new char[strlen(newAttributeValue->getStrValue())+1];
			strcpy(keyChar,newAttributeValue->getStrValue());

			//add new attrvalue + same key
			lnode = new ListNode();
			lnode->SetStartPos(attributeKey);
			lnode->SetEndPos(attributeKey);
			lnode->SetLevel(parentNode->getLevel()+1);
			ret = index->insert(keyChar,(int)(strlen((char *)keyChar))+1,lnode,sizeof(ListNode));

			if (ret != RCOKGist) {
				globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"IndexIncrementalUpdate::attributeValueModification",__FILE__,"Cannot insert an entry from the gist index file.");
				delete indexName;
				delete lnode;
				delete keyChar;
				delete iInfo;
				index->close();
				this->indexMng->fileIndexTable->closeScanIndex();
				return false;
			}

			delete lnode;
			delete keyChar;
		}
		else if (iInfo->indexType == INT_INDEX){
			//remove
			keyInt = atoi(oldAttributeValue->getStrValue());

			lnode = new ListNode();
			lnode->SetStartPos(attributeKey);
			lnode->SetEndPos(attributeKey);
			lnode->SetLevel(parentNode->getLevel()+1);
			qDel = new bt_query_t(bt_query_t::bt_eq,new int(keyInt),NULL,lnode,NULL);
			ret = index->remove(qDel);

			if (ret != RCOKGist) {
				globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"IndexIncrementalUpdate::attributeValueModification",__FILE__,"Cannot remove an entry from the gist index file.");
				delete indexName;
				delete qDel;
				delete iInfo;
				index->close();
				this->indexMng->fileIndexTable->closeScanIndex();
				return false;
			}
			//add new attrval + samekey
			keyInt = atoi(newAttributeValue->getStrValue());
			ret = index->insert(&keyInt,sizeof(int),lnode,sizeof(ListNode));

			if (ret != RCOKGist) {
				globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"IndexIncrementalUpdate::attributeValueModification",__FILE__,"Cannot insert an entry from the gist index file.");
				delete indexName;
				delete qDel;
				delete iInfo;
				index->close();
				this->indexMng->fileIndexTable->closeScanIndex();
				return false;
			}

			delete qDel;
		}
		else if (iInfo->indexType == FLOAT_INDEX){
			//remove
			keyFloat = (float)atof(oldAttributeValue->getStrValue());

			lnode = new ListNode();
			lnode->SetStartPos(attributeKey);
			lnode->SetEndPos(attributeKey);
			lnode->SetLevel(parentNode->getLevel()+1);
			qDel = new bt_query_t(bt_query_t::bt_eq,new float(keyFloat),NULL,lnode,NULL);
			ret = index->remove(qDel);

			if (ret != RCOKGist) {
				globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"IndexIncrementalUpdate::attributeValueModification",__FILE__,"Cannot remove an entry from the gist index file.");
				delete indexName;
				delete qDel;
				delete iInfo;
				index->close();
				this->indexMng->fileIndexTable->closeScanIndex();
				return false;
			}
			//add new attrval + samekey
			keyFloat = (float)atof(newAttributeValue->getStrValue());
			ret = index->insert(&keyFloat,sizeof(float),lnode,sizeof(ListNode));

			if (ret != RCOKGist) {
				globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"IndexIncrementalUpdate::attributeValueModification",__FILE__,"Cannot insert an entry from the gist index file.");
				delete indexName;
				delete qDel;
				delete iInfo;
				index->close();
				this->indexMng->fileIndexTable->closeScanIndex();
				return false;
			}

			delete qDel;
		}
		else if (iInfo->indexType == DOUBLE_INDEX){
			//remove
			keyDouble = (double)atof(oldAttributeValue->getStrValue());

			lnode = new ListNode();
			lnode->SetStartPos(attributeKey);
			lnode->SetEndPos(attributeKey);
			lnode->SetLevel(parentNode->getLevel()+1);
			qDel = new bt_query_t(bt_query_t::bt_eq,new double(keyDouble),NULL,lnode,NULL);
			ret = index->remove(qDel);

			if (ret != RCOKGist) {
				globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"IndexIncrementalUpdate::attributeValueModification",__FILE__,"Cannot remove an entry from the gist index file.");
				delete indexName;
				delete qDel;
				delete iInfo;
				index->close();
				this->indexMng->fileIndexTable->closeScanIndex();
				return false;
			}
			//add new attrval + samekey
			keyDouble = (double)atof(newAttributeValue->getStrValue());
			ret = index->insert(&keyDouble,sizeof(double),lnode,sizeof(ListNode));

			if (ret != RCOKGist) {
				globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"IndexIncrementalUpdate::attributeValueModification",__FILE__,"Cannot insert an entry from the gist index file.");
				delete indexName;
				delete qDel;
				delete iInfo;
				index->close();
				this->indexMng->fileIndexTable->closeScanIndex();
				return false;
			}

			delete qDel;
		}
		index->close();
		delete indexName;
	}
	break;
case VALUEINDEX_ATTRIBUTECONTENT:
	{
		Value* attrnameval =  new Value(STRING_VALUE,attributeName);
		//if the index is built on this attrname, modify key
		SelectionCondition* idxcond = new SelectionCondition(iInfo->selectionCondition);
		PredicateCondition* idxpred = idxcond->getCondition()->getCondAt(0)->getCondAt(0);

		if (!idxpred->getRightValue()->compareValue(VALUE_COMP_OP_EQ,attrnameval)) {
			//if attrname built != this attrname, ignore
			delete idxcond;
			delete attrnameval;
			break;
		}

		delete idxcond;
		delete attrnameval;

		//get index name concat with path, and open it
		indexName = new char[strlen(this->indexNamePath) + strlen(iInfo->indexName) + 1];
		strcpy(indexName,this->indexNamePath);
		strcpy(indexName + strlen(this->indexNamePath), iInfo->indexName);


		ret = index->open(indexName);
		if (ret != RCOKGist) {
			globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"IndexIncrementalUpdate::attributeValueModification",__FILE__,"Cannot open gist index file.");
			delete indexName;
			delete iInfo;
			this->indexMng->fileIndexTable->closeScanIndex();
			return false;
		}

		if(iInfo->indexType == STRING_INDEX){

			//remove attrvalue
			keyChar = new char[strlen(oldAttributeValue->getStrValue())+1];
			strcpy(keyChar,oldAttributeValue->getStrValue());

			lnode = new ListNode();
			lnode->SetStartPos(parentNode->getKey());
			lnode->SetEndPos(parentNode->getEndKey());
			lnode->SetLevel(parentNode->getLevel());
			qDel = new bt_query_t(bt_query_t::bt_eq,keyChar,NULL,lnode,NULL);
			ret = index->remove(qDel);

			if (ret != RCOKGist) {
				globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"IndexIncrementalUpdate::attributeValueModification",__FILE__,"Cannot remove an entry from the gist index file.");
				delete indexName;
				delete qDel;
				delete iInfo;
				index->close();
				this->indexMng->fileIndexTable->closeScanIndex();
				return false;
			}

			delete qDel;
			keyChar = new char[strlen(newAttributeValue->getStrValue())+1];
			strcpy(keyChar,newAttributeValue->getStrValue());

			//add new attrvalue + same key
			lnode = new ListNode();
			lnode->SetStartPos(parentNode->getKey());
			lnode->SetEndPos(parentNode->getEndKey());
			lnode->SetLevel(parentNode->getLevel());
			ret = index->insert(keyChar,(int)(strlen((char *)keyChar))+1,lnode,sizeof(ListNode));

			if (ret != RCOKGist) {
				globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"IndexIncrementalUpdate::attributeValueModification",__FILE__,"Cannot insert an entry from the gist index file.");
				delete indexName;
				delete lnode;
				delete keyChar;
				delete iInfo;
				index->close();
				this->indexMng->fileIndexTable->closeScanIndex();
				return false;
			}

			delete lnode;
			delete keyChar;
		}
		else if (iInfo->indexType == INT_INDEX){
			//remove
			keyInt = atoi(oldAttributeValue->getStrValue());

			lnode = new ListNode();
			lnode->SetStartPos(parentNode->getKey());
			lnode->SetEndPos(parentNode->getEndKey());
			lnode->SetLevel(parentNode->getLevel());
			qDel = new bt_query_t(bt_query_t::bt_eq,new int(keyInt),NULL,lnode,NULL);
			ret = index->remove(qDel);

			if (ret != RCOKGist) {
				globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"IndexIncrementalUpdate::attributeValueModification",__FILE__,"Cannot remove an entry from the gist index file.");
				delete indexName;
				delete qDel;
				delete iInfo;
				index->close();
				this->indexMng->fileIndexTable->closeScanIndex();
				return false;
			}
			//add new attrval + samekey
			keyInt = atoi(newAttributeValue->getStrValue());
			ret = index->insert(&keyInt,sizeof(int),lnode,sizeof(ListNode));

			if (ret != RCOKGist) {
				globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"IndexIncrementalUpdate::attributeValueModification",__FILE__,"Cannot insert an entry from the gist index file.");
				delete indexName;
				delete qDel;
				delete iInfo;
				index->close();
				this->indexMng->fileIndexTable->closeScanIndex();
				return false;
			}

			delete qDel;
		}
		else if (iInfo->indexType == FLOAT_INDEX){
			//remove
			keyFloat = (float)atof(oldAttributeValue->getStrValue());

			lnode = new ListNode();
			lnode->SetStartPos(parentNode->getKey());
			lnode->SetEndPos(parentNode->getEndKey());
			lnode->SetLevel(parentNode->getLevel());
			qDel = new bt_query_t(bt_query_t::bt_eq,new float(keyFloat),NULL,lnode,NULL);
			ret = index->remove(qDel);

			if (ret != RCOKGist) {
				globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"IndexIncrementalUpdate::attributeValueModification",__FILE__,"Cannot remove an entry from the gist index file.");
				delete indexName;
				delete qDel;
				delete iInfo;
				index->close();
				this->indexMng->fileIndexTable->closeScanIndex();
				return false;
			}
			//add new attrval + samekey
			keyFloat = (float)atof(newAttributeValue->getStrValue());
			ret = index->insert(&keyFloat,sizeof(float),lnode,sizeof(ListNode));

			if (ret != RCOKGist) {
				globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"IndexIncrementalUpdate::attributeValueModification",__FILE__,"Cannot insert an entry from the gist index file.");
				delete indexName;
				delete qDel;
				delete iInfo;
				index->close();
				this->indexMng->fileIndexTable->closeScanIndex();
				return false;
			}

			delete qDel;
		}
		else if (iInfo->indexType == DOUBLE_INDEX){
			//remove
			keyDouble = (double)atof(oldAttributeValue->getStrValue());

			lnode = new ListNode();
			lnode->SetStartPos(parentNode->getKey());
			lnode->SetEndPos(parentNode->getEndKey());
			lnode->SetLevel(parentNode->getLevel());
			qDel = new bt_query_t(bt_query_t::bt_eq,new double(keyDouble),NULL,lnode,NULL);
			ret = index->remove(qDel);

			if (ret != RCOKGist) {
				globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"IndexIncrementalUpdate::attributeValueModification",__FILE__,"Cannot remove an entry from the gist index file.");
				delete indexName;
				delete qDel;
				delete iInfo;
				index->close();
				this->indexMng->fileIndexTable->closeScanIndex();
				return false;
			}
			//add new attrval + samekey
			keyDouble = (double)atof(newAttributeValue->getStrValue());
			ret = index->insert(&keyDouble,sizeof(double),lnode,sizeof(ListNode));

			if (ret != RCOKGist) {
				globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"IndexIncrementalUpdate::attributeValueModification",__FILE__,"Cannot insert an entry from the gist index file.");
				delete indexName;
				delete qDel;
				delete iInfo;
				index->close();
				this->indexMng->fileIndexTable->closeScanIndex();
				return false;
			}

			delete qDel;
		}

		index->close();
		delete indexName;
	}
	break;
case JOININDEX:
	{
		if ((iInfo->leftSideType == JOININDEX_ATTRIBUTECONTENT) ||
			(iInfo->rightSideType == JOININDEX_ATTRIBUTECONTENT) |
			(iInfo->leftSideType == JOININDEX_ATTRIBUTEVALUE) ||
			(iInfo->rightSideType == JOININDEX_ATTRIBUTEVALUE)) 
		{
			if ((iInfo->leftSideType == JOININDEX_ATTRIBUTECONTENT) || 
				(iInfo->leftSideType == JOININDEX_ATTRIBUTEVALUE))
			{
				//check whether the attribute name inserted is the left side
				if (strcmp(iInfo->leftSide,attributeName) == 0){
					//not support, and inefficient to update the join index for this case
					cout << "Please drop and rebuild join index: " << iInfo->indexName  << endl;
					globalErrorInfo.insertProblem(ERR_TYPE_WARNING,__LINE__,"IndexIncrementalUpdate::attributeValueModification",__FILE__,"Some of join indices are not supported to the update. Please rebuild accordingly");  
					break;
				}

			}

			if ((iInfo->rightSideType == JOININDEX_ATTRIBUTECONTENT) ||
				(iInfo->rightSideType == JOININDEX_ATTRIBUTEVALUE))
			{
				//check whether the attribute name inserted is the right side
				if (strcmp(iInfo->rightSide,attributeName) == 0){
					//not support, and inefficient to update the join index for this case
					cout << "Please drop and rebuild join index: " << iInfo->indexName  << endl;
					globalErrorInfo.insertProblem(ERR_TYPE_WARNING,__LINE__,"IndexIncrementalUpdate::attributeValueModification",__FILE__,"Some of join indices are not supported to the update. Please rebuild accordingly");  
					break;
				}
			}

		} //if 4
	}
	break;
default:
	break;
		} //switch

		delete iInfo;
	}//while scan fileindex
	this->indexMng->fileIndexTable->closeScanIndex();
	return true;
}

/**
* Process Method
*
* Perform relevant incremental index update in case of attribute value deletion of a particular attribute name
* Only the value of the atribute is deleted, the attribute name and attribute node is still present.
*
* @param fileinfo The file info type of the xml file to perform incremental index update
* @param parentNode The data node pointer of the parent
* @param attributeKey The attribute key of that to be modified its attribute value
* @param attributeName The string contains attributename
* @param oldAttributeValue The old value of the attribute value
* @return Whether it has any errors.
*/
bool IndexIncrementalUpdate::attributeValueDeletion(FileInfoType* fileinfo, DM_ElementNode* parentNode, KeyType attributeKey, char* attributeName, Value* oldAttributeValue)
{
	IndexInfoType *iInfo;
	ListNode* lnode;
	bt_query_t* qDel;
	int keyInt;
	float keyFloat;
	double keyDouble;
	char* keyChar;
	char* indexName;
	rc_tGist ret;
	
	//scan for all concerned indices
	this->indexMng->fileIndexTable->startScanIndex(fileinfo->key);
	while ((iInfo = this->indexMng->fileIndexTable->getNextIndexInfo()) != NULL) {

		switch (iInfo->indexDescription) {

case VALUEINDEX_ATTRIBUTEVALUE:
	{
		//get index name concat with path, and open it
		indexName = new char[strlen(this->indexNamePath) + strlen(iInfo->indexName) + 1];
		strcpy(indexName,this->indexNamePath);
		strcpy(indexName + strlen(this->indexNamePath), iInfo->indexName);


		ret = index->open(indexName);
		if (ret != RCOKGist) {
			globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"IndexIncrementalUpdate::attributeValueDeletion",__FILE__,"Cannot open gist index file.");
			delete indexName;
			delete iInfo;
			this->indexMng->fileIndexTable->closeScanIndex();
			return false;
		}

		if(iInfo->indexType == STRING_INDEX){

			//remove attrvalue
			keyChar = new char[strlen(oldAttributeValue->getStrValue())+1];
			strcpy(keyChar,oldAttributeValue->getStrValue());

			lnode = new ListNode();
			lnode->SetStartPos(attributeKey);
			lnode->SetEndPos(attributeKey);
			lnode->SetLevel(parentNode->getLevel()+1);
			qDel = new bt_query_t(bt_query_t::bt_eq,keyChar,NULL,lnode,NULL);
			ret = index->remove(qDel);

			if (ret != RCOKGist) {
				globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"IndexIncrementalUpdate::attributeValueDeletion",__FILE__,"Cannot remove an entry from the gist index file.");
				delete indexName;
				delete qDel;
				delete iInfo;
				index->close();
				this->indexMng->fileIndexTable->closeScanIndex();
				return false;
			}

			delete qDel;
		}
		else if (iInfo->indexType == INT_INDEX){
			//remove
			keyInt = atoi(oldAttributeValue->getStrValue());

			lnode = new ListNode();
			lnode->SetStartPos(attributeKey);
			lnode->SetEndPos(attributeKey);
			lnode->SetLevel(parentNode->getLevel()+1);
			qDel = new bt_query_t(bt_query_t::bt_eq,new int(keyInt),NULL,lnode,NULL);
			ret = index->remove(qDel);

			if (ret != RCOKGist) {
				globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"IndexIncrementalUpdate::attributeValueDeletion",__FILE__,"Cannot remove an entry from the gist index file.");
				delete indexName;
				delete qDel;
				delete iInfo;
				index->close();
				this->indexMng->fileIndexTable->closeScanIndex();
				return false;
			}

			delete qDel;
		}
		else if (iInfo->indexType == FLOAT_INDEX){
			//remove
			keyFloat = (float)atof(oldAttributeValue->getStrValue());

			lnode = new ListNode();
			lnode->SetStartPos(attributeKey);
			lnode->SetEndPos(attributeKey);
			lnode->SetLevel(parentNode->getLevel()+1);
			qDel = new bt_query_t(bt_query_t::bt_eq,new float(keyFloat),NULL,lnode,NULL);
			ret = index->remove(qDel);

			if (ret != RCOKGist) {
				globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"IndexIncrementalUpdate::attributeValueDeletion",__FILE__,"Cannot remove an entry from the gist index file.");
				delete indexName;
				delete qDel;
				delete iInfo;
				index->close();
				this->indexMng->fileIndexTable->closeScanIndex();
				return false;
			}
			delete qDel;
		}
		else if (iInfo->indexType == DOUBLE_INDEX){
			//remove
			keyDouble = (double)atof(oldAttributeValue->getStrValue());

			lnode = new ListNode();
			lnode->SetStartPos(attributeKey);
			lnode->SetEndPos(attributeKey);
			lnode->SetLevel(parentNode->getLevel()+1);
			qDel = new bt_query_t(bt_query_t::bt_eq,new double(keyDouble),NULL,lnode,NULL);
			ret = index->remove(qDel);

			if (ret != RCOKGist) {
				globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"IndexIncrementalUpdate::attributeValueDeletion",__FILE__,"Cannot remove an entry from the gist index file.");
				delete indexName;
				delete qDel;
				delete iInfo;
				index->close();
				this->indexMng->fileIndexTable->closeScanIndex();
				return false;
			}
			
			delete qDel;
		}
		index->close();
		delete indexName;
	}
	break;
case VALUEINDEX_ATTRIBUTECONTENT:
	{
		Value* attrnameval =  new Value(STRING_VALUE,attributeName);
		//if the index is built on this attrname, modify key
		SelectionCondition* idxcond = new SelectionCondition(iInfo->selectionCondition);
		PredicateCondition* idxpred = idxcond->getCondition()->getCondAt(0)->getCondAt(0);

		if (!idxpred->getRightValue()->compareValue(VALUE_COMP_OP_EQ,attrnameval)) {
			//if attrname built != this attrname, ignore
			delete idxcond;
			delete attrnameval;
			break;
		}

		delete idxcond;
		delete attrnameval;

		//get index name concat with path, and open it
		indexName = new char[strlen(this->indexNamePath) + strlen(iInfo->indexName) + 1];
		strcpy(indexName,this->indexNamePath);
		strcpy(indexName + strlen(this->indexNamePath), iInfo->indexName);


		ret = index->open(indexName);
		if (ret != RCOKGist) {
			globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"IndexIncrementalUpdate::attributeValueDeletion",__FILE__,"Cannot open gist index file.");
			delete indexName;
			delete iInfo;
			this->indexMng->fileIndexTable->closeScanIndex();
			return false;
		}

		if(iInfo->indexType == STRING_INDEX){

			//remove attrvalue
			keyChar = new char[strlen(oldAttributeValue->getStrValue())+1];
			strcpy(keyChar,oldAttributeValue->getStrValue());

			lnode = new ListNode();
			lnode->SetStartPos(parentNode->getKey());
			lnode->SetEndPos(parentNode->getEndKey());
			lnode->SetLevel(parentNode->getLevel());
			qDel = new bt_query_t(bt_query_t::bt_eq,keyChar,NULL,lnode,NULL);
			ret = index->remove(qDel);

			if (ret != RCOKGist) {
				globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"IndexIncrementalUpdate::attributeValueDeletion",__FILE__,"Cannot remove an entry from the gist index file.");
				delete indexName;
				delete qDel;
				delete iInfo;
				index->close();
				this->indexMng->fileIndexTable->closeScanIndex();
				return false;
			}

			delete qDel;
		}
		else if (iInfo->indexType == INT_INDEX){
			//remove
			keyInt = atoi(oldAttributeValue->getStrValue());

			lnode = new ListNode();
			lnode->SetStartPos(parentNode->getKey());
			lnode->SetEndPos(parentNode->getEndKey());
			lnode->SetLevel(parentNode->getLevel());
			qDel = new bt_query_t(bt_query_t::bt_eq,new int(keyInt),NULL,lnode,NULL);
			ret = index->remove(qDel);

			if (ret != RCOKGist) {
				globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"IndexIncrementalUpdate::attributeValueDeletion",__FILE__,"Cannot remove an entry from the gist index file.");
				delete indexName;
				delete qDel;
				delete iInfo;
				index->close();
				this->indexMng->fileIndexTable->closeScanIndex();
				return false;
			}
			delete qDel;
		}
		else if (iInfo->indexType == FLOAT_INDEX){
			//remove
			keyFloat = (float)atof(oldAttributeValue->getStrValue());

			lnode = new ListNode();
			lnode->SetStartPos(parentNode->getKey());
			lnode->SetEndPos(parentNode->getEndKey());
			lnode->SetLevel(parentNode->getLevel());
			qDel = new bt_query_t(bt_query_t::bt_eq,new float(keyFloat),NULL,lnode,NULL);
			ret = index->remove(qDel);

			if (ret != RCOKGist) {
				globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"IndexIncrementalUpdate::attributeValueDeletion",__FILE__,"Cannot remove an entry from the gist index file.");
				delete indexName;
				delete qDel;
				delete iInfo;
				index->close();
				this->indexMng->fileIndexTable->closeScanIndex();
				return false;
			}
			delete qDel;
		}
		else if (iInfo->indexType == DOUBLE_INDEX){
			//remove
			keyDouble = (double)atof(oldAttributeValue->getStrValue());

			lnode = new ListNode();
			lnode->SetStartPos(parentNode->getKey());
			lnode->SetEndPos(parentNode->getEndKey());
			lnode->SetLevel(parentNode->getLevel());
			qDel = new bt_query_t(bt_query_t::bt_eq,new double(keyDouble),NULL,lnode,NULL);
			ret = index->remove(qDel);

			if (ret != RCOKGist) {
				globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"IndexIncrementalUpdate::attributeValueDeletion",__FILE__,"Cannot remove an entry from the gist index file.");
				delete indexName;
				delete qDel;
				delete iInfo;
				index->close();
				this->indexMng->fileIndexTable->closeScanIndex();
				return false;
			}
			
			delete qDel;
		}

		index->close();
		delete indexName;
	}
	break;
case JOININDEX:
	{
		bool mirror = false, same = false; //whether mirror index exist, and successfully opened for operation
		char* indexName2;
		gist* index2 = new gist;
		//check only if it is left side, since we can retrieve/del the entry only if it's the key (left side)
		//since we assume there will be a mirror index, we will automatically try to update both
		if ((iInfo->leftSideType == JOININDEX_ATTRIBUTECONTENT) ||
			(iInfo->leftSideType == JOININDEX_ATTRIBUTEVALUE)) {
			//try to delete from it the parent key as leftside key (for content type) or attrkey (for value type)

			//check whether left side = this attrname
			if (strcmp(attributeName,iInfo->leftSide) == 0) {
				//get index name concat with path, and open it
				indexName = new char[strlen(this->indexNamePath) + strlen(iInfo->indexName) + 1];
				strcpy(indexName,this->indexNamePath);
				strcpy(indexName + strlen(this->indexNamePath), iInfo->indexName);

				ret = index->open(indexName);
				if (ret != RCOKGist) {
					globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"IndexIncrementalUpdate::attributeValueDeletion",__FILE__,"Cannot open gist index file.");
					delete indexName;
					delete iInfo;
					this->indexMng->fileIndexTable->closeScanIndex();
					return false;
				}

				//get mirror only if mirror name is different than this name
				char indexMirror[MAX_INDEX_NAME_LENGTH];
				bool rc = this->indexMng->constructIndexName(iInfo->fileName,indexMirror,JOININDEX,NULL,DOUBLE_INDEX,iInfo->rightSide,iInfo->rightSideType,iInfo->leftSide,iInfo->leftSideType);
				if (strcmp(indexMirror,iInfo->indexName) != 0) {
					if (rc && this->indexMng->existIndex(indexMirror)) {
						indexName2 = new char[strlen(this->indexNamePath) + strlen(indexMirror) + 1];
						strcpy(indexName2,this->indexNamePath);
						strcpy(indexName2 + strlen(this->indexNamePath), indexMirror);

						ret = index2->open(indexName2);
						if (ret == RCOKGist) {
							mirror = true;
						}
						delete indexName2;
					}
				}
				else { //ac_id_ac_id
					same = true;
				}

				bt_query_t *qGet, *qDel;
				gist_cursor_t cursor;
				bool eof = false;
				unsigned long keysz, datasz;
				double key;
				ListNode lnode;
				ListNode* lnodeDel;

				if (iInfo->leftSideType == JOININDEX_ATTRIBUTECONTENT)
					qGet = new bt_query_t(bt_query_t::bt_eq,new double(parentNode->getKey().toDouble()),NULL);
				else
					qGet = new bt_query_t(bt_query_t::bt_eq,new double(attributeKey.toDouble()),NULL);

				cursor.k = 0;
				cursor.io = 0;
				cursor.query = NULL;
				cursor.ext = NULL;
				cursor.cext = NULL;
				cursor.iter = NULL;
				cursor.state = NULL;
				index->fetch_init(cursor, qGet);


				//retrieve key,data pair
				while (!eof) {
					ret = index->fetch(cursor, &key, keysz, (void *)&lnode, datasz, eof);
					if (!ret && !eof){

						//if (key != lnode.GetStartPos().toDouble()) {
							//no false positive b/c one attrname only for one attrnode

							lnodeDel = new ListNode(lnode);
							qDel = new bt_query_t(bt_query_t::bt_eq,new double(key),NULL,lnodeDel,NULL);
							ret = index->remove(qDel);
							if (ret != RCOKGist) {
								globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"IndexIncrementalUpdate::attributeValueDeletion",__FILE__,"Cannot remove an entry from the gist index file.");
								delete indexName;
								delete qDel;
								delete qGet;
								delete iInfo;
								index->close();
								this->indexMng->fileIndexTable->closeScanIndex();
								return false;
							}
							delete qDel;
							//then delete the mirror index if found one
							if (mirror) {
								lnodeDel = new ListNode();
								if (iInfo->leftSideType == JOININDEX_ATTRIBUTECONTENT) {
									lnodeDel->SetStartPos(parentNode->getKey());
									lnodeDel->SetEndPos(parentNode->getEndKey());
									lnodeDel->SetLevel(parentNode->getLevel());
								}
								else {
									lnodeDel->SetStartPos(attributeKey);
									lnodeDel->SetEndPos(attributeKey);
									lnodeDel->SetLevel(parentNode->getLevel()+1);
								}
								qDel = new bt_query_t(bt_query_t::bt_eq,new double(lnode.GetStartPos().toDouble()),NULL,lnodeDel,NULL);
								ret = index2->remove(qDel);
								if (ret != RCOKGist) {
									globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"IndexIncrementalUpdate::attributeValueDeletion",__FILE__,"Cannot remove an entry from the gist index file.");
									delete indexName;
									delete qDel;
									delete qGet;
									delete iInfo;
									index->close();
									index2->close();
									this->indexMng->fileIndexTable->closeScanIndex();
									return false;
								}
								delete qDel;
							}
							else if (same) { 
								//if ac_id_ac_id, do not need another opened index, b/c it's the same file
								//we want to delete lnode -> key (which is different)
								//for lnode = key , it fall in the below else clause
								lnodeDel = new ListNode();
								if (iInfo->leftSideType == JOININDEX_ATTRIBUTECONTENT) {
									lnodeDel->SetStartPos(parentNode->getKey());
									lnodeDel->SetEndPos(parentNode->getEndKey());
									lnodeDel->SetLevel(parentNode->getLevel());
								}
								else {
									lnodeDel->SetStartPos(attributeKey);
									lnodeDel->SetEndPos(attributeKey);
									lnodeDel->SetLevel(parentNode->getLevel());
								}
								qDel = new bt_query_t(bt_query_t::bt_eq,new double(lnode.GetStartPos().toDouble()),NULL,lnodeDel,NULL);
								ret = index->remove(qDel);
								if (ret != RCOKGist) {
									globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"IndexIncrementalUpdate::attributeValueDeletion",__FILE__,"Cannot remove an entry from the gist index file.");
									delete indexName;
									delete qDel;
									delete qGet;
									delete iInfo;
									index->close();
									this->indexMng->fileIndexTable->closeScanIndex();
									return false;
								}
								delete qDel;
							}
						/*} // if (key != data.key)
						else { //key == data.key, usually in case of joining itself
							lnodeDel = new ListNode(lnode);
							qDel = new bt_query_t(bt_query_t::bt_eq,new double(key),NULL,lnodeDel,NULL);
							ret = index->remove(qDel);
							if (ret != RCOKGist) {
								globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"IndexIncrementalUpdate::attributeValueDeletion",__FILE__,"Cannot remove an entry from the gist index file.");
								delete indexName;
								delete qDel;
								delete qGet;
								delete iInfo;
								index->close();
								this->indexMng->fileIndexTable->closeScanIndex();
								return false;
							}
							delete qDel;
						}*/
					}//if (!ret && !eof)
				} //while !eof
				delete qGet;
				index->close();
				if (mirror){
					index2->close();
					delete index2;
				}
			} // strcmp(attributeName,iInfo->leftSide) == 0

		}
	}
	break;
default:
	break;
		} //switch

		delete iInfo;
	}//while scan fileindex
	this->indexMng->fileIndexTable->closeScanIndex();
	return true;
}

/**
* Process Method
*
* Perform relevant incremental index update in case of key (start, end, level) modification
* Node can be element, text or attribute node
*
* @param fileinfo The file info type of the xml file to perform incremental index update
* @param oldNode The data node pointer of the node to change its key(s)
* @param newStartKey The anew start key to be changed to
* @param newEndKey The new end key
* @param newLevel The new level value
* @return Whether it has any errors.
*/
bool IndexIncrementalUpdate::keyModification(FileInfoType* fileinfo, DM_DataNode* oldNode, KeyType newStartKey, KeyType newEndKey, short newLevel)
{

	if (oldNode->getFlag() == ELEMENT_NODE){
		return keyElementNodeModification(fileinfo,(DM_ElementNode*)oldNode,newStartKey,newEndKey,newLevel);
	}
	else if (oldNode->getFlag()== TEXT_NODE) {
		return keyTextNodeModification(fileinfo,(DM_TextNode*)oldNode,newStartKey,newEndKey,newLevel);
	}
	else if (oldNode->getFlag() == ATTRIBUTE_NODE) {
		return keyAttributeNodeModification(fileinfo,(DM_AttributeNode*)oldNode,newStartKey,newEndKey,newLevel);
	}
	else{ 
		globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"IndexIncrementalUpdate::keyModification",__FILE__,"Node type not support for key modification.");
		return false;
	}
}

/**
* Process Method
*
* Perform relevant incremental index update in case of key (start, end, level) modification on element node
*
* @param fileinfo The file info type of the xml file to perform incremental index update
* @param oldNode The data node pointer of the node to change its key(s)
* @param newStartKey The anew start key to be changed to
* @param newEndKey The new end key
* @param newLevel The new level value
* @return Whether it has any errors.
*/
bool IndexIncrementalUpdate::keyElementNodeModification(FileInfoType* fileinfo, DM_ElementNode* oldNode, KeyType newStartKey, KeyType newEndKey, short newLevel)
{
	IndexInfoType *iInfo;
	ListNode* lnode;
	bt_query_t* qDel;
	int keyInt;
	float keyFloat;
	double keyDouble;
	char* keyChar;
	char* indexName;
	rc_tGist ret;

	//scan for all concerned indices
	this->indexMng->fileIndexTable->startScanIndex(fileinfo->key);
	while ((iInfo = this->indexMng->fileIndexTable->getNextIndexInfo()) != NULL) {

		switch (iInfo->indexDescription) {

case VALUEINDEX_ELEMENTTAG:
	{
		//get index name concat with path, and open it
		indexName = new char[strlen(this->indexNamePath) + strlen(iInfo->indexName) + 1];
		strcpy(indexName,this->indexNamePath);
		strcpy(indexName + strlen(this->indexNamePath), iInfo->indexName);

		ret = index->open(indexName);
		if (ret != RCOKGist) {
			globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"IndexIncrementalUpdate::keyElementNodeModification",__FILE__,"Cannot open gist index file.");
			delete indexName;
			delete iInfo;
			this->indexMng->fileIndexTable->closeScanIndex();
			return false;
		}

		//remove tag + oldkey
		keyInt = oldNode->getTag();
		lnode = new ListNode();
		lnode->SetStartPos(oldNode->getKey());
		lnode->SetEndPos(oldNode->getEndKey());
		lnode->SetLevel(oldNode->getLevel());
		qDel = new bt_query_t(bt_query_t::bt_eq,new int(keyInt),NULL,lnode,NULL);
		ret = index->remove(qDel);

		if (ret != RCOKGist) {
			globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"IndexIncrementalUpdate::keyElementNodeModification",__FILE__,"Cannot remove an entry from the gist index file.");
			delete indexName;
			delete qDel;
			delete iInfo;
			index->close();
			this->indexMng->fileIndexTable->closeScanIndex();
			return false;
		}
		//add tag + newkey
		lnode->SetStartPos(newStartKey);
		lnode->SetEndPos(newEndKey);
		lnode->SetLevel(newLevel);
		ret = index->insert(&keyInt,sizeof(int),lnode,sizeof(ListNode));

		if (ret != RCOKGist) {
			globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"IndexIncrementalUpdate::keyElementNodeModification",__FILE__,"Cannot insert an entry from the gist index file.");
			delete indexName;
			delete qDel;
			delete iInfo;
			index->close();
			this->indexMng->fileIndexTable->closeScanIndex();
			return false;
		}

		index->close();
		delete qDel;
		delete indexName;
	}
	break;

case VALUEINDEX_TAGNAME_ID_PAIR:
	{
		//get index name concat with path, and open it
		indexName = new char[strlen(this->indexNamePath) + strlen(iInfo->indexName) + 1];
		strcpy(indexName,this->indexNamePath);
		strcpy(indexName + strlen(this->indexNamePath), iInfo->indexName);

		ret = index->open(indexName);
		if (ret != RCOKGist) {
			globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"IndexIncrementalUpdate::keyElementNodeModification",__FILE__,"Cannot open gist index file.");
			delete indexName;
			delete iInfo;
			this->indexMng->fileIndexTable->closeScanIndex();
			return false;
		}

		tagIdIndex = new TagNameAndNodeIdIndex();

		//remove tag&key
		bool tRet = this->tagIdIndex->deleteNode(oldNode->getTag(this->indexMng->pDataMng->getXMLNameTable()),oldNode->getKey().toDouble(),index);

		if (tRet != true) {
			globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"IndexIncrementalUpdate::keyElementNodeModification",__FILE__,"Cannot remove an entry from the gist index file.");
			delete indexName;
			delete iInfo;
			delete tagIdIndex;
			index->close();
			this->indexMng->fileIndexTable->closeScanIndex();
			return false;
		}

		//add tag&new key
		lnode = new ListNode();
		lnode->SetStartPos(newStartKey);
		lnode->SetEndPos(newEndKey);
		lnode->SetLevel(newLevel);
		tagIdIndex = new TagNameAndNodeIdIndex();

		//remove tag&key
		tRet = this->tagIdIndex->insertNode(oldNode->getTag(this->indexMng->pDataMng->getXMLNameTable()),newStartKey.toDouble(),lnode,sizeof(ListNode),index);

		if (tRet != true) {
			globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"IndexIncrementalUpdate::keyElementNodeModification",__FILE__,"Cannot remove an entry from the gist index file.");
			delete indexName;
			delete iInfo;
			delete lnode;
			delete tagIdIndex;
			index->close();
			this->indexMng->fileIndexTable->closeScanIndex();
			return false;
		}
		delete lnode;
		delete tagIdIndex;
		index->close();
		delete indexName;
	}
	break;

case VALUEINDEX_ELEMENTTAGSTR:

	{
		//get index name concat with path, and open it
		indexName = new char[strlen(this->indexNamePath) + strlen(iInfo->indexName) + 1];
		strcpy(indexName,this->indexNamePath);
		strcpy(indexName + strlen(this->indexNamePath), iInfo->indexName);

		ret = index->open(indexName);
		if (ret != RCOKGist) {
			globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"IndexIncrementalUpdate::keyElementNodeModification",__FILE__,"Cannot open gist index file.");
			delete indexName;
			delete iInfo;
			this->indexMng->fileIndexTable->closeScanIndex();
			return false;
		}

		//remove tag + oldkey
		keyChar = new char[strlen(oldNode->getTag(this->indexMng->pDataMng->getXMLNameTable()))+1];
		strcpy(keyChar,oldNode->getTag(this->indexMng->pDataMng->getXMLNameTable()));

		lnode = new ListNode();
		lnode->SetStartPos(oldNode->getKey());
		lnode->SetEndPos(oldNode->getEndKey());
		lnode->SetLevel(oldNode->getLevel());
		qDel = new bt_query_t(bt_query_t::bt_eq,keyChar,NULL,lnode,NULL);
		ret = index->remove(qDel);

		if (ret != RCOKGist) {
			globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"IndexIncrementalUpdate::keyElementNodeModification",__FILE__,"Cannot remove an entry from the gist index file.");
			delete indexName;
			delete qDel;
			delete iInfo;
			index->close();
			this->indexMng->fileIndexTable->closeScanIndex();
			return false;
		}
		//add tag + newkey
		lnode->SetStartPos(newStartKey);
		lnode->SetEndPos(newEndKey);
		lnode->SetLevel(newLevel);
		ret = index->insert(keyChar,(int)(strlen((char *)keyChar))+1,lnode,sizeof(ListNode));

		if (ret != RCOKGist) {
			globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"IndexIncrementalUpdate::keyElementNodeModification",__FILE__,"Cannot insert an entry from the gist index file.");
			delete indexName;
			delete qDel;
			delete iInfo;
			index->close();
			this->indexMng->fileIndexTable->closeScanIndex();
			return false;
		}

		index->close();
		delete qDel;
		delete indexName;
	}
	break;

case VALUEINDEX_ELEMENTCONTENT:
	{
		int tagInt = oldNode->getTag();
		//check whether the index is built on this node tag
		SelectionCondition* idxcond = new SelectionCondition(iInfo->selectionCondition);
		PredicateCondition* idxpred = idxcond->getCondition()->getCondAt(0)->getCondAt(0);
		Value* val = new Value(INT_VALUE);
		val->setIntValue(tagInt);
		if (!idxpred->getRightValue()->compareValue(VALUE_COMP_OP_EQ,val)) {
			//if tagname built != this modified node tag name, ignore
			delete idxcond;
			delete val;
			break;
		}

		delete idxcond;
		delete val;

		//get index name concat with path, and open it
		indexName = new char[strlen(this->indexNamePath) + strlen(iInfo->indexName) + 1];
		strcpy(indexName,this->indexNamePath);
		strcpy(indexName + strlen(this->indexNamePath), iInfo->indexName);


		ret = index->open(indexName);
		if (ret != RCOKGist) {
			globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"IndexIncrementalUpdate::keyElementNodeModification",__FILE__,"Cannot open gist index file.");
			delete indexName;
			delete iInfo;
			this->indexMng->fileIndexTable->closeScanIndex();
			return false;
		}


		//get all text node to modify the key in the entry
		KeyType childkey = oldNode->getFirstChild();
		while (childkey >= 0)
		{
			DM_DataNode* childnode = this->indexMng->pDataMng->fetchDataNodeFromDBFile((const FileInfoType)*fileinfo, childkey);
			if (childnode == NULL){
				globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"IndexIncrementalUpdate::keyElementNodeModification",__FILE__,"Cannot get child node with the given key.");
				delete indexName;
				delete iInfo;
				index->close();
				this->indexMng->fileIndexTable->closeScanIndex();
				return false;
			}


			if (childnode->getFlag() == TEXT_NODE)
			{
				if(iInfo->indexType == STRING_INDEX){
					//remove content + oldkey
					keyChar = new char[strlen(((DM_TextNode*)childnode)->getCharValue())+1];
					strcpy(keyChar,((DM_TextNode*)childnode)->getCharValue());

					lnode = new ListNode();
					lnode->SetStartPos(oldNode->getKey());
					lnode->SetEndPos(oldNode->getEndKey());
					lnode->SetLevel(oldNode->getLevel());
					qDel = new bt_query_t(bt_query_t::bt_eq,keyChar,NULL,lnode,NULL);
					ret = index->remove(qDel);

					if (ret != RCOKGist) {
						globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"IndexIncrementalUpdate::keyElementNodeModification",__FILE__,"Cannot remove an entry from the gist index file.");
						delete indexName;
						delete qDel;
						delete iInfo;
						index->close();
						this->indexMng->fileIndexTable->closeScanIndex();
						return false;
					}
					//add tag + newkey
					lnode->SetStartPos(newStartKey);
					lnode->SetEndPos(newEndKey);
					lnode->SetLevel(newLevel);
					ret = index->insert(keyChar,(int)(strlen((char *)keyChar))+1,lnode,sizeof(ListNode));

					if (ret != RCOKGist) {
						globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"IndexIncrementalUpdate::keyElementNodeModification",__FILE__,"Cannot insert an entry from the gist index file.");
						delete indexName;
						delete qDel;
						delete iInfo;
						index->close();
						this->indexMng->fileIndexTable->closeScanIndex();
						return false;
					}

					delete qDel;
				}
				else if (iInfo->indexType == INT_INDEX) {

					//remove content + oldkey
					keyInt = atoi(((DM_TextNode*)childnode)->getCharValue());

					lnode = new ListNode();
					lnode->SetStartPos(oldNode->getKey());
					lnode->SetEndPos(oldNode->getEndKey());
					lnode->SetLevel(oldNode->getLevel());
					qDel = new bt_query_t(bt_query_t::bt_eq,new int(keyInt),NULL,lnode,NULL);
					ret = index->remove(qDel);

					if (ret != RCOKGist) {
						globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"IndexIncrementalUpdate::keyElementNodeModification",__FILE__,"Cannot remove an entry from the gist index file.");
						delete indexName;
						delete qDel;
						delete iInfo;
						index->close();
						this->indexMng->fileIndexTable->closeScanIndex();
						return false;
					}
					//add tag + newkey
					lnode->SetStartPos(newStartKey);
					lnode->SetEndPos(newEndKey);
					lnode->SetLevel(newLevel);
					ret = index->insert(&keyInt,sizeof(int),lnode,sizeof(ListNode));

					if (ret != RCOKGist) {
						globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"IndexIncrementalUpdate::keyElementNodeModification",__FILE__,"Cannot insert an entry from the gist index file.");
						delete indexName;
						delete qDel;
						delete iInfo;
						index->close();
						this->indexMng->fileIndexTable->closeScanIndex();
						return false;
					}

					delete qDel;
				}
				else if (iInfo->indexType == FLOAT_INDEX) {
					//remove content + oldkey
					keyFloat = (float)atof(((DM_TextNode*)childnode)->getCharValue());

					lnode = new ListNode();
					lnode->SetStartPos(oldNode->getKey());
					lnode->SetEndPos(oldNode->getEndKey());
					lnode->SetLevel(oldNode->getLevel());
					qDel = new bt_query_t(bt_query_t::bt_eq,new float(keyFloat),NULL,lnode,NULL);
					ret = index->remove(qDel);

					if (ret != RCOKGist) {
						globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"IndexIncrementalUpdate::keyElementNodeModification",__FILE__,"Cannot remove an entry from the gist index file.");
						delete indexName;
						delete qDel;
						delete iInfo;
						index->close();
						this->indexMng->fileIndexTable->closeScanIndex();
						return false;
					}
					//add tag + newkey
					lnode->SetStartPos(newStartKey);
					lnode->SetEndPos(newEndKey);
					lnode->SetLevel(newLevel);
					ret = index->insert(&keyFloat,sizeof(float),lnode,sizeof(ListNode));

					if (ret != RCOKGist) {
						globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"IndexIncrementalUpdate::keyElementNodeModification",__FILE__,"Cannot insert an entry from the gist index file.");
						delete indexName;
						delete qDel;
						delete iInfo;
						index->close();
						this->indexMng->fileIndexTable->closeScanIndex();
						return false;
					}

					delete qDel;
				}
				else if (iInfo->indexType == DOUBLE_INDEX) {
					//remove content + oldkey
					keyDouble = (double)atof(((DM_TextNode*)childnode)->getCharValue());

					lnode = new ListNode();
					lnode->SetStartPos(oldNode->getKey());
					lnode->SetEndPos(oldNode->getEndKey());
					lnode->SetLevel(oldNode->getLevel());
					qDel = new bt_query_t(bt_query_t::bt_eq,new double(keyDouble),NULL,lnode,NULL);
					ret = index->remove(qDel);

					if (ret != RCOKGist) {
						globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"IndexIncrementalUpdate::keyElementNodeModification",__FILE__,"Cannot remove an entry from the gist index file.");
						delete indexName;
						delete qDel;
						delete iInfo;
						index->close();
						this->indexMng->fileIndexTable->closeScanIndex();
						return false;
					}
					//add tag + newkey
					lnode->SetStartPos(newStartKey);
					lnode->SetEndPos(newEndKey);
					lnode->SetLevel(newLevel);
					ret = index->insert(&keyDouble,sizeof(double),lnode,sizeof(ListNode));

					if (ret != RCOKGist) {
						globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"IndexIncrementalUpdate::keyElementNodeModification",__FILE__,"Cannot insert an entry from the gist index file.");
						delete indexName;
						delete qDel;
						delete iInfo;
						index->close();
						this->indexMng->fileIndexTable->closeScanIndex();
						return false;
					}
					delete qDel;
				}
			} //if = TEXT_NODE

			childkey = childnode->getNextSibling();
			//Multicolor
			//If key is not valid , and it is char node, and attribute key is valid
			if ((!childkey.isValid()) && 
				((childnode->getFlag() == TEXT_NODE) || (childnode->getFlag() == COMMENT_NODE)) &&
				(((DM_CharNode*)childnode)->getAttributes().isValid())) {
					// it is part of the children of Multicolor node
					//go to that attribute node to get next sibling of this char node
					DM_DataNode* attrnode;
					attrnode = this->indexMng->pDataMng->fetchDataNodeFromDBFile((const FileInfoType)*fileinfo, ((DM_CharNode*)childnode)->getAttributes());
					childkey = ((DM_AttributeNode*)attrnode)->getMCTNextSibling(oldNode->getKey(),childnode->getKey());
					delete attrnode;
				}
				//end Multicolor
				delete childnode;
		} //while childkey >=0

		index->close();
		delete indexName;
	}
	break;

case VALUEINDEX_ATTRIBUTECONTENT:
	{
		//get attribute node
		KeyType attrkey = oldNode->getAttributes();
		DM_AttributeNode* attrnode = (DM_AttributeNode*)this->indexMng->pDataMng->fetchDataNodeFromDBFile((const FileInfoType)* fileinfo,attrkey);
		if (attrnode == NULL) break;

		for(short i = 0 ; i < oldNode->getAttributeNumber(); i++)
		{
			char* attrname = ((DM_AttributeNode*) attrnode)->getAttributeNameAt(i);
			Value* attrval =  new Value(STRING_VALUE,attrname);
			//if the index is built on this attrname, modify key
			SelectionCondition* idxcond = new SelectionCondition(iInfo->selectionCondition);
			PredicateCondition* idxpred = idxcond->getCondition()->getCondAt(0)->getCondAt(0);

			if (!idxpred->getRightValue()->compareValue(VALUE_COMP_OP_EQ,attrval)) {
				//if attrname built != this attrname, ignore
				delete idxcond;
				delete attrval;
				continue;
			}

			delete idxcond;
			delete attrval;

			//get index name concat with path, and open it
			indexName = new char[strlen(this->indexNamePath) + strlen(iInfo->indexName) + 1];
			strcpy(indexName,this->indexNamePath);
			strcpy(indexName + strlen(this->indexNamePath), iInfo->indexName);


			ret = index->open(indexName);
			if (ret != RCOKGist) {
				globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"IndexIncrementalUpdate::keyModification",__FILE__,"Cannot open gist index file.");
				delete attrnode;
				delete indexName;
				delete iInfo;
				this->indexMng->fileIndexTable->closeScanIndex();
				return false;
			}

			if(iInfo->indexType == STRING_INDEX){
				//remove content + oldkey
				keyChar = new char[strlen(((DM_AttributeNode*) attrnode)->getAttr(attrname)->getStrValue())+1];
				strcpy(keyChar,((DM_AttributeNode*) attrnode)->getAttr(attrname)->getStrValue());

				lnode = new ListNode();
				lnode->SetStartPos(oldNode->getKey());
				lnode->SetEndPos(oldNode->getEndKey());
				lnode->SetLevel(oldNode->getLevel());
				qDel = new bt_query_t(bt_query_t::bt_eq,keyChar,NULL,lnode,NULL);
				ret = index->remove(qDel);

				if (ret != RCOKGist) {
					globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"IndexIncrementalUpdate::keyModification",__FILE__,"Cannot remove an entry from the gist index file.");
					delete attrnode;
					delete indexName;
					delete qDel;
					delete iInfo;
					index->close();
					this->indexMng->fileIndexTable->closeScanIndex();
					return false;
				}
				//add tag + newkey
				lnode->SetStartPos(newStartKey);
				lnode->SetEndPos(newEndKey);
				lnode->SetLevel(newLevel);
				ret = index->insert(keyChar,(int)(strlen((char *)keyChar))+1,lnode,sizeof(ListNode));

				if (ret != RCOKGist) {
					globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"IndexIncrementalUpdate::keyModification",__FILE__,"Cannot insert an entry from the gist index file.");
					delete attrnode;
					delete indexName;
					delete qDel;
					delete iInfo;
					index->close();
					this->indexMng->fileIndexTable->closeScanIndex();
					return false;
				}

				delete qDel;
			}
			else if (iInfo->indexType == INT_INDEX) {
				//remove content + oldkey
				keyInt = atoi(((DM_AttributeNode*) attrnode)->getAttr(attrname)->getStrValue());

				lnode = new ListNode();
				lnode->SetStartPos(oldNode->getKey());
				lnode->SetEndPos(oldNode->getEndKey());
				lnode->SetLevel(oldNode->getLevel());
				qDel = new bt_query_t(bt_query_t::bt_eq,new int(keyInt),NULL,lnode,NULL);
				ret = index->remove(qDel);

				if (ret != RCOKGist) {
					globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"IndexIncrementalUpdate::keyModification",__FILE__,"Cannot remove an entry from the gist index file.");
					delete indexName;
					delete attrnode;
					delete qDel;
					delete iInfo;
					index->close();
					this->indexMng->fileIndexTable->closeScanIndex();
					return false;
				}
				//add tag + newkey
				lnode->SetStartPos(newStartKey);
				lnode->SetEndPos(newEndKey);
				lnode->SetLevel(newLevel);
				ret = index->insert(&keyInt,sizeof(int),lnode,sizeof(ListNode));

				if (ret != RCOKGist) {
					globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"IndexIncrementalUpdate::keyModification",__FILE__,"Cannot insert an entry from the gist index file.");
					delete indexName;
					delete attrnode;
					delete qDel;
					delete iInfo;
					index->close();
					this->indexMng->fileIndexTable->closeScanIndex();
					return false;
				}
				delete qDel;
			}
			else if (iInfo->indexType == FLOAT_INDEX) {
				//remove content + oldkey
				keyFloat = (float)atof(((DM_AttributeNode*) attrnode)->getAttr(attrname)->getStrValue());

				lnode = new ListNode();
				lnode->SetStartPos(oldNode->getKey());
				lnode->SetEndPos(oldNode->getEndKey());
				lnode->SetLevel(oldNode->getLevel());
				qDel = new bt_query_t(bt_query_t::bt_eq,new float(keyFloat),NULL,lnode,NULL);
				ret = index->remove(qDel);

				if (ret != RCOKGist) {
					globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"IndexIncrementalUpdate::keyModification",__FILE__,"Cannot remove an entry from the gist index file.");
					delete indexName;
					delete qDel;
					delete attrnode;
					delete iInfo;
					index->close();
					this->indexMng->fileIndexTable->closeScanIndex();
					return false;
				}
				//add tag + newkey
				lnode->SetStartPos(newStartKey);
				lnode->SetEndPos(newEndKey);
				lnode->SetLevel(newLevel);
				ret = index->insert(&keyFloat,sizeof(float),lnode,sizeof(ListNode));

				if (ret != RCOKGist) {
					globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"IndexIncrementalUpdate::keyModification",__FILE__,"Cannot insert an entry from the gist index file.");
					delete indexName;
					delete qDel;
					delete attrnode;
					delete iInfo;
					index->close();
					this->indexMng->fileIndexTable->closeScanIndex();
					return false;
				}
				delete qDel;
			}
			else if (iInfo->indexType == DOUBLE_INDEX) {
				//remove content + oldkey
				keyDouble = (double)atof(((DM_AttributeNode*) attrnode)->getAttr(attrname)->getStrValue());

				lnode = new ListNode();
				lnode->SetStartPos(oldNode->getKey());
				lnode->SetEndPos(oldNode->getEndKey());
				lnode->SetLevel(oldNode->getLevel());
				qDel = new bt_query_t(bt_query_t::bt_eq,new double(keyDouble),NULL,lnode,NULL);
				ret = index->remove(qDel);

				if (ret != RCOKGist) {
					globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"IndexIncrementalUpdate::keyModification",__FILE__,"Cannot remove an entry from the gist index file.");
					delete indexName;
					delete qDel;
					delete attrnode;
					delete iInfo;
					index->close();
					this->indexMng->fileIndexTable->closeScanIndex();
					return false;
				}
				//add tag + newkey
				lnode->SetStartPos(newStartKey);
				lnode->SetEndPos(newEndKey);
				lnode->SetLevel(newLevel);
				ret = index->insert(&keyDouble,sizeof(double),lnode,sizeof(ListNode));

				if (ret != RCOKGist) {
					globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"IndexIncrementalUpdate::keyModification",__FILE__,"Cannot insert an entry from the gist index file.");
					delete indexName;
					delete qDel;
					delete attrnode;
					delete iInfo;
					index->close();
					this->indexMng->fileIndexTable->closeScanIndex();
					return false;
				}
				delete qDel;
			}

			index->close();
			delete indexName;
			break; //at least one match, should not be more
		}//for all attribute name
		delete attrnode;
	}
	break;
case JOININDEX:
	{
		bool mirror = false, same = false; //whether mirror index exist, and successfully opened for operation
		char* indexName2;
		DM_AttributeNode* attrNode;
		short at = -1;
		int tagInt = -1;
		gist* index2 = new gist;
		if ((iInfo->leftSideType == JOININDEX_ELEMENTCONTENT) ||
			(iInfo->leftSideType == JOININDEX_ATTRIBUTECONTENT))
		{

			//for attr , check at least one attribute as the leftside
			if (iInfo->leftSideType == JOININDEX_ATTRIBUTECONTENT) {
			
				attrNode = (DM_AttributeNode*)this->indexMng->pDataMng->fetchDataNodeFromDBFile((const FileInfoType)*fileinfo,oldNode->getAttributes());
				if (attrNode == NULL) {
					globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"IndexIncrementalUpdate::keyElementNodeModification",__FILE__,"Parent cannot be fetched by the key given.");
					return false;
				}
				//for each attribute name, value pair, find matching attrname == the left side of this index
				for (short i = 0 ; i < attrNode->getAttributeNumber() ; i++) {
					if (strcmp(attrNode->getAttributeNameAt(i),iInfo->leftSide) == 0) {
						at = i;
						break;
					}
				}
				delete attrNode;
			}


			//for element, check tag
			if (iInfo->leftSideType == JOININDEX_ELEMENTCONTENT) {
				tagInt = oldNode->getTag();
				if (tagInt == this->indexMng->xmlNameTable->getCodeByName(iInfo->leftSide))
					at = 0;
			}

			//check whether left side = this attrname
			if (at != -1) {
				//get index name concat with path, and open it
				indexName = new char[strlen(this->indexNamePath) + strlen(iInfo->indexName) + 1];
				strcpy(indexName,this->indexNamePath);
				strcpy(indexName + strlen(this->indexNamePath), iInfo->indexName);

					

				ret = index->open(indexName);
				if (ret != RCOKGist) {
					globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"IndexIncrementalUpdate::keyElementNodeModification",__FILE__,"Cannot open gist index file.");
					delete indexName;
					delete iInfo;
					this->indexMng->fileIndexTable->closeScanIndex();
					return false;
				}

				//get mirror only if mirror name is different than this name
				char indexMirror[MAX_INDEX_NAME_LENGTH];
				bool rc = this->indexMng->constructIndexName(iInfo->fileName,indexMirror,JOININDEX,NULL,DOUBLE_INDEX,iInfo->rightSide,iInfo->rightSideType,iInfo->leftSide,iInfo->leftSideType);
				if (strcmp(indexMirror,iInfo->indexName) != 0) {
					if (rc && this->indexMng->existIndex(indexMirror)) {
						indexName2 = new char[strlen(this->indexNamePath) + strlen(indexMirror) + 1];
						strcpy(indexName2,this->indexNamePath);
						strcpy(indexName2 + strlen(this->indexNamePath), indexMirror);

						ret = index2->open(indexName2);
						if (ret == RCOKGist) {
							mirror = true;
						}
						delete indexName2;
					}
				}
				else { //ac_id_ac_id
					same = true;
				}

				bt_query_t *qGet, *qDel;
				gist_cursor_t cursor;
				bool eof = false;
				unsigned long keysz, datasz;
				double key;
				ListNode lnode;
				ListNode  *lnodeDel, *lnodeAdd;

				qGet = new bt_query_t(bt_query_t::bt_eq,new double(oldNode->getKey().toDouble()),NULL);

				cursor.k = 0;
				cursor.io = 0;
				cursor.query = NULL;
				cursor.ext = NULL;
				cursor.cext = NULL;
				cursor.iter = NULL;
				cursor.state = NULL;
				index->fetch_init(cursor, qGet);


				//retrieve key,data pair
				while (!eof) {
					ret = index->fetch(cursor, &key, keysz, (void *)&lnode, datasz, eof);
					bool skip = false;
					if (!ret && !eof){

						//if (key != lnode.GetStartPos().toDouble()) {
							//no false positive b/c one attrname only for one attrnode
							//cout << key << "-" << lnode.GetStartPos().toDouble() << endl;
							lnodeDel = new ListNode(lnode);
							//delete the key,data
							qDel = new bt_query_t(bt_query_t::bt_eq,new double(key),NULL,lnodeDel,NULL);
							ret = index->remove(qDel);
							if (ret != RCOKGist) {
								globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"IndexIncrementalUpdate::keyElementNodeModification",__FILE__,"Cannot remove an entry from the gist index file.");
								delete indexName;
								delete qDel;
								delete qGet;
								delete iInfo;
								index->close();
								index2->close();
								this->indexMng->fileIndexTable->closeScanIndex();
								return false;
							}
							delete qDel;

							double newKey = newStartKey.toDouble();
							if (lnode.GetStartPos().toDouble() == key) {
								lnodeAdd = new ListNode();
								lnodeAdd->SetStartPos(newStartKey);
								lnodeAdd->SetEndPos(newEndKey);
								lnodeAdd->SetLevel(newLevel);
								skip = true; 
								// in case of av_id_av_id if 4 == 4, we change to 5 == 5, 
								// then we do not find 4 = 4 for another time since it has only one, 
								// so we do not add more than once
							}
							else lnodeAdd = new ListNode(lnode);

							//add by new key
							ret = index->insert(&newKey,sizeof(double),lnodeAdd,sizeof(ListNode));

							if (ret != RCOKGist) {
								globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"IndexIncrementalUpdate::keyElementNodeModification",__FILE__,"Cannot insert an entry from the gist index file.");
								delete indexName;
								delete qGet;
								delete iInfo;
								delete lnodeAdd;
								index->close();
								index2->close();
								this->indexMng->fileIndexTable->closeScanIndex();
								return false;
							}

							delete lnodeAdd;


							//then delete+add the mirror index if found one
							if (mirror) {
								lnodeDel = new ListNode();
								lnodeDel->SetStartPos(oldNode->getKey());
								lnodeDel->SetEndPos(oldNode->getEndKey());
								lnodeDel->SetLevel(oldNode->getLevel());

								qDel = new bt_query_t(bt_query_t::bt_eq,new double(lnode.GetStartPos().toDouble()),NULL,lnodeDel,NULL);
								ret = index2->remove(qDel);
								if (ret != RCOKGist) {
									globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"IndexIncrementalUpdate::keyElementNodeModification",__FILE__,"Cannot remove an entry from the gist index file.");
									delete indexName;
									delete qDel;
									delete qGet;
									delete iInfo;
									index->close();
									index2->close();
									this->indexMng->fileIndexTable->closeScanIndex();
									return false;
								}
								delete qDel;

								newKey = lnode.GetStartPos().toDouble();
								lnodeAdd = new ListNode();
								lnodeAdd->SetStartPos(newStartKey);
								lnodeAdd->SetEndPos(newEndKey);
								lnodeAdd->SetLevel(newLevel);
								//add by new key
								ret = index2->insert(&newKey,sizeof(double),lnodeAdd,sizeof(ListNode));

								if (ret != RCOKGist) {
									globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"IndexIncrementalUpdate::keyElementNodeModification",__FILE__,"Cannot insert an entry from the gist index file.");
									delete indexName;
									delete lnodeAdd;
									delete qGet;
									delete iInfo;
									index->close();
									index2->close();
									this->indexMng->fileIndexTable->closeScanIndex();
									return false;
								}

								delete lnodeAdd;
							}
							else if (same && !skip) { 
								//if ac_id_ac_id, do not need another opened index, b/c it's the same file
								//we want to delete lnode -> old key
								
								
								lnodeDel = new ListNode();
								lnodeDel->SetStartPos(oldNode->getKey());
								lnodeDel->SetEndPos(oldNode->getEndKey());
								lnodeDel->SetLevel(oldNode->getLevel());


								qDel = new bt_query_t(bt_query_t::bt_eq,new double(lnode.GetStartPos().toDouble()),NULL,lnodeDel,NULL);
								ret = index->remove(qDel);
								if (ret != RCOKGist) {
									globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"IndexIncrementalUpdate::keyElementNodeModification",__FILE__,"Cannot remove an entry from the gist index file.");
									delete indexName;
									delete qDel;
									delete qGet;
									delete iInfo;
									index->close();
									this->indexMng->fileIndexTable->closeScanIndex();
									return false;
								}
								delete qDel;

								//add lnode-> new key
								double newKey;
								if (lnode.GetStartPos().toDouble() == key) {
									newKey = newStartKey.toDouble();
								}
								else {
									newKey = lnode.GetStartPos().toDouble();
								}

								lnodeAdd = new ListNode();
								lnodeAdd->SetStartPos(newStartKey);
								lnodeAdd->SetEndPos(newEndKey);
								lnodeAdd->SetLevel(newLevel);
								//add by new key
								ret = index->insert(&newKey,sizeof(double),lnodeAdd,sizeof(ListNode));

								if (ret != RCOKGist) {
									globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"IndexIncrementalUpdate::keyElementNodeModification",__FILE__,"Cannot insert an entry from the gist index file.");
									delete indexName;
									delete lnodeAdd;
									delete qGet;
									delete iInfo;
									index->close();
									index2->close();
									this->indexMng->fileIndexTable->closeScanIndex();
									return false;
								}

								delete lnodeAdd;

							}
						//} // if (key != data.key)
						/*else { //key == data.key, usually in case of joining itself
							lnodeDel = new ListNode(lnode);
							qDel = new bt_query_t(bt_query_t::bt_eq,new double(key),NULL,lnodeDel,NULL);
							ret = index->remove(qDel);
							if (ret != RCOKGist) {
								globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"IndexIncrementalUpdate::keyElementNodeModification",__FILE__,"Cannot remove an entry from the gist index file.");
								delete indexName;
								delete qDel;
								delete qGet;
								delete iInfo;
								index->close();
								this->indexMng->fileIndexTable->closeScanIndex();
								return false;
							}
							delete qDel;
						}*/
					}//if (!ret && !eof)
				} //while !eof
				delete qGet;
				index->close();
				if (mirror){
					index2->close();
					delete index2;
				}
			} // if joinindex == elementcontent


		}
	}
	break;
default:
	break;
		} //switch

		delete iInfo;
	}
	this->indexMng->fileIndexTable->closeScanIndex();
	return true;
}

/**
* Process Method
*
* Perform relevant incremental index update in case of key (start, end, level) modification on text node
*
* @param fileinfo The file info type of the xml file to perform incremental index update
* @param oldNode The data node pointer of the node to change its key(s)
* @param newStartKey The anew start key to be changed to
* @param newEndKey The new end key
* @param newLevel The new level value
* @return Whether it has any errors.
*/
bool IndexIncrementalUpdate::keyTextNodeModification(FileInfoType* fileinfo, DM_TextNode* oldNode, KeyType newStartKey, KeyType newEndKey, short newLevel)
{
	IndexInfoType *iInfo;
	ListNode* lnode;
	bt_query_t* qDel;
	int keyInt;
	float keyFloat;
	double keyDouble;
	char* keyChar;
	char* indexName;
	rc_tGist ret;

	//scan for all concerned indices
	this->indexMng->fileIndexTable->startScanIndex(fileinfo->key);
	while ((iInfo = this->indexMng->fileIndexTable->getNextIndexInfo()) != NULL) {

		switch (iInfo->indexDescription) {
case VALUEINDEX_TEXTVALUE :
	{
		//get index name concat with path, and open it
		indexName = new char[strlen(this->indexNamePath) + strlen(iInfo->indexName) + 1];
		strcpy(indexName,this->indexNamePath);
		strcpy(indexName + strlen(this->indexNamePath), iInfo->indexName);


		ret = index->open(indexName);
		if (ret != RCOKGist) {
			globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"IndexIncrementalUpdate::keyTextNodeModification",__FILE__,"Cannot open gist index file.");
			delete indexName;
			delete iInfo;
			this->indexMng->fileIndexTable->closeScanIndex();
			return false;
		}

		if(iInfo->indexType == STRING_INDEX){

			//remove textvalue + oldkey
			keyChar = new char[strlen(oldNode->getCharValue())+1];
			strcpy(keyChar,oldNode->getCharValue());

			lnode = new ListNode();
			lnode->SetStartPos(oldNode->getKey());
			lnode->SetEndPos(oldNode->getEndKey());
			lnode->SetLevel(oldNode->getLevel());
			qDel = new bt_query_t(bt_query_t::bt_eq,keyChar,NULL,lnode,NULL);
			ret = index->remove(qDel);

			if (ret != RCOKGist) {
				globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"IndexIncrementalUpdate::keyTextNodeModification",__FILE__,"Cannot remove an entry from the gist index file.");
				delete indexName;
				delete qDel;
				delete iInfo;
				index->close();
				this->indexMng->fileIndexTable->closeScanIndex();
				return false;
			}
			//add textvalue + newkey
			lnode->SetStartPos(newStartKey);
			lnode->SetEndPos(newEndKey);
			lnode->SetLevel(newLevel);
			ret = index->insert(keyChar,(int)(strlen((char *)keyChar))+1,lnode,sizeof(ListNode));

			if (ret != RCOKGist) {
				globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"IndexIncrementalUpdate::keyTextNodeModification",__FILE__,"Cannot insert an entry from the gist index file.");
				delete indexName;
				delete qDel;
				delete iInfo;
				index->close();
				this->indexMng->fileIndexTable->closeScanIndex();
				return false;
			}

			delete qDel;
		}
		else if (iInfo->indexType == INT_INDEX){
			//remove textvalue + oldkey
			keyInt = atoi(oldNode->getCharValue());

			lnode = new ListNode();
			lnode->SetStartPos(oldNode->getKey());
			lnode->SetEndPos(oldNode->getEndKey());
			lnode->SetLevel(oldNode->getLevel());
			qDel = new bt_query_t(bt_query_t::bt_eq,new int(keyInt),NULL,lnode,NULL);
			ret = index->remove(qDel);

			if (ret != RCOKGist) {
				globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"IndexIncrementalUpdate::keyTextNodeModification",__FILE__,"Cannot remove an entry from the gist index file.");
				delete indexName;
				delete qDel;
				delete iInfo;
				index->close();
				this->indexMng->fileIndexTable->closeScanIndex();
				return false;
			}
			//add textvalue + newkey
			lnode->SetStartPos(newStartKey);
			lnode->SetEndPos(newEndKey);
			lnode->SetLevel(newLevel);
			ret = index->insert(&keyInt,sizeof(int),lnode,sizeof(ListNode));

			if (ret != RCOKGist) {
				globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"IndexIncrementalUpdate::keyTextNodeModification",__FILE__,"Cannot insert an entry from the gist index file.");
				delete indexName;
				delete qDel;
				delete iInfo;
				index->close();
				this->indexMng->fileIndexTable->closeScanIndex();
				return false;
			}

			delete qDel;
		}
		else if (iInfo->indexType == FLOAT_INDEX){
			//remove textvalue + oldkey
			keyFloat = (float)atof(oldNode->getCharValue());

			lnode = new ListNode();
			lnode->SetStartPos(oldNode->getKey());
			lnode->SetEndPos(oldNode->getEndKey());
			lnode->SetLevel(oldNode->getLevel());
			qDel = new bt_query_t(bt_query_t::bt_eq,new float(keyFloat),NULL,lnode,NULL);
			ret = index->remove(qDel);

			if (ret != RCOKGist) {
				globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"IndexIncrementalUpdate::keyTextNodeModification",__FILE__,"Cannot remove an entry from the gist index file.");
				delete indexName;
				delete qDel;
				delete iInfo;
				index->close();
				this->indexMng->fileIndexTable->closeScanIndex();
				return false;
			}
			//add textvalue + newkey
			lnode->SetStartPos(newStartKey);
			lnode->SetEndPos(newEndKey);
			lnode->SetLevel(newLevel);
			ret = index->insert(&keyFloat,sizeof(float),lnode,sizeof(ListNode));

			if (ret != RCOKGist) {
				globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"IndexIncrementalUpdate::keyTextNodeModification",__FILE__,"Cannot insert an entry from the gist index file.");
				delete indexName;
				delete qDel;
				delete iInfo;
				index->close();
				this->indexMng->fileIndexTable->closeScanIndex();
				return false;
			}

			delete qDel;
		}
		else if (iInfo->indexType == DOUBLE_INDEX){
			//remove textvalue + oldkey
			keyDouble = (double)atof(oldNode->getCharValue());

			lnode = new ListNode();
			lnode->SetStartPos(oldNode->getKey());
			lnode->SetEndPos(oldNode->getEndKey());
			lnode->SetLevel(oldNode->getLevel());
			qDel = new bt_query_t(bt_query_t::bt_eq,new double(keyDouble),NULL,lnode,NULL);
			ret = index->remove(qDel);

			if (ret != RCOKGist) {
				globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"IndexIncrementalUpdate::keyTextNodeModification",__FILE__,"Cannot remove an entry from the gist index file.");
				delete indexName;
				delete qDel;
				delete iInfo;
				index->close();
				this->indexMng->fileIndexTable->closeScanIndex();
				return false;
			}
			//add textvalue + newkey
			lnode->SetStartPos(newStartKey);
			lnode->SetEndPos(newEndKey);
			lnode->SetLevel(newLevel);
			ret = index->insert(&keyDouble,sizeof(double),lnode,sizeof(ListNode));

			if (ret != RCOKGist) {
				globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"IndexIncrementalUpdate::keyTextNodeModification",__FILE__,"Cannot insert an entry from the gist index file.");
				delete indexName;
				delete qDel;
				delete iInfo;
				index->close();
				this->indexMng->fileIndexTable->closeScanIndex();
				return false;
			}

			delete qDel;
		}

		index->close();
		delete indexName;
	}
	break;
default:
	break;
		} //switch

		delete iInfo;
	}
	this->indexMng->fileIndexTable->closeScanIndex();
	return true;
}

/**
* Process Method
*
* Perform relevant incremental index update in case of key (start, end, level) modification on attribute node
*
* @param fileinfo The file info type of the xml file to perform incremental index update
* @param oldNode The data node pointer of the node to change its key(s)
* @param newStartKey The anew start key to be changed to
* @param newEndKey The new end key
* @param newLevel The new level value
* @return Whether it has any errors.
*/
bool IndexIncrementalUpdate::keyAttributeNodeModification(FileInfoType* fileinfo, DM_AttributeNode* oldNode, KeyType newStartKey, KeyType newEndKey, short newLevel)
{
	IndexInfoType *iInfo;
	ListNode* lnode;
	bt_query_t* qDel;
	int keyInt;
	float keyFloat;
	double keyDouble;
	char* keyChar;
	char* indexName;
	rc_tGist ret;

	//scan for all concerned indices
	this->indexMng->fileIndexTable->startScanIndex(fileinfo->key);
	while ((iInfo = this->indexMng->fileIndexTable->getNextIndexInfo()) != NULL) {

		switch (iInfo->indexDescription) {
case VALUEINDEX_ATTRIBUTENAME :
	{
		//get index name concat with path, and open it
		indexName = new char[strlen(this->indexNamePath) + strlen(iInfo->indexName) + 1];
		strcpy(indexName,this->indexNamePath);
		strcpy(indexName + strlen(this->indexNamePath), iInfo->indexName);


		ret = index->open(indexName);
		if (ret != RCOKGist) {
			globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"IndexIncrementalUpdate::keyAttributeNodeModification",__FILE__,"Cannot open gist index file.");
			delete indexName;
			delete iInfo;
			this->indexMng->fileIndexTable->closeScanIndex();
			return false;
		}

		//for each attribute name modify data portion with new key
		for (short i = 0 ; i < oldNode->getAttributeNumber() ; i++){
			//remove
			keyChar = new char[strlen(oldNode->getAttributeNameAt(i))+1];
			strcpy(keyChar,oldNode->getAttributeNameAt(i));

			lnode = new ListNode();
			lnode->SetStartPos(oldNode->getKey());
			lnode->SetEndPos(oldNode->getEndKey());
			lnode->SetLevel(oldNode->getLevel());
			qDel = new bt_query_t(bt_query_t::bt_eq,keyChar,NULL,lnode,NULL);
			ret = index->remove(qDel);

			if (ret != RCOKGist) {
				globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"IndexIncrementalUpdate::keyAttributeNodeModification",__FILE__,"Cannot remove an entry from the gist index file.");
				delete indexName;
				delete qDel;
				delete iInfo;
				index->close();
				this->indexMng->fileIndexTable->closeScanIndex();
				return false;
			}
			//add attrname+newkey
			lnode->SetStartPos(newStartKey);
			lnode->SetEndPos(newEndKey);
			lnode->SetLevel(newLevel);
			ret = index->insert(keyChar,(int)(strlen((char *)keyChar))+1,lnode,sizeof(ListNode));

			if (ret != RCOKGist) {
				globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"IndexIncrementalUpdate::keyAttributeNodeModification",__FILE__,"Cannot insert an entry from the gist index file.");
				delete indexName;
				delete qDel;
				delete iInfo;
				index->close();
				this->indexMng->fileIndexTable->closeScanIndex();
				return false;
			}

			delete qDel;
		}

		index->close();
		delete indexName;
	}
	break;
case VALUEINDEX_ATTRIBUTENAME_ID_PAIR:
	{
		//get index name concat with path, and open it
		indexName = new char[strlen(this->indexNamePath) + strlen(iInfo->indexName) + 1];
		strcpy(indexName,this->indexNamePath);
		strcpy(indexName + strlen(this->indexNamePath), iInfo->indexName);

		ret = index->open(indexName);
		if (ret != RCOKGist) {
			globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"IndexIncrementalUpdate::keyAttributeNodeModification",__FILE__,"Cannot open gist index file.");
			delete indexName;
			delete iInfo;
			this->indexMng->fileIndexTable->closeScanIndex();
			return false;
		}

		tagIdIndex = new TagNameAndNodeIdIndex();
		
		//for each attribute name modify data portion with new key
		for (short i = 0 ; i < oldNode->getAttributeNumber() ; i++){
			//remove attrname&key
			bool tRet = this->tagIdIndex->deleteNode(oldNode->getAttributeNameAt(i),oldNode->getKey().toDouble(),index);

			if (tRet != true) {
				globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"IndexIncrementalUpdate::keyAttributeNodeModification",__FILE__,"Cannot remove an entry from the gist index file.");
				delete indexName;
				delete iInfo;
				delete tagIdIndex;
				index->close();
				this->indexMng->fileIndexTable->closeScanIndex();
				return false;
			}

			//add attrname&new key
			lnode = new ListNode();
			lnode->SetStartPos(newStartKey);
			lnode->SetEndPos(newEndKey);
			lnode->SetLevel(newLevel);
			tagIdIndex = new TagNameAndNodeIdIndex();

			//remove tag&key
			tRet = this->tagIdIndex->insertNode(oldNode->getAttributeNameAt(i),newStartKey.toDouble(),lnode,sizeof(ListNode),index);

			if (tRet != true) {
				globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"IndexIncrementalUpdate::keyAttributeNodeModification",__FILE__,"Cannot remove an entry from the gist index file.");
				delete indexName;
				delete iInfo;
				delete lnode;
				delete tagIdIndex;
				index->close();
				this->indexMng->fileIndexTable->closeScanIndex();
				return false;
			}
			delete lnode;
		}
		delete tagIdIndex;
		index->close();
		delete indexName;
	}
	break;
case VALUEINDEX_ATTRIBUTEVALUE :
	{
		//get index name concat with path, and open it
		indexName = new char[strlen(this->indexNamePath) + strlen(iInfo->indexName) + 1];
		strcpy(indexName,this->indexNamePath);
		strcpy(indexName + strlen(this->indexNamePath), iInfo->indexName);


		ret = index->open(indexName);
		if (ret != RCOKGist) {
			globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"IndexIncrementalUpdate::keyAttributeNodeModification",__FILE__,"Cannot open gist index file.");
			delete indexName;
			delete iInfo;
			this->indexMng->fileIndexTable->closeScanIndex();
			return false;
		}

		if(iInfo->indexType == STRING_INDEX){
			//for each attribute value modify data portion with new key
			for (short i = 0 ; i < oldNode->getAttributeNumber() ; i++){
				//remove
				keyChar = new char[strlen(oldNode->getAttrAt(i)->getStrValue())+1];
				strcpy(keyChar,oldNode->getAttrAt(i)->getStrValue());

				lnode = new ListNode();
				lnode->SetStartPos(oldNode->getKey());
				lnode->SetEndPos(oldNode->getEndKey());
				lnode->SetLevel(oldNode->getLevel());
				qDel = new bt_query_t(bt_query_t::bt_eq,keyChar,NULL,lnode,NULL);
				ret = index->remove(qDel);

				if (ret != RCOKGist) {
					globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"IndexIncrementalUpdate::keyAttributeNodeModification",__FILE__,"Cannot remove an entry from the gist index file.");
					delete indexName;
					delete qDel;
					delete iInfo;
					index->close();
					this->indexMng->fileIndexTable->closeScanIndex();
					return false;
				}
				//add textvalue + newkey
				lnode->SetStartPos(newStartKey);
				lnode->SetEndPos(newEndKey);
				lnode->SetLevel(newLevel);
				ret = index->insert(keyChar,(int)(strlen((char *)keyChar))+1,lnode,sizeof(ListNode));

				if (ret != RCOKGist) {
					globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"IndexIncrementalUpdate::keyAttributeNodeModification",__FILE__,"Cannot insert an entry from the gist index file.");
					delete indexName;
					delete qDel;
					delete iInfo;
					index->close();
					this->indexMng->fileIndexTable->closeScanIndex();
					return false;
				}

				delete qDel;
			}//for

		}
		else if (iInfo->indexType == INT_INDEX){
			//for each attribute value modify data portion with new key
			for (short i = 0 ; i < oldNode->getAttributeNumber() ; i++){
				//remove
				keyInt = atoi(oldNode->getAttrAt(i)->getStrValue());

				lnode = new ListNode();
				lnode->SetStartPos(oldNode->getKey());
				lnode->SetEndPos(oldNode->getEndKey());
				lnode->SetLevel(oldNode->getLevel());
				qDel = new bt_query_t(bt_query_t::bt_eq,new int(keyInt),NULL,lnode,NULL);
				ret = index->remove(qDel);

				if (ret != RCOKGist) {
					globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"IndexIncrementalUpdate::keyAttributeNodeModification",__FILE__,"Cannot remove an entry from the gist index file.");
					delete indexName;
					delete qDel;
					delete iInfo;
					index->close();
					this->indexMng->fileIndexTable->closeScanIndex();
					return false;
				}
				//add textvalue + newkey
				lnode->SetStartPos(newStartKey);
				lnode->SetEndPos(newEndKey);
				lnode->SetLevel(newLevel);
				ret = index->insert(&keyInt,sizeof(int),lnode,sizeof(ListNode));

				if (ret != RCOKGist) {
					globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"IndexIncrementalUpdate::keyAttributeNodeModification",__FILE__,"Cannot insert an entry from the gist index file.");
					delete indexName;
					delete qDel;
					delete iInfo;
					index->close();
					this->indexMng->fileIndexTable->closeScanIndex();
					return false;
				}

				delete qDel;
			}//for
		}
		else if (iInfo->indexType == FLOAT_INDEX){
			//for each attribute value modify data portion with new key
			for (short i = 0 ; i < oldNode->getAttributeNumber() ; i++){
				//remove
				keyFloat = (float)atof(oldNode->getAttrAt(i)->getStrValue());

				lnode = new ListNode();
				lnode->SetStartPos(oldNode->getKey());
				lnode->SetEndPos(oldNode->getEndKey());
				lnode->SetLevel(oldNode->getLevel());
				qDel = new bt_query_t(bt_query_t::bt_eq,new float(keyFloat),NULL,lnode,NULL);
				ret = index->remove(qDel);

				if (ret != RCOKGist) {
					globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"IndexIncrementalUpdate::keyAttributeNodeModification",__FILE__,"Cannot remove an entry from the gist index file.");
					delete indexName;
					delete qDel;
					delete iInfo;
					index->close();
					this->indexMng->fileIndexTable->closeScanIndex();
					return false;
				}
				//add textvalue + newkey
				lnode->SetStartPos(newStartKey);
				lnode->SetEndPos(newEndKey);
				lnode->SetLevel(newLevel);
				ret = index->insert(&keyFloat,sizeof(float),lnode,sizeof(ListNode));

				if (ret != RCOKGist) {
					globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"IndexIncrementalUpdate::keyAttributeNodeModification",__FILE__,"Cannot insert an entry from the gist index file.");
					delete indexName;
					delete qDel;
					delete iInfo;
					index->close();
					this->indexMng->fileIndexTable->closeScanIndex();
					return false;
				}

				delete qDel;
			}//for
		}
		else if (iInfo->indexType == DOUBLE_INDEX){
			//for each attribute value modify data portion with new key
			for (short i = 0 ; i < oldNode->getAttributeNumber() ; i++){
				//remove
				keyDouble = (double)atof(oldNode->getAttrAt(i)->getStrValue());

				lnode = new ListNode();
				lnode->SetStartPos(oldNode->getKey());
				lnode->SetEndPos(oldNode->getEndKey());
				lnode->SetLevel(oldNode->getLevel());
				qDel = new bt_query_t(bt_query_t::bt_eq,new double(keyDouble),NULL,lnode,NULL);
				ret = index->remove(qDel);

				if (ret != RCOKGist) {
					globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"IndexIncrementalUpdate::keyAttributeNodeModification",__FILE__,"Cannot remove an entry from the gist index file.");
					delete indexName;
					delete qDel;
					delete iInfo;
					index->close();
					this->indexMng->fileIndexTable->closeScanIndex();
					return false;
				}
				//add textvalue + newkey
				lnode->SetStartPos(newStartKey);
				lnode->SetEndPos(newEndKey);
				lnode->SetLevel(newLevel);
				ret = index->insert(&keyDouble,sizeof(double),lnode,sizeof(ListNode));

				if (ret != RCOKGist) {
					globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"IndexIncrementalUpdate::keyAttributeNodeModification",__FILE__,"Cannot insert an entry from the gist index file.");
					delete indexName;
					delete qDel;
					delete iInfo;
					index->close();
					this->indexMng->fileIndexTable->closeScanIndex();
					return false;
				}

				delete qDel;
			}//for
		}
		index->close();
		delete indexName;
	}
	break;
case JOININDEX:
	{
		bool mirror = false, same = false; //whether mirror index exist, and successfully opened for operation
		char* indexName2;
		gist* index2 = new gist;
		if (iInfo->leftSideType == JOININDEX_ATTRIBUTEVALUE) {

			short attrat = -1;

			//for each attribute name, value pair, find matching attrname == the left side of this index
			for (short i = 0 ; i < oldNode->getAttributeNumber() ; i++) {
				if (strcmp(oldNode->getAttributeNameAt(i),iInfo->leftSide) == 0) {
					attrat = i;
					break;
				}
			}


			//check whether left side = this attrname
			if (attrat != -1) {
				//get index name concat with path, and open it
				indexName = new char[strlen(this->indexNamePath) + strlen(iInfo->indexName) + 1];
				strcpy(indexName,this->indexNamePath);
				strcpy(indexName + strlen(this->indexNamePath), iInfo->indexName);

					

				ret = index->open(indexName);
				if (ret != RCOKGist) {
					globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"IndexIncrementalUpdate::keyAttributeNodeModification",__FILE__,"Cannot open gist index file.");
					delete indexName;
					delete iInfo;
					this->indexMng->fileIndexTable->closeScanIndex();
					return false;
				}

				//get mirror only if mirror name is different than this name
				char indexMirror[MAX_INDEX_NAME_LENGTH];
				bool rc = this->indexMng->constructIndexName(iInfo->fileName,indexMirror,JOININDEX,NULL,DOUBLE_INDEX,iInfo->rightSide,iInfo->rightSideType,iInfo->leftSide,iInfo->leftSideType);
				if (strcmp(indexMirror,iInfo->indexName) != 0) {
					if (rc && this->indexMng->existIndex(indexMirror)) {
						indexName2 = new char[strlen(this->indexNamePath) + strlen(indexMirror) + 1];
						strcpy(indexName2,this->indexNamePath);
						strcpy(indexName2 + strlen(this->indexNamePath), indexMirror);

						ret = index2->open(indexName2);
						if (ret == RCOKGist) {
							mirror = true;
						}
						delete indexName2;
					}
				}
				else { //ac_id_ac_id
					same = true;
				}

				bt_query_t *qGet, *qDel;
				gist_cursor_t cursor;
				bool eof = false;
				unsigned long keysz, datasz;
				double key;
				ListNode lnode;
				ListNode  *lnodeDel, *lnodeAdd;

				qGet = new bt_query_t(bt_query_t::bt_eq,new double(oldNode->getKey().toDouble()),NULL);

				cursor.k = 0;
				cursor.io = 0;
				cursor.query = NULL;
				cursor.ext = NULL;
				cursor.cext = NULL;
				cursor.iter = NULL;
				cursor.state = NULL;
				index->fetch_init(cursor, qGet);


				//retrieve key,data pair
				while (!eof) {
					ret = index->fetch(cursor, &key, keysz, (void *)&lnode, datasz, eof);
					bool skip = false;
					if (!ret && !eof){

						//if (key != lnode.GetStartPos().toDouble()) {
							//no false positive b/c one attrname only for one attrnode
							//cout << key << "-" << lnode.GetStartPos().toDouble() << endl;
							lnodeDel = new ListNode(lnode);
							//delete the key,data
							qDel = new bt_query_t(bt_query_t::bt_eq,new double(key),NULL,lnodeDel,NULL);
							ret = index->remove(qDel);
							if (ret != RCOKGist) {
								globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"IndexIncrementalUpdate::keyAttributeNodeModification",__FILE__,"Cannot remove an entry from the gist index file.");
								delete indexName;
								delete qDel;
								delete qGet;
								delete iInfo;
								index->close();
								index2->close();
								this->indexMng->fileIndexTable->closeScanIndex();
								return false;
							}
							delete qDel;

							double newKey = newStartKey.toDouble();
							if (lnode.GetStartPos().toDouble() == key) {
								lnodeAdd = new ListNode();
								lnodeAdd->SetStartPos(newStartKey);
								lnodeAdd->SetEndPos(newEndKey);
								lnodeAdd->SetLevel(newLevel);
								skip = true; 
								// in case of av_id_av_id if 4 == 4, we change to 5 == 5, 
								// then we do not find 4 = 4 for another time since it has only one, 
								// so we do not add more than once
							}
							else lnodeAdd = new ListNode(lnode);

							//add by new key
							ret = index->insert(&newKey,sizeof(double),lnodeAdd,sizeof(ListNode));

							if (ret != RCOKGist) {
								globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"IndexIncrementalUpdate::keyAttributeNodeModification",__FILE__,"Cannot insert an entry from the gist index file.");
								delete indexName;
								delete qGet;
								delete iInfo;
								delete lnodeAdd;
								index->close();
								index2->close();
								this->indexMng->fileIndexTable->closeScanIndex();
								return false;
							}

							delete lnodeAdd;


							//then delete+add the mirror index if found one
							if (mirror) {
								lnodeDel = new ListNode();
								lnodeDel->SetStartPos(oldNode->getKey());
								lnodeDel->SetEndPos(oldNode->getEndKey());
								lnodeDel->SetLevel(oldNode->getLevel());

								qDel = new bt_query_t(bt_query_t::bt_eq,new double(lnode.GetStartPos().toDouble()),NULL,lnodeDel,NULL);
								ret = index2->remove(qDel);
								if (ret != RCOKGist) {
									globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"IndexIncrementalUpdate::keyAttributeNodeModification",__FILE__,"Cannot remove an entry from the gist index file.");
									delete indexName;
									delete qDel;
									delete qGet;
									delete iInfo;
									index->close();
									index2->close();
									this->indexMng->fileIndexTable->closeScanIndex();
									return false;
								}
								delete qDel;

								newKey = lnode.GetStartPos().toDouble();
								lnodeAdd = new ListNode();
								lnodeAdd->SetStartPos(newStartKey);
								lnodeAdd->SetEndPos(newEndKey);
								lnodeAdd->SetLevel(newLevel);
								//add by new key
								ret = index2->insert(&newKey,sizeof(double),lnodeAdd,sizeof(ListNode));

								if (ret != RCOKGist) {
									globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"IndexIncrementalUpdate::keyAttributeNodeModification",__FILE__,"Cannot insert an entry from the gist index file.");
									delete indexName;
									delete lnodeAdd;
									delete qGet;
									delete iInfo;
									index->close();
									index2->close();
									this->indexMng->fileIndexTable->closeScanIndex();
									return false;
								}

								delete lnodeAdd;
							}
							else if (same && !skip) { 
								//if ac_id_ac_id, do not need another opened index, b/c it's the same file
								//we want to delete lnode -> old key
								
								
								lnodeDel = new ListNode();
								lnodeDel->SetStartPos(oldNode->getKey());
								lnodeDel->SetEndPos(oldNode->getEndKey());
								lnodeDel->SetLevel(oldNode->getLevel());


								qDel = new bt_query_t(bt_query_t::bt_eq,new double(lnode.GetStartPos().toDouble()),NULL,lnodeDel,NULL);
								ret = index->remove(qDel);
								if (ret != RCOKGist) {
									globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"IndexIncrementalUpdate::keyAttributeNodeModification",__FILE__,"Cannot remove an entry from the gist index file.");
									delete indexName;
									delete qDel;
									delete qGet;
									delete iInfo;
									index->close();
									this->indexMng->fileIndexTable->closeScanIndex();
									return false;
								}
								delete qDel;

								//add lnode-> new key
								double newKey;
								if (lnode.GetStartPos().toDouble() == key) {
									newKey = newStartKey.toDouble();
								}
								else {
									newKey = lnode.GetStartPos().toDouble();
								}

								lnodeAdd = new ListNode();
								lnodeAdd->SetStartPos(newStartKey);
								lnodeAdd->SetEndPos(newEndKey);
								lnodeAdd->SetLevel(newLevel);
								//add by new key
								ret = index->insert(&newKey,sizeof(double),lnodeAdd,sizeof(ListNode));

								if (ret != RCOKGist) {
									globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"IndexIncrementalUpdate::keyAttributeNodeModification",__FILE__,"Cannot insert an entry from the gist index file.");
									delete indexName;
									delete lnodeAdd;
									delete qGet;
									delete iInfo;
									index->close();
									index2->close();
									this->indexMng->fileIndexTable->closeScanIndex();
									return false;
								}

								delete lnodeAdd;

							}
						//} // if (key != data.key)
						/*else { //key == data.key, usually in case of joining itself
							lnodeDel = new ListNode(lnode);
							qDel = new bt_query_t(bt_query_t::bt_eq,new double(key),NULL,lnodeDel,NULL);
							ret = index->remove(qDel);
							if (ret != RCOKGist) {
								globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"IndexIncrementalUpdate::keyAttributeNodeModification",__FILE__,"Cannot remove an entry from the gist index file.");
								delete indexName;
								delete qDel;
								delete qGet;
								delete iInfo;
								index->close();
								this->indexMng->fileIndexTable->closeScanIndex();
								return false;
							}
							delete qDel;
						}*/
					}//if (!ret && !eof)
				} //while !eof
				delete qGet;
				index->close();
				if (mirror){
					index2->close();
					delete index2;
				}
			} // if joinindex == elementcontent


		}
	}
	break;
default:
	break;
		} //switch

		delete iInfo;
	}
	this->indexMng->fileIndexTable->closeScanIndex();
	return true;
}