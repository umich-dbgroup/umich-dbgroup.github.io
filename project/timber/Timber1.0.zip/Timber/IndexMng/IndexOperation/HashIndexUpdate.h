/*
COPYRIGHT  (c) 2000-2004 
THE REGENTS OF THE UNIVERSITY OF MICHIGAN
ALL RIGHTS RESERVED

PERMISSION IS GRANTED TO USE, COPY, CREATE DERIVATIVE WORKS AND
REDISTRIBUTE THIS SOFTWARE AND SUCH DERIVATIVE WORKS FOR NONCOMMERCIAL
EDUCATION AND RESEARCH PURPOSES, SO LONG AS NO FEE IS CHARGED, AND SO LONG
AS THE COPYRIGHT NOTICE ABOVE, THIS GRANT OF PERMISSION, AND THE
DISCLAIMER BELOW APPEAR IN ALL COPIES MADE; AND SO LONG AS THE NAME OF THE
UNIVERSITY OF MICHIGAN IS NOT USED IN ANY ADVERTISING OR PUBLICITY
PERTAINING TO THE USE OR DISTRIBUTION OF THIS SOFTWARE WITHOUT SPECIFIC,
WRITTEN PRIOR AUTHORIZATION.

THIS SOFTWARE IS PROVIDED AS IS, WITHOUT REPRESENTATION FROM THE
UNIVERSITY OF MICHIGAN AS TO ITS FITNESS FOR ANY PURPOSE, AND WITHOUT
WARRANTY BY THE UNIVERSITY OF MICHIGAN OF ANY KIND, EITHER EXPRESS OR
IMPLIED, INCLUDING WITHOUT LIMITATION THE IMPLIED WARRANTIES OF
MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE. THE REGENTS OF THE
UNIVERSITY OF MICHIGAN SHALL NOT BE LIABLE FOR ANY DAMAGES, INCLUDING
SPECIAL, INDIRECT, INCIDENTAL, OR CONSEQUENTIAL DAMAGES, WITH RESPECT TO
ANY CLAIM ARISING OUT OF OR IN CONNECTION WITH THE USE OF THE SOFTWARE,
EVEN IF IT HAS BEEN OR IS HEREAFTER ADVISED OF THE POSSIBILITY OF SUCH
DAMAGES.
*/

#ifndef __HashIndexUpdate_h
#define __HashIndexUpdate_h

#include "../Common/ListNode.h"
#include "../Common/ContainerClass.h"
//#include "../../IndexMng/IndexOperation/GistIndexUpdate.h"

/**
* HashIndexUpdate
* 
* This class provides hash indices manipulation
* 
* @version 1.0
*/

class HashIndexUpdate
{
public:


	/**
	* Constructor
	*
	* @param indexName The name of the index
	* @param indexType The tpye of the index (int, float, string)
	*/
	HashIndexUpdate(char *indexName,int indexType);	

	/**
	* Destructor
	*/
	~HashIndexUpdate();

	void create();
	void open();

	/**
	* Insert <key,data> pair to the index
	*
	* @param insertedKey Key to be inserted
	* @param insertedData Data to be inserted in ListNode type
	* @returns Error code
	*/
	int insert(void *insertedKey,ListNode insertedData);

	/**
	* Get number of records in the indices inserted in this session
	* 
	* @returns Number of records
	*/
	int getRecordNumber();

	/**
	* Close an index
	*
	* @param Error code
	*/
	int close();

private:

	/**
	* write Container
	*
	* @param Error code
	*/
	int writeContainer();

	/**
	* write Range 
	*
	* @param startRange The start of the range
	* @param Error code
	*/
	int writeRange(void *startRange);
	char *indexName;
	FILE *indexFile;

	FILE *rangeTableFile; 
	int numRanges;

	//index replacing table
	//gist *rangeIndex;


	int indexType;
	int recordNumber;
	int keySize;
	int dataSize;
	int contMaxSize;
	ContainerClass cont;
	char *buffer;
	int recSize;
};

#endif