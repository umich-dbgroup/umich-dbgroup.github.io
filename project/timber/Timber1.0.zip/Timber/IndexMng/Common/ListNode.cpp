/*
COPYRIGHT  (c) 2000-2004 
THE REGENTS OF THE UNIVERSITY OF MICHIGAN
ALL RIGHTS RESERVED

PERMISSION IS GRANTED TO USE, COPY, CREATE DERIVATIVE WORKS AND
REDISTRIBUTE THIS SOFTWARE AND SUCH DERIVATIVE WORKS FOR NONCOMMERCIAL
EDUCATION AND RESEARCH PURPOSES, SO LONG AS NO FEE IS CHARGED, AND SO LONG
AS THE COPYRIGHT NOTICE ABOVE, THIS GRANT OF PERMISSION, AND THE
DISCLAIMER BELOW APPEAR IN ALL COPIES MADE; AND SO LONG AS THE NAME OF THE
UNIVERSITY OF MICHIGAN IS NOT USED IN ANY ADVERTISING OR PUBLICITY
PERTAINING TO THE USE OR DISTRIBUTION OF THIS SOFTWARE WITHOUT SPECIFIC,
WRITTEN PRIOR AUTHORIZATION.

THIS SOFTWARE IS PROVIDED AS IS, WITHOUT REPRESENTATION FROM THE
UNIVERSITY OF MICHIGAN AS TO ITS FITNESS FOR ANY PURPOSE, AND WITHOUT
WARRANTY BY THE UNIVERSITY OF MICHIGAN OF ANY KIND, EITHER EXPRESS OR
IMPLIED, INCLUDING WITHOUT LIMITATION THE IMPLIED WARRANTIES OF
MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE. THE REGENTS OF THE
UNIVERSITY OF MICHIGAN SHALL NOT BE LIABLE FOR ANY DAMAGES, INCLUDING
SPECIAL, INDIRECT, INCIDENTAL, OR CONSEQUENTIAL DAMAGES, WITH RESPECT TO
ANY CLAIM ARISING OUT OF OR IN CONNECTION WITH THE USE OF THE SOFTWARE,
EVEN IF IT HAS BEEN OR IS HEREAFTER ADVISED OF THE POSSIBILITY OF SUCH
DAMAGES.
*/

#include "ListNode.h"

ListNode::ListNode()
{
    initialize();
}

ListNode::~ListNode()
{
}

ListNode::ListNode(ListNode* lNode)
{
	this->startPos = lNode->startPos;
	this->endPos = lNode->endPos;
	this->level = lNode->level;
	this->offset = lNode->offset;
	this->nre = lNode->nre;
	this->fileIndex = lNode->fileIndex;
}

void ListNode::initialize()
{
    startPos =  -1;
    endPos = -1;
    level = -1;
    offset = -1;
	nre = DEFAULT_NODES_NRE;
	fileIndex = -1;

    //// CONG: remove after inex
    //seckey = -1;
    //articlekey = -1;
}

void ListNode::SetStartPos(KeyType startPos)
{
    this->startPos = startPos;
}

KeyType ListNode::GetStartPos()
{
    return startPos;
}

void ListNode::SetEndPos(KeyType endPos)
{
    this->endPos = endPos;
}

KeyType ListNode::GetEndPos()
{
    return endPos;
}

void ListNode::SetLevel(short level)
{
    this->level = level;
}

short ListNode::GetLevel()
{
    return level;
}

void ListNode::SetOffset(short offset)
{
    this->offset = offset;
}

short ListNode::GetOffset()
{
    return offset;
}

bool ListNode::isAncsOf(ListNode *potentialDesc)
{
    return (startPos < potentialDesc->GetStartPos() && 
            endPos > potentialDesc->GetEndPos());
}

bool ListNode::isDescOf(ListNode *potentialAncs)
{
    return (startPos > potentialAncs->GetStartPos() && 
            endPos < potentialAncs->GetEndPos());
}

bool ListNode::isNotContainedIn(ListNode *someNode)
{
    return (startPos > someNode->GetEndPos() || endPos < someNode->GetStartPos());
}

bool ListNode::isParentOf(ListNode *potentialChild)
{
    short childLev = potentialChild->GetLevel() -1;
    return (startPos < potentialChild->GetStartPos() && 
            endPos > potentialChild->GetEndPos() && 
            level == childLev);
}

bool ListNode::isChildOf(ListNode *potentialParent)
{
    short parentLev = potentialParent->GetLevel() + 1;
    return (startPos > potentialParent->GetStartPos() && 
            endPos < potentialParent->GetEndPos() && 
            level == parentLev);
}

void ListNode::setFileIndex(char fileIndex)
{
    this->fileIndex = fileIndex;
}

char ListNode::getFileIndex()
{
    return this->fileIndex;
}


NREType ListNode::getNRE()
{
	return nre;
}

void ListNode::setNRE(NREType nre)
{
	this->nre = nre;
}
