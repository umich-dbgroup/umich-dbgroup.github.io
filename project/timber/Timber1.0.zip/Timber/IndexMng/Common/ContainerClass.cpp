/*
COPYRIGHT  (c) 2000-2004 
THE REGENTS OF THE UNIVERSITY OF MICHIGAN
ALL RIGHTS RESERVED

PERMISSION IS GRANTED TO USE, COPY, CREATE DERIVATIVE WORKS AND
REDISTRIBUTE THIS SOFTWARE AND SUCH DERIVATIVE WORKS FOR NONCOMMERCIAL
EDUCATION AND RESEARCH PURPOSES, SO LONG AS NO FEE IS CHARGED, AND SO LONG
AS THE COPYRIGHT NOTICE ABOVE, THIS GRANT OF PERMISSION, AND THE
DISCLAIMER BELOW APPEAR IN ALL COPIES MADE; AND SO LONG AS THE NAME OF THE
UNIVERSITY OF MICHIGAN IS NOT USED IN ANY ADVERTISING OR PUBLICITY
PERTAINING TO THE USE OR DISTRIBUTION OF THIS SOFTWARE WITHOUT SPECIFIC,
WRITTEN PRIOR AUTHORIZATION.

THIS SOFTWARE IS PROVIDED AS IS, WITHOUT REPRESENTATION FROM THE
UNIVERSITY OF MICHIGAN AS TO ITS FITNESS FOR ANY PURPOSE, AND WITHOUT
WARRANTY BY THE UNIVERSITY OF MICHIGAN OF ANY KIND, EITHER EXPRESS OR
IMPLIED, INCLUDING WITHOUT LIMITATION THE IMPLIED WARRANTIES OF
MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE. THE REGENTS OF THE
UNIVERSITY OF MICHIGAN SHALL NOT BE LIABLE FOR ANY DAMAGES, INCLUDING
SPECIAL, INDIRECT, INCIDENTAL, OR CONSEQUENTIAL DAMAGES, WITH RESPECT TO
ANY CLAIM ARISING OUT OF OR IN CONNECTION WITH THE USE OF THE SOFTWARE,
EVEN IF IT HAS BEEN OR IS HEREAFTER ADVISED OF THE POSSIBILITY OF SUCH
DAMAGES.
*/

#include "ContainerClass.h"

/**
* Constructor
* Initialize the variables.
*@param size is the size of the container. default is CONTAINER_SIZE
*/
ContainerClass::ContainerClass()
{
	this->size = gSettings->getIntegerValue("CONTAINER_SIZE",CONTAINER_SIZE_DEFAULT);
	this->container = NULL; //new char[size];
	
	Initialize();
}

/**
* Destructor
* nothing.
*/
ContainerClass::~ContainerClass()
{
	if (container) delete [] container;
}

/**
* Initialization
* Initialize the variables. called by the constructor.
*/
void ContainerClass::Initialize()
{
	addCursor = 0;
	scanCursor = 0;
	oldScanCursor = -1;
	unitCursor = 0;
	unitCursorEnd = 0;
}

/**
* Access Method
* decides whether or not the container is full.
*@returns true if the container is full. otherwise, returns false.
*/
bool ContainerClass::IsFull()
{
	return (addCursor==size?true:false);
}

/**
* Access Method
* decides whether or not the container is empty.
*@returns true if the container is empty. otherwise, returns false.
*/
bool ContainerClass::IsEmpty()
{
	return (addCursor == 0?true:false);
}

/**
* Access Method
* decides whether or not the container has enough space to accomedate a given number of bytes.
*@param size is the number of bytes we want to check if they can fit in the container.
*@returns true if the container can accomedate size. otherwise, returns false.
*/
bool ContainerClass::EnoughSpace(int size)
{
	int spaceLeft = this->size - this->addCursor - 1;
	return (size <= spaceLeft);
}

/**
* Access Method
* decides whether or not you will be exceeding the adding cursor (you will be getting junk) 
* if you decide to read from the scanning cursor for size number of bytes. 
*@param size is the number of bytes we are planning on reading.
*@returns true if the adding cursor is exceeded. otherwise, returns false.
*/
bool ContainerClass::ExceedBoundry(int size)
{
	return (scanCursor+size <= addCursor?false:true);
}


/**
* Access Method
* decides whether or not you will be exceeding the adding cursor (you will be getting junk) 
* if you decide to read from location start for size number of bytes. 
*@param start is the location to start from in the contianer to check for exceeding boundry.
*@param size is the number of bytes we are planning on reading.
*@returns true if the adding cursor is exceeded. otherwise, returns false.
*/
bool ContainerClass::ExceedBoundry(int start ,int size)
{
	return (start+size <= addCursor?false:true);
}

/**
* Access Method
* Gets the value of the adding cursor.
*@returns the value of the adding cursor.
*/
int ContainerClass::GetAddCursor()
{
	return addCursor;
}

/**
* Access Method
* Gets the value of the scanning cursor.
*@returns the value of the scanning cursor.
*/
int ContainerClass::GetScanCursor()
{
	return scanCursor;
}

/**
* Access Method
* Gets the previous value of the scanning cursor.
*@returns the previous value of the scanning cursor.
*/
int ContainerClass::GetOldScanCursor()
{
	return oldScanCursor;
}

/**
* Process Method
* assigns a new value to the scan cursor.
*@param scanCursor is the new value of scanCursor.
*/
void ContainerClass::SetScanCursor(int scanCursor)
{
	this->scanCursor = scanCursor;
}

/**
* Process Method
* assigns a new value to the add cursor.
*@param addCursor is the new value of addCursor.
*/
void ContainerClass::SetAddCursor(int addCursor)
{
	this->addCursor = addCursor;
}

/**
* Process Method
* writes data in newData into the container at the add cursor location. 
* this operation advances the add cursor by length.
*@param newData is a buffer holding the data
*@param length is the size of teh data to written.
*@returns SUCCESS if the data was written. If the container is full or newData
* is NULL, FAILURE is returned.
*/
int ContainerClass::AddData(char *newData,int length)
{
	if (newData == NULL)
		return FAILURE;
	if (!(this->EnoughSpace(length)))
		return FAILURE;
	if (!container)
	{
		container = new char[size];
		container[this->size - 1] = '\0';
	}
	memcpy(container+addCursor,newData,length);
	addCursor+=length;
	return SUCCESS;
}

/**
* Access Method
*@returns a pointer to the actual buffer.
*/
char *ContainerClass::GetContianer()
{
	return container;
}

/**
* Access Method
* reads data from location start for length number of bytes and puts the read section in data. 
*@param start is the location in the container to start reading from.
*@param length is the number of bytes we are planning on reading.
*@param data is a buffer passed in to hold the data read from the container.
*@returns SUCCESS if the data was read. If the container is empty or the adding cursor
* is exceeded, FAILURE is returned.
*/
int ContainerClass::GetData(int start, int length, char *data)
{
	if (IsEmpty())
		return FAILURE;
	
	if (!container)
	{
		container = new char[size];
		container[this->size - 1] = '\0';
	}

	if (!ExceedBoundry(start, length))
	{
		memcpy(data,container+start,length);
		return SUCCESS;
	}
	else 
		return FAILURE;
}

/**
* Access Method
* reads data from scan cursor for length number of bytes and puts the read section in data. 
* this operation advances the scan cursor by length.
*@param length is the number of bytes we are planning on reading.
*@param data is a buffer passed in to hold the data read from the container.
*@returns SUCCESS if the data was read. If the container is empty or the adding cursor
* is exceeded, FAILURE is returned.
*/
int ContainerClass::GetNext(int length, char *data, bool updateUnitCursor, bool updateUnitCursorEnd)
{
	if (IsEmpty()){
		return FAILURE;
	}

	if (length == 0){
		return FAILURE;
	}
	if (!ExceedBoundry(length))
	{
		oldScanCursor = scanCursor;
		if (updateUnitCursor)
			unitCursor = scanCursor;
		memcpy(data,container+scanCursor,length);
		scanCursor+=length;
		if (updateUnitCursorEnd)
			unitCursorEnd = scanCursor;
		return SUCCESS;
	}
	else {
		return FAILURE;
	}
}

/**
* Access Method
*@returns teh maximum size of this container.
*/
int ContainerClass::GetSize()
{
	return size;
}

/**
* Access Method
* reads data from scan cursor and returns a pointer to it. 
* this operation advances the scan cursor by length.
*@param length is the number of bytes we are planning on reading.
*@returns a pointer to the data read. If the container is empty or the adding cursor
* is exceeded, NULL is returned.
*/
char *ContainerClass::GetNextPtr(int length, bool updateUnitCursor, bool updateUnitCursorEnd)
{
	if (IsEmpty())
		return NULL;
	
	if (length == 0)
		return NULL;
	
	if (!ExceedBoundry(length))
	{
		oldScanCursor = scanCursor;
		if (updateUnitCursor)
			unitCursor = scanCursor;
		scanCursor+=length;
		if (updateUnitCursorEnd)
			unitCursorEnd = scanCursor;
		return container+oldScanCursor;
	}
	else 
		return NULL;
}

/**
* Process Method
* copies a container cont to this container.
*@param cont is a container that we want to copy to this container.
*/
void ContainerClass::CopyContainer(ContainerClass *cont)
{
	/*	char tmpStr[CONTAINER_SIZE];
	Initialize();
	cont->GetData(0,cont->GetAddCursor(),tmpStr);
	AddData(tmpStr,cont->GetAddCursor());*/
	this->Initialize();
	AddData(cont->GetContianer(),cont->GetAddCursor());
}

/**
*cursor that indicates how much has been added to the container.
*/
bool ContainerClass::reachedEndOfContainer()
{
	return addCursor == scanCursor;
}

/**
*cursor that indicates how much has been scanned from the container.
*/
void ContainerClass::decrementScanCursor()
{
	scanCursor = unitCursor;
}

/**
*cursor that holds a previous value of scan cursor
*/
void ContainerClass::advanceScanCursor()
{
	scanCursor = unitCursorEnd;
}

void ContainerClass::nullifyContainer()
{
	this->container = NULL;
	this->Initialize();
}