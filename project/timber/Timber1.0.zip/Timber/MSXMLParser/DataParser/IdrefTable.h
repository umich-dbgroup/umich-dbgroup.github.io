/*
COPYRIGHT  (c) 2000-2004 
THE REGENTS OF THE UNIVERSITY OF MICHIGAN
ALL RIGHTS RESERVED

PERMISSION IS GRANTED TO USE, COPY, CREATE DERIVATIVE WORKS AND
REDISTRIBUTE THIS SOFTWARE AND SUCH DERIVATIVE WORKS FOR NONCOMMERCIAL
EDUCATION AND RESEARCH PURPOSES, SO LONG AS NO FEE IS CHARGED, AND SO LONG
AS THE COPYRIGHT NOTICE ABOVE, THIS GRANT OF PERMISSION, AND THE
DISCLAIMER BELOW APPEAR IN ALL COPIES MADE; AND SO LONG AS THE NAME OF THE
UNIVERSITY OF MICHIGAN IS NOT USED IN ANY ADVERTISING OR PUBLICITY
PERTAINING TO THE USE OR DISTRIBUTION OF THIS SOFTWARE WITHOUT SPECIFIC,
WRITTEN PRIOR AUTHORIZATION.

THIS SOFTWARE IS PROVIDED AS IS, WITHOUT REPRESENTATION FROM THE
UNIVERSITY OF MICHIGAN AS TO ITS FITNESS FOR ANY PURPOSE, AND WITHOUT
WARRANTY BY THE UNIVERSITY OF MICHIGAN OF ANY KIND, EITHER EXPRESS OR
IMPLIED, INCLUDING WITHOUT LIMITATION THE IMPLIED WARRANTIES OF
MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE. THE REGENTS OF THE
UNIVERSITY OF MICHIGAN SHALL NOT BE LIABLE FOR ANY DAMAGES, INCLUDING
SPECIAL, INDIRECT, INCIDENTAL, OR CONSEQUENTIAL DAMAGES, WITH RESPECT TO
ANY CLAIM ARISING OUT OF OR IN CONNECTION WITH THE USE OF THE SOFTWARE,
EVEN IF IT HAS BEEN OR IS HEREAFTER ADVISED OF THE POSSIBILITY OF SUCH
DAMAGES.
*/

/**
* @author Nuwee Wiwatwattana
*/

#ifndef __IDREFTABLE_H
#define __IDREFTABLE_H

#include <map>
#include "../Treestructure/TreeStructure_definitions.h"
#include "../Treestructure/Value.h"

/**
* class IdrefTable
* 
* This class provide a mapping table for converting id/idref attributes 
* to multicolor model
*
* The key is "id" attribute value
* In case of id, we keep the node id key
* In case of idref, other than keeping node id key, we also have
* the direction that Multicolor node will be duplicated to
* and an optional flag
* 
* @see MSXMLParser
* @see MSXMLParserHandlers
*
* @author Nuwee Wiwatwattana
* @version 1.0
*/

/**
* The idref record
*/
typedef struct {
	KeyType idrefKey;
	int copydirection;
	int flag;
} idrefElementToDirection;

/**
* The item pair of the map element
*/
typedef struct {
	KeyType idElementKey;
	int idrefNum;
	idrefElementToDirection idrefElement[MAX_IDREF_NUMBER];
} IdrefItem;

typedef std::map<const char*, IdrefItem*, ltstr> IdrefTableMapType;

class IdrefTable
{
public:

	/**
	* Constructor
	*
	* Create a map table
	*/
	IdrefTable();

	/**
	* Destructor
	*
	* Clear a map table by iterating through each record
	* and delete data value
	*/
	~IdrefTable();

	/**
	* Exist
	* Check for the existence of id value in the map table
	*
	* @param idvalue The string value of attribute id.
	* @returns Boolean value.
	*/
	bool exist(const char* idvalue);

	/**
	* Add method
	* Add to the map table when id is found first/ before idref found
	*
	* @param idvalue The string value of attribute id.
	* @param idElementKey The node id key of the element with id attribute
	* @returns Error code.
	*/
	int add(const char* idvalue, KeyType idElementKey);

	/**
	* Add method
	* Add to the map table when idref found /before any other id/idref found
	*
	* @param idvalue The string value of attribute id.
	* @param idrefElementKey The node id key of the element with idref attribute.
	* @param copydirection Single character (0 or 1) denotes the direction of the Multicolor duplication.
	* @param flag Optional flag for this idref value.
	* @returns Error code.
	*/
	int add(const char* idvalue, KeyType idrefElementKey, char copydirection, int flag = 0);

	/**
	* Modify method
	* Modify the map table when id is found after idref found
	*
	* @param idvalue The string value of attribute id.
	* @param idElementKey The node id key of the element with id attribute.
	* @returns Error code.
	*/
	int modify(const char* idvalue, KeyType idrefElementKey, char copydirection, int flag = 0);

	/**
	* Modify method
	* Modify the map table when idref found after other id/idref found
	*
	* @param idvalue The string value of attribute id.
	* @param idrefElementKey The node id key of the element with idref attribute.
	* @param copydirection Single character (0 or 1) denotes the direction of the Multicolor duplication.
	* @param flag Optional flag for this idref value.
	* @returns Error code.
	*/
	int modify(const char* idvalue, KeyType idElementKey);

	/**
	* Iterator method
	* Start the scan table map iterator
	*/
	void startScan();

	/**
	* Iterator method
	* Get next item in the map table
	*
	* @returns Item type
	*/
	IdrefItem* next();

	/**
	* Iterator method
	* Whether it is the end of table
	*
	* @returns Boolean value
	*/
	bool eof();

	/**
	* Iterator method
	* Current key value
	*
	* @returns String vaue of the current id attribute
	*/
	const char* currentValue();

	/**
	* Debug method
	*/
	void printTable();

private:

	/**
	* The mapping table
	*/
	IdrefTableMapType* IdrefTableMap;
	IdrefItem* currentItem;
	char* currentID;
	bool eOF,start;
	std::map<const char*, IdrefItem*, ltstr>::const_iterator iter;
	std::map<const char*, IdrefItem*, ltstr>::iterator deliter;
};

/**
* Specialty function for address id/idref in TPC-W data set
*/
typedef struct {
	KeyType billaddr;
	KeyType shipaddr;
} SpecialItem;

typedef std::map<const char*, SpecialItem*, ltstr> SpecialTableMapType;

#endif  
