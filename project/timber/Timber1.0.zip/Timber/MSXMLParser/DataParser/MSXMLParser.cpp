/*
COPYRIGHT  (c) 2000-2004 
THE REGENTS OF THE UNIVERSITY OF MICHIGAN
ALL RIGHTS RESERVED

PERMISSION IS GRANTED TO USE, COPY, CREATE DERIVATIVE WORKS AND
REDISTRIBUTE THIS SOFTWARE AND SUCH DERIVATIVE WORKS FOR NONCOMMERCIAL
EDUCATION AND RESEARCH PURPOSES, SO LONG AS NO FEE IS CHARGED, AND SO LONG
AS THE COPYRIGHT NOTICE ABOVE, THIS GRANT OF PERMISSION, AND THE
DISCLAIMER BELOW APPEAR IN ALL COPIES MADE; AND SO LONG AS THE NAME OF THE
UNIVERSITY OF MICHIGAN IS NOT USED IN ANY ADVERTISING OR PUBLICITY
PERTAINING TO THE USE OR DISTRIBUTION OF THIS SOFTWARE WITHOUT SPECIFIC,
WRITTEN PRIOR AUTHORIZATION.

THIS SOFTWARE IS PROVIDED AS IS, WITHOUT REPRESENTATION FROM THE
UNIVERSITY OF MICHIGAN AS TO ITS FITNESS FOR ANY PURPOSE, AND WITHOUT
WARRANTY BY THE UNIVERSITY OF MICHIGAN OF ANY KIND, EITHER EXPRESS OR
IMPLIED, INCLUDING WITHOUT LIMITATION THE IMPLIED WARRANTIES OF
MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE. THE REGENTS OF THE
UNIVERSITY OF MICHIGAN SHALL NOT BE LIABLE FOR ANY DAMAGES, INCLUDING
SPECIAL, INDIRECT, INCIDENTAL, OR CONSEQUENTIAL DAMAGES, WITH RESPECT TO
ANY CLAIM ARISING OUT OF OR IN CONNECTION WITH THE USE OF THE SOFTWARE,
EVEN IF IT HAS BEEN OR IS HEREAFTER ADVISED OF THE POSSIBILITY OF SUCH
DAMAGES.
*/

/**
 * @author Nuwee Wiwatwattana
 * @author Yuqing (Melanie) Wu
 */

#include "MSXMLParser.h"
#include "../../Utilities/ErrorInfoClass.h"
extern ErrorInfoClass globalErrorInfo;

/**
* class MSXMLParser
* 
* This class handles XML data parsing and storing the parsing result (nodes) into database.
* MSXML parser is used. The callback functions in MSXMLParserHandlers are used for storing the parsing
* result into Timber. 
* 
* @see MSXMLParserHandlers
*/

/**
* Constructor
* Initialize the MSXMLParser
* @param volumnID The id of the volume in which the data file is to be stored. 
*/
MSXMLParser::MSXMLParser(lvid_t volumeID)
{
	this->volumeID = volumeID;
}

MSXMLParser::~MSXMLParser()
{
}

/**
* Process Method
* 
* Parser the given XML document and store the parsing result -- nodes -- into data file in the 
* database.
*
* @param filename The name of the XML document, with path
* @param maxdepth The estimated maximum depth of the XML document
* @param operation The operation associated with data parsing. the value can be OP_PARSE_ONLY, 
*		OP_PARSE_STORE or OP_PARSE_APPEND.
* @param fileinfo The information of the data file to be appended to (used when operation is OP_PARSE_APPEND).
* @param nodestack The nodestack that contains nodes from the root to the node while will be the parent
*		of the root of the XML document being parsed (used when operation is OP_PARSE_APPEND).
* @param adphander The append handler for appending nodes to the tail of a data file (used when operation is OP_PARSE_APPEND).
* @param startKey/endKey The start key and end key of the root of the new document (return value, for parse-and-append).
* @param convertmulticolor The flag saying whether to convert pointer-based to multicolor model (Nuwee added 07/14/03)
* @returns The fileinfo of the data file which stores the data nodes from the incoming XML document
*/
FileInfoType* MSXMLParser::parseXML(char* filename, 
									int maxdepth, 
									int operation,
									// the following are used when append is true. 
									FileInfoType* fileinfo,
									NodeStack* nodestack,
									append_file_i* apdhandler,
									KeyType* startKey,
									KeyType* endKey,
									bool convertmulticolor,
                                    XMLNameTable *xmlNameTable)
{ 
    CoInitialize(NULL);  
    ISAXXMLReader* pRdr = NULL; 
	FileInfoType* retFileinfo = NULL; 
	
	// initialize SAX XML reader
    HRESULT hr = CoCreateInstance(__uuidof(SAXXMLReader), NULL, 
                                  CLSCTX_ALL, __uuidof(ISAXXMLReader), (void **)&pRdr);
    if(!FAILED(hr))  
    { 
        MSXMLParserHandlers * pMc;

		// initialize parsing handlers based on different operation value.
		switch (operation)
		{
		case OP_PARSE_ONLY:
			pMc = new MSXMLParserHandlers(filename, xmlNameTable);
			break;
		case OP_PARSE_STORE:
			//if (!append)
			pMc = new MSXMLParserHandlers(this->volumeID, filename, maxdepth, convertmulticolor, xmlNameTable);
			break;
		case OP_PARSE_APPEND:
			pMc = new MSXMLParserHandlers(this->volumeID, filename, maxdepth, fileinfo, nodestack, apdhandler, xmlNameTable); 
			break;
		default:
            globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"MSXMLParser::parseXML",__FILE__,"Unknown operation code");
            CoUninitialize(); 
            return retFileinfo; 
		}

		hr = pRdr->putContentHandler(pMc); 

        static wchar_t URL[1000]; 
		int len = strlen(filename);
        mbstowcs( URL, filename, len); 
		URL[len] = (wchar_t) '\0';
        wprintf(L"\nParsing document: %s\n", URL); 
         
		// parse the XML document and store it into database
        hr = pRdr->parseURL(URL); 

		// print the summery information of the XML document being parsed
		pMc->printSummary();
        cout << endl << "Parse result code: " << hr << endl; 

		if (hr != 0)
        {
            globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"MSXMLParser::parseXML",__FILE__,"Parsing encountered some problems");
            retFileinfo = NULL;
        } else
        {
		    switch (operation)
		    {
		    case OP_PARSE_ONLY:
			    retFileinfo = NULL;
			    break;

		    case OP_PARSE_STORE:
                retFileinfo = pMc->getFileInfo();
			    break;

		    case OP_PARSE_APPEND:
			    retFileinfo = pMc->getFileInfo();
			    pMc->getRootKeys(startKey, endKey);
			    break;
		    }
        }
        pRdr->Release(); 
		delete pMc;
    } 
    else  
    {
        globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"MSXMLParser::parseXML",__FILE__,"Parser initialization failed");
    } 

    CoUninitialize(); 
    return retFileinfo; 
} 
