/*
COPYRIGHT  (c) 2000-2004 
THE REGENTS OF THE UNIVERSITY OF MICHIGAN
ALL RIGHTS RESERVED

PERMISSION IS GRANTED TO USE, COPY, CREATE DERIVATIVE WORKS AND
REDISTRIBUTE THIS SOFTWARE AND SUCH DERIVATIVE WORKS FOR NONCOMMERCIAL
EDUCATION AND RESEARCH PURPOSES, SO LONG AS NO FEE IS CHARGED, AND SO LONG
AS THE COPYRIGHT NOTICE ABOVE, THIS GRANT OF PERMISSION, AND THE
DISCLAIMER BELOW APPEAR IN ALL COPIES MADE; AND SO LONG AS THE NAME OF THE
UNIVERSITY OF MICHIGAN IS NOT USED IN ANY ADVERTISING OR PUBLICITY
PERTAINING TO THE USE OR DISTRIBUTION OF THIS SOFTWARE WITHOUT SPECIFIC,
WRITTEN PRIOR AUTHORIZATION.

THIS SOFTWARE IS PROVIDED AS IS, WITHOUT REPRESENTATION FROM THE
UNIVERSITY OF MICHIGAN AS TO ITS FITNESS FOR ANY PURPOSE, AND WITHOUT
WARRANTY BY THE UNIVERSITY OF MICHIGAN OF ANY KIND, EITHER EXPRESS OR
IMPLIED, INCLUDING WITHOUT LIMITATION THE IMPLIED WARRANTIES OF
MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE. THE REGENTS OF THE
UNIVERSITY OF MICHIGAN SHALL NOT BE LIABLE FOR ANY DAMAGES, INCLUDING
SPECIAL, INDIRECT, INCIDENTAL, OR CONSEQUENTIAL DAMAGES, WITH RESPECT TO
ANY CLAIM ARISING OUT OF OR IN CONNECTION WITH THE USE OF THE SOFTWARE,
EVEN IF IT HAS BEEN OR IS HEREAFTER ADVISED OF THE POSSIBILITY OF SUCH
DAMAGES.
*/

/**
* @author Nuwee Wiwatwattana
* @author Yuqing (Melanie) Wu
*/

// disable VC warning: vc7\include\xtree(1112) : warning C4702: unreachable code
#pragma warning(disable:4702)
#include "stdafx.h" 
#pragma warning(default:4702)
#include <time.h>
#include "MSXMLParserHandlers.h" 

#include "../../Utilities/ErrorInfoClass.h"
extern ErrorInfoClass globalErrorInfo;

/**
* class MSXMLParserHandlers
*
* This class define a set of callback functions for each incident in the data parsing process.
* The callback functions interpretate the data returned by the parser and stored them into
* database. 
* 
* @see FileInfoType
* @see PhysicalDataMng
*/

/**
* Constructor
* 
* This constructor is for parsing the data only. It print statistical information about the XML document. 
* Given the name of the XML document, It initialize the variable for performaing data parsing. 
*
* @param filename The name of the XML document, with path. 
*/
MSXMLParserHandlers::MSXMLParserHandlers(char* filename, XMLNameTable *xmlNameTable) 
{
	// initialize the variables before parsing. 
	this->operation = OP_PARSE_ONLY;
	this->nextKey = 0;
	this->depth = 0; 
	this->maxDepth = 0;
	this->nodeCount = 0;
	this->numAttr = 0;
	this->numDoc = 0;
	this->numEle = 0;
	this->numText = 0;
	this->dataSize = 0;
	this->filename = filename;
    this->textCollector = NULL;
    this->isSpecialCharacter = false;
    this->fileinfo = NULL;
    this->nameTable = xmlNameTable;

#ifdef DEBUG_PARSER
	{
		this->pinCount = 0;
		this->unpinCount = 0;
		this->storeCount = 0;
		this->modifyCount = 0;
	}
#endif
}

/**
* Constructor
*
* This is for the case that the file will be stored alone in database, or it is the first document
* among document that are to be stored together in one data file. 
* 
* For this purpose, a new data file and a new key index is created before the actually loading process. 
*
* @param volumeID The volumn in which the data file is to be created. 
* @param filename The name of the XML document, with path. 
* @param maxdepth The maximum depth of the xml document. 
* @param convertmulticolor The flag saying whether to convert pointer-based to multicolor model (Nuwee added 07/14/03)
*/
MSXMLParserHandlers::MSXMLParserHandlers(lvid_t volumeID, char* filename, int maxdepth, 
                                         bool convertmulticolor, XMLNameTable *xmlNameTable)
{
	// set the volumn id and the filename with the value given. 
	this->volumeID = volumeID;
	this->filename = filename;
    this->nameTable = xmlNameTable;

	// set operation to be parse-and-store.
	this->operation = OP_PARSE_STORE;

	char XMLfilename[MAX_FILE_NAME_LENGTH];
	char XMLfilepath[MAX_FILE_PATH_LENGTH];

	// parse the filename (with path), split the xml document name and the path. 
	parse_name(filename, XMLfilepath, XMLfilename);

	// create a new instance for fileinfo, set the key of the fileinfo to be the name of the XML document
	this->fileinfo = new FileInfoType;

    // MEM INIT: initialize the fileinfo
    memset(this->fileinfo->key,0,MAX_FILE_NAME_LENGTH);
	strcpy(this->fileinfo->key, XMLfilename);

    // MEM INIT: initialize the fileinfo
    this->fileinfo->dataSize = 0.0;
    this->fileinfo->rootKey = -1;
    this->fileinfo->maxKey = -1;
    this->fileinfo->firstOverflowNodeKey = -1;
    this->fileinfo->recNum = this->fileinfo->maxDepth = -1;
    this->fileinfo->overflow = false;
    memset(&(this->fileinfo->fid),0,sizeof(serial_t));
    memset(&(this->fileinfo->firstRid),0,sizeof(serial_t));
    memset(&(this->fileinfo->keyIndex),0,sizeof(serial_t));

	cout << endl << "Store XML file: " << filename << " into database..." << endl;

	// create a new data file in database for the new XML document
	rc_t rc = ss_m::create_file(this->volumeID, this->fileinfo->fid, ss_m::t_regular);
	if (rc)
	{
		globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"MSXMLParserHandlers::MSXMLParserHandlers",__FILE__,"Create shore file failed");
	}

	// create a new key index in the database, which is aoociated with the datafile which stores
	// nodes in the XML document. 
	rc = ss_m::create_index(this->volumeID, ss_m::t_uni_btree, ss_m::t_regular,
		SHORE_INDEX_KEY_TYPE_OPT, 0, this->fileinfo->keyIndex);
	if (rc)
	{
		globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"MSXMLParserHandlers::MSXMLParserHandlers",__FILE__,"Create shore file index failed");
	}

	// prepare the stack for parsing and inserting node to database. 
	this->nodeStack = new NodeStack(maxdepth);

	// initialized the variables
	this->nextKey = 0;
	this->depth = 0; 
	this->maxDepth = 0;
	this->nodeCount = 0;
	this->dataSize = 0;

	// create a new instance of append_file_i, which is in charge of appending new record to the
	// tail of the data file. 
	this->apd = new append_file_i(this->volumeID, this->fileinfo->fid);

#ifdef DEBUG_PARSER
	{
		cout << "----------append_file_i" << endl;
		for (int i=0; i<10000; i++)
		{
			this->nodelist[i] = -1;
			this->valid[i] = false; 
		}
		this->stackitemcount = 0;
		this->pinCount = 0;
		this->unpinCount = 0;
		this->storeCount = 0;
		this->modifyCount = 0;
	}
#endif

	numEle = numAttr = numText = numDoc = 0;
	textCollector = NULL;
    this->isSpecialCharacter = false;

	this->multicolor = convertmulticolor;
	if (this->multicolor)
	{
		this->idrefTable = new IdrefTable; 
	}
}

/**
* Constructor
*
* This is for appending a new XML document to another one which is already in database.
* 
* @param volumeID The volumn in which the data file is to be created. 
* @param filename The name of the XML document ( with path) to be appended to the existing file.
* @param maxdepth The maximum depth of the xml document. 
* @param appendtofileinfo The fileinfo of the existing file. 
* @param nodestack The nodestack for the existing file, which contains all nodes from the root to the node
*		at which the root of the new document is to be appended. 
* @param apdhandler An append handler for the old data file. 
*/
MSXMLParserHandlers::MSXMLParserHandlers(lvid_t volumeID, char* filename, int maxdepth, FileInfoType* appendtofileinfo, 
                                         NodeStack* nodestack, append_file_i* apdhandler, XMLNameTable *xmlNameTable)
{ 
	this->volumeID = volumeID;
	this->filename = filename;
    this->nameTable = xmlNameTable;
	this->maxDepth = maxdepth;
	this->operation = OP_PARSE_APPEND;

	// use the fileinfo and node stack prepared by PhyscialDataMng
	this->fileinfo = appendtofileinfo;
	this->nodeStack = nodestack;

	// the next key to size should start from the largest key from the existing data file. 
	this->nextKey = appendtofileinfo->maxKey.toInt();

	// all other information is also got from the existing data file. 
	this->depth = nodestack->getItemNum()-1;
	this->maxDepth = appendtofileinfo->maxDepth;
	this->nodeCount = appendtofileinfo->recNum;
	this->dataSize = appendtofileinfo->dataSize;

	// create an instance of the append handler if it is not provided by the caller. 
	if (apdhandler == NULL)
	{
		this->apd = new append_file_i(this->volumeID, this->fileinfo->fid);
#ifdef DEBUG_PARSER
		cout << "----------new append_file_i" << endl;
#endif
	}
	else this->apd = apdhandler;

#ifdef DEBUG_PARSER
	{
		for (int i=0; i<10000; i++)
		{
			this->nodelist[i] = -1;
			this->valid[i] = false; 
		}
		this->stackitemcount = 0;
		this->pinCount = 0;
		this->unpinCount = 0;
		this->storeCount = 0;
		this->modifyCount = 0;
	}
#endif

	numEle = numAttr = numText = numDoc = 0;
	textCollector = NULL;
    this->isSpecialCharacter = false;

	// Multicolor is not supported in appending right now
	this->multicolor = false;
	if (this->multicolor)
	{
		this->idrefTable = new IdrefTable; 
	}
} 

/**
* Destructor
* 
* release the append handler and the node stack. 
*/
MSXMLParserHandlers::~MSXMLParserHandlers() 
{ 
	if ((this->operation == OP_PARSE_STORE) || (this->operation == OP_PARSE_APPEND))
	{
		this->apd->finish();
		delete this->apd;
		delete this->nodeStack;

		//if (fileinfo)
		//	delete fileinfo;

		if (this->multicolor) 
		{ // multicolor
			//this->idrefTable->printTable();
			delete this->idrefTable; 
		}
        // MEM INIT
        //if (this->operation == OP_PARSE_STORE && this->fileinfo != NULL) 
        //    delete this->fileinfo; // can not release memory here, seg fault!
	}
}

/**
* Callback function for startDocument
*
* Create a document node and stored it into data base. 
* Incase the operation is parse-and-append, skip the document node
*/
HRESULT STDMETHODCALLTYPE MSXMLParserHandlers::startDocument() 
{ 	
	if (this->operation == OP_PARSE_ONLY)
	{
		// if the operation is only parse-and-count, modify the statistical info and do nothing else. 
		this->numDoc++;
		this->increaseNodeCount(0, 0);

		this->depth++;
		if (this->depth > this->maxDepth)
			this->maxDepth++;
		return S_OK;
	}

	if (this->operation == OP_PARSE_APPEND)
	{
		// in case this node is to be append to other document, no need to build
		// a new document node here. 
		return S_OK;
	}

	// compute the key for the new document node
	KeyType docKey = this->nextKey;
	this->fileinfo->rootKey = docKey;
	this->nextKey++;

	numDoc++;
	char XMLfilename[MAX_FILE_NAME_LENGTH];
	char XMLfilepath[MAX_FILE_PATH_LENGTH];
	parse_name(this->filename, XMLfilepath, XMLfilename);

	// create a new document node
	DM_DocumentNode* docnode = new DM_DocumentNode(docKey, (short)this->depth, XMLfilename, XMLfilepath);

#ifdef DEBUG_PARSER
	docnode->printValue();
#endif

	// write document node to database 
	lrid_t rid;
	int retval = this->storeNodeToDB(docnode, &rid);
	if (retval != S_OK) return E_FAIL;

	// push the document node to stack
	NodeStackItem* docitem= new NodeStackItem(docnode);
	docitem->setNodeRid(rid.serial);
	this->nodeStack->push(docitem);

#ifdef DEBUG_PARSER
	this->stackitemcount++;
#endif

	return S_OK; 
} 

/**
* Callback function for end document
*
* For parse-and-count, and parse-and-store, at the time when the parsing is done, there should be 
* only the document node left in the stack. Just pop the node, assign end key to it, and print the summery 
* information. 
*
* Things get complicated when the XML document being parses is to be appended to an existing document
* and the appending does not happens at the root node. At these time, all the nodes from the root
* to the append node are still in the stack. need to handle them one by one, assign end key to them and 
* write them to the database. 
*/
HRESULT STDMETHODCALLTYPE MSXMLParserHandlers::endDocument() 
{
	if (this->operation == OP_PARSE_ONLY)
	{
		// in case that the operation is just parse-and-count, print the summary information here
		this->printSummary();
		return S_OK;
	}

	// at this time, the new document has been parsed and stored into database, 
	// the last thing is to finish up by update the root node and write it to database.
	NodeStackItem* stItem = this->nodeStack->pop();

	DM_DataNode* node = (DM_DocumentNode*) (stItem->getNode());

	// change the endkey
	node->setEndKey(this->nextKey);
	this->nextKey++;

	DM_DataNode* lastchild = stItem->getLastChild();

	// keep record of the startkey/endkey, 
	if (this->operation == OP_PARSE_APPEND) {
		this->rootStartKey = lastchild->getKey();
		this->rootEndKey = lastchild->getEndKey();
	}
	else {
		this->rootStartKey = node->getKey();
		this->rootEndKey = node->getEndKey();
	}

	// delete the last child of the root node from memory
	if (lastchild != NULL)
		deleteNode(lastchild);

#ifdef DEBUG_PARSER
	{
		cout << "\nbefore calling modifyNodeInDB" << endl;
		//docnode->printValue();
	}
#endif

	// modify the node in database. 
	int retval = this->modifyNodeInDB(stItem->getNodeRid(), node);
	if (retval != S_OK) return E_FAIL;
	delete stItem;

#ifdef DEBUG_PARSER
	this->stackitemcount--;
#endif

	if (this->nodeStack->empty())
	{
		// if the node stack is empty at this time, the operation is parse-and-store, or append
		// with merge at root. Then, it is the end of the parsing process. 

		// delete the last node from memory
		deleteNode(node);
	}

	else
	{
		// this means, the document being parsed is to be merged in to an old 
		// document, and the merge point is not at the root
		// in this case, just reset the end key of the node to be merged at, 
		// which is currently at the top of the stack and leave the parsing process. 
		while (!this->nodeStack->empty())
		{
			// pop the node at the top of the stack 
			stItem = this->nodeStack->top();

			// delete the last child of the root node from memory
			lastchild = stItem->getLastChild();
			if (lastchild != NULL)
				deleteNode(lastchild);

			// modify the endkey of the node
			node = stItem->getNode();
			node->setEndKey(this->nextKey);
			this->nextKey++;

			// modify the node in database
			int retval = this->modifyNodeInDB(stItem->getNodeRid(), node);
			if (retval != S_OK) return E_FAIL;
			delete stItem;

#ifdef DEBUG_PARSER
			this->stackitemcount--;
#endif
		}
	}

	// modify fileinfo with information of the file
	this->fileinfo->recNum = this->nodeCount;
	this->fileinfo->maxDepth = this->maxDepth;
	this->fileinfo->maxKey = this->nextKey;
	//the overflow info is set in the constructors.
	//for the loading of a new file overflow==false, but for an append overflow might be true
	//AN: actually, we probably don't want to append if there is an overflow, because everything
	//that we append will go into the overflow!
	//this->fileinfo->firstOverflowNodeKey = -1;
	//this->fileinfo->overflow = false;

	this->depth--;

	//Multicolor 07/19/03
	//Cross check logic of color stack
	if (!this->colorstack.empty())
	{
		globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"MSXMLParserHandlers::endDocument",__FILE__,"Miss logic for color stack");
	}

	//Processing multicolor conversion
	if (this->multicolor) 
	{
		cout << "=======Processing multicolor conversion=======" << endl;
		if (gSettings->getBooleanValue("MCT_SPECIAL",false)) {
			int rc = this->multicolorConversionSpecial();
			if (rc != 0) {
				return E_FAIL;
			}
		}
		else {
			int rc = this->multicolorConversion();
			if (rc != 0) {
				return E_FAIL;
			}
		}
	}
	//end Multicolor

	return S_OK; 

}

/**
* callback function for StartElement
* 
* It create a new element node for the element, a new attribute node for attributes, if there is any. 
* Text value is accumulated and handled here. This is to deal with the general case that one element may
* have more than one piece of text, interleaved by its subelements.
*/
#pragma warning(disable:4100)
HRESULT STDMETHODCALLTYPE MSXMLParserHandlers::startElement(  
	/* [in] */ wchar_t __RPC_FAR *pwchNamespaceUri, 
	/* [in] */ int cchNamespaceUri, 
	/* [in] */ wchar_t __RPC_FAR *pwchLocalName, 
	/* [in] */ int cchLocalName, 
	/* [in] */ wchar_t __RPC_FAR *pwchRawName, 
	/* [in] */ int cchRawName, 
	/* [in] */ ISAXAttributes __RPC_FAR *pAttributes) 
{ 
	int retval = 0;
	// if the operation is to parse the XML document and count the number of nodes
	// just change the countings and do nothing else. 
	if (this->operation == OP_PARSE_ONLY)
	{
		this->depth++;
		if (this->depth > this->maxDepth)
			this->maxDepth = this->depth;
		this->numEle++;
		this->increaseNodeCount(0, 0);

		int attrnum;
		pAttributes->getLength(&attrnum); 
		if (attrnum > 0) this->numAttr ++;
		return S_OK;
	}

	// otherwise, need to write the element node (and attribute node, if there is any 
	// attributes, to the database.
	if (textCollector != NULL)
	{
		// need to write text to database
		KeyType textKey = this->nextKey;
		this->nextKey ++;
		this->depth++;
		if (this->depth > this->maxDepth) this->maxDepth = this->depth;

		// append the text node as the last child of the element node at the top of the stack
		NodeStackItem* stItem = this->nodeStack->top();
		DM_ElementNode* elenode = (DM_ElementNode*) (stItem->getNode());
		DM_DataNode* lastChild = stItem->getLastChild();

        // remove the trailing Space
        int len = strlen(textCollector);
        len--;
        while (*(textCollector+len) == ' ') len--;
        *(textCollector+len+1) = '\0';

		// create a new text node
		numText++;
		DM_TextNode* textnode = new DM_TextNode(textKey, (short)this->depth, textCollector);
		elenode->appendChild(textnode, lastChild);

		// update the current last child of the element at the top of the stack
		if (stItem->getLastChild() != NULL)
		{
			int retval = this->modifyNodeInDB(stItem->getLastChildRid(), lastChild);
			if (retval != S_OK) return E_FAIL;
			deleteNode(lastChild);
		}

		// store the new text node into shore
		lrid_t rid;
		int retval = this->storeNodeToDB(textnode, &rid);
		if (retval != S_OK) return E_FAIL;

		// set this new text node as the last child of the element at the top of the stack
		stItem->setLastChild(textnode);
		stItem->setLastChildRid(rid.serial);

		// set the descendant depth of its parten.
		stItem->setDescendantDepth(1);

		this->depth--;
		delete [] textCollector;
		textCollector = NULL;
	}

	HRESULT hr = S_OK; 

	// variable for the element node
	int attrnum; 
	char* tag;

	// new element node
	DM_ElementNode* elenode;
	NodeStackItem* stItem;
	DM_ElementNode* parent;
	DM_DataNode* lastChild;

	numEle++;
	this->depth ++;
	if (this->depth > this->maxDepth) this->maxDepth = this->depth;

	// create element node
	tag = this->wcharToChar(pwchLocalName,cchLocalName); 
	KeyType eleKey = this->nextKey;
	this->nextKey ++;
    
    // encoding start
	//elenode = new DM_ElementNode(eleKey, this->depth, tag);
    int tagCode = nameTable->getCodeByName(tag);
    if (tagCode == -1) tagCode = nameTable->addNameToTable(tag);
    elenode = new DM_ElementNode(eleKey, (short)this->depth, tagCode);
    // encoding end

	delete [] tag;

	// set the number of attribute to the new element node
	pAttributes->getLength(&attrnum); 
	elenode->setAttrNumber((short)attrnum);

#ifdef DEBUG_PARSER
	elenode->printValue();
#endif

	// append the element node as the last child of its parent (the node on top of the stack).
	stItem = this->nodeStack->top();
	parent = (DM_ElementNode*) (stItem->getNode());
	lastChild = stItem->getLastChild();
	parent->appendChild(elenode, lastChild);

	// update the current last child of the node at the top of the stack
	if (lastChild != NULL)
	{
		int retval = this->modifyNodeInDB(stItem->getLastChildRid(), lastChild);
		if (retval != S_OK) return E_FAIL;
		deleteNode(lastChild);
	} 

	// create attribute node if there is any attribute associated with the element
	DM_AttributeNode* attrnode = NULL;

	//Nuwee 10/14/03
	//Flag to keep id,idref, copydirection, and numcolor attribute index
	int foundid = -1;
	int foundidref[5]; //array of idref index
	for (int i=0 ; i<5 ; i++)
	{
		foundidref[i] = -1;
	}
	int foundnumc = -1;

	int numidref = 0; //number of idref attributes
	int copydirection = -1; //string array of direction to copy syncing with order of idref specified
	//end multicolor

	if (attrnum > 0)
	{
		// compute the key for the new attribute node
		KeyType attrKey = this->nextKey;
		this->nextKey++;

		// update statistical information
		this->depth++;
		numAttr++;

		// list of attribute names and values
		char** attrnames = new char*[attrnum];
		Value** attrvalues = new Value*[attrnum];

		wchar_t *wattrname, *wattrvalue; 
		char* attrval;

		for (int i=0; i<attrnum; i++ ) 
		{ 
			// get each attribute name and value. 
			int namelen, vallen; 

			pAttributes->getLocalName(i,&wattrname,&namelen);  
			attrnames[i] = this->wcharToChar(wattrname, namelen);

			// 10/18/03 :Multicolor
			//Locate id/idref attribute and its corresponding attributes
			if (this->multicolor){
				char str[] = "idref";
				if (!stricmp(attrnames[i],"id")){
					foundid = i;
				}
				else if (!stricmp(attrnames[i],"copydirection")){
					copydirection = i;
					elenode->setAttrNumber(elenode->getAttributeNumber()-1);
				}
				else if (!stricmp(attrnames[i],"numcolor")){
					foundnumc = i;
					elenode->setAttrNumber(elenode->getAttributeNumber()-1);
				}
				else if (strstr(strlwr(attrnames[i]),str) != NULL){
					foundidref[numidref] = i;
					numidref++;
				}
			}
			//end Multicolor

			pAttributes->getValue(i,&wattrvalue,&vallen); 
			attrval = this->wcharToChar(wattrvalue, vallen);	

			attrvalues[i] = new Value(STRING_VALUE);
			attrvalues[i]->setStrValue(attrval);
			delete [] attrval;
		} 

		//10/14/03 Multicolor
		if (this->multicolor) {

			if (foundnumc != -1) {
				cstack cstack_1;
				cstack_1.ekey = eleKey;
				cstack_1.num = atoi(attrvalues[foundnumc]->getStrValue());

				this->colorstack.push(cstack_1);
			}
			if (foundid != -1) { //There is an id attribute
				//looking up the mapping table for this idvalue
				//if found , change data to <idvalue, {idelementkey,(same))>
				//if not found, add <idvalue,0>
				if (this->idrefTable->exist(attrvalues[foundid]->getStrValue())) {
					(void)this->idrefTable->modify(attrvalues[foundid]->getStrValue(),eleKey);
				}
				else {
					(void)this->idrefTable->add(attrvalues[foundid]->getStrValue(),eleKey);
				}
			}
			if (numidref > 0) { // There are at least one idref and one idref will come with 1 corresponding copydirection
				//char seps[]   = " ,\t\n";
				//char *idtoken;
				char copytoken;
				int copyindex = 0;

				for (int j = 0 ; j < numidref ; j++) { 
					char* idtokentemp = new char[strlen(attrvalues[foundidref[j]]->getStrValue())+1];
					//strcpy(idtokentemp,attrvalues[foundidref[j]]->getStrValue());
					//idtoken = strtok( idtokentemp, seps );
					//memcpy(&copytoken, attrvalues[copydirection]->getStrValue()+copyindex, 1 );
					//while( idtoken != NULL )
					//{
					//	/* While there are tokens in "string" */
					//	//printf( " %s\n", idtoken );
					//	//printf( " %d\n", copytoken);
					//	if (this->idrefTable->exist(idtoken)) {
					//		(void)this->idrefTable->modify(idtoken,eleKey,copytoken);
					//	}
					//	else {
					//		(void)this->idrefTable->add(idtoken,eleKey,copytoken);
					//	}
					//	/* Get next token: */
					//	idtoken = strtok( NULL, seps );
					//}
					//copyindex = copyindex + 2;
					int specialflag = 0;

					//10/27/03 Special processing for billing & shipping address dual color
					// rememeber whether the idref is billing or shipping address
					// so to copy to the correct multicolored address node
					if (gSettings->getBooleanValue("MCT_SPECIAL",false)) {
						char strb[] = "bill";
						char strs[] = "ship";
						if (strstr(strlwr(attrnames[foundidref[j]]),strb) != NULL) {
							//it is billing address
							specialflag = 1;
						}
						else if (strstr(strlwr(attrnames[foundidref[j]]),strs) != NULL) {
							//it is shipping address
							specialflag = 2;
						}
					}


					//DEBUG
					//if (strcmp(attrvalues[foundidref[j]]->getStrValue(),"addr10") == 0) {
					//	cout << attrvalues[foundidref[j]]->getStrValue() << ": " << eleKey.toString() <<endl;
					//}
					//DEBUG

					strcpy(idtokentemp,attrvalues[foundidref[j]]->getStrValue());
					memcpy(&copytoken, attrvalues[copydirection]->getStrValue()+copyindex, 1 );
					if (this->idrefTable->exist(idtokentemp)) {
						(void)this->idrefTable->modify(idtokentemp,eleKey,copytoken,specialflag);
					}
					else {
						(void)this->idrefTable->add(idtokentemp,eleKey,copytoken,specialflag);
					}
					copyindex = copyindex + 2;
					delete idtokentemp;
				}

			}
		}//end multicolor

		//10/14/03 Multicolor
		if ((this->multicolor)&&(!this->colorstack.empty())) {
			// create a new attribute node. 
			attrnode = new DM_AttributeNode(attrKey, (short)this->depth, 
				(short)attrnum, elenode->getAttributeNumber(), 
				attrnames, attrvalues, this->colorstack.top().num, eleKey);
		}
		else {
			// create a new attribute node. 
			attrnode = new DM_AttributeNode(attrKey, (short)this->depth, 
				(short)attrnum, attrnames, attrvalues, eleKey);
		}
#ifdef DEBUG_PARSER
		attrnode->printValue();
#endif

		// release space allocated for attribute name and value. 
		//this is done in the attribute node itself now:
		/*
		for (i=0; i<attrnum; i++ )
		{
			delete [] attrnames[i];
			delete attrvalues[i];
		}
		delete [] attrnames;
		delete [] attrvalues;
		*/

		// set the attribute link in the element node
		elenode->setAttributes(attrKey);

		this->depth--;
	} //if attrnum>0
	// Added 10/14/03 for Multicolor
	else if ((this->multicolor) && (!this->colorstack.empty()))
	{
		//also allocate for all elements in the subtree as part of the multicolored
		// compute the key for the new attribute node
		KeyType attrKey = this->nextKey;
		this->nextKey++;

		// update statistical information
		this->depth++;
		numAttr++;

		// create a new attribute node. 
		attrnode = new DM_AttributeNode(attrKey, (short)this->depth, 
			0, 0, NULL, NULL, this->colorstack.top().num, eleKey);

		// set the attribute link in the element node
		elenode->setAttributes(attrKey);

		this->depth--;
	} //else if

	// write element node to database 
	lrid_t rid;
	retval = this->storeNodeToDB(elenode, &rid);
	if (retval != S_OK)
		return E_FAIL;

	// set this new element node as the last child of the element at the top of the stack

	stItem->setLastChild(elenode);
	stItem->setLastChildRid(rid.serial);

	// push the elementnode into stack

	NodeStackItem* eleitem= new NodeStackItem(elenode);

#ifdef DEBUG_PARSER
	this->stackitemcount++;
#endif

	eleitem->setNodeRid(rid.serial);
	this->nodeStack->push(eleitem);

	// write attribute node to database. there is no need to push the attribute node to the stack.

	if ((attrnum > 0) || ((this->multicolor) && (!this->colorstack.empty())))
	{
		lrid_t rid;
		retval = this->storeNodeToDB(attrnode, &rid);
		if (retval != S_OK)
			return E_FAIL;

		deleteNode(attrnode);
	}

	return hr; 
}

/**
* Callback function for end element
* 
* It poppes the element at the top of the stack, now, it is done with its last child and it could be removed
* from the stack. Please note we have not done with the element whose end tag is reached. Later, its 
* nextSibling link may change in the startElement callback of its next sibling node. 
* After this callback, the node on the top of the stack should be the parent of the node just ends. 
* And the nodes just ends is in the lastChild field of the item at the top of the stack. 
*/
HRESULT STDMETHODCALLTYPE MSXMLParserHandlers::endElement(  
	/* [in] */ wchar_t __RPC_FAR *pwchNamespaceUri, 
	/* [in] */ int cchNamespaceUri, 
	/* [in] */ wchar_t __RPC_FAR *pwchLocalName, 
	/* [in] */ int cchLocalName, 
	/* [in] */ wchar_t __RPC_FAR *pwchRawName, 
	/* [in] */ int cchRawName) 
{ 
	// if the operation is just to parse the document and count nodes, at the time when then  end tag
	// of an element is encountered, just need to move on level up the tree, by decreasing the depth. 
	if (this->operation == OP_PARSE_ONLY)
	{
		this->depth --;
		return S_OK;
	}

	if (textCollector != NULL)
	{
		// need to write text to database
		KeyType textKey = this->nextKey;
		this->nextKey++;
		this->depth++;
		if (this->depth > this->maxDepth)
			this->maxDepth = this->depth;

		// append the text node as the last child of the element node at the top of the stack
		NodeStackItem* stItem = this->nodeStack->top();
		DM_ElementNode* elenode = (DM_ElementNode*) (stItem->getNode());
		DM_DataNode* lastChild = stItem->getLastChild();

        // remove the trailing Space
        int len = strlen(textCollector);
        len--;
        while (*(textCollector+len) == ' ') len--;
        *(textCollector+len+1) = '\0';

		// create a new text node
		numText++;
		DM_TextNode* textnode = new DM_TextNode(textKey, (short)this->depth, textCollector);
		// append the child to the element at the top of the stack.
		elenode->appendChild(textnode, lastChild);


		// update the current last child of the element at the top of the stack in database
		if (stItem->getLastChild() != NULL)
		{
			int retval = this->modifyNodeInDB(stItem->getLastChildRid(), lastChild);
			if (retval != S_OK) return E_FAIL;
			deleteNode(lastChild);
		}

		// store the new text node into database
		lrid_t rid;
		int retval = this->storeNodeToDB(textnode, &rid);
		if (retval != S_OK) return E_FAIL;

		// set this new text node as the last child of the element at the top of the stack
		stItem->setLastChild(textnode);
		stItem->setLastChildRid(rid.serial);

		// set the descendant depth of its parten (the element node which is used to be at the 
		// top of the stack).
		stItem->setDescendantDepth(1);

		this->depth--;
		delete [] textCollector;
		textCollector = NULL;
	}

	// The element whose end tag is reached is the element at the top of the stack. 
	// pop it. 
	NodeStackItem* eleitem = this->nodeStack->pop();
	DM_ElementNode* elenode = (DM_ElementNode*) (eleitem->getNode());

	// if the last child of the node is not NULL, delete it from memory
	// no change is needed for that node in SHORE.
	DM_DataNode* lastchild = eleitem->getLastChild() ;
	if (lastchild != NULL) deleteNode(lastchild);

	// change the endkey
	// Multicolor 10/14/03
	// Adjust space for copied multicolor node, that will append as last child later
	if(this->multicolor) 
	{
        char *tag = elenode->getTag(nameTable);
		if ((elenode->getAttributeNumber() > 0) && (strcmp(tag,"customer") != 0)
			&& (strcmp(tag,"author") != 0) && (strcmp(tag,"country") != 0)) 
        {
			this->nextKey = this->nextKey + gSettings->getIntegerValue("MCT_ALLOWANCE",2000) ;
        }
        delete [] tag;
		if (!this->colorstack.empty()) 
        {
			if (this->colorstack.top().ekey == elenode->getKey()) {
				//root of the multicolor subtree is found, pop numcolor stack
				this->colorstack.pop();
            }
        }
	}
	// end Multicolor

	elenode->setEndKey(this->nextKey);
	this->nextKey++;

	// modify the element node in database. 
	int retval = this->modifyNodeInDB(eleitem->getNodeRid(), elenode);
	if (retval != S_OK) return E_FAIL;

	// modify the descendant depth of its parent
	NodeStackItem* stackItem =  this->nodeStack->top();
	if (stackItem != NULL)
		stackItem->setDescendantDepth(eleitem->getDescendantDepth()+1);

	// delete the popped stackitem
	delete eleitem;

#ifdef DEBUG_PARSER
	this->stackitemcount--;
#endif

	this->depth--;
	return S_OK; 

}  
#pragma warning(default:4100)

/**
* Callback function for text content
*
* This function create a text node and append it to the element node in stack, which should be its
* parent in our database. 
*
* Significance of white-space:
*   Leading/trailing white-spaces are removed, middle white-space are either conserved (for Space) 
* or removed/converted into Space (for non-Space).  A non-Space white-space is converted into Space
* if and only if it is not adjacent to Space.
*/
HRESULT STDMETHODCALLTYPE MSXMLParserHandlers::characters(  
	/* [in] */ wchar_t __RPC_FAR *pwchChars, 
	/* [in] */ int cchChars) 
{ 
	char* text = this->wcharToCharPreserveSpace(pwchChars, cchChars); 

	if (text[0] == '\0') 
	{
		delete [] text;
		// this text is not meaningful
		return S_OK;
	}

	if (this->operation == OP_PARSE_ONLY)
	{
		// for parse-and-count operation, just change the statistical information
		if (this->depth >= this->maxDepth) this->maxDepth++;
		this->numText++;
		this->increaseNodeCount(0, 0);
		return S_OK;
	}

	// merge the text with the content in the textCollector
	if (textCollector == NULL)
	{
		// leading white-space should be trimmed
        char *placeholder = text;
        while ( *text == ' ' ) text++;
        if (strlen(text)>0)
        {
            textCollector = new char [strlen(text) +1];
		    strcpy(textCollector,text);
        }
		delete [] placeholder;
		return S_OK;
	}
	else
	{
		char *tmp = textCollector;
		int n1 = strlen(tmp);
		int n2 = strlen(text);
        // allocate new memory, 1 for '\0', one for possible SP
        // 4 for possible special character
        textCollector = new char [n1 + n2 + 7];
		strcpy(textCollector,tmp);
        //   In MSXML Parser, white-space like new line will cause the textual content 
        // to be broken up into two parts, we eliminate the new line if previously we have 
        // a Space or afterwards we have a Space.
        //   IN MSXML Parser, special character like <, >, & (encoded in entity format, i.e.,
        // &lt;, &gt;, &amp;) will cause the textual content to be broken up as well. We treat
        // those three special cases, support for others will be added as needed.
        if (*text == '&')
        {
            strcat(textCollector, "&amp;");
            this->isSpecialCharacter = true;
        } else if (*text == '<')
        {
            strcat(textCollector, "&lt;");
            this->isSpecialCharacter = true;
        } else if (*text == '>')
        {
            strcat(textCollector, "&gt;");
            this->isSpecialCharacter = true;
        } else if (this->isSpecialCharacter)
        {
            strcat(textCollector,text);
            this->isSpecialCharacter = false;
        } else if ( *(tmp+n1-1) != ' ' && *text != ' ')
        {
            strcat(textCollector," ");
            strcat(textCollector,text);
        } else strcat(textCollector, text);

		delete [] tmp;
		delete [] text;
		return S_OK;
	}

	//// compute the key for the next text node. 
	//KeyType textKey = this->nextKey;
	//this->nextKey++;
	//this->depth++;
	//if (this->depth > this->maxDepth) this->maxDepth = this->depth;

	//// append the text node as the last child of the element node at the top of the stack
	//NodeStackItem* stItem = this->nodeStack->top();
	//DM_ElementNode* elenode = (DM_ElementNode*) (stItem->getNode());
	//DM_DataNode* lastChild = stItem->getLastChild();

	//numText++;

	//// create a new text node
	//DM_TextNode* textnode = new DM_TextNode(textKey, this->depth, text);

	//delete [] text;

	//// append the text node to the element node in stack
	//elenode->appendChild(textnode, lastChild);

	//// update the current last child of the element at the top of the stack
	//if (stItem->getLastChild() != NULL)
	//{
	//	int retval = this->modifyNodeInDB(stItem->getLastChildRid(), lastChild);
	//	if (retval != S_OK) return E_FAIL;
	//	deleteNode(lastChild);
	//}

	//// store the new text node into shore
	//lrid_t rid;
	//int retval = this->storeNodeToDB(textnode, &rid);
	//if (retval != S_OK) return E_FAIL;

	//// set this new text node as the last child of the element at the top of the stack

	//stItem->setLastChild(textnode);
	//stItem->setLastChildRid(rid.serial);

	//// set the descendant depth of its parten.
	//stItem->setDescendantDepth(1);

	//this->depth--;
	//return S_OK; 
}

#pragma warning(disable:4100)
HRESULT STDMETHODCALLTYPE MSXMLParserHandlers::ignorableWhitespace(  
	/* [in] */ wchar_t __RPC_FAR *pwchChars, 
	/* [in] */ int cchChars) 
{ 
	return S_OK; 
}
#pragma warning(default:4100)

/**
* Process Method
* 
* Store a node to the database.
*
* This involves wrapping the node into a string, storing the record into the data file and addding 
* correspond index item to the key index. 
* 
* @param node The node to be stored into the database
* @param rid The record id of the record that contains the node (return value)
* @param Error code
*/
int MSXMLParserHandlers::storeNodeToDB(DM_DataNode* node, lrid_t* rid)
{
#ifdef DEBUG_PARSER
	this->storeCount++;
#endif

	// wrap the node into a string
	this->nodeInStr = node->wrap(&(this->nodeInStrLen));

#ifdef DEBUG_PARSER
	cout << "wrap node (key=" << node->getKey().toString() << "), length = " << this->nodeInStrLen << endl;
#endif

	// increase node count variables
	this->increaseNodeCount(node->getKey(), nodeInStrLen);

	// append the record (with the string that contains the node information) into database
	vec_t data(this->nodeInStr, this->nodeInStrLen); 
	rc_t rc = this->apd->create_rec(vec_t(), this->nodeInStrLen, data, *rid);

#ifdef DEBUG_PARSER
	cout << "----------create_rec, key = " << node->getKey().toString() << endl;
#endif

	if (rc)
	{
		globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"MSXMLParserHandlers::storeNodeToDB",__FILE__,"Creating a record failed");
		return E_FAIL;
	}

	// release the string
	delete [] this->nodeInStr;

	// insert an item into the key index, which matches the key of the node to its rid. 
	serial_t srid = (*rid).serial;
	KeyType key = node->getKey();
	rc = ss_m::create_assoc(this->volumeID, this->fileinfo->keyIndex, 
		vec_t(&key, sizeof(KeyType)), vec_t(&srid, sizeof(srid)));

#ifdef DEBUG_PARSER
	cout << "----------create_assoc " << endl;
#endif

	if (rc) 
	{
		globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"MSXMLParserHandlers::storeNodeToDB",__FILE__,"Creating an index entry failed");
		return E_FAIL;				
	}

	return S_OK;
}

/**
* Process Methog
* 
* Modify a node in the database with new information in the data node.
* There is no need to change the index item since the key and the rid are not changed. 
*
* @param srid The record id of the record to be changed.
* @param node The node that contains new information. 
* @param Error code
*/
int MSXMLParserHandlers::modifyNodeInDB(serial_t srid, DM_DataNode* node)
{
#ifdef DEBUG_PARSER
	this->modifyCount++;
#endif

	// pin the node in the database
	rc_t rc = this->pinHandler.pin(this->volumeID, srid, 0);

#ifdef DEBUG_PARSER
	{
		cout << "----------pinHandler.pin" << endl;
		this->pinCount++;
	}
#endif

	if (rc)
	{
		globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"MSXMLParserHandlers::modifyNodeInDB",__FILE__,"Pinning a record failed");
		return E_FAIL;
	}

	// wrap the new node into a string
	this->nodeInStr = node->wrap(&(this->nodeInStrLen));

#ifdef DEBUG_PARSER
	{
		cout << "wrap node (key=" << node->getKey().toString() << "), length = " << this->nodeInStrLen << endl;

		DM_DataNode* tempnode = DM_DataNode::unwrap(this->nodeInStr);
		cout << "\nwrap node: key=" << node->getKey().toString() << " , endkey =" << node->getEndKey().toString() << endl;
		node->printValue();

		cout << "\nwrap node: key=" << tempnode->getKey().toString() << " , endkey =" << tempnode->getEndKey().toString() << endl;
		tempnode->printValue();
		deleteNode(tempnode);
	}
#endif

	// update the record with the string generated from the new node. 
	vec_t data(this->nodeInStr, this->nodeInStrLen); 				
	this->pinHandler.update_rec(0, data);

#ifdef DEBUG_PARSER
	cout << "----------pinHandler.update_rec" << endl;
#endif			

	// unpin the node
	this->pinHandler.unpin();	

#ifdef DEBUG_PARSER
	{
		cout << "----------pinHandler.unpin" << endl;
		this->unpinCount++;
	}
#endif	

	delete [] this->nodeInStr;
	return S_OK;
}

/**
* Process Method
* Delete a node according to its type
*/
void MSXMLParserHandlers::deleteNode(DM_DataNode* node)
{
#ifdef DEBUG_PARSER
	{
		cout << "before delete a node: key = " << node->getKey().toString();
		cout << ", endkey = " << node->getEndKey().toString() << endl;
	}
#endif

	if ((node->getFlag() == TEXT_NODE) || (node->getFlag() == ATTRIBUTE_NODE))
	{
		if (node->getKey() > node->getEndKey())
			getchar();
	}
	else if (node->getKey() >= node->getEndKey())
		getchar();

	//#ifdef DEBUG_PARSER
	//	{
	//		int key = (int) node->getKey();
	//		cout << "delete node key = %d\n", key);
	//		this->valid[key] = false;
	//	}
	//#endif

	switch (node->getFlag())
	{
	case ATTRIBUTE_NODE:
		delete ((DM_AttributeNode*) node);
		break;

	case ELEMENT_NODE:
		delete ((DM_ElementNode*) node);
		break;

	case DOCUMENT_NODE:
		delete ((DM_DocumentNode*) node);
		break;

	case TEXT_NODE:
		delete ((DM_TextNode*) node);
		break;

	case COMMENT_NODE:
		delete ((DM_CommentNode*) node);
		break;

	default:
		break;
	}

}

/**
* Access Method
* Get the node information
* @return The node information
*/
DM_DataNode* MSXMLParserHandlers::getNodeFromDB(KeyType nodekey, serial_t* nrid)
{

	if (!nodekey.isValid()) return NULL;
	// variable definitions

	// the pointer to data node.
	DM_DataNode* nodepnt;
	rc_t rc;

	// the following three variable will be used as parameters to the SHORE/BerkeleyDB function calls. 
	bool found = false;
	serial_t noderid;
	smsize_t id_len = sizeof(noderid);

	// find the record id of the record that contains the node with the given key.
	rc = ss_m::find_assoc(this->volumeID, this->fileinfo->keyIndex, 
		vec_t(&nodekey, sizeof(KeyType)), &noderid, id_len, found);
	if (rc)
	{
		globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"MSXMLParserHandlers::getNodeFromDB",__FILE__,"Finding the record id of the record that contains the node with the given key failed");
		return NULL;
	}

	if (!found)
	{
		// in case that a node with the given key could not be found in the database, return NULL. 
		//cout << "Warning (reported in MSXMLParserHandlers::getNodeFromDB): "
		//	<< "node (key=" << nodekey.toString() << ") does not exist in this file" << endl;
		globalErrorInfo.insertProblem(ERR_TYPE_WARNING,__LINE__,"MSXMLParserHandlers::getNodeFromDB",__FILE__,"Finding the record id of the record that contains the node with the given key failed");
		return NULL;
	}
	else
	{			
		// if nrid is not NULL, this means the calling function expect the rid be returned.
		//if (nrid != NULL) *nrid = noderid;

		// get the record with the rid just found. 
		pin_i handler;
		rc = handler.pin(this->volumeID, noderid, 0);
		if (rc)
		{
			globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"MSXMLParserHandlers::getNodeFromDB",__FILE__,"Pinning record failed");
			return NULL;
		}

		// rebuild the node using the string obtained from the database. 
		nodepnt = DM_DataNode::unwrap((char*) handler.body());
		handler.unpin();

		// if nrid is not NULL, this means the calling function expect the rid be returned.
		if (nrid != NULL) *nrid = noderid;
	}

	return nodepnt;
}

/**
* Access Method
* Get the file information about the file just parsed.
* @returns The file information about the file just parsed.
*/
FileInfoType* MSXMLParserHandlers::getFileInfo()
{
	return this->fileinfo;
}

/**
* Access Method
* Get the start/end key of the root node of the document just parsed
*/
void MSXMLParserHandlers::getRootKeys(KeyType* startKey, KeyType* endKey)
{
	*startKey = this->rootStartKey;
	*endKey = this->rootEndKey;
}

/*
* Access Method
* 
* Given a node, returning its last child endkey if any
* @param node Data node that would like to find its last child's endkey
* @returns Key of the last child
*/
KeyType MSXMLParserHandlers::getLastChildEndKey(DM_DataNode* node)
{
	KeyType lastkey = node->getLastChild();
	if (lastkey == -1) { 
		//no last child, so attribute key instead (have attribute sure bcoz it's part of multicolored)
		//note: no way that the last child is text node of the duplicated multicolor node which key 
		//is not conformed to normal inclusion system, because only multicolred element node can be last child
		// any of its text node will be descendant, not child for sure
		lastkey = ((DM_ElementNode*) node)->getAttributes();
	}
	else {
		serial_t rid;
		DM_DataNode* lastchild = this->getNodeFromDB(lastkey, &rid);
		lastkey = lastchild->getEndKey();
		deleteNode(lastchild);
	}
	return lastkey;
}

/**
* Supporting Method
* Change a string from wchar* to char*
*/
char* MSXMLParserHandlers::wcharToChar(wchar_t* pwchVal, int cchVal)
{
	char* pchVal = new char[cchVal+1];
	int cursor = 0;

	bool prefixspace = true;
	bool midspace = false;

	for ( int i=0; i<cchVal; i++)
	{
		char ch;
		memcpy(&ch, pwchVal+i, 1);

		if (!((ch >= 33) && (ch <=126)))
			if (prefixspace)
				continue;
			else 
			{
				midspace = true;
				continue;
			}

			prefixspace = false;

			if (midspace)
			{
				pchVal[cursor] = ' ';
				cursor ++;
				midspace = false;
			}

			pchVal[cursor] = ch;
			cursor ++;

	}
	pchVal[cursor] = '\0';

	return pchVal;
}

/**
* Supporting Method
* Change a string from wchar* to char*, preserve Space
* 9-13: Non-Space white-space, HTab, LF, Vtab, FF, CR
* 32: Space
* 33-126: Printable characters
* others: Non-printable, non-white-space characters
* cchVal point to the position where LF or '<' is.
*/
char* MSXMLParserHandlers::wcharToCharPreserveSpace(wchar_t* pwchVal, int cchVal)
{
	char* pchVal = new char[cchVal+1];
	int cursor = 0;
	for (int i=0; i<cchVal; i++)
	{
        char ch = '\0';
		memcpy(&ch, pwchVal+i, 1);
        if (ch == ' ')
        {
            pchVal[cursor] = ' ';
            cursor++;
        } else if ( (ch >= 9) && (ch <= 13) )
        {
            bool isLeftWhite = false;
            bool isRightWhite = false;
            // if there is no left character or left character is not white-space
            if ( (cursor == 0) || (pchVal[cursor-1] != ' ') ) isLeftWhite = false;
            else isLeftWhite = true;
            // if there is no right character or right character is not white-space 
            // assume that pwchVal does not stop at cchVal
            if ( !( (pwchVal[i+1]>=9 && pwchVal[i+1]<=13) || (pwchVal[i+1]==' ') ) ) isRightWhite = false;
            else isRightWhite = true;
            if ( !isLeftWhite && !isRightWhite) 
            { // if there is no white-space surrounding it, convert it into Space
                pchVal[cursor] = ' ';
                cursor++;
            }
        } else
        {
            pchVal[cursor] = ch;
            cursor++;
        }
	}
	pchVal[cursor] = '\0';
	return pchVal;
}

/**
* Supporting Method
* Parse the name of the input XML document, split name and path
*/
void MSXMLParserHandlers::parse_name(char* str, char* path, char* filename)
{
	char* strpos;
	int pos;

	strpos = strrchr(str, '/');
	// Modified by Cong: "/" is UNIX convention, need to deal with "\" as well
	if (strpos == NULL) strpos = strrchr(str, '\\');
	// end of modification
	pos = (int) strpos - (int) str + 1;
	if (pos >=0)
	{
		strncpy(path, str, pos);
		path[pos] = '\0';
		strcpy(filename, strpos+1);
	}
	else 
	{
		strcpy(path, "./");
		strcpy(filename, str);
	}
}

/**
* Debug Method
* Keep track of the node count, and timing. 
* 
* TRICK: commit and restart transaction for every 10000 nodes. 
*/
void MSXMLParserHandlers::increaseNodeCount(KeyType key, int nodesize)
{
	char tmpbuf[128];

	this->nodeCount++;
	this->dataSize = this->dataSize + nodesize;
	if ( (this->nodeCount < 10000 && (this->nodeCount % 1000) == 0) ||
		(this->nodeCount % 10000 == 0) )
	{
		_strtime( tmpbuf );
		cout << this->nodeCount << " nodes have been parsed	" <<  "OS time:		" << tmpbuf  << endl;
	}

	if (this->operation != OP_PARSE_ONLY)
	{
		if ((this->nodeCount > 0) && (this->nodeCount % 10000 == 0))
		{
			rc_t rc = ss_m::commit_xct();
			if (rc)  
			{
				globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"MSXMLParserHandlers::increaseNodeCount",__FILE__,"After committing transaction");
			}

			rc = ss_m::begin_xct();
			if (rc)
			{
				globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"MSXMLParserHandlers::increaseNodeCount",__FILE__,"After beginning transaction");
			}
		}
	}
}	

/*
* Internal Method for Multicolor
*
* Copy a subtree from one colored tree to another by traversing in preorder 
* using a NodeStack to keep track of current node, its parent, its child
* @param rootnode The root node of the subtree that we would like to copy to another tree
* @param root_nrid Rootnode's record id
* @returns Whether it has any errors
*/
//Note: deletNode only for last child that has been discarded
//      not to delete the node that has been pop, because it may still associated with its parent in stack
int MSXMLParserHandlers::preorderTraversalAndCopy(DM_DataNode* rootnode, serial_t* root_nrid)
{

	//cutting duplication, so it will not be stack up and up
	this->cutting_depth++;
	//if ((this->cutting_depth > gSettings->getIntegerValue("MCT_CUTTING",MCT_CUTTING)) && (rootnode->getFlag() != TEXT_NODE)) {
	//  this->cutting_depth--;
	//	return;
	//}

	this->depth++;
	if (this->depth > this->maxDepth)
		this->maxDepth = this->depth;

	//Get its copied parent information
	NodeStackItem* copy_stItem = this->nodeStack->top();
	DM_ElementNode* copy_parent = (DM_ElementNode*) (copy_stItem->getNode()); // parent's element node
	DM_AttributeNode* copy_parentattr = (DM_AttributeNode*) copy_stItem->getAttribute(); //parent's attribute node
	if (copy_parentattr == NULL) {
		//get attrnode
		copy_parentattr = (DM_AttributeNode*)this->getNodeFromDB(copy_parent->getAttributes(), NULL);
	}
	DM_DataNode* copy_lastChild = copy_stItem->getLastChild();

	//if it is text node then just link with parent in stack
	if (rootnode->getFlag() == TEXT_NODE) {		

		//do not have to copy (parent must have attribute multicolor already for sure)
		if (((DM_CharNode*)rootnode)->getAttributes().isValid()) {
			//for debugging purpose, make sure every time attribute key is the same
			if (((DM_CharNode*)rootnode)->getAttributes() != copy_parentattr->getKey()) {
				globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"MSXMLParserHandlers::preorderTraversalAndCopy",__FILE__,"Inconsistent attribute key of a text node in multicolor");
				((DM_CharNode*)rootnode)->setAttributes(copy_parentattr->getKey());
				return E_FAIL;
			}
		}
		else {
			((DM_CharNode*)rootnode)->setAttributes(copy_parentattr->getKey()); //set link to attribute node of its parent
		}

		//get index for MCTParent & MCTTextNode
		int parentat = copy_parentattr->getParentIndex(copy_parent->getKey()); // must already added by the parent, with the master parent at index = 0
		int textat = copy_parentattr->getTextIndex(rootnode->getKey());
		if (textat == -1) { //have not yet add this text info into attribute node, so add it
			textat = copy_parentattr->addMCTTextNode(rootnode->getKey());
		}

		//it's the first time multicolored with this text, so set the master prev & next sibling info
		if (copy_parentattr->getMCTPrevSibling(0,textat) <= 0) {
			copy_parentattr->setMCTPrevSibling(textat,0,rootnode->getPrevSibling());
		}
		if (copy_parentattr->getMCTNextSibling(0,textat) <= 0) {
			copy_parentattr->setMCTNextSibling(textat,0,rootnode->getNextSibling());
		}

		if (copy_lastChild == NULL) { //It's the first child of its parent
			copy_parent->setFirstChild(rootnode->getKey());
			copy_parent->setLastChild(rootnode->getKey());

			copy_stItem->setLastChild(rootnode);
			copy_stItem->setLastChildRid(*root_nrid);

			copy_parentattr->setMCTPrevSibling(textat,parentat,-1);
			copy_parentattr->setMCTNextSibling(textat,parentat,-1);
		}
		else {
			copy_parent->setLastChild(rootnode->getKey());

			copy_lastChild->setNextSibling(rootnode->getKey()); //assume last child never be text node b/c text node cannot stay together, it will be clustered

			copy_parentattr->setMCTPrevSibling(textat,parentat,copy_lastChild->getKey());
			copy_parentattr->setMCTNextSibling(textat,parentat,-1);

			//update current last child to db
			int retval = this->modifyNodeInDB(copy_stItem->getLastChildRid(), copy_lastChild);
			if (retval != S_OK)
				return E_FAIL;

			copy_stItem->setLastChild(rootnode);
			copy_stItem->setLastChildRid(*root_nrid);

			this->deleteNode(copy_lastChild);
		}

		//clear next/prev sibling info, ???not important
		rootnode->setParent(-1);
		rootnode->setNextSibling(-1);
		rootnode->setPrevSibling(-1);

		serial_t copy_parentattr_noderid;
		smsize_t id_len = sizeof(copy_parentattr_noderid);
		bool found;
		KeyType pattrKey = copy_parentattr->getKey();

		// find the record id of the record that contains the node with the given key.
		int rc = ss_m::find_assoc(this->volumeID, this->fileinfo->keyIndex, vec_t(&pattrKey, sizeof(KeyType)), 
			&copy_parentattr_noderid, id_len, found);
		if (rc)
		{
			globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"MSXMLParserHandlers::preorderTraversalAndCopy",__FILE__,"Finding of copied parent attribute key failed");
			return E_FAIL;
		}

		int retval = this->modifyNodeInDB(copy_parentattr_noderid,copy_parentattr);
		if (retval != S_OK) return E_FAIL;

		retval = this->modifyNodeInDB(*root_nrid, rootnode);
		if (retval != S_OK) return E_FAIL;

		this->cutting_depth--;
		this->depth--;
		return E_FAIL;

	} //if text node


	DM_ElementNode* copy_node;
	DM_AttributeNode* attrnode = NULL; //same for both copy & master
	lrid_t attr_rid;

	//copy rootnode
	copy_node = new DM_ElementNode((DM_ElementNode*) rootnode);
	copy_node->setKey(this->nextKey);
	copy_node->setLevel((short)this->depth);
	if (this->nextKey > atof(this->fileinfo->maxKey.toString()))
		this->fileinfo->maxKey = this->nextKey;

	this->nextKey = this->nextKey+0.01;
	this->numEle++;

	//copy_parent->appendChild(copy_node, copy_lastChild);

	//// update the current last child of the node at the top of the stack
	//if (copy_lastChild != NULL)
	//{
	//	int retval = this->modifyNodeInDB(copy_stItem->getLastChildRid(), copy_lastChild);
	//		if (retval != S_OK)
	//			return E_FAIL;

	//	deleteNode(copy_lastChild);
	//}

	//get last child of the copied parent in stack
	if (copy_lastChild == NULL) {
		copy_parent->setFirstChild(copy_node->getKey());
		copy_parent->setLastChild(copy_node->getKey());

		copy_node->setPrevSibling(-1);
		copy_node->setNextSibling(-1);
		copy_node->setParent(copy_parent->getKey());
	}
	else {
		copy_parent->setLastChild(copy_node->getKey());

		copy_node->setPrevSibling(copy_lastChild->getKey());
		copy_node->setNextSibling(-1);
		copy_node->setParent(copy_parent->getKey());

		//if last child is text node must see multicolor
		if (copy_lastChild->getFlag() == TEXT_NODE) {
			//if its parent attribute have mctNum, textNum > 0, = multicolored
			if ((copy_parentattr->getMCTNum() > 0) && (copy_parentattr->getMCTTextNum() > 0)) {
				int parentat = copy_parentattr->getParentIndex(copy_parent->getKey()); 
				int textat = copy_parentattr->getTextIndex(copy_lastChild->getKey());
				copy_parentattr->setMCTNextSibling(textat,parentat,copy_node->getKey());
				//get rid for this copy_parentattr node
				bool found = false;
				serial_t copy_parentattr_noderid;
				smsize_t id_len = sizeof(copy_parentattr_noderid);
				KeyType pattKey = copy_parentattr->getKey();

				// find the record id of the record that contains the node with the given key.
				int rc = ss_m::find_assoc(this->volumeID, this->fileinfo->keyIndex, vec_t(&pattKey, sizeof(KeyType)), 
					&copy_parentattr_noderid, id_len, found);

				if (rc)
				{
					globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"MSXMLParserHandlers::preorderTraversalAndCopy",__FILE__,"Finding of copied parent attribute key failed");
					return E_FAIL;
				}
				int retval = this->modifyNodeInDB(copy_parentattr_noderid, copy_parentattr);

				if (retval != S_OK) return E_FAIL;
			}
			else {
				copy_lastChild->setNextSibling(copy_node->getKey());
			}
		}
		else {
			copy_lastChild->setNextSibling(copy_node->getKey());
		}

		//update current last child to db
		int retval = this->modifyNodeInDB(copy_stItem->getLastChildRid(), copy_lastChild);
		if (retval != S_OK) return E_FAIL;

		this->deleteNode(copy_lastChild);
	}

	//get attribute node
	if (((DM_ElementNode*)rootnode)->getAttributes().isValid()) {
		//if there is attribute, modify this attribute
		//first get the attribute node
		attrnode = (DM_AttributeNode*) this->getNodeFromDB(((DM_ElementNode*)rootnode)->getAttributes(),NULL);

		if (gSettings->getBooleanValue("MCT_SPECIAL",false)) 
		{
			//10/27/03 Special processing for billing & shipping address dual color
			if (strcspn(idrefTable->currentValue(),"0") == 0) 
			{
				Value* addrvalue = attrnode->getAttr("id");

				if (addrvalue != NULL) {

					//cout << "SPECIAL::: noting id " << addrvalue->getStrValue() << endl;

					char* thisid = new char[strlen(addrvalue->getStrValue())+1];

					strcpy(thisid,addrvalue->getStrValue());

					SpecialItem* sitem = new SpecialItem;

					sitem->billaddr = rootnode->getKey();
					sitem->shipaddr = copy_node->getKey();

					sTableMap->insert(std::make_pair(thisid, sitem));
				}
			}
		}
		//if (attrnode->getMCTNum() > 0) { //they are at least once duplicated
		//	attrnode->addMCTParent(copy_node->getKey());//add copy info
		//}
		//else {
		//	attrnode->addMCTParent(rootnode->getKey()); //add master info
		//	attrnode->addMCTParent(copy_node->getKey());//add copy info
		//}
		attrnode->addMCTParent(copy_node->getKey());//add copy info, do not need above bcoz was added during creation of @node

		serial_t attrnode_noderid;
		smsize_t id_len = sizeof(attrnode_noderid);
		bool found;
		KeyType aKey = attrnode->getKey();

		// find the record id of the record that contains the node with the given key.
		int rc = ss_m::find_assoc(this->volumeID, this->fileinfo->keyIndex, vec_t(&aKey, sizeof(KeyType)), 
			&attrnode_noderid, id_len, found);
		if (rc)
		{
			globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"MSXMLParserHandlers::preorderTraversalAndCopy",__FILE__,"Finding attribute node key failed");
			return E_FAIL;
		}

		//store by first deleting old attribute node then add again
		rc = this->modifyNodeInDB(attrnode_noderid,attrnode);
		if (rc != S_OK) return E_FAIL;
	}
	else {
		globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"MSXMLParserHandlers::preorderTraversalAndCopy",__FILE__,"You have come to the wrong place");
		return E_FAIL;
	}

	copy_node->setAttributes(attrnode->getKey());
	//store copied element node to db
	lrid_t copy_node_rid;
	int rc = this->storeNodeToDB(copy_node, &copy_node_rid);
	if (rc != S_OK) return E_FAIL;

	copy_stItem->setLastChild(copy_node);
	copy_stItem->setLastChildRid(copy_node_rid.serial);

	DM_DataNode* sibling;
	serial_t sibling_nrid;
	NodeStackItem* copy_rootitem;
	//push node into stack
	copy_rootitem = new NodeStackItem(copy_node);
	copy_rootitem->setAttribute(attrnode);
	copy_rootitem->setNodeRid(copy_node_rid.serial);
	this->nodeStack->push(copy_rootitem);

	sibling = this->getNodeFromDB(rootnode->getFirstChild(), &sibling_nrid);
	while (sibling != NULL)
	{
		int ret = this->preorderTraversalAndCopy(sibling,&sibling_nrid);

		if (ret != S_OK) return E_FAIL;

		//get next sibling
		//if current is text node
		DM_DataNode* oldsibling = sibling;
		if (sibling->getFlag() == TEXT_NODE) 
		{
			//its parent is surely multicolored now
			//go to attr of parent 
			sibling = this->getNodeFromDB(attrnode->getMCTNextSibling(copy_node->getKey(), sibling->getKey()),&sibling_nrid);
		}
		else 
		{
			sibling = this->getNodeFromDB(sibling->getNextSibling(),&sibling_nrid);
		}

		if (oldsibling->getFlag() != TEXT_NODE)
			this->deleteNode(oldsibling); //We can delete because it's the master copy, not need anymore
		//but if it is text node it will be delete later by delete(lastChild)
	}

	//pop stack
	NodeStackItem* eleitem = this->nodeStack->pop();
	DM_ElementNode* elenode = (DM_ElementNode*) (eleitem->getNode());

	// if the last child of the node is not NULL, delete it from memory
	// no change is needed for that node in SHORE. 
	DM_DataNode* lastchild = eleitem->getLastChild() ;
	if (lastchild != NULL) deleteNode(lastchild);

	deleteNode(eleitem->getAttribute());

	if (gSettings->getBooleanValue("MCT_SPECIAL",false)) 
	{ //leave room for the copied shipping address
		// this allowance must accommodate all order node under this address
		// and add up with other addresses in the same country not exceed MCT_ALLOWANCE
        char *tag = elenode->getTag(nameTable);
		if ((strcspn(idrefTable->currentValue(),"0") == 0) && (strcmp(tag,"address") == 0)) 
		{
			this->nextKey = this->nextKey + 40;
		}
        delete [] tag;
	}
	elenode->setEndKey(this->nextKey);
	if (this->nextKey > this->fileinfo->maxKey.toInt())
		this->fileinfo->maxKey = this->nextKey;

	this->nextKey = this->nextKey+0.01;

	// modify the element node in database. 
	int retval = this->modifyNodeInDB(eleitem->getNodeRid(), elenode);
	if (retval != S_OK) return E_FAIL;
	// delete the popped stackitem
	delete eleitem;

	this->depth--;
	this->cutting_depth--;
	return S_OK;
}

/*
* Internal Method for Multicolor
*
* Convert id/idref to proper multicolored trees
* @returns Whether it has any errors
*/
int MSXMLParserHandlers::multicolorConversion()
{
	int count = 0;
	IdrefItem* item;

	idrefTable->startScan();
	while (!idrefTable->eof()){
		item = idrefTable->next();
		count++;
		if (count%500 == 0) cout << "id-idref converted " << count << endl;
		if (item->idrefNum > 0) {
			//Get id element node
			serial_t idele_nrid,idelelastchild_nrid;
			DM_DataNode* idelenode = this->getNodeFromDB(item->idElementKey, &idele_nrid);
			if (idelenode == NULL){
				//cout << "Warning ID Value missing: " << idrefTable->currentValue() << endl;
				continue;
			}

			//cout << "ID value:" << idrefTable->currentValue();
			//cout << " element node " <<  idelenode->getKey().toString() << "," ;
			//cout << idelenode->getEndKey().toString() << endl;
			for (int i = 0 ; i < item->idrefNum ; i++) {
				serial_t idrefele_nrid,idrefelelastchild_nrid;
				//cout << item->idrefElement[i].idrefKey.toString() << endl;
				DM_DataNode* idelenode_lastchild = this->getNodeFromDB(idelenode->getLastChild(), &idelelastchild_nrid);
				DM_DataNode* idrefelenode = this->getNodeFromDB(item->idrefElement[i].idrefKey, &idrefele_nrid);
				DM_DataNode* idrefelenode_lastchild = this->getNodeFromDB(idrefelenode->getLastChild(), &idrefelelastchild_nrid);
				if (item->idrefElement[i].copydirection == 0) { // copy to source id
					//find the end key of the last child (if no child, get key of attribute node) of id element
					this->nextKey = this->getLastChildEndKey(idelenode).toInt()+1;
					//start copy at the idref element
					this->depth = idelenode->getLevel();
					//push merging point node and its lastchild into stack
					// push the node to stack
					NodeStackItem* stItem;;
					stItem = new NodeStackItem(idelenode);
					stItem->setNodeRid(idele_nrid);
					stItem->setLastChild(idelenode_lastchild);
					stItem->setLastChildRid(idelelastchild_nrid);
					this->nodeStack->push(stItem);
					this->cutting_depth = 0;

					int ret = this->preorderTraversalAndCopy(idrefelenode,&idrefele_nrid);
					if (ret != S_OK) return E_FAIL;

					//pop node and modify node, delete from mem, until stack empty
					((DM_ElementNode*)idelenode)->setChildNumber(idelenode->getChildNumber()+1); //Not use right now

					//should pop the merging point and modify it and its lastchild into DB
					stItem = this->nodeStack->pop();

					// delete the last child of the root node from memory
					DM_DataNode* lastchild = stItem->getLastChild();
					if (lastchild != NULL) this->deleteNode(lastchild);
					// modify the node in database. 
					int retval = this->modifyNodeInDB(stItem->getNodeRid(), stItem->getNode());
					if (retval != S_OK) return E_FAIL;

					//this->deleteNode(stItem->getNode());
					delete stItem;

				}
				else { //copy to source idref
					//find the end key of the last child (if no child, get key of attribute node) of idref element
					this->nextKey = this->getLastChildEndKey(idrefelenode).toInt()+1;
					this->depth = idrefelenode->getLevel();

					NodeStackItem* stItem;;
					stItem = new NodeStackItem(idrefelenode);
					stItem->setNodeRid(idrefele_nrid);
					stItem->setLastChild(idrefelenode_lastchild);
					stItem->setLastChildRid(idrefelelastchild_nrid);
					this->nodeStack->push(stItem);
					this->cutting_depth = 0;

					int ret = this->preorderTraversalAndCopy(idelenode,&idele_nrid);
					if (ret != S_OK) return E_FAIL;

					((DM_ElementNode*)idrefelenode)->setChildNumber(idrefelenode->getChildNumber()+1); //Not use right now
					//should pop the merging point and modify it and its lastchild into DB
					stItem = this->nodeStack->pop();

					// delete the last child of the root node from memory
					DM_DataNode* lastchild = stItem->getLastChild();
					if (lastchild != NULL) this->deleteNode(lastchild);
					// modify the node in database. 
					int retval = this->modifyNodeInDB(stItem->getNodeRid(), stItem->getNode());
					if (retval != S_OK) return E_FAIL;

					//this->deleteNode(stItem->getNode());
					delete stItem;
				}

				deleteNode(idrefelenode);
			}
			//cout << item->idElementKey.toString() << endl;
			deleteNode(idelenode);
		}
	}

	return S_OK;
}

/*
* Internal Method for Multicolor
*
* Convert id/idref to proper multicolored trees.
* A method same as multicolorConversion() but with specialized dualcolor address
* This is an ugly for SIGMOD2004 submisssion
* @returns Whether it has any errors
*/
int MSXMLParserHandlers::multicolorConversionSpecial()
{
	int count = 0;
	IdrefItem* item;

	if (gSettings->getBooleanValue("MCT_SPECIAL",false)) {
		sTableMap = new SpecialTableMapType;
	}

	idrefTable->startScan();
	while (!idrefTable->eof()){
		item = idrefTable->next();
		count++;
		if (count%500 == 0) cout << "id-idref converted " << count << endl;
		if (item->idrefNum > 0) {
			//Get id element node
			serial_t idele_nrid,idelelastchild_nrid;
			DM_DataNode* idelenode = this->getNodeFromDB(item->idElementKey, &idele_nrid);
			if (idelenode == NULL){
				globalErrorInfo.insertProblem(ERR_TYPE_WARNING,__LINE__,"MSXMLParserHandles::multicolorConversionSpecial",__FILE__,"ID Value missing");
				//cout << "Warning ID Value missing: " << idrefTable->currentValue() << endl;
				continue;
			}

			//cout << "ID value:" << idrefTable->currentValue();
			//cout << " element node " <<  idelenode->getKey().toString() << "," ;
			//cout << idelenode->getEndKey().toString() << endl;
			for (int i = 0 ; i < item->idrefNum ; i++) {
				if (item->idrefElement[i].flag == 1) //if it is billaddr idref
				{
					//Look up in special table
					if (sTableMap->find(idrefTable->currentValue()) != sTableMap->end())
					{ // found , let the id of billaddr mct as the starter for copying
						std::map<const char*, SpecialItem*, ltstr>::const_iterator k;

						k = sTableMap->find(idrefTable->currentValue());
						SpecialItem* matchaddrinfo = k->second;

						deleteNode(idelenode);
						idelenode = this->getNodeFromDB(matchaddrinfo->billaddr, &idele_nrid);
						if (idelenode == NULL){
							globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"MSXMLParserHandles::multicolorConversionSpecial",__FILE__,"Special table not given the existing node");
							return E_FAIL;
						}
					}
				}
				else if (item->idrefElement[i].flag == 2) // if it is shipaddr idref
				{
					//Look up in special table
					if (sTableMap->find(idrefTable->currentValue()) != sTableMap->end())
					{ // found , let the id of billaddr mct as the starter for copying

						std::map<const char*, SpecialItem*, ltstr>::const_iterator k;

						k = sTableMap->find(idrefTable->currentValue());
						SpecialItem* matchaddrinfo = k->second;

						deleteNode(idelenode);
						idelenode = this->getNodeFromDB(matchaddrinfo->shipaddr, &idele_nrid);
						if (idelenode == NULL)
						{
							globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"MSXMLParserHandles::multicolorConversionSpecial",__FILE__,"Special table not given the existing node");						
							return E_FAIL;
						}
					}
				}

				serial_t idrefele_nrid,idrefelelastchild_nrid;
				//cout << item->idrefElement[i].idrefKey.toString() << endl;
				DM_DataNode* idelenode_lastchild = this->getNodeFromDB(idelenode->getLastChild(), &idelelastchild_nrid);
				DM_DataNode* idrefelenode = this->getNodeFromDB(item->idrefElement[i].idrefKey, &idrefele_nrid);
				DM_DataNode* idrefelenode_lastchild = this->getNodeFromDB(idrefelenode->getLastChild(), &idrefelelastchild_nrid);
				if (item->idrefElement[i].copydirection == 0) { // copy to source id
					//find the end key of the last child (if no child, get key of attribute node) of id element
					this->nextKey = atof(this->getLastChildEndKey(idelenode).toString()) + 0.01;
					//start copy at the idref element
					this->depth = idelenode->getLevel();
					//push merging point node and its lastchild into stack
					// push the node to stack
					NodeStackItem* stItem;;
					stItem = new NodeStackItem(idelenode);
					stItem->setNodeRid(idele_nrid);
					stItem->setLastChild(idelenode_lastchild);
					stItem->setLastChildRid(idelelastchild_nrid);
					this->nodeStack->push(stItem);
					this->cutting_depth = 0;

					int ret = this->preorderTraversalAndCopy(idrefelenode,&idrefele_nrid);
					if (ret != S_OK) return E_FAIL;
					//pop node and modify node, delete from mem, until stack empty
					((DM_ElementNode*)idelenode)->setChildNumber(idelenode->getChildNumber()+1); //Not use right now

					//should pop the merging point and modify it and its lastchild into DB
					stItem = this->nodeStack->pop();

					// delete the last child of the root node from memory
					DM_DataNode* lastchild = stItem->getLastChild();
					if (lastchild != NULL) this->deleteNode(lastchild);
					// modify the node in database. 
					int retval = this->modifyNodeInDB(stItem->getNodeRid(), stItem->getNode());
					if (retval != S_OK) return E_FAIL;

					//this->deleteNode(stItem->getNode());
					delete stItem;

				}
				else { //copy to source idref
					//find the end key of the last child (if no child, get key of attribute node) of idref element
					this->nextKey = this->getLastChildEndKey(idrefelenode).toInt()+1;
					this->depth = idrefelenode->getLevel();

					NodeStackItem* stItem;;
					stItem = new NodeStackItem(idrefelenode);
					stItem->setNodeRid(idrefele_nrid);
					stItem->setLastChild(idrefelenode_lastchild);
					stItem->setLastChildRid(idrefelelastchild_nrid);
					this->nodeStack->push(stItem);
					this->cutting_depth = 0;

					int ret = this->preorderTraversalAndCopy(idelenode,&idele_nrid);
					if (ret != S_OK) return E_FAIL;

					((DM_ElementNode*)idrefelenode)->setChildNumber(idrefelenode->getChildNumber()+1); //Not use right now
					//should pop the merging point and modify it and its lastchild into DB
					stItem = this->nodeStack->pop();

					// delete the last child of the root node from memory
					DM_DataNode* lastchild = stItem->getLastChild();
					if (lastchild != NULL) this->deleteNode(lastchild);
					// modify the node in database. 
					int retval = this->modifyNodeInDB(stItem->getNodeRid(), stItem->getNode());
					if (retval != S_OK) return E_FAIL;

					//this->deleteNode(stItem->getNode());
					delete stItem;
				}

				deleteNode(idrefelenode);
			}
			//cout << item->idElementKey.toString() << endl;
			deleteNode(idelenode);
		}
	}

	if (gSettings->getBooleanValue("MCT_SPECIAL",false)) {
		std::map<const char*, SpecialItem*, ltstr>::const_iterator k;

		for (k = sTableMap->begin(); k != sTableMap->end(); ++k) {
			delete k->second;
			delete k->first;
		}
		sTableMap->clear();
		delete sTableMap;
	}
	return 0;
}

/**
* Debug Method
* 
* Print the summary information about the XML document being parsed.
* The information includes the number of nodes, number of elements, attribute, text... nodes
* and the estimated data file size. 
*/
void MSXMLParserHandlers::printSummary()
{
	cout << "\n\n-----------------------------" << endl;
	cout << "node number = " << this->nodeCount << endl;
	cout << "max level = " << this->maxDepth << endl;
	cout<<"Num elements:"<<numEle<<endl;
	cout<<"Num attributes:"<<numAttr<<endl;
	cout<<"Num text:"<<numText<<endl;
	cout<<"Num doc:"<<numDoc<<endl;
	cout<<"Data size (in bytes):"<<dataSize<<endl;

#ifdef DEBUG_PARSER
	{
		for (int i=0; i<this->nextKey; i++)
			if (this->valid[i])
				cout << "valid at key = " << i << endl;

		cout << "unreleased stackitem number = " << this->stackitemcount << endl;
		cout << "pin number = " << this->pinCount << endl;
		cout << "unpin number = " << this->unpinCount << endl;
		cout << "store number = " << this->storeCount << endl;
		cout << "modify number = " << this->modifyCount << endl;
	}
#endif
}
