/*
COPYRIGHT  (c) 2000-2004 
THE REGENTS OF THE UNIVERSITY OF MICHIGAN
ALL RIGHTS RESERVED

PERMISSION IS GRANTED TO USE, COPY, CREATE DERIVATIVE WORKS AND
REDISTRIBUTE THIS SOFTWARE AND SUCH DERIVATIVE WORKS FOR NONCOMMERCIAL
EDUCATION AND RESEARCH PURPOSES, SO LONG AS NO FEE IS CHARGED, AND SO LONG
AS THE COPYRIGHT NOTICE ABOVE, THIS GRANT OF PERMISSION, AND THE
DISCLAIMER BELOW APPEAR IN ALL COPIES MADE; AND SO LONG AS THE NAME OF THE
UNIVERSITY OF MICHIGAN IS NOT USED IN ANY ADVERTISING OR PUBLICITY
PERTAINING TO THE USE OR DISTRIBUTION OF THIS SOFTWARE WITHOUT SPECIFIC,
WRITTEN PRIOR AUTHORIZATION.

THIS SOFTWARE IS PROVIDED AS IS, WITHOUT REPRESENTATION FROM THE
UNIVERSITY OF MICHIGAN AS TO ITS FITNESS FOR ANY PURPOSE, AND WITHOUT
WARRANTY BY THE UNIVERSITY OF MICHIGAN OF ANY KIND, EITHER EXPRESS OR
IMPLIED, INCLUDING WITHOUT LIMITATION THE IMPLIED WARRANTIES OF
MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE. THE REGENTS OF THE
UNIVERSITY OF MICHIGAN SHALL NOT BE LIABLE FOR ANY DAMAGES, INCLUDING
SPECIAL, INDIRECT, INCIDENTAL, OR CONSEQUENTIAL DAMAGES, WITH RESPECT TO
ANY CLAIM ARISING OUT OF OR IN CONNECTION WITH THE USE OF THE SOFTWARE,
EVEN IF IT HAS BEEN OR IS HEREAFTER ADVISED OF THE POSSIBILITY OF SUCH
DAMAGES.
*/

/**
 * @author Nuwee Wiwatwattana
 * @author Yuqing (Melanie) Wu
 */

////////////////////////////////////////////////////////////////////// 
// SAXContentHandlerImpl.cpp: implementation of the SAXContentHandlerImpl class.
////////////////////////////////////////////////////////////////////// 

#include "stdafx.h" 
#include "SAXContentHandlerImpl.h" 
#pragma warning(disable: 4100)
////////////////////////////////////////////////////////////////////// 
// Construction/Destruction 
////////////////////////////////////////////////////////////////////// 


SAXContentHandlerImpl::SAXContentHandlerImpl() 
{ 
} 

SAXContentHandlerImpl::~SAXContentHandlerImpl() 
{ 
} 

HRESULT STDMETHODCALLTYPE SAXContentHandlerImpl::putDocumentLocator(  
            /* [in] */ ISAXLocator __RPC_FAR *pLocator) 
{ 
    return S_OK; 
} 
         
HRESULT STDMETHODCALLTYPE SAXContentHandlerImpl::startDocument() 
{ 
    return S_OK; 
} 

HRESULT STDMETHODCALLTYPE SAXContentHandlerImpl::endDocument( void) 
{ 
    return S_OK; 
} 
    
HRESULT STDMETHODCALLTYPE SAXContentHandlerImpl::startPrefixMapping(  
            /* [in] */ wchar_t __RPC_FAR *pwchPrefix, 
            /* [in] */ int cchPrefix, 
            /* [in] */ wchar_t __RPC_FAR *pwchUri, 
            /* [in] */ int cchUri) 
{ 
    return S_OK; 
} 

HRESULT STDMETHODCALLTYPE SAXContentHandlerImpl::endPrefixMapping(  
            /* [in] */ wchar_t __RPC_FAR *pwchPrefix, 
            /* [in] */ int cchPrefix) 
{ 
    return S_OK; 
} 

HRESULT STDMETHODCALLTYPE SAXContentHandlerImpl::startElement(  
            /* [in] */ wchar_t __RPC_FAR *pwchNamespaceUri, 
            /* [in] */ int cchNamespaceUri, 
            /* [in] */ wchar_t __RPC_FAR *pwchLocalName, 
            /* [in] */ int cchLocalName, 
            /* [in] */ wchar_t __RPC_FAR *pwchRawName, 
            /* [in] */ int cchRawName, 
            /* [in] */ ISAXAttributes __RPC_FAR *pAttributes) 
{ 
    return S_OK; 
} 

HRESULT STDMETHODCALLTYPE SAXContentHandlerImpl::endElement(  
            /* [in] */ wchar_t __RPC_FAR *pwchNamespaceUri, 
            /* [in] */ int cchNamespaceUri, 
            /* [in] */ wchar_t __RPC_FAR *pwchLocalName, 
            /* [in] */ int cchLocalName, 
            /* [in] */ wchar_t __RPC_FAR *pwchRawName, 
            /* [in] */ int cchRawName) 
{ 
    return S_OK; 
} 

HRESULT STDMETHODCALLTYPE SAXContentHandlerImpl::characters(  
            /* [in] */ wchar_t __RPC_FAR *pwchChars, 
            /* [in] */ int cchChars) 
{ 
    return S_OK; 
} 

HRESULT STDMETHODCALLTYPE SAXContentHandlerImpl::ignorableWhitespace(  
            /* [in] */ wchar_t __RPC_FAR *pwchChars, 
            /* [in] */ int cchChars) 
{ 
    return S_OK; 
} 

HRESULT STDMETHODCALLTYPE SAXContentHandlerImpl::processingInstruction(  
            /* [in] */ wchar_t __RPC_FAR *pwchTarget, 
            /* [in] */ int cchTarget, 
            /* [in] */ wchar_t __RPC_FAR *pwchData, 
            /* [in] */ int cchData) 
{ 
    return S_OK; 
} 

HRESULT STDMETHODCALLTYPE SAXContentHandlerImpl::skippedEntity(  
            /* [in] */ wchar_t __RPC_FAR *pwchVal, 
            /* [in] */ int cchVal) 
{ 
    return S_OK; 
} 

long __stdcall SAXContentHandlerImpl::QueryInterface(const struct _GUID &riid,void ** ppvObject) 
{ 
    // hack-hack-hack! 
    return 0; 
} 

unsigned long __stdcall SAXContentHandlerImpl::AddRef() 
{ 
    // hack-hack-hack! 
    return 0; 
} 

unsigned long __stdcall SAXContentHandlerImpl::Release() 
{ 
    // hack-hack-hack! 
    return 0; 
} 
