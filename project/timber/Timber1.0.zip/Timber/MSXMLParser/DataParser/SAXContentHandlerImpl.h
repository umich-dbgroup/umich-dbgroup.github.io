/*
COPYRIGHT  (c) 2000-2004 
THE REGENTS OF THE UNIVERSITY OF MICHIGAN
ALL RIGHTS RESERVED

PERMISSION IS GRANTED TO USE, COPY, CREATE DERIVATIVE WORKS AND
REDISTRIBUTE THIS SOFTWARE AND SUCH DERIVATIVE WORKS FOR NONCOMMERCIAL
EDUCATION AND RESEARCH PURPOSES, SO LONG AS NO FEE IS CHARGED, AND SO LONG
AS THE COPYRIGHT NOTICE ABOVE, THIS GRANT OF PERMISSION, AND THE
DISCLAIMER BELOW APPEAR IN ALL COPIES MADE; AND SO LONG AS THE NAME OF THE
UNIVERSITY OF MICHIGAN IS NOT USED IN ANY ADVERTISING OR PUBLICITY
PERTAINING TO THE USE OR DISTRIBUTION OF THIS SOFTWARE WITHOUT SPECIFIC,
WRITTEN PRIOR AUTHORIZATION.

THIS SOFTWARE IS PROVIDED AS IS, WITHOUT REPRESENTATION FROM THE
UNIVERSITY OF MICHIGAN AS TO ITS FITNESS FOR ANY PURPOSE, AND WITHOUT
WARRANTY BY THE UNIVERSITY OF MICHIGAN OF ANY KIND, EITHER EXPRESS OR
IMPLIED, INCLUDING WITHOUT LIMITATION THE IMPLIED WARRANTIES OF
MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE. THE REGENTS OF THE
UNIVERSITY OF MICHIGAN SHALL NOT BE LIABLE FOR ANY DAMAGES, INCLUDING
SPECIAL, INDIRECT, INCIDENTAL, OR CONSEQUENTIAL DAMAGES, WITH RESPECT TO
ANY CLAIM ARISING OUT OF OR IN CONNECTION WITH THE USE OF THE SOFTWARE,
EVEN IF IT HAS BEEN OR IS HEREAFTER ADVISED OF THE POSSIBILITY OF SUCH
DAMAGES.
*/

/**
 * @author Yuqing (Melanie) Wu
 */

////////////////////////////////////////////////////////////////////// 
// SAXContentHandlerImpl.h: interface for the SAXContentHandlerImpl class. 
////////////////////////////////////////////////////////////////////// 

#if !defined(AFX_SAXCONTENTHANDLERIMPL_H__517D91C0_0BCF_474D_A77C_10EE27231233__INCLUDED_) 
#define AFX_SAXCONTENTHANDLERIMPL_H__517D91C0_0BCF_474D_A77C_10EE27231233__INCLUDED_ 

#if _MSC_VER > 1000 
#pragma once 
#endif // _MSC_VER > 1000 

class SAXContentHandlerImpl : public ISAXContentHandler   
{ 
public: 
    SAXContentHandlerImpl(); 
    virtual ~SAXContentHandlerImpl(); 

        // This must be correctly implemented, if your handler must be a COM Object (in this example it does not) 
        long __stdcall QueryInterface(const struct _GUID &,void ** ); 
        unsigned long __stdcall AddRef(void); 
        unsigned long __stdcall Release(void); 

        virtual HRESULT STDMETHODCALLTYPE putDocumentLocator(  
            /* [in] */ ISAXLocator __RPC_FAR *pLocator); 
         
        virtual HRESULT STDMETHODCALLTYPE startDocument( void); 
         
        virtual HRESULT STDMETHODCALLTYPE endDocument( void); 
         
        virtual HRESULT STDMETHODCALLTYPE startPrefixMapping(  
            /* [in] */ wchar_t __RPC_FAR *pwchPrefix, 
            /* [in] */ int cchPrefix, 
            /* [in] */ wchar_t __RPC_FAR *pwchUri, 
            /* [in] */ int cchUri); 
         
        virtual HRESULT STDMETHODCALLTYPE endPrefixMapping(  
            /* [in] */ wchar_t __RPC_FAR *pwchPrefix, 
            /* [in] */ int cchPrefix); 
         
        virtual HRESULT STDMETHODCALLTYPE startElement(  
            /* [in] */ wchar_t __RPC_FAR *pwchNamespaceUri, 
            /* [in] */ int cchNamespaceUri, 
            /* [in] */ wchar_t __RPC_FAR *pwchLocalName, 
            /* [in] */ int cchLocalName, 
            /* [in] */ wchar_t __RPC_FAR *pwchRawName, 
            /* [in] */ int cchRawName, 
            /* [in] */ ISAXAttributes __RPC_FAR *pAttributes); 
         
        virtual HRESULT STDMETHODCALLTYPE endElement(  
            /* [in] */ wchar_t __RPC_FAR *pwchNamespaceUri, 
            /* [in] */ int cchNamespaceUri, 
            /* [in] */ wchar_t __RPC_FAR *pwchLocalName, 
            /* [in] */ int cchLocalName, 
            /* [in] */ wchar_t __RPC_FAR *pwchRawName, 
            /* [in] */ int cchRawName); 
         
        virtual HRESULT STDMETHODCALLTYPE characters(  
            /* [in] */ wchar_t __RPC_FAR *pwchChars, 
            /* [in] */ int cchChars); 
         
        virtual HRESULT STDMETHODCALLTYPE ignorableWhitespace(  
            /* [in] */ wchar_t __RPC_FAR *pwchChars, 
            /* [in] */ int cchChars); 
         
        virtual HRESULT STDMETHODCALLTYPE processingInstruction(  
            /* [in] */ wchar_t __RPC_FAR *pwchTarget, 
            /* [in] */ int cchTarget, 
            /* [in] */ wchar_t __RPC_FAR *pwchData, 
            /* [in] */ int cchData); 
         
        virtual HRESULT STDMETHODCALLTYPE skippedEntity(  
            /* [in] */ wchar_t __RPC_FAR *pwchName, 
            /* [in] */ int cchName); 

}; 

#endif // !defined(AFX_SAXCONTENTHANDLERIMPL_H__517D91C0_0BCF_474D_A77C_10EE27231233__INCLUDED_) 
