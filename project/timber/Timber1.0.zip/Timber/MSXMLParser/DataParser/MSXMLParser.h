/*
COPYRIGHT  (c) 2000-2004 
THE REGENTS OF THE UNIVERSITY OF MICHIGAN
ALL RIGHTS RESERVED

PERMISSION IS GRANTED TO USE, COPY, CREATE DERIVATIVE WORKS AND
REDISTRIBUTE THIS SOFTWARE AND SUCH DERIVATIVE WORKS FOR NONCOMMERCIAL
EDUCATION AND RESEARCH PURPOSES, SO LONG AS NO FEE IS CHARGED, AND SO LONG
AS THE COPYRIGHT NOTICE ABOVE, THIS GRANT OF PERMISSION, AND THE
DISCLAIMER BELOW APPEAR IN ALL COPIES MADE; AND SO LONG AS THE NAME OF THE
UNIVERSITY OF MICHIGAN IS NOT USED IN ANY ADVERTISING OR PUBLICITY
PERTAINING TO THE USE OR DISTRIBUTION OF THIS SOFTWARE WITHOUT SPECIFIC,
WRITTEN PRIOR AUTHORIZATION.

THIS SOFTWARE IS PROVIDED AS IS, WITHOUT REPRESENTATION FROM THE
UNIVERSITY OF MICHIGAN AS TO ITS FITNESS FOR ANY PURPOSE, AND WITHOUT
WARRANTY BY THE UNIVERSITY OF MICHIGAN OF ANY KIND, EITHER EXPRESS OR
IMPLIED, INCLUDING WITHOUT LIMITATION THE IMPLIED WARRANTIES OF
MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE. THE REGENTS OF THE
UNIVERSITY OF MICHIGAN SHALL NOT BE LIABLE FOR ANY DAMAGES, INCLUDING
SPECIAL, INDIRECT, INCIDENTAL, OR CONSEQUENTIAL DAMAGES, WITH RESPECT TO
ANY CLAIM ARISING OUT OF OR IN CONNECTION WITH THE USE OF THE SOFTWARE,
EVEN IF IT HAS BEEN OR IS HEREAFTER ADVISED OF THE POSSIBILITY OF SUCH
DAMAGES.
*/

/**
 * @author Yuqing (Melanie) Wu
 */

#ifndef __MSXMLParser_H
#define __MSXMLParser_H

#include "stdafx.h" 
#include "MSXMLParserHandlers.h" 
#include "../../PhysicalDataMng/SystemCatalog/XMLNameTable.h"

/**
* class MSXMLParser
* 
* This class handles XML data parsing and storing the parsing result 
* (nodes) into database.  MSXML parser is used. The callback functions 
* in MSXMLParserHandlers are used for storing the parsing result into 
* Timber. 
* 
* @see MSXMLParserHandlers
*/

class MSXMLParser
{
public:
	/**
	* Constructor
	* Initialize the MSXMLParser
	* @param volumnID The id of the volume in which the data file is to be stored. 
	*/
	MSXMLParser(lvid_t volumeID);
	~MSXMLParser();

	/**
	* Process Method
	* 
	* Parser the given XML document and store the parsing result -- nodes -- into data file in the 
	* database.
	*
	* @param filename The name of the XML document, with path
	* @param maxdepth The estimated maximum depth of the XML document
	* @param operation The operation associated with data parsing. the value can be OP_PARSE_ONLY, 
	*		OP_PARSE_STORE or OP_PARSE_APPEND.
	* @param fileinfo The information of the data file to be appended to (used when operation is OP_PARSE_APPEND).
	* @param nodestack The nodestack that contains nodes from the root to the node while will be the parent
	*		of the root of the XML document being parsed (used when operation is OP_PARSE_APPEND).
	* @param adphander The append handler for appending nodes to the tail of a data file (used when operation is OP_PARSE_APPEND).
	* @param startKey/endKey The start key and end key of the root of the new document (return value, for parse-and-append).
	* @param convertmulticolor The flag saying whether to convert pointer-based to multicolor model (Nuwee added 07/14/03)
	* @returns The fileinfo of the data file which stores the data nodes from the incoming XML document
	*/	
	FileInfoType* parseXML(char* filename,  
						   int maxdepth,    
						   int operation,	   
						   FileInfoType* fileinfo,
						   NodeStack* nodestack,
						   append_file_i* apthandler,
						   KeyType* startKey,
						   KeyType* endKey,
						   bool convertmulticolor,
                           XMLNameTable *xmlNameTable);

	
private:
	/**
	* The id of the volume on which the data is to be stored
	*/
	lvid_t volumeID;

	/**
	* The anem of the XML document to be parsed.
	*/
	char* fileName;

	/**
	* The estimated maximum depth of the document
	*/
	int maxDepth;
	
};

#endif
