/*
COPYRIGHT  (c) 2000-2004 
THE REGENTS OF THE UNIVERSITY OF MICHIGAN
ALL RIGHTS RESERVED

PERMISSION IS GRANTED TO USE, COPY, CREATE DERIVATIVE WORKS AND
REDISTRIBUTE THIS SOFTWARE AND SUCH DERIVATIVE WORKS FOR NONCOMMERCIAL
EDUCATION AND RESEARCH PURPOSES, SO LONG AS NO FEE IS CHARGED, AND SO LONG
AS THE COPYRIGHT NOTICE ABOVE, THIS GRANT OF PERMISSION, AND THE
DISCLAIMER BELOW APPEAR IN ALL COPIES MADE; AND SO LONG AS THE NAME OF THE
UNIVERSITY OF MICHIGAN IS NOT USED IN ANY ADVERTISING OR PUBLICITY
PERTAINING TO THE USE OR DISTRIBUTION OF THIS SOFTWARE WITHOUT SPECIFIC,
WRITTEN PRIOR AUTHORIZATION.

THIS SOFTWARE IS PROVIDED AS IS, WITHOUT REPRESENTATION FROM THE
UNIVERSITY OF MICHIGAN AS TO ITS FITNESS FOR ANY PURPOSE, AND WITHOUT
WARRANTY BY THE UNIVERSITY OF MICHIGAN OF ANY KIND, EITHER EXPRESS OR
IMPLIED, INCLUDING WITHOUT LIMITATION THE IMPLIED WARRANTIES OF
MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE. THE REGENTS OF THE
UNIVERSITY OF MICHIGAN SHALL NOT BE LIABLE FOR ANY DAMAGES, INCLUDING
SPECIAL, INDIRECT, INCIDENTAL, OR CONSEQUENTIAL DAMAGES, WITH RESPECT TO
ANY CLAIM ARISING OUT OF OR IN CONNECTION WITH THE USE OF THE SOFTWARE,
EVEN IF IT HAS BEEN OR IS HEREAFTER ADVISED OF THE POSSIBILITY OF SUCH
DAMAGES.
*/

/**
* @author Nuwee Wiwatwattana
* @author Yuqing (Melanie) Wu
*/

#ifndef __MSXMLPARSERHANDLERS_H
#define __MSXMLPARSERHANDLERS_H 

#include <stack>
#include "SAXContentHandlerImpl.h" 
#include "NodeStack.h"
#include "IdrefTable.h"
#include "../TreeStructure/DM_DocumentNode.h"
#include "../Treestructure/DM_AttributeNode.h"
#include "../Treestructure/DM_CharNode.h"
#include "../TreeStructure/TreeStructure_definitions.h"
#include "../../PhysicalDataMng/SystemCatalog/XMLNameTable.h"

#define OP_PARSE_ONLY		0
#define OP_PARSE_STORE		1
#define OP_PARSE_APPEND		2

/**
* For Multicolor
* Elements for color stack
* ekey is the key of the root of subtree
* num is number of colors of this subtree rooted at ekey
**/
typedef struct {
	KeyType ekey;
	int num;
} cstack;

/**
* datatype FileInfoType
*
* This type definition defines a data type -- FileInfoType -- whichis used to store information
* about a data file in the database.
*
* An XML document can be stored in a data file in the database. A datafile can also contains 
* nodes from multiple XML document, loaded into the database using append functions. 
*
* The information about a data file are :
*	key: The name of the data file. It is the document name if the data file contains data from single
*			XML document, or the name of the first XML document, if the data file contains data from
*			more than one XML document. 
*	fid: The file id for the data
*	rootKey: The start key of the root node. (in current implementation, it is always 0 after loading, 
*			however, it may changes after modification.)
*	firstRid: The record id of the first record (usually the root node) in the data file. 
*	keyIndex: An index associated with the data file which maps the start key of a node to 
*			the record id that contains the node. 
*	recNum: The total number of records (nodes) in the data file.
*	maxKepth: The height of the tree structure of the XML document.
*	maxKey: The maximum key value assigned to the start key for nodes in the data file.
*		Actually, maxKey is treated as the 'largest endKey + 1' by the MSXMLParser files.
*		AppendDataNodeToDB in the PhysicalDataMng has been modified to coincide with this interpretation.
*
*	dataSize: The esitmated size (in byte) of the data file.
*	overflow: A boolean value which indicate whether the records in the data file are stored in 
*			the key order. 
*	firstOverflowNodeKey: In case the records in the data file are not stored in order (this 
*			happends after modification), the first part of the data file is still under the key
*			order, while the second half of the file has nodes in random order. We call the second 
*			half overflowSection. This field keeps the key of the first node in the overflow section. 
*/
typedef struct {
	/**
	*	The name of the data file. It is the document name if the data file contains data from single
	*	XML document, or the name of the first XML document, if the data file contains data from
	*	more than one XML document. 
	*/
	char        key[MAX_FILE_NAME_LENGTH];

	/**
	*	The file id for the data
	*/
	serial_t 	fid;

	/**
	* The start key of the root node. (in current implementation, it is always 0 after loading, 
	* however, it may changes after modification.)
	*/
	KeyType 	rootKey;

	/**
	* The record id of the first record (usually the root node) in the data file. 
	*/
	serial_t	firstRid;

	/**
	* An index associated with the data file which maps the start key of a node to 
	* the record id that contains the node. 
	*/
	serial_t	keyIndex;

	/**
	* The total number of records (nodes) in the data file.
	*/
	int 		recNum;

	/**
	* The height of the tree structure of the XML document.
	*/
	int			maxDepth;

	/**
	* The maximum key value assigned to the start key for nodes in the data file. 
	*/
	KeyType		maxKey;

	/**
	* The esitmated size (in byte) of the data file.
	*/
	float		dataSize;

	/**
	* A boolean value which indicate whether the records in the data file are stored in 
	* the key order. 
	*/
	bool		overflow;

	/**
	* In case the records in the data file are not stored in order (this 
	* happends after modification), the first part of the data file is still under the key
	* order, while the second half of the file has nodes in random order. We call the second 
	* half overflowSection. This field keeps the key of the first node in the overflow section. 
	*/
	KeyType		firstOverflowNodeKey;

}  FileInfoType;

/**
* class MSXMLParserHandlers
*
* This class define a set of callback functions for each incident in the data parsing process.
* The callback functions interpretate the data returned by the parser and stored them into
* database. 
* 
* @see FileInfoType
* @see PhysicalDataMng
*/

class MSXMLParserHandlers : public SAXContentHandlerImpl   
{ 
public: 
	/**
	* Constructor
	* 
	* This constructor is for parsing the data only. 
	* Given the name of the XML document, It initialize the variable for performaing data parsing. 
	*
	* @param filename The name of the XML document, with path. 
	*/
	MSXMLParserHandlers(char* filename, XMLNameTable *xmlNameTable);

	/**
	* Constructor
	*
	* This is for the case that the file will be stored alone in database, or it is the first document
	* among document that are to be stored together in one data file. 
	* 
	* For this purpose, a new data file and a new key index is created before the actually loading process. 
	*
	* @param volumeID The volumn in which the data file is to be created. 
	* @param filename The name of the XML document, with path. 
	* @param maxdepth The maximum depth of the xml document. 
	* @param convertmulticolor The flag saying whether to convert pointer-based to multicolor model (Nuwee added 07/14/03)
	*/    
	MSXMLParserHandlers(lvid_t volumeID, 
		char* filename, 
		int maxdepth,
		bool convertmulticolor,
        XMLNameTable *xmlNameTable);

	/**
	* Constructor
	*
	* This is for appending a new XML document to another one which is already in database.
	* 
	* @param volumeID The volumn in which the data file is to be created. 
	* @param filename The name of the XML document ( with path) to be appended to the existing file.
	* @param maxdepth The maximum depth of the xml document. 
	* @param appendtofileinfo The fileinfo of the existing file. 
	* @param nodestack The nodestack for the existing file, which contains all nodes from the root to the node
	*		at which the root of the new document is to be appended. 
	* @param apdhandler An append handler for the old data file. 
	*/
	MSXMLParserHandlers(lvid_t volumeID, 
		char* filename, 
		int maxdepth,
		FileInfoType* fileinfo,
		NodeStack* nodestack, 
		append_file_i* apthandler,
        XMLNameTable *xmlNameTable);

	/**
	* Destructor
	* 
	* release the append handler and the node stack. 
	*/   
	virtual ~MSXMLParserHandlers(); 

	/**
	* callback function for StartElement
	* 
	* It create a new element node for the element, a new attribute node for attributes, if there is any. 
	* Text value is accumulated and handled here. This is to deal with the general case that one element may
	* have more than one piece of text, interleaved by its subelements.
	*/
	HRESULT STDMETHODCALLTYPE startElement(  
		/* [in] */ wchar_t __RPC_FAR *pwchNamespaceUri, 
		/* [in] */ int cchNamespaceUri, 
		/* [in] */ wchar_t __RPC_FAR *pwchLocalName, 
		/* [in] */ int cchLocalName, 
		/* [in] */ wchar_t __RPC_FAR *pwchRawName, 
		/* [in] */ int cchRawName, 
		/* [in] */ ISAXAttributes __RPC_FAR *pAttributes); 


		/**
		* Callback function for end element
		* 
		* It poppes the element at the top of the stack, now, it is done with its last child and it could be removed
		* from the stack. Please note we have not done with the element whose end tag is reached. Later, its 
		* nextSibling link may change in the startElement callback of its next sibling node. 
		* After this callback, the node on the top of the stack should be the parent of the node just ends. 
		* And the nodes just ends is in the lastChild field of the item at the top of the stack. 
		*/
		HRESULT STDMETHODCALLTYPE endElement(  
		/* [in] */ wchar_t __RPC_FAR *pwchNamespaceUri, 
		/* [in] */ int cchNamespaceUri, 
		/* [in] */ wchar_t __RPC_FAR *pwchLocalName, 
		/* [in] */ int cchLocalName, 
		/* [in] */ wchar_t __RPC_FAR *pwchRawName, 
		/* [in] */ int cchRawName); 


		/**
		* Callback function for startDocument
		*
		* Create a document node and stored it into data base. 
		* Incase the operation is parse-and-append, skip the document node
		*/
		HRESULT STDMETHODCALLTYPE startDocument(); 

	/**
	* Callback function for end document
	*
	* For parse-and-count, and parse-and-store, at the time when the parsing is done, there should be 
	* only the document node left in the stack. Just pop the node, assign end key to it, and print the summery 
	* information. 
	*
	* Things get complicated when the XML document being parses is to be appended to an existing document
	* and the appending does not happens at the root node. At these time, all the nodes from the root
	* to the append node are still in the stack. need to handle them one by one, assign end key to them and 
	* write them to the database. 
	*/
	HRESULT STDMETHODCALLTYPE endDocument(); 

	/**
	* Callback function for text content
	*
	* This function create a text node and append it to the element node in stack, which should be its
	* parent in our database. 
	*/
	HRESULT STDMETHODCALLTYPE characters(  
		/* [in] */ wchar_t __RPC_FAR *pwchChars, 
		/* [in] */ int cchChars);

    HRESULT STDMETHODCALLTYPE ignorableWhitespace(  
        /* [in] */ wchar_t __RPC_FAR *pwchChars, 
        /* [in] */ int cchChars);

    /**
    * Access Method
    * Get the file information about the file just parsed.
    * @returns The file information about the file just parsed.
    */
    FileInfoType* getFileInfo();

    /**
    * Access Method
	* Get the start/end key of the root node of the document just parsed
	*/
	void getRootKeys(KeyType* startKey, KeyType* endKey);

	/**
	* Debug Method
	* 
	* Print the summary information about the XML document being parsed.
	* The information includes the number of nodes, number of elements, attribute, text... nodes
	* and the estimated data file size. 
	*/
	void printSummary();

private: 
	/**
	* The operation associated with data parsing, it can be OP_PARSE_ONLY, OP_PARSE_STORE or OP_PARSE_APPEND	
	*/
	int operation;

	/**
	* A stack that keeps nodes on the path from the root to the node currently under consideration.
	*/
	NodeStack* nodeStack;

	/**
	* The volume id of the volumn in which  the data is to be stored. 
	*/
	lvid_t volumeID;

	/** 
	* THe information about the data file
	*/
	FileInfoType* fileinfo;

	/**
	* The name of the input XML document
	*/
	char* filename;

	/**
	* The append handler that deals with appending a record to the tail of the data file
	*/
	append_file_i* apd;

	/**
	* The pin handler that deals with pinning a record in the database
	*/
	pin_i pinHandler;

	/**
	* The next key that can be assigned to nodes
	*/
	double nextKey;

	/**
	* The start/end key of the root node of the document to be parsed
	*/
	KeyType rootStartKey;
	KeyType rootEndKey;

	/**
	* The following two varialbes are for wrapping a data node into string
	*/
	int nodeInStrLen;
	char* nodeInStr;

	/** 
	* The following variables are for statistical use
	*/
	int depth; 		
	int maxDepth;		
	int nodeCount;
	int numEle;
	int numAttr;
	int numText;
	int numDoc;
	float dataSize;

	/**
	* This is a hack to avoid the splitting of text nodes.
	*/ 
	char *textCollector;
    bool isSpecialCharacter;

	/**
	* Process Method
	* 
	* Store a node to the database.
	*
	* This involves wrapping the node into a string, storing the record into the data file and addding 
	* correspond index item to the key index. 
	* 
	* @param node The node to be stored into the database
	* @param rid The record id of the record that contains the node (return value)
	* @param Error code
	*/	
	int storeNodeToDB(DM_DataNode* node, lrid_t* rid);

	/**
	* Process Methog
	* 
	* Modify a node in the database with new information in the data node.
	* There is no need to change the index item since the key and the rid are not changed. 
	*
	* @param srid The record id of the record to be changed.
	* @param node The node that contains new information. 
	* @param Error code
	*/
	int modifyNodeInDB(serial_t srid, DM_DataNode* node);

	/*int deleteAndStoreToDB(DM_DataNode* node, serial_t* nrid);*/
	/**
	*
	*/
	DM_DataNode* getNodeFromDB(KeyType nodekey, serial_t* nrid);

	/**
	* Supporting Method
	* Change a string from wchar* to char*
	*/
	char* wcharToChar(wchar_t* pwchVal, int cchVal);
    char* wcharToCharPreserveSpace(wchar_t* pwchVal, int cchVal);

	/**
	* Process Method
	* Parse the name of the input XML document, split name and path
	*/
	void parse_name(char* str, char* path, char* filename);

	/**
	* Debug Method
	* Keep track of the node count, and timing. 
	* 
	* TRICK: commit and restart transaction for every 10000 nodes. 
	*/
	void increaseNodeCount(KeyType key, int nodeSize);

	/**
	* Process Method
	* Delete a node according to its type
	*/
	void deleteNode(DM_DataNode* node);

	/**
	* The following varialbes are for debugging
	*/
	KeyType nodelist[10000];
	bool valid[10000];
	int stackitemcount;
	int pinCount;
	int unpinCount;
	int storeCount;
	int modifyCount;

	// ---- Processing Variables, and Functions for Multicolored-XML----
	/**
	* A mapping table that keep information for converting id/idref to multicolor model 
	*/
	IdrefTable* idrefTable;

	//A stack said start of multicolor subtree to mark it as a replication points

	std::stack<cstack> colorstack;

	//Flag whether we are converting multicolor
	bool multicolor;
	//Flag counting the depth for cutting
	int cutting_depth;

	/*
	* Internal Method for Multicolor
	*
	* Convert id/idref to proper multicolored trees
	* @returns Whether it has any errors
	*/
	int multicolorConversion();


	/*
	* Access Method
	* 
	* Given a node, returning its last child endkey if any
	* @param node Data node that would like to find its last child's endkey
	* @returns Key of the last child
	*/
	KeyType getLastChildEndKey(DM_DataNode* node);

	/*
	* Internal Method for Multicolor
	*
	* Copy a subtree from one colored tree to another by traversing in preorder 
	* using a NodeStack to keep track of current node, its parent, its child
	* @param rootnode The root node of the subtree that we would like to copy to another tree
	* @param root_nrid Rootnode's record id
	* @returns Whether it has any errors
	*/
	int preorderTraversalAndCopy(DM_DataNode* rootnode, serial_t* root_nrid);

	//void pushAncToNodeStack(DM_DataNode* node, serial_t* nrid);

	/*
	* For Multicolor
	* A mapping table specialized for dualcolor address
	*/
	SpecialTableMapType* sTableMap;

	/*
	* Internal Method for Multicolor
	*
	* Convert id/idref to proper multicolored trees.
	* A method same as multicolorConversion() but with specialized dualcolor address
	* This is an ugly for SIGMOD2004 submisssion
	* @returns Whether it has any errors
	*/
	int multicolorConversionSpecial();

    /**
    * For name encoding scheme
    */
    XMLNameTable *nameTable;
}; 

#endif 
