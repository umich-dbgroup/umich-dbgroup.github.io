/*
COPYRIGHT  (c) 2000-2004 
THE REGENTS OF THE UNIVERSITY OF MICHIGAN
ALL RIGHTS RESERVED

PERMISSION IS GRANTED TO USE, COPY, CREATE DERIVATIVE WORKS AND
REDISTRIBUTE THIS SOFTWARE AND SUCH DERIVATIVE WORKS FOR NONCOMMERCIAL
EDUCATION AND RESEARCH PURPOSES, SO LONG AS NO FEE IS CHARGED, AND SO LONG
AS THE COPYRIGHT NOTICE ABOVE, THIS GRANT OF PERMISSION, AND THE
DISCLAIMER BELOW APPEAR IN ALL COPIES MADE; AND SO LONG AS THE NAME OF THE
UNIVERSITY OF MICHIGAN IS NOT USED IN ANY ADVERTISING OR PUBLICITY
PERTAINING TO THE USE OR DISTRIBUTION OF THIS SOFTWARE WITHOUT SPECIFIC,
WRITTEN PRIOR AUTHORIZATION.

THIS SOFTWARE IS PROVIDED AS IS, WITHOUT REPRESENTATION FROM THE
UNIVERSITY OF MICHIGAN AS TO ITS FITNESS FOR ANY PURPOSE, AND WITHOUT
WARRANTY BY THE UNIVERSITY OF MICHIGAN OF ANY KIND, EITHER EXPRESS OR
IMPLIED, INCLUDING WITHOUT LIMITATION THE IMPLIED WARRANTIES OF
MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE. THE REGENTS OF THE
UNIVERSITY OF MICHIGAN SHALL NOT BE LIABLE FOR ANY DAMAGES, INCLUDING
SPECIAL, INDIRECT, INCIDENTAL, OR CONSEQUENTIAL DAMAGES, WITH RESPECT TO
ANY CLAIM ARISING OUT OF OR IN CONNECTION WITH THE USE OF THE SOFTWARE,
EVEN IF IT HAS BEEN OR IS HEREAFTER ADVISED OF THE POSSIBILITY OF SUCH
DAMAGES.
*/

// disable VC warning: vc7\include\xtree(1112) : warning C4702: unreachable code
#pragma warning(disable:4702)
#include "IdrefTable.h"
#pragma warning(default:4702)

/**
* class IdrefTable
* 
* This class provide a mapping table for converting id/idref attributes 
* to multicolor model
*
* The key is "id" attribute value
* In case of id, we keep the node id key
* In case of idref, other than keeping node id key, we also have
* the direction that Multicolor node will be duplicated to
* and an optional flag
* 
* @see MSXMLParser
* @see MSXMLParserHandlers
*
* @author Nuwee Wiwatwattana
* @version 1.0
*/

/**
* Constructor
*
* Create a map table
*/
IdrefTable::IdrefTable()
{
	IdrefTableMap = new IdrefTableMapType;
}

/**
* Destructor
*
* Clear a map table by iterating through each record
* and delete data value
*/
IdrefTable::~IdrefTable()
{
	std::map<const char*, IdrefItem*, ltstr>::const_iterator k;
	for (k = IdrefTableMap->begin(); k != IdrefTableMap->end(); ++k) 
    {
		delete k->second;
		delete k->first;
	}
	IdrefTableMap->clear();
	delete IdrefTableMap;
}

/**
* Exist
* Check for the existence of id value in the map table
*
* @param idvalue The string value of attribute id.
* @returns Boolean value.
*/
bool IdrefTable::exist(const char* idvalue)
{
	if (IdrefTableMap->find(idvalue) == IdrefTableMap->end()) return false; // not exist
	else return true;
}

/**
* Add method
* Add to the map table when id is found first/ before idref found
*
* @param idvalue The string value of attribute id.
* @param idElementKey The node id key of the element with id attribute
* @returns Error code.
*/
int IdrefTable::add(const char* idvalue, KeyType idElementKey)
{
	char* idval = new char[strlen(idvalue)+1];

	strcpy(idval,idvalue);
	IdrefItem* item = new IdrefItem;
	item->idElementKey = idElementKey;
	item->idrefNum = 0; // no idref yet

	IdrefTableMap->insert(std::make_pair(idval, item));
	return 0;
}

/**
* Add method
* Add to the map table when idref found /before any other id/idref found
*
* @param idvalue The string value of attribute id.
* @param idrefElementKey The node id key of the element with idref attribute.
* @param copydirection Single character (0 or 1) denotes the direction of the Multicolor duplication.
* @param flag Optional flag for this idref value.
* @returns Error code.
*/
int IdrefTable::add(const char* idvalue, KeyType idrefElementKey, char copydirection, int flag)
{
	char* idval = new char[strlen(idvalue)+1];

	strcpy(idval,idvalue);
	IdrefItem* item = new IdrefItem;
	item->idElementKey = -1;
	item->idrefElement[0].idrefKey = idrefElementKey;
	if (copydirection == '0') 
    {
		item->idrefElement[0].copydirection = 0;
		item->idrefElement[0].flag = flag;
	}
	else 
    {
		item->idrefElement[0].copydirection = 1;
		item->idrefElement[0].flag = flag;
	}
	item->idrefNum = 1;

	IdrefTableMap->insert(std::make_pair(idval, item));
	return 0;
}

/**
* Modify method
* Modify the map table when id is found after idref found
*
* @param idvalue The string value of attribute id.
* @param idElementKey The node id key of the element with id attribute.
* @returns Error code.
*/
int IdrefTable::modify(const char* idvalue, KeyType idElementKey)
{
    std::map<const char*, IdrefItem*, ltstr>::iterator k;
	k = IdrefTableMap->find(idvalue);
	IdrefItem* itemPtr = k->second;
	itemPtr->idElementKey = idElementKey;
	return 0;
}

/**
* Modify method
* Modify the map table when idref found after other id/idref found
*
* @param idvalue The string value of attribute id.
* @param idrefElementKey The node id key of the element with idref attribute.
* @param copydirection Single character (0 or 1) denotes the direction of the Multicolor duplication.
* @param flag Optional flag for this idref value.
* @returns Error code.
*/
int IdrefTable::modify(const char* idvalue, KeyType idrefElementKey, char copydirection, int flag)
{
    std::map<const char*, IdrefItem*, ltstr>::iterator k;
	k = IdrefTableMap->find(idvalue);
	IdrefItem* itemPtr = k->second;

	itemPtr->idrefElement[itemPtr->idrefNum].idrefKey = idrefElementKey;
	if (copydirection == '0') 
    {
		itemPtr->idrefElement[itemPtr->idrefNum].copydirection = 0;
		itemPtr->idrefElement[itemPtr->idrefNum].flag = flag;
	}
	else 
    {
		itemPtr->idrefElement[itemPtr->idrefNum].copydirection = 1;
		itemPtr->idrefElement[itemPtr->idrefNum].flag = flag;
	}
	itemPtr->idrefNum++;
	return 0;
}

/**
* Iterator method
* Start the scan table map iterator
*/
void IdrefTable::startScan()
{
	eOF = false;
	start = true;
}

/**
* Iterator method
* Get next item in the map table
*
* @returns Item type
*/
IdrefItem* IdrefTable::next()
{
    IdrefItem* current;
	if (start) 
    {
		iter = IdrefTableMap->begin();
		deliter = IdrefTableMap->begin();
		if (iter == IdrefTableMap->end()) 
        {
			eOF = true;
			return NULL;
		}
	}

	if (!start) 
    {
		delete deliter->first;
		deliter = IdrefTableMap->erase(deliter);
	}
	if (start) start = false;

	current = iter->second;
	currentItem = iter->second;
	currentID = (char*)iter->first;
	++iter;
	if (iter == IdrefTableMap->end()) 
    {
		eOF = true;
	}
	return current;
}

/**
* Iterator method
* Current key value
*
* @returns String vaue of the current id attribute
*/
const char* IdrefTable::currentValue()
{
	return currentID;
}

/**
* Iterator method
* Whether it is the end of table
*
* @returns Boolean value
*/
bool IdrefTable::eof()
{
	if (eOF) return true;
	else return false;
}

/**
* Debug method
*/
void IdrefTable::printTable()
{
    std::map<const char*, IdrefItem*, ltstr>::const_iterator k;
	for (k = IdrefTableMap->begin(); k != IdrefTableMap->end(); ++k) 
    {
		IdrefItem* itemPtr = k->second;
		const char* idPtr = k->first;
		cout << "idvalue: " << idPtr << " id key: " << itemPtr->idElementKey.key << endl;
		for (int i = 0 ; i < itemPtr->idrefNum ; i++) 
        {
			cout << " - idref key: " << itemPtr->idrefElement[i].idrefKey.key << " copyto: " << itemPtr->idrefElement[i].copydirection << endl;
		}
	}
}
