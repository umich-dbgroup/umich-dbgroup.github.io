/*
COPYRIGHT  (c) 2000-2004 
THE REGENTS OF THE UNIVERSITY OF MICHIGAN
ALL RIGHTS RESERVED

PERMISSION IS GRANTED TO USE, COPY, CREATE DERIVATIVE WORKS AND
REDISTRIBUTE THIS SOFTWARE AND SUCH DERIVATIVE WORKS FOR NONCOMMERCIAL
EDUCATION AND RESEARCH PURPOSES, SO LONG AS NO FEE IS CHARGED, AND SO LONG
AS THE COPYRIGHT NOTICE ABOVE, THIS GRANT OF PERMISSION, AND THE
DISCLAIMER BELOW APPEAR IN ALL COPIES MADE; AND SO LONG AS THE NAME OF THE
UNIVERSITY OF MICHIGAN IS NOT USED IN ANY ADVERTISING OR PUBLICITY
PERTAINING TO THE USE OR DISTRIBUTION OF THIS SOFTWARE WITHOUT SPECIFIC,
WRITTEN PRIOR AUTHORIZATION.

THIS SOFTWARE IS PROVIDED AS IS, WITHOUT REPRESENTATION FROM THE
UNIVERSITY OF MICHIGAN AS TO ITS FITNESS FOR ANY PURPOSE, AND WITHOUT
WARRANTY BY THE UNIVERSITY OF MICHIGAN OF ANY KIND, EITHER EXPRESS OR
IMPLIED, INCLUDING WITHOUT LIMITATION THE IMPLIED WARRANTIES OF
MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE. THE REGENTS OF THE
UNIVERSITY OF MICHIGAN SHALL NOT BE LIABLE FOR ANY DAMAGES, INCLUDING
SPECIAL, INDIRECT, INCIDENTAL, OR CONSEQUENTIAL DAMAGES, WITH RESPECT TO
ANY CLAIM ARISING OUT OF OR IN CONNECTION WITH THE USE OF THE SOFTWARE,
EVEN IF IT HAS BEEN OR IS HEREAFTER ADVISED OF THE POSSIBILITY OF SUCH
DAMAGES.
*/

/**
 * @author Yuqing (Melanie) Wu
 */

#ifndef __DoubleKey_H
#define __DoubleKey_H

#include "../DataParser/stdafx.h"

/**
* class IntPairKey
* 
* The key type in which the key of a node (the smallest storage unit in Timber), is represented by 
* a double value.
*/
class DoubleKey
{
public:
	DoubleKey(void) {this->key = 0;}
	DoubleKey(double key) {this->key = key;}
	~DoubleKey(void) {}

	bool isValid() {return this->key >= 0;}

	// operators
	void operator =(const DoubleKey key1) {this->key = key1.key;}
	void operator =(const int key) {this->key = key;}
	void operator =(const double key) {this->key = key;}
	void operator =(const float key) {this->key = key;}

	bool operator ==(const int intval) {return this->key == intval;}
	bool operator !=(const int intval) {return this->key != intval;}
	bool operator >(const int intval) {return this->key > intval;}
	bool operator >=(const int intval) {return this->key >= intval;}
	bool operator <(const int intval) {return this->key < intval;}
	bool operator <=(const int intval) {return this->key <= intval;}

	bool operator ==(const float fval) {return this->key == fval;}
	bool operator !=(const float fval) {return this->key != fval;}
	bool operator >(const float fval) {return this->key > fval;}
	bool operator >=(const float fval) {return this->key >= fval;}
	bool operator <(const float fval) {return this->key < fval;}
	bool operator <=(const float fval) {return this->key <= fval;}

	bool operator ==(const double dval) {return this->key == dval;}
	bool operator !=(const double dval) {return this->key != dval;}
	bool operator >(const double dval) {return this->key > dval;}
	bool operator >=(const double dval) {return this->key >= dval;}
	bool operator <(const double dval) {return this->key < dval;}
	bool operator <=(const double dval) {return this->key <= dval;}

	bool operator ==(const DoubleKey key1) {return this->key == key1.key;}
	bool operator !=(const DoubleKey key1) {return this->key != key1.key;}
	bool operator >(const DoubleKey key1) {return this->key > key1.key;}
	bool operator >=(const DoubleKey key1) {return this->key >= key1.key;}
	bool operator <(const DoubleKey key1) {return this->key < key1.key;}
	bool operator <=(const DoubleKey key1) {return this->key <= key1.key;}

	DoubleKey operator +(int intval) {return DoubleKey(this->key + intval);}
	DoubleKey operator -(int intval) {return DoubleKey(this->key - intval);}
	DoubleKey operator *(int intval) {return DoubleKey(this->key * intval);}
	DoubleKey operator /(int intval) {return DoubleKey(this->key / intval);}

	DoubleKey operator +(float fval) {return DoubleKey(this->key + fval);}
	DoubleKey operator -(float fval) {return DoubleKey(this->key - fval);}
	DoubleKey operator *(float fval) {return DoubleKey(this->key * fval);}
	DoubleKey operator /(float fval) {return DoubleKey(this->key / fval);}

	DoubleKey operator +(double dval) {return DoubleKey(this->key + dval);}
	DoubleKey operator -(double dval) {return DoubleKey(this->key - dval);}
	DoubleKey operator *(double dval) {return DoubleKey(this->key * dval);}
	DoubleKey operator /(double dval) {return DoubleKey(this->key / dval);}

	DoubleKey operator +(DoubleKey key1) {return DoubleKey(this->key + key1.key);}
	DoubleKey operator -(DoubleKey key1) {return DoubleKey(this->key - key1.key);}
	//DoubleKey operator *(DoubleKey key1) {return DoubleKey(this->key * key1.key);}
	double operator /(DoubleKey key1) {return (this->key / key1.key);}

	//ostream& operator << (ostream& os);

	static DoubleKey mid(DoubleKey key1, DoubleKey key2) {return DoubleKey(key1/2 + key2/2);}

	int toInt() {return (int) this->key;}
	double toDouble() {return this->key; }
	char* toString();

	// variables
	double key;
};

// The following key comparason will be used when the key types is used in mapping. 

struct ltDoubleKey
{
    bool operator()(const DoubleKey key1, const DoubleKey key2) const
    {
        return (key1.key < key2.key) ;
    }
};

#endif
