/*
COPYRIGHT  (c) 2000-2004 
THE REGENTS OF THE UNIVERSITY OF MICHIGAN
ALL RIGHTS RESERVED

PERMISSION IS GRANTED TO USE, COPY, CREATE DERIVATIVE WORKS AND
REDISTRIBUTE THIS SOFTWARE AND SUCH DERIVATIVE WORKS FOR NONCOMMERCIAL
EDUCATION AND RESEARCH PURPOSES, SO LONG AS NO FEE IS CHARGED, AND SO LONG
AS THE COPYRIGHT NOTICE ABOVE, THIS GRANT OF PERMISSION, AND THE
DISCLAIMER BELOW APPEAR IN ALL COPIES MADE; AND SO LONG AS THE NAME OF THE
UNIVERSITY OF MICHIGAN IS NOT USED IN ANY ADVERTISING OR PUBLICITY
PERTAINING TO THE USE OR DISTRIBUTION OF THIS SOFTWARE WITHOUT SPECIFIC,
WRITTEN PRIOR AUTHORIZATION.

THIS SOFTWARE IS PROVIDED AS IS, WITHOUT REPRESENTATION FROM THE
UNIVERSITY OF MICHIGAN AS TO ITS FITNESS FOR ANY PURPOSE, AND WITHOUT
WARRANTY BY THE UNIVERSITY OF MICHIGAN OF ANY KIND, EITHER EXPRESS OR
IMPLIED, INCLUDING WITHOUT LIMITATION THE IMPLIED WARRANTIES OF
MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE. THE REGENTS OF THE
UNIVERSITY OF MICHIGAN SHALL NOT BE LIABLE FOR ANY DAMAGES, INCLUDING
SPECIAL, INDIRECT, INCIDENTAL, OR CONSEQUENTIAL DAMAGES, WITH RESPECT TO
ANY CLAIM ARISING OUT OF OR IN CONNECTION WITH THE USE OF THE SOFTWARE,
EVEN IF IT HAS BEEN OR IS HEREAFTER ADVISED OF THE POSSIBILITY OF SUCH
DAMAGES.
*/

/**
 * @author Yuqing (Melanie) Wu
 */

#include "DM_CharNode.h"

/**
* Class DM_CommentNode
* 
* This class represent a piece of comment in the XML document.
* 
* @see DM_CharNode
* @see DM_DataNode
*/

/**
* Constructor
*
* Initialize the variable with the information given.
*
* @param key The start key of the node
* @param level The depth of the node
* @param comment The string value of the content of the node
*/

DM_CommentNode::DM_CommentNode(KeyType key, 
							   short level,
							   const char* comment) 
							   : DM_CharNode(key, level, comment)
{
	setFlag(COMMENT_NODE);
}

/**
* Constructor
* 
* Construct a CommentNode using the information wrapped in a string
*
* @param buffer The string which contains the wrapped information about the comment node. 
*/

DM_CommentNode::DM_CommentNode(char* buffer) : DM_CharNode(buffer)
{
	setFlag(COMMENT_NODE);
}

/**
* Default Destructor
*/
DM_CommentNode::~DM_CommentNode()
{
}

/**
* Debug Method
* Print the string value of the node
*/
void DM_CommentNode::printValue()
{
	cout << "Comment Node: Key = " << this->key.toString() << endl;
	cout << "<!-- " << this->charValue << "-->\n" << endl ;
}
