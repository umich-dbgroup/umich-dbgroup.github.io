/*
COPYRIGHT  (c) 2000-2004 
THE REGENTS OF THE UNIVERSITY OF MICHIGAN
ALL RIGHTS RESERVED

PERMISSION IS GRANTED TO USE, COPY, CREATE DERIVATIVE WORKS AND
REDISTRIBUTE THIS SOFTWARE AND SUCH DERIVATIVE WORKS FOR NONCOMMERCIAL
EDUCATION AND RESEARCH PURPOSES, SO LONG AS NO FEE IS CHARGED, AND SO LONG
AS THE COPYRIGHT NOTICE ABOVE, THIS GRANT OF PERMISSION, AND THE
DISCLAIMER BELOW APPEAR IN ALL COPIES MADE; AND SO LONG AS THE NAME OF THE
UNIVERSITY OF MICHIGAN IS NOT USED IN ANY ADVERTISING OR PUBLICITY
PERTAINING TO THE USE OR DISTRIBUTION OF THIS SOFTWARE WITHOUT SPECIFIC,
WRITTEN PRIOR AUTHORIZATION.

THIS SOFTWARE IS PROVIDED AS IS, WITHOUT REPRESENTATION FROM THE
UNIVERSITY OF MICHIGAN AS TO ITS FITNESS FOR ANY PURPOSE, AND WITHOUT
WARRANTY BY THE UNIVERSITY OF MICHIGAN OF ANY KIND, EITHER EXPRESS OR
IMPLIED, INCLUDING WITHOUT LIMITATION THE IMPLIED WARRANTIES OF
MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE. THE REGENTS OF THE
UNIVERSITY OF MICHIGAN SHALL NOT BE LIABLE FOR ANY DAMAGES, INCLUDING
SPECIAL, INDIRECT, INCIDENTAL, OR CONSEQUENTIAL DAMAGES, WITH RESPECT TO
ANY CLAIM ARISING OUT OF OR IN CONNECTION WITH THE USE OF THE SOFTWARE,
EVEN IF IT HAS BEEN OR IS HEREAFTER ADVISED OF THE POSSIBILITY OF SUCH
DAMAGES.
*/

/**
 * @author Yuqing (Melanie) Wu
 */

#include "TreeStructure_definitions.h"
#include "../DataParser/StdAfx.h"
#include <float.h>

#ifndef __Value_H
#define __Value_H

#define INT_VALUE		1
#define STRING_VALUE	2
#define DATE_VALUE		3
#define REAL_VALUE		4

// operator in value comparison
#define VALUE_COMP_OP_LT				1
#define VALUE_COMP_OP_LE				2
#define VALUE_COMP_OP_GT				3
#define VALUE_COMP_OP_GE				4
#define VALUE_COMP_OP_EQ				5
#define VALUE_COMP_OP_NE				6
#define VALUE_COMP_OP_CONTAINS			7
#define VALUE_COMP_OP_CONTAINEDBY		8
#define VALUE_COMP_OP_STARTWITH			9

//@{
// This class represent the value type the content of a node may have
// @author Yuqing Melanie Wu
// @version 1.0
//@}
class Value
{
friend class PredicateCondition;

public:
	//@{
	// Default Constructor
	//@}
	//added by shurug... strValue needs initialization to null
	Value() { this->strValue = NULL;};

	//@{
	// Constructor
	//
	// initialize the instance with the type of value given
	// @param type The type of the value, can be one of the following:
	// INT_VALUE, STRING_VALUE, DATE_VALUE, REAL_VALUE,
	//@}
	Value(int type);
		
	//@{
	// Constructor
	//
	// initialize the instance with the type of value given, 
	// and transform the value in the input string to the desired type.
	// @param type The type of the value, can be one of the following:
	// INT_VALUE, STRING_VALUE, DATE_VALUE, REAL_VALUE,
	// @param str The value in string format.
	//@}
	Value(int valuetype, const char* str);

	//@{
	// Unwrap Constructor
	//
	// Create a new instannce with the information wraped in a string
	// @param str A string of the result of wrapping an instance of Value
	//@}
	Value(char* str);

	//@{
	// Copy Constructor
	//
	// Create a new Value instance, copying the content of the instance given
	// @param An instance of Value to be copied from.
	//@}
	Value(Value* val);

	//@{
	// Destructor
	//
	// free the space allocated for string value
	//@}
	virtual ~Value();

	//@{
	// Set Method
	//
	// Set the value type
	// @param type The value type
	//@}
	void setValueType(int type);

	//@{
	// Set Method
	//
	// Set integer value
	// @param intval The integer value
	//@}
	void setIntValue(int intval);

	//@{
	// Set Method
	//
	// Set string value
	// @param strval The string value
	//@}
	void setStrValue(const char* strval);
	
	//@{
	// Set Method
	//
	// Set date value (not implemented yet)
	//@}
	void setDateValue();
	
	//@{
	// Set Method
	//
	// Set real value
	// @param realval The real value
	//@}
	void setRealValue(double realval);
	//void CopyValue(Value val);

	//@{
	// Access Method
	//
	// Get the value Type
	// @returns The value type
	//@}
	int getValueType();
	
	//@{
	// Access Method
	//
	// Get integer value
	// @returns The integer value
	//@}
	int getIntValue();

	//@{
	// Access Method
	//
	// Get string value
	// @returns The string value
	//@}
	char* getStrValue();
	
	//@{
	// Access Method
	//
	// Get date value (not implemented yet)
	//@}
	void getDateValue();

	//@{
	// Access Method
	//
	// Get real value
	// @returns The real value
	//@}
	double getRealValue();

	//@{
	// Process Method
	//
	// Change the value to a string
	// @returns A string which contains the value and can be printed
	//@}
	char* valueToString();

	//@{
	// Process Method
	//
	// Wrap the content of the Value into a string
	// @parem length The length of the output string (output)
	// @returns The string of the wrapping result
	//@}
	char* wrap(int* length);

	//@{
	// Process Method
	//
	// Unwrap the information from a string, and restore the instance of Value
	// @param str A string which is the result of wrapping and contains all information of an instance of Value
	//@}
	void unWrap(char* buffer);

	int getValueSize();

	//@{
	// Process Method
	//
	// Compare the two value, based on their type and the operator
	// @param op The comparason operator
	// @param other The other value to be compared with this value
	// @returns the boolean result of the comparason
	//@}
	bool compareValue(int op, Value* other);

	//@{
	// Set Method
	//
	// Set the Integer value from a string
	// This is a temperary method used as patch to the current implementation
	//@}
	void setValue(char* str);

	//@{
	// Debug Method
	// Print the contents of the Value
	//@}
	void printValue();

private:
	//@{
	// The type of the value, can be one of the following:
	// INT_VALUE, STRING_VALUE, DATE_VALUE, REAL_VALUE,
	//@}
	int valueType;

	//@{
	// The integer value
	//@}
	int intValue;

	//@{
	// The string value
	//@}
	char* strValue;

//	CTime Date_time;
	
	//@{
	// The real value
	//@}
	double realValue;

	//@{
	// Process Method
	//
	// Compare the value of two instance of value
	// @param other An instance of Value which is to be compared with this one
	// @returns True if this value > value in "other"
	//@}
	bool greaterThan(Value* other);

	//@{
	// Process Method
	//
	// Compare the value of two instance of value
	// @param other An instance of Value which is to be compared with this one
	// @returns True if this value >= value in "other"
	//@}
	bool greaterEqual(Value* other);

	//@{
	// Process Method
	//
	// Compare the value of two instance of value
	// @param other An instance of Value which is to be compared with this one
	// @returns True if this value < value in "other"
	//@}
	bool lessThan(Value* other);

	//@{
	// Process Method
	//
	// Compare the value of two instance of value
	// @param other An instance of Value which is to be compared with this one
	// @returns True if this value <= value in "other"
	//@}
	bool lessEqual(Value* other);

	//@{
	// Process Method
	//
	// Compare the value of two instance of value
	// @param other An instance of Value which is to be compared with this one
	// @returns True if this value = value in "other"
	//@}
	bool equal(Value* other);

	//@{
	// Process Method
	//
	// Compare the value of two instance of value
	// @param other An instance of Value which is to be compared with this one
	// @returns True if this value != value in "other"
	//@}
	bool notEqual(Value* other);

	//@{
	// Process Method
	//
	// Compare the value of two instance of value
	// @param other An instance of Value which is to be compared with this one
	// @returns True if the string value start with the string value in "other". (used only for string value)
	//@}
	bool startWith(Value* other);

	//@{
	// Process Method
	//
	// Compare the value of two instance of value
	// @param other An instance of Value which is to be compared with this one
	// @returns True if the string value contains the string value in "other". (used only for string value)
	//@}
	bool contains(Value* other);

	//@{
	// Process Method
	//
	// Compare the value of two instance of value
	// @param other An instance of Value which is to be compared with this one
	// @returns True if the string value is contained in the string value in "other". (used only for string value)
	//@}
	bool containedBy(Value* other);
	
	//@{
	// Process Method
	//
	// Compare the value of two instance of value
	// @param other An instance of Value which is to be compared with this one
	// @returns True if this length of value > the length of value in "other". (used only for string value)
	//@}
	bool lenLT(Value* other);
	
	//@{
	// Process Method
	//
	// Compare the value of two instance of value
	// @param other An instance of Value which is to be compared with this one
	// @returns True if this length of value >= the length of value in "other". (used only for string value)
	//@}
	bool lenLE(Value* other);
	
	//@{
	// Process Method
	//
	// Compare the value of two instance of value
	// @param other An instance of Value which is to be compared with this one
	// @returns True if this length of value < the length of value in "other". (used only for string value)
	//@}
	bool lenST(Value* other);
	
	//@{
	// Process Method
	//
	// Compare the value of two instance of value
	// @param other An instance of Value which is to be compared with this one
	// @returns True if this length of value <= the length of value in "other". (used only for string value)
	//@}
	bool lenSE(Value* other);
	
	//@{
	// Process Method
	//
	// Compare the value of two instance of value
	// @param other An instance of Value which is to be compared with this one
	// @returns True if this length of value = the length of value in "other". (used only for string value)
	//@}
	bool lenEQ(Value* other);
	
	//@{
	// Process Method
	//
	// Compare the value of two instance of value
	// @param other An instance of Value which is to be compared with this one
	// @returns True if this length of value != the length of value in "other". (used only for string value)
	//@}
	bool lenNE(Value* other);

    void convertToInt();
    void convertToReal();
    void Value::convertBackToString();
};

#endif
