/*
COPYRIGHT  (c) 2000-2004 
THE REGENTS OF THE UNIVERSITY OF MICHIGAN
ALL RIGHTS RESERVED

PERMISSION IS GRANTED TO USE, COPY, CREATE DERIVATIVE WORKS AND
REDISTRIBUTE THIS SOFTWARE AND SUCH DERIVATIVE WORKS FOR NONCOMMERCIAL
EDUCATION AND RESEARCH PURPOSES, SO LONG AS NO FEE IS CHARGED, AND SO LONG
AS THE COPYRIGHT NOTICE ABOVE, THIS GRANT OF PERMISSION, AND THE
DISCLAIMER BELOW APPEAR IN ALL COPIES MADE; AND SO LONG AS THE NAME OF THE
UNIVERSITY OF MICHIGAN IS NOT USED IN ANY ADVERTISING OR PUBLICITY
PERTAINING TO THE USE OR DISTRIBUTION OF THIS SOFTWARE WITHOUT SPECIFIC,
WRITTEN PRIOR AUTHORIZATION.

THIS SOFTWARE IS PROVIDED AS IS, WITHOUT REPRESENTATION FROM THE
UNIVERSITY OF MICHIGAN AS TO ITS FITNESS FOR ANY PURPOSE, AND WITHOUT
WARRANTY BY THE UNIVERSITY OF MICHIGAN OF ANY KIND, EITHER EXPRESS OR
IMPLIED, INCLUDING WITHOUT LIMITATION THE IMPLIED WARRANTIES OF
MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE. THE REGENTS OF THE
UNIVERSITY OF MICHIGAN SHALL NOT BE LIABLE FOR ANY DAMAGES, INCLUDING
SPECIAL, INDIRECT, INCIDENTAL, OR CONSEQUENTIAL DAMAGES, WITH RESPECT TO
ANY CLAIM ARISING OUT OF OR IN CONNECTION WITH THE USE OF THE SOFTWARE,
EVEN IF IT HAS BEEN OR IS HEREAFTER ADVISED OF THE POSSIBILITY OF SUCH
DAMAGES.
*/

/**
 * @author Yuqing (Melanie) Wu
 */

#include "DM_DataNode.h"
#include "DM_DocumentNode.h"
#include "DM_AttributeNode.h"
#include "DM_CharNode.h"
#include "../../Utilities/ErrorInfoClass.h"
extern ErrorInfoClass globalErrorInfo;

/**
* class DM_DataNode
* This class represent the basic data structure (node). It is the base class for all 
* node types in Timber:
*
* @see DM_ElementNode
* @see DM_DocumentNode
* @see DM_CharNode
* @see DM_AttributeNode
* @see DM_TextNode
* @see DM_CommentNode
*/

/**
* Constructor
*
* Initialize the variables with the information provides
* Set the other variables with default value.
*
* @param key The start key of the node
* @parem nodeflag The Type of node
* @param nodetag The tag of the node
* @param level The depth of the node
*/

DM_DataNode::DM_DataNode(KeyType key, 
						 char nodeflag, 
						 int nodetag,
						 short level)
{
	// set the key and the node type
	this->key = key;
	this->nodeFlag = nodeflag;

	// for document node and element node, the end key should be different from the key
	// set it to -1 here, then, if the end key is not assigned, it is easy to be detected.
	if ((nodeflag == DOCUMENT_NODE) || (nodeflag == ELEMENT_NODE))
		this->endKey = -1;
	else this->endKey = key;
	//if (nodetag == NULL)
	//{
	//	// for nodee that does not have a tag, set it to be an empty string
	//	this->nodeTag[0] = '\0';
	//}
	//else 
	//{
	//	// there is an upper-bound on the length of the node tag in Timber
	//	// varify the length here, cut the tag short if it is too long. 
	//	if (strlen(nodetag) < MAX_NODETAG_LENGTH)
	//		strcpy(this->nodeTag, nodetag);
	//	else
	//	{
	//		memcpy(this->nodeTag, nodetag, MAX_NODETAG_LENGTH);
	//		this->nodeTag[MAX_NODETAG_LENGTH-1] = '\0';
	//	}
	//}
    this->nodeTag = nodetag;
	this->level = level;

	// set default value to the relative links. 
	this->parent = -1;
	this->prevSibling = -1;
	this->nextSibling = -1;

    // set default value for descendants
    //this->descNumber = -1;
    this->descendantDepth = -1;

	// set default value for history and its length. 
	this->historyLength = 0;
	this->history = NULL;
}

/**
* Copy Constructor
* Added: 07/14/03
* Construct a DataNode copied from another DataNode
*
* @param elenode The source element node to copy
*/
DM_DataNode::DM_DataNode(DM_DataNode* node)
{
	// set the key and the node type
	this->key = node->key;
	this->nodeFlag = node->nodeFlag;
	this->endKey = node->endKey;

	//strcpy(this->nodeTag, node->nodeTag);
    this->nodeTag = node->nodeTag;
	this->level = node->level;

	// set default value to the relative links. 
	this->parent = node->parent;
	this->prevSibling = node->prevSibling;
	this->nextSibling = node->nextSibling;

    // set default value for descendants
    //this->descNumber = node->descNumber;
    this->descendantDepth = node->descendantDepth;

	// set default value for history and its length. 
	this->historyLength = 0;
	this->history = NULL;
}

/**
* Default Destructor
* Release the space occupied.
*/
DM_DataNode::~DM_DataNode()
{
	if (this->historyLength != NULL)
		delete [] this->history;
}

/*----------------------------------------------------------*
*		Access Methods										*
*-----------------------------------------------------------*/

/**
* Access Method
* Get the key (start position) of the node.
* 
* @returns The key of the node
*/
KeyType DM_DataNode::getKey()
{
	return this->key;
}

/**
* Access Method
* Get the node type
* @returns The type of the node
*/
char DM_DataNode::getFlag()
{
	return this->nodeFlag; 
}

/**
* Access Method
* Get the node tag.
* @returns The node tag of the node
*/
char* DM_DataNode::getTag(XMLNameTable *nameTable)
{
    // caller will have to free the memory!!
    return nameTable->getNameByCode(this->nodeTag);
}
int DM_DataNode::getTag()
{
    return this->nodeTag;
}

/**
* Access Method
* Get parent link 
* @returns The key of the parent of this node. -1 if this node does not have a parent.
*/
KeyType DM_DataNode::getParent()                      
{
	return this->parent;
}

/**
* Access Method
* Get sibling link
* @returns The key of the previous sibling of this node. -1 if this node is the first child of its parent.
*/
KeyType DM_DataNode::getPrevSibling()                      
{
	return this->prevSibling;
}

/**
* Access Method
* Get sibling link
* @returns The key of the next sibling of this node. -1 if this node is the last child of its parent.
*/
KeyType DM_DataNode::getNextSibling()                      
{
	return this->nextSibling;
}

/**
* Access Method
* Get the endkey (end position) of the node
* @returns The endkey (end position) of the node
*/
KeyType DM_DataNode::getEndKey()
{
	return this->endKey;
}

/**
* Access Method
* Get the depth of the node
* @returns The depth of the node
*/
short DM_DataNode::getLevel()
{
	return this->level;
}

/**
* Access Method
* Get the number of descendants of the node
* @returns The number of descendants of the node
*/
//int DM_DataNode::getDescNumber()
//{
//	return this->descNumber;
//}

/**
* Access Method
* Get the key of the attribute node which contains all the attribute of this element node
* @returns The key of the attribute node which contains all the attributes in this element node
*/
//KeyType DM_DataNode::getAttributes()
//{
//	switch (this->nodeFlag)
//	{
//		case ELEMENT_NODE:
//			return ((DM_ElementNode*) this)->getAttributes();
//			break;
//		default: return -1;
//	}
//}

/**
* Access Method
* Get the key of the first child of this node.
* Valid only when the node is ELEMENT_NODE or DOCUMENT_NODE:
* @returns The key of the first child fo this ndoe
*/
KeyType DM_DataNode::getFirstChild()
{
	switch (this->nodeFlag)
	{
		case ELEMENT_NODE:
		case DOCUMENT_NODE:
			return ((DM_ElementNode*) this)->getFirstChild();
			break;
		default: return -1;
	}
}

/**
* Access Method
* Get the key of the last child of this node
* Valid only when the node is ELEMENT_NODE or DOCUMENT_NODE:
* @returns THe key of the last child fo this ndoe
*/
KeyType DM_DataNode::getLastChild()
{
	switch (this->nodeFlag)
	{
		case ELEMENT_NODE:
		case DOCUMENT_NODE:
			return ((DM_ElementNode*) this)->getLastChild();
			break;
		default: return -1;
	}
}

/**
* Access Method
* Get the number of children of this  node
* Valid only when the node is ELEMENT_NODE or DOCUMENT_NODE:
* @returns The number of children of this node.
*/
int DM_DataNode::getChildNumber()
{
	switch (this->nodeFlag)
	{
		case ELEMENT_NODE:
		case DOCUMENT_NODE:
			return ((DM_ElementNode*) this)->getChildNumber();
			break;
		default: return -1;
	}
}

/**
* Access Method
* Get the number of attributes in this  ode
* Valid only when the node is ELEMENT_NODE or ATTRIBUTE_NODE
* @returns The number of attributes of this node. -1 if the node type is not valid for this access method. 
*/
short DM_DataNode::getAttributeNumber()
{
	switch (this->nodeFlag)
	{
		case ELEMENT_NODE:
			return ((DM_ElementNode*) this)->getAttributeNumber();

		case ATTRIBUTE_NODE:
			return ((DM_AttributeNode*) this)->getAttributeNumber();

		default:
            globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"DM_DataNode::getAttributeNumber",__FILE__,"Unknown node type");
            return -1;
	}
}

/**
* Access Method
* Get the depth of the node
* @returns The depth of the node
*/
short DM_DataNode::getDescendantDepth()
{
	return this->descendantDepth;
}

/* 
* Access Method
* Get the length of the history field
* @returns The length of the history field
*/
int DM_DataNode::getHistoryLength()
{
	return this->historyLength;
}

/* 
* Access Method
* Get the history field
* @returns The history field
*/
char* DM_DataNode::getHistory()
{
	return this->history;
}

/**
* Access Method
* Find out whether the history field has any content
* @returns A boolean value which indicates whether the history field is empty or not.
*/
bool DM_DataNode::hasHistory()
{
	if (this->historyLength == 0) return false;
	else return true;
}

/**
* Access Method
* Find out whether the node is a leaf node.
* @returns A boolean value which indicates whether the node is a leaf node or not.
*/
bool DM_DataNode::isLeafNode()
{
	bool retval = false;

	switch (this->nodeFlag)
	{
	case ATTRIBUTE_NODE:
	case TEXT_NODE:
	case COMMENT_NODE:
		// attribute node, text node and comment node are leaf-nodes for sure. 
		retval = true;
		break;

	case ELEMENT_NODE:
	case DOCUMENT_NODE:
		// element node and document node can be leaf node only when it has no children. 
		if (((DM_ElementNode*) this)->getChildNumber() == 0) retval = true;
		else retval = false;
	}

	return retval;

}

/*----------------------------------------------------------*
*		Access Methods										*
*-----------------------------------------------------------*/

/**
* Set Method
* Set the Node Type
* @param flag The new node type for the node
*/
void DM_DataNode::setFlag(char flag)
{
	this->nodeFlag = flag;
}

/**
* Set Method
* Set the node tag
* @param nodetag The new node tag for the node
*/
//void DM_DataNode::setTag(char* nodetag)
//{
//	// if the new node tag is too long (longer than the upper-bound), it will be cut to fit in. 
//	if (strlen(nodetag) < MAX_NODETAG_LENGTH)
//		strcpy(this->nodeTag, nodetag);
//	else
//	{
//		memcpy(this->nodeTag, nodetag, MAX_NODETAG_LENGTH);
//		this->nodeTag[MAX_NODETAG_LENGTH-1] = '\0';
//	}
//}
void DM_DataNode::setTag(int nodetag)
{
    this->nodeTag = nodetag;
}


/**
* Set Method
* Set the parent link
* @param parent The key of the parent node
*/
void DM_DataNode::setParent(KeyType parent)
{
	this->parent = parent;
}

/**
* Set Method
* Set the Sibling link
* @param presibling The key of the previous sibling of the node
*/
void DM_DataNode::setPrevSibling(KeyType prevsibling)
{
	this->prevSibling = prevsibling;
}

/**
* Set Method
* Set the Sibling link
* @param nextsibling The key of the next sibling of the node
*/
void DM_DataNode::setNextSibling(KeyType nextsibling)
{
	this->nextSibling = nextsibling;
}

/**
* Set Method
* Set the key value
* @param key The new key value for the node
*/
void DM_DataNode::setKey(KeyType key)
{
	this->key = key;
}

/**
* Set Method
* Set the endkey (end position) of the node
* @param endkey The new endkey (end position) of the node
*/
void DM_DataNode::setEndKey(KeyType endkey)
{
	this->endKey = endkey;
}

/**
* Set Method
* Set the level (depth) of the node
* @param endkey The new level of the node
*/
void DM_DataNode::setLevel(short level)
{
	this->level = level;
}

/**
* Set Method
* Set the number of descendant of the node
* @param descnum The new number of descendants of this node.
*/
//void DM_DataNode::setDescNumber(int descnum)
//{
//	this->descNumber = descnum;
//}

/**
* Set Method
* Set the descendant depth, which is the height of the subtree rooted at the node.
* @param depth The height of the subtree rooted at the node.
*/
void DM_DataNode::setDescendantDepth(short depth)
{
	this->descendantDepth = depth;
}

/**
* Set Method
* Set value to the history field of the node.
* @param length The length of the history value.
* @param history The history, which is a string (memory block) of the length given, which contains the history information about the node.
*/
void DM_DataNode::setHistory(int length, char* history)
{
	// if the history field is not empty, need to delete it first.
	if (this->historyLength != 0)
		delete [] this->history;

	// need to allocate space for the history information. 
	this->historyLength = length;
	this->history = new char[length];
	memcpy(this->history, history, length);
}

/**
* Process Method
* Wrap the content of the DM_DataNode into a string. These are the common fields of all nodes.
* 
* Data to be wraped up for every DM_DataNode include
* 1. key
* 2. endkey
* 3. node flag (type)
* 4. node tag length
* 5. node tag
* 6. level
* 7. parent key
* 8. previous sibling key
* 9. next sibling key
* 10. descendant number -- removed
* 11. descendant depth
* 12. history length
* 13. history (if history field has content)
*
* @param length The length of the string generated (return value).
* @returns A string that contains all the information of the node.
*/
char* DM_DataNode::wrapCommon(int* length)
{
	// the return string
	char* buffer;
	
	// compute the length of the string will take. 
	int datasize = sizeof(DM_DataNode) // the size of all field in the class
					//+ sizeof(int) + strlen(this->nodeTag) // for node tag
					- sizeof(char*) + this->historyLength;// this takes in the size of the history

	// allocate memory, based on the length computed.
	buffer = new char[datasize];
    // MEM INIT
	memset(buffer,0,datasize);
	int cursor = 0;

	// key
	memcpy(buffer+cursor, &(this->key), sizeof(KeyType));
	cursor += sizeof(KeyType);

	// endkey
	memcpy(buffer+cursor, &(this->endKey), sizeof(KeyType));
	cursor += sizeof(KeyType);

	// node flag (type)
	memcpy(buffer+cursor, &(this->nodeFlag), sizeof(char));
	cursor += sizeof(char);

	// node tag
	//cursor += this->wrapString(buffer+cursor, this->nodeTag, strlen(this->nodeTag));
    memcpy(buffer+cursor, &(this->nodeTag), sizeof(int));
    cursor += sizeof(int);

	// level
	memcpy(buffer+cursor, &(this->level), sizeof(short));
	cursor += sizeof(short);

	// parent key
	memcpy(buffer+cursor, &(this->parent), sizeof(KeyType));
	cursor += sizeof(KeyType);
	
	// previous sibling key
	memcpy(buffer+cursor, &(this->prevSibling), sizeof(KeyType));
	cursor += sizeof(KeyType);
	
	// next sibling key
	memcpy(buffer+cursor, &(this->nextSibling), sizeof(KeyType));
	cursor += sizeof(KeyType);

	// descendant number
	//memcpy(buffer+cursor, &(this->descNumber), sizeof(int));
	//cursor += sizeof(int);

	// descendant depth
	memcpy(buffer+cursor, &(this->descendantDepth), sizeof(short));
	cursor += sizeof(short);

	// history length
	memcpy(buffer+cursor, &(this->historyLength), sizeof(int));
	cursor += sizeof(int);

	// history
	if (this->hasHistory())
	{
		memcpy(buffer+cursor, this->history, this->historyLength);
		cursor += this->historyLength;
	}

	(*length) = cursor;
	return buffer;
}

/**
* Process Method
* unwrap the content of the DM_DataNode from a string. These fields are the common fields for nodes of all types.
*
* Data to be unwraped up for every DM_DataNode include:
* 1. key
* 2. endkey
* 3. node flag (type)
* 4. node tag length
* 5. node tag
* 6. level
* 7. parent key
* 8. previous sibling key
* 9. next sibling key
* 10. descendant number
* 11. descendant depth
* 12. history length
* 13. history (if history field has content)
*
* @param buffer A string that contains all the information of the node
*/
void DM_DataNode::unwrapCommon(char* buffer)
{
	int cursor;

	cursor = 0;

	// key
	memcpy(&this->key, buffer + cursor, sizeof(KeyType));
	cursor += sizeof(KeyType);

	// endkey
	memcpy(&this->endKey, buffer + cursor, sizeof(KeyType));
	cursor += sizeof(KeyType);

	// node flag (type)
	memcpy(&this->nodeFlag, buffer + cursor, sizeof(char));
	cursor += sizeof(char);

	// node tag
	//cursor += this->unwrapString(buffer+cursor, this->nodeTag);
    memcpy(&(this->nodeTag), buffer + cursor, sizeof(int));
    cursor += sizeof(int);

	// level
	memcpy(&(this->level), buffer+cursor, sizeof(short));
	cursor += sizeof(short);

	// parent key
	memcpy(&this->parent, buffer+cursor, sizeof(KeyType));
	cursor += sizeof(KeyType);

	// previous sibling key
	memcpy(&this->prevSibling, buffer+cursor, sizeof(KeyType));
	cursor += sizeof(KeyType);

	// next sibling key
	memcpy(&this->nextSibling, buffer+cursor, sizeof(KeyType));
	cursor += sizeof(KeyType);
	
	// descendant number
	//memcpy(&(this->descNumber), buffer+cursor, sizeof(int));
	//cursor += sizeof(int);

	// descendant depth
	memcpy(&(this->descendantDepth), buffer+cursor, sizeof(short));
	cursor += sizeof(short);

	// history 
	memcpy(&(this->historyLength), buffer+cursor, sizeof(int));
	cursor += sizeof(int);

	if (this->history != NULL) delete this->history;
	if (this->historyLength > 0)
	{
		this->history = new char[this->historyLength];
		memcpy(this->history, buffer+cursor, this->historyLength);
	}
	else this->history = NULL;
}

/**
* Process Method
* unwrap the content of the node from a string. 
*
* The node type is detected and the unwrap function of each such class is called
* to unwrap the string. 
* 
* @param buffer A string that contains all the information of the node
* @returns A pointer to the node unwrapped from the string
*/
DM_DataNode* DM_DataNode::unwrap(char* buffer)
{
	char nodeType;
	DM_DataNode* nodePnt;

	// get the node type, which is the first field in the incoming string. 
	memcpy(&nodeType, buffer, sizeof(char));

	// unwrap node to different type
	switch (nodeType)
	{
	case ELEMENT_NODE:
		nodePnt = new DM_ElementNode(buffer);
		break;
	case DOCUMENT_NODE:
		nodePnt = new DM_DocumentNode(buffer);
		break;
	case ATTRIBUTE_NODE:
		nodePnt = new DM_AttributeNode(buffer);
		break;
	case TEXT_NODE:
		nodePnt = new DM_TextNode(buffer);
		break;
	case COMMENT_NODE:
		nodePnt = new DM_CommentNode(buffer);
		break;
	default:
		nodePnt = NULL;
        globalErrorInfo.insertProblem(ERR_TYPE_WARNING,__LINE__,"DM_DataNode::unwrap",__FILE__,"Invalid node type");
	}

	return nodePnt;
}

/**
* Process Method
* Used for wraping a vchar to a buffer, by storing the length and the content of the string.
*
*@param buffer The buffer to write to. (return value)
*@param str The string to wrap
*@param length The length of the string (since the char* to be wrapped maybe a memory block, rather than a string).
*@return the size that has been writting to the buffer;
*/
int DM_DataNode::wrapString(char* buffer, char* str, int length)
{
	memcpy(buffer, &length, sizeof(int));
	int buflen = sizeof(int);
	if (length > 0)
	{
		memcpy(buffer + sizeof(int), str, length);
		buflen += length;
	}
	return buflen;
}

/**
* Process Method
* Used for unwrapping a vchar, by getting its length, allocate memory, and copy the string from buffer
*
*@param  buffer The buffer to read from
*@param  targetStr The place where the unwrapped string should go
*@returns The length of buffer (in bytes) has been consumed by the unwrapped string. 
*/
int DM_DataNode::unwrapString(char* buffer, char* targetStr)
{
	int length;

	// get the length of the string. 
	memcpy(&length, buffer, sizeof(int));
	if (length <= 0) {
		if (targetStr != NULL)
			targetStr[0] = '\0';
		return sizeof(int);
	}
	//when targetStr == NULL this will not work, since we only pass in char*:
	if (targetStr == NULL)
	{
		// allocate space is the targetStr is a NULL pointer
		//targetStr = new char[length+1];
		//memcpy(targetStr, buffer+sizeof(int), length);
		//targetStr[length] = '\0';
		globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"DM_DataNode::unwrapString",__FILE__,"this unwrap string method only works with pre-allocated buffers");
		globalErrorInfo.displayError();
		exit(0);
	}
	else
	{
		// otherwise, just copy the string. 
		memcpy(targetStr, buffer+sizeof(int), length);
		targetStr[length] = '\0';
	}
	return length+sizeof(int);
}


//hack (for now), since unwrapString above doesn't work for char[] arrays that aren't pre-allocated
//and I'll need to change a bunch of fixed size char[] arrays before getting rid of the one above:
/*
int DM_DataNode::unwrapStringAlloc(char* buffer, char** targetStr)
{
	int length;

	// get the length of the string. 
	memcpy(&length, buffer, sizeof(int));
	if (length <= 0) {
		if (*targetStr != NULL)
			(*targetStr)[0] = '\0';
		return sizeof(int);
	}
	if (*targetStr == NULL)
	{
		// allocate space is the targetStr is a NULL pointer
		*targetStr = new char[length+1];
		memcpy(*targetStr, buffer+sizeof(int), length);
		(*targetStr)[length] = '\0';
	}
	else
	{
		// otherwise, just copy the string. 
		memcpy(*targetStr, buffer+sizeof(int), length);
		(*targetStr)[length] = '\0';
	}
	return length+sizeof(int);	
}
*/

bool DM_DataNode::isAncestorOf(DM_DataNode *potentialDescendant)
{
	return (key < potentialDescendant->getKey() && 
		endKey > potentialDescendant->getEndKey());
}

bool DM_DataNode::isDescendantOf(DM_DataNode *potentialAncestor)
{
	return (key > potentialAncestor->getKey() && 
		endKey < potentialAncestor->getEndKey());
}

bool DM_DataNode::isParentOf(DM_DataNode *potentialChild)
{
	return (level == potentialChild->getLevel() - 1 &&
			key < potentialChild->getKey() && 
			endKey > potentialChild->getEndKey());
}

bool DM_DataNode::isChildOf(DM_DataNode *potentialParent)
{
	return (level == potentialParent->getLevel() + 1 &&
		key > potentialParent->getKey() && 
		endKey < potentialParent->getEndKey());
}
