/*
COPYRIGHT  (c) 2000-2004 
THE REGENTS OF THE UNIVERSITY OF MICHIGAN
ALL RIGHTS RESERVED

PERMISSION IS GRANTED TO USE, COPY, CREATE DERIVATIVE WORKS AND
REDISTRIBUTE THIS SOFTWARE AND SUCH DERIVATIVE WORKS FOR NONCOMMERCIAL
EDUCATION AND RESEARCH PURPOSES, SO LONG AS NO FEE IS CHARGED, AND SO LONG
AS THE COPYRIGHT NOTICE ABOVE, THIS GRANT OF PERMISSION, AND THE
DISCLAIMER BELOW APPEAR IN ALL COPIES MADE; AND SO LONG AS THE NAME OF THE
UNIVERSITY OF MICHIGAN IS NOT USED IN ANY ADVERTISING OR PUBLICITY
PERTAINING TO THE USE OR DISTRIBUTION OF THIS SOFTWARE WITHOUT SPECIFIC,
WRITTEN PRIOR AUTHORIZATION.

THIS SOFTWARE IS PROVIDED AS IS, WITHOUT REPRESENTATION FROM THE
UNIVERSITY OF MICHIGAN AS TO ITS FITNESS FOR ANY PURPOSE, AND WITHOUT
WARRANTY BY THE UNIVERSITY OF MICHIGAN OF ANY KIND, EITHER EXPRESS OR
IMPLIED, INCLUDING WITHOUT LIMITATION THE IMPLIED WARRANTIES OF
MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE. THE REGENTS OF THE
UNIVERSITY OF MICHIGAN SHALL NOT BE LIABLE FOR ANY DAMAGES, INCLUDING
SPECIAL, INDIRECT, INCIDENTAL, OR CONSEQUENTIAL DAMAGES, WITH RESPECT TO
ANY CLAIM ARISING OUT OF OR IN CONNECTION WITH THE USE OF THE SOFTWARE,
EVEN IF IT HAS BEEN OR IS HEREAFTER ADVISED OF THE POSSIBILITY OF SUCH
DAMAGES.
*/

/**
 * @author Yuqing (Melanie) Wu
 */

#include "DM_CharNode.h"

/**
* class DM_CharNode
* 
* This class represent a node whose content is of string type.
* 
* @see DM_DataNode
* @see DM_TextNode
* @see DM_CommentNode
*/


/**
* Constructor
*
* Initialize the variable with the information given
*
* @param key The start key of the node
* @param level The depth of the node
* @param str The string value of the content of the node
*/
DM_CharNode::DM_CharNode(KeyType key,
						 short level,
						 const char* str) 
						 : DM_DataNode(key, CHAR_NODE, NULL, level)
{
	if (str==NULL) this->length = 0;
	else 
	{
		// the value of varible length is the length of the string
		this->length = strlen(str);
		this->charValue = new char[strlen(str)+1];
		strcpy(this->charValue, str);
	}
	this->descendantDepth = 0;
	this->attributes = -1;
}

/**
* Constructor
* 
* Create an instance of the DM_CharNode using the information wrapped in a string
*
*@param buffer The string which contains the information about the node, wrapped in a string
* 
*@see DM_CharNode::unwrap()
*/
DM_CharNode::DM_CharNode(char* buffer) : DM_DataNode(-1, CHAR_NODE, NULL, -1)
{
	// this is done by unwrap().
	unwrap(buffer);
}

/**
* Destructor
* Free the space allocated for the string
*/
DM_CharNode::~DM_CharNode()
{
	delete [] this->charValue;
}

/**
* Access Method
* Get the string value of the nodes
* @returns The string which is the content of the node. 
*/
char* DM_CharNode::getCharValue()
{
	return this->charValue;
}

/**
* Access Method for Multicolor
* Added 06/23/2003
* Get the key of the attribute node which contains the attributes belonging to this element node
*
* @returns The key of the attribute node
*/

KeyType DM_CharNode::getAttributes()
{
	return this->attributes;
}

/**
* Set Method for Multicolor
* Added 06/23/2003
* Set the link to the attribute node which contains the attributes belonging to this element node
* @param key The key of the attribute node
*/
void DM_CharNode::setAttributes(KeyType key)
{
	this->attributes = key;
}

/**
* Check Method for Multicolor
* Added 06/29/2003
* See whether it is part of multicolor semantics
*/
bool DM_CharNode::isPartOfMCT()
{
	if ((this->attributes).isValid()) return true;
	return false;
}

/**
* Process Method
*
* Wrap the content of the node into a string
* 
* The output of this method is used to be stored into database
*
* @param bufLength The size of the string, which is the wrapping result (return value)
* @returns A string that contains all the information of the node.
*
* @see DM_DataNode::wrapCommon()
*/
char* DM_CharNode::wrap(int* bufLength)
{
	// variable definition. 

	// the buffer that contains the common information of all nodes (DM_DataNode)
	char* dataBuffer;
	int dataBufferLen;

	// the length of the data unique in DM_CharNode
	int charBufferLen;

	// the output
	char* buffer;

	// wrap the common fields in DM_DataNode
	dataBuffer = this->wrapCommon(&dataBufferLen);

	// the length of the buffer for char node
	// Nuwee added sizeof(KeyType) 06/23/2003 for Multicolor 
	charBufferLen = this->length + sizeof(int) + sizeof(KeyType);

	// the information wrapped into the string for a DM_CharNode is: 
	// 1. the nodetype.
	// 2. the size of the common data of all nodes (DM_DataNode)
	// 3. the size of the data unique in DM_CharNode
	// 4. the common data
	// 5. the data unique in DM_CharNode, which contains the length of the text string, and the text string itself.

	// first, compute the length of the buffer. 
	(*bufLength) = dataBufferLen + charBufferLen + 3 * sizeof(int);
	buffer = new char[*bufLength];
    // MEM INIT
    memset(buffer,0,*bufLength);
	int cursor = 0;

	// the note type
	memcpy(buffer+cursor, &(this->nodeFlag), sizeof(char));
	cursor += sizeof(char);

	// the length of the common data
	memcpy(buffer+cursor, &dataBufferLen, sizeof(int));
	cursor += sizeof(int);

	// the length of the data unique in DM_CharNode
	memcpy(buffer+cursor, &charBufferLen, sizeof(int));
	cursor += sizeof(int);

	// the common data
	memcpy(buffer+cursor, dataBuffer, dataBufferLen);
	cursor += dataBufferLen;

	// attribute node key Nuwee added for Multicolor
	memcpy(buffer + cursor, &(this->attributes), sizeof(KeyType));
	cursor += sizeof(KeyType);

	// the text data of DM_CharNode (length + text).
	cursor += this->wrapString(buffer+cursor, this->charValue, this->length);
	
	// release the dataBuffer.
	delete [] dataBuffer;
	return buffer;
}

/**
* Process Method
*
* Unwrap the content of the node from a string and restore the instance
* 
* @param buffer A string that contains all the information of the node
*/
void DM_CharNode::unwrap(char* buffer)
{
	int dataLen, charLen;
	int cursor = sizeof(char);

	// get the length of the common data
	memcpy(&dataLen, buffer+cursor, sizeof(int));
	cursor += sizeof(int);

	// get the length of the text data
	memcpy(&charLen, buffer+cursor, sizeof(int));
	cursor += sizeof(int);
	
	// unwrap the common fields in DM_DataNode
	this->unwrapCommon(buffer+cursor);
	cursor += dataLen;

	// attribute node key
	// Nuwee added 06/23/2003 for Multicolor
	memcpy(&(this->attributes), buffer + cursor, sizeof(KeyType));
	cursor += sizeof(KeyType);

	// unwrap the char value 

	// get the length of the text data
	memcpy(&(this->length), buffer+cursor, sizeof(int));	
	cursor += sizeof(int);

	if (this->length > 0)
	{
		// allocate space enough for the text and copy the content of the text from the incoming buffer.
		this->charValue = new char[this->length+1];
		memcpy(this->charValue, buffer+cursor, this->length);
		this->charValue[this->length] = '\0';
	}
	else this->charValue = NULL;
}

/**
* Process Method
* 
* This method compute the size of memory occupied by the node.
* Note: this size is the size of the node in memory, not the record size in database.
*
* @returns The in-memory size of the node in bytes.
*/
int DM_CharNode::getNodeSize()
{
	// the size of data in DM_DataNode
	int datanodeSize = sizeof(DM_DataNode) // the size of all field in the class
					//+ sizeof(int) + strlen(this->nodeTag) // for node tag
					- sizeof(char*) + this->historyLength; // for history

	// the size of data in DM_CharNode
	// Nuwee added sizeof(KeyType) 06/23/2003
	int charnodeSize = this->length + sizeof(int) + sizeof(KeyType);

	// the size teken is the sum of the size for common data and the size for the text, which is 
	// unique in DM_CharNode.
	return datanodeSize + charnodeSize; 
}
