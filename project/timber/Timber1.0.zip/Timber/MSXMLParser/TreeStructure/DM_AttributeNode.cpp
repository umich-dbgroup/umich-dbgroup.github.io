/*
COPYRIGHT  (c) 2000-2004 
THE REGENTS OF THE UNIVERSITY OF MICHIGAN
ALL RIGHTS RESERVED

PERMISSION IS GRANTED TO USE, COPY, CREATE DERIVATIVE WORKS AND
REDISTRIBUTE THIS SOFTWARE AND SUCH DERIVATIVE WORKS FOR NONCOMMERCIAL
EDUCATION AND RESEARCH PURPOSES, SO LONG AS NO FEE IS CHARGED, AND SO LONG
AS THE COPYRIGHT NOTICE ABOVE, THIS GRANT OF PERMISSION, AND THE
DISCLAIMER BELOW APPEAR IN ALL COPIES MADE; AND SO LONG AS THE NAME OF THE
UNIVERSITY OF MICHIGAN IS NOT USED IN ANY ADVERTISING OR PUBLICITY
PERTAINING TO THE USE OR DISTRIBUTION OF THIS SOFTWARE WITHOUT SPECIFIC,
WRITTEN PRIOR AUTHORIZATION.

THIS SOFTWARE IS PROVIDED AS IS, WITHOUT REPRESENTATION FROM THE
UNIVERSITY OF MICHIGAN AS TO ITS FITNESS FOR ANY PURPOSE, AND WITHOUT
WARRANTY BY THE UNIVERSITY OF MICHIGAN OF ANY KIND, EITHER EXPRESS OR
IMPLIED, INCLUDING WITHOUT LIMITATION THE IMPLIED WARRANTIES OF
MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE. THE REGENTS OF THE
UNIVERSITY OF MICHIGAN SHALL NOT BE LIABLE FOR ANY DAMAGES, INCLUDING
SPECIAL, INDIRECT, INCIDENTAL, OR CONSEQUENTIAL DAMAGES, WITH RESPECT TO
ANY CLAIM ARISING OUT OF OR IN CONNECTION WITH THE USE OF THE SOFTWARE,
EVEN IF IT HAS BEEN OR IS HEREAFTER ADVISED OF THE POSSIBILITY OF SUCH
DAMAGES.
*/

/**
 * @author Yuqing (Melanie) Wu
 */

#include "DM_AttributeNode.h"
#include "../../Utilities/ErrorInfoClass.h"
#include <sstream>
extern ErrorInfoClass globalErrorInfo;

/**
* class DM_AttibuteNode
* 
* This class represent an Attribute in the data structure which we are going to store into Shore
* 
* @see DM_DataNode
* @see DM_ElementNode
*/

/**
* Constructor
* Initialize the variables with the information given
*
* @param key The start key of the node. 
* @param level The depth of the node
* @param num The number of attributes to be stored in this node.
* @param names A list of attribute names
* @param values A list of attribute values
* @param parent The key of the element node which has these attributes
*/
DM_AttributeNode::DM_AttributeNode(KeyType key,
								   short level,
								   short num,
								   char** names,
								   Value** values,
								   KeyType parent)
								   : DM_DataNode(key, ATTRIBUTE_NODE, NULL, level)
{
	this->attrNum = num;

	this->attrNames = names;
	this->attrValues = values;

	//AN: DM_AttributeNode is taking 'owernship' of the names/values arrays now, so comment out:

	/*
	// allocate space for attribute values, based on the number of attributes
	if (this->attrNum > 0) this->attrValues = new Value*[num];

	for (int i=0; i<this->attrNum; i++)
	{
		// copy the 1'th attribute node
		if (strlen(names[i]) > MAX_ATTRIBUTE_NAME_LENGTH)
		{
			memcpy(this->attrNames[i], names[i], MAX_ATTRIBUTE_NAME_LENGTH-1);
			this->attrNames[i][MAX_ATTRIBUTE_NAME_LENGTH-1] = '\0';
		}
		else 
		{
			strcpy(this->attrNames[i], names[i]);
		}

		// copy the i'th attribute value.
		this->attrValues[i] = new Value(values[i]);
	}
	*/

	// set the parent pointer
	this->setParent(parent);

	// an attribute node is a leaf node.
	this->descendantDepth = 0;

	// Added 10/17/03
	//initialize for Multicolor information
	this->textNum = 0;
	this->mctNum = 0;

	for (int i=0; i < MAX_TEXT_NUMBER ; i++){
		this->mctTextNode[i] = 0;
	}
	for (int i=0; i < MAX_COLOR_NUMBER ; i++){
		this->mctParents[i] = 0;
	}
	for (int i=0; i < MAX_TEXT_NUMBER ; i++) {
		for (int j = 0 ; j < MAX_COLOR_NUMBER ; j++) {
			this->mctNextSibling[i][j] = 0;
			this->mctPrevSibling[i][j] = 0;
		}
	} //end Multicolor

}

/**
* Constructor for Multicolor
* Initialize the variables with the information given
* Allocate attributes for colors info
*
* @param key The start key of the node. 
* @param level The depth of the node
* @param num The number of attributes to be stored in this node. (including bogus multicolor attribute)
* @param realnum The real number of attributes to be stored in this node
* @param names A list of attribute names
* @param values A list of attribute values
* @param numcolor The number of colors this node is painted
* @param parent The key of the element node which has these attributes
*/
DM_AttributeNode::DM_AttributeNode(KeyType key,
								   short level,
								   short num,
								   short realnum, 
								   char** names, 							 
								   Value** values,
								   int numcolor,
								   KeyType parent) 							 
								   : DM_DataNode(key, ATTRIBUTE_NODE, NULL, level)
{
	//this->attrNum = realnum;
	//AN: now that we're just using the full names/values arrays here:
	this->attrNum = num;

	this->attrNames = names;
	this->attrValues = values;

/*
	// allocate space for attribute values, based on the number of attributes
	if (this->attrNum > 0) this->attrValues = new Value*[realnum];

	int j=0;
	for (int i=0; i<num; i++)
	{
		// copy the 1'th attribute node
		if (strlen(names[i]) > MAX_ATTRIBUTE_NAME_LENGTH)
		{
			memcpy(this->attrNames[i], names[i], MAX_ATTRIBUTE_NAME_LENGTH-1);
			this->attrNames[i][MAX_ATTRIBUTE_NAME_LENGTH-1] = '\0';
		}
		else if (!strcmp(names[i],"copydirection")){
			continue;
		}
		else if (!strcmp(names[i],"numcolor")){
			continue;
		}
		else 
		{
			strcpy(this->attrNames[j], names[i]);
		}

		// copy the i'th attribute value.
		this->attrValues[j] = new Value(values[i]);
		j++;
	}
*/

	// set the parent pointer
	this->setParent(parent);

	// an attribute node is a leaf node.
	this->descendantDepth = 0;

	// Added 10/17/03
	//initialize for Multicolor information
	this->textNum = 1;
	this->mctNum = numcolor;

	for (int i=0; i < MAX_TEXT_NUMBER ; i++){
		this->mctTextNode[i] = 0;
	}
	for (int i=0; i < MAX_COLOR_NUMBER ; i++){
		this->mctParents[i] = 0;
	}
	for (int i=0; i < MAX_TEXT_NUMBER ; i++) {
		for (int j = 0 ; j < MAX_COLOR_NUMBER ; j++) {
			this->mctNextSibling[i][j] = 0;
			this->mctPrevSibling[i][j] = 0;
		}
	} 
	(void)this->addMCTParent(parent);
	//end Multicolor
}

/**
* Constructor
* 
* Create an instance of the DM_AttributeNode using the information wrapped in a string
*
*@param buffer The string which contains the information about the node, wrapped in a string
* 
*@see DM_AttributeNode::unwrap()
*/
DM_AttributeNode::DM_AttributeNode(char* buffer) : DM_DataNode(-1, ATTRIBUTE_NODE, NULL, -1)
{
	unwrap(buffer);
}

/**
* Destructor
* Free space allocated for names and values
*/
DM_AttributeNode::~DM_AttributeNode() 
{
	//currently attrNames is allocated statically, with fixed sizes,
	//uncomment the following 'delete attrNames' lines when this is changed:

	for (int i=0; i < this->attrNum; i++ )
	{
		delete [] attrNames[i];
		delete attrValues[i];
	}
	if (this->attrNum > 0) {
		delete [] attrNames;
		delete [] attrValues;
	}
}

/**
* Access Method
* Get the total number of attributes in the node
* @returns the total number of attributes in the node
*/
short DM_AttributeNode::getAttributeNumber()
{
	return this->attrNum;
}

/**
* Access Method
* Get the name and value of the attribute with the given index
*
* @param index The position of the attribute whose information is required
* @param name The name of the attribute (return value)
* @returns The value of the attribute
*/
Value* DM_AttributeNode::getAttr(short index, char* &name)
{
	if (index<=this->attrNum)
	{
		name = new char[strlen(this->attrNames[index]) + 1];
		strcpy(name, this->attrNames[index]);
		return this->attrValues[index];
	}
	else 
    {
        //globalErrorInfo.insertProblem(ERR_TYPE_WARNING,__LINE__,"DM_AttributeNode::getAttr",__FILE__,"Attribute position out of bound");
		return NULL;
    }
}

/**
* Access Method
* Get the names and values of all the attributes in the node
*
* @param attrname The name of an attribute whose value we are looking for
* @returns The value of the attribute with given name, NULL if no attribute has the name in the node
*/
Value* DM_AttributeNode::getAttr(const char* attrname)
{
	// go over attributes one by one, return the value if the attribute name matches the name given.
	for (int i=0;i<this->attrNum; i++)
	{
		if (strcmp(this->attrNames[i], attrname) == 0)
			return this->attrValues[i];
	}
	return NULL;
}

/**
* Access Method
* Get the values of an attribute in the node with the given index
*
* @param ndex The position of the attribute whose information is required
* @returns The value of the attribute with given index, NULL if no attribute has the index in the node
*/
Value* DM_AttributeNode::getAttrAt(short index)
{
	return this->attrValues[index];
}

int DM_AttributeNode::setAttrValue(char* attrname, Value* value)
{
	// go over attributes one by one, set the value if the attribute name matches the name given.
	for (int i=0;i<this->attrNum; i++)
	{
		if (strcmp(this->attrNames[i], attrname) == 0) {
			delete this->attrValues[i];
			this->attrValues[i] = value;
			return i;
		}
	}
	return -1;
}

int DM_AttributeNode::insertAttribute(const char *attributeName, Value* value) {
	//if (this->attrNum == MAX_ATTRIBUTE_NUMBER) {
	//	globalErrorInfo.insertProblem(ERR_TYPE_WARNING,__LINE__,"DM_AttributeNode",__FILE__,"The maximum # of attributes has been reached for this node.  The node was not modified.");
	//	return -1;
	//}
	if (this->hasAttributeWithName(attributeName)) {
		//ostringstream oss;
		//oss << "The attribute node with start key = " <<
		//	key.toDouble()
		//	<< " already had an attribute named '" <<
		//	attributeName << "'. The new attribute/value pair was not inserted" ;

		//globalErrorInfo.insertProblem(ERR_TYPE_WARNING,__LINE__,"DM_AttributeNode::insertAttribute",__FILE__,oss.str().c_str());
		//globalErrorInfo.insertProblem(ERR_TYPE_WARNING,__LINE__,"DM_AttributeNode",__FILE__,"The attribute to insert already existed.  This node was not modified");

		return -1;
	}

	char** newAttributeNames = new char*[this->attrNum + 1];
	Value** newAttributeValues = new Value*[this->attrNum + 1];
	
	for (int i = 0; i < this->attrNum; i++) {
		newAttributeNames[i] = this->attrNames[i];
		newAttributeValues[i] = this->attrValues[i];
	}

	newAttributeNames[this->attrNum] = new char[strlen(attributeName)+1];
	strcpy(newAttributeNames[this->attrNum], attributeName);
	newAttributeValues[this->attrNum] = value;

	delete [] this->attrNames;
	delete [] this->attrValues;

	this->attrNames = newAttributeNames;
	this->attrValues = newAttributeValues;

	//AN: we need to get rid of the max restriction on attribute length!:
	//if (strlen(attributeName) > MAX_ATTRIBUTE_NAME_LENGTH)
	//{
	//	memcpy(this->attrNames[this->attrNum], attributeName, MAX_ATTRIBUTE_NAME_LENGTH-1);
	//	this->attrNames[this->attrNum][MAX_ATTRIBUTE_NAME_LENGTH-1] = '\0';
	//}
	//else 
	//{
	//	strcpy(this->attrNames[this->attrNum], attributeName);
	//}

	this->attrNum++;

	return this->attrNum;
}

/**
* Access Method
* Get the name of the index'th attribute.
* 
* @param index The position of the attribute whose information is required
* @returns The name of the attribute at that position.
*/
char* DM_AttributeNode::getAttributeNameAt(short index)
{
	if ((index >= 0) && (index < this->attrNum)) return this->attrNames[index];
	else return NULL;
}

/**
* Access Method
* Find out whether there is an attribute in this attribute node with the name given.
* 
* @param attrname The attribute name which it is looked for.
* @returns A boolean value which indicate whether an attribute with the given name exists in the node.
*/
bool DM_AttributeNode::hasAttributeWithName(const char* attrname)
{
	// go over the attributes one by one, looking for the name. 
	for (int i=0;i<this->attrNum; i++)
	{
		if (strcmp(this->attrNames[i], attrname) == 0) return true;
	}
	return false;
}

/**
* Access Method for Multicolor
* Added 06/29/2003
* Get sibling link
* @param parentkey The key of the parent node
* @param textnodekey The key of the text node in consideration
* @returns The key of the previous sibling of this node. -1 if this node is the first child of its parent.
*/
KeyType DM_AttributeNode::getMCTPrevSibling(KeyType parentkey, KeyType textnodekey)
{
 int i,forTextIndex = -1,forParentIndex = -1;
 bool foundtext = false;
 bool foundparent = false;

	//loop through to find the particular textnode index
	for (i = 0; i < this->textNum ; i++) {
		if (this->mctTextNode[i] == 0)
			break;
		if (this->mctTextNode[i] == textnodekey) {
			forTextIndex = i;
			foundtext = true;
			break;
		}
	}

	//loop through to find the particular parentnode (element) index
	for (i = 0; i < this->mctNum ; i++) {
		if(this->mctParents[i] == 0)
			break;
		if(this->mctParents[i] == parentkey) {
			forParentIndex = i;
			foundparent = true;
			break;
		}
	}

	if (foundtext && foundparent) {
		return this->mctPrevSibling[forTextIndex][forParentIndex];
	}
	else {
		globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"DM_AttributeNode::getMCTPrevSibling",__FILE__,"The key of the text or parent node given is not found");
		return -1;
	}
}

/**
* Access Method for Multicolor
* Added 06/29/2003
* Get sibling link
* @param parentindex The index of the parent node
* @param textindex The index of the text node in consideration
* @returns The key of the previous sibling of this node. -1 if this node is the first child of its parent.
*/
KeyType DM_AttributeNode::getMCTPrevSibling(int parentindex, int textindex)
{
	return this->mctPrevSibling[textindex][parentindex];
}

/**
* Access Method for Multicolor
* Added 06/29/2003
* Get sibling link
* @param parentkey The key of the parent node
* @param textnodekey The key of the text node in consideration
* @returns The key of the next sibling of this node. -1 if this node is the last child of its parent.
*/
KeyType DM_AttributeNode::getMCTNextSibling(KeyType parentkey, KeyType textnodekey)
{
 int i,forTextIndex = 0 ,forParentIndex = 0;
 bool foundtext = false;
 bool foundparent = false;

	//loop through to find the particular textnode index
	for (i = 0; i < this->textNum ; i++) {
		if (this->mctTextNode[i] == 0)
			break;
		if (this->mctTextNode[i] == textnodekey) {
			forTextIndex = i;
			foundtext = true;
			break;
		}
	}

	//loop through to find the particular parentnode (element) index
	for (i = 0; i < this->mctNum ; i++) {
		if(this->mctParents[i] == 0)
			break;
		if(this->mctParents[i] == parentkey) {
			forParentIndex = i;
			foundparent = true;
			break;
		}
	}

	if (foundtext && foundparent) {
		return this->mctNextSibling[forTextIndex][forParentIndex];
	}
	else {
		globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"DM_AttributeNode::getMCTPrevSibling",__FILE__,"The key of the text or parent node given is not found");
		return -1;
	}
}

/**
* Access Method for Multicolor
* Added 06/29/2003
* Get sibling link
* @param parentindex The index of the parent node
* @param textindex The index of the text node in consideration
* @returns The key of the next sibling of this node. -1 if this node is the last child of its parent.
*/
KeyType DM_AttributeNode::getMCTNextSibling(int parentindex, int textindex)
{
	return this->mctNextSibling[textindex][parentindex];
}

/**
* Access Method for Multicolor
* Added 07/06/2003
* Get number of color numbers/ parent numbers
* @returns mctNum
*/
int DM_AttributeNode::getMCTNum()
{
	return this->mctNum;
}

/**
* Access Method for Multicolor
* Added 07/06/2003
* Get number of text node associated with the multiclor elements
* @returns textNum
*/
int DM_AttributeNode::getMCTTextNum()
{
	return this->textNum;
}

/**
* Access Method for Multicolor
* Added 06/30/2003
* Get parent key for given index
* @param index The position of the color
* @returns The key of the parent for that position
*/
KeyType DM_AttributeNode::getParent(int index)
{
	if ((index >= 0) && (index < mctNum)){
		return this->mctParents[index];
	}
	globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"DM_AttributeNode::getParent",__FILE__,"The parent multicolored key is not found");
	return -1;
}

/**
* Access Method for Multicolor
* Added 07/22/2003
* Get index (position) of given parent key
* @param parentkey The key of parent node
* @returns The position indexed in attribute node
*/
int DM_AttributeNode::getParentIndex(KeyType parentkey)
{
	for (int i = 0 ; i< this->mctNum ; i++) {
		if (this->mctParents[i] == parentkey) return i;
	}
	globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"DM_AttributeNode::getParentIndex",__FILE__,"The parent mulicolored key is not found");
	return -1;
}

/**
* Access Method for Multicolor
* Added 07/22/2003
* Get index (position) of given text key
* @param textkey The key of the text node
* @returns The position indexed in attribute node
*/
int DM_AttributeNode::getTextIndex(KeyType textkey)
{
	for (int i = 0 ; i< this->textNum ; i++) {
		if (this->mctTextNode[i] == textkey) return i;
	}
	globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"DM_AttributeNode::getTextIndex",__FILE__,"The MCT text key is not found");
	return -1;
}

/**
* Access Method for Multicolor
* Added 06/30/2003
* Get all parent keys of this multicolor elements
* @param parents The returned array of parents key
* @returns Number of parents key
*/
int DM_AttributeNode::getAllParents(KeyType* parents)
{
	parents = new KeyType[mctNum];
	for (int i = 0; i < mctNum ; i++) {
		parents[i] = this->mctParents[i];
	}
	return mctNum;
}

/**
* Access Method for Multicolor
* Added 07/22/2003
* Add 1 parent associated with multicolor
* @param parent The key of the parent to be added
* @returns The index the parent is located
*/
int DM_AttributeNode::addMCTParent(KeyType parent)
{
	int index = -1;
	for (int i = 0 ; i < this->mctNum; i++) 
	{
		if (this->mctParents[i] == 0) {
			this->mctParents[i] = parent;
			index = i;
			break;
		}
	}
	return index;
}

/**
* Access Method for Multicolor
* Added 07/22/2003
* Add 1 text node associated with multicolor
* @param parent The key of the text to be added
* @returns The index the text is located
*/
int DM_AttributeNode::addMCTTextNode(KeyType textkey)
{
	int index = -1;
	for (int i = 0 ; i < this->textNum; i++) 
	{
		if (this->mctTextNode[i] == 0) 
		{
			this->mctTextNode[i] = textkey;
			index = i;
			break;
		}
	}
	return index;
}

/**
* Access Method for Multicolor
* Added 06/29/2003
* Set the sibling link at the parent and text position
* @param textindex The index of the text node in consideration
* @param parentindex The index of the parent node
* @prevsibling The key of the prev sibling.
*/
void DM_AttributeNode::setMCTPrevSibling(int textindex, int parentindex, KeyType prevsibling)
{
	//check consistency
	if (textindex >= this->textNum) 
		globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"DM_AttributeNode::setMCTPrevSibling",__FILE__,"Inconsistent text node index");
	if (parentindex >= this->mctNum) 
		globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"DM_AttributeNode::setMCTPrevSibling",__FILE__,"Inconsistent parent node index");
	this->mctPrevSibling[textindex][parentindex] = prevsibling;

}

/**
* Access Method for Multicolor
* Added 06/29/2003
* Set the sibling link at the parent and text position
* @param textindex The index of the text node in consideration
* @param parentindex The index of the parent node
* @nextsibling The key of the next sibling.
*/
void DM_AttributeNode::setMCTNextSibling(int textindex, int parentindex, KeyType nextsibling)
{
	//check consistency
	if (textindex >= this->textNum) 
		globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"DM_AttributeNode::setMCTPrevSibling",__FILE__,"Inconsistent text node index");
	if (parentindex >= this->mctNum) 
		globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"DM_AttributeNode::setMCTPrevSibling",__FILE__,"Inconsistent parent node index");
	this->mctNextSibling[textindex][parentindex] = nextsibling;
}

/**
* Debug Method
* Print the content of the node (the name and value of each attribute)
*/
void DM_AttributeNode::printValue()
{
	cout << "Attribute Node: Key = " << this->key.toString() << "	" << endl;

	for (int i = 0; i < this->attrNum; i++)
	{
		switch (this->attrValues[i]->getValueType())
		{
		case INT_VALUE:
			cout << "	" << this->attrNames[i] << " = '"  << this->attrValues[i]->getIntValue() << "'" << endl;
			break;
		case STRING_VALUE:
			cout << "	" << this->attrNames[i] << " = '"  << this->attrValues[i]->getStrValue() << "'" << endl;
			break;
		default:
			break;
		}
	}
}

/**
* Process Method
*
* Wrap the content of the node into a string
* 
* The output of this method is used to be stored into database
*
* @param bufLength The size of the string, which is the wrapping result (return value)
* @returns A string that contains all the information of the node.
*
* @see DM_DataNode::wrapCommon()
*/
char* DM_AttributeNode::wrap(int* length)
{
	// the buffer for common data shared by all type of nodes
	char* dataBuffer;
	int dataBufferLen;

	// the buffer for data unique to the attribute node
	char* attrBuffer ;
	short attrBufferLen;

	// for output
	char* buffer;

	// value is also wrapped into string. the following two variables are for the length and string of 
	// each attribute value. 
	int* valuelength = NULL;
	char** values = NULL;

	// wrap the common data defined in DM_DataNode
	dataBuffer = this->wrapCommon(&dataBufferLen);

	// wrap the data unique in DM_AttributeNode
	// Multicolor 10/14/03
	if (this->attrNum > 0) {
		// the length for each value
		valuelength = new int[this->attrNum];
		// the string for each wrapped attribute value
		values = new char*[this->attrNum];
	}
	// the length of string needed for data unique to attribute node is computed as following

	// initialized with an integer (for attribute number)
	attrBufferLen = sizeof(short);	

	// compute the length needed for each attribute (name and value)
	for (int i=0; i<this->attrNum; i++)
	{
		// wrap the attribute value
		values[i] = this->attrValues[i]->wrap(&(valuelength[i]));

		// add up the space requirement for this attribute 
		attrBufferLen = (short) attrBufferLen 
			+ sizeof(int) + (short)strlen(this->attrNames[i]) + 1		// for attribute name
			+ sizeof(int) + (short)valuelength[i]; // for attribute value
	}

	attrBufferLen += /* Multicolor*/ 2*sizeof(int);
    attrBufferLen += (short) (this->mctNum)*sizeof(KeyType);
    attrBufferLen += (short) (this->textNum)*sizeof(KeyType);
	attrBufferLen += 2*((short)(this->mctNum))*((short)(this->textNum))*sizeof(KeyType);

	// allocate space for the buffer for data unique to attribute node
	attrBuffer = new char[attrBufferLen];
    // MEM INIT
    memset(attrBuffer,0,attrBufferLen);
	int cursor = 0;

	// attribute number
	memcpy(attrBuffer+cursor, &(this->attrNum), sizeof(short));
	cursor += sizeof(short);

	//Added: 06/30/03
	//wrap data for Multicolor information
	memcpy(attrBuffer+cursor, &(this->mctNum), sizeof(int)); // Number of MCT color element
	cursor += sizeof(int);

	memcpy(attrBuffer+cursor, &(this->textNum), sizeof(int)); //Number of text node under element
	cursor += sizeof(int);

	//Parents key
	for (int i = 0; i < mctNum ; i++) {
		memcpy(attrBuffer+cursor,&(this->mctParents[i]),sizeof(KeyType));
		cursor += sizeof(KeyType);
	}

	//Text node key
	for (int i = 0; i < textNum; i++) {
		memcpy(attrBuffer+cursor, &(this->mctTextNode[i]), sizeof(KeyType));
		cursor += sizeof(KeyType);
	}

	//sibling key for text node
	for (int i = 0; i < textNum ; i++) {
		for (int j = 0 ; j < mctNum ;j++) {
			memcpy(attrBuffer+cursor, &(this->mctPrevSibling[i][j]), sizeof(KeyType));
			cursor += sizeof(KeyType);

			memcpy(attrBuffer+cursor, &(this->mctNextSibling[i][j]), sizeof(KeyType));
			cursor += sizeof(KeyType);
		}
	}
	// end Multicolor

	// for each attribute, wrap its name and value
	for (int i=0; i<this->attrNum; i++)
	{
		// attribute name
		this->wrapString(attrBuffer+cursor, this->attrNames[i], strlen(this->attrNames[i]));
		cursor += strlen(this->attrNames[i]) + sizeof(int);

		// attribute value
		this->wrapString(attrBuffer+cursor, values[i], valuelength[i]);
		cursor += valuelength[i] + sizeof(int);

	}

	// combine the content in the two buffer, headed with the 
    // node type, and the length of the two parts
	(*length) = dataBufferLen + attrBufferLen + sizeof(char) + sizeof(int) + sizeof(short);

	buffer = new char[*length];
    memset(buffer,0,*length);
	cursor = 0;

	// node type
	memcpy(buffer+cursor, &(this->nodeFlag), sizeof(char));
	cursor += sizeof(char);

	// size for common data
	memcpy(buffer+cursor, &dataBufferLen, sizeof(int));
	cursor += sizeof(int);

	// size for data unique to attribute node
	memcpy(buffer+cursor, &attrBufferLen, sizeof(short));
	cursor += sizeof(short);

	// common data
	memcpy(buffer+cursor, dataBuffer, dataBufferLen);
	cursor += dataBufferLen;

	// data for attribute node
	memcpy(buffer+cursor, attrBuffer, attrBufferLen);
	cursor += attrBufferLen;

	delete [] dataBuffer;
	delete [] attrBuffer;
	if (this->attrNum >0)
	{
		delete [] valuelength;
        for (int i=0; i<attrNum; i++) delete [] values[i];
		delete [] values;
	}
	return buffer;
}


/**
* Process Method
*
* Unwrap the content of the node from a string and restore the instance
* 
* @param buffer A string that contains all the information of the node
*/
void DM_AttributeNode::unwrap(char* buffer)
{
	int dataLen, attrLen;
	int cursor,i,j;

	// get the length of the two parts: common data in DataNode, and data for ElementNode only
	cursor = sizeof(char); // skip the first integer (node type)

	// data length for common data
	memcpy(&dataLen, buffer + cursor, sizeof(int));
	cursor += sizeof(int);

	// data length for data unique to attribute node
	memcpy(&attrLen, buffer + cursor, sizeof(short));
	cursor += sizeof(short);

	// unwrap the common data
	this->unwrapCommon(buffer + cursor);
	cursor += dataLen;

	// unwrap the data fields in AttributeNode

	// attribute Number
	memcpy(&(this->attrNum), buffer + cursor, sizeof(short));
	cursor += sizeof(short);

	//Added: 06/30/03
	//Unwrap data for Multicolor information
	memcpy(&(this->mctNum), buffer + cursor, sizeof(int));// Number of MCT color element
	cursor += sizeof(int);

	memcpy(&(this->textNum), buffer + cursor, sizeof(int));//Number of text node under element
	cursor += sizeof(int);

	i = 0;
	//Parents key
	for (i = 0 ; i < this->mctNum ; i++) {
		memcpy(&(this->mctParents[i]), buffer + cursor, sizeof(KeyType));
		cursor += sizeof(KeyType);
	}

	//Text nodes key
	for (i = 0 ; i < this->textNum ; i++) {
		memcpy(&(this->mctTextNode[i]), buffer + cursor, sizeof(KeyType));
		cursor += sizeof(KeyType);
	}

	//Siblings key
	for (i = 0 ; i < this->textNum ; i++) {
		for (j = 0 ; j < this->mctNum ; j++) {
			memcpy(&(this->mctPrevSibling[i][j]), buffer + cursor, sizeof(KeyType));
			cursor += sizeof(KeyType);

			memcpy(&(this->mctNextSibling[i][j]), buffer + cursor, sizeof(KeyType));
			cursor += sizeof(KeyType);
		}
	}
	//end Multicolor

	// attribute name and value
	if (this->attrNum > 0) {
		this->attrValues = new Value*[this->attrNum];
		this->attrNames = new char*[this->attrNum];
	}
	for (i=0; i<this->attrNum; i++)
	{
		int strLen;
		char* valueStr = NULL;


		// attribute name

		///// let's not mess with unwrapString:
		//this->attrNames[i] = NULL;
		//cursor += this->unwrapString(buffer+cursor, this->attrNames[i]);
		//cursor += this->unwrapStringAlloc(buffer+cursor, &(this->attrNames[i]));
		
		///// do the following intead:
		memcpy(&strLen, buffer+cursor, sizeof(int));	
		cursor += sizeof(int);

		this->attrNames[i] = new char[strLen + 1];
		memcpy(this->attrNames[i], buffer+cursor, strLen);
		this->attrNames[i][strLen] = '\0';
		cursor += strLen;
		////////////////////

		memcpy(&strLen, buffer+cursor, sizeof(int));	
		cursor += sizeof(int);

		// string that contains attribute value
		valueStr = new char[strLen];
		memcpy(valueStr, buffer+cursor, strLen);
		cursor += strLen;

		// reconstruct the attribute value (in Value type)
		this->attrValues[i] = new Value(valueStr);
		delete [] valueStr;
	}

	//07/29/03 for Multicolor
	//Fill in invalid info
	for (i=this->textNum; i < MAX_TEXT_NUMBER ; i++) {
		this->mctTextNode[i] = 0;
	}
	for (i=this->mctNum; i < MAX_COLOR_NUMBER ; i++) {
		this->mctParents[i] = 0;
	}
	for (i=this->textNum; i < MAX_TEXT_NUMBER ; i++) {
		for (j = this->mctNum ; j < MAX_COLOR_NUMBER ; j++) {
			this->mctNextSibling[i][j] = 0;
			this->mctPrevSibling[i][j] = 0;
		}
	} //end Multicolor

}

/**
* Process Method
* 
* This method compute the size of memory occupied by the node.
* Note: this size is the size of the node in memory, not the record size in database.
*
* @returns The in-memory size of the node in bytes.
*/

int DM_AttributeNode::getNodeSize()
{
	// the size of data in DM_DataNode
	int datanodeSize = sizeof(DM_DataNode) // the size of all field in the class
					//+ sizeof(int) + strlen(this->nodeTag) // for node tag
					- sizeof(char*) + this->historyLength; // for history

	// the size of data in DM_AttributeNode
	int attrnodeSize = sizeof(int);	// for attribute number
	for (int i=0; i<this->attrNum; i++)
	{
		// add up the space requirement for this attribute 
		attrnodeSize = attrnodeSize 
			+ sizeof(int) + strlen(this->attrNames[i]) + 1		// for attribute name
			+ sizeof(int) + this->attrValues[i]->getValueSize(); // for attribute value
	}

	//Added 06/23/2003 for Multicolor
	int mctinfoSize = 2*sizeof(int); //for number of colors
	mctinfoSize += mctNum*sizeof(KeyType) + textNum*sizeof(KeyType) + 2*mctNum*textNum*sizeof(KeyType);

	return datanodeSize + attrnodeSize; 
}
