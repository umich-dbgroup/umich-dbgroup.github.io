/*
COPYRIGHT  (c) 2000-2004 
THE REGENTS OF THE UNIVERSITY OF MICHIGAN
ALL RIGHTS RESERVED

PERMISSION IS GRANTED TO USE, COPY, CREATE DERIVATIVE WORKS AND
REDISTRIBUTE THIS SOFTWARE AND SUCH DERIVATIVE WORKS FOR NONCOMMERCIAL
EDUCATION AND RESEARCH PURPOSES, SO LONG AS NO FEE IS CHARGED, AND SO LONG
AS THE COPYRIGHT NOTICE ABOVE, THIS GRANT OF PERMISSION, AND THE
DISCLAIMER BELOW APPEAR IN ALL COPIES MADE; AND SO LONG AS THE NAME OF THE
UNIVERSITY OF MICHIGAN IS NOT USED IN ANY ADVERTISING OR PUBLICITY
PERTAINING TO THE USE OR DISTRIBUTION OF THIS SOFTWARE WITHOUT SPECIFIC,
WRITTEN PRIOR AUTHORIZATION.

THIS SOFTWARE IS PROVIDED AS IS, WITHOUT REPRESENTATION FROM THE
UNIVERSITY OF MICHIGAN AS TO ITS FITNESS FOR ANY PURPOSE, AND WITHOUT
WARRANTY BY THE UNIVERSITY OF MICHIGAN OF ANY KIND, EITHER EXPRESS OR
IMPLIED, INCLUDING WITHOUT LIMITATION THE IMPLIED WARRANTIES OF
MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE. THE REGENTS OF THE
UNIVERSITY OF MICHIGAN SHALL NOT BE LIABLE FOR ANY DAMAGES, INCLUDING
SPECIAL, INDIRECT, INCIDENTAL, OR CONSEQUENTIAL DAMAGES, WITH RESPECT TO
ANY CLAIM ARISING OUT OF OR IN CONNECTION WITH THE USE OF THE SOFTWARE,
EVEN IF IT HAS BEEN OR IS HEREAFTER ADVISED OF THE POSSIBILITY OF SUCH
DAMAGES.
*/

/**
 * @author Yuqing (Melanie) Wu
 */

#ifndef __DM_ElementNode_H
#define __DM_ElementNode_H

#include "DM_DataNode.h"

/**
* class DM_ElementNode
* 
* This class represent an element node in XML document.
* 
* @see DM_DataNode
* @see DM_DocumentNode
*/
class DM_ElementNode : public DM_DataNode  
{
public:
	/**
	* Constructor
	*
	* Set the node tag to be the element tag.
	* Initialize other variables with default value
	*
	* @param key The start key of the node
	* @param level The depth of the node
	* @param elementtag The element tag of the element node
	*/
	//DM_ElementNode(KeyType key, int level, char* elementtag);
    DM_ElementNode(KeyType key, short level, int elementtag);
	
	/**
	* Constructor
	* 
	* Construct an ElementNode using the information wrapped in a string
	*
	* @param buffer The string which contains the wrapped information about the element node. 
	*/
	DM_ElementNode(char* buffer);
	
	/**
	* Copy Constructor
	* Nuwee added: 07/14/03
	* Construct an ElementNode copied from another ElementNode
	*
	* @param elenode The source element node to copy
	*/
	DM_ElementNode(DM_ElementNode* elenode);

	/**
	* Default Destructor
	*/	
	virtual ~DM_ElementNode();

	/*----------------------------------------------------------*
	*		Access Methods										*
	*-----------------------------------------------------------*/

	/**
	* Access Method
	* Get the key of the attribute node which contains the attributes belonging to this element node
	* @returns The key of the attribute node
	*/
	KeyType getAttributes();

	/**
	* Access Method
	* Get the key of the first child of this element node.
	* @returns The key of the first child fo this element node.
	*/
	KeyType getFirstChild();

	/**
	* Access Method
	* Get the key of the last child of this element node
	* @returns The key of the last child fo this element ndoe
	*/
	KeyType getLastChild();

	/**
	* Access Method
	* Get the number of the children of this element node
	* @returns The number of the children fo this element ndoe
	*/
	int getChildNumber();

	/**
	* Access Method
	* Get the number of the attributes of this element node
	* @returns The number of the attributes fo this element ndoe
	*/
	short getAttributeNumber();

	/**
	 * @returns Returns true if the element node has any attributes associated with it. False otherwise.
	 *
	 */
	bool hasAttributes();

	/*----------------------------------------------------------*
	*		Set Methods											*
	*-----------------------------------------------------------*/

	/**
	* Set Method
	* Set the number of children for the element node
	* @param num The number of children of the element node.
	*/
	void setChildNumber(int num);

	/**
	* Set Method
	* Set the link to the first child
	* @param firstchild The key of the node which is the first child of this element node. 
	*/
	void setFirstChild(KeyType firstchild);

	/**
	* Set Method
	* Set the link to the last child
	* @param lastchild The key of the node which is the last child of this element node. 
	*/
	void setLastChild(KeyType lastchild);

	/**
	* Set Method
	* Set the Number of attributes belongs to this element node
	* @param num The number of attributse.
	*/
	void setAttrNumber(short num);

	/**
	* Set Method
	* Set the link to the attribute node which contains the attributes belonging to this element node
	* @param key The key of the attribute node
	*/
	void setAttributes(KeyType key);

	/*----------------------------------------------------------*
	*		Process Methods										*
	*-----------------------------------------------------------*/

	/**
	* Process method
	*
	* Insert a new child to the children list of the element.
	*
	* @param offset The offset of the child node.
	* @param child A point to the node to be added as child of this node.
	* @param prevsibling The previous sibling of the child node to be inserted. Its next sibling link will be changed after the insertion. 
	* @param nextsibling The next sibling of the child node to be inserted. Its previous sibling link will be changed after the insertion. 
	* @returns Error code
	*/
	int insertChild(int offset, DM_DataNode* child, DM_DataNode* prevsibling, DM_DataNode* nextsibling);

	/**
	* Process Method
	*
	* Append a node as the last child to this node. 
	* This is a special case of insert node. It can be doen by calling insertChild(this->childNum, child, this->lastChild, NULL).
	* However, since appendChild happens much more frequently than insertChild, it is coded separately to speed it up. 
	*
	* @param child The node to be appended as the last child to this node.
	* @param lastChild The current last child of this node. 
	* @returns Error code. 
	*/
	int appendChild(DM_DataNode* child, DM_DataNode* lastsibling);

	/**
	* Process Method
	* 
	* Delete a child node from this node
	* 
	* @param key The key of the node to be deleted.
	* @param prevSibling The previous sibling of the node to be deleted.
	* @param nextSibling The next sibling of the node to be deleted. 
	* @returns Error code. 
	*/
	int deleteChild(KeyType key, DM_DataNode* prevSibl, DM_DataNode* nextSibl);

	/**
	* Process Method
	*
	* Wrap the content of the node into a string
	* 
	* The output of this method is used to be stored into database
	*
	* @param bufLength The size of the string, which is the wrapping result (return value)
	* @returns A string that contains all the information of the node.
	*
	* @see DM_DataNode::wrapCommon()
	*/
	char* wrap(int* length);

	/**
	* Process Method
	*
	* Unwrap the content of the node from a string and restore the instance
	* 
	* @param buffer A string that contains all the information of the node
	*/
	void unwrap(char* buffer);

	/**
	* Process Method
	* 
	* This method compute the size of memory occupied by the node.
	* Note: this size is the size of the node in memory, not the record size in database.
	*
	* @returns The in-memory size of the node in bytes.
	*/
	int getNodeSize();

	/**
	* Debug Method
	* Print the content of the element, including the element tag, its attributes
	* and all its children (in forms of key), etc.
	*/
	void printValue();

protected:
	/**
	* The total number of nodes that are children of this element node
	*/
	int childNumber;

	/**
	* The total number of attribute (not attribute node, since all attributes are stored in one attribute node) 
	* belongs to this element node
	*/
	//int attrNumber;
    short attrNumber;
	
	/**
	* The key of the node which is the first child of the element node
	*/
	KeyType firstChild;
	
	/**
	* The key of the node which is the last child of the element node
	*/
	KeyType lastChild;
	
	/**
	* The key of the attribute node which contains all the attributes belonging to the element node
	*/
	KeyType attributes;	
};

#endif
