/*
COPYRIGHT  (c) 2000-2004 
THE REGENTS OF THE UNIVERSITY OF MICHIGAN
ALL RIGHTS RESERVED

PERMISSION IS GRANTED TO USE, COPY, CREATE DERIVATIVE WORKS AND
REDISTRIBUTE THIS SOFTWARE AND SUCH DERIVATIVE WORKS FOR NONCOMMERCIAL
EDUCATION AND RESEARCH PURPOSES, SO LONG AS NO FEE IS CHARGED, AND SO LONG
AS THE COPYRIGHT NOTICE ABOVE, THIS GRANT OF PERMISSION, AND THE
DISCLAIMER BELOW APPEAR IN ALL COPIES MADE; AND SO LONG AS THE NAME OF THE
UNIVERSITY OF MICHIGAN IS NOT USED IN ANY ADVERTISING OR PUBLICITY
PERTAINING TO THE USE OR DISTRIBUTION OF THIS SOFTWARE WITHOUT SPECIFIC,
WRITTEN PRIOR AUTHORIZATION.

THIS SOFTWARE IS PROVIDED AS IS, WITHOUT REPRESENTATION FROM THE
UNIVERSITY OF MICHIGAN AS TO ITS FITNESS FOR ANY PURPOSE, AND WITHOUT
WARRANTY BY THE UNIVERSITY OF MICHIGAN OF ANY KIND, EITHER EXPRESS OR
IMPLIED, INCLUDING WITHOUT LIMITATION THE IMPLIED WARRANTIES OF
MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE. THE REGENTS OF THE
UNIVERSITY OF MICHIGAN SHALL NOT BE LIABLE FOR ANY DAMAGES, INCLUDING
SPECIAL, INDIRECT, INCIDENTAL, OR CONSEQUENTIAL DAMAGES, WITH RESPECT TO
ANY CLAIM ARISING OUT OF OR IN CONNECTION WITH THE USE OF THE SOFTWARE,
EVEN IF IT HAS BEEN OR IS HEREAFTER ADVISED OF THE POSSIBILITY OF SUCH
DAMAGES.
*/

/**
 * @author Yuqing (Melanie) Wu
 */

#include "DM_ElementNode.h"
#include "DM_AttributeNode.h"
#include "../../Utilities/ErrorInfoClass.h"
extern ErrorInfoClass globalErrorInfo;

/**
* class DM_ElementNode
* 
* This class represent an element node in XML document.
* 
* @see DM_DataNode
* @see DM_DocumentNode
*/

/**
* Constructor
*
* Set the node tag to be the element tag.
* Initialize other variables with default value
*
* @param key The start key of the node
* @param level The depth of the node
* @param elementtag The element tag of the element node
*/
DM_ElementNode::DM_ElementNode(KeyType key,
							   short level, 
							   int elementtag) 
							   : DM_DataNode(key, ELEMENT_NODE, 
							   elementtag, level)
{
	this->childNumber = 0;
	this->firstChild = -1;
	this->lastChild = -1;
	this->attrNumber = 0;
	this->attributes = -1;
}

/**
* Constructor
* 
* Construct an ElementNode using the information wrapped in a string
*
* @param buffer The string which contains the wrapped information about the element node. 
*/
DM_ElementNode::DM_ElementNode(char* buffer) : DM_DataNode(KeyType(-1), ELEMENT_NODE, -1,-1)
{
	// this is done by unwrapping the information in the buffer. 
	unwrap(buffer);
}

/**
* Copy Constructor
* Added: 07/14/03
* Construct an ElementNode copied from another ElementNode
*
* @param elenode The source element node to copy
*/
DM_ElementNode::DM_ElementNode(DM_ElementNode* elenode) : DM_DataNode( (DM_DataNode*) elenode)
{
	this->attributes = elenode->attributes;
	this->attrNumber = elenode->attrNumber;
	this->childNumber = elenode->childNumber;
	this->firstChild = elenode->firstChild;
	this->lastChild = elenode->lastChild;
}

/**
* Default Destructor
*/
DM_ElementNode::~DM_ElementNode()
{
}

/*----------------------------------------------------------*
*		Access Methods										*
*-----------------------------------------------------------*/

/**
* Access Method
*
* Get the key of the attribute node which contains the attributes belonging to this element node
*
* @returns The key of the attribute node
*/
KeyType DM_ElementNode::getAttributes()
{
	return this->attributes;
}

/**
* Access Method
* Get the key of the first child of this element node.
* @returns The key of the first child fo this element node.
*/
KeyType DM_ElementNode::getFirstChild()
{
	if (this->childNumber == 0) return -1;
	else return this->firstChild;
}

/**
* Access Method
* Get the key of the last child of this element node
* @returns The key of the last child fo this element ndoe
*/
KeyType DM_ElementNode::getLastChild()
{
	if (this->childNumber == 0) return -1;
	else return this->lastChild;
}

/**
* Access Method
* Get the number of the children of this element node
* @returns The number of the children fo this element ndoe
*/
int DM_ElementNode::getChildNumber()
{
	return this->childNumber;
}

/**
* Access Method
* Get the number of the attributes of this element node
* @returns The number of the attributes fo this element ndoe
*/
short DM_ElementNode::getAttributeNumber()
{
	return this->attrNumber;
}

//AN: we should replace getAttributeNumber with hasAttributes(), since most people use
//getAttributeNumber() > 0 in their checks anyway.  if we keep the number of attributes
//with each element node, then if we modify an attribute node, we have to fetch the parent
//element node from the DB and update this number as well. with hasAttributes, we only need
//to modify the element node if an attribute node is deleted or inserted.
bool DM_ElementNode::hasAttributes()
{
	//return (this->attributes == -1);
	return this->attributes.isValid();
}

/*----------------------------------------------------------*
*		Set Methods											*
*-----------------------------------------------------------*/

/**
* Set Method
* Set the number of children for the element node
* @param num The number of children of the element node.
*/
void DM_ElementNode::setChildNumber(int num)
{
	this->childNumber = num;
}

/**
* Set Method
* Set the link to the first child
* @param firstchild The key of the node which is the first child of this element node. 
*/
void DM_ElementNode::setFirstChild(KeyType firstchild)
{
	this->firstChild = firstchild;
}

/**
* Set Method
* Set the link to the last child
* @param lastchild The key of the node which is the last child of this element node. 
*/
void DM_ElementNode::setLastChild(KeyType lastchild)
{
	this->lastChild = lastchild;
}

/**
* Set Method
* Set the Number of attributes belongs to this element node
* @param num The number of attributse.
*/
void DM_ElementNode::setAttrNumber(short num)
{
	this->attrNumber = num;
}

/**
* Set Method
* Set the link to the attribute node which contains the attributes belonging to this element node
* @param key The key of the attribute node
*/
void DM_ElementNode::setAttributes(KeyType key)
{
	this->attributes = key;
}

/*----------------------------------------------------------*
*		Process Methods										*
*-----------------------------------------------------------*/

/**
* Process method
*
* Insert a new child to the children list of the element.
*
* @param offset The offset of the child node.
* @param child A point to the node to be added as child of this node.
* @param prevsibling The previous sibling of the child node to be inserted. Its next sibling link will be changed after the insertion. 
* @param nextsibling The next sibling of the child node to be inserted. Its previous sibling link will be changed after the insertion. 
* @returns Error code
*/
int DM_ElementNode::insertChild(int offset, 
								DM_DataNode* child,
								DM_DataNode* prevsibling,
								DM_DataNode* nextsibling)
								 
{

	// we only allow user to insert node before the first child, right after last child, or between any
	// two existing child. any other offset is illegal for insertion. 
	if ((offset < 0) || (offset > this->childNumber)) 
    {
		globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"DM_ElementNode::insertChild",__FILE__,"Offset is illegal for insertion");
		return OFFSET_ERROR;
	}
	
	// set the parent link for the new child
	child->setParent(this->getKey());

	if (prevsibling != NULL)
	{
		// in case the previouse sibling is not NULL, need to change the next sibling link of the prevsibling. 
		child->setPrevSibling(prevsibling->getKey());
		prevsibling->setNextSibling(child->getKey());
	}
	else
		child->setPrevSibling(-1);

	if (nextsibling != NULL)
	{
		// in case the next sibling is not NULL, need to change the prev sibling link of the nextsibling. 
		child->setNextSibling(nextsibling->getKey());
		nextsibling->setPrevSibling(child->getKey());
	}
	else child->setNextSibling(-1);

	// increase the child number.
	this->childNumber++;

	if (offset == 0)
	{
		// if the new node is the first child of the node, set the firstchild link to point to it. 
		this->firstChild = child->getKey();
		if (this->childNumber == 1) this->lastChild = child->getKey();
	}

	if (offset == this->childNumber-1)
		this->lastChild = child->getKey();

	return NON_ERROR;
}

/**
* Process Method
*
* Append a node as the last child to this node. 
* This is a special case of insert node. It can be doen by calling insertChild(this->childNum, child, this->lastChild, NULL).
* However, since appendChild happens much more frequently than insertChild, it is coded separately to speed it up. 
*
* @param child The node to be appended as the last child to this node.
* @param lastChild The current last child of this node. 
* @returns Error code. 
*/
int DM_ElementNode::appendChild(DM_DataNode* child, DM_DataNode* lastchild)
{
	// change the parent link, the prevSibling link and the nextSiblingLink of the child node
	// to reflect the relationship of the node to this node. 
	child->setParent(this->key);
	child->setPrevSibling(this->lastChild);
	child->setNextSibling(-1);

	if (this->childNumber == 0)
		this->firstChild = child->getKey();
	else
	{
		// change the nextSibling link of the current last child, to reflect the relationship between
		// the current last child and the new node. 
		lastchild->setNextSibling(child->getKey());
	}

	// change the lastchild pointer of this node to point to the new node. 
	this->lastChild = child->getKey();

	this->childNumber++;

	// change the endkey of this node, to be larger than the endkey of the new node. 
	this->endKey = child->getEndKey() + 1;
	return 0;
}

/**
* Process Method
* 
* Delete a child node from this node
* 
* @param key The key of the node to be deleted.
* @param prevSibling The previous sibling of the node to be deleted.
* @param nextSibling The next sibling of the node to be deleted. 
* @returns Error code. 
*/
int DM_ElementNode::deleteChild(KeyType key, 
								DM_DataNode* prevSibl,
								DM_DataNode* nextSibl)
{
	if ((prevSibl == NULL) && (nextSibl == NULL))
		// if the prevSibling and the nextSibling are all NULL, this means the node to delete is the only
		// child of this node.
		if ((this->firstChild == key) && (this->lastChild == key))
		{
			// verify it. if it is true, delete the node by changing the childNumber to 0
			// and the pointer to first child and last child all to -1. 
			this->childNumber = 0;
			this->firstChild = -1;
			this->lastChild = -1;
			return NO_ERROR;
		}
		else
		{
			// if it turns out that the node to delete is not the only child of this node, report error. 
    		globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"DM_ElementNode::deleteChild",__FILE__,"Illegal deletion of child");
			return -1;
		}


	if (prevSibl == NULL)
	{
		// in case the node to be deleted is the first child of this node, 
		// need to reset the prevSibling link of its next Sibling, and the firstchild pointer of this node. 
		nextSibl->setPrevSibling(-1);
		this->firstChild = nextSibl->getKey();
	}
	else 
		// otherwise, reset the prevSibling link of the next sibling to cross the node to delete.
		if (nextSibl != NULL)
			nextSibl->setPrevSibling(prevSibl->getKey());

	if (nextSibl == NULL)
	{
		// in case the node to be deleted is the last child of this node, 
		// need to reset the nextSibling link of its previous Sibling, and the lastchild pointer of this node. 
		prevSibl->setNextSibling(-1);
		this->lastChild = prevSibl->getKey();
	}
	else 
		// otherwise, reset the nextSibling link of the previous sibling to cross the node to delete. 
		if (prevSibl != NULL)
			prevSibl->setNextSibling(nextSibl->getKey());

	this->childNumber--;

	return NO_ERROR;
}


/**
* Process Method
*
* Wrap the content of the node into a string
* 
* The output of this method is used to be stored into database
*
* @param bufLength The size of the string, which is the wrapping result (return value)
* @returns A string that contains all the information of the node.
*
* @see DM_DataNode::wrapCommon()
*/
char* DM_ElementNode::wrap(int* length)
{
	// the string produced for the common data of all node types.
	char* dataBuffer;
	int dataBufferLen;

	// the string produced by wrapping the information unique to the element node
	char* eleBuffer ;
	short eleBufferLen;

	// the output
	char* buffer;

	// wrap the common data defined in DM_DataNode
	dataBuffer = this->wrapCommon(&dataBufferLen);

	// wrap the fields that are defined in DM_ElementNode
	eleBufferLen = sizeof(DM_ElementNode) - sizeof(DM_DataNode);
	eleBuffer = new char[eleBufferLen];
	int cursor = 0;
	
	// child number
	memcpy(eleBuffer+cursor, &(this->childNumber), sizeof(int));
	cursor += sizeof(int);

	// attribute number
	memcpy(eleBuffer+cursor, &(this->attrNumber), sizeof(short));
	cursor += sizeof(short);

	// first child key
	memcpy(eleBuffer + cursor, &(this->firstChild), sizeof(KeyType));
	cursor += sizeof(KeyType);

	// last child key
	memcpy(eleBuffer + cursor, &(this->lastChild), sizeof(KeyType));
	cursor += sizeof(KeyType);

	// attribute node key
	memcpy(eleBuffer + cursor, &(this->attributes), sizeof(KeyType));
    cursor += sizeof(KeyType);
	eleBufferLen = (short) cursor;

	// combine the content in the two buffer, headed with the node type, and the length 
	// of the two parts
	(*length) = dataBufferLen + eleBufferLen + sizeof(char) + sizeof(int) + sizeof(short);

	buffer = new char[*length];
    // MEM INIT
    memset(buffer,0,*length);
	cursor = 0;

	// the node type
	memcpy(buffer+cursor, &(this->nodeFlag), sizeof(char));
	cursor += sizeof(char);

	// the length for common data
	memcpy(buffer+cursor, &dataBufferLen, sizeof(int));
	cursor += sizeof(int);

	// the length of the string for information unique in element node
	memcpy(buffer+cursor, &eleBufferLen, sizeof(short));
	cursor += sizeof(short);

	// the string for common data
	memcpy(buffer+cursor, dataBuffer, dataBufferLen);
	cursor += dataBufferLen;

	// the string for element node. 
	memcpy(buffer+cursor, eleBuffer, eleBufferLen);
	cursor += eleBufferLen;

	// release space allocated for intermediate results. 
	delete [] dataBuffer;
	delete [] eleBuffer;

	return buffer;
}

/**
* Process Method
*
* Unwrap the content of the node from a string and restore the instance
* 
* @param buffer A string that contains all the information of the node
*/
void DM_ElementNode::unwrap(char* buffer)
{
	int dataLen, eleLen;
	int cursor;

	// get the length of the two parts: common data in DataNode, and data for ElementNode only
	cursor = sizeof(char); // skip the first integer (node type)

	memcpy(&dataLen, buffer + cursor, sizeof(int));
	cursor += sizeof(int);

	memcpy(&eleLen, buffer + cursor, sizeof(short));
	cursor += sizeof(short);

	// unwrap the common data
	this->unwrapCommon(buffer + cursor);
	cursor += dataLen;

	// unwrap the data fields in ElementNode
	
	// child number
	memcpy(&(this->childNumber), buffer+cursor, sizeof(int));
	cursor += sizeof(int);

	// attribute number
	memcpy(&(this->attrNumber), buffer+cursor, sizeof(short));
	cursor += sizeof(short);

	// first child key
	memcpy(&(this->firstChild), buffer + cursor, sizeof(KeyType));
	cursor += sizeof(KeyType);

	// last child key
	memcpy(&(this->lastChild), buffer + cursor, sizeof(KeyType));
	cursor += sizeof(KeyType);

	// attribute node key
	memcpy(&(this->attributes), buffer + cursor, sizeof(KeyType));
	cursor += sizeof(KeyType);
}

/**
* Process Method
* 
* This method compute the size of memory occupied by the node.
* Note: this size is the size of the node in memory, not the record size in database.
*
* @returns The in-memory size of the node in bytes.
*/
int DM_ElementNode::getNodeSize()
{
	// the size of data in DM_DataNode
	int datanodeSize = sizeof(DM_DataNode) // the size of all field in the class
					//+ sizeof(int) + strlen(this->nodeTag) // for node tag
					- sizeof(char*) + this->historyLength; // for history

	// the size of data in DM_ElementNode
	int elenodeSize = sizeof(DM_ElementNode);

	return datanodeSize+elenodeSize;
}

/**
* Debug Method
* Print the content of the element, including the element tag, its attributes
* and all its children (in forms of key), etc.
*/
void DM_ElementNode::printValue()
{
	cout << "Element Node: Key = " << this->key.toString();
	cout << ", EndKey = " << this->endKey.toString() << endl;

	cout << "node tag = " << this->nodeTag << endl;
      
	cout << "	attribute number = " << this->attrNumber << endl;
	if (this->attrNumber > 0)
		cout << "	attribute node: Key = " << this->attributes.toString() << endl;
	cout << "	child number = " << this->childNumber << endl;
	if (this->childNumber > 0)
	{
		cout << "	first child key = " << this->firstChild.toString();
		cout << ", last child key = " << this->lastChild.toString() << endl;
	}

	cout << "	history length = " << this->historyLength << endl;
}
