/*
COPYRIGHT  (c) 2000-2004 
THE REGENTS OF THE UNIVERSITY OF MICHIGAN
ALL RIGHTS RESERVED

PERMISSION IS GRANTED TO USE, COPY, CREATE DERIVATIVE WORKS AND
REDISTRIBUTE THIS SOFTWARE AND SUCH DERIVATIVE WORKS FOR NONCOMMERCIAL
EDUCATION AND RESEARCH PURPOSES, SO LONG AS NO FEE IS CHARGED, AND SO LONG
AS THE COPYRIGHT NOTICE ABOVE, THIS GRANT OF PERMISSION, AND THE
DISCLAIMER BELOW APPEAR IN ALL COPIES MADE; AND SO LONG AS THE NAME OF THE
UNIVERSITY OF MICHIGAN IS NOT USED IN ANY ADVERTISING OR PUBLICITY
PERTAINING TO THE USE OR DISTRIBUTION OF THIS SOFTWARE WITHOUT SPECIFIC,
WRITTEN PRIOR AUTHORIZATION.

THIS SOFTWARE IS PROVIDED AS IS, WITHOUT REPRESENTATION FROM THE
UNIVERSITY OF MICHIGAN AS TO ITS FITNESS FOR ANY PURPOSE, AND WITHOUT
WARRANTY BY THE UNIVERSITY OF MICHIGAN OF ANY KIND, EITHER EXPRESS OR
IMPLIED, INCLUDING WITHOUT LIMITATION THE IMPLIED WARRANTIES OF
MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE. THE REGENTS OF THE
UNIVERSITY OF MICHIGAN SHALL NOT BE LIABLE FOR ANY DAMAGES, INCLUDING
SPECIAL, INDIRECT, INCIDENTAL, OR CONSEQUENTIAL DAMAGES, WITH RESPECT TO
ANY CLAIM ARISING OUT OF OR IN CONNECTION WITH THE USE OF THE SOFTWARE,
EVEN IF IT HAS BEEN OR IS HEREAFTER ADVISED OF THE POSSIBILITY OF SUCH
DAMAGES.
*/

/**
 * @author Yuqing (Melanie) Wu
 */

#ifndef __DM_CharNode_H
#define __DM_CharNode_H

#include "DM_DataNode.h"

/**
* class DM_CharNode
* 
* This class represent a node whose content is of string type.
* 
* @see DM_DataNode
* @see DM_TextNode
* @see DM_CommentNode
*/

class DM_CharNode : public DM_DataNode  
{
public:
	/**
	* Constructor
	*
	* Initialize the variable with the information given
	*
	* @param key The start key of the node
	* @param level The depth of the node
	* @param str The string value of the content of the node
	*/
	DM_CharNode(KeyType key, short level, const char* str);

	/**
	* Constructor
	* 
	* Create an instance of the DM_CharNode using the information wrapped in a string
	*
	*@param buffer The string which contains the information about the node, wrapped in a string
	* 
	*@see DM_CharNode::unwrap()
	*/	
	DM_CharNode(char* buffer);

	/**
	* Destructor
	* Free the space allocated for the string
	*/
	virtual ~DM_CharNode();

	/**
	* Access Method
	* Get the string value of the nodes
	*@returns The string which is the content of the node. 
	*/
	char* getCharValue();

	/**
	* Access Method for Multicolor
	* Added 06/23/2003
	* Get the key of the attribute node which contains the attributes belonging to this element node
	*
	* @returns The key of the attribute node
	*/
	KeyType getAttributes();

	/**
	* Set Method for Multicolor
	* Added 06/23/2003
	* Set the link to the attribute node which contains the attributes belonging to this element node
	* @param key The key of the attribute node
	*/
	void setAttributes(KeyType key);

	/**
	* Check Method for Multicolor
	* Added 06/29/2003
	* See whether it is part of multicolor semantics
	*/
	bool isPartOfMCT();
	
	/**
	* Process Method
	*
	* Wrap the content of the node into a string
	* 
	* The output of this method is used to be stored into database
	*
	* @param bufLength The size of the string, which is the wrapping result (return value)
	* @returns A string that contains all the information of the node.
	*
	* @see DM_DataNode::wrapCommon()
	*/
	char* wrap(int* length);

	/**
	* Process Method
	*
	* Unwrap the content of the node from a string and restore the instance
	* 
	* @param buffer A string that contains all the information of the node
	*/
	void unwrap(char* buffer);

	/**
	* Process Method
	* 
	* This method compute the size of memory occupied by the node.
	* Note: this size is the size of the node in memory, not the record size in database.
	*
	* @returns The in-memory size of the node in bytes.
	*/
	int getNodeSize();

	/**
	Process Method
	appends a string to the end of char value of the text node.
	@param str a string to appended.
	**/
	//void appendString(char *str);

protected:
	/**
	* The string value of the node
	*/
	char* charValue;

	/**
	* The length of the string value of the node
	*/
	int length;	

	/**
	* The key of the attribute node which contains all the multicolor info
	* Added 06/23/2003
	*/
	KeyType attributes;	
};

/**
* class DM_TextNode
*
* This class represent a node whose content is PCDATA type in the data structure 
*
* @see DM_CharNode
* @see DM_DataNode
*
* @author Yuqing Melanie Wu
* @version 1.0
*/
class DM_TextNode : public DM_CharNode
{
public: 
	/**
	* Constructor
	*
	* Initialize the variable with the information given
	*
	* @param key The start key of the node
	* @param level The depth of the node
	* @param text The string value of the content of the node
	*/
	DM_TextNode(KeyType key, short level, const char* text);

	/**
	* Constructor
	* 
	* Construct a TextNode using the information wrapped in a string
	*
	* @param buffer The string which contains the wrapped information about the text node. 
	*/
	DM_TextNode(char* buffer);

	/**
	* Default Destructor
	*/
	virtual ~DM_TextNode();

	/**
	* Debug Method
	* Print the string value of the node
	*/
	void printValue();
};

/**
* Class DM_CommentNode
* 
* This class represent a piece of comment in the XML document.
*
* @author Yuqing Melanie Wu
* @version 1.0
* 
* @see DM_CharNode
* @see DM_DataNode
*/
class DM_CommentNode : public DM_CharNode
{
public: 
	/**
	* Constructor
	*
	* Initialize the variable with the information given.
	*
	* @param key The start key of the node
	* @param level The depth of the node
	* @param comment The string value of the content of the node
	*/
	DM_CommentNode(KeyType key, short level, const char* comment);
	
	/**
	* Constructor
	* 
	* Construct a CommentNode using the information wrapped in a string
	*
	* @param buffer The string which contains the wrapped information about the comment node. 
	*/
	DM_CommentNode(char* buffer);

	/**
	* Default Destructor
	*/
	virtual ~DM_CommentNode();

	/**
	* Debug Method
	* Print the string value of the node
	*/
	void printValue();
};

#endif
