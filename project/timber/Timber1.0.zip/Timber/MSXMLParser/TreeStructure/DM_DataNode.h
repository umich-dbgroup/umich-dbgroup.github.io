/*
COPYRIGHT  (c) 2000-2004 
THE REGENTS OF THE UNIVERSITY OF MICHIGAN
ALL RIGHTS RESERVED

PERMISSION IS GRANTED TO USE, COPY, CREATE DERIVATIVE WORKS AND
REDISTRIBUTE THIS SOFTWARE AND SUCH DERIVATIVE WORKS FOR NONCOMMERCIAL
EDUCATION AND RESEARCH PURPOSES, SO LONG AS NO FEE IS CHARGED, AND SO LONG
AS THE COPYRIGHT NOTICE ABOVE, THIS GRANT OF PERMISSION, AND THE
DISCLAIMER BELOW APPEAR IN ALL COPIES MADE; AND SO LONG AS THE NAME OF THE
UNIVERSITY OF MICHIGAN IS NOT USED IN ANY ADVERTISING OR PUBLICITY
PERTAINING TO THE USE OR DISTRIBUTION OF THIS SOFTWARE WITHOUT SPECIFIC,
WRITTEN PRIOR AUTHORIZATION.

THIS SOFTWARE IS PROVIDED AS IS, WITHOUT REPRESENTATION FROM THE
UNIVERSITY OF MICHIGAN AS TO ITS FITNESS FOR ANY PURPOSE, AND WITHOUT
WARRANTY BY THE UNIVERSITY OF MICHIGAN OF ANY KIND, EITHER EXPRESS OR
IMPLIED, INCLUDING WITHOUT LIMITATION THE IMPLIED WARRANTIES OF
MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE. THE REGENTS OF THE
UNIVERSITY OF MICHIGAN SHALL NOT BE LIABLE FOR ANY DAMAGES, INCLUDING
SPECIAL, INDIRECT, INCIDENTAL, OR CONSEQUENTIAL DAMAGES, WITH RESPECT TO
ANY CLAIM ARISING OUT OF OR IN CONNECTION WITH THE USE OF THE SOFTWARE,
EVEN IF IT HAS BEEN OR IS HEREAFTER ADVISED OF THE POSSIBILITY OF SUCH
DAMAGES.
*/

/**
 * @author Yuqing (Melanie) Wu
 */

#ifndef __DM_DataNode_H
#define __DM_DataNode_H

#include "TreeStructure_definitions.h"
#include "Value.h"
#include "../../PhysicalDataMng/SystemCatalog/XMLNameTable.h"

// define the node types. 
#define DOCUMENT_NODE	0x00
#define ELEMENT_NODE	0x01
#define ATTRIBUTE_NODE	0x02
#define TEXT_NODE		0x03
#define COMMENT_NODE	0x04
#define CHAR_NODE		0x05

// define error codes in node operation
#define NON_ERROR				0
#define VALUE_TYPE_NOT_DEFINE	1
#define OFFSET_ERROR			2
#define ATTR_EXIST				3

/**
* class DM_DataNode
* This class represent the basic data structure (node). It is the base class for all 
* node types in Timber:
*
* @see DM_ElementNode
* @see DM_DocumentNode
* @see DM_CharNode
* @see DM_AttributeNode
* @see DM_TextNode
* @see DM_CommentNode
*/

class DM_DataNode  
{
public:
	/**
	* Constructor
	*
	* Initialize the variables with the information provides
	* Set the other variables with default value.
	*
	* @param key The start key of the node
	* @parem nodeflag The Type of node
	* @param nodetag The tag of the node
	* @param level The depth of the node
	*/
	//DM_DataNode(KeyType key, int nodeflag, char* nodetag, int level);
    DM_DataNode(KeyType key, char nodeflag, int nodetag, short level);

	/**
	* Copy Constructor
	* Nuwee added: 07/14/03
	* Construct a DataNode copied from another DataNode
	*
	* @param elenode The source element node to copy
	*/
	DM_DataNode(DM_DataNode* node);
	/**
	* Default Destructor
	* Release the space occupied.
	*/
	virtual ~DM_DataNode();

	/*----------------------------------------------------------*
	*		Access Methods										*
	*-----------------------------------------------------------*/

	/**
	* Access Method
	* Get the key (start position) of the node.
	* 
	* @returns The key of the node
	*/
	KeyType getKey();

	/**
	* Access Method
	* Get the endkey (end position) of the node
	* @returns The endkey (end position) of the node
	*/
	KeyType getEndKey();

	/**
	* Access Method
	* Get the depth of the node
	* @returns The depth of the node
	*/
	//int getLevel();
	short getLevel();

	/**
	* Access Method
	* Get the node type
	* @returns The type of the node
	*/
	//int getFlag();
    char getFlag();

	/**
	* Access Method
	* Get the node tag 
	* @returns The node tag of the node
	*/
	char* getTag(XMLNameTable *nameTable);
    int getTag();

	/**
	* Access Method
	* Get parent link 
	* @returns The key of the parent of this node. -1 if this node does not have a parent.
	*/
	KeyType getParent();                 

	/**
	* Access Method
	* Get sibling link
	* @returns The key of the previous sibling of this node. -1 if this node is the first child of its parent.
	*/
	KeyType getPrevSibling();                   

	/**
	* Access Method
	* Get sibling link
	* @returns The key of the next sibling of this node. -1 if this node is the last child of its parent.
	*/
	KeyType getNextSibling();

	/**
	* Access Method
	* Get the number of descendants of the node
	* @returns The number of descendants of the node
	*/
	//int getDescNumber();

	/**
	* Access Method
	* Get the depth of the node
	* @returns The depth of the node
	*/
	//int getDescendantDepth();
	short getDescendantDepth();

	/* 
	* Access Method
	* Get the history field
	* @returns The history field
	*/
	char* getHistory();

	/* 
	* Access Method
	* Get the length of the history field
	* @returns The length of the history field
	*/
	int getHistoryLength();

	/**
	* Access Method
	* Find out whether the history field has any content
	* @returns A boolean value which indicates whether the history field is empty or not.
	*/
	bool hasHistory();

	/**
	* Access Method
	* Find out whether the node is a leaf node.
	* @returns A boolean value which indicates whether the node is a leaf node or not.
	*/
	bool isLeafNode();

	/**
	* Access Method
	* Get the number of children of this  node
	* Valid only when the node is ELEMENT_NODE or DOCUMENT_NODE:
	* @returns The number of children of this node.
	*/
	int getChildNumber();

	/**
	* Access Method
	* Get the number of attributes in this  ode
	* Valid only when the node is ELEMENT_NODE or ATTRIBUTE_NODE
	* @returns The number of attributes of this node. -1 if the node type is not valid for this access method. 
	*/
	short getAttributeNumber();

	/**
	* Access Method
	* Get the key of the first child of this node.
	* Valid only when the node is ELEMENT_NODE or DOCUMENT_NODE:
	* @returns The key of the first child fo this ndoe
	*/
	KeyType getFirstChild();

	/**
	* Access Method
	* Get the key of the last child of this node
	* Valid only when the node is ELEMENT_NODE or DOCUMENT_NODE:
	* @returns THe key of the last child fo this ndoe
	*/
	KeyType getLastChild();

	/*----------------------------------------------------------*
	*		Set Methods											*
	*-----------------------------------------------------------*/

	/**
	* Set Method
	* Set the Node Type
	* @param flag The new node type for the node
	*/
	//void setFlag(int flag);
	void setFlag(char flag);

	/**
	* Set Method
	* Set the node tag
	* @param nodetag The new node tag for the node
	*/
	//void setTag(char* nodetag);
    void setTag(int nodetag);

	/**
	* Set Method
	* Set the key value
	* @param key The new key value for the node
	*/
	void setKey(KeyType key);

	/**
	* Set Method
	* Set the endkey (end position) of the node
	* @param endkey The new endkey (end position) of the node
	*/
	void setEndKey(KeyType endkey);

	/**
	* Set Method
	* Set the level (depth) of the node
	* @param endkey The new level of the node
	*/
	//void setLevel(int level);
	void setLevel(short level);

	/**
	* Set Method
	* Set the number of descendant of the node
	* @param descnum The new number of descendants of this node.
	*/
	//void setDescNumber(int descnum);

	/**
	* Set Method
	* Set the parent link
	* @param parent The key of the parent node
	*/
	void setParent(KeyType parent);

	/**
	* Set Method
	* Set the Sibling link
	* @param presibling The key of the previous sibling of the node
	*/
	void setPrevSibling(KeyType prevsibling);

	/**
	* Set Method
	* Set the Sibling link
	* @param nextsibling The key of the next sibling of the node
	*/
	void setNextSibling(KeyType nextsibling);

	/**
	* Set Method
	* Set the descendant depth, which is the height of the subtree rooted at the node.
	* @param depth The height of the subtree rooted at the node.
	*/
	//void setDescendantDepth(int depth);
	void setDescendantDepth(short depth);

	/**
	* Set Method
	* Set value to the history field of the node.
	* @param length The length of the history value.
	* @param history The history, which is a string (memory block) of the length given, which contains the history information about the node.
	*/
	void setHistory(int length, char* history);

	/*----------------------------------------------------------*
	*		Process Methods										*
	*-----------------------------------------------------------*/

	/**
	* Process Method
	* Wrap the content of the DM_DataNode into a string. These are the common fields of all nodes.
	* 
	* Data to be wraped up for every DM_DataNode include
	* 1. key
	* 2. endkey
	* 3. node flag (type)
	* 4. node tag length
	* 5. node tag
	* 6. level
	* 7. parent key
	* 8. previous sibling key
	* 9. next sibling key
	* 10. descendant number
	* 11. descendant depth
	* 12. history length
	* 13. history (if history field has content)
	*
	* @param length The length of the string generated (return value).
	* @returns A string that contains all the information of the node.
	*/
	char* wrapCommon(int* length);

	/**
	* Process Method
	* unwrap the content of the DM_DataNode from a string. These fields are the common fields for nodes of all types.
	*
	* Data to be unwraped up for every DM_DataNode include:
	* 1. key
	* 2. endkey
	* 3. node flag (type)
	* 4. node tag length
	* 5. node tag
	* 6. level
	* 7. parent key
	* 8. previous sibling key
	* 9. next sibling key
	* 10. descendant number
	* 11. descendant depth
	* 12. history length
	* 13. history (if history field has content)
	*
	* @param buffer A string that contains all the information of the node
	*/
	void unwrapCommon(char* buffer);

	/**
	* Process Method
	* unwrap the content of the node from a string. 
	*
	* The node type is detected and the unwrap function of each such class is called
	* to unwrap the string. 
	* 
	* @param buffer A string that contains all the information of the node
	* @returns A pointer to the node unwrapped from the string
	*/
	static DM_DataNode* unwrap(char* buffer);



   /**
	* check to see if this node is an ancestor of potentialDescendant node.
	* @param potentialDescendant is a node that we will be checking to see if it is a desc of this node.
	* @returns true if this node is an ancestor of potentialDescendant node.
	*/
    bool isAncestorOf(DM_DataNode *potentialDescendant);

	/**
	* check to see if this node is a descendant of potentialAncestor node.
	* @param potentialAncestor is a node that we will be checking to see if it is an ancs of this node.
	* @returns true if this node is a descendant of potentialAncestor node.
	*/
    bool isDescendantOf(DM_DataNode *potentialAncestor);

	/**
	* check to see if this node is a parent of potentialChild node.
	* @param potentialChild is a node that we will be checking to see if it is a child of this node.
	* @returns true if this node is a parent of potentialChild node.
	*/
    bool isParentOf(DM_DataNode *potentialChild);

	/**
	* check to see if this node is a child of potentialParent node.
	* @param potentialParent is a node that we will be checking to see if it is a parent of this node.
	* @returns true if this node is a child of potentialParent node.
	*/
    bool isChildOf(DM_DataNode *potentialParent);


	/*----------------------------------------------------------*
	*		Virtual Methods										*
	*-----------------------------------------------------------*/

	// wrap the node into a string
	virtual char* wrap(int* length) {length = length; return NULL;}

	// get the node size (used for buffer management
	virtual int getNodeSize() {return 0;}

	// print the information of the node
	virtual void printValue() {}

protected: // do NOT change the sequence of the member variables -- optimally aligned
	/**
	* An ID assign to the node
	*
	* Each node is assigned a unique key, which indicate the position of the node 
	* in the tree (left-deep order).
	*/
	KeyType key;

	/**
	* A number assign to the node
	* 
	* This number is assigned to be at least as large as its key, and is larger than
	* the end keys of all its descendants.
	* 
	* It differs from key only for ElementNode and DocumentNode
	* For all other type of node, endKey is the same as key.
	*/
	KeyType endKey;

	/**
	* The depth of the node in the tree structure.
	* Root node has level 0.
	*/
	//int level;
    short level;

	/**
	* Indicate what kind of node it is.
	* 
	* Value can be: 
	* DOCUMENT_NODE, ELEMENT_NODE, ATTRIBUTE_NODE, TEXT_NODE, COMMENT_NODE, CHAR_NODE.
	*/
	//int nodeFlag;
    char nodeFlag;

	/**
	* This field is used for view maintainment (by Andrew Nierman). He is in charge of wrap the
	* information he would use into a string and stored in this field
	* and in charge of its interpretation. 
	*/
	char* history;

	/**
	* the length of the history field. if it it 0, it indicates that the history field is
	* empty;
	*/
	int historyLength;

	/**
	* Node tag is the name of the node,
	* 
	* for document, it is document file name
	* for element, it is start tag
	* for attribute, it is the name of parent element
	*/
	//char nodeTag[MAX_NODETAG_LENGTH]; 
    int nodeTag;
	
	/**
	* The key of the parent node of this node.
	*/
	KeyType parent;

	/**
	* A key to the node that has the same parent as this node and is right in front of 
	* this node in order sementics.
	*/
	KeyType prevSibling;

	/**
	* A key to the node that has the same parent as this node and is right after
	* this node in order sementics.
	*/
    KeyType nextSibling;

	/**
	* The number of descendants of this node.
	*/
	//int descNumber;

	/**
	* The height of the subtree rooted at this node. 
	*/
	//int descendantDepth;
    short descendantDepth;

	/**
	* Process Method
	* Used for wraping a vchar to a buffer, by storing the length and the content of the string.
	*
	*@param buffer The buffer to write to. (return value)
	*@param str The string to wrap
	*@param length The length of the string (since the char* to be wrapped maybe a memory block, rather than a string).
	*@return the size that has been writting to the buffer;
	*/
	int wrapString(char* buffer, char* str, int length);

	/**
	* Process Method
	* Used for unwrapping a vchar, by getting its length, allocate memory, and copy the string from buffer
	*
	*@param  buffer The buffer to read from
	*@param  targetStr The place where the unwrapped string should go
	*@returns The length of buffer (in bytes) has been consumed by the unwrapped string. 
	*/
	int unwrapString(char* buffer, char* target);

	//hack until we change other unwrapString calls to not be using fixed size arrays:
	//int unwrapStringAlloc(char* buffer, char** target);
};

#endif
