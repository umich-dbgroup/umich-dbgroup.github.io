/*
COPYRIGHT  (c) 2000-2004 
THE REGENTS OF THE UNIVERSITY OF MICHIGAN
ALL RIGHTS RESERVED

PERMISSION IS GRANTED TO USE, COPY, CREATE DERIVATIVE WORKS AND
REDISTRIBUTE THIS SOFTWARE AND SUCH DERIVATIVE WORKS FOR NONCOMMERCIAL
EDUCATION AND RESEARCH PURPOSES, SO LONG AS NO FEE IS CHARGED, AND SO LONG
AS THE COPYRIGHT NOTICE ABOVE, THIS GRANT OF PERMISSION, AND THE
DISCLAIMER BELOW APPEAR IN ALL COPIES MADE; AND SO LONG AS THE NAME OF THE
UNIVERSITY OF MICHIGAN IS NOT USED IN ANY ADVERTISING OR PUBLICITY
PERTAINING TO THE USE OR DISTRIBUTION OF THIS SOFTWARE WITHOUT SPECIFIC,
WRITTEN PRIOR AUTHORIZATION.

THIS SOFTWARE IS PROVIDED AS IS, WITHOUT REPRESENTATION FROM THE
UNIVERSITY OF MICHIGAN AS TO ITS FITNESS FOR ANY PURPOSE, AND WITHOUT
WARRANTY BY THE UNIVERSITY OF MICHIGAN OF ANY KIND, EITHER EXPRESS OR
IMPLIED, INCLUDING WITHOUT LIMITATION THE IMPLIED WARRANTIES OF
MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE. THE REGENTS OF THE
UNIVERSITY OF MICHIGAN SHALL NOT BE LIABLE FOR ANY DAMAGES, INCLUDING
SPECIAL, INDIRECT, INCIDENTAL, OR CONSEQUENTIAL DAMAGES, WITH RESPECT TO
ANY CLAIM ARISING OUT OF OR IN CONNECTION WITH THE USE OF THE SOFTWARE,
EVEN IF IT HAS BEEN OR IS HEREAFTER ADVISED OF THE POSSIBILITY OF SUCH
DAMAGES.
*/

/**
 * @author Yuqing (Melanie) Wu
 */

#ifndef __DM_AttributeNode_H
#define __DM_AttributeNode_H

#include "DM_DataNode.h"

/**
* class DM_AttibuteNode
* 
* This class represent an Attribute in the data structure which we are going to store into Shore
* 
* @see DM_DataNode
* @see DM_ElementNode
*/
class DM_AttributeNode : public DM_DataNode  
{
public:
	/**
	* Constructor
	* Initialize the variables with the information given
	*
	* @param key The start key of the node. 
	* @param level The depth of the node
	* @param num The number of attributes to be stored in this node.
	* @param names A list of attribute names
	* @param values A list of attribute values
	* @param parent The key of the element node which has these attributes
	*/
	DM_AttributeNode(KeyType key, short level, short num, char** names, Value** values, KeyType parent); 

	/**
	* Constructor for Multicolor
	* Initialize the variables with the information given
	* Allocate attributes for colors info
	*
	* @param key The start key of the node. 
	* @param level The depth of the node
	* @param num The number of attributes to be stored in this node. (including bogus multicolor attribute)
	* @param realnum The real number of attributes to be stored in this node
	* @param names A list of attribute names
	* @param values A list of attribute values
	* @param numcolor The number of colors this node is painted
	* @param parent The key of the element node which has these attributes
	*/
	DM_AttributeNode(KeyType key, short level, short num, short realnum, char** names, 
                     Value** values, int numcolor, KeyType parent); 

	/**
	* Constructor
	* 
	* Create an instance of the DM_AttributeNode using the information wrapped in a string
	*
	*@param buffer The string which contains the information about the node, wrapped in a string
	* 
	*@see DM_AttributeNode::unwrap()
	*/	
	DM_AttributeNode(char* buffer); 

	/**
	* Destructor
	* Free space allocated for names and values
	*/
	virtual ~DM_AttributeNode();

	/**
	* Access Method
	* Get the total number of attributes in the node
	* @returns the total number of attributes in the node
	*/
	short getAttributeNumber();

	/**
	* Access Method
	* Get the name and value of the attribute with the given index
	*
	* @param index The position of the attribute whose information is required
	* @param name The name of the attribute (return value)
	* @returns The value of the attribute
	*/
	Value* getAttr(short index, char* &name);

	/**
	* Access Method
	* Get the names and values of all the attributes in the node
	*
	* @param attrname The name of an attribute whose value we are looking for
	* @returns The value of the attribute with given name, NULL if no attribute has the name in the node
	*/
	Value* getAttr(const char* name);

	/**
	* Access Method
	* Get the values of an attribute in the node with the given index
	*
	* @param ndex The position of the attribute whose information is required
	* @returns The value of the attribute with given index, NULL if no attribute has the index in the node
	*/
	Value* getAttrAt(short index);

	/**
	* Set the Value for an attribute.
	*
	* @param attrname The name of the attribute whose value we would like to change.
	* @param value The new value for attribute attrname.  value should be non-NULL.
	* @returns Returns the index of the attribute that had its value replaced,
	* or -1 if the attribute with attrname was not found.
	*/
	int setAttrValue(char* attrname, Value* value);

	/**
	 * Insert a new attribute and value.
	 *
	 * @param attributeName The name for the new attribute.
	 * @param value The value for the new attribute.
	 * @returns Returns -1 if an attribute with attributeName already exists,
	 * otherwise the number of attributes (after the insert) is returned.
	 */
	int insertAttribute(const char *attributeName, Value* value);

	/**
	* Access Method
	* Get the name of the index'th attribute.
	* 
	* @param index The position of the attribute whose information is required
	* @returns The name of the attribute at that position.
	*/
	char* getAttributeNameAt(short index);

	/**
	* Access Method
	* Find out whether there is an attribute in this attribute node with the name given.
	* 
	* @param attrname The attribute name which it is looked for.
	* @returns A boolean value which indicate whether an attribute with the given name exists in the node.
	*/
	bool hasAttributeWithName(const char* name);

	/**
	* Access Method for Multicolor
	* Added 06/29/2003
	* Get sibling link
	* @param parentkey The key of the parent node
	* @param textnodekey The key of the text node in consideration
	* @returns The key of the previous sibling of this node. -1 if this node is the first child of its parent.
	*/
	KeyType getMCTPrevSibling(KeyType parentkey, KeyType textnodekey);                   

	/**
	* Access Method for Multicolor
	* Added 06/29/2003
	* Get sibling link
	* @param parentindex The index of the parent node
	* @param textindex The index of the text node in consideration
	* @returns The key of the previous sibling of this node. -1 if this node is the first child of its parent.
	*/
	KeyType getMCTPrevSibling(int parentindex, int textindex);  

	/**
	* Access Method for Multicolor
	* Added 06/29/2003
	* Get sibling link
	* @param parentkey The key of the parent node
	* @param textnodekey The key of the text node in consideration
	* @returns The key of the next sibling of this node. -1 if this node is the last child of its parent.
	*/
	KeyType getMCTNextSibling(KeyType parentkey, KeyType textnodekey);

	/**
	* Access Method for Multicolor
	* Added 06/29/2003
	* Get sibling link
	* @param parentindex The index of the parent node
	* @param textindex The index of the text node in consideration
	* @returns The key of the next sibling of this node. -1 if this node is the last child of its parent.
	*/
	KeyType getMCTNextSibling(int parentindex, int textindex);

	/**
	* Access Method for Multicolor
	* Added 07/06/2003
	* Get number of color numbers/ parent numbers
	* @returns mctNum
	*/
	int getMCTNum();

	/**
	* Access Method for Multicolor
	* Added 07/06/2003
	* Get number of text node associated with the multiclor elements
	* @returns textNum
	*/
	int getMCTTextNum();

	/**
	* Access Method for Multicolor
	* Added 06/30/2003
	* Get parent key for given index
	* @param index The position of the color
	* @returns The key of the parent for that position
	*/
	KeyType getParent(int index);

	/**
	* Access Method for Multicolor
	* Added 07/22/2003
	* Get index (position) of given parent key
	* @param parentkey The key of parent node
	* @returns The position indexed in attribute node
	*/
	int getParentIndex(KeyType parentkey);

	/**
	* Access Method for Multicolor
	* Added 07/22/2003
	* Get index (position) of given text key
	* @param textkey The key of the text node
	* @returns The position indexed in attribute node
	*/
	int getTextIndex(KeyType textkey);

	/**
	* Access Method for Multicolor
	* Added 06/30/2003
	* Get all parent keys of this multicolor elements
	* @param parents The returned array of parents key
	* @returns Number of parents key
	*/
	int getAllParents(KeyType* parents);

	/**
	* Access Method for Multicolor
	* Added 07/22/2003
	* Add 1 parent associated with multicolor
	* @param parent The key of the parent to be added
	* @returns The index the parent is located
	*/
	int addMCTParent(KeyType parent);

	/**
	* Access Method for Multicolor
	* Added 07/22/2003
	* Add 1 text node associated with multicolor
	* @param parent The key of the text to be added
	* @returns The index the text is located
	*/
	int addMCTTextNode(KeyType textkey);

	/**
	* Access Method for Multicolor
	* Added 06/29/2003
	* Set the sibling link at the parent and text position
	* @param textindex The index of the text node in consideration
	* @param parentindex The index of the parent node
	* @prevsibling The key of the prev sibling.
	*/
	void setMCTPrevSibling(int textindex, int parentindex, KeyType prevsibling);

	/**
	* Access Method for Multicolor
	* Added 06/29/2003
	* Set the sibling link at the parent and text position
	* @param textindex The index of the text node in consideration
	* @param parentindex The index of the parent node
	* @nextsibling The key of the next sibling.
	*/
	void setMCTNextSibling(int textindex, int parentindex, KeyType nextsibling);

	/**
	* Debug Method
	* Print the content of the node (the name and value of each attribute)
	*/
	void printValue();
	
	/**
	* Process Method
	*
	* Wrap the content of the node into a string
	* 
	* The output of this method is used to be stored into database
	*
	* @param bufLength The size of the string, which is the wrapping result (return value)
	* @returns A string that contains all the information of the node.
	*
	* @see DM_DataNode::wrapCommon()
	*/
	char* wrap(int* size);

	/**
	* Process Method
	*
	* Unwrap the content of the node from a string and restore the instance
	* 
	* @param buffer A string that contains all the information of the node
	*/
	void unwrap(char* buffer);

	/**
	* Process Method
	* 
	* This method compute the size of memory occupied by the node.
	* Note: this size is the size of the node in memory, not the record size in database.
	*
	* @returns The in-memory size of the node in bytes.
	*/
	int getNodeSize();

private:
	/**
	* Total number of attributes in the node
	*/
	short attrNum;
	
	/**
	* A list of names for the attributes
	*/
	char** attrNames;
	//char attrNames[MAX_ATTRIBUTE_NUMBER][MAX_ATTRIBUTE_NAME_LENGTH];
	
	/**
	* A list of values of the attributes
	*/
	Value** attrValues;

	/**
	* For multicolor
	* Added: 06/23/2003
	* Actual number of colors, or parents of this attribute node (less one (primary)???)
	*/
	int mctNum;

	/**
	* For multicolor
	* Added: 06/23/2003
	* A list of parent key (other than the primary one???)
	*/
	KeyType mctParents[MAX_COLOR_NUMBER];

	/**
	* For multicolor
	* Added: 06/29/2003
	* Actual number of text node (include comment node)
	*/
	int textNum;

	/**
	* For multicolor
	* Added: 06/29/2003
	* A list of text node key for particular mulicolored element
	*/
	KeyType mctTextNode[MAX_TEXT_NUMBER];

	/**
	* For multicolor
	* Added: 06/23/2003
	* A list of nextSibling key
	*/
	KeyType mctNextSibling[MAX_TEXT_NUMBER][MAX_COLOR_NUMBER];

	/**
	* For multicolor
	* Added: 06/23/2003
	* A list of prevSibling key
	*/
	KeyType mctPrevSibling[MAX_TEXT_NUMBER][MAX_COLOR_NUMBER];

};

#endif
