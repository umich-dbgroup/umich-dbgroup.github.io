/*
COPYRIGHT  (c) 2000-2004 
THE REGENTS OF THE UNIVERSITY OF MICHIGAN
ALL RIGHTS RESERVED

PERMISSION IS GRANTED TO USE, COPY, CREATE DERIVATIVE WORKS AND
REDISTRIBUTE THIS SOFTWARE AND SUCH DERIVATIVE WORKS FOR NONCOMMERCIAL
EDUCATION AND RESEARCH PURPOSES, SO LONG AS NO FEE IS CHARGED, AND SO LONG
AS THE COPYRIGHT NOTICE ABOVE, THIS GRANT OF PERMISSION, AND THE
DISCLAIMER BELOW APPEAR IN ALL COPIES MADE; AND SO LONG AS THE NAME OF THE
UNIVERSITY OF MICHIGAN IS NOT USED IN ANY ADVERTISING OR PUBLICITY
PERTAINING TO THE USE OR DISTRIBUTION OF THIS SOFTWARE WITHOUT SPECIFIC,
WRITTEN PRIOR AUTHORIZATION.

THIS SOFTWARE IS PROVIDED AS IS, WITHOUT REPRESENTATION FROM THE
UNIVERSITY OF MICHIGAN AS TO ITS FITNESS FOR ANY PURPOSE, AND WITHOUT
WARRANTY BY THE UNIVERSITY OF MICHIGAN OF ANY KIND, EITHER EXPRESS OR
IMPLIED, INCLUDING WITHOUT LIMITATION THE IMPLIED WARRANTIES OF
MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE. THE REGENTS OF THE
UNIVERSITY OF MICHIGAN SHALL NOT BE LIABLE FOR ANY DAMAGES, INCLUDING
SPECIAL, INDIRECT, INCIDENTAL, OR CONSEQUENTIAL DAMAGES, WITH RESPECT TO
ANY CLAIM ARISING OUT OF OR IN CONNECTION WITH THE USE OF THE SOFTWARE,
EVEN IF IT HAS BEEN OR IS HEREAFTER ADVISED OF THE POSSIBILITY OF SUCH
DAMAGES.
*/

/**
 * @author Yuqing (Melanie) Wu
 */

#include "DM_DocumentNode.h"

/**
* class DM_DocumentNode
* 
* This class represent the root node of an XML document.
* 
* @see DM_DataNode
* @see DM_ElementNode
*/

/**
* Constuctor
* Initialize the variables with information given
* @param key The start key of the node
* @param level The depth of the node
* @param docname Name of the XML document
* @param path Path of the XML document
*/
DM_DocumentNode::DM_DocumentNode(KeyType key,
								 short level, 
								 char* docname, 
								 char* path) 
								 : DM_ElementNode(key, level, -1) 
{
	this->nodeFlag = DOCUMENT_NODE;

	strcpy(this->fileName, docname);
	strcpy(this->filePath, path);
	
	DTDFileName[0] = '\0';
	DTDPath[0] = '\0';
}

/**
* Constructor
* 
* Create an instance of the DM_DocumentNode using the information wrapped in a string
*
*@param buffer The string which contains the information about the node, wrapped in a string
* 
*@see DM_DocumentNode::unwrap()
*/
DM_DocumentNode::DM_DocumentNode(char* buffer) : DM_ElementNode(-1,-1,-1)
{
	this->childNumber = 1;
	this->attributes = -1;
	this->attrNumber = 0;

	unwrap(buffer);
}

/**
* Default Destructor
*/
DM_DocumentNode::~DM_DocumentNode()
{
}

/**
* Access Method
* Get the file name of the XML document
* @returns The file name of the XML document
*/
char* DM_DocumentNode::getXMLFileName()
{
	return this->fileName;
}

/**
* Access Method
* Get the file name of the DTD document
* @returns The file name of the DTD document
*/
char* DM_DocumentNode::getDTDFileName()
{
	return DTDFileName;
}

/**
* Debug Method
* Print the information of the DM_DoucmentNode
*/
void DM_DocumentNode::printValue()
{
	cout << "Document Node: Key = " << this->key.toString();
	cout << ", EndKey = " << this->endKey.toString() << endl;

	cout << "file name = " << this->fileName << endl;
	cout << "path = " << this->filePath << endl;
	cout << "child number = " << this->childNumber << endl;

	if (this->childNumber > 0)
	{
		cout << "	first child key = " << this->firstChild.toString();
		cout << ", last child key = " << this->lastChild.toString() << endl;
	}
	cout << endl;
}

/**
* Process Method
*
* Wrap the content of the node into a string
* 
* The output of this method is used to be stored into database
*
* @param bufLength The size of the string, which is the wrapping result (return value)
* @returns A string that contains all the information of the node.
*
* @see DM_DataNode::wrapCommon()
*/
char* DM_DocumentNode::wrap(int* length)
{
	// the buffer for the common data shared by all type of nodes
	char* dataBuffer;
	int dataBufferLen;

	// the buffer for the data that is unique in document node
	char* docBuffer ;
	int docBufferLen;

	// for output
	char* buffer;

	// wrap the common data defined in DM_DataNode
	dataBuffer = this->wrapCommon(&dataBufferLen);

	// wrap the fields that are defined in DM_DocumentNode
	
	// compute the buffer length
	docBufferLen = 2*sizeof(KeyType) + strlen(this->fileName) + strlen(this->filePath) 
		+ strlen(this->DTDFileName) + strlen(this->DTDPath) + 5* sizeof(int);

	// allocate space for the buffer
	docBuffer = new char[docBufferLen];
	int cursor = 0;
	
	// child number
	memcpy(docBuffer + cursor, &(this->childNumber), sizeof(int));
	cursor += sizeof(int);

	// first child
	memcpy(docBuffer + cursor, &(this->firstChild), sizeof(KeyType));
	cursor += sizeof(KeyType);

	// last child. 
	memcpy(docBuffer + cursor, &(this->lastChild), sizeof(KeyType));
	cursor += sizeof(KeyType);

	// wrap the XML  filename, and schema fileName

	// XML filename
	cursor += this->wrapString(docBuffer+cursor, this->fileName, strlen(this->fileName));

	// XML filepath
	cursor += this->wrapString(docBuffer+cursor, this->filePath, strlen(this->filePath));

	// schema filename
	cursor += this->wrapString(docBuffer+cursor, this->DTDFileName, strlen(this->DTDFileName));
 
	// schema filepath
	cursor += this->wrapString(docBuffer+cursor, this->DTDPath, strlen(this->DTDPath));

	docBufferLen = cursor;

	// combine the content in the two buffer, headed with the node type, and the length 
	// of the two parts	
	//(*length) = dataBufferLen + docBufferLen + 3 * sizeof(int);
    (*length) = dataBufferLen + docBufferLen + 2 * sizeof(int) + sizeof(char);
    buffer = new char[*length];
    // MEM INIT
    memset(buffer,0,*length);
	cursor = 0;

	// the node type
	memcpy(buffer+cursor, &(this->nodeFlag), sizeof(char));
	cursor += sizeof(char);

	// the length of the common data
	memcpy(buffer+cursor, &dataBufferLen, sizeof(int));
	cursor += sizeof(int);

	// the length for data that is unique to the document node
	memcpy(buffer+cursor, &docBufferLen, sizeof(int));
	cursor += sizeof(int);

	// the common data
	memcpy(buffer+cursor, dataBuffer, dataBufferLen);
	cursor += dataBufferLen;

	// the data that is unique to the document node
	memcpy(buffer+cursor, docBuffer, docBufferLen);
	cursor += docBufferLen;

	// release allocated space
	delete [] dataBuffer;
	delete [] docBuffer;

	return buffer;
}

/**
* Process Method
*
* Unwrap the content of the node from a string and restore the instance
* 
* @param buffer A string that contains all the information of the node
*/
void DM_DocumentNode::unwrap(char* buffer)
{
	int dataLen, docLen;
	int cursor;

	// get the length of the two parts: common data in DataNode, and data for ElementNode only
	cursor = sizeof(char); // skip the first integer (node type)

	// the length of the common data
	memcpy(&dataLen, buffer + cursor, sizeof(int));
	cursor += sizeof(int);

	// the length of the data unique to document node
	memcpy(&docLen, buffer + cursor, sizeof(int));
	cursor += sizeof(int);

	// unwrap the common data
	this->unwrapCommon(buffer + cursor);
	cursor += dataLen;

	// unwrap the data fields in DocumentNode
	
	// child
	this->attrNumber = 0;
	this->attributes = -1;

	// child number
	//memcpy(&(this->childNumber), buffer + cursor, sizeof(KeyType));
	memcpy(&(this->childNumber), buffer + cursor, sizeof(int));	
	cursor += sizeof(int);

	// first child. 
	memcpy(&(this->firstChild), buffer + cursor, sizeof(KeyType));
	cursor += sizeof(KeyType);

	// last child.
	memcpy(&(this->lastChild), buffer + cursor, sizeof(KeyType));
	cursor += sizeof(KeyType);

	// unwrap the XML and schema file info

	cursor += this->unwrapString(buffer+cursor, this->fileName);
	cursor += this->unwrapString(buffer+cursor, this->filePath);
	cursor += this->unwrapString(buffer+cursor, this->DTDFileName);
	cursor += this->unwrapString(buffer+cursor, this->DTDPath);

}

/**
* Process Method
* 
* This method compute the size of memory occupied by the node.
* Note: this size is the size of the node in memory, not the record size in database.
*
* @returns The in-memory size of the node in bytes.
*/
int DM_DocumentNode::getNodeSize()
{
	// the size of data in DM_DataNode
	int datanodeSize = sizeof(DM_DataNode) // the size of all field in the class
					//+ sizeof(int) + strlen(this->nodeTag) // for node tag
					- sizeof(char*) + this->historyLength; // for history

	// the size of data in DM_ElementNode
	int elenodeSize = sizeof(DM_ElementNode);

	// the size of data in DM_DocumentNode
	int docnodeSize = 2*sizeof(KeyType) + strlen(this->fileName) + strlen(this->filePath) 
		+ strlen(this->DTDFileName) + strlen(this->DTDPath) + 5* sizeof(int);

	return datanodeSize + elenodeSize + docnodeSize;
}
