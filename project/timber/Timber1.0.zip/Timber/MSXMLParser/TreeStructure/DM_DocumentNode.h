/*
COPYRIGHT  (c) 2000-2004 
THE REGENTS OF THE UNIVERSITY OF MICHIGAN
ALL RIGHTS RESERVED

PERMISSION IS GRANTED TO USE, COPY, CREATE DERIVATIVE WORKS AND
REDISTRIBUTE THIS SOFTWARE AND SUCH DERIVATIVE WORKS FOR NONCOMMERCIAL
EDUCATION AND RESEARCH PURPOSES, SO LONG AS NO FEE IS CHARGED, AND SO LONG
AS THE COPYRIGHT NOTICE ABOVE, THIS GRANT OF PERMISSION, AND THE
DISCLAIMER BELOW APPEAR IN ALL COPIES MADE; AND SO LONG AS THE NAME OF THE
UNIVERSITY OF MICHIGAN IS NOT USED IN ANY ADVERTISING OR PUBLICITY
PERTAINING TO THE USE OR DISTRIBUTION OF THIS SOFTWARE WITHOUT SPECIFIC,
WRITTEN PRIOR AUTHORIZATION.

THIS SOFTWARE IS PROVIDED AS IS, WITHOUT REPRESENTATION FROM THE
UNIVERSITY OF MICHIGAN AS TO ITS FITNESS FOR ANY PURPOSE, AND WITHOUT
WARRANTY BY THE UNIVERSITY OF MICHIGAN OF ANY KIND, EITHER EXPRESS OR
IMPLIED, INCLUDING WITHOUT LIMITATION THE IMPLIED WARRANTIES OF
MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE. THE REGENTS OF THE
UNIVERSITY OF MICHIGAN SHALL NOT BE LIABLE FOR ANY DAMAGES, INCLUDING
SPECIAL, INDIRECT, INCIDENTAL, OR CONSEQUENTIAL DAMAGES, WITH RESPECT TO
ANY CLAIM ARISING OUT OF OR IN CONNECTION WITH THE USE OF THE SOFTWARE,
EVEN IF IT HAS BEEN OR IS HEREAFTER ADVISED OF THE POSSIBILITY OF SUCH
DAMAGES.
*/

/**
 * @author Yuqing (Melanie) Wu
 */

#ifndef __DM_DocumentNode_H
#define __DM_DocumentNode_H

#include "DM_ElementNode.h"

/**
* class DM_DocumentNode
* 
* This class represent the root node of an XML document.
* 
* @see DM_DataNode
* @see DM_ElementNode
*/

class DM_DocumentNode : public DM_ElementNode  
{
public:
	/**
	* Constuctor
	* Initialize the variables with information given
	* @param key The start key of the node
	* @param level The depth of the node
	* @param docname Name of the XML document
	* @param path Path of the XML document
	*/
	DM_DocumentNode(KeyType key, short level, char* docname, char* path);

	/**
	* Constructor
	* 
	* Create an instance of the DM_DocumentNode using the information wrapped in a string
	*
	*@param buffer The string which contains the information about the node, wrapped in a string
	* 
	*@see DM_DocumentNode::unwrap()
	*/
	DM_DocumentNode(char* buffer);

	/**
	* Default Destructor
	*/
	virtual ~DM_DocumentNode();

	/**
	* Access Method
	* Get the file name of the XML document
	* @returns The file name of the XML document
	*/
	char* getXMLFileName();

	/**
	* Access Method
	* Get the file name of the DTD document
	* @returns The file name of the DTD document
	*/
	char* getDTDFileName();

	/**
	* Debug Method
	* Print the information of the DM_DoucmentNode
	*/
	void printValue();

	/**
	* Process Method
	*
	* Wrap the content of the node into a string
	* 
	* The output of this method is used to be stored into database
	*
	* @param bufLength The size of the string, which is the wrapping result (return value)
	* @returns A string that contains all the information of the node.
	*
	* @see DM_DataNode::wrapCommon()
	*/
	char* wrap(int* length);

	/**
	* Process Method
	*
	* Unwrap the content of the node from a string and restore the instance
	* 
	* @param buffer A string that contains all the information of the node
	*/
	void unwrap(char* buffer);
	
	/**
	* Process Method
	* 
	* This method compute the size of memory occupied by the node.
	* Note: this size is the size of the node in memory, not the record size in database.
	*
	* @returns The in-memory size of the node in bytes.
	*/
	int getNodeSize();

private:
	/**
	* The file name of the XML document
	*/
	char fileName[MAX_FILE_NAME_LENGTH];

	/**
	* The file path of the XML document
	*/
	char filePath[MAX_FILE_PATH_LENGTH];

	/**
	* The file name of the DTD document
	*/
	char DTDFileName[MAX_FILE_NAME_LENGTH];

	/**
	* The file path of the DTD document
	*/
	char DTDPath[MAX_FILE_PATH_LENGTH];
	
};

#endif
