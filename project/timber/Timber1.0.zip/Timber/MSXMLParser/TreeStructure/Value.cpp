/*
COPYRIGHT  (c) 2000-2004 
THE REGENTS OF THE UNIVERSITY OF MICHIGAN
ALL RIGHTS RESERVED

PERMISSION IS GRANTED TO USE, COPY, CREATE DERIVATIVE WORKS AND
REDISTRIBUTE THIS SOFTWARE AND SUCH DERIVATIVE WORKS FOR NONCOMMERCIAL
EDUCATION AND RESEARCH PURPOSES, SO LONG AS NO FEE IS CHARGED, AND SO LONG
AS THE COPYRIGHT NOTICE ABOVE, THIS GRANT OF PERMISSION, AND THE
DISCLAIMER BELOW APPEAR IN ALL COPIES MADE; AND SO LONG AS THE NAME OF THE
UNIVERSITY OF MICHIGAN IS NOT USED IN ANY ADVERTISING OR PUBLICITY
PERTAINING TO THE USE OR DISTRIBUTION OF THIS SOFTWARE WITHOUT SPECIFIC,
WRITTEN PRIOR AUTHORIZATION.

THIS SOFTWARE IS PROVIDED AS IS, WITHOUT REPRESENTATION FROM THE
UNIVERSITY OF MICHIGAN AS TO ITS FITNESS FOR ANY PURPOSE, AND WITHOUT
WARRANTY BY THE UNIVERSITY OF MICHIGAN OF ANY KIND, EITHER EXPRESS OR
IMPLIED, INCLUDING WITHOUT LIMITATION THE IMPLIED WARRANTIES OF
MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE. THE REGENTS OF THE
UNIVERSITY OF MICHIGAN SHALL NOT BE LIABLE FOR ANY DAMAGES, INCLUDING
SPECIAL, INDIRECT, INCIDENTAL, OR CONSEQUENTIAL DAMAGES, WITH RESPECT TO
ANY CLAIM ARISING OUT OF OR IN CONNECTION WITH THE USE OF THE SOFTWARE,
EVEN IF IT HAS BEEN OR IS HEREAFTER ADVISED OF THE POSSIBILITY OF SUCH
DAMAGES.
*/

/**
 * @author Cong Yu
 * @author Yuqing (Melanie) Wu
 */

#include <string.h>
#include "Value.h"

//@{
// This class represent the value type the content of a node may have
//@}

//@{
// Constructor
// initialize the instance with the type of value given
// @param type The type of the value, can be one of the following:
// INT_VALUE, STRING_VALUE, DATE_VALUE, REAL_VALUE,
//@}
Value::Value(int type)
{
	this->strValue = NULL;
    this->intValue = INT_MIN;
    this->realValue = LONG_MIN;
	this->valueType = type;
}

//@{
// Unwrap Constructor
// Create a new instannce with the information wraped in a string
// @param str A string of the result of wrapping an instance of Value
//@}
Value::Value(char* str)
{
	this->strValue = NULL;
	unWrap(str);
}

//@{
// Constructor
//
// initialize the instance with the type of value given, 
// and transform the value in the input string to the desired type.
// @param type The type of the value, can be one of the following:
// INT_VALUE, STRING_VALUE, DATE_VALUE, REAL_VALUE,
// @param str The value in string format.
//@}
Value::Value(int valuetype, const char* str)
{
	this->strValue = NULL;
    this->intValue = INT_MIN;
    this->realValue = LONG_MIN;
	this->valueType = valuetype;
	switch (this->valueType)
	{
	case INT_VALUE:
		setIntValue(atoi(str));
		break;
	case STRING_VALUE:
		setStrValue(str);
		break;
	case REAL_VALUE:
		setRealValue(atof(str));
		break;
	case DATE_VALUE:
		setDateValue();
		break;
	}
}

//@{
// Copy Constructor
// Create a new Value instance, copying the content of the instance given
// @param An instance of Value to be copied from.
//@}
Value::Value(Value* val)
{
	int type = val->getValueType();
	this->strValue = NULL;
    this->intValue = INT_MIN;
    this->realValue = LONG_MIN;
	setValueType(type);
	switch(type)
	{
	case INT_VALUE:
		setIntValue(val->getIntValue());
		break;
	case STRING_VALUE:
		setStrValue(val->getStrValue());
		break;
	case REAL_VALUE:
		setRealValue(val->getRealValue());
		break;
	case DATE_VALUE:
		setDateValue();
		break;
	}

}

//@{
// Destructor
// free the space allocated for string value
//@}
Value::~Value()
{
	if (this->valueType == STRING_VALUE)
	{
		delete [] this->strValue;
	}
}

//@{
// Set Method
// Set the value type
// @param type The value type
//@}
void Value::setValueType(int type)
{
	this->valueType = type;
}

//@{
// Set Method
// Set the Integer value from a string
// This is a temperary method used as patch to the current implementation
//@}
void Value::setValue(char* str)
{
	// set the value type manually, 
	// let the user to input the data type, and set the value according to it
	setValueType(INT_VALUE);
	setIntValue(atoi(str));

	/*
	char ch;

	cout << "\nvalue = %s\n", str);
	cout << "please input the type of the data (s: string, i: int, r: real, d: date) : ");
	scanf("%c\n", &ch);

	switch (ch)
	{
	case 's':
	case 'S':
		setValueType(STRING_VALUE);
		setStrValue(str);
		break;
	case 'i':
	case 'I':
		setValueType(INT_VALUE);
		setIntValue(atoi(str));
		break;
	case 'r':
	case 'R':
		double dval;
		sscanf(str, "%d", &dval);
		setValueType(REAL_VALUE);
		setRealValue(dval);
		break;
	case 'd': 
	case 'D':
		// not implemented
		break;
	default:
		setValueType(STRING_VALUE);
		setStrValue(str);
		break;
	}
	*/
}

//@{
// Set Method
// Set integer value
// @param intval The integer value
//@}
void Value::setIntValue(int intval)
{
	this->intValue = intval;
}

//@{
// Set Method
// Set string value
// @param strval The string value
//@}
void Value::setStrValue(const char* strval)
{
	if (this->strValue)
		delete [] this->strValue;
	this->strValue = new char[strlen(strval)+1];
	strcpy(this->strValue, strval);
}

//@{
// Set Method
// Set date value (not implemented yet)
//@}
void Value::setDateValue() { }

//@{
// Set Method
// Set real value
// @param realval The real value
//@}
void Value::setRealValue(double realval)
{
	this->realValue = realval;
}

//@{
// Access Method
// Get the value Type
// @returns The value type
//@}
int Value::getValueType()
{
	return this->valueType;
}

//@{
// Access Method
// Get integer value
// @returns The integer value
//@}
int Value::getIntValue()
{
	return this->intValue;
}

//@{
// Access Method
// Get string value
// @returns The string value
//@}
char* Value::getStrValue()
{
	return this->strValue;
}

//@{
// Access Method
// Get date value (not implemented yet)
//@}
void Value::getDateValue() { }

//@{
// Access Method
// Get real value
// @returns The real value
//@}
double Value::getRealValue()
{
	return this->realValue;
}

//@{
// Process Method
// Get the memory size of the value
// @returns the size
//@}
int Value::getValueSize()
{
	int size = 0;

	switch(this->valueType)
	{
	case INT_VALUE:
		size = sizeof(int)*2;
		break;
	case STRING_VALUE:
		size = sizeof(int)+strlen(this->strValue)+1;
		break;
	case DATE_VALUE:
		// not implement
		break;
	case REAL_VALUE:
		size = sizeof(int) + sizeof(double);
		break;
	}

	return  size;
}

//@{
// Process Method
// Change the value to a string
// @returns A string which contains the value and can be printed
//@}
char* Value::valueToString()
{
	char* str = NULL;
	switch(this->valueType)
	{
	case INT_VALUE:
		str = new char[12];
		sprintf(str,"%d", this->intValue);
		//itoa(this->intValue, str, 10);
		break;
	case STRING_VALUE:
		str = new char[strlen(this->strValue)+1];
		memcpy(str, this->strValue, strlen(this->strValue)+1);
		break;
	case DATE_VALUE:
		// not implement
		break;
	case REAL_VALUE:
		str = new char[24];
		sprintf(str,"%.17g", this->realValue);
		break;
	}
	return str;
}

//@{
// Process Method
//
// Compare the two value, based on their type and the operator
// @param op The comparason operator
// @param other The other value to be compared with this value
// @returns the boolean result of the comparason
//@}
bool Value::compareValue(int op, Value* other)
{
	bool retval = false;
	switch (op)
	{
	case VALUE_COMP_OP_LT:
		retval = this->lessThan(other);
		break;

	case VALUE_COMP_OP_LE:
		retval = this->lessEqual(other);
		break;

	case VALUE_COMP_OP_GT:
		retval = this->greaterThan(other);
		break;

	case VALUE_COMP_OP_GE:
		retval = this->greaterEqual(other);

	case VALUE_COMP_OP_EQ:
		retval = this->equal(other);
		break;

	case VALUE_COMP_OP_NE:
		retval = this->notEqual(other);
		break;

	case VALUE_COMP_OP_CONTAINS:
		retval = this->contains(other);
		break;

	case VALUE_COMP_OP_CONTAINEDBY:
		retval = this->containedBy(other);
		break;

	case VALUE_COMP_OP_STARTWITH:
		retval = this->startWith(other);
		break;

	default:
		break;
	}
	return retval;
}

//@{
// Process Method
// Wrap the content of the Value into a string
// @parem length The length of the output string (output)
// @returns The string of the wrapping result
//@}
char* Value::wrap(int* length)
{
	char* str = NULL;
	int size = 0;

	switch(this->valueType)
	{
	case INT_VALUE:
		size = sizeof(int)*2;
		str = new char[size];
		memcpy(str, &this->valueType, sizeof(int));
		memcpy(str+sizeof(int), &this->intValue, sizeof(int));
		break;
	case STRING_VALUE:
		size = sizeof(int)+strlen(this->strValue)+1;
		str = new char[size];
		memcpy(str, &this->valueType, sizeof(int));
		strcpy(str+sizeof(int), this->strValue);
		break;
	case DATE_VALUE:
		// not implement
		break;
	case REAL_VALUE:
		size = sizeof(int) + sizeof(double);
		str = new char[size];
		memcpy(str, &this->valueType, sizeof(int));
		memcpy(str+sizeof(int), &this->realValue, sizeof(double));
		break;
	}
	(*length) = size;
	return str;
}

//@{
// Process Method
// Unwrap the information from a string, and restore the instance of Value
// @param str A string which is the result of wrapping and contains all information of an instance of Value
//@}
void Value::unWrap(char* str)
{
	memcpy(&this->valueType, str, sizeof(int));

	switch(this->valueType)
	{
	case INT_VALUE:
		memcpy(&this->intValue, str+sizeof(int), sizeof(int));
		break;
	case STRING_VALUE:
		this->strValue = new char[strlen(str+sizeof(int))+1];
		strcpy(this->strValue, str+sizeof(int));
		break;
	case DATE_VALUE:
		// not implement
		break;
	case REAL_VALUE:
		memcpy(&this->realValue, str+sizeof(int), sizeof(double));
		break;	
	}
}

//@{
// Process Method
// Compare the value of two instance of value
// @param other An instance of Value which is to be compared with this one
// @returns True if this value > value in "other"
//@}
bool Value::greaterThan(Value* other)
{
	bool retval = false;

	switch(this->valueType)
	{
	case INT_VALUE:
		if (other->valueType == INT_VALUE)
			retval = this->intValue > other->intValue;
		else if (other->valueType == REAL_VALUE)
			retval = (double) this->intValue > other->realValue;
		else 
			retval = (this->intValue > atoi(other->strValue));
		break;

	case REAL_VALUE:
		if (other->valueType == INT_VALUE)
			retval = this->realValue > (double) other->intValue;
		else if (other->valueType == REAL_VALUE)
			retval = this->realValue > other->realValue;
		else  
			retval = (this->realValue > atof(other->strValue));
		break;

	case STRING_VALUE:
        // we try to compare with string as well
        if (other->valueType == INT_VALUE)
        {
            this->convertToInt();
            retval = this->greaterThan(other);
            this->convertBackToString();
        } else if (other->valueType == REAL_VALUE)
        {
            this->convertToReal();
            retval = this->greaterThan(other);
            this->convertBackToString();
        } else if (other->valueType == STRING_VALUE)
        {
            if(strcmp(this->strValue, other->strValue)>0) retval = true;
            else retval = false;
        }
		break;

    default:
        retval = false;
        break;
	}
	return retval;
}

//@{
// Process Method
// Compare the value of two instance of value
// @param other An instance of Value which is to be compared with this one
// @returns True if this value >= value in "other"
//@}
bool Value::greaterEqual(Value* other)
{
	bool retval = false;

	switch(this->valueType)
	{
	case INT_VALUE:
		if (other->valueType == INT_VALUE)
			retval = this->intValue >= other->intValue;
		else if (other->valueType == REAL_VALUE)
			retval = (double) this->intValue >= other->realValue;
		else {
			//else it is a string value
			//we try to typecast string to int before comparing the value
			retval = (this->intValue >= atoi(other->strValue));
		}
		break;

	case REAL_VALUE:
		if (other->valueType == INT_VALUE)
			retval = this->realValue >= (double) other->intValue;
		else if (other->valueType == REAL_VALUE)
			retval = this->realValue >= other->realValue;
		else  {
			//else it is a string value
			//we try to typecast string to real before comparing the value
			retval = (this->realValue >= atof(other->strValue));
		}
		break;

	case STRING_VALUE:
        if (other->valueType == INT_VALUE)
        {
            this->convertToInt();
            retval = this->greaterEqual(other);
            this->convertBackToString();
        } else if (other->valueType == REAL_VALUE)
        {
            this->convertToReal();
            retval = this->greaterEqual(other);
            this->convertBackToString();
        } else if (other->valueType == STRING_VALUE)
        {
            if(strcmp(this->strValue, other->strValue)>=0) retval = true;
            else retval = false;
        }
		break;

    default:
        retval = false;
        break;
	}
	return retval;
}

//@{
// Process Method
// Compare the value of two instance of value
// @param other An instance of Value which is to be compared with this one
// @returns True if this value < value in "other"
//@}
bool Value::lessThan(Value* other)
{
    switch (this->valueType)
    {
    case INT_VALUE:
    case REAL_VALUE:
    case STRING_VALUE:
        return !(greaterEqual(other));
    default:
        return false;
    }
}

//@{
// Process Method
// Compare the value of two instance of value
// @param other An instance of Value which is to be compared with this one
// @returns True if this value <= value in "other"
//@}
bool Value::lessEqual(Value* other)
{
    switch (this->valueType)
    {
    case INT_VALUE:
    case REAL_VALUE:
    case STRING_VALUE:
        return !(greaterThan(other));
    default:
        return false;
    }
}

//@{
// Process Method
// Compare the value of two instance of value
// @param other An instance of Value which is to be compared with this one
// @returns True if this value = value in "other"
//@}
bool Value::equal(Value* other)
{
	bool retval = false;
	switch(this->valueType)
	{
	case INT_VALUE:
		if (other->valueType == INT_VALUE)
			retval = this->intValue == other->intValue;
		else if (other->valueType == REAL_VALUE)
			retval = (double) this->intValue == other->realValue;
		else 
			retval = (this->intValue == atoi(other->strValue));
		break;

	case REAL_VALUE:
		if (other->valueType == INT_VALUE)
			retval = this->realValue == (double) other->intValue;
		else if (other->valueType == REAL_VALUE)
			retval = this->realValue == other->realValue;
		else 
			retval = (this->realValue == atof(other->strValue));
		break;

	case STRING_VALUE:
		if (other->valueType == STRING_VALUE)
		{
			int cmpret = strcmp(this->strValue, other->strValue);
			if (cmpret == 0) retval = true;
			else retval = false;
		}
		else if (other->valueType == INT_VALUE)
			retval = (atoi(this->strValue) == other->intValue);
		else 
			retval = (atof(this->strValue) == other->realValue);
		break;

    default:
        retval = false;
        break;
	}
	return retval;
}

//@{
// Process Method
// Compare the value of two instance of value
// @param other An instance of Value which is to be compared with this one
// @returns True if this value != value in "other"
//@}
bool Value::notEqual(Value* other)
{
    switch (this->valueType)
    {
    case INT_VALUE:
    case REAL_VALUE:
    case STRING_VALUE:
        return !(equal(other));
    default:
        return false;
    }
}

//@{
// Process Method
// Compare the value of two instance of value
// @param other An instance of Value which is to be compared with this one
// @returns True if this length of value > the length of value in "other". (used only for string value)
//@}
bool Value::lenLT(Value* other)
{
	if ((this->valueType == STRING_VALUE) && (other->valueType == STRING_VALUE))
		return (strlen(this->strValue) > strlen(other->strValue));
	else 
	{
		//cout << "Length Comparision is not legal for the operands" << endl;
		return false;
	}
}

//@{
// Process Method
// Compare the value of two instance of value
// @param other An instance of Value which is to be compared with this one
// @returns True if this length of value >= the length of value in "other". (used only for string value)
//@}
bool Value::lenLE(Value* other)
{
	if ((this->valueType == STRING_VALUE) && (other->valueType == STRING_VALUE))
		return (strlen(this->strValue) >= strlen(other->strValue));
	else 
	{
		//cout << "Length Comparision is not legal for the operands" << endl;
		return false;
	}
}

//@{
// Process Method
// Compare the value of two instance of value
// @param other An instance of Value which is to be compared with this one
// @returns True if this length of value < the length of value in "other". (used only for string value)
//@}
bool Value::lenST(Value* other)
{
    if (this->valueType == STRING_VALUE && other->valueType == STRING_VALUE)
    	return !(lenLE(other));
    else return false;
}

//@{
// Process Method
// Compare the value of two instance of value
// @param other An instance of Value which is to be compared with this one
// @returns True if this length of value <= the length of value in "other". (used only for string value)
//@}
bool Value::lenSE(Value* other)
{
    if (this->valueType == STRING_VALUE && other->valueType == STRING_VALUE)
    	return !(lenLT(other));
    else return false;
}

//@{
// Process Method
// Compare the value of two instance of value
// @param other An instance of Value which is to be compared with this one
// @returns True if this length of value = the length of value in "other". (used only for string value)
//@}
bool Value::lenEQ(Value* other)
{
	if ((this->valueType == STRING_VALUE) && (other->valueType == STRING_VALUE))
		return (strlen(this->strValue) == strlen(other->strValue));
	else 
	{
		//cout << "Length Comparision is not legal for the operands" << endl;
		return false;
	}
}

//@{
// Process Method
// Compare the value of two instance of value
// @param other An instance of Value which is to be compared with this one
// @returns True if this length of value != the length of value in "other". (used only for string value)
//@}
bool Value::lenNE(Value* other)
{
    if (this->valueType == STRING_VALUE && other->valueType == STRING_VALUE)
    	return !(lenEQ(other));
    else return false;
}

//@{
// Process Method
// Compare the value of two instance of value
// @param other An instance of Value which is to be compared with this one
// @returns True if the string value start with the string value in "other". (used only for string value)
//@}
bool Value::startWith(Value* other)
{
	bool retval = false;

	switch(this->valueType)
	{
	case INT_VALUE:
	case REAL_VALUE:
	case DATE_VALUE:
		break;

	case STRING_VALUE:
		if (other->valueType == STRING_VALUE)
		{
			int strlength = strlen(other->strValue);
			if ((int)strlen(this->strValue) < strlength)
				retval = false;
			else 
			{
				retval = (strncmp(this->strValue,other->strValue,strlength) == 0);
			}
		}
		else 
		{
			retval = false;
		}
		break;
	}
	return retval;
}

//@{
// Process Method
// Compare the value of two instance of value
// @param other An instance of Value which is to be compared with this one
// @returns True if the string value contains the string value in "other". (used only for string value)
//@}
bool Value::contains(Value* other)
{
	bool retval;
	if ((this->valueType == STRING_VALUE) && (other->getValueType() == STRING_VALUE))
	{
		char* ret = strstr(this->strValue, other->getStrValue());
		if (ret == NULL)
			retval = false;
		else retval = true;
	}
	else retval = false;

	return retval;
}

//@{
// Process Method
// Compare the value of two instance of value
// @param other An instance of Value which is to be compared with this one
// @returns True if the string value is contained in the string value in "other". (used only for string value)
//@}
bool Value::containedBy(Value* other)
{
	return other->contains(this);
}

//@{
// Potential bugs in the following utility method, string value
// may not be convertible to int or real!
//@}

//@{
// Utility Method
// Convert this String value into an int value: keep the originial 
// String value for possible converting back
//@}
void Value::convertToInt()
{
    this->valueType = INT_VALUE;
    if (this->strValue)
    {
        this->intValue = atoi(this->strValue);
    }
}

//@{
// Utility Method
// Convert this String value into a double value
//@}
void Value::convertToReal()
{
    this->valueType = REAL_VALUE;
    if (this->strValue)
    {
        this->realValue = atof(this->strValue);
    }
}

//@{
// Utility Method
// Convert decimal value back into a string value
//@}
void Value::convertBackToString()
{
    if (this->valueType == INT_VALUE)
    {
        this->intValue = INT_MIN;
    } else if (this->valueType == REAL_VALUE)
    {
        this->realValue = LONG_MIN;
    }
    this->valueType = STRING_VALUE;
}

//@{
// Debug Method
// Print the contents of the Value
//@}
void Value::printValue()
{
	switch(this->valueType)
	{
	case INT_VALUE:
		cout << this->intValue << endl;
		break;
	case STRING_VALUE:
		cout << this->strValue << endl;
		break;
	case REAL_VALUE:
		cout << this->realValue << endl;
		break;
	case DATE_VALUE:
		break;
	}	
}
