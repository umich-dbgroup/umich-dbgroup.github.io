/*
COPYRIGHT  (c) 2000-2004 
THE REGENTS OF THE UNIVERSITY OF MICHIGAN
ALL RIGHTS RESERVED

PERMISSION IS GRANTED TO USE, COPY, CREATE DERIVATIVE WORKS AND
REDISTRIBUTE THIS SOFTWARE AND SUCH DERIVATIVE WORKS FOR NONCOMMERCIAL
EDUCATION AND RESEARCH PURPOSES, SO LONG AS NO FEE IS CHARGED, AND SO LONG
AS THE COPYRIGHT NOTICE ABOVE, THIS GRANT OF PERMISSION, AND THE
DISCLAIMER BELOW APPEAR IN ALL COPIES MADE; AND SO LONG AS THE NAME OF THE
UNIVERSITY OF MICHIGAN IS NOT USED IN ANY ADVERTISING OR PUBLICITY
PERTAINING TO THE USE OR DISTRIBUTION OF THIS SOFTWARE WITHOUT SPECIFIC,
WRITTEN PRIOR AUTHORIZATION.

THIS SOFTWARE IS PROVIDED AS IS, WITHOUT REPRESENTATION FROM THE
UNIVERSITY OF MICHIGAN AS TO ITS FITNESS FOR ANY PURPOSE, AND WITHOUT
WARRANTY BY THE UNIVERSITY OF MICHIGAN OF ANY KIND, EITHER EXPRESS OR
IMPLIED, INCLUDING WITHOUT LIMITATION THE IMPLIED WARRANTIES OF
MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE. THE REGENTS OF THE
UNIVERSITY OF MICHIGAN SHALL NOT BE LIABLE FOR ANY DAMAGES, INCLUDING
SPECIAL, INDIRECT, INCIDENTAL, OR CONSEQUENTIAL DAMAGES, WITH RESPECT TO
ANY CLAIM ARISING OUT OF OR IN CONNECTION WITH THE USE OF THE SOFTWARE,
EVEN IF IT HAS BEEN OR IS HEREAFTER ADVISED OF THE POSSIBILITY OF SUCH
DAMAGES.
*/

/**
 * @author Yuqing (Melanie) Wu
 */

#ifndef __TestDataParser_H
#define __TestDataParser_H

#include "TestClass.h"
#include "../DataParser/MSXMLParser.h"

// the test code
#define TEST_NODES			0
#define TEST_PARSER			1

/**
* TestDataParser
* 
* This class provide test cases as well as code examples for how to use the functionality provided
* in this MSXMLParser project. 
*
* There are two major blocks in the MSXMLParser project, one is the definition of the tree structural 
* representation of XML data in Timber, another is parsing and storing XML document into  database.
* Accordingly, the example code and test cases provided by this test class include TEST_NODES and TEST_PARSER.
*
* @see DM_DataNode
* @see MSXMLParser
*/

class TestDataParser : public TestClass
{
public:
	/**
	* Constructor
	* Set variables, and initialize data parser. 
	*/
	TestDataParser(lvid_t vold_i, char* filename);
	~TestDataParser();

	/**
	* Process Method
	* Read the test parameter and run tests accordingly
	*/
	void runTest();

private:

	MSXMLParser* dataParser;

	/**
	* TestNodes
	* 
	* Test the construction, some basic functions and especailly wrapping/unwrapping of the data nodes.
	*/
	void testNodes();

	/**
	* Test Parser
	* This tests the data parser, by parse the XML only and output the statistical information of the XML document. 
	*/
	void testDataParser();
	
	void initTestCode();

};

#endif
