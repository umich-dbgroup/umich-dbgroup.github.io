/*
COPYRIGHT  (c) 2000-2004 
THE REGENTS OF THE UNIVERSITY OF MICHIGAN
ALL RIGHTS RESERVED

PERMISSION IS GRANTED TO USE, COPY, CREATE DERIVATIVE WORKS AND
REDISTRIBUTE THIS SOFTWARE AND SUCH DERIVATIVE WORKS FOR NONCOMMERCIAL
EDUCATION AND RESEARCH PURPOSES, SO LONG AS NO FEE IS CHARGED, AND SO LONG
AS THE COPYRIGHT NOTICE ABOVE, THIS GRANT OF PERMISSION, AND THE
DISCLAIMER BELOW APPEAR IN ALL COPIES MADE; AND SO LONG AS THE NAME OF THE
UNIVERSITY OF MICHIGAN IS NOT USED IN ANY ADVERTISING OR PUBLICITY
PERTAINING TO THE USE OR DISTRIBUTION OF THIS SOFTWARE WITHOUT SPECIFIC,
WRITTEN PRIOR AUTHORIZATION.

THIS SOFTWARE IS PROVIDED AS IS, WITHOUT REPRESENTATION FROM THE
UNIVERSITY OF MICHIGAN AS TO ITS FITNESS FOR ANY PURPOSE, AND WITHOUT
WARRANTY BY THE UNIVERSITY OF MICHIGAN OF ANY KIND, EITHER EXPRESS OR
IMPLIED, INCLUDING WITHOUT LIMITATION THE IMPLIED WARRANTIES OF
MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE. THE REGENTS OF THE
UNIVERSITY OF MICHIGAN SHALL NOT BE LIABLE FOR ANY DAMAGES, INCLUDING
SPECIAL, INDIRECT, INCIDENTAL, OR CONSEQUENTIAL DAMAGES, WITH RESPECT TO
ANY CLAIM ARISING OUT OF OR IN CONNECTION WITH THE USE OF THE SOFTWARE,
EVEN IF IT HAS BEEN OR IS HEREAFTER ADVISED OF THE POSSIBILITY OF SUCH
DAMAGES.
*/

/**
 * @author Yuqing (Melanie) Wu
 */

// disable VC warning: vc7\include\xtree(1112) : warning C4702: unreachable code
#pragma warning(disable:4702)
#include "testDataParser.h"
#pragma warning(default:4702)
#include <time.h>

/**
* TestDataParser
* 
* This class provide test cases as well as code examples for how to use the functionality provided
* in this MSXMLParser project. 
*
* There are two major blocks in the MSXMLParser project, one is the definition of the tree structural 
* representation of XML data in Timber, another is parsing and storing XML document into  database.
* Accordingly, the example code and test cases provided by this test class include TEST_NODES and TEST_PARSER.
*
* @see DM_DataNode
* @see MSXMLParser
*/

/**
* Constructor
* Set variables, and initialize data parser. 
*/
TestDataParser::TestDataParser(lvid_t vold_i, char* filename) : TestClass(vold_i, filename)
{
	this->dataParser = new MSXMLParser(this->volumeID);
	this->initTestCode();
}

TestDataParser::~TestDataParser(void)
{
	delete this->dataParser;
}

/**
* Process Method 
* Initialize the TestCodeMap with the test code supported by the test class. 
*/
void TestDataParser::initTestCode()
{
	this->testCodeMap.insert(StringIntMapType::value_type("TEST_NODES", TEST_NODES));
	this->testCodeMap.insert(StringIntMapType::value_type("TEST_PARSER", TEST_PARSER));

	printf("the choices for TestDataParser are:\n");

	StringIntMapType::iterator item = this->testCodeMap.begin();
	while (item != this->testCodeMap.end())
	{
		printf("%s %d\n", item->first, item->second);
		item++;
	}

}

/**
* Process Method
* Read the test parameter and run tests accordingly
*/
void TestDataParser::runTest()
{
	this->fpPara = fopen(this->filenamePara, "r");
	if (this->fpPara == NULL) return;
	
	// read the test code
	int testCode = this->getTestCode();

	// run test according to the test code. 
	while (testCode >= 0)
	{
		switch (testCode)
		{
		case TEST_NODES:
			this->testNodes();
			break;
		case TEST_PARSER:
			this->testDataParser();
			break;
		default:
			fclose(this->fpPara);
			break;
		}
        testCode = this->getTestCode();
	}
}

/**
* TestNodes
* 
* Test the construction, some basic functions and especailly wrapping/unwrapping of the data nodes.
*/
void TestDataParser::testNodes()
{
	DM_TextNode* textNode4 = new DM_TextNode(4, 4, "Peter");
	DM_TextNode* textNode6 = new DM_TextNode(6, 4, "Tom");

	char* names[2] = {"id", "code"};
	Value* values[2];
	values[0] = new Value(STRING_VALUE);
	values[0]->setStrValue("0001");
	values[1] = new Value(STRING_VALUE);
	values[1]->setStrValue("aaaa");
	
	DM_AttributeNode* attrNode2 = new DM_AttributeNode(2,3,2,names, values, 1);
	
	DM_ElementNode* eleNode3 = new DM_ElementNode(3, 3, 11);
	eleNode3->setEndKey(5);
	eleNode3->appendChild(textNode4, NULL);

	DM_ElementNode* eleNode1 = new DM_ElementNode(1, 2, 12);
	eleNode1->setEndKey(7);
	eleNode1->appendChild(eleNode3, NULL);
	eleNode1->appendChild(textNode6, eleNode3);
	eleNode1->setAttributes(2);
	eleNode1->setAttrNumber(2);
	eleNode1->setHistory(5, "55555");

	DM_DocumentNode* docNode0 = new DM_DocumentNode(0, 1, "docname.xml", "docpath");
	docNode0->appendChild(eleNode1, NULL);

	char* nodeinstr;
	int length;
	DM_DataNode* newNode;

	printf("\n----------------------------------------\n");
	printf("test wrap document node\n");
	nodeinstr = docNode0->wrap(&length);
	printf("string length = %d\n", length);

	newNode = DM_DataNode::unwrap(nodeinstr);
	printf("before wrap:\n");
	docNode0->printValue();
	printf("after unwrap\n");
	newNode->printValue();	

	delete [] nodeinstr;
	delete newNode;

	printf("\n----------------------------------------\n");
	printf("test wrap element node\n");
	nodeinstr = eleNode3->wrap(&length);

	newNode = DM_DataNode::unwrap(nodeinstr);
	printf("string length = %d\n", length);
	printf("before wrap:\n");
	eleNode3->printValue();
	printf("after unwrap\n");
	newNode->printValue();	

	delete newNode;

	int count = 0;
	while (count < 1)
	{
		count++;
		newNode = DM_DataNode::unwrap(nodeinstr);
		if (count %10000 == 0) printf("%d element unwrapped, newnode = %p\n", count);
		delete newNode;
	}
	delete [] nodeinstr;

	printf("\n----------------------------------------\n");
	nodeinstr = eleNode1->wrap(&length);
	printf("string length = %d\n", length);
	newNode = DM_DataNode::unwrap(nodeinstr);
	printf("before wrap:\n");
	eleNode1->printValue();
	printf("after unwrap\n");
	newNode->printValue();	
	delete newNode;

	count = 0;
	while (count < 2000000)
	{
		count++;
		newNode = DM_DataNode::unwrap(nodeinstr);
		if (count %100000 == 0) printf("%d element unwrapped, newnode = %p\n", count);
		delete newNode;
	}

	delete [] nodeinstr;

	printf("\n----------------------------------------\n");
	printf("test wrap Attribute node\n");
	nodeinstr = attrNode2->wrap(&length);
	printf("string length = %d\n", length);
	
	newNode = DM_DataNode::unwrap(nodeinstr);
	printf("before wrap:\n");
	attrNode2->printValue();
	printf("after unwrap\n");
	newNode->printValue();	

	delete newNode;

	count = 0;
	while (count < 2000000)
	{
		count++;
		newNode = DM_DataNode::unwrap(nodeinstr);
		if (count %100000 == 0) printf("%d attr node unwrapped, newnode = %p\n", count);
		delete newNode;
	}

	delete [] nodeinstr;

	printf("\n----------------------------------------\n");
	printf("test wrap text node\n");
	nodeinstr = textNode4->wrap(&length);
	printf("string length = %d\n", length);
	
	newNode = DM_DataNode::unwrap(nodeinstr);
	printf("before wrap:\n");
	textNode4->printValue();
	printf("after unwrap\n");
	newNode->printValue();
	delete newNode;

	count = 0;
	while (count < 2000000)
	{
		count++;
		newNode = DM_DataNode::unwrap(nodeinstr);
		if (count %100000 == 0) printf("%d text unwrapped, newnode = %p\n", count);
		delete newNode;
	}

	delete [] nodeinstr;

	delete docNode0;
	delete eleNode1;
	delete attrNode2;
	delete eleNode3;
	delete textNode4;
	delete textNode6;

}

/**
* Test Parser
* This tests the data parser, by parse the XML only and output the statistical information of the XML document. 
*/
void TestDataParser::testDataParser()
{
	char filename[200];
	fscanf(this->fpPara, "%s", filename);
	MSXMLParser* xmlParser = new MSXMLParser(this->volumeID);
	xmlParser->parseXML(filename, 100, OP_PARSE_ONLY, NULL, NULL, NULL, NULL, NULL, false, NULL);
	delete xmlParser;
}
