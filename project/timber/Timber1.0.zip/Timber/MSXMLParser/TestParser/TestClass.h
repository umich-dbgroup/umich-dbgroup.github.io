/*
COPYRIGHT  (c) 2000-2004 
THE REGENTS OF THE UNIVERSITY OF MICHIGAN
ALL RIGHTS RESERVED

PERMISSION IS GRANTED TO USE, COPY, CREATE DERIVATIVE WORKS AND
REDISTRIBUTE THIS SOFTWARE AND SUCH DERIVATIVE WORKS FOR NONCOMMERCIAL
EDUCATION AND RESEARCH PURPOSES, SO LONG AS NO FEE IS CHARGED, AND SO LONG
AS THE COPYRIGHT NOTICE ABOVE, THIS GRANT OF PERMISSION, AND THE
DISCLAIMER BELOW APPEAR IN ALL COPIES MADE; AND SO LONG AS THE NAME OF THE
UNIVERSITY OF MICHIGAN IS NOT USED IN ANY ADVERTISING OR PUBLICITY
PERTAINING TO THE USE OR DISTRIBUTION OF THIS SOFTWARE WITHOUT SPECIFIC,
WRITTEN PRIOR AUTHORIZATION.

THIS SOFTWARE IS PROVIDED AS IS, WITHOUT REPRESENTATION FROM THE
UNIVERSITY OF MICHIGAN AS TO ITS FITNESS FOR ANY PURPOSE, AND WITHOUT
WARRANTY BY THE UNIVERSITY OF MICHIGAN OF ANY KIND, EITHER EXPRESS OR
IMPLIED, INCLUDING WITHOUT LIMITATION THE IMPLIED WARRANTIES OF
MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE. THE REGENTS OF THE
UNIVERSITY OF MICHIGAN SHALL NOT BE LIABLE FOR ANY DAMAGES, INCLUDING
SPECIAL, INDIRECT, INCIDENTAL, OR CONSEQUENTIAL DAMAGES, WITH RESPECT TO
ANY CLAIM ARISING OUT OF OR IN CONNECTION WITH THE USE OF THE SOFTWARE,
EVEN IF IT HAS BEEN OR IS HEREAFTER ADVISED OF THE POSSIBILITY OF SUCH
DAMAGES.
*/

/**
 * @author Yuqing (Melanie) Wu
 */

#ifndef __TestClass_H
#define __TestClass_H

#include "../DataParser/MSXMLParser.h"
#include <map>
//#include <iostream.h>
#include <iostream>
using namespace std;

/**
* class TestClass
* 
* This is the base class for the test classes developped by Yuqing Melanie Wu. 
* This test are all done in the following ways: 
* 1. a test parameter file gives the configuration of the test, including the test to run and the parameters
* 2. each subclass of this class test the functionaliry of one project in Timber.
* 3. new test cases can be added, either by changing the parameters in the test parameter file, or by
*		adding new test functions to the code. 
* 
* @see TestDataParser
* @see TestPhysicalDataMng
* @see TestNodeIDMap
* @see TestDataMng
* @see TestStatisticalInfoMng
*/

class TestClass
{
public:
	/**
	* Constructor
	* 
	* Initialize the varialbe.
	*
	* @param vol_id The id of the volume where the current database is at.
	* @param filename The name of the parameter file
	*/
	TestClass(lvid_t vold_i, char* filename);
	~TestClass(void);

	/**
	* This is the function that actually read the test parameter and run test. 
	* Will be overwritten by each subclass. 
	*/
	virtual void runTest() {};

protected:
	/**
	* The id of the volume where the database is on
	*/
	lvid_t volumeID;

	/**
	* The name of the test parameter file
	*/
	char* filenamePara;

	/**
	* The opened file scream for the test parameter file.
	*/
	FILE* fpPara;

	/**
	* A map that maps the test code string to test code (integer)
	*/
	StringIntMapType testCodeMap;

	char testCodeString[100][100];

	/**
	* Process Method
	* 
	* Read the test-code (a string) from the parameter file, and interpreate it into a test-code (an int). 
	* @return the test-code (integer), -1 if the string read is not a valid test-code. 
	*/
	int getTestCode();

	/**
	* Virtual Method (this will be overwritten by each subclass of TestClass)
	* 
	* Initialize the TestCodeMap with the test code supported by the test class. 
	*/
	virtual void initTestCode() {};
};

#endif
