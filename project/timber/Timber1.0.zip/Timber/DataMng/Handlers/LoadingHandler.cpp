/*
COPYRIGHT  � 2000-2004 
THE REGENTS OF THE UNIVERSITY OF MICHIGAN
ALL RIGHTS RESERVED

PERMISSION IS GRANTED TO USE, COPY, CREATE DERIVATIVE WORKS AND
REDISTRIBUTE THIS SOFTWARE AND SUCH DERIVATIVE WORKS FOR NONCOMMERCIAL
EDUCATION AND RESEARCH PURPOSES, SO LONG AS NO FEE IS CHARGED, AND SO
LONG AS THE COPYRIGHT NOTICE ABOVE, THIS GRANT OF PERMISSION, AND THE
DISCLAIMER BELOW APPEAR IN ALL COPIES MADE; AND SO LONG AS THE NAME OF
THE UNIVERSITY OF MICHIGAN IS NOT USED IN ANY ADVERTISING OR PUBLICITY
PERTAINING TO THE USE OR DISTRIBUTION OF THIS SOFTWARE WITHOUT
SPECIFIC, WRITTEN PRIOR AUTHORIZATION.

THIS SOFTWARE IS PROVIDED AS IS, WITHOUT REPRESENTATION FROM THE
UNIVERSITY OF MICHIGAN AS TO ITS FITNESS FOR ANY PURPOSE, AND WITHOUT
WARRANTY BY THE UNIVERSITY OF MICHIGAN OF ANY KIND, EITHER EXPRESS OR
IMPLIED, INCLUDING WITHOUT LIMITATION THE IMPLIED WARRANTIES OF
MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE. THE REGENTS OF
THE UNIVERSITY OF MICHIGAN SHALL NOT BE LIABLE FOR ANY DAMAGES,
INCLUDING SPECIAL, INDIRECT, INCIDENTAL, OR CONSEQUENTIAL DAMAGES,
WITH RESPECT TO ANY CLAIM ARISING OUT OF OR IN CONNECTION WITH THE USE
OF THE SOFTWARE, EVEN IF IT HAS BEEN OR IS HEREAFTER ADVISED OF THE
POSSIBILITY OF SUCH DAMAGES.
*/

#include "../StdAfx.h"
#include "loadinghandler.h"

/**
* class LoadingHandler
* This class provides interface and service for data loading, at the DataMng Level. 
* Some of the tasks can be acomplished simply by calling the functions in the Loading Interface of PhysicalDataMng
* Some of them requires extra process on this level, such as appendXMLFile. 
* 
* @see PhysicalDataMng
* @see DataMng
*
* @author Yuqing Melanie Wu
* @version 1.0
*/

/**
* Constructor
* Initialize the LoadingHandler with the PhysicalDataMng which supports its tasks. 
*/

LoadingHandler::LoadingHandler(PhysicalDataMng* pdatamng)
{
	this->physicalDataMng = pdatamng;
}

LoadingHandler::~LoadingHandler(void)
{
}

/**
* Loading Interface
* Load an xml document into database
* This is fully supported by the loading interface provided by PhysicalDataMng
* 
* @param filename The name of the xml document (with path) to be loaded to the database.
* @param maxdepth The esitmated depth of the xml document.  
* @param convertmulticolor The flag saying whether to convert pointer-based to multicolor model (Nuwee added 07/14/03)
* @returns Error Code
*/

int LoadingHandler::loadXMLFile(char* filename, bool convertmulticolor, int maxdepth)
{
	return this->physicalDataMng->loadXMLFile(filename, maxdepth, convertmulticolor);
}

/**
* Loading Interace
* This function append an XML document an existing data file in the database, and incrementally maintain
* the indicies built on the data file, as well as statistial informations about the database. 
* 
* The loading interface, with regard to append, provided by PhysicalDataMng deals with data file only. 
* It appends the new XML document to the data file in the database. However, the maintainance of indices and 
* statistical information about the data file could not be done at the PhysicalDataMng level, since IndexMng 
* and StatisticalInfoMng are involved. 
* 
* @param newXMLFile The name of the XML document to loaded into the database.
* @param maxdepth The estimated depth of the new XML document. 
* @param appendToFile The name of the data file where the new document is to be appended to. 
* @param mergeAt The key of the node in the data file that will be the parent of the root node of the new 
*	XML document after merging. 
* @returns Error Code
*/

int LoadingHandler::appendXMLFile(char* newXMLFile,
								  int maxdepth,
								  char* appendToFile,
								  KeyType mergeAt,
								  IndexIncrementalUpdate* indexUpdater)
{
	KeyType rootStartKey, rootEndKey;
	int returnValue = this->physicalDataMng->appendXMLFile(newXMLFile, maxdepth, appendToFile, mergeAt, 
		&rootStartKey, &rootEndKey);

	if (returnValue != NO_ERROR)
		return returnValue;

	//using the rootStartKey and rootEndKey, scan all the nodes in the range
	//and insert each node into the applicable indices
	
	ScanInfo* scanInfo;
	DM_DataNode* cntNode;
	KeyType cntNodeKey;
	serial_t cntNodeRid;

	SelectionCondition* scanCond;
	scanCond = new SelectionCondition(SCAN_ALLNODES, NULL, SCAN_RETURN_THISNODE);

	//don't need a scanRange, because we inserted an XML file with a distinct root (well-formed),
	//and the root of that node is rootStartKey:
	//ScanRange* scanRanges;
	//ScanRangeType* scanRange;
	//scanRanges = new ScanRange(1);
	//scanRange = new ScanRangeType();
	//scanRange->startPos = rootStartKey;
	//scanRange->endPos = rootEndKey;
	//scanRanges->setScanRangeAt(0, scanRange);
	//scanInfo = this->physicalDataMng->startScan(fileInfo, rootStartKey, 0, -1, scanRanges, scanCond, false);

	FileInfoType* fileInfo = this->physicalDataMng->getFileInfo(appendToFile);

	if (fileInfo->overflow) {
		//if there was an overflow, then the append put all the new nodes at the end of the overflow
		//so we just need to scan in the overflow:
		scanInfo = this->physicalDataMng->startOverflowScan(fileInfo, rootStartKey, 0, -1, scanCond);
	}
	else {
		//final parameter of false indicates that we will only scan the ordered portion of the file
		//not the overflow (there was no overflow, so the data was appended to the sorted portion)
		scanInfo = this->physicalDataMng->startScan(fileInfo, rootStartKey, 0, -1, NULL, scanCond, false);
	}

	if (scanInfo != NULL) {
		cntNode = this->physicalDataMng->scanFetchNext(scanInfo);
		while (cntNode!= NULL) {
			cntNodeKey = cntNode->getKey();
			indexUpdater->nodeInsertion(fileInfo, cntNode->getParent(), cntNode);

			cntNode = this->physicalDataMng->scanFetchNext(scanInfo);
		}
		this->physicalDataMng->clearScan(scanInfo);
	}

	// TODO: 
	// find out all the statitical informaiton built on the flie and rebuilt them.

	return returnValue;
}
