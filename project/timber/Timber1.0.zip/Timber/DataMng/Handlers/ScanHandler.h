/*
COPYRIGHT  � 2000-2004 
THE REGENTS OF THE UNIVERSITY OF MICHIGAN
ALL RIGHTS RESERVED

PERMISSION IS GRANTED TO USE, COPY, CREATE DERIVATIVE WORKS AND
REDISTRIBUTE THIS SOFTWARE AND SUCH DERIVATIVE WORKS FOR NONCOMMERCIAL
EDUCATION AND RESEARCH PURPOSES, SO LONG AS NO FEE IS CHARGED, AND SO
LONG AS THE COPYRIGHT NOTICE ABOVE, THIS GRANT OF PERMISSION, AND THE
DISCLAIMER BELOW APPEAR IN ALL COPIES MADE; AND SO LONG AS THE NAME OF
THE UNIVERSITY OF MICHIGAN IS NOT USED IN ANY ADVERTISING OR PUBLICITY
PERTAINING TO THE USE OR DISTRIBUTION OF THIS SOFTWARE WITHOUT
SPECIFIC, WRITTEN PRIOR AUTHORIZATION.

THIS SOFTWARE IS PROVIDED AS IS, WITHOUT REPRESENTATION FROM THE
UNIVERSITY OF MICHIGAN AS TO ITS FITNESS FOR ANY PURPOSE, AND WITHOUT
WARRANTY BY THE UNIVERSITY OF MICHIGAN OF ANY KIND, EITHER EXPRESS OR
IMPLIED, INCLUDING WITHOUT LIMITATION THE IMPLIED WARRANTIES OF
MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE. THE REGENTS OF
THE UNIVERSITY OF MICHIGAN SHALL NOT BE LIABLE FOR ANY DAMAGES,
INCLUDING SPECIAL, INDIRECT, INCIDENTAL, OR CONSEQUENTIAL DAMAGES,
WITH RESPECT TO ANY CLAIM ARISING OUT OF OR IN CONNECTION WITH THE USE
OF THE SOFTWARE, EVEN IF IT HAS BEEN OR IS HEREAFTER ADVISED OF THE
POSSIBILITY OF SUCH DAMAGES.
*/

#ifndef __ScanHandler_H
#define __ScanHandler_H

#include "../stdafx.h"

// for Data Instantiation operation
#define DATA_INSTANTIATION			0
#define DATA_DISCARD				1

// for Data Instantiation scope
#define DI_SPEC_THENODE				0	
#define DI_SPEC_SUBTREE				1	
#define DI_SPEC_SUBTREEWITHCUT		2

/**
* data type DataInstantiationSpecification
* This data structure specify the requirement on data instantiation. 
* 
* @param scope The scope of the data instantiation (the node, the subtree or with cut). 
* @param cutDepth The height of the subtree to instantiate. This is valid only when  the scope is DI_SPEC_SUBTREEWITHCUT. 
* @param element/attribute/content Boolean values which indicate whether element/attribute/content nodes are to be fetched. 
*/
typedef struct {
	int scope;
	int cutDepth;
	bool element;
	bool attribute;
	bool content;
} DataInstantiationSpecification;

/**
* class ScanHandler
* 
* This class support functionality of file scan and those related to scan access. The scan interface can 
* be supported directly through the PhysicalDataMng, except scanFetchNext(), since buffer management is 
* involved here at DataMng level. The functions related to scan access are those supporting data instantiation. 
*
* @see PhysicalDataMng
* @see DataMng
* 
* @author Yuqing Melanie Wu
* @version 1.0
*/

class ScanHandler
{
public:
	/**
	* Constructor
	* Initialize the ScanHandler with the PhysicalDataMng which provide support at physical level.
	*/
	ScanHandler(PhysicalDataMng* pdatamng);
	~ScanHandler(void);

	//static const int SORTED_AND_OVERFLOW = 0;
	//static const int JUST_SORTED = 1;
	//static const int JUST_OVERFLOW = 2;

	/**
	* Scan Interface
	* Start A scan. This is done by calling the startScan method in PhysicalDataMng.
	*
	* @param fileinfo The Information of the file in which scan is to be done.
	* @param nodekey The key of the node which is the root of the subtree to be scanned
	* @param scanmethod The scan method (reserved for later use)
	* @param depth The depth to get into the subtree. Only nodes within "depth" to the subtree root can be result of the scan.					 
	* @param scanrange A list of ranges. Only nodes fall in to  the scan range can be result of the scan. 
	* @param condition The scan condition in CNF format.
	* @param overflowSetting 0=scan both sorted and overflow sections, 1=just sorted, 2=just overflow
	* @returns The scaninfo which contains the inforamtion about the scan, and is to be used later for data fetching. 
	*		returns NULL is the scan is illegal, so, something is wrong in the process. 
	*/
	ScanInfo* startScan(FileInfoType* fileinfo,
		KeyType nodekey,
		int scanmethod,
		int depth,
		ScanRange* scanranges,
		SelectionCondition* condition,
		int overflowSetting = 0);

	/**
	* Scan Interface
	* Finish a scan. This is done by calling the cleartScan method in PhysicalDataMng.
	*
	* @param scaninfo The information about the scan to be finished
	* @returns Error code
	*/
	void clearScan(ScanInfo* scaninfo);

	/**
	* Scan Interface
	* 
	* Fetch the next result of the scan. 
	* The node, which is the next scan result, is fetched through the scan interface of PhysicalDataMng.
	* In addition, this method maintains the memory buffer, if it is required. 
	*
	* @param scaninfo The information of the scan.
	* @writetonodemap A boolean value which indicate whether the result node is to be written to the NodeIDMap.
	* @param idMap The NodeIDMap associated with the data file. 
	* @returns The next result node in the scan. NULL if all nodes have been fetched already. 
	*/
	DM_DataNode* scanFetchNext(ScanInfo* scaninfo,
		bool writetonodemap, 
		NodeIDMap* idMap);

	/**
	* Process Method
	* Instantiate node(s) by bringing the nodes from database to the memory buffer (NodeIDMap). 
	* 
	* @param fileinfo The information of the data file.
	* @param nodekey The key of the node to be instantiated. 
	* @param diSpec The data instantiation specification. 
	* @param idMap The NodeIDMap associated with the data file. 
	* @returns A pointer to the node. 
	*
	* Note: cutting is not currently supported.
	*/
	DM_DataNode* dataInstantiation(FileInfoType* fileinfo,
		KeyType nodekey, 
		DataInstantiationSpecification* diSpec,
		NodeIDMap* idMap);

	/**
	* Process Method
	* Discard nodes from buffer (NodeIDMap). 
	* 
	* @param fileinfo The information of the data file.
	* @param nodekey The key of the node to be discarded from the buffer. 
	* @param diSpec The data instantiation specification which specify what nodes are to be discarded. 
	* @param idMap The NodeIDMap associated with the data file. 
	*
	* Note: cutting is not currently supported.
	*/
	void dataDiscard(KeyType nodekey, 
		DataInstantiationSpecification* diSpec,
		NodeIDMap* idMap);


private:
	/**
	* The PhysicalDataMng which provide support for scan access at physical level
	*/
	PhysicalDataMng* physicalDataMng;

};

//const int ScanHandler::SORTED_AND_OVERFLOW;
//const int ScanHandler::JUST_SORTED;
//const int ScanHandler::JUST_OVERFLOW;


#endif
