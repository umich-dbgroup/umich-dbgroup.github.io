/*
COPYRIGHT  � 2000-2004 
THE REGENTS OF THE UNIVERSITY OF MICHIGAN
ALL RIGHTS RESERVED

PERMISSION IS GRANTED TO USE, COPY, CREATE DERIVATIVE WORKS AND
REDISTRIBUTE THIS SOFTWARE AND SUCH DERIVATIVE WORKS FOR NONCOMMERCIAL
EDUCATION AND RESEARCH PURPOSES, SO LONG AS NO FEE IS CHARGED, AND SO
LONG AS THE COPYRIGHT NOTICE ABOVE, THIS GRANT OF PERMISSION, AND THE
DISCLAIMER BELOW APPEAR IN ALL COPIES MADE; AND SO LONG AS THE NAME OF
THE UNIVERSITY OF MICHIGAN IS NOT USED IN ANY ADVERTISING OR PUBLICITY
PERTAINING TO THE USE OR DISTRIBUTION OF THIS SOFTWARE WITHOUT
SPECIFIC, WRITTEN PRIOR AUTHORIZATION.

THIS SOFTWARE IS PROVIDED AS IS, WITHOUT REPRESENTATION FROM THE
UNIVERSITY OF MICHIGAN AS TO ITS FITNESS FOR ANY PURPOSE, AND WITHOUT
WARRANTY BY THE UNIVERSITY OF MICHIGAN OF ANY KIND, EITHER EXPRESS OR
IMPLIED, INCLUDING WITHOUT LIMITATION THE IMPLIED WARRANTIES OF
MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE. THE REGENTS OF
THE UNIVERSITY OF MICHIGAN SHALL NOT BE LIABLE FOR ANY DAMAGES,
INCLUDING SPECIAL, INDIRECT, INCIDENTAL, OR CONSEQUENTIAL DAMAGES,
WITH RESPECT TO ANY CLAIM ARISING OUT OF OR IN CONNECTION WITH THE USE
OF THE SOFTWARE, EVEN IF IT HAS BEEN OR IS HEREAFTER ADVISED OF THE
POSSIBILITY OF SUCH DAMAGES.
*/

#ifndef __FileHandler_H
#define __FileHandler_H

#include "../stdafx.h"
#include "../SystemCatalog/DynamicFileTable.h"


/**
* class FileHandler
* 
* A Filehandler handles the operations related to data file, including data loading, appending, 
* checking for file existence in database, opening/closeing file, etc. 
* 
* Some of the operations can be done by directly calling the function in PhysicalDataMng that provide the 
* service, such as loading file. Some of them requires extra book-keeping on this Logical Data Management 
* level, such as open file and close file. Some of them could not be done properly at physical data
* management level and require a lot of additional process in this level, such as data appending. 
* 
* @see DynamicFileTalbe
* @see DataMng
* @see PhysicalDataMng
*
* @author Yuqing Melanie Wu
* @version 1.0
*/

class FileHandler
{
public:
	/**
	* Constructor
	* initialize the FileHandler with a pointer to the PhysicalDataMng
	* @param pdatamng A pointer to the PhysicalDataMng
	*/
	FileHandler(PhysicalDataMng* pdatamng);

	~FileHandler(void);

	/**
	* File Interface
	* Find out whether a data file exist in the database
	* @param filename The name of the file we are looking for
	* @returns A boolean value which indicate whether a data file with the given name exists in the database.
	* @see PhysicalDataMng::fileExist
	*/
	bool fileExist(char* filename);

	/**
	* File Interface
	* 
	* Given the name of a data file, open the file and prepare for further operation.
	*
	* This is the first step for all the operations on the file. 
	* Nothing can be done without open the file first.
	*
	* This Method does the following:
	*		find the file in the database
	*		prepare the buffer (NodeIDMap) for the file in memory 
	*		insert an item into DynamicFileTable for this file
	*
	* @param filename The name of the file to be opened
	* @param rootkey The key of the root node in the file (return value)
	* @param capacityChoice/idmapCapacity/rpPolicy/LRURemovePercentage The parameters for NodeIDMap.
	* @returns The dynamic file id assigned to the file. -1 if any error happens, or when no more file can be opened.
	* @see NodeIDMap
	*/
	
	FileIDType openFile(char* XMLFileName,
		KeyType* rootkey, 
		int capacityChoice = -1, 
		int idmapCapacity  = -1, 
		int rpPolicy = -1, 
		float LRURemovePercentage = -1);

	/**
	* File Interface
	* 
	* Close a data file. 
	* 
	* After all operation is done on a file, this file must be closed explicitly in TIMBER. 
	* This is done by remove the item associated with the data file from the DynamicFileTable. No more
	* operation can be applied on the data file (through the DataMng's interface) after the file is closed. 
	* If the file has been changed during the time it is opened, the fileinfo is write out to database 
	* at this time.
	* 
	* @param fileid The dynamic id of the file to be closed. 
	* @param sizeRequirement/replacementTimes The statistical information related to the buffer (NodeIDMap) usage.
	*		These are return values. These info will be provided when the input is not NULL.   
	*/
	void closeFile(FileIDType fileid,
		int* sizeRequirement = NULL,
		int* replacementTimes = NULL);

	/**
	* File Interface 
	*
	* Reorganize a file (most possiblly after updates), to make sure nodes are stored in key order.
	*
	* This is done by directly calling the reorganizeFile function in PhysicalDataMng. 
	* 
	* @param filename The name of the file to be reorganized.
	* @returns Error code.
	*/
	int reorganizeFile(char* filename);

	/**
	* Access Method
	* Get the information about the data file in the database, given the dynamic file id.
	* Get the information  from the DynamicFileTable.
	* 
	* @param fileid The dyanmic file id of the opened data file. 
	* @returns the information about the file. 
	*/
	FileInfoType*	getFileInfo(FileIDType fileid);
	
	/**
	* Access Method
	* Get the NodeIDMap associated with the data file in the database, given the dynamic file id.
	* Get the NodeIDMap from the DynamicFileTable.
	* 
	* @param fileid The dyanmic file id of the opened data file. 
	* @returns The NodeIDMap associated with the data file in the database
	*/
	NodeIDMap*		getNodeIDMap(FileIDType fileid);
	
	/**
	* Process Method
	* Reserve a new ScanID for a file. 
	* This is done by the functions provided by DyanmicFileTable. 
	* 
	* @param fileid The dyanmic file id of the opened data file. 
	* @returns The scan id reserved for the new scan. 
	*/
	ScanIDType		getNewScanID(FileIDType fileid);
	
	/**
	* Access Method
	* Get the scan table item about a scan, given the file id and scan id. 
	* The scan table item, with the matching fileid and scanid, in the DynamicFileTable will be returned.
	* 
	* @param fileid The dynamic file id of the file. 
	* @param scanid The id of the scan. 
	* @param The scan table item, with the matching fileid and scanid. 
	*/
	ScanTableItem*	getScanItem(FileIDType fileid, ScanIDType scanid);
	
	/**
	* Process Method
	* Validate a scan in the DynamicFileTable, given the fileid and the scanid. 
	* The information about the scan is provided here. They will be written to the scan item. 
	* 
	* @param fileid The dynamic file id of the file. 
	* @param scanid The id of the scan. 
	* @param scaninfo The information about the scan. 
	* @param writetonodemap A boolean value which indicate whether the scan results are to be written to the NodeIDMap. 
	*/
	void			validateScan(FileIDType fileid, 
									ScanIDType scanid, 
									ScanInfo* scaninfo,
									bool writetonodemap);
	/**
	* Process Method
	* Invalidate a scan item, with the given fileid and the scan id. 
	* It remove the informaiton associated with the scan from the DynamicFileTable. 
	* @param fileid The dynamic file id of the file. 
	* @param scanid The id of the scan. 
	*/
	void			invalidateScan(FileIDType fileid, 
									ScanIDType scanid);

	/**
	* Set Method
	* Set the information about the data file to the item in the DynamicFileTable
	* that is associated with the file with the given id. 
	* @param fileid The dynamic id of the data file.
	* @param fileinfo The information about the data file. 
	*/
	void			setFileInfo(FileIDType fileid, FileInfoType* fileinfo);

	/**
	* File Interface
	* Get the names of all the data files in the database. 
	* This is done by calling the correspondent function provided by PhyscialDataMng.
	* @param num The total number of data files in the database (return value).
	* @returns The list of names of the data file. 
	*/
	char**			getFileNames(int* num);

	/**
	* Debug Method
	* Print the content of the buffer (NodeIDMap) associated with a data file. 
	* @param fileid The dynamic id of the data file. 
	*/
	void			printNodeIDMap(FileIDType fileid);

private:
	/**
	* The PhyscialDataMng which provides support for the File Interface at the physical level. 
	* @see PhysicalDataMng.
	*/
	PhysicalDataMng* physicalDataMng;

	/**
	* A structure that keeps track of all the files opened in TIMBER.
	* @see DynamicFileTable
	*/
	DynamicFileTable* dynamicFileTable;

};

#endif
