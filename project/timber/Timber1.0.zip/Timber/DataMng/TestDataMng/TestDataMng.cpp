/*
  COPYRIGHT  � 2000-2004 
  THE REGENTS OF THE UNIVERSITY OF MICHIGAN
  ALL RIGHTS RESERVED

  PERMISSION IS GRANTED TO USE, COPY, CREATE DERIVATIVE WORKS AND
  REDISTRIBUTE THIS SOFTWARE AND SUCH DERIVATIVE WORKS FOR NONCOMMERCIAL
  EDUCATION AND RESEARCH PURPOSES, SO LONG AS NO FEE IS CHARGED, AND SO
  LONG AS THE COPYRIGHT NOTICE ABOVE, THIS GRANT OF PERMISSION, AND THE
  DISCLAIMER BELOW APPEAR IN ALL COPIES MADE; AND SO LONG AS THE NAME OF
  THE UNIVERSITY OF MICHIGAN IS NOT USED IN ANY ADVERTISING OR PUBLICITY
  PERTAINING TO THE USE OR DISTRIBUTION OF THIS SOFTWARE WITHOUT
  SPECIFIC, WRITTEN PRIOR AUTHORIZATION.

  THIS SOFTWARE IS PROVIDED AS IS, WITHOUT REPRESENTATION FROM THE
  UNIVERSITY OF MICHIGAN AS TO ITS FITNESS FOR ANY PURPOSE, AND WITHOUT
  WARRANTY BY THE UNIVERSITY OF MICHIGAN OF ANY KIND, EITHER EXPRESS OR
  IMPLIED, INCLUDING WITHOUT LIMITATION THE IMPLIED WARRANTIES OF
  MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE. THE REGENTS OF
  THE UNIVERSITY OF MICHIGAN SHALL NOT BE LIABLE FOR ANY DAMAGES,
  INCLUDING SPECIAL, INDIRECT, INCIDENTAL, OR CONSEQUENTIAL DAMAGES,
  WITH RESPECT TO ANY CLAIM ARISING OUT OF OR IN CONNECTION WITH THE USE
  OF THE SOFTWARE, EVEN IF IT HAS BEEN OR IS HEREAFTER ADVISED OF THE
  POSSIBILITY OF SUCH DAMAGES.
*/


#pragma warning(disable: 4702)
#include "testdatamng.h"
#include <time.h>

#define SIMPLE_COND		0

//#define DEBUG_TEST_NODEIDMAP true
//#define DEBUG_TEST_LOADING true
//#define DEBUG_TEST_SCAN true
// Stelios: All these should go in the preprocessor.

TestDataMng::TestDataMng(lvid_t vold_i, char* filename) :TestClass(vold_i, filename)
{
  this->initTestCode();
}

TestDataMng::~TestDataMng(void)
{
  delete this->dataMng;
} 

void TestDataMng::initTestCode() 
{
  this->testCodeMap.insert(StringIntMapType::value_type("TEST_DM_LOADING", TEST_DM_LOADING));
  this->testCodeMap.insert(StringIntMapType::value_type("TEST_DM_APPENDING", TEST_DM_APPENDING));
  this->testCodeMap.insert(StringIntMapType::value_type("TEST_DM_SCANNING", TEST_DM_SCANNING));
  this->testCodeMap.insert(StringIntMapType::value_type("TEST_DM_UPDATE", TEST_DM_UPDATE));
  this->testCodeMap.insert(StringIntMapType::value_type("TEST_DM_NODEIDMAP", TEST_DM_NODEIDMAP));
  this->testCodeMap.insert(StringIntMapType::value_type("TEST_DM_DATAINSTANTIATION", TEST_DM_DATAINSTANTIATION));

  this->testCodeMap.insert(StringIntMapType::value_type("TEST_DM_SCAN_ALL", TEST_DM_SCAN_ALL));
  this->testCodeMap.insert(StringIntMapType::value_type("TEST_DM_SCAN_SIMPLE_COND", TEST_DM_SCAN_SIMPLE_COND));
  this->testCodeMap.insert(StringIntMapType::value_type("TEST_DM_SCAN_COMPLEX_COND", TEST_DM_SCAN_COMPLEX_COND));
  this->testCodeMap.insert(StringIntMapType::value_type("TEST_DM_SCAN_SIMPLE_RANGE", TEST_DM_SCAN_SIMPLE_RANGE));
  this->testCodeMap.insert(StringIntMapType::value_type("TEST_DM_SCAN_COMPLEX_RANGE", TEST_DM_SCAN_COMPLEX_RANGE));

  this->testCodeMap.insert(StringIntMapType::value_type("TEST_DM_COUNT_NODE", TEST_DM_COUNT_NODE));
  this->testCodeMap.insert(StringIntMapType::value_type("TEST_DM_PRINT_NODE", TEST_DM_PRINT_NODE));

  printf("the choices for TestDataMng are:\n");

  StringIntMapType::iterator item = this->testCodeMap.begin();
  while (item != this->testCodeMap.end())
    {
      printf("%s %d\n", item->first, item->second);
      item++;
    }

	
  strcpy(this->testCodeString[TEST_DM_LOADING], "TEST_DM_LOADING");
  strcpy(this->testCodeString[TEST_DM_APPENDING], "TEST_DM_APPENDING");
  strcpy(this->testCodeString[TEST_DM_SCANNING], "TEST_DM_SCANNING");
  strcpy(this->testCodeString[TEST_DM_UPDATE], "TEST_DM_UPDATE");
  strcpy(this->testCodeString[TEST_DM_NODEIDMAP], "TEST_DM_NODEIDMAP");
  strcpy(this->testCodeString[TEST_DM_DATAINSTANTIATION], "TEST_DM_DATAINSTANTIATION");

  strcpy(this->testCodeString[TEST_DM_SCAN_ALL], "TEST_DM_SCAN_ALL");
  strcpy(this->testCodeString[TEST_DM_SCAN_SIMPLE_COND], "TEST_DM_SCAN_SIMPLE_COND");
  strcpy(this->testCodeString[TEST_DM_SCAN_COMPLEX_COND], "TEST_DM_SCAN_COMPLEX_COND");
  strcpy(this->testCodeString[TEST_DM_SCAN_SIMPLE_RANGE], "TEST_DM_SCAN_SIMPLE_RANGE");
  strcpy(this->testCodeString[TEST_DM_SCAN_COMPLEX_RANGE], "TEST_DM_SCAN_COMPLEX_RANGE");

  strcpy(this->testCodeString[TEST_DM_COUNT_NODE], "TEST_DM_COUNT_NODE");
  strcpy(this->testCodeString[TEST_DM_PRINT_NODE], "TEST_DM_PRINT_NODE");

}

void TestDataMng::runTest()
{
  this->fpPara = fopen(this->filenamePara, "r");

  PhysicalDataMng* physicalDataMng = new PhysicalDataMng(this->volumeID);
  this->dataMng = new DataMng(physicalDataMng);		 

  int testCode = this->getTestCode();

  while (testCode >= 0)
    {
      cout << endl << endl << endl;
      cout << "-------------------------------------------------------------------------" << endl;
      cout << "                      " << testCodeString[testCode] << endl;
      cout << "-------------------------------------------------------------------------" << endl;

      switch (testCode)
        {
        case TEST_DM_LOADING: 
          this->testLoading();
          break;
        case TEST_DM_APPENDING:
          this->testAppending();
          break;
        case TEST_DM_SCANNING:
          this->testScan();
          break;
        case TEST_DM_UPDATE:
          this->testUpdate();
          break;
        case TEST_DM_NODEIDMAP:
          this->testNodeIDMap();
          break;
        case TEST_DM_DATAINSTANTIATION:
          this->testDataInstantiation();
        default:
          fclose(this->fpPara);
          break;
        }
		
      getchar();

      testCode = this->getTestCode();

    }
}


void TestDataMng::testLoading()
{
  char tmpbuf[128];

  int retval;

  int fileNum;
  char filenamewithpath1[200];
  char path[200];
  char filename1[100];

  this->outputChoice = this->getTestCode();
  if (this->outputChoice == TEST_DM_COUNT_NODE)
    retval = fscanf(this->fpPara, "%d", &this->countInterval);

  retval = fscanf(this->fpPara, "%d", &fileNum);
  for (int i=0; i<fileNum; i++)
    {
      retval = fscanf(this->fpPara, "%s", filenamewithpath1);
      PhysicalDataMng::parse_name(filenamewithpath1, path, filename1);

      cout << "******** test loading document: " << filenamewithpath1 << "..." << endl << endl; 

      _strtime( tmpbuf );
      cout << "starting at OS time	" << tmpbuf << endl;

      this->loadXMLFile(filenamewithpath1);
			
      _strtime( tmpbuf );
      cout << "End at OS time	" << tmpbuf << endl;

      cout << endl << "Scan the file after loading...." << endl;
      this->printFile(filename1);
    }

  int num;
  char** names = this->dataMng->getFileNames(&num);
  cout << "After all loading, there are" << num << "files in the system" << endl;
  for (int i=0; i<num; i++)
    cout << i+1 << "	" << names[i] << endl;
}

void TestDataMng::testAppending()
{
	cout << "testAppending requires access to IndexMng now.  Update this test method." << endl;
}
/*
void TestDataMng::testAppending()
{
  char tmpbuf[128];

  int retval;

  char filenamewithpath1[200];
  char filenamewithpath2[200];
  char path[200];
  char filename1[100];
  char filename2[100];

  this->outputChoice = this->getTestCode();
  if (this->outputChoice == TEST_DM_COUNT_NODE)
    retval = fscanf(this->fpPara, "%d", &this->countInterval);

  retval = fscanf(this->fpPara, "%s", filenamewithpath1);
  PhysicalDataMng::parse_name(filenamewithpath1, path, filename1);
  retval = fscanf(this->fpPara, "%s", filenamewithpath2);
  PhysicalDataMng::parse_name(filenamewithpath2, path, filename2);

  cout << "******** test appending: " << filenamewithpath2 << " to " << filenamewithpath2 << "..." << endl << endl; 


  if (!this->dataLoaded(filename1))
    this->loadXMLFile(filenamewithpath1);
  this->printFile(filename1);

  _strtime( tmpbuf );
  cout << "start appending at OS time	" << tmpbuf << endl;
  retval = this->dataMng->appendXMLFile(filenamewithpath2, 100, filename1, 0);
  if (retval < 0)
    cout << "appending problem" << endl;
  cout << "appending successful" << endl;

  _strtime( tmpbuf );
  cout << "end appending at OS time	" << tmpbuf << endl;

  this->printFile(filename1);
}
*/

int TestDataMng::loadXMLFile(char* filenamewithpath)
{
  char filename[100];
  char path[200];
  PhysicalDataMng::parse_name(filenamewithpath, path, filename);
	
  FileIDType fileid;
  KeyType rootkey;
  int retval;

  this->dataMng->beginTransaction();
  retval = this->dataMng->loadXMLFile(filenamewithpath,false);
  if (retval < 0)
    printf("loading problem\n");
  fileid = this->dataMng->openFile(filename, &rootkey);
  if (fileid < 0)
    {
      printf("loading is not successful\n");
      retval = -1;
    }
  else 
    {
      this->dataMng->closeFile(fileid);
      printf("loading successful\n");
      retval = 0;
    }
  this->dataMng->endTransaction();

  return retval;
}


bool TestDataMng::dataLoaded(char* filename)
{
  return this->dataMng->fileExist(filename);
  /*
    bool loaded;
    this->dataMng->beginTransaction();
    KeyType rootkey;
    FileIDType fileid = this->dataMng->openFile(filename, &rootkey);
    if (fileid < 0)
    loaded = false;
    else 
    {
    this->dataMng->closeFile(fileid);
    loaded = true;
    }
    this->dataMng->endTransaction();
    return loaded;
  */
}

void TestDataMng::testScan()
{
  int retval;
  this->outputChoice = this->getTestCode();
  if (this->outputChoice == TEST_DM_COUNT_NODE)
    retval = fscanf(this->fpPara, "%d", &this->countInterval);

  char filenamewithpath[200];
  char path[200];
  char filename[100];

  retval = fscanf(this->fpPara, "%s", filenamewithpath);
  PhysicalDataMng::parse_name(filenamewithpath, path, filename);
		
  if (!this->dataLoaded(filename))
    {
      this->loadXMLFile(filenamewithpath);
      if (!this->dataLoaded(filename))
        {
          cout << "Warning: Could not load the data file for scan testing" << endl;
          return;
        }
    }

  FileIDType fileid;
  ScanIDType scanid;

  KeyType rootkey;
  KeyType cntKey;
  DM_DataNode* node;

  SelectionCondition* scancond;
  DisjunctiveCondition* discond;
  ConjunctiveCondition* concond;
  PredicateCondition* predicate;
  int leftval;
  int op;
  Value* rightval;

  ScanRange* scanRanges;
  ScanRangeType* scanRange;

  int count;

  int testScanNum;
  int scanCode;

  retval = fscanf(this->fpPara, "%d", &testScanNum);

  for (int sn=0; sn < testScanNum; sn++)
    {
      scanCode = this->getTestCode();

      switch (scanCode)
        {
        case TEST_DM_SCAN_ALL:
          {
            printf("------------------------------------------------\n");
            printf("test scan with empty condition (scan the whole document)\n");
				
            this->dataMng->beginTransaction();

            fileid = this->dataMng->openFile(filename, &rootkey);
            if (fileid < 0)
              {
                printf("can not open file with name %s\n", filename);
                return;
              }

            printf("rootkey = %s\n", rootkey.toString());
            cntKey = rootkey;

            discond = new DisjunctiveCondition(0);
            scancond = new SelectionCondition(SCAN_ALLNODES,
                                              discond,
                                              SCAN_RETURN_THISNODE);

            scanid = this->dataMng->startScan(fileid, rootkey, 0, -1, NULL, scancond, false);

            node = this->dataMng->scanFetchNext(fileid, scanid);
            count = 0;
            while (node!= NULL)
              {
                printf("key = %s, endkey = %s, tag = %d\n", 
                       node->getKey().toString(), node->getEndKey().toString(), node->getTag());
                delete node;
                count++;
                node = this->dataMng->scanFetchNext(fileid, scanid);
              }
            printf("totaly number of result = %d\n", count);
				
            retval = this->dataMng->clearScan(fileid, scanid);
            if (retval < 0)
              printf("scan with id %d does not exist\n", scanid);

            this->dataMng->closeFile(fileid);
            printf("call endTransaction from tester::testScan\n");
            this->dataMng->endTransaction();
          }
          break;

        case TEST_DM_SCAN_SIMPLE_COND:
          {
            printf("------------------------------------------------\n");
            printf("test scan with simple condition\n");
				
            for (int targetNodeType = 0; targetNodeType < 4; targetNodeType++)
              for (int leftValueType = 0; leftValueType < 9; leftValueType++)
                for (int opType = 1; opType < 9; opType++)
                  {
                    if ((targetNodeType == ELEMENT_NODE) &
                        (leftValueType == SCAN_LEFTVALUE_NODETAG) &
                        (opType == SCAN_OP_EQ))
                      printf("---\n");

                    scancond = constructScanCond(targetNodeType, 
                                                 leftValueType, opType);
                    scancond->printSelectionCondition();

                    this->dataMng->beginTransaction();

                    fileid = this->dataMng->openFile(filename, &rootkey);
                    if (fileid < 0)
                      {
                        printf("can not open file with name %s\n", filename);
                        return;
                      }

                    printf("rootkey = %s\n", rootkey.toString());
                    cntKey = rootkey;

                    scanid = this->dataMng->startScan(fileid, rootkey, 
                                                      0, -1, NULL, scancond, false);

                    if (scanid >= 0)
                      {
                        node = this->dataMng->scanFetchNext(fileid, scanid);
                        count = 0;
                        while (node!= NULL)
                          {
                            printf("key = %s, endkey = %s, tag = %d\n", 
                                   node->getKey().toString(), node->getEndKey().toString(), node->getTag());
                            delete node;
                            count++;
                            node = this->dataMng->scanFetchNext(fileid, scanid);
                          }
                        printf("totaly number of result = %d\n", count);
								
                        retval = this->dataMng->clearScan(fileid, scanid);
                        if (retval < 0)
                          printf("scan with id %d does not exist\n", scanid);
                      }
                    else 
                      printf("does not open a valid scan\n");
								
                    printf("*******************\n\n");

                    this->dataMng->closeFile(fileid);
                    this->dataMng->endTransaction();
                  }
          }
          break;

        case TEST_DM_SCAN_COMPLEX_COND:
          {
            printf("------------------------------------------------\n");
            printf("test scan with complex condition\n");

            this->dataMng->beginTransaction();

            fileid = this->dataMng->openFile(filename, &rootkey);
            if (fileid < 0)
              {
                printf("can not open file with name %s\n", filename);
                return;
              }

            printf("rootkey = %s\n", rootkey);
            cntKey = rootkey;

            discond = new DisjunctiveCondition(2);
            concond = new ConjunctiveCondition(3);
							
            leftval = SCAN_LEFTVALUE_NODETAG;
            op = SCAN_OP_EQ;
            rightval = new Value(STRING_VALUE);
            rightval->setStrValue("Degree");	
            predicate = new PredicateCondition(leftval, op, rightval);
            concond->insertCond(predicate);

            leftval = SCAN_LEFTVALUE_HASATTRIBUTE;
            op = SCAN_OP_EQ;
            rightval = new Value(STRING_VALUE);
            rightval->setStrValue("id");	
            predicate = new PredicateCondition(leftval, op, rightval);
            concond->insertCond(predicate);

            leftval = SCAN_LEFTVALUE_ELEMENTCONTENT;
            op = SCAN_OP_EQ;
            rightval = new Value(STRING_VALUE);
            rightval->setStrValue("Masters");	
            predicate = new PredicateCondition(leftval, op, rightval);
            concond->insertCond(predicate);

            discond->insertCond(concond);

            concond = new ConjunctiveCondition(2);

            leftval = SCAN_LEFTVALUE_NODETAG;
            op = SCAN_OP_EQ;
            rightval = new Value(STRING_VALUE);
            rightval->setStrValue("Student");	
            predicate = new PredicateCondition(leftval, op, rightval);
            concond->insertCond(predicate);

            leftval = SCAN_LEFTVALUE_CHILDNUMBER;
            op = SCAN_OP_EQ;
            rightval = new Value(INT_VALUE);
            rightval->setIntValue(2);	
            predicate = new PredicateCondition(leftval, op, rightval);
            concond->insertCond(predicate);

            discond->insertCond(concond);

            scancond = new SelectionCondition(ELEMENT_NODE,
                                              discond,
                                              SCAN_RETURN_THISNODE);

            scanid = this->dataMng->startScan(fileid, rootkey, 0, -1, NULL, scancond, false);

            node = this->dataMng->scanFetchNext(fileid, scanid);
            count = 0;
            while (node!= NULL)
              {
                printf("key = %s, endkey = %s, tag = %d\n", 
                       node->getKey().toString(), node->getEndKey().toString(), node->getTag());
                delete node;
                count++;
                node = this->dataMng->scanFetchNext(fileid, scanid);
              }
            printf("totaly number of result = %d\n", count);
				
            retval = this->dataMng->clearScan(fileid, scanid);
            if (retval < 0)
              printf("scan with id %d does not exist\n", scanid);

            this->dataMng->closeFile(fileid);
            printf("call endTransaction from tester::testScan\n");
            this->dataMng->endTransaction();
          }
          break;

        case TEST_DM_SCAN_SIMPLE_RANGE:
          {
            printf("------------------------------------------------\n");
            printf("test scan with scan range\n");

            this->dataMng->beginTransaction();

            fileid = this->dataMng->openFile(filename, &rootkey);
            if (fileid < 0)
              {
                printf("can not open file with name %s\n", filename);
                return;
              }

            printf("rootkey = %s\n", rootkey);
            cntKey = rootkey;

            discond = new DisjunctiveCondition(1);
            concond = new ConjunctiveCondition(1);
							
            leftval = SCAN_LEFTVALUE_NODETAG;
            op = SCAN_OP_EQ;
            rightval = new Value(STRING_VALUE);
            rightval->setStrValue("Degree");	
            predicate = new PredicateCondition(leftval, op, rightval);

            concond->insertCond(predicate);
            discond->insertCond(concond);

            scancond = new SelectionCondition(ELEMENT_NODE,
                                              discond,
                                              SCAN_RETURN_THISNODE);

            scanRanges = new ScanRange(1);
            scanRange = new ScanRangeType();
            scanRange->startPos = 35;
            scanRange->endPos = 50;
            scanRanges->setScanRangeAt(0, scanRange);

            scanid = this->dataMng->startScan(fileid, rootkey, 0, -1, scanRanges, scancond, false);

            node = this->dataMng->scanFetchNext(fileid, scanid);
            count = 0;
            while (node!= NULL)
              {
                printf("key = %s, endkey = %s, tag = %d\n", 
                       node->getKey().toString(), node->getEndKey().toString(), node->getTag());
                delete node;
                count++;
                node = this->dataMng->scanFetchNext(fileid, scanid);
              }
            printf("totaly number of result = %d\n", count);
				
            retval = this->dataMng->clearScan(fileid, scanid);
            if (retval < 0)
              printf("scan with id %d does not exist\n", scanid);

            this->dataMng->closeFile(fileid);
            printf("call endTransaction from tester::testScan\n");
            this->dataMng->endTransaction();
          }
          break;	

        case TEST_DM_SCAN_COMPLEX_RANGE:
          {
          }
          break;

        default:
          printf("not valid scan test code\n");
          break;
        }
    }
}

void TestDataMng::testUpdate() {}
/*
void TestDataMng::testUpdate()
{
  int retval;

  this->outputChoice = this->getTestCode();
  if (this->outputChoice == TEST_DM_COUNT_NODE)
    retval = fscanf(this->fpPara, "%d", &this->countInterval);

  char filenamewithpath[200];
  char filename[100];
  char path[200];
	
  retval = fscanf(this->fpPara, "%s", filenamewithpath);
  PhysicalDataMng::parse_name(filenamewithpath, path, filename);

  if (!this->dataLoaded(filename))
    {
      this->loadXMLFile(filenamewithpath);
      if (!this->dataLoaded(filename))
        {
          printf("could not load the data file for scan testing\n");
          return;
        }
    }

  FileIDType fileid;
  ScanIDType scanid;

  KeyType rootkey;
  DM_DataNode* node;

  SelectionCondition* scancond;
  DisjunctiveCondition* discond;
  ConjunctiveCondition* concond;
  PredicateCondition* predicate;
  Value* rightval;

  // used for insertion
  KeyType newEleKey;
  KeyType newTextKey;
  KeyType newAttrKey;
  DM_ElementNode* newEleNode; 
  DM_TextNode* newTextNode;
  DM_AttributeNode* newAttrNode;

  this->dataMng->beginTransaction();
  fileid = this->dataMng->openFile(filename, &rootkey);
  printf("the data in the database before update\n");
  this->fullScanSubtree(fileid, rootkey);
  this->dataMng->closeFile(fileid);
  this->dataMng->endTransaction();

  printf("\n------------------------------------------\n");
  printf("test node modification\n");

  this->dataMng->beginTransaction();
  fileid = this->dataMng->openFile(filename, &rootkey);
	
  discond = new DisjunctiveCondition(1);
  concond = new ConjunctiveCondition(1);

  rightval = new Value(STRING_VALUE);
  rightval->setStrValue("Degree");
  predicate = new PredicateCondition(SCAN_LEFTVALUE_NODETAG, SCAN_OP_EQ, rightval);

  concond->insertCond(predicate);
  discond->insertCond(concond);

  scancond = new SelectionCondition(ELEMENT_NODE,
                                    discond,
                                    SCAN_RETURN_THISNODE);

  scanid = this->dataMng->startScan(fileid, rootkey, 
                                    0, -1, NULL, scancond, false);

  if (scanid >= 0)
    {
      node = this->dataMng->scanFetchNext(fileid, scanid);
      while (node!= NULL)
        {
          printf("node to be modified: key = %s, endkey = %s, tag = %d\n", 
                 node->getKey().toString(), node->getEndKey().toString(), node->getTag());

          node->setTag(23);
          printf("modify the node to: key = %s, endkey = %s, tag = %d\n", 
                 node->getKey().toString(), node->getEndKey().toString(), node->getTag());
	
          this->dataMng->update(fileid, DATAMNG_UPDATEOP_MODIFYNODE, 
                                node->getKey(), -1, node);

          delete node; 
          node = this->dataMng->scanFetchNext(fileid, scanid);
        }
      retval = this->dataMng->clearScan(fileid, scanid);
    }
  else 
    printf("error reported while starting scan\n");

  printf("\nfetching all modes after modification\n");

  this->dataMng->closeFile(fileid);
  this->dataMng->endTransaction();
	
  this->dataMng->beginTransaction();
  fileid = this->dataMng->openFile(filename, &rootkey);
  this->fullScanSubtree(fileid, rootkey);
  this->dataMng->closeFile(fileid);
  this->dataMng->endTransaction();

  printf("\n------------------------------------------\n");
  printf("test leaf node insertion\n");
  printf("insert middle name for each person\n");

  this->dataMng->beginTransaction();
  fileid = this->dataMng->openFile(filename, &rootkey);
	
  newEleNode = new DM_ElementNode(0,0,27);
  newTextNode = new DM_TextNode(0,0,"C.");

  char* attrname = "id";
  Value* attrvalue = new Value(STRING_VALUE);
  attrvalue->setStrValue("0001");	
  newAttrNode = new DM_AttributeNode(2,3,1,&attrname, &attrvalue, 100);

  discond = new DisjunctiveCondition(1);
  concond = new ConjunctiveCondition(1);

  rightval = new Value(STRING_VALUE);
  rightval->setStrValue("Name");
  predicate = new PredicateCondition(SCAN_LEFTVALUE_NODETAG, SCAN_OP_EQ, rightval);

  concond->insertCond(predicate);
  discond->insertCond(concond);

  scancond = new SelectionCondition(ELEMENT_NODE,
                                    discond,
                                    SCAN_RETURN_THISNODE);

  scanid = this->dataMng->startScan(fileid, rootkey, 
                                    0, -1, NULL, scancond, false);

  if (scanid >= 0)
    {
      node = this->dataMng->scanFetchNext(fileid, scanid);
      while (node!= NULL)
        {			
          node->printValue();
			
          printf("insert element node Middle\n");
          newEleKey = this->dataMng->update(fileid, DATAMNG_UPDATEOP_INSERTLEAFNODE, 
                                            node->getKey(), 1, newEleNode);
          printf("insert element content for element node Middle\n");
          newTextKey = this->dataMng->update(fileid, DATAMNG_UPDATEOP_INSERTLEAFNODE, 
                                             newEleKey, 0, newTextNode);
          printf("insert attribute for element node Middle\n");
          newAttrKey = this->dataMng->update(fileid, DATAMNG_UPDATEOP_INSERTLEAFNODE, 
                                             newEleKey, -1, newAttrNode);


          delete node; 
          break;
        }
		
      retval = this->dataMng->clearScan(fileid, scanid);
    }
  else 
    printf("error reported while starting scan\n");

  delete newEleNode;
  delete newTextNode;
  delete newAttrNode;

  printf("\nfetching all modes after modification\n");
  this->fullScanSubtree(fileid, rootkey);

  this->dataMng->closeFile(fileid);
  this->dataMng->endTransaction();

  printf("\n------------------------------------------\n");
  printf("test non-leaf node insertion\n");
  printf("insert element 'final-degree' between 'degree' and 'Ph.D' value\n");


  //this->dataMng->beginTransaction();
  //fileid = this->dataMng->openFile(filename, &rootkey);
	
  //newEleNode = new DM_ElementNode(0,0,24);

  //discond = new DisjunctiveCondition(1);
  //concond = new ConjunctiveCondition(1);

  //rightval = new Value(STRING_VALUE);
  //rightval->setStrValue("Ph.D.");
  //predicate = new PredicateCondition(SCAN_LEFTVALUE_VALUE, SCAN_OP_EQ, rightval);

  //concond->insertCond(predicate);
  //discond->insertCond(concond);

  //scancond = new SelectionCondition(TEXT_NODE,
  //                                  discond,
  //                                  SCAN_RETURN_THISNODE);

  //scanid = this->dataMng->startScan(fileid, rootkey, 
  //                                  0, -1, NULL, scancond, false);

  //if (scanid >= 0)
  //  {
  //    node = this->dataMng->scanFetchNext(fileid, scanid);
  //    while (node!= NULL)
  //      {	
  //        newEleKey = this->dataMng->update(fileid, DATAMNG_UPDATEOP_INSERTNONLEAFNODE, 
  //                                          node->getParent(), 0, newEleNode);
  //        delete node;
  //        break;
  //        //node = this->dataMng->scanFetchNext(fileid, scanid);
  //      }
  //    retval = this->dataMng->clearScan(fileid, scanid);
  //  }
  //else 
  //  printf("error reported while starting scan\n");

  //delete newEleNode;

  //printf("\nfetching all modes after modification\n");
  //this->fullScanSubtree(fileid, rootkey);

  //this->dataMng->closeFile(fileid);
  //this->dataMng->endTransaction();

  //printf("\n------------------------------------------\n");
  //printf("test leaf node deletion\n");



  //this->dataMng->beginTransaction();
  //fileid = this->dataMng->openFile(filename, &rootkey);
	
  //discond = new DisjunctiveCondition(1);
  //concond = new ConjunctiveCondition(1);

  //rightval = new Value(STRING_VALUE);
  //rightval->setStrValue("Masters");
  //predicate = new PredicateCondition(SCAN_LEFTVALUE_VALUE, SCAN_OP_EQ, rightval);

  //concond->insertCond(predicate);
  //discond->insertCond(concond);

  //scancond = new SelectionCondition(TEXT_NODE,
  //                                  discond,
  //                                  SCAN_RETURN_THISNODE);

  //scanid = this->dataMng->startScan(fileid, rootkey, 
  //                                  0, -1, NULL, scancond, false);

  //if (scanid >= 0)
  //  {
  //    node = this->dataMng->scanFetchNext(fileid, scanid);
  //    while (node!= NULL)
  //      {
  //        printf("node to delte: key = %s, endkey = %s, text = %s\n", 
  //               node->getKey().toString(), node->getEndKey().toString(), ((DM_TextNode*) node)->getCharValue());


  //        this->dataMng->update(fileid, DATAMNG_UPDATEOP_DELETENODE, 
  //                              node->getKey(), -1, NULL);
  //        delete node; 
  //        node = this->dataMng->scanFetchNext(fileid, scanid);
  //      }
  //    retval = this->dataMng->clearScan(fileid, scanid);
  //  }
  //else 
  //  printf("error reported while starting scan\n");

  //printf("\nfetching all modes after modification\n");
  //this->fullScanSubtree(fileid, rootkey);

  //this->dataMng->closeFile(fileid);
  //this->dataMng->endTransaction();

  //printf("\n------------------------------------------\n");
  //printf("test nonleaf node deletion\n");
  //printf("delete the first 'name' element found\n");



  //this->dataMng->beginTransaction();
  //fileid = this->dataMng->openFile(filename, &rootkey);
	
  //discond = new DisjunctiveCondition(1);
  //concond = new ConjunctiveCondition(1);

  //rightval = new Value(STRING_VALUE);
  //rightval->setStrValue("Name");
  //predicate = new PredicateCondition(SCAN_LEFTVALUE_NODETAG, SCAN_OP_EQ, rightval);

  //concond->insertCond(predicate);
  //discond->insertCond(concond);

  //scancond = new SelectionCondition(ELEMENT_NODE,
  //                                  discond,
  //                                  SCAN_RETURN_THISNODE);

  //scanid = this->dataMng->startScan(fileid, rootkey, 
  //                                  0, -1, NULL, scancond, false);

  //if (scanid >= 0)
  //  {
  //    node = this->dataMng->scanFetchNext(fileid, scanid);
  //    while (node!= NULL)
  //      {
  //        printf("node to delete: key = %s, endkey = %s, tag = %d\n", 
  //               node->getKey().toString(), node->getEndKey().toString(), node->getTag());


  //        this->dataMng->update(fileid, DATAMNG_UPDATEOP_DELETENODE, 
  //                              node->getKey(), -1, NULL);

  //        delete node; 
  //        break;
  //        //node = this->dataMng->scanFetchNext(fileid, scanid);
  //      }
  //    retval = this->dataMng->clearScan(fileid, scanid);
  //  }
  //else 
  //  printf("error reported while starting scan\n");

  //printf("\nfetching all modes after modification\n");
  //this->fullScanSubtree(fileid, rootkey);

  //this->dataMng->closeFile(fileid);
  //this->dataMng->endTransaction();



  printf("------------------------------------------------\n");
  printf("reorganize the file\n");

  this->dataMng->reorganizeFile(filename);

  this->dataMng->beginTransaction();
  fileid = this->dataMng->openFile(filename, &rootkey);

  this->fullScanSubtree(fileid, rootkey);

  this->dataMng->closeFile(fileid);
  this->dataMng->endTransaction();

  printf("\n------------------------------------------\n");
  printf("test subtree deletion\n");

  this->dataMng->beginTransaction();
  fileid = this->dataMng->openFile(filename, &rootkey);
	

  discond = new DisjunctiveCondition(1);
  concond = new ConjunctiveCondition(1);

  rightval = new Value(STRING_VALUE);
  rightval->setStrValue("NewDgr");
  predicate = new PredicateCondition(SCAN_LEFTVALUE_NODETAG, SCAN_OP_EQ, rightval);

  concond->insertCond(predicate);
  discond->insertCond(concond);

  scancond = new SelectionCondition(ELEMENT_NODE,
                                    discond,
                                    SCAN_RETURN_THISNODE);

  scanid = this->dataMng->startScan(fileid, rootkey, 
                                    0, -1, NULL, scancond, false);

  if (scanid >= 0)
    {
      node = this->dataMng->scanFetchNext(fileid, scanid);
      while (node!= NULL)
        {
          printf("root node of the subtree to delete: key = %s, endkey = %s, tag = %d\n", 
                 node->getKey().toString(), node->getEndKey().toString(), node->getTag());
          this->dataMng->update(fileid, DATAMNG_UPDATEOP_DELETESUBTREE, 
                                node->getKey(), -1, NULL);

          delete node; 
          break;
          //node = this->dataMng->scanFetchNext(fileid, scanid);
        }
      retval = this->dataMng->clearScan(fileid, scanid);
    }
  else 
    printf("error reported while starting scan\n");

  printf("\nfetching all modes after modification\n");
  this->fullScanSubtree(fileid, rootkey);

  this->dataMng->closeFile(fileid);
  this->dataMng->endTransaction();

  printf("------------------------------------------------\n");
  printf("scan the document after modification\n");
  printf("scan a subtree of name (newly inserted node should appear here\n");

  this->dataMng->beginTransaction();
  fileid = this->dataMng->openFile(filename, &rootkey);

  this->fullScanSubtree(fileid, 2);

  this->dataMng->closeFile(fileid);
  this->dataMng->endTransaction();


  printf("------------------------------------------------\n");
  printf("reorganize the file\n");

  this->dataMng->reorganizeFile(filename);

  this->dataMng->beginTransaction();
  fileid = this->dataMng->openFile(filename, &rootkey);

  this->fullScanSubtree(fileid, rootkey);

  this->dataMng->closeFile(fileid);
  this->dataMng->endTransaction();


}
*/

void TestDataMng::testNodeIDMap()
{
  int retval;

  char filenamewithpath[200];
  char filename[100];
  char path[200];
	
  retval = fscanf(this->fpPara, "%s", filenamewithpath);
  PhysicalDataMng::parse_name(filenamewithpath, path, filename);

  if (!this->dataLoaded(filename))
    {
      this->loadXMLFile(filenamewithpath);
      if (!this->dataLoaded(filename))
        {
          printf("could not load the data file for scan testing\n");
          return;
        }
    }

  int parameterNum;
  int parameters[5][10];
  float LRUpara[10];

  fscanf(this->fpPara, "%d", &parameterNum);
  for (int i=0; i<parameterNum; i++)
    {
      fscanf(this->fpPara, "%d %d %d %f", 
             &(parameters[i][0]), &(parameters[i][1]), &(parameters[i][2]), 
             &(LRUpara[i]));
      cout << "NodeIDMap choice " << i << " is ("
           << parameters[i][0] << ", "
           << parameters[i][1] << ", "
           << parameters[i][2] << ", "
           << LRUpara[i] << ")" << endl;
    }

  FileIDType fileid;

  KeyType rootkey;
  KeyType cntKey;

  SelectionCondition* scancond;

  // test node id map by getting node one by one
  printf("------------------------------------------------\n");
  printf("get node one by one\n");

  for (i=0; i<parameterNum; i++)
    {
      printf("\n\n\n\n");
      this->dataMng->beginTransaction();

      cout << "Before calling openFile:" << endl;
      cout << "NodeIDMap choice " << i << " is ("
           << parameters[i][0] << ", "
           << parameters[i][1] << ", "
           << parameters[i][2] << ", "
           << LRUpara[i] << ")" << endl;

      fileid = this->dataMng->openFile(filename, &rootkey, 
                                       parameters[i][0], parameters[i][1], 
                                       parameters[i][2], 
                                       LRUpara[i]);
      if (fileid < 0)
        {
          printf("can not open file with name %s\n", filename);
          return;
        }

      printf("rootkey = %s\n", rootkey.toString());
      cntKey = rootkey;

      for (int j=0; j<50; j++)
        {
          this->dataMng->getDataNode(fileid, j, true);

          if (j > 10)
            this->dataMng->getDataNode(fileid, j-10, true);
        }

      this->dataMng->closeFile(fileid);
      this->dataMng->endTransaction();
    }


  // test node id map by doing scans
  printf("\n\n------------------------------------------------\n");
  printf("get node by scan\n");


  for (i=0; i<parameterNum; i++)
    {
      printf("\n\n\n\n");
      this->dataMng->beginTransaction();
      fileid = this->dataMng->openFile(filename, &rootkey, 
                                       parameters[i][0], parameters[i][1], 
                                       parameters[i][2], 
                                       LRUpara[i]);
      if (fileid < 0)
        {
          printf("can not open file with name %s\n", filename);
          return;
        }

      printf("rootkey = %s\n", rootkey.toString());
      cntKey = rootkey;

      scancond = new SelectionCondition(SCAN_ALLNODES,
                                        NULL,
                                        SCAN_RETURN_THISNODE);

      ScanIDType scanid;
      DM_DataNode* node;

      scanid = this->dataMng->startScan(fileid, rootkey, 
                                        0, -1, NULL, scancond, true);

      if (scanid >= 0)
        {
          node = this->dataMng->scanFetchNext(fileid, scanid);
          while (node!= NULL)
            {
              printf("key = %s, endkey = %s, level = %d, parent = %s, prevSibling = %s, next Sibling = %s, ",  
                     node->getKey().toString(), node->getEndKey().toString(), node->getLevel(), 
                     node->getParent().toString(), node->getPrevSibling().toString(), node->getNextSibling().toString());
              if ((node->getFlag() == ELEMENT_NODE) || (node->getFlag() == DOCUMENT_NODE))
                printf("tag = %d, childnumber = %d, firstchild = %s, lastchild = %s\n",
                       node->getTag(),	node->getChildNumber(), 
                       node->getFirstChild().toString(), node->getLastChild().toString());
              else if (node->getFlag() == TEXT_NODE)
                printf("text = %s\n ", ((DM_TextNode*) node)->getCharValue());
              else if (node->getFlag() == ATTRIBUTE_NODE)
                printf(" attribute-node\n");

              node = this->dataMng->scanFetchNext(fileid, scanid);
            }
          printf("after fetching the last node\n");
          this->dataMng->clearScan(fileid, scanid);
        }
      else 
        printf("error reported while starting scan\n");

      this->dataMng->closeFile(fileid);
      this->dataMng->endTransaction();

    }
	
}

void TestDataMng::testDataInstantiation()
{
  int retval;

  char filenamewithpath[200];
  char filename[100];
  char path[200];
	
  retval = fscanf(this->fpPara, "%s", filenamewithpath);
  PhysicalDataMng::parse_name(filenamewithpath, path, filename);

  if (!this->dataLoaded(filename))
    {
      this->loadXMLFile(filenamewithpath);
      if (!this->dataLoaded(filename))
        {
          printf("could not load the data file for scan testing\n");
          return;
        }
    }


  FileIDType fileid;
  ScanIDType scanid;
  KeyType rootkey;
  DM_DataNode* datanode;

  this->dataMng->beginTransaction();	
  fileid = this->dataMng->openFile(filename, &rootkey);
  if (fileid < 0)
    {
      printf("can not open file with name %s\n", filename);
      this->dataMng->endTransaction();
      return;
    }
  this->dataMng->closeFile(fileid);
  this->dataMng->endTransaction();

  this->printFile(filename);

  SelectionCondition* scancond;
  DisjunctiveCondition* discond;
  ConjunctiveCondition* concond;
  PredicateCondition* predicate;
  int leftval;
  int op;
  Value* rightval;

  DataInstantiationSpecification diSpec[10] = {DI_SPEC_THENODE, -1, true, false, false,
                                               DI_SPEC_THENODE, -1, true, true, false,
                                               DI_SPEC_THENODE, -1, true, true, true,
                                               DI_SPEC_THENODE, -1, false, true, true,
                                               DI_SPEC_THENODE, -1, false, false, true,

                                               DI_SPEC_SUBTREE, -1, true, false, false,
                                               DI_SPEC_SUBTREE, -1, true, true, false,
                                               DI_SPEC_SUBTREE, -1, true, true, true,
                                               DI_SPEC_SUBTREE, -1, false, true, true,
                                               DI_SPEC_SUBTREE, -1, false, false, true};


  DataInstantiationSpecification ddSpec[10] = {DI_SPEC_THENODE, -1, true, false, false,
                                               DI_SPEC_THENODE, -1, false, true, false,
                                               DI_SPEC_THENODE, -1, false, false, true,
                                               DI_SPEC_THENODE, -1, false, true, true,
                                               DI_SPEC_THENODE, -1, false, false, true,

                                               DI_SPEC_THENODE, -1, true, false, false,
                                               DI_SPEC_THENODE, -1, true, true, false,
                                               DI_SPEC_SUBTREE, -1, false, true, true,
                                               DI_SPEC_SUBTREE, -1, false, false, true,
                                               DI_SPEC_SUBTREE, -1, false, false, true};




  discond = new DisjunctiveCondition(1);
  concond = new ConjunctiveCondition(1);
		
  for (int i=0; i<10; i++)
    {
      this->dataMng->beginTransaction();
      fileid = this->dataMng->openFile(filename, &rootkey);

      printf("\n\n*********************************** The %dth instantiation setting  *************************\n", i);
      printf("\n\n DISpec = %d, %d, %d, %d, %d\n", 
             diSpec[i].scope, diSpec[i].cutDepth,
             diSpec[i].element, diSpec[i].attribute, diSpec[i].content);

      discond = new DisjunctiveCondition(1);
      concond = new ConjunctiveCondition(1);
		
      leftval = SCAN_LEFTVALUE_NODETAG;
      op = SCAN_OP_EQ;
      rightval = new Value(STRING_VALUE);
      rightval->setStrValue("Student");	
      predicate = new PredicateCondition(leftval, op, rightval);
		
      concond->insertCond(predicate);
      discond->insertCond(concond);
      scancond = new SelectionCondition(ELEMENT_NODE, discond, SCAN_RETURN_THISNODE);

      scanid = this->dataMng->startScan(fileid, rootkey, 0, -1, NULL, scancond, false);
      datanode = this->dataMng->scanFetchNext(fileid, scanid);

      while (datanode != NULL)
        {
          this->dataMng->dataInstantiation(fileid, datanode->getKey(), &diSpec[i]);
          datanode = this->dataMng->scanFetchNext(fileid, scanid);
        }

      this->dataMng->clearScan(fileid, scanid);
      this->dataMng->printNodeIDMap(fileid);
		
      printf("\n\n*********************************** The %dth dsicard setting  *************************\n", i);
      printf("\n\n DISpec = %d, %d, %d, %d, %d\n", 
             ddSpec[i].scope, ddSpec[i].cutDepth,
             ddSpec[i].element, ddSpec[i].attribute, ddSpec[i].content);

      discond = new DisjunctiveCondition(1);
      concond = new ConjunctiveCondition(1);
		
      leftval = SCAN_LEFTVALUE_NODETAG;
      op = SCAN_OP_EQ;
      rightval = new Value(STRING_VALUE);
      if (i<5)
        rightval->setStrValue("Student");	
      else rightval->setStrValue("Degree");
      predicate = new PredicateCondition(leftval, op, rightval);
		
      concond->insertCond(predicate);
      discond->insertCond(concond);
      scancond = new SelectionCondition(ELEMENT_NODE, discond, SCAN_RETURN_THISNODE);

      scanid = this->dataMng->startScan(fileid, rootkey, 0, -1, NULL, scancond, false);
      datanode = this->dataMng->scanFetchNext(fileid, scanid);

      while (datanode != NULL)
        {
          this->dataMng->dataDiscard(fileid, datanode->getKey(), &ddSpec[i]);
          datanode = this->dataMng->scanFetchNext(fileid, scanid);
        }

      this->dataMng->clearScan(fileid, scanid);
      this->dataMng->printNodeIDMap(fileid);

      this->dataMng->closeFile(fileid);
      this->dataMng->endTransaction();
    }
}





SelectionCondition* TestDataMng::constructScanCond( int targetNode,
                                                   int leftValue,
                                                   int op)
												   
{
  SelectionCondition* scancond;
  DisjunctiveCondition* discond;
  ConjunctiveCondition* concond;
  PredicateCondition* predicate;
  Value* rightval;
  rightval = NULL;

  discond = new DisjunctiveCondition(1);
  concond = new ConjunctiveCondition(1);
		

  switch (leftValue)
    {
    case SCAN_LEFTVALUE_VALUE:
      rightval = new Value(STRING_VALUE);
      rightval->setStrValue("Degree");
      break;

    case SCAN_LEFTVALUE_LENGTH:
      rightval = new Value(INT_VALUE);
      rightval->setIntValue(6);
      break;
    case SCAN_LEFTVALUE_XMLFILENAME:
      rightval = new Value(STRING_VALUE);
      rightval->setStrValue("testdata1.xml");
      break;
    case SCAN_LEFTVALUE_NODETAG:
      rightval = new Value(STRING_VALUE);
      rightval->setStrValue("Degree");
      break;
    case SCAN_LEFTVALUE_CHILDNUMBER:
      rightval = new Value(INT_VALUE);
      rightval->setIntValue(2);
      break;
    case SCAN_LEFTVALUE_ATTRIBUTENUMBER:
      rightval = new Value(INT_VALUE);
      rightval->setIntValue(1);
      break;
    case SCAN_LEFTVALUE_HASCHILD:
      rightval = new Value(STRING_VALUE);
      rightval->setStrValue("Degree");
      break;
    case SCAN_LEFTVALUE_HASATTRIBUTE:
      rightval = new Value(STRING_VALUE);
      rightval->setStrValue("id");
      break;
    case SCAN_LEFTVALUE_ELEMENTCONTENT:
      rightval = new Value(STRING_VALUE);
      rightval->setStrValue("Ph.D");
      break;

    }
	
  predicate = new PredicateCondition(leftValue, op, rightval);

  concond->insertCond(predicate);
  discond->insertCond(concond);

  scancond = new SelectionCondition(targetNode,
                                    discond,
                                    SCAN_RETURN_THISNODE);
  return scancond;

}


void TestDataMng::scanSubTreeForTag(FileIDType fileid, 
                                    KeyType rootkey, 
                                    char* tag)
{
  if (tag == NULL)
    this->fullScanSubtree(fileid, rootkey);
  else
    {
      SelectionCondition* scancond;
      DisjunctiveCondition* discond;
      ConjunctiveCondition* concond;
      PredicateCondition* predicate;
      Value* rightval;

      discond = new DisjunctiveCondition(1);
      concond = new ConjunctiveCondition(1);
					
      rightval = new Value(STRING_VALUE);
      rightval->setStrValue(tag);	
      predicate = new PredicateCondition(SCAN_LEFTVALUE_NODETAG, SCAN_OP_EQ, rightval);

      concond->insertCond(predicate);
      discond->insertCond(concond);

      scancond = new SelectionCondition(ELEMENT_NODE,
                                        discond,
                                        SCAN_RETURN_THISNODE);
      this->scanAndPrint(fileid, rootkey, scancond, NULL);
    }

}

void TestDataMng::fullScanSubtree(FileIDType fileid,
                                  KeyType rootkey)
{
  SelectionCondition* scancond;

  scancond = new SelectionCondition(SCAN_ALLNODES,
                                    NULL,
                                    SCAN_RETURN_THISNODE);
  this->scanAndPrint(fileid, rootkey, scancond, NULL);
}

void TestDataMng::scanAndPrint(FileIDType fileid,
                               KeyType rootkey, 
                               SelectionCondition* scancond, 
                               ScanRange* ranges)
{
  ScanIDType scanid;
  DM_DataNode* node;

  scanid = this->dataMng->startScan(fileid, rootkey, 
                                    0, -1, ranges, scancond, false);

  int count = 0;
  if (scanid >= 0)
    {
      node = this->dataMng->scanFetchNext(fileid, scanid);
      while (node!= NULL)
        {
          count++;

          if (this->outputChoice == TEST_DM_PRINT_NODE)
            {
              printf("key = %s, endkey = %s, level = %d, parent = %s, prevSibling = %s, next Sibling = %s, ",  
                     node->getKey().toString(), node->getEndKey().toString(), node->getLevel(), 
                     node->getParent().toString(), node->getPrevSibling().toString(), node->getNextSibling().toString());
              if ((node->getFlag() == ELEMENT_NODE) || (node->getFlag() == DOCUMENT_NODE))
                printf("tag = %d, childnumber = %d, firstchild = %s, lastchild = %s\n",
                       node->getTag(),	node->getChildNumber(), 
                       node->getFirstChild().toString(), node->getLastChild().toString());
              else if (node->getFlag() == TEXT_NODE)
                printf("text = %s\n ", ((DM_TextNode*) node)->getCharValue());
              else if (node->getFlag() == ATTRIBUTE_NODE)
                printf(" attribute-node\n");
            }
			
          if (this->outputChoice == TEST_DM_COUNT_NODE)
            if (count % this->countInterval == 0)
              printf("%d nodes has been scaned\n", count);
				
          delete node; 
          node = this->dataMng->scanFetchNext(fileid, scanid);
        }
      this->dataMng->clearScan(fileid, scanid);
    }
  else 
    printf("error reported while starting scan\n");

  printf("totally %d nodes has been scanned\n\n\n", count);
}

void TestDataMng::fetchANode(FileIDType fileid,
                             KeyType nodekey)
{
  DM_DataNode* node = this->dataMng->getDataNode(fileid, nodekey);
	
  if (node == NULL)
    printf("Warning: can not find node with key = %s\n", nodekey.toString());
  else
    {
      printf("key = %s, endkey = %s, level = %d, parent = %s, prevSibling = %s, next Sibling = %s, ",  
             node->getKey().toString(), node->getEndKey().toString(), node->getLevel(), 
             node->getParent().toString(), 
             node->getPrevSibling().toString(), 
             node->getNextSibling().toString());

      if ((node->getFlag() == ELEMENT_NODE) || (node->getFlag() == DOCUMENT_NODE))
        printf("tag = %d, childnumber = %d, firstchild = %s, lastchild = %s\n",
               node->getTag(),	node->getChildNumber(), 
               node->getFirstChild().toString(), 
               node->getLastChild().toString());
      else if (node->getFlag() == TEXT_NODE)
        printf("text = %s\n ", ((DM_TextNode*) node)->getCharValue());
      else if (node->getFlag() == ATTRIBUTE_NODE)
        printf(" attribute-node\n");
		
      delete node; 
    }
}

void TestDataMng::printFile(char* filename)
{
  FileIDType fileid;
  KeyType rootkey;

  cout << endl << "***** print the content of file :" << filename << " ...." << endl;
  this->dataMng->beginTransaction();
  fileid = this->dataMng->openFile(filename, &rootkey);
  if (fileid < 0)
    printf("file does not exist\n");
  else 
    {
      this->fullScanSubtree(fileid, rootkey);
      //scancond = new SelectionCondition(SCAN_ALLNODES,
      //    NULL,
      //    SCAN_RETURN_THISNODE);
      //scanid = this->dataMng->startScan(fileid, rootkey, 
      //    0, -1, NULL, scancond, false);

      //if (scanid >= 0)
      //{
      //    node = this->dataMng->scanFetchNext(fileid, scanid);
      //    while (node!= NULL)
      //    {
      //        //node->printValue();

      //        printf("key = %s, endkey = %s, level = %d, parent = %s, prevSibling = %s, next Sibling = %s, ",  
      //            node->getKey().toString(), node->getEndKey().toString(), node->getLevel(), 
      //            node->getParent().toString(), 
      //            node->getPrevSibling().toString(), 
      //            node->getNextSibling().toString());

      //        if ((node->getFlag() == ELEMENT_NODE) || (node->getFlag() == DOCUMENT_NODE))
      //            printf("tag = %d, childnumber = %d, firstchild = %s, lastchild = %s\n",
      //            node->getTag(),	node->getChildNumber(), 
      //            node->getFirstChild().toString(),
      //            node->getLastChild().toString());

      //        else if (node->getFlag() == TEXT_NODE)
      //            printf("text = %s\n ", ((DM_TextNode*) node)->getCharValue());
      //        else if (node->getFlag() == ATTRIBUTE_NODE)
      //            printf(" attribute-node\n");

      //        delete node; 
      //        node = this->dataMng->scanFetchNext(fileid, scanid);
      //    }
      //    this->dataMng->clearScan(fileid, scanid);
      //}
      //else 
      //    printf("error reported while starting scan\n");
    }
  this->dataMng->closeFile(fileid);
  this->dataMng->endTransaction();
}


