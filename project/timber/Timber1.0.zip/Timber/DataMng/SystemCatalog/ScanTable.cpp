/*
COPYRIGHT  � 2000-2004 
THE REGENTS OF THE UNIVERSITY OF MICHIGAN
ALL RIGHTS RESERVED

PERMISSION IS GRANTED TO USE, COPY, CREATE DERIVATIVE WORKS AND
REDISTRIBUTE THIS SOFTWARE AND SUCH DERIVATIVE WORKS FOR NONCOMMERCIAL
EDUCATION AND RESEARCH PURPOSES, SO LONG AS NO FEE IS CHARGED, AND SO
LONG AS THE COPYRIGHT NOTICE ABOVE, THIS GRANT OF PERMISSION, AND THE
DISCLAIMER BELOW APPEAR IN ALL COPIES MADE; AND SO LONG AS THE NAME OF
THE UNIVERSITY OF MICHIGAN IS NOT USED IN ANY ADVERTISING OR PUBLICITY
PERTAINING TO THE USE OR DISTRIBUTION OF THIS SOFTWARE WITHOUT
SPECIFIC, WRITTEN PRIOR AUTHORIZATION.

THIS SOFTWARE IS PROVIDED AS IS, WITHOUT REPRESENTATION FROM THE
UNIVERSITY OF MICHIGAN AS TO ITS FITNESS FOR ANY PURPOSE, AND WITHOUT
WARRANTY BY THE UNIVERSITY OF MICHIGAN OF ANY KIND, EITHER EXPRESS OR
IMPLIED, INCLUDING WITHOUT LIMITATION THE IMPLIED WARRANTIES OF
MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE. THE REGENTS OF
THE UNIVERSITY OF MICHIGAN SHALL NOT BE LIABLE FOR ANY DAMAGES,
INCLUDING SPECIAL, INDIRECT, INCIDENTAL, OR CONSEQUENTIAL DAMAGES,
WITH RESPECT TO ANY CLAIM ARISING OUT OF OR IN CONNECTION WITH THE USE
OF THE SOFTWARE, EVEN IF IT HAS BEEN OR IS HEREAFTER ADVISED OF THE
POSSIBILITY OF SUCH DAMAGES.
*/

#include "ScanTable.h"
#include "../../Utilities/ErrorInfoClass.h"

/**
* class ScanTable
* This class keeps track of all scans opened on a single data file. 
* 
* @see ScanTableItem
* @see DynamicFileMap
* 
* @author Yuqing Melanie Wu
* @version 1.0
*/

/**
* Constructor
* Initialize the variables with default value.
*/
ScanTable::ScanTable()
{
	this->activeScanNumber = 0;

	for (int i=0;i<MAXSCAN_NUMBER; i++)
		this->scanList[i] = new ScanTableItem(i);
}

/**
* Destructor
* Release space taken by the scanlist.
*/
ScanTable::~ScanTable()
{
	for (int i=0; i<MAXSCAN_NUMBER; i++)
		if (this->scanList[i] != NULL)
			delete this->scanList[i];
}

/**
* Process Method
* Get the ID of the first free (invalid) ScanTableItem in the scanlist
* @returns The ID of the first free (invalid) ScanTableItem in the scanlist. -1 if all the scan table item in the list are occupied. 
*/
ScanIDType ScanTable::getNewScanID()
{
	if (this->activeScanNumber == MAXSCAN_NUMBER)
		return -1;
	else 
	{
		for (int i=0; i<MAXSCAN_NUMBER; i++)
			if (!this->scanList[i]->valid)
				// return the first one that is invalid. 
				return this->scanList[i]->scanID;
	}
	return -1;
}

/**
* Set Method
* Set the scan inforamtion to the ScanTableItem with a reserved id.
* @param scanid The id of the ScanTableItem reserved for the scan. 
* @param scaninfo The information about a scan on the physical data management level.
* @param writetoNodeMap A boolean value which indicate whether the results of the scan are to be written to the buffer (NodeIDMap). 
*/
void ScanTable::validate(ScanIDType scanid, 
						 ScanInfo* scaninfo,
						 bool writetoNodeMap)
{
	if (this->scanList[scanid]->valid)
          globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"DynamicFileTable",__FILE__,"Cannot overwrite a valid scan");
	else
	{
		this->scanList[scanid]->validate(scaninfo, writetoNodeMap);
		this->activeScanNumber++;
	}
}

/**
* Process Method
* Invalidate a scan table item in the ScanTable.
*
* @param scanid The id of the scan table item to be invalidated. 
*/

void ScanTable::invalidate(const ScanIDType scanid)
{
	if (this->scanList[scanid]->valid)
	{
		this->scanList[scanid]->invalidata();
		this->activeScanNumber--;
	}
	else 
          globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"DynamicFileTable",__FILE__,"The specified scan does not exist.");
}


/**
* Access Method
* 
* Get the ScanTableItem with a given scanid.
*
* @param scanid The id of the scan table item 
* @returns The ScanTableItem that contains information about the scan
*/
ScanTableItem* ScanTable::getScan(const ScanIDType scanid)
{
	return this->scanList[scanid];
}

/**
* Assert Method
* 
* Check whether a scan talbe item in the ScanTable with a given scanid is valid.
* 
* @param scanid The id of the scan table item 
* @returns a boolean value which indicate whether the scan table item is valid
*/
bool ScanTable::checkValid(const ScanIDType scanid)
{
	return this->scanList[scanid]->valid;
}


