/*
COPYRIGHT  � 2000-2004 
THE REGENTS OF THE UNIVERSITY OF MICHIGAN
ALL RIGHTS RESERVED

PERMISSION IS GRANTED TO USE, COPY, CREATE DERIVATIVE WORKS AND
REDISTRIBUTE THIS SOFTWARE AND SUCH DERIVATIVE WORKS FOR NONCOMMERCIAL
EDUCATION AND RESEARCH PURPOSES, SO LONG AS NO FEE IS CHARGED, AND SO
LONG AS THE COPYRIGHT NOTICE ABOVE, THIS GRANT OF PERMISSION, AND THE
DISCLAIMER BELOW APPEAR IN ALL COPIES MADE; AND SO LONG AS THE NAME OF
THE UNIVERSITY OF MICHIGAN IS NOT USED IN ANY ADVERTISING OR PUBLICITY
PERTAINING TO THE USE OR DISTRIBUTION OF THIS SOFTWARE WITHOUT
SPECIFIC, WRITTEN PRIOR AUTHORIZATION.

THIS SOFTWARE IS PROVIDED AS IS, WITHOUT REPRESENTATION FROM THE
UNIVERSITY OF MICHIGAN AS TO ITS FITNESS FOR ANY PURPOSE, AND WITHOUT
WARRANTY BY THE UNIVERSITY OF MICHIGAN OF ANY KIND, EITHER EXPRESS OR
IMPLIED, INCLUDING WITHOUT LIMITATION THE IMPLIED WARRANTIES OF
MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE. THE REGENTS OF
THE UNIVERSITY OF MICHIGAN SHALL NOT BE LIABLE FOR ANY DAMAGES,
INCLUDING SPECIAL, INDIRECT, INCIDENTAL, OR CONSEQUENTIAL DAMAGES,
WITH RESPECT TO ANY CLAIM ARISING OUT OF OR IN CONNECTION WITH THE USE
OF THE SOFTWARE, EVEN IF IT HAS BEEN OR IS HEREAFTER ADVISED OF THE
POSSIBILITY OF SUCH DAMAGES.
*/

#ifndef __ScanTableItem_H
#define __ScanTableItem_H

#include "../stdafx.h"

typedef int		ScanIDType;



/**
* class ScanTableItem
* 
* This class defines an item in ScanMap that keeps the information for a single scan. It keeps
* information about a scan, including the information needed at physical data managemenet left, 
* such as scaninfo, and the information at DataMng level, such as whether the result is to be
* write to the buffer (NodeIDMap). 
*
* @see ScanInfo
* @see ScanMap
* 
* @author Yuqing Melanie Wu
* @version 1.0
*/

class ScanTableItem  
{
public:
	/**
	* Constructor
	* Initialize variables with default value
	*/
	ScanTableItem(ScanIDType ScanID);

	/**
	* Destructor
	* Release space taken by the scan info. 
	*/
	virtual ~ScanTableItem();

	/**
	* Access Method
	* Get Information about the scan
	* @returns ScanInfo, the information about the scan at physical data management level. \
	*/
	ScanInfo*		getScanInfo();
	
	/**
	* Access Method
	* Get information about whether the result of the scan is to be written to memory buffer or not
	*/
	bool			writeToNodeIDMap();

	/**
	* Set Method
	* Validata a scan table item and store the information of a scan in the scan table item. 
	* @param scaninfo The information about a scan at the physical data management level. 
	* @param writetoNodeMap Whether the results are to be written to the NodeIDMap
	*/
	void	validate(ScanInfo* scaninfo, bool writetonodemap);

	/**
	* Process Method
	* Remove the scaninfo from the scan table item. 
	*/
	void	invalidata();

protected:
	/**
	* An ID assigned to each of a scan
	* It is unique to data file 
	*/
	ScanIDType	scanID;

	/**
	* Whether the scan table item is currently valid
	*/
	bool		valid;

private:
	
	/**
	* Information about the scan at the physical data management level
	*/
	ScanInfo* scaninfo;
	
	/**
	* Whether the results are to be written to the NodeIDMap
	*/
	bool writetoNodeMap;


friend class ScanTable;
};

#endif
