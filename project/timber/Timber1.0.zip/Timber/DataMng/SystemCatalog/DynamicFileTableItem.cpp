/*
  COPYRIGHT  � 2000-2004 
  THE REGENTS OF THE UNIVERSITY OF MICHIGAN
  ALL RIGHTS RESERVED

  PERMISSION IS GRANTED TO USE, COPY, CREATE DERIVATIVE WORKS AND
  REDISTRIBUTE THIS SOFTWARE AND SUCH DERIVATIVE WORKS FOR NONCOMMERCIAL
  EDUCATION AND RESEARCH PURPOSES, SO LONG AS NO FEE IS CHARGED, AND SO
  LONG AS THE COPYRIGHT NOTICE ABOVE, THIS GRANT OF PERMISSION, AND THE
  DISCLAIMER BELOW APPEAR IN ALL COPIES MADE; AND SO LONG AS THE NAME OF
  THE UNIVERSITY OF MICHIGAN IS NOT USED IN ANY ADVERTISING OR PUBLICITY
  PERTAINING TO THE USE OR DISTRIBUTION OF THIS SOFTWARE WITHOUT
  SPECIFIC, WRITTEN PRIOR AUTHORIZATION.

  THIS SOFTWARE IS PROVIDED AS IS, WITHOUT REPRESENTATION FROM THE
  UNIVERSITY OF MICHIGAN AS TO ITS FITNESS FOR ANY PURPOSE, AND WITHOUT
  WARRANTY BY THE UNIVERSITY OF MICHIGAN OF ANY KIND, EITHER EXPRESS OR
  IMPLIED, INCLUDING WITHOUT LIMITATION THE IMPLIED WARRANTIES OF
  MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE. THE REGENTS OF
  THE UNIVERSITY OF MICHIGAN SHALL NOT BE LIABLE FOR ANY DAMAGES,
  INCLUDING SPECIAL, INDIRECT, INCIDENTAL, OR CONSEQUENTIAL DAMAGES,
  WITH RESPECT TO ANY CLAIM ARISING OUT OF OR IN CONNECTION WITH THE USE
  OF THE SOFTWARE, EVEN IF IT HAS BEEN OR IS HEREAFTER ADVISED OF THE
  POSSIBILITY OF SUCH DAMAGES.
*/

#include "DynamicFileTableItem.h"

/**
 * class DynamicFileTableItem
 * 
 * This class is an item in DynamicFileMap, which represents an opened data file.
 * 
 * It keeps infomation of the data file, operations on the data file, such as scans,  as well as
 * the NodeIDMap which is a simulated buffer which keeps the data in memory. 
 *
 * @see NodeIDMap
 * @see ScanTable
 * @see DynamicFileMap
 * 
 * @author Yuqing Melanie Wu
 * @version 1.0
 */

/**
 * Constructor
 * Initialized a blank DynamicFileTableItem
 */
DynamicFileTableItem::DynamicFileTableItem()
{
  this->fileInfo = NULL;
  this->nodeMap = NULL;
}


/**
 * Constructor
 * 
 * Initialize a DynamicFileTableItem with some information about the file
 *
 * @param dynid Dynamic id of the file
 * @param filename The name of the data file. 
 */
DynamicFileTableItem::DynamicFileTableItem(FileIDType	dynid,									   
                                           char* filename)
{
  this->dynamicFileID = dynid;
  strcpy(this->fileName, filename);
}

/**
 * Constructor
 * 
 * Initialize a DynamicFileTableItem with information about the file.
 *
 * @param dynid Dynamic id of the file
 * @param filename The name of the data file. 
 * @param fileinfo Information about the data file.
 * @param nodemap The NodeIDMap associated with the data file.
 */

DynamicFileTableItem::DynamicFileTableItem(const FileIDType	dynid,
                                           char* filename,
                                           FileInfoType* fileinfo,
                                           NodeIDMap*	nodemap)
{
  this->dynamicFileID = dynid;
  strcpy(this->fileName, filename);
  this->fileInfo = fileinfo;
  this->fileInfoChanged = false;
  this->nodeMap = nodemap;
}
	
/**
 * Destructor
 * Release space taken by the fileinfo and NodeIDMap
 */
DynamicFileTableItem::~DynamicFileTableItem()
{
  if (this->fileInfo != NULL)
    delete this->fileInfo;
  if (this->nodeMap != NULL)
    delete this->nodeMap;
}

/**
 * Access Method
 * Get the name of the data file stored in this DynamicFileTableItem. 
 * @returns The name of the data file
 */
char* DynamicFileTableItem::getFileName()
{
  return this->fileName;
}

/**
 * Access Method
 * Get the dynamic file id of the DynamicFileTableItem
 * @returns The dynamic file id of the DynamicFileTableItem
 */
FileIDType	DynamicFileTableItem::getDynamicFileID()
{
  return this->dynamicFileID;
}

/**
 * Access Method
 * Get the information of the data file.
 * @returns The information of the data file. 
 */
FileInfoType* DynamicFileTableItem::getFileInfo()
{
  return this->fileInfo;
}

/**
 * Access Method
 * Find out whether the file info have been changed
 * @return A boolean value which indicate whether the information about the file has been changed. 
 */
bool DynamicFileTableItem::fileInfoIsChange()
{
  return this->fileInfoChanged;
}

/**
 * Access Method
 * Get the NodeIDMap associated with the data file
 * @returns The NodeIDMap associated with the data file
 */
NodeIDMap*	DynamicFileTableItem::getNodeMap()
{
  if (this->nodeMap == NULL)
    return NULL;
  else return this->nodeMap;
}

/**
 * Access Method
 * Get the scan table associated with the data file.
 * @returns The the scan table associated with the data file.
 */
ScanTable* DynamicFileTableItem::getScanTable()
{
  return &this->scans;
}

/**
 * Set Method
 * Set the dynamic file id for the DynamicFileTableItem.
 * @param id The dynamic file id to be assigned to the DynamicFileTableItem.
 */
void DynamicFileTableItem::setFileID(FileIDType id)
{
  this->dynamicFileID = id;
}

/**
 * Set Method
 * Set the name of the data file to the DynamicFileTableItem.
 * @param filename The name of the data file
 */
void DynamicFileTableItem::setFileName(char* filename)
{
  strcpy(this->fileName, filename);
}

/**
 * Set Method
 * Set the information about the data file to the DynamicFileTableItem.
 * @param fileindo Information about the data file
 */
void DynamicFileTableItem::setFileInfo(FileInfoType* fileinfo)
{
  if (this->fileInfo  == NULL)
    {
      // this is the first time the fileinfo is assigned to this DynamicFileTableItem. 
      this->fileInfo = fileinfo;
      this->fileInfoChanged = false;
    }
  else
    {
      // if the DynamicFileTableItem already has a fileinfo, replace it with the new one
      // and set the fileInfoChanged flag to be true. 
      if (this->fileInfo != fileinfo)
        {
          delete this->fileInfo;
          this->fileInfo = fileinfo;
        }
      this->fileInfoChanged = true;
    }
}

/**
 * Set Method 
 * Set the NodeIDmap associated with the data file.
 * @param nodemap The NodeIDmap associated with the data file.
 */
void DynamicFileTableItem::setNodeMap(NodeIDMap* nodemap)
{
  this->nodeMap = nodemap;
}


/**
 * Semi-Destruction
 * Invalidate the DynamicFileTableItem by free the space for FileInfo and NodeIDMap
 */

void DynamicFileTableItem::invalidate()
{
  if (this->fileInfo != NULL)
    {
      delete this->fileInfo;
      this->fileInfo = NULL;
    }

  if (this->nodeMap != NULL)
    {
      delete this->nodeMap;
      this->nodeMap = NULL;
    }
}



