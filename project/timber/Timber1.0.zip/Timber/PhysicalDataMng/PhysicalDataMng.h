/*
COPYRIGHT  (c) 2000-2004 
THE REGENTS OF THE UNIVERSITY OF MICHIGAN
ALL RIGHTS RESERVED

PERMISSION IS GRANTED TO USE, COPY, CREATE DERIVATIVE WORKS AND
REDISTRIBUTE THIS SOFTWARE AND SUCH DERIVATIVE WORKS FOR NONCOMMERCIAL
EDUCATION AND RESEARCH PURPOSES, SO LONG AS NO FEE IS CHARGED, AND SO LONG
AS THE COPYRIGHT NOTICE ABOVE, THIS GRANT OF PERMISSION, AND THE
DISCLAIMER BELOW APPEAR IN ALL COPIES MADE; AND SO LONG AS THE NAME OF THE
UNIVERSITY OF MICHIGAN IS NOT USED IN ANY ADVERTISING OR PUBLICITY
PERTAINING TO THE USE OR DISTRIBUTION OF THIS SOFTWARE WITHOUT SPECIFIC,
WRITTEN PRIOR AUTHORIZATION.

THIS SOFTWARE IS PROVIDED AS IS, WITHOUT REPRESENTATION FROM THE
UNIVERSITY OF MICHIGAN AS TO ITS FITNESS FOR ANY PURPOSE, AND WITHOUT
WARRANTY BY THE UNIVERSITY OF MICHIGAN OF ANY KIND, EITHER EXPRESS OR
IMPLIED, INCLUDING WITHOUT LIMITATION THE IMPLIED WARRANTIES OF
MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE. THE REGENTS OF THE
UNIVERSITY OF MICHIGAN SHALL NOT BE LIABLE FOR ANY DAMAGES, INCLUDING
SPECIAL, INDIRECT, INCIDENTAL, OR CONSEQUENTIAL DAMAGES, WITH RESPECT TO
ANY CLAIM ARISING OUT OF OR IN CONNECTION WITH THE USE OF THE SOFTWARE,
EVEN IF IT HAS BEEN OR IS HEREAFTER ADVISED OF THE POSSIBILITY OF SUCH
DAMAGES.
*/

/**
 * @author Yuqing (Melanie) Wu
 */

#ifndef __PhysicalDataMng_H
#define __PhysicalDataMng_H

#include "SystemCatalog/XMLDocumentTable.h"
#include "SystemCatalog/XMLNameTable.h"
#include "ScanInfo/ScanInfo.h"

/**
* This data structure is used in scan interface to specify the types of node to fetch
* as well as the depth of the subtree to fetch.
*/
typedef struct {
	int Depth;
	int NodeTypes;
} CuttingType;

/**
* Physcial Data Manager
* 
* This class is the physical data manager which interact with the storage management product (shore/berkeleydb)
* and provide single node/tuple access interface to the database. 
*
* It handles the lower-level data management of TIMBER, including:
*		data loading interface
*		navigation interface
*		scan interface
* and numerous other supporting functions.
*
* @see MSXMLParser
* @see DataMng
*/

class PhysicalDataMng
{
public:
	/**
	* Constructor
	* Create a new DataMng instance with a given volume id of Shore/BerkeleyDB.
	* Initialize the XMLDocumentTable.
	*@param vol_id The volumn ID of SHORE/BerkeleyDB
	*/
	PhysicalDataMng(lvid_t vold_id);

	/**
	* Destructor
	*
	* Free space allocated for xmlDocumentTable
	*/
	virtual ~PhysicalDataMng();

	/** 
	* Access  Method
	* Get the volumnID where the database is on
	*/
	lvid_t getVolumeID();

	/**
	* Process Method
	* Begin a transaction in the SHORE/BerkeleyDB.
	* This function, together with endTransaction, allow the user of PhysicalDataMng to control the 
	* scope of a transaction. 
	* 
	* TRICK: To avoid portential error, such as begin transaction inside an active transaction, a variable "inTransaction"
	* is kept in PhysicalDataMng. The begin_xct is called only when it is not currently inside an active transaction. 
	* The variable is set to be true if begin_xct is called and is done successfully. 
	*/
	void beginTransaction();
	
	/**
	* Process Method
	* End a transaction in the SHORE/BerkeleyDB.
	* This function, together with beginTransaction, allow the user of PhysicalDataMng to control the 
	* scope of a transaction. 
	* 
	* TRICK: To avoid portential error, such as calling end transaction while there is no active transaction,
	* a variable "inTransaction" is kept in PhysicalDataMng. The commit_xct is called only when it is currently 
	* inside an active transaction. The variable is set to be false if commit_xct is called and is done 
	* successfully. 
	*/
	void endTransaction();

	/**
	* Process Method
	* Abort a transaction in the SHORE/BerkeleyDB.
	* This function, together with beginTransaction and endTransaction, allow the user of PhysicalDataMng to control the 
	* scope of a transaction and enforce . 
	* 
	* TRICK: To avoid portential error, such as calling end transaction while there is no active transaction,
	* a variable "inTransaction" is kept in PhysicalDataMng. The abort_xact is called only when it is currently 
	* inside an active transaction. The variable is set to be false if abort_xct is called and is done 
	* successfully. 
	*/
	void abortTransaction();

	/**
	* (used to be Internal) Process Method
	* 
	* Get the record id of a node with given key. 
	* 
	* @param fileinfo The information of the data file that contains the node.
	* @param nodekey The key of the node whose record id is to be found. 
	* @param found The is a return value, which indicate whether the node exist in the databse or not. 
	* @returns The record id of the node, if found is true. 
	*/	
	serial_t getNodeRid(FileInfoType fileinfo, 
		KeyType nodekey, bool* found);


	/* ----------------------------------------------------------- */
	/*						file interface					       */
	/* ----------------------------------------------------------- */

	/**
	* File Interface
	* 
	* Find out whether XML document with the given name exists in the database or not. 
	*
	*@param filename The name of the file to look for.
	*@returns A boolean value which indicate whether the file exists in the database or not. 
	*/
	bool fileExist(char* filename);

	/**
	* File Interface
	* 
	* Get the information about an XML document in the database.
	* 
	*@param filename The name of the file whose information is to be obtained.
	*@returns The information about the file, in FileInfoType. Return NULL when the file does not exist in the database.
	*
	*@seealso FileInfoType
	*/
	FileInfoType* getFileInfo(char* filename);

	/**
	* File Interface
	* 
	* Reset the fileinfo when the information about a file is changed. 
	* The following are some example of the changes: new document is appended to an existing document, which
	* changes the node num, max level, etc. of the existing document; update happens and move some node to the 
	* overflow section.
	* 
	*@param filename The name of the file whose information is to be reset.
	*@param fileinfo The new information about the file. 
	*@return Error code.
	*/
	int resetFileInfo(char* filename, FileInfoType* fileinfo);

	/**
	* File Interface
	* 
	* Delete an XML docuemnt from the database
	*
	* @param filename The name of the file to be deleted
	* @returns Whether this deletion operation is done successfully.
	*/
	int deleteFile(char* filename);

	/**
	* File Interface 
	*
	* Reorganize a file (most possiblly after updates), to make sure nodes are stored in key order.
	*
	* This is done by scan key index, and fetch the correspondent node, and store the node in right order 
	* to a new file. 
	* 
	* @param filename The name of the file to be reorganized.
	* @returns Error code.
	*/
	int reorganizeFile(char* filename);

	/**
	* File Interface
	* 
	* Get the names of all files in the database
	* 
	* @param num The totally number of files in the database (used as return value).
	* @returns List of file names.
	*/
	char** getFileNames(int* num);

	/* ----------------------------------------------------------- */
	/*						loading interface					   */
	/* ----------------------------------------------------------- */

	/** 
	* Loading Interface
	* 
	* Load an XML document into database
	* 
	*@param XMLfile The name (with path) of the XML docuemnt to be loaded
	*@param maxdepth The maximum depth of the XML docuemnt, default value is 100. 
	*@param convertmulticolor The flag saying whether to convert pointer-based to multicolor model (Nuwee added 07/14/03)
	*@returns Whether the loading process is done successfully. 
	*/
	int loadXMLFile(char* XMLFile, int maxdepth = 100, bool convertmulticolor = false);

	/**
	* Loading Interface
	* 
	* Append a XML document to an existing data file in the database.
	*
	* The data (nodes) in the new documents will be added to the existing data file. The root of the XML document
	* will become the last child of the merge node. 
	* Only merge at root is implemented right now. It should not be hard to extend it to merge at any given node. 
	*
	* @param newXMLFile The name (with path) of the XML document to be merged into database.
	* @param maxdepth The estimated depth of the new XML document. 
	* @param appendToXMLFile The name of the data file in the database to which the new data is to be appended.
	* @param mergeAt The key of the node which will become the parent of the root of the new XML document. Since
	*			only merge at root is implemented, this is reserved for future use. 
	* @param rootStartKey The start key of the root node of the new document (return value).
	* @param rootEndKey The end key of the root node of the new document (return value).
	* @returns Error code. 
	*/
	int appendXMLFile(char* newXMLFile,
		int maxdepth,
		char* appendToXMLFile,
		KeyType mergeAt, 
		KeyType* rootStartKey,
		KeyType* rootEndKey);	

	/*-----------------------------------------------------------
	 *		Single Node Access Interface
	 *-----------------------------------------------------------*/

	/**
	* Single Node Access Interface
	* 
	* Store a new node to SHORE/BerkeleyDB by appending the node to the end of the file.
	* It changes the fileinfo if it is the first time a node is expended to the file after loading.
	*
	*@param fileinfo The information of the file to which the new node is to be inserted.
	*@param node The node to be appened to the file. 
	*@returns A boolean value which indicate whether a the process is done successfully. 
	*/	
	int storeNodeToDBFile(FileInfoType* fileinfo, 
		DM_DataNode* node);
	
	/**
	* Single Node Access Interface
	* 
	* Fetch a data node from the database, given the node key. Also return the record id of the node
	* 
	* @param fileinfo The information about the data file. What we need is the fileid in it.
	* @param nodekey The key of the node to be fetched.
	* @param nrid A pointer to a variable with type serial_t. If the input is NULL, that means no rid is requested.
	*		When it is not NULL, the record id of the record that contains the node with the key is to be returned 
	*		in this variable. 
	* @returns The data node with the given key. Return NULL is node with such key does not exist in the database.
	*/
	DM_DataNode* fetchDataNodeFromDBFile(const FileInfoType fileinfo,
		KeyType nodekey, 
		serial_t* srid = NULL);

	/**
	* Single Node Access Interface
	* 
	* Delete a node with given key from the data file.
	*
	* @param fileinfo The information about the data file from which the node is to be deleted. 
	* @param nodekey The key of the node to be deleted.
	* @returns The error code.
	*/
	int deleteNodeFromDBFile(FileInfoType* fileinfo,
		KeyType nodekey);

	/**
	* Single Node Access Interface
	* 
	* Modify a node in the database, given the key of the node to be modified and the new nodes. 
	* The new node has to have the same key as the node to be modified.
	* 
	*@param fileinfo The information of the file to be modified.
	*@param nodekey THe key of the node to be modified.
	*@param newnode The node that is used to replace the node with the given key in the database. 
	*@returns Error code.
	*/
	int modifyNodeInDBFile(FileInfoType* fileinfo, 
		KeyType nodekey, 
		DM_DataNode* newnode);

	/**
	* this method is used to modify nodes in the database "in place".
	* in this way, we avoid moving nodes to the overflow area when they are modified.
	* when serialized, the node cannot be longer (is shorter ok?) than it's current length
	* in the database.  If so, use modifyNodeInDBFile instead.
	*/
	int fixedSizeModifyNodeInDBFile(DM_DataNode* updatedDataNode, serial_t srid);

	/*-------------------------------------------------------------------------------
	* scan interface
	--------------------------------------------------------------------------------*/

	/**
	* Scan Interface
	* 
	* Start a scan
	* 
	* Scan result can be fetched only when this method is called explicitly to start the scan.
	* This function takes the scan condition and other scan criteria, such as the subtree root, the scan range, etc.
	* process them and produce ScanInfo. Later, this ScanInfo is used  as the unique identification of scan
	* for data fetching and scan termination. 
	*
	* @param fileinfo The Information of the file in which scan is to be done.
	* @param nodekey The key of the node which is the root of the subtree to be scanned
	* @param scanmethod The scan method (reserved for later use)
	* @param depth The depth to get into the subtree. Only nodes within "depth" to the subtree root can be result of the scan.					 
	* @param scanrange A list of ranges. Only nodes fall in to  the scan range can be result of the scan. 
	* @param condition The scan condition in CNF format.
	* @returns The scaninfo which contains the inforamtion about the scan, and is to be used later for data fetching. 
	*		returns NULL is the scan is illegal, so, something is wrong in the process. 
	*/
	ScanInfo* startScan(FileInfoType* fileinfo, 
		const KeyType nodekey,
		const int scanmethod,
		const int depth,
		ScanRange* scanranges,
		SelectionCondition* condition,
		bool considerOverflow = true);

	ScanInfo* startOverflowScan(FileInfoType* fileinfo, 
		const KeyType nodekey,
		const int scanmethod,
		const int depth,
		SelectionCondition* condition);

	/**
	* Scan Interface
	* Finish a scan.
	*
	* Every scan, after all or some of the result are fetched, should be closed explicitly by
	* calling this method. No more fetching can be done when a scan is closed.
	* 
	* @param scaninfo The information about the scan to be finished
	* @returns Error code
	*/
	int clearScan(ScanInfo* scaninfo);

	/**
	* Scan Interface
	* 
	* Fetch the next result of the scan.
	*
	* This function can only be called when the scaninfo is refer to a valid scan. That is, it is 
	* returned from startScan, and no clearScan has been called on it.
	*
	* @param scaninfo The information of the scan.
	* @returns The next result node in the scan. NULL if all nodes have been fetched already. 
	*/
	DM_DataNode* scanFetchNext(ScanInfo* scanInfoType);

	/*-----------------------------------------------------------
	 *		other interface
	 *-----------------------------------------------------------*/

	/**
	* Process Method
	* 
	* Apply a selection condition against a node, determine whether the node meet the predicate.
	* 
	* @param fileinfo The information of the file which contains the node to be checked. 
	* @param node The node to be checked.
	* @param scancond The condition to be applied on the node
	* @returns A boolean value which indicate whether the node meet the condition or not.
	*
	* @see checkConCond
	* @see checkPredicate
	* @see scanfetchNext
	*/
	bool checkCond(const FileInfoType fileinfo,
		DM_DataNode* node, 
		SelectionCondition* scancond);

	/**
	* Internal Method
	* 
	* Parser the name of XML  document with path, split it to filename and file path
	* 
	*@param str The filename with path
	*@param path The path (return value).
	*@param filename The filename (return value).
	*/	
	const static void parse_name(char* str, char* path, char* filename);

    /**
    * @return xmlNameTable
    */
    XMLNameTable* getXMLNameTable();


private:

	/**
	* The structure that acts as a system catalog, which keeps information about the data files. 
	* @see XMLDocumentTable
	*/
	XMLDocumentTable* xmlDocumentTable;

    /**
    * The structure implementing the tag/attribute name encoding scheme
    * @see XMLNameTable
    */
    XMLNameTable* xmlNameTable;

	/**
	* volume id
	*/ 
	lvid_t volumeID;

	/**
	* A boolean value which indicate whether the Physical Data Manager is in a DB transaction or not. 
	*/
	bool inTransaction;

	/*-----------------------------------------------------------
	 *		Internal Methods
	 *-----------------------------------------------------------*/

	/**
	* Internal Method
	*
	* In support of the Loading Interface.
	* 
	* Load an XML document into the database.
	* 
	* @param XMLFile The XML document name, with path.
	* @param targetName The name of the data file in the database that will stored the nodes in the XML document.
	* @param maxdepth The maximum depth of the XML document.
	* @param convertmulticolor The flag saying whether to convert pointer-based to multicolor model (Nuwee added 07/14/03)
	* @returns Error Code.
	*/	
	int loadXMLFileToDBFile(char* XMLFile, 
		char* targetFile, 
		int maxdepth,
		bool convertmulticolor);

	/**
	* Internal Method
	* 
	* In support of the single node access interface, the loading interface the the update interface
	* 
	* Append a node to the tail of the data file.
	* 
	* @param fileinfo The information of the file where the node is to be appended to. 
	* @param apdHandler An append handler on the data file.
	* @param node The node to be appended to the data file. 
	* @returns Error code 
	*/
	int appendNodeToDBFile(FileInfoType* fileinfo,
		append_file_i* apdHandler, 
		DM_DataNode* node);

	/**
	* Internal Method
	* 
	* In support of scan and update
	* 
	* Find the first node in the scan range. 
	* 
	* Given a scan range (a set of start keys pairs), it is not necessary that there is a node in the data file whose 
	* key is the same as the start key on the boundary. and it is not necessarily true that there is any node
	* in the first range in the range set. This function find the first node that falls in the scan range. 
	* 
	* @param fileinfo The information of the data file.
	* @param scanrange A scan range (set of ranges (key pairs)).
	* @param startCursor A pointer to a range in the scan range that we are currently looking at.
	* @param foundKey A boolean value which indicate whether a node is found (return value)
	* @param foundInCursor A pointer to a range in which the first node is found (return value)
	* @param scankey The key found (return value)
	* @param sortedFileOnly If true, we only look for the node in the sorted portion of the file, and ignore the overflow area
	* @returns A boolean value which indicate whether the process is done successfully. 
	*		return false means something wrong happends and all values returned through parameter are meaningless. 
	*		return true means the searching is done successfully. if foundKey is false, that means nothing is found. 
	*/	
	bool findFirstKeyInScanRange(FileInfoType* fileinfo, 
		ScanRange* scanrange, 
		int crtCursor, 
		bool* foundKey, 
		int* findInCursor, 
		KeyType* scanKey,
		bool sortedFileOnly = false);

	/**
	* Internal Method
	*
	* In support of checkCond()
	* 
	* Apply a predicate (one predicate within the scan condition) against a node, 
	* determine whether the node meet the predicate or not.
	*
	* @param fileinfo The inforamtion about the file where the node is from.  
	* @param node The node to be checked
	* @param predicate The predicate (part of a selection condition)
	* @returns A boolean value which indicate whether the node meets the predicate or not.
	* 
	* @see checkCond
	*/
	bool checkPredicate(const FileInfoType fileinfo, DM_DataNode* node, PredicateCondition* predicate);
	
	/**
	* Internal Method
	*
	* In support of the checkCond.
	*
	* Apply a predicate (one predicate within the selection condition) against a CharNode, 
	* determine whether the node meet the predicate.
	*
	* @param node The node to check, it should be guaranteed to be a DM_CharNode
	* @param predicate The predicate (part of the selection condition)
	* @returns A boolean value which indicate whether the node meet the predicate or not.
	* 
	* @see checkCond
	* @see checkPredicate
	*/
	bool checkPredChar(DM_DataNode* node, PredicateCondition* predicate);
	
	/**
	* Internal Method
	*
	* In support of the checkCond.
	*
	* Apply a predicate (one predicate within the selection condition) against a document node, 
	* determine whether the node meet the predicate.
	*
	* @param node The node to check, it should be guaranteed to be a DM_DocumentNode
	* @param predicate The predicate (part of the selection condition)
	* @returns A boolean value which indicate whether the node meet the predicate or not.
	* 
	* @see checkCond
	* @see checkPredicate
	*/
	bool checkPredDoc(DM_DataNode* node, PredicateCondition* predicate);
	
	/**
	* Internal Method
	*
	* In support of the checkCond.
	*
	* Apply a predicate (one predicate within the selection condition) against a element node, 
	* determine whether the node meet the predicate.
	*
	* @param node The node to check, it should be guaranteed to be a DM_ElementNode
	* @param predicate The predicate (part of the selection condition)
	* @returns A boolean value which indicate whether the node meet the predicate or not.
	* 
	* @see checkCond
	* @see checkPredicate
	*/
	bool checkPredEle(const FileInfoType fileinfo, DM_DataNode* node, PredicateCondition* predicate);
	
	/**
	* Internal Method
	*
	* In support of the checkCond.
	*
	* Apply a predicate (one predicate within the selection condition) against an attribute node, 
	* determine whether the node meet the predicate.
	*
	* @param node The node to check, it should be guaranteed to be a DM_AttributeNode
	* @param predicate The predicate (part of the selection condition)
	* @returns A boolean value which indicate whether the node meet the predicate or not.
	* 
	* @see checkCond
	* @see checkPredicate
	*/
	bool checkPredAttr(DM_DataNode* node, PredicateCondition* predicate);

	/**
	* Internal Method
	* 
	* In supprot of checkCond, which part of the scan interface, and can also be called along.
	* 
	* Apply a selection condition in conjunctive expression (a part of the selection condition) against 
	* a node, determine whether the node meet the predicate.
	* 
	* @param fileinfo The information of the file which contains the node to be checked. 
	* @param node The node to be checked.
	* @param concond The condition in conjunctive expression (part of the selection condition)
	* @returns A boolean value which indicate whether the node meet the condition or not.
	*
	* @see checkCond
	* @see checkDisCond
	* @see checkPredicate
	*/
	bool checkConCond(const FileInfoType fileinfo, DM_DataNode* node, ConjunctiveCondition* concond);
	
	/**
	* Internal Method
	* 
	* In supprot of checkCond, which part of the scan interface, and can also be called along.
	* 
	* Apply a selection condition in disjunctive expression (a part of the selection condition) against 
	* a node, determine whether the node meet the predicate.
	* 
	* @param fileinfo The information of the file which contains the node to be checked. 
	* @param node The node to be checked.
	* @param concond The condition in disnjunctive expression (part of the selection condition)
	* @returns A boolean value which indicate whether the node meet the condition or not.
	*
	* @see checkCond
	* @see checkCondsCond
	* @see checkPredicate
	*/
	bool checkDisCond(const FileInfoType fileinfo, DM_DataNode* node, DisjunctiveCondition* discond);

};

#endif
