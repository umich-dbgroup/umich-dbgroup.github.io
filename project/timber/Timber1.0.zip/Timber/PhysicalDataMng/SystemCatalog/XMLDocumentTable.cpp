/*
COPYRIGHT  (c) 2000-2004 
THE REGENTS OF THE UNIVERSITY OF MICHIGAN
ALL RIGHTS RESERVED

PERMISSION IS GRANTED TO USE, COPY, CREATE DERIVATIVE WORKS AND
REDISTRIBUTE THIS SOFTWARE AND SUCH DERIVATIVE WORKS FOR NONCOMMERCIAL
EDUCATION AND RESEARCH PURPOSES, SO LONG AS NO FEE IS CHARGED, AND SO LONG
AS THE COPYRIGHT NOTICE ABOVE, THIS GRANT OF PERMISSION, AND THE
DISCLAIMER BELOW APPEAR IN ALL COPIES MADE; AND SO LONG AS THE NAME OF THE
UNIVERSITY OF MICHIGAN IS NOT USED IN ANY ADVERTISING OR PUBLICITY
PERTAINING TO THE USE OR DISTRIBUTION OF THIS SOFTWARE WITHOUT SPECIFIC,
WRITTEN PRIOR AUTHORIZATION.

THIS SOFTWARE IS PROVIDED AS IS, WITHOUT REPRESENTATION FROM THE
UNIVERSITY OF MICHIGAN AS TO ITS FITNESS FOR ANY PURPOSE, AND WITHOUT
WARRANTY BY THE UNIVERSITY OF MICHIGAN OF ANY KIND, EITHER EXPRESS OR
IMPLIED, INCLUDING WITHOUT LIMITATION THE IMPLIED WARRANTIES OF
MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE. THE REGENTS OF THE
UNIVERSITY OF MICHIGAN SHALL NOT BE LIABLE FOR ANY DAMAGES, INCLUDING
SPECIAL, INDIRECT, INCIDENTAL, OR CONSEQUENTIAL DAMAGES, WITH RESPECT TO
ANY CLAIM ARISING OUT OF OR IN CONNECTION WITH THE USE OF THE SOFTWARE,
EVEN IF IT HAS BEEN OR IS HEREAFTER ADVISED OF THE POSSIBILITY OF SUCH
DAMAGES.
*/

/**
 * @author Yuqing (Melanie) Wu
 */

#include "XMLDocumentTable.h"
#include "../../Utilities/ErrorInfoClass.h"
extern ErrorInfoClass globalErrorInfo;

/**
* class XMLDocumentTable
* 
* This class acts as a system catalog, which deals with storing information about files to the database.
* And provide name based file information access. 
* 
* @see PhysicalDataMng
*/

/**
* Constructor
* 
* Initialize the xml document table, locate or create the index that contains the info about the data files.
* 
* @param volumnID The id of the volume where the database is on. 
*/

XMLDocumentTable::XMLDocumentTable(lvid_t volumeID)
{
	this->volumeID = volumeID;
	serial_t root_iid;

	rc_t rc = ss_m::begin_xct();
	if (rc)
	{
        globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"XMLDocumentTable::XMLDocumentTable",__FILE__,"Error begin_xct");
	}

	// find the root index in the database
	rc = ss_m::vol_root_index(this->volumeID, root_iid);
	if (rc)
	{
        globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"XMLDocumentTable::XMLDocumentTable",__FILE__,"Error vol_root_index");
	}
	
	// look for the XMLDocumentTable file in the root index in the database
	char* name = "XMLDocumentTable";
	int namesize = (int) strlen(name);
	smsize_t size = sizeof(serial_t);
	bool found = false;
	rc = ss_m::find_assoc(this->volumeID, root_iid,vec_t(name, namesize),&(this->XMLDocumentTable_IndexID),size,found);
	if (rc)
	{
        globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"XMLDocumentTable::XMLDocumentTable",__FILE__,"Error find_assoc");
		return;
	}

	if (!found)
	{
		// if the XMLDocumentTable can not be found, this means, it is
		// the first run of the database

		// create a XMLDocumentTable, which itself is an index
		
		char index_t[10] = "b*";
		char size[10];
		itoa(MAX_FILE_NAME_LENGTH, size, 10);
		strcpy(index_t+2, size);

		rc = ss_m::create_index(this->volumeID, ss_m::t_btree, ss_m::t_regular,
								index_t, 0, this->XMLDocumentTable_IndexID);
		if (rc)
		{
            globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"XMLDocumentTable::XMLDocumentTable",__FILE__,"Error create_index");
			return;
		}

		// Create association of the file and its name in root index of the database

		rc = ss_m::create_assoc(this->volumeID, root_iid, vec_t("XMLDocumentTable", strlen("XMLDocumentTable")),
 					            vec_t(&(this->XMLDocumentTable_IndexID), sizeof(serial_t)));
		if (rc)
		{
            globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"XMLDocumentTable::XMLDocumentTable",__FILE__,"Error create_assoc");
			return;
		}
	}

	rc = ss_m::commit_xct();
	if (rc)
	{
        globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"XMLDocumentTable::XMLDocumentTable",__FILE__,"Error commit_xct");
	}
	return;

}


XMLDocumentTable::~XMLDocumentTable()
{
}

/**
* Process Method
* 
* Insert the information of a file into the XMLDocumentTable in database
* 
* @param filename The name of the XML document stored in the data file
* @param fileinfo Information about the data file
* @returns Error  code.
*/
int	XMLDocumentTable::insertFile(char* filename, FileInfoType* fileinfo)
{
	// first, check whether a file with the same name is in the XML document table already. 
	FileInfoType* fi = getFileInfo(filename);
	if (fi != NULL)
	{
		// if a file with same name already exists in the database, 
        // should not call insertFile but setFileInfo instead.
        globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"XMLDocumentTable::insertFile",__FILE__,"File already in Timber");
		delete fi;
		return -1;
	}
	
	// create an index item to map the fileinfo to its name. 
	rc_t rc = ss_m::create_assoc(this->volumeID, this->XMLDocumentTable_IndexID,
				                 vec_t(filename, strlen(filename)),vec_t(fileinfo, sizeof(FileInfoType)));
	if (rc)
	{
        globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"XMLDocumentTable::insertFile",__FILE__,"Error create_assoc");
		return -1;
	}

	return 0;
}

/**
* Process Method
* 
* Set new file information to an existing file in the database.
* This is done by remove the index item that associate the old file information with the file name
* then insert a new item that reflect the new file information. 
* 
* @param filename The name of the data file whose information is to be changed
* @param fileinfo The new information about the data file
* @returns Error  code.
*/
int XMLDocumentTable::setFileInfo(char* filename, FileInfoType* fileinfo)
{
	// delete the index item that assoicate the fileinfo with the file name
	int ret = deleteFile(filename);
	if (ret < 0) return ret;

	// insert the new file info. 
	ret = insertFile(filename, fileinfo);
	return ret;
}

/**
* Process Method
* 
* Removed a data file and its information from the system catalog.
* 
* @param filename The name of the data file whose information is to be removed from the catalog
* @returns Error code.
*/
bool XMLDocumentTable::deleteFile(char* filename)
{
	rc_t rc;
	
	FileInfoType* fileinfo = getFileInfo(filename);
	if (fileinfo == NULL)
	{
		// report error is file with the given name does not exist in the system. 
        globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"XMLDocumentTable::deleteFile",__FILE__,"File not in Timber");
		delete fileinfo;
		return false;
	}
	else
	{
		// remove the index item that maps the file name to its information
		rc = ss_m::destroy_assoc(this->volumeID, this->XMLDocumentTable_IndexID,
			                     vec_t(filename, strlen(filename)), vec_t(fileinfo, sizeof(FileInfoType)));
		delete fileinfo;
		return true;
	}
}

/**
* Process Method
* 
* Given a file name, find out whether a data file with the name exists in the database
* 
* @param filename The name of data file which we are looking for.
* @returns A boolean value which indicate whether file with the given name exists in the database or not.
*/
bool XMLDocumentTable::fileExist(char* filename)
{
	FileInfoType* fileinfo = new FileInfoType;
	smsize_t fileinfo_len = sizeof(FileInfoType);
	bool found = false;

	// look for the name-info mapping in the index.
	rc_t rc = ss_m::find_assoc(this->volumeID, this->XMLDocumentTable_IndexID,
				               vec_t(filename, strlen(filename)), fileinfo, fileinfo_len, found);
	if (rc)
	{
        globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"XMLDocumentTable::fileExist",__FILE__,"Error find_assoc");
        delete fileinfo;
		return false;
	}
	delete fileinfo;
	return found; 
}

/**
* Access Method
* 
* Get the information about a data file, given the file name
* 
* @param filename The name of data file which we are looking for.
* @returns The information about the data file. NULL if file with the given name does not exist in the database. 
*/
FileInfoType* XMLDocumentTable::getFileInfo(char* filename)
{
	FileInfoType* fileinfo = new FileInfoType;
	smsize_t fileinfo_len = sizeof(FileInfoType);
	bool found = false;

	// get the file information associated with the file from the index. 
	rc_t rc = ss_m::find_assoc(this->volumeID, this->XMLDocumentTable_IndexID,
				               vec_t(filename, strlen(filename)),fileinfo, fileinfo_len, found);
	if (rc)
	{
        globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"XMLDocumentTable::getFileInfo",__FILE__,"Error find_assoc");
        delete fileinfo;
		return NULL;
	}

	if (found) 
        return fileinfo;
	else 
    {
        delete fileinfo;
        return NULL;
    }
}


/**
* Access Method
* Get the name of all files in the database.
* This is done by scanning the index that contains the filename-fileinfo mapping. 
* 
* @param num The number of files in the databse (return value).
* @returns The name of the files. 
*/
char** XMLDocumentTable::getFileNames(int* num)
{
	// start to scan the index. 
	scan_index_i* scanindex = new scan_index_i(this->volumeID, this->XMLDocumentTable_IndexID, scan_index_i::gt, 
											   cvec_t::neg_inf, scan_index_i::lt, cvec_t::pos_inf);

	char** fileNames = new char*[MAX_FILENUMER];
	char tempStr[MAX_FILE_NAME_LENGTH];

	FileInfoType fileInfo;
	vec_t key(tempStr,MAX_FILE_NAME_LENGTH), ele(&fileInfo, sizeof(FileInfoType));
	smsize_t keysize;
	smsize_t elesize;
	bool eof = false;
	
	int cursor = 0;

	// move to the next index item. 
	rc_t rc = scanindex->next(eof);

	// keep going till the whole index has been scanned.  
	while (!eof)
	{
		// get the name of the file from the index item. 
		rc = scanindex->curr(&key, keysize, &ele, elesize);
		if (rc)
		{
            globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"XMLDocumentTable::getFileNames",__FILE__,"Error scanindex->curr");
			delete [] fileNames;
			return NULL;
		}

		fileNames[cursor] = new char[keysize+1];
		strncpy(fileNames[cursor], (char*) key.ptr(0),keysize);
		fileNames[cursor][keysize] = '\0';

		rc = scanindex->next(eof);
		cursor++;
	}	

	delete scanindex;
	*num = cursor;

	return fileNames;
}
