/*
COPYRIGHT  (c) 2000-2004 
THE REGENTS OF THE UNIVERSITY OF MICHIGAN
ALL RIGHTS RESERVED

PERMISSION IS GRANTED TO USE, COPY, CREATE DERIVATIVE WORKS AND
REDISTRIBUTE THIS SOFTWARE AND SUCH DERIVATIVE WORKS FOR NONCOMMERCIAL
EDUCATION AND RESEARCH PURPOSES, SO LONG AS NO FEE IS CHARGED, AND SO LONG
AS THE COPYRIGHT NOTICE ABOVE, THIS GRANT OF PERMISSION, AND THE
DISCLAIMER BELOW APPEAR IN ALL COPIES MADE; AND SO LONG AS THE NAME OF THE
UNIVERSITY OF MICHIGAN IS NOT USED IN ANY ADVERTISING OR PUBLICITY
PERTAINING TO THE USE OR DISTRIBUTION OF THIS SOFTWARE WITHOUT SPECIFIC,
WRITTEN PRIOR AUTHORIZATION.

THIS SOFTWARE IS PROVIDED AS IS, WITHOUT REPRESENTATION FROM THE
UNIVERSITY OF MICHIGAN AS TO ITS FITNESS FOR ANY PURPOSE, AND WITHOUT
WARRANTY BY THE UNIVERSITY OF MICHIGAN OF ANY KIND, EITHER EXPRESS OR
IMPLIED, INCLUDING WITHOUT LIMITATION THE IMPLIED WARRANTIES OF
MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE. THE REGENTS OF THE
UNIVERSITY OF MICHIGAN SHALL NOT BE LIABLE FOR ANY DAMAGES, INCLUDING
SPECIAL, INDIRECT, INCIDENTAL, OR CONSEQUENTIAL DAMAGES, WITH RESPECT TO
ANY CLAIM ARISING OUT OF OR IN CONNECTION WITH THE USE OF THE SOFTWARE,
EVEN IF IT HAS BEEN OR IS HEREAFTER ADVISED OF THE POSSIBILITY OF SUCH
DAMAGES.
*/

/**
* @author Cong Yu
*/

/**
*   XMLNameTable: implementation of the tag/attribute name encoding scheme.
* Tag or attribute names are encoded into an integer value at the loading 
* time.  The encoding function follows:
*   hash = sum(ASCII value of all chars in the NAME) % NameTableHashFactor
*   CODE = hash + n * NameTableHashFactor, where NAME is the nth name has
* a hash value of hash.
*   This scheme allows the hash generated for NAME and CODE to be the same,
* which means we can use the same in-memory hash table during loading or 
* querying time.
*   Two shore indices will be built: XMLNameToCodeIndex and XMLCodeToNameIndex.
* The XMLNameToCodeIndex will also contain entries recording the number of NAMEs
* hashed to the same hash value (so that new CODE can be calculated based on it).
*   All documents in the volume share the same XMLNameToCodeIndex and 
* XMLCodeToNameIndex.  Having one per document introduces overhead and code 
* complexity.
*/

#include "../../MSXMLParser/TreeStructure/TreeStructure_definitions.h"

#include "../../Utilities/ErrorInfoClass.h"
extern ErrorInfoClass globalErrorInfo;
#include "XMLNameTable.h"
using namespace PHYSICAL_DATA_MNG;

#define CDBG 0

/**
* Constructor
*/
XMLNameTable::XMLNameTable(lvid_t volumeID)
{
	this->volumeID = volumeID;
    memset(this->hashTable, 0, sizeof(HashRow)*NameTableHashFactor);
	serial_t root_iid;

	rc_t rc = ss_m::begin_xct();
	if (rc)
	{
        globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"XMLNameTable::XMLNameTable",__FILE__,"Error begin_xct");
	}

	// find the root index in the database
	rc = ss_m::vol_root_index(this->volumeID, root_iid);
	if (rc)
	{
        globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"XMLNameTable::XMLNameTable",__FILE__,"Error vol_root_index");
	}
	
	// look for both index files in the root index in the database
    int n2cLen = (int) strlen(NameToCodeIndex);
	int c2nLen = (int) strlen(CodeToNameIndex);
	smsize_t idLen = sizeof(serial_t);
	bool foundn2c = false, foundc2n = false;

	rc = ss_m::find_assoc(this->volumeID, root_iid, vec_t(NameToCodeIndex, n2cLen), 
        &(this->XMLNameToCodeTable_IndexID), idLen, foundn2c);
	if (rc)
	{
        globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"XMLNameTable::XMLNameTable",__FILE__,"Error find_assoc");
		return;
	}
	rc = ss_m::find_assoc(this->volumeID, root_iid, vec_t(CodeToNameIndex, c2nLen), 
        &(this->XMLCodeToNameTable_IndexID), idLen, foundc2n);
	if (rc)
	{
        globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"XMLNameTable::XMLNameTable",__FILE__,"Error find_assoc");
		return;
	}

    // Those two indices must be exist/nonexist together
    if ( (foundc2n && !foundn2c) || (!foundc2n && foundn2c) )
    {
        globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"XMLNameTable::XMLNameTable",__FILE__,"NameToCode index and CodeToName index are inconsistent");
        return;
    }

    // Create new name tables since this is the first run of the volume
    if (!foundc2n && !foundn2c)
	{
		char index_t[6] = "b*";
		char size[4];
		itoa(MAX_NODETAG_LENGTH, size, 10);
		strcpy(index_t+2, size);

        // create index for NameToCode index
		rc = ss_m::create_index(this->volumeID, ss_m::t_btree, ss_m::t_regular,
								index_t, 0, this->XMLNameToCodeTable_IndexID);
		if (rc)
		{
            globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"XMLNameTable::XMLNameTable",__FILE__,"");
			return;
		}
		rc = ss_m::create_assoc(this->volumeID, root_iid, vec_t(NameToCodeIndex, n2cLen),
 					            vec_t(&(this->XMLNameToCodeTable_IndexID), idLen));
		if (rc)
		{
            globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"XMLNameTable::XMLNameTable",__FILE__,"");
			return;
		}

        // create index for CodeToName index
		rc = ss_m::create_index(this->volumeID, ss_m::t_btree, ss_m::t_regular,
								index_t, 0, this->XMLCodeToNameTable_IndexID);
		if (rc)
		{
            globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"XMLNameTable::XMLNameTable",__FILE__,"");
			return;
		}
		rc = ss_m::create_assoc(this->volumeID, root_iid, vec_t(CodeToNameIndex, c2nLen),
 					            vec_t(&(this->XMLCodeToNameTable_IndexID), idLen));
		if (rc)
		{
            globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"XMLNameTable::XMLNameTable",__FILE__,"");
			return;
		}
	}

    // Name indices already built, need to grab the numEntries for each hash value from XMLNameToCodeIndex
    else
    {
        // DEBUG: do calculation of time spent retrieving numEntries to decide whether to distinguish load vs. query
        clock_t starttime = clock(), finishtime;
        char *cntName = new char[strlen(NameCodeIndexPrefix) + strlen(NameCodeIndexSuffix) + 3];
        char temp[3] = "\0";
        int cntNameLen = 0;
        smsize_t cntValueLen = sizeof(int);
        bool foundcnt = false;
        strcpy(cntName, NameCodeIndexPrefix);
        for (int i=0; i<NameTableHashFactor; i++)
        {
            // search for numEntry: if not found, then numEntry is 0 (as initialized)
            strcpy(cntName+strlen(NameCodeIndexPrefix), itoa(i, temp, 10));
            strcat(cntName, NameCodeIndexSuffix);
            cntNameLen = (int) strlen(cntName);
        	rc = ss_m::find_assoc(this->volumeID, this->XMLNameToCodeTable_IndexID, vec_t(cntName, cntNameLen),
                &(this->hashTable[i].numEntry), cntValueLen, foundcnt);
		    if (rc)
		    {
                globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"XMLNameTable::XMLNameTable",__FILE__,"");
			    return;
		    }
        }
        delete [] cntName;
        // DEBUG
        finishtime = clock();
        double duration = (double)(finishtime - starttime) / CLOCKS_PER_SEC;
        cerr << "\nTime spent retrieving numEntries: " << duration << endl;
    }

	rc = ss_m::commit_xct();
	if (rc)
	{
        globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"XMLNameTable::XMLNameTable",__FILE__,"Error commit_xct");
	}
	return;
}

/**
* Destructor
*/
XMLNameTable::~XMLNameTable()
{
    for (int i=0; i<NameTableHashFactor; i++)
    {
        HashEntry *entry = hashTable[i].entries;
        while (entry != NULL)
        {
            delete [] entry->name;
            HashEntry *temp = entry;
            entry = entry->next;
            delete temp;
        }
    }
}

/*----- Public Interfaces -----*/

int XMLNameTable::getCodeByName(char *name)
{
    int hash = hashFunction(name);

#if (CDBG)
    cout << "getCodeByName <" << name << ">: ";
#endif

    // search the in-memory table first
    HashEntry *entry = hashTable[hash].entries;
    while (entry != NULL && strcmp(entry->name, name))
    {
        entry = entry->next;
    }
#if (CDBG)
    if (entry != NULL) cout << "found in memory <" << entry->code << ">" << endl;
#endif
    if (entry != NULL) return entry->code;

    // search shore if not found in memory
    int nameLen = (int) strlen(name);
    int code = -1;
	smsize_t codeLen = sizeof(int);
    bool found = false;
    rc_t rc = ss_m::find_assoc(this->volumeID, this->XMLNameToCodeTable_IndexID, 
        vec_t(name, nameLen), &code, codeLen, found);
	if (rc)
	{
        globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"XMLNameTable::getCodeByName",__FILE__,"");
		return -1;
	}
    if (found) 
    {
#if (CDBG)
        cout << "found in shore <" << code << ">" << endl;
#endif
        addPairToTable(name, code, true); // name is provided from caller, do allocate here
        return code;
    }

    // return -1 if not found anywhere
#if (CDBG)
    cout << "not found" << endl;
#endif
    return -1;
}

/**
* @return the name corresponding to the code
*/
char* XMLNameTable::getNameByCode (int code)
{
    int hash = hashFunction(code);
#if (CDBG)
    cout << "getNameByCode <" << code << ">: ";
#endif

    // search the in-memory table first
    HashEntry *entry = hashTable[hash].entries;
    while (entry != NULL && entry->code != code)
    {
        entry = entry->next;
    }
#if (CDBG)
    if (entry != NULL) cout << "found in memory <" << entry->name << ">" << endl;
#endif
    if (entry != NULL) return entry->name;

    // search shore if not found in memory
    int codeLen = (int) sizeof(int);
    char *name = new char[MAX_NODETAG_LENGTH];
    memset(name, 0, MAX_NODETAG_LENGTH);
    smsize_t nameLen = (smsize_t) MAX_NODETAG_LENGTH;
    bool found = false;
    rc_t rc = ss_m::find_assoc(this->volumeID, this->XMLCodeToNameTable_IndexID, 
        vec_t(&code, codeLen), name, nameLen, found);
	if (rc)
	{
        globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"XMLNameTable::getNameByCode",__FILE__,"");
		return NULL;
	}
    if (found) 
    {
#if (CDBG)
        cout << "found in shore <" << name << ">" << endl;
#endif
        addPairToTable(name, code, false); // name is allocated here, no need to allocate memory for it
        return name;
    }

    // return NULL if not found anywhere
#if (CDBG) 
    cout << "not found" << endl;
#endif
    return NULL;
}

/**
* addNameToTable: add a never-before-seen name into the im-meory table
* and in shore. This should only be called during loading time!
* numEntry should be modified!  Be aware that the numEntry and the 
* actual number of entries in memory is not the same!  numEntry reflects
* how many tag/attribute name of the same hash code has been encountered 
* for the entire volume!
* @return the code for the name, -1 if failed
*/
int XMLNameTable::addNameToTable (char *name)
{
    int hash = hashFunction(name);

    /**
    * add to in memory table
    * code is calculated such that code and name will share the same bucket
    */
    int pos = hashTable[hash].numEntry;
    int code = hash + pos*NameTableHashFactor;
    hashTable[hash].numEntry++;

    // find the first empty entry and instantiate it
    HashEntry *entry = hashTable[hash].entries;
    HashEntry *prevEntry = entry;
    while (entry != NULL) 
    {
        prevEntry = entry;
        entry = entry->next;
    }
    entry = new HashEntry();
    entry->code = code;
    entry->name = new char[strlen(name)+1];
    strcpy(entry->name, name);
    entry->next = NULL;
    if (prevEntry != NULL) prevEntry->next = entry;
    else hashTable[hash].entries = entry;

    // store into shore, notice that numEntry is also changed!
    char *cntName = new char[strlen(NameCodeIndexPrefix) + strlen(NameCodeIndexSuffix) + 3];
    memset(cntName, 0, strlen(NameCodeIndexPrefix) + strlen(NameCodeIndexSuffix) + 3);
    char temp[3] = "\0";
    int retval = 0;
    strcpy(cntName, NameCodeIndexPrefix);
    strcat(cntName, itoa(hash, temp, 10));
    strcat(cntName, NameCodeIndexSuffix);
    retval = storePairToDB(cntName, hashTable[hash].numEntry); // the numEntry pair

	delete cntName;

    if (retval == -1) return retval;
    retval = storePairToDB(name, code); // the (name, code) pair
    if (retval == -1) return retval;
    storePairToDB(code, name); // the (code, name) pair
    if (retval == -1) return retval;

    // successful, return the code
    return code;
}

/**
* addPairToTable: add a (name, code) pair into the in-memory table
* numEntry is not modified since no never-before-seen tag/attribute 
* name is encountered
* @return false if failed
*/
bool XMLNameTable::addPairToTable (char *name, int code, bool doNameAllocate)
{
    int hash = code % NameTableHashFactor;
    HashEntry *entry = hashTable[hash].entries;
    HashEntry *prevEntry = entry;
    while (entry != NULL) 
    {
        prevEntry = entry;
        entry = entry->next;
    }
    entry = new HashEntry();
    entry->code = code;
    if (doNameAllocate)
    {
        entry->name = new char[strlen(name)+1];
        strcpy(entry->name, name);
    } else
    {
        entry->name = name;
    }
    entry->next = NULL;
    if (prevEntry != NULL) prevEntry->next = entry;
    else hashTable[hash].entries = entry;
    return true;
}

/*---- Private Functions ----*/

/**
* In-memory hash related functions
*/
int XMLNameTable::hashFunction(int code)
{
    return (code % NameTableHashFactor);
}

int XMLNameTable::hashFunction(char *name)
{
    int total = 0;
    int len = (int) strlen(name);
    for (int i=0; i<len; i++) 
    {
        total += (int) name[i];
    }
    return (total % NameTableHashFactor);
}

/**
* Shore related functions
*/
int XMLNameTable::storePairToDB(char* name, int code)
{
    rc_t rc;
    int nameLen = (int) strlen(name);
    smsize_t codeLen = sizeof(int);
    
    // this is a numEntry pair, need to remove the old one
    if (!strncmp(name, "&", 1))
    {
        bool found;
        int tempCode;
        rc = ss_m::find_assoc(this->volumeID, this->XMLNameToCodeTable_IndexID, 
            vec_t(name, nameLen), &tempCode, codeLen, found);
        if (!rc && found)
	    {
            rc = ss_m::destroy_assoc(this->volumeID, this->XMLNameToCodeTable_IndexID, 
                vec_t(name, nameLen), vec_t(&tempCode, codeLen));
	    }
		if (!rc)
		{
			rc = ss_m::create_assoc(this->volumeID, this->XMLNameToCodeTable_IndexID, 
				vec_t(name, nameLen), vec_t(&code, codeLen));
		}
		if (rc)
		{
			globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"XMLNameTable::storePairToDB",__FILE__,"");
			return -1;
		}
    }
	else {
		
		rc = ss_m::create_assoc(this->volumeID, this->XMLNameToCodeTable_IndexID, 
			vec_t(name, nameLen), vec_t(&code, codeLen));

		if (rc)
		{
			globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"XMLNameTable::storePairToDB",__FILE__,"");
			return -1;
		}
	}
    return 0;
}

int XMLNameTable::storePairToDB(int code, char *name)
{
    rc_t rc;
    int nameLen = (int) strlen(name);
    smsize_t codeLen = sizeof(int);
    rc = ss_m::create_assoc(this->volumeID, this->XMLCodeToNameTable_IndexID, 
        vec_t(&code, codeLen), vec_t(name, nameLen));
    if (rc)
	{
        globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"XMLNameTable::storePairToDB",__FILE__,"");
		return -1;
	}
    return 0;
}
