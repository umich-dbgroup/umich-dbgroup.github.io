/*
COPYRIGHT  (c) 2000-2004 
THE REGENTS OF THE UNIVERSITY OF MICHIGAN
ALL RIGHTS RESERVED

PERMISSION IS GRANTED TO USE, COPY, CREATE DERIVATIVE WORKS AND
REDISTRIBUTE THIS SOFTWARE AND SUCH DERIVATIVE WORKS FOR NONCOMMERCIAL
EDUCATION AND RESEARCH PURPOSES, SO LONG AS NO FEE IS CHARGED, AND SO LONG
AS THE COPYRIGHT NOTICE ABOVE, THIS GRANT OF PERMISSION, AND THE
DISCLAIMER BELOW APPEAR IN ALL COPIES MADE; AND SO LONG AS THE NAME OF THE
UNIVERSITY OF MICHIGAN IS NOT USED IN ANY ADVERTISING OR PUBLICITY
PERTAINING TO THE USE OR DISTRIBUTION OF THIS SOFTWARE WITHOUT SPECIFIC,
WRITTEN PRIOR AUTHORIZATION.

THIS SOFTWARE IS PROVIDED AS IS, WITHOUT REPRESENTATION FROM THE
UNIVERSITY OF MICHIGAN AS TO ITS FITNESS FOR ANY PURPOSE, AND WITHOUT
WARRANTY BY THE UNIVERSITY OF MICHIGAN OF ANY KIND, EITHER EXPRESS OR
IMPLIED, INCLUDING WITHOUT LIMITATION THE IMPLIED WARRANTIES OF
MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE. THE REGENTS OF THE
UNIVERSITY OF MICHIGAN SHALL NOT BE LIABLE FOR ANY DAMAGES, INCLUDING
SPECIAL, INDIRECT, INCIDENTAL, OR CONSEQUENTIAL DAMAGES, WITH RESPECT TO
ANY CLAIM ARISING OUT OF OR IN CONNECTION WITH THE USE OF THE SOFTWARE,
EVEN IF IT HAS BEEN OR IS HEREAFTER ADVISED OF THE POSSIBILITY OF SUCH
DAMAGES.
*/

/**
 * @author Yuqing (Melanie) Wu
 */

#ifndef __XMLDocumentTable_H
#define __XMLDocumentTable_H

#include "../stdafx.h"

// this defines the maximum number of data files Timber holds
#define MAX_FILENUMER				100 //TODO: compile time parameter

/**
* class XMLDocumentTable
* 
* This class acts as a system catalog, which deals with storing information about files to the database.
* And provide name based file information access. 
* 
* @see PhysicalDataMng
*/

class XMLDocumentTable
{
public:
	/**
	* Constructor
	* 
	* Initialize the xml document table, locate or create the index that contains the info about the data files.
	* 
	* @param volumnID The id of the volume where the database is on. 
	*/
	XMLDocumentTable(lvid_t volumeID);
	~XMLDocumentTable();

	/**
	* Process Method
	* 
	* Insert the information of a file into the XMLDocumentTable in database
	* 
	* @param filename The name of the XML document stored in the data file
	* @param fileinfo Information about the data file
	* @returns Error  code.
	*/
	int insertFile(char* filename, FileInfoType* fileinfo);

	/**
	* Process Method
	* 
	* Set new file information to an existing file in the database.
	* This is done by remove the index item that associate the old file information with the file name
	* then insert a new item that reflect the new file information. 
	* 
	* @param filename The name of the data file whose information is to be changed
	* @param fileinfo The new information about the data file
	* @returns Error  code.
	*/
	int setFileInfo(char* filename, FileInfoType* fileinfo);

	/**
	* Process Method
	* 
	* Removed a data file and its information from the system catalog.
	* 
	* @param filename The name of the data file whose information is to be removed from the catalog
	* @returns Error code.
	*/
	bool deleteFile(char* filename);

	/**
	* Process Method
	* 
	* Given a file name, find out whether a data file with the name exists in the database
	* 
	* @param filename The name of data file which we are looking for.
	* @returns A boolean value which indicate whether file with the given name exists in the database or not.
	*/
	bool fileExist(char* filename);

	/**
	* Access Method
	* 
	* Get the information about a data file, given the file name
	* 
	* @param filename The name of data file which we are looking for.
	* @returns The information about the data file. NULL if file with the given name does not exist in the database. 
	*/
	FileInfoType* getFileInfo(char* filename);

	/**
	* Access Method
	* Get the name of all files in the database.
	* This is done by scanning the index that contains the filename-fileinfo mapping. 
	* 
	* @param num The number of files in the databse (return value).
	* @returns The name of the files. 
	*/
	char** getFileNames(int* num);

private:
	/** 
	* the id of the volume where the database is on. 
	*/
	lvid_t volumeID;

	/**
	* the id of the index served as a system catalog, mapping file name to file info.
	*/
	serial_t XMLDocumentTable_IndexID;

};

#endif
