/*
COPYRIGHT  (c) 2000-2004 
THE REGENTS OF THE UNIVERSITY OF MICHIGAN
ALL RIGHTS RESERVED

PERMISSION IS GRANTED TO USE, COPY, CREATE DERIVATIVE WORKS AND
REDISTRIBUTE THIS SOFTWARE AND SUCH DERIVATIVE WORKS FOR NONCOMMERCIAL
EDUCATION AND RESEARCH PURPOSES, SO LONG AS NO FEE IS CHARGED, AND SO LONG
AS THE COPYRIGHT NOTICE ABOVE, THIS GRANT OF PERMISSION, AND THE
DISCLAIMER BELOW APPEAR IN ALL COPIES MADE; AND SO LONG AS THE NAME OF THE
UNIVERSITY OF MICHIGAN IS NOT USED IN ANY ADVERTISING OR PUBLICITY
PERTAINING TO THE USE OR DISTRIBUTION OF THIS SOFTWARE WITHOUT SPECIFIC,
WRITTEN PRIOR AUTHORIZATION.

THIS SOFTWARE IS PROVIDED AS IS, WITHOUT REPRESENTATION FROM THE
UNIVERSITY OF MICHIGAN AS TO ITS FITNESS FOR ANY PURPOSE, AND WITHOUT
WARRANTY BY THE UNIVERSITY OF MICHIGAN OF ANY KIND, EITHER EXPRESS OR
IMPLIED, INCLUDING WITHOUT LIMITATION THE IMPLIED WARRANTIES OF
MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE. THE REGENTS OF THE
UNIVERSITY OF MICHIGAN SHALL NOT BE LIABLE FOR ANY DAMAGES, INCLUDING
SPECIAL, INDIRECT, INCIDENTAL, OR CONSEQUENTIAL DAMAGES, WITH RESPECT TO
ANY CLAIM ARISING OUT OF OR IN CONNECTION WITH THE USE OF THE SOFTWARE,
EVEN IF IT HAS BEEN OR IS HEREAFTER ADVISED OF THE POSSIBILITY OF SUCH
DAMAGES.
*/

/**
* @author Cong Yu
*/

#ifndef __XMLNameTable_H
#define __XMLNameTable_H

#define NameTableHashFactor 97
#define NameToCodeIndex "XMLNameToCodeIndex"
#define CodeToNameIndex "XMLCodeToNameIndex"
#define NameCodeIndexPrefix "&CNT"
#define NameCodeIndexSuffix ";"

namespace PHYSICAL_DATA_MNG
{
    /**
    * in-memory hash entry
    */
    struct HashEntry
    {
        char *name;
        int code;
        HashEntry *next;
    };

    /**
    * in-memory hash row
    */
    struct HashRow
    {
        int numEntry;
        HashEntry *entries;
    };
} // namespace PHYSICAL_DATA_MNG

using namespace PHYSICAL_DATA_MNG;

/**
* Class XMLNameTable
*   Mapping tag names into integer code
*/
class XMLNameTable
{
public:
    XMLNameTable(lvid_t volumeID);
    ~XMLNameTable();

    /**
    * interfaces to fetch name and/or code, and add new name entries
    */
    int getCodeByName (char *name);
    char* getNameByCode (int code);
    int addNameToTable (char *name);
    bool addPairToTable (char *name, int code, bool doNameAllocate);

private:
    /** 
    * variable: the id of the volume where the database is on. 
    */
    lvid_t volumeID;

    /**
    * variable: the ids of the indices: name to code & code to name
    */
    serial_t XMLNameToCodeTable_IndexID;
    serial_t XMLCodeToNameTable_IndexID;

    /**
    * variable: the internal in-memory hash table to speed up loading and 
    * querying.  It stores accessed tag/attribute names in the current session. 
    * Table is preallocated, but the rows in the table are dynamically allocated.
    * This seems to be the best compromise between memory usage and speed.
    */
    HashRow hashTable[NameTableHashFactor];

    /*----- In-memory hash table related stuff -----*/

    /**
    * I use a coding scheme such that both the code to name conversion 
    * and the name to code conversion can share the same hashTable.  
    * It is accomplished by hashing the corresponding name and code into 
    * the same hash bucket.  The encoding scheme is encapsulated inside 
    * XMLNameTable and can be changed later on.
    */
    int hashFunction (char *name);
    int hashFunction (int code);

    /*----- Shore related stuff -----*/

    /**
    * stores the (name, code) or (code, name) pair into Shore
    */
    int storePairToDB (char *name, int code);
    int storePairToDB (int code, char *name);
};

#endif
