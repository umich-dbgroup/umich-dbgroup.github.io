/*
COPYRIGHT  (c) 2000-2004 
THE REGENTS OF THE UNIVERSITY OF MICHIGAN
ALL RIGHTS RESERVED

PERMISSION IS GRANTED TO USE, COPY, CREATE DERIVATIVE WORKS AND
REDISTRIBUTE THIS SOFTWARE AND SUCH DERIVATIVE WORKS FOR NONCOMMERCIAL
EDUCATION AND RESEARCH PURPOSES, SO LONG AS NO FEE IS CHARGED, AND SO LONG
AS THE COPYRIGHT NOTICE ABOVE, THIS GRANT OF PERMISSION, AND THE
DISCLAIMER BELOW APPEAR IN ALL COPIES MADE; AND SO LONG AS THE NAME OF THE
UNIVERSITY OF MICHIGAN IS NOT USED IN ANY ADVERTISING OR PUBLICITY
PERTAINING TO THE USE OR DISTRIBUTION OF THIS SOFTWARE WITHOUT SPECIFIC,
WRITTEN PRIOR AUTHORIZATION.

THIS SOFTWARE IS PROVIDED AS IS, WITHOUT REPRESENTATION FROM THE
UNIVERSITY OF MICHIGAN AS TO ITS FITNESS FOR ANY PURPOSE, AND WITHOUT
WARRANTY BY THE UNIVERSITY OF MICHIGAN OF ANY KIND, EITHER EXPRESS OR
IMPLIED, INCLUDING WITHOUT LIMITATION THE IMPLIED WARRANTIES OF
MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE. THE REGENTS OF THE
UNIVERSITY OF MICHIGAN SHALL NOT BE LIABLE FOR ANY DAMAGES, INCLUDING
SPECIAL, INDIRECT, INCIDENTAL, OR CONSEQUENTIAL DAMAGES, WITH RESPECT TO
ANY CLAIM ARISING OUT OF OR IN CONNECTION WITH THE USE OF THE SOFTWARE,
EVEN IF IT HAS BEEN OR IS HEREAFTER ADVISED OF THE POSSIBILITY OF SUCH
DAMAGES.
*/

/**
 * @author Yuqing (Melanie) Wu
 */

// disable VC warning: vc7\include\xtree(1112) : warning C4702: unreachable code
#pragma warning(disable:4702)
#include "TestPhysicalDataMng.h"
#pragma warning(default:4702)
#include <time.h>

#define SIMPLE_COND		0

TestPhysicalDataMng::TestPhysicalDataMng(lvid_t vold_i, char* filename) :TestClass(vold_i, filename)
{
	this->initTestCode();
}

TestPhysicalDataMng::~TestPhysicalDataMng(void)
{
	delete this->physicalDataMng;
}

void TestPhysicalDataMng::initTestCode()
{
	this->testCodeMap.insert(StringIntMapType::value_type("TEST_DB_ONLY", TEST_DB_ONLY));
	this->testCodeMap.insert(StringIntMapType::value_type("TEST_LOADING", TEST_LOADING));
	this->testCodeMap.insert(StringIntMapType::value_type("TEST_APPENDING", TEST_APPENDING));
	this->testCodeMap.insert(StringIntMapType::value_type("TEST_SCANNING", TEST_SCANNING));
	this->testCodeMap.insert(StringIntMapType::value_type("TEST_FETCHING", TEST_FETCHING));
	this->testCodeMap.insert(StringIntMapType::value_type("TEST_UPDATE", TEST_UPDATE));
	this->testCodeMap.insert(StringIntMapType::value_type("TEST_COND_WRAP", TEST_COND_WRAP));
	
	this->testCodeMap.insert(StringIntMapType::value_type("SCAN_ALL", SCAN_ALL));
	this->testCodeMap.insert(StringIntMapType::value_type("SCAN_SIMPLE_COND", SCAN_SIMPLE_COND));
	this->testCodeMap.insert(StringIntMapType::value_type("SCAN_COMPLEX_COND", SCAN_COMPLEX_COND));
	this->testCodeMap.insert(StringIntMapType::value_type("SCAN_SIMPLE_RANGE", SCAN_SIMPLE_RANGE));
	this->testCodeMap.insert(StringIntMapType::value_type("SCAN_COMPLEX_RANGE", SCAN_COMPLEX_RANGE));

	printf("the choices for TestDataParser are:\n");

	StringIntMapType::iterator item = this->testCodeMap.begin();
	while (item != this->testCodeMap.end())
	{
		printf("%s %d\n", item->first, item->second);
		item++;
	}
}

void TestPhysicalDataMng::runTest()
{
	this->fpPara = fopen(this->filenamePara, "r");
	this->physicalDataMng = new PhysicalDataMng(this->volumeID);

    int testCode = this->getTestCode();
	while (testCode >= 0)
	{
		switch (testCode)
		{
		case TEST_DB_ONLY:
			this->testDBOnly();
			break;
		case TEST_LOADING: 
			this->testLoading();
			break;
		case TEST_APPENDING:
			this->testAppending();
			break;
		case TEST_SCANNING:
			this->testScan();
			break;
		case TEST_UPDATE:
			this->testUpdate();
			break;
		case TEST_COND_WRAP:
			this->testCondWrap();
			break;
		default:
			fclose(this->fpPara);
			break;
		}		
		testCode = this->getTestCode();
	}
}

void TestPhysicalDataMng::testDBOnly()
{
	lid_t rid;
	rc_t rc;
	append_file_i* apdHandler;
	pin_i pinHandler;

	int nodeNum;
	int intkey[2];
	int nodeinstr_len;
	char* nodeinstr;
	FileInfoType* fileinfo = new FileInfoType;

	fscanf(this->fpPara, "%d", &nodeNum);

	rc = ss_m::begin_xct();
	printf("begin transaction\n");

	rc = ss_m::create_file(this->volumeID, fileinfo->fid, ss_m::t_regular);
	if (rc)
	{
		printf("after create file\n");
		cout << rc <<  endl;
	}
	printf("create file\n");

	rc = ss_m::create_index(this->volumeID, ss_m::t_uni_btree, ss_m::t_regular, "i4i4", 0, fileinfo->keyIndex);
	if (rc)
	{
		printf("after create_index\n");
		cout << rc <<  endl;
	}
	printf("create index\n");

	apdHandler = new append_file_i(this->volumeID, fileinfo->fid);

	printf("new append_file_i\n");
	char* textVal = "aaaaaaaaaabbbbbbbbbbaaaaaaaaaabbbbbbbbbbaaaaaaaaaabbbbbbbbbbaaaaaaaaaabbbbbbbbbbaaaaaaaaaabbbbbbbbbbaaaaaaaaaabbbbbbbbbbaaaaaaaaaabbbbbbbbbbaaaaaaaaaabbbbbbbbbbaaaaaaaaaabbbbbbbbbb";
	serial_t srids[10000];
	serial_t srid;

	for (intkey[0]=0; intkey[0]<100; intkey[0]++)
    {
		for (intkey[1]=0; intkey[1]<100; intkey[1]++)
		{
			KeyType nodekey = intkey[0]*1000+intkey[1];
	
			DM_TextNode* textNode = new DM_TextNode(nodekey, 1, textVal);
			nodeinstr = textNode->wrap(&nodeinstr_len);
			delete textNode;

			vec_t data(nodeinstr, nodeinstr_len);
			rc = apdHandler->create_rec(vec_t(), nodeinstr_len, data, rid);
			if (rc)
			{
				printf("after create_rec in StartDocumentHandler\n");
				cout << rc << endl;
			}
			delete [] nodeinstr;

            srid = rid.serial;
			rc = ss_m::create_assoc(this->volumeID, fileinfo->keyIndex, 
						            vec_t(&intkey, sizeof(KeyType)), vec_t(&srid, sizeof(srid)));
			if (rc) 
			{
				printf("after create index for node, key=%s\n", nodekey.toString());
				cout << rc << endl;
			}
		}
    }
	delete apdHandler;
	printf("delete apdHandler\n");

	// scan the index
	int lb[2] = {10,0}; 
	int ub[2] = {12, 97};
	vec_t indexUpperBound(&lb, sizeof(KeyType));
	vec_t indexLowerBound(&ub, sizeof(KeyType));

	scan_index_i* indexScanHandler = new scan_index_i(this->volumeID, fileinfo->keyIndex, ss_m::ge, 			
								                      indexUpperBound, ss_m::le, indexLowerBound);	
	if (indexScanHandler->error_code())
	{
		printf("Error: error reported while start index scan in DataMng::reorganizeFile\n");
		cout << indexScanHandler->error_code() <<  endl;
	}
	else
	{
		bool eof = false; 
		serial_t srid;
		int indexKey[2];
		int keySize = sizeof(KeyType);
		vec_t* vecIndexKey = new vec_t(&indexKey, keySize);
		int ridSize = sizeof(serial_t);
		vec_t* vecRid = new vec_t(&srid, ridSize);

		while (!eof)
		{
			rc = indexScanHandler->next(eof);
			if (rc)
			{
				printf("Error: error reported after getting the next item from index, in DataMng::reorganizeFile\n");
				cout << rc <<  endl;
			}
			if (!eof)
			{
				rc = indexScanHandler->curr(vecIndexKey, (unsigned long &)keySize, vecRid, (unsigned long &)ridSize);
				printf("get index item: key = (%d, %d)\n", indexKey[0], indexKey[1]);
			}
		}

	}

	rc = ss_m::commit_xct();
	printf("commit transaction\n");

}

void TestPhysicalDataMng::testLoading()
{
	char tmpbuf[128];

	int retval;

	char filenamewithpath[200];
	char path[200];
	char filename[100];

	retval = fscanf(this->fpPara, "%s", filenamewithpath);
	PhysicalDataMng::parse_name(filenamewithpath, path, filename);

    /* Display operating system-style date and time. */
    _strtime( tmpbuf );
    printf( "OS time:\t\t\t\t%s\n", tmpbuf );

	this->loadXMLFile(filenamewithpath);
		
	_strtime( tmpbuf );
    printf( "OS time:\t\t\t\t%s\n", tmpbuf );

	this->printFile(filename);
}


void TestPhysicalDataMng::testAppending()
{
	char tmpbuf[128];

	int retval;

	char filenamewithpath1[200];
	char filenamewithpath2[200];
	char path[200];
	char filename1[100];
	char filename2[100];

	retval = fscanf(this->fpPara, "%s", filenamewithpath1);
	PhysicalDataMng::parse_name(filenamewithpath1, path, filename1);
	retval = fscanf(this->fpPara, "%s", filenamewithpath2);
	PhysicalDataMng::parse_name(filenamewithpath2, path, filename2);

	if (!this->dataLoaded(filename1))
	{
		_strtime( tmpbuf );
		printf( "OS time:\t\t\t\t%s\n", tmpbuf );

		this->loadXMLFile(filenamewithpath1);
			
		_strtime( tmpbuf );
		printf( "OS time:\t\t\t\t%s\n", tmpbuf );

		this->printFile(filename1);
	}

	this->printFile(filename1);

	KeyType rootS, rootE;
	retval = this->physicalDataMng->appendXMLFile(filenamewithpath2, 100, filename1, 0, &rootS, &rootE);
	if (retval < 0) printf("loading problem\n");
	printf("loading successful. The root of the new document is not at (%s, %s)\n", rootS, rootE);

    _strtime( tmpbuf );
    printf( "OS time:\t\t\t\t%s\n", tmpbuf );

	this->printFile(filename1);
}

int TestPhysicalDataMng::loadXMLFile(char* filenamewithpath)
{
	char filename[100];
	char path[200];
	PhysicalDataMng::parse_name(filenamewithpath, path, filename);
	
	KeyType rootkey;
	int retval;

	this->physicalDataMng->beginTransaction();
	retval = this->physicalDataMng->loadXMLFile(filenamewithpath);
	if (retval < 0) printf("loading problem\n");

	FileInfoType* fileinfo = this->physicalDataMng->getFileInfo(filename);
	if (fileinfo == NULL)
	{
		printf("loading is not successful\n");
		retval = -1;
	}
	else 
	{
		printf("loading successful\n");
		retval = 0;
	}
	this->physicalDataMng->endTransaction();

	return retval;
}

bool TestPhysicalDataMng::dataLoaded(char* filename)
{
	bool loaded;
	this->physicalDataMng->beginTransaction();
	FileInfoType* fileinfo = this->physicalDataMng->getFileInfo(filename);
	if (fileinfo == NULL) loaded = false;
	else loaded = true;
	this->physicalDataMng->endTransaction();
	return loaded;
}

void TestPhysicalDataMng::testScan()
{
	int retval;

	char filenamewithpath[200];
	char path[200];
	char filename[100];

	retval = fscanf(this->fpPara, "%s", filenamewithpath);
	PhysicalDataMng::parse_name(filenamewithpath, path, filename);

	if (!this->dataLoaded(filename))
	{
		this->testLoading();
		if (!this->dataLoaded(filename))
		{
			printf("could not load the data file for scan testing\n");
			return;
		}
	}

	int testNum;
	int testCode;
	retval = fscanf(this->fpPara, "%d", &testNum);

	FileInfoType* fileinfo;
	ScanInfo* scaninfo;

	KeyType rootKey;
	KeyType cntKey;
	DM_DataNode* node;

	SelectionCondition* scancond;
	DisjunctiveCondition* discond;
	ConjunctiveCondition* concond;
	PredicateCondition* predicate;
	int leftval;
	int op;
	Value* rightval;

	ScanRange* scanRanges;
	ScanRangeType* scanRange;

	int count;

	for (int tn = 0; tn < testNum; tn++)
	{
		testCode = this->getTestCode();

		switch (testCode)
		{
		case SCAN_ALL:
			{
				printf("------------------------------------------------\n");
				printf("test scan with empty condition (scan the whole document)\n");
				
				this->physicalDataMng->beginTransaction();

				fileinfo = this->physicalDataMng->getFileInfo(filename);
				rootKey = fileinfo->rootKey;
				if (fileinfo == NULL)
				{
					printf("can not open file with name %s\n", filename);
					return;
				}

				printf("rootKey = %s\n", rootKey.toString());
				cntKey = rootKey;

				discond = new DisjunctiveCondition(0);
				scancond = new SelectionCondition(SCAN_ALLNODES, discond, SCAN_RETURN_THISNODE);
				scaninfo = this->physicalDataMng->startScan(fileinfo, rootKey, 0, -1, NULL, scancond);
				node = this->physicalDataMng->scanFetchNext(scaninfo);
				count = 0;
				while (node!= NULL)
				{
					printf("key = %s, endkey = %s, tag = %d\n", node->getKey().toString(), 
                            node->getEndKey().toString(), node->getTag());
					delete node;
					count++;
					node = this->physicalDataMng->scanFetchNext(scaninfo);
				}
				printf("totaly number of result = %d\n", count);
				this->physicalDataMng->clearScan(scaninfo);
				this->physicalDataMng->endTransaction();
			}
			break;

		case SCAN_SIMPLE_COND:
			{
				printf("------------------------------------------------\n");
				printf("test scan with simple condition\n");
				
				for (int targetNodeType = 0; targetNodeType < 4; targetNodeType++)
					for (int leftValueType = 0; leftValueType <= 9; leftValueType++)
						for (int opType = 1; opType <= 9; opType++)
						{
							if ((targetNodeType == ELEMENT_NODE) && (leftValueType == SCAN_LEFTVALUE_NODETAG) && (opType == SCAN_OP_EQ))
								printf("---\n");

							scancond = constructScanCond(SIMPLE_COND, targetNodeType, leftValueType, opType);
							scancond->printSelectionCondition();
							this->physicalDataMng->beginTransaction();

							fileinfo = this->physicalDataMng->getFileInfo(filename);
							if (fileinfo == NULL)
							{
								printf("can not open file with name %s\n", filename);
								return;
							}

							printf("rootKey = %s\n", rootKey.toString());
							cntKey = rootKey;

							scaninfo = this->physicalDataMng->startScan(fileinfo, rootKey, 0, -1, NULL, scancond);
							if (scaninfo != NULL)
							{
								node = this->physicalDataMng->scanFetchNext(scaninfo);
								count = 0;
								while (node!= NULL)
								{
									printf("key = %s, endkey = %s, tag = %d\n", node->getKey().toString(), 
                                            node->getEndKey().toString(), node->getTag());
									delete node;
									count++;
									node = this->physicalDataMng->scanFetchNext(scaninfo);
								}
								printf("totaly number of result = %d\n", count);
								
								this->physicalDataMng->clearScan(scaninfo);
							}
							else 
								printf("does not open a valid scan\n");
								
							printf("*******************\n\n");

							this->physicalDataMng->endTransaction();
						}
			}
			break;

		case SCAN_COMPLEX_COND:
			{
				printf("------------------------------------------------\n");
				printf("test scan with complex condition\n");

				this->physicalDataMng->beginTransaction();
				fileinfo = this->physicalDataMng->getFileInfo(filename);
				if (fileinfo == NULL)
				{
					printf("can not open file with name %s\n", filename);
					return;
				}

				printf("rootKey = %s\n", rootKey.toString());
				cntKey = rootKey;

				discond = new DisjunctiveCondition(2);
				concond = new ConjunctiveCondition(3);
							
				leftval = SCAN_LEFTVALUE_NODETAG;
				op = SCAN_OP_EQ;
				rightval = new Value(STRING_VALUE);
				rightval->setStrValue("Degree");	
				predicate = new PredicateCondition(leftval, op, rightval);
				concond->insertCond(predicate);

				leftval = SCAN_LEFTVALUE_HASATTRIBUTE;
				op = SCAN_OP_EQ;
				rightval = new Value(STRING_VALUE);
				rightval->setStrValue("id");	
				predicate = new PredicateCondition(leftval, op, rightval);
				concond->insertCond(predicate);

				leftval = SCAN_LEFTVALUE_ELEMENTCONTENT;
				op = SCAN_OP_EQ;
				rightval = new Value(STRING_VALUE);
				rightval->setStrValue("Masters");	
				predicate = new PredicateCondition(leftval, op, rightval);
				concond->insertCond(predicate);

				discond->insertCond(concond);

				concond = new ConjunctiveCondition(2);

				leftval = SCAN_LEFTVALUE_NODETAG;
				op = SCAN_OP_EQ;
				rightval = new Value(STRING_VALUE);
				rightval->setStrValue("Student");	
				predicate = new PredicateCondition(leftval, op, rightval);
				concond->insertCond(predicate);

				leftval = SCAN_LEFTVALUE_CHILDNUMBER;
				op = SCAN_OP_EQ;
				rightval = new Value(INT_VALUE);
				rightval->setIntValue(2);	
				predicate = new PredicateCondition(leftval, op, rightval);
				concond->insertCond(predicate);

				discond->insertCond(concond);

				scancond = new SelectionCondition(ELEMENT_NODE, discond, SCAN_RETURN_THISNODE);
				scaninfo = this->physicalDataMng->startScan(fileinfo, rootKey, 0, -1, NULL, scancond);

				node = this->physicalDataMng->scanFetchNext(scaninfo);
				count = 0;
				while (node!= NULL)
				{
					printf("key = %s, endkey = %s, tag = %d\n", node->getKey().toString(), 
                            node->getEndKey().toString(), node->getTag());
					delete node;
					count++;
					node = this->physicalDataMng->scanFetchNext(scaninfo);
				}
				printf("totaly number of result = %d\n", count);
				
				this->physicalDataMng->clearScan(scaninfo);

				this->physicalDataMng->endTransaction();
			}
			break;

		case SCAN_SIMPLE_RANGE:
			{
				printf("------------------------------------------------\n");
				printf("test scan with scan range\n");

				this->physicalDataMng->beginTransaction();

				fileinfo = this->physicalDataMng->getFileInfo(filename);
				rootKey = fileinfo->rootKey;
				if (fileinfo == NULL)
				{
					printf("can not open file with name %s\n", filename);
					return;
				}

				printf("rootKey = %s\n", rootKey.toString());
				cntKey = rootKey;

				discond = new DisjunctiveCondition(1);
				concond = new ConjunctiveCondition(1);
							
				leftval = SCAN_LEFTVALUE_NODETAG;
				op = SCAN_OP_EQ;
				rightval = new Value(STRING_VALUE);
				rightval->setStrValue("Degree");	
				predicate = new PredicateCondition(leftval, op, rightval);

				concond->insertCond(predicate);
				discond->insertCond(concond);

				scancond = new SelectionCondition(ELEMENT_NODE, discond, SCAN_RETURN_THISNODE);
				scanRanges = new ScanRange(1);
				scanRange = new ScanRangeType();
				scanRange->startPos = 35;
				scanRange->endPos = 50;
				scanRanges->setScanRangeAt(0, scanRange);

				scaninfo = this->physicalDataMng->startScan(fileinfo, cntKey, 0, -1, scanRanges, scancond);

				if (scaninfo == NULL) return;

				node = this->physicalDataMng->scanFetchNext(scaninfo);
				count = 0;
				while (node!= NULL)
				{
					printf("key = %s, endkey = %s, tag = %d\n", node->getKey().toString(), 
                            node->getEndKey().toString(), node->getTag());
					delete node;
					count++;
					node = this->physicalDataMng->scanFetchNext(scaninfo);
				}
				printf("totaly number of result = %d\n", count);
				
				this->physicalDataMng->clearScan(scaninfo);

				this->physicalDataMng->endTransaction();
			}
			break;

		case SCAN_COMPLEX_RANGE:
			{
				printf("------------------------------------------------\n");
				printf("test scan with multiple scan ranges\n");

				this->physicalDataMng->beginTransaction();

				fileinfo = this->physicalDataMng->getFileInfo(filename);
				rootKey = fileinfo->rootKey;
				if (fileinfo == NULL)
				{
					printf("can not open file with name %s\n", filename);
					return;
				}

				printf("rootKey = %s\n", rootKey.toString());
				cntKey = rootKey;

				discond = new DisjunctiveCondition(1);
				concond = new ConjunctiveCondition(1);
							
				leftval = SCAN_LEFTVALUE_NODETAG;
				op = SCAN_OP_EQ;
				rightval = new Value(STRING_VALUE);
				rightval->setStrValue("Degree");	
				predicate = new PredicateCondition(leftval, op, rightval);

				concond->insertCond(predicate);
				discond->insertCond(concond);

				scancond = new SelectionCondition(ELEMENT_NODE, discond, SCAN_RETURN_THISNODE);
				scanRanges = new ScanRange(2);

				scanRange = new ScanRangeType();
				scanRange->startPos = 10;
				scanRange->endPos = 25;
				scanRanges->setScanRangeAt(0, scanRange);

				scanRange = new ScanRangeType();
				scanRange->startPos = 35;
				scanRange->endPos = 50;
				scanRanges->setScanRangeAt(1, scanRange);


				scaninfo = this->physicalDataMng->startScan(fileinfo, rootKey, 0, -1, scanRanges, scancond);

				node = this->physicalDataMng->scanFetchNext(scaninfo);
				count = 0;
				while (node!= NULL)
				{
					printf("key = %s, endkey = %s, tag = %d\n", node->getKey().toString(), 
                            node->getEndKey().toString(), node->getTag());
					delete node;
					count++;
					node = this->physicalDataMng->scanFetchNext(scaninfo);
				}
				printf("totaly number of result = %d\n", count);
				
				this->physicalDataMng->clearScan(scaninfo);
				this->physicalDataMng->endTransaction();
			}
			break;

		default:
			printf("not valid scan test choice\n");
			break;
		}
	}
}

void TestPhysicalDataMng::testUpdate()
{
	char filenamewithpath[200];
	char filename[100];
	char path[200];
	
	fscanf(this->fpPara, "%s", filenamewithpath);
	PhysicalDataMng::parse_name(filenamewithpath, path, filename);

	if (!this->dataLoaded(filename))
	{
		this->loadXMLFile(filenamewithpath);
		if (!this->dataLoaded(filename))
		{
			printf("could not load the data file for scan testing\n");
			return;
		}
	}

	FileInfoType* fileinfo;

	KeyType rootkey;

	DM_DataNode* node;
	KeyType	nodekey;
	serial_t noderid;

	// used for insertion
	KeyType newEleKey;
	KeyType newTextKey;
	KeyType newAttrKey;

	this->physicalDataMng->beginTransaction();
	fileinfo = this->physicalDataMng->getFileInfo(filename);
	rootkey = fileinfo->rootKey;

	printf("the data in the database before update\n");
	this->fullScanSubtree(fileinfo, rootkey);

	printf("\n------------------------------------------\n");
	printf("test node modification\n");

	node = this->physicalDataMng->fetchDataNodeFromDBFile((const FileInfoType) *fileinfo, KeyType(15), &noderid);
	nodekey = node->getKey();
	node->printValue();

	node->setTag(23);

	this->physicalDataMng->modifyNodeInDBFile(fileinfo, node->getKey(), node);
	node = this->physicalDataMng->fetchDataNodeFromDBFile((const FileInfoType) *fileinfo, KeyType(15), &noderid);

	printf("\nafter modification, from DB:\n");
	node->printValue();

	delete fileinfo;
	this->physicalDataMng->endTransaction();

	this->printFile(filename);
}

void TestPhysicalDataMng::testCondWrap()
{
	SelectionCondition* cond;
	SelectionCondition* newcond;
	char* buffer;
	int len;

	cond = new SelectionCondition(ELEMENT_NODE, NULL, SCAN_RETURN_THISNODE);
	buffer = cond->wrap(&len);
	newcond = new SelectionCondition(buffer);

	newcond->printSelectionCondition();

	delete cond;
	delete newcond;

	Value* val = new Value(STRING_VALUE);
	val->setStrValue("aaa");
	PredicateCondition* predicate = new PredicateCondition(SCAN_LEFTVALUE_NODETAG, SCAN_OP_EQ, val);
	ConjunctiveCondition* conjcond = new ConjunctiveCondition(1);
	conjcond->insertCond(predicate);
	DisjunctiveCondition* disjcond = new DisjunctiveCondition(1);
	disjcond->insertCond(conjcond);

	cond = new SelectionCondition(ELEMENT_NODE,disjcond, SCAN_RETURN_THISNODE);
	buffer = cond->wrap(&len);
	newcond = new SelectionCondition(buffer);

	newcond->printSelectionCondition();
	delete cond;
	delete newcond;
}

#pragma warning(disable:4100)
SelectionCondition* TestPhysicalDataMng::constructScanCond(int condType, int targetNode, int leftValue, int op)
{
	SelectionCondition* scancond;
	DisjunctiveCondition* discond;
	ConjunctiveCondition* concond;
	PredicateCondition* predicate;
	Value* rightval = NULL;

	discond = new DisjunctiveCondition(1);
	concond = new ConjunctiveCondition(1);
	
	switch (leftValue)
	{
	case SCAN_LEFTVALUE_VALUE:
		rightval = new Value(STRING_VALUE);
		rightval->setStrValue("Degree");
		break;

	case SCAN_LEFTVALUE_LENGTH:
		rightval = new Value(INT_VALUE);
		rightval->setIntValue(6);
		break;
	case SCAN_LEFTVALUE_XMLFILENAME:
		rightval = new Value(STRING_VALUE);
		rightval->setStrValue("testdata1.xml");
		break;
	case SCAN_LEFTVALUE_DTDFILENAME:
		rightval = new Value(STRING_VALUE);
		rightval->setStrValue("dtd");
		break;
	case SCAN_LEFTVALUE_NODETAG:
		rightval = new Value(STRING_VALUE);
		rightval->setStrValue("Degree");
		break;
	case SCAN_LEFTVALUE_CHILDNUMBER:
		rightval = new Value(INT_VALUE);
		rightval->setIntValue(2);
		break;
	case SCAN_LEFTVALUE_ATTRIBUTENUMBER:
		rightval = new Value(INT_VALUE);
		rightval->setIntValue(1);
		break;
	case SCAN_LEFTVALUE_HASCHILD:
		rightval = new Value(STRING_VALUE);
		rightval->setStrValue("Degree");
		break;
	case SCAN_LEFTVALUE_HASATTRIBUTE:
		rightval = new Value(STRING_VALUE);
		rightval->setStrValue("id");
		break;
	case SCAN_LEFTVALUE_ELEMENTCONTENT:
		rightval = new Value(STRING_VALUE);
		rightval->setStrValue("Ph.D");
		break;
	}
	
	predicate = new PredicateCondition(leftValue, op, rightval);

	concond->insertCond(predicate);
	discond->insertCond(concond);
	scancond = new SelectionCondition(targetNode, discond, SCAN_RETURN_THISNODE);
	return scancond;

}
#pragma warning(default:4100)

void TestPhysicalDataMng::scanSubTreeForTag(FileInfoType* fileinfo, KeyType rootkey, char* tag)
{
	if (tag == NULL)
		this->fullScanSubtree(fileinfo, rootkey);
	else
	{
		SelectionCondition* scancond;
		DisjunctiveCondition* discond;
		ConjunctiveCondition* concond;
		PredicateCondition* predicate;
		Value* rightval;

		discond = new DisjunctiveCondition(1);
		concond = new ConjunctiveCondition(1);
					
		rightval = new Value(STRING_VALUE);
		rightval->setStrValue(tag);	
		predicate = new PredicateCondition(SCAN_LEFTVALUE_NODETAG, SCAN_OP_EQ, rightval);

		concond->insertCond(predicate);
		discond->insertCond(concond);
		scancond = new SelectionCondition(ELEMENT_NODE, discond, SCAN_RETURN_THISNODE);
		this->scanAndPrint(fileinfo, rootkey, scancond, NULL);
	}
}

void TestPhysicalDataMng::fullScanSubtree(FileInfoType* fileinfo, KeyType rootkey)
{
	SelectionCondition* scancond;
	scancond = new SelectionCondition(SCAN_ALLNODES, NULL, SCAN_RETURN_THISNODE);
	this->scanAndPrint(fileinfo, rootkey, scancond, NULL);
}

void TestPhysicalDataMng::scanAndPrint(FileInfoType* fileinfo, KeyType rootkey, 
							           SelectionCondition* scancond, ScanRange* ranges)
{
	ScanInfo* scaninfo;
	DM_DataNode* node;

	scaninfo = this->physicalDataMng->startScan(fileinfo, rootkey, 0, -1, ranges, scancond);
	if (scaninfo != NULL)
	{
		node = this->physicalDataMng->scanFetchNext(scaninfo);
		while (node!= NULL)
		{
		printf("key = %s, endkey = %s, level = %d, parent = %s, prevSibling = %s, next Sibling = %s, ",  
			node->getKey().toString(), node->getEndKey().toString(), node->getLevel(), 
				node->getParent().toString(), node->getPrevSibling().toString(), node->getNextSibling().toString());
			if ((node->getFlag() == ELEMENT_NODE) || (node->getFlag() == DOCUMENT_NODE))
				printf("tag = %d, childnumber = %d, firstchild = %s, lastchild = %s\n",
						node->getTag(),	node->getChildNumber(), node->getFirstChild().toString(), 
						node->getLastChild().toString());
			else if (node->getFlag() == TEXT_NODE)
				printf("text = %s\n ", ((DM_TextNode*) node)->getCharValue());
			else if (node->getFlag() == ATTRIBUTE_NODE)
				printf(" attribute-node\n");

			delete node; 
			node = this->physicalDataMng->scanFetchNext(scaninfo);
		}
		printf("after fetching the last node\n");
		this->physicalDataMng->clearScan(scaninfo);
	}
	else 
		printf("error reported while starting scan\n");
}

void TestPhysicalDataMng::fetchANode(FileInfoType* fileinfo, KeyType nodekey)
{
	DM_DataNode* node = this->physicalDataMng->fetchDataNodeFromDBFile((const FileInfoType) *fileinfo, nodekey);
	if (node == NULL)
		printf("Warning: can not find node with key = %s\n", nodekey.toString());
	else
	{
		printf("key = %s, endkey = %s, level = %d, parent = %s, prevSibling = %s, next Sibling = %s, ",  
				node->getKey().toString(), node->getEndKey().toString(), node->getLevel(), 
				node->getParent().toString(), node->getPrevSibling().toString(), node->getNextSibling().toString());
		if ((node->getFlag() == ELEMENT_NODE) || (node->getFlag() == DOCUMENT_NODE))
			printf("tag = %d, childnumber = %d, firstchild = %s, lastchild = %s\n",
					node->getTag(),	node->getChildNumber(), node->getFirstChild().toString(),
					node->getLastChild().toString());
		else if (node->getFlag() == TEXT_NODE)
			printf("text = %s\n ", ((DM_TextNode*) node)->getCharValue());
		else if (node->getFlag() == ATTRIBUTE_NODE)
			printf(" attribute-node\n");
		
		delete node;
	}
}

void TestPhysicalDataMng::printFile(char* filename)
{
	FileInfoType* fileinfo;
	ScanInfo* scaninfo;
	SelectionCondition* scancond;
	KeyType rootkey;
	DM_DataNode* node;

	this->physicalDataMng->beginTransaction();
	fileinfo = this->physicalDataMng->getFileInfo(filename);
	rootkey = fileinfo->rootKey;
	if (fileinfo == NULL)
		printf("file does not exist\n");
	else 
	{
		scancond = new SelectionCondition(SCAN_ALLNODES, NULL, SCAN_RETURN_THISNODE);
		scaninfo = this->physicalDataMng->startScan(fileinfo, rootkey, 0, -1, NULL, scancond);
		if (scaninfo != NULL)
		{
			node = this->physicalDataMng->scanFetchNext(scaninfo);
            while (node!= NULL)
            {
                //node->printValue();
                printf("key = %s, endkey = %s, level = %d, parent = %s, prevSibling = %s, next Sibling = %s, ",  
                    node->getKey().toString(), node->getEndKey().toString(), node->getLevel(), 
                    node->getParent().toString(), node->getPrevSibling().toString(), node->getNextSibling().toString());
                if ((node->getFlag() == ELEMENT_NODE) || (node->getFlag() == DOCUMENT_NODE))
                    printf("tag = %d, childnumber = %d, firstchild = %s, lastchild = %s\n",
                    node->getTag(),	node->getChildNumber(), 
                    node->getFirstChild().toString(),
                    node->getLastChild().toString());
                else if (node->getFlag() == TEXT_NODE)
                    printf("text = %s\n ", ((DM_TextNode*) node)->getCharValue());
                else if (node->getFlag() == ATTRIBUTE_NODE)
                    printf(" attribute-node\n");
                delete node; 
                node = this->physicalDataMng->scanFetchNext(scaninfo);
            }
			this->physicalDataMng->clearScan(scaninfo);
		}
		else 
			printf("error reported while starting scan\n");
	}
	this->physicalDataMng->endTransaction();
}
