/*
COPYRIGHT  (c) 2000-2004 
THE REGENTS OF THE UNIVERSITY OF MICHIGAN
ALL RIGHTS RESERVED

PERMISSION IS GRANTED TO USE, COPY, CREATE DERIVATIVE WORKS AND
REDISTRIBUTE THIS SOFTWARE AND SUCH DERIVATIVE WORKS FOR NONCOMMERCIAL
EDUCATION AND RESEARCH PURPOSES, SO LONG AS NO FEE IS CHARGED, AND SO LONG
AS THE COPYRIGHT NOTICE ABOVE, THIS GRANT OF PERMISSION, AND THE
DISCLAIMER BELOW APPEAR IN ALL COPIES MADE; AND SO LONG AS THE NAME OF THE
UNIVERSITY OF MICHIGAN IS NOT USED IN ANY ADVERTISING OR PUBLICITY
PERTAINING TO THE USE OR DISTRIBUTION OF THIS SOFTWARE WITHOUT SPECIFIC,
WRITTEN PRIOR AUTHORIZATION.

THIS SOFTWARE IS PROVIDED AS IS, WITHOUT REPRESENTATION FROM THE
UNIVERSITY OF MICHIGAN AS TO ITS FITNESS FOR ANY PURPOSE, AND WITHOUT
WARRANTY BY THE UNIVERSITY OF MICHIGAN OF ANY KIND, EITHER EXPRESS OR
IMPLIED, INCLUDING WITHOUT LIMITATION THE IMPLIED WARRANTIES OF
MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE. THE REGENTS OF THE
UNIVERSITY OF MICHIGAN SHALL NOT BE LIABLE FOR ANY DAMAGES, INCLUDING
SPECIAL, INDIRECT, INCIDENTAL, OR CONSEQUENTIAL DAMAGES, WITH RESPECT TO
ANY CLAIM ARISING OUT OF OR IN CONNECTION WITH THE USE OF THE SOFTWARE,
EVEN IF IT HAS BEEN OR IS HEREAFTER ADVISED OF THE POSSIBILITY OF SUCH
DAMAGES.
*/

/**
 * @author Yuqing (Melanie) Wu
 */

#include "StdAfx.h"
#include "physicaldatamng.h"
#include "../Utilities/ErrorInfoClass.h"
extern ErrorInfoClass globalErrorInfo;

#include <sstream>

/**
* Physcial Data Manager
* 
* This class is the physical data manager which interact with the storage management product (shore/berkeleydb)
* and provide single node/tuple access interface to the database. 
*
* It handles the lower-level data management of TIMBER, including:
*		data loading interface
*		single node process interface
*		navigation interface
*		scan interface
* and numerous other supporting functions.
*
* @see MSXMLParser
* @see DataMng
*/


/**
* Constructor
* Create a new DataMng instance with a given volume id of Shore/BerkeleyDB.
* Initialize the XMLDocumentTable.
*@param vol_id The volumn ID of SHORE/BerkeleyDB
*/
PhysicalDataMng::PhysicalDataMng(lvid_t vol_id)
{
	this->volumeID = vol_id;
	this->xmlDocumentTable = new XMLDocumentTable(this->volumeID);
    this->xmlNameTable = new XMLNameTable(this->volumeID);
	this->inTransaction = false;
}

/**
* Destructor
*
* Free space allocated for xmlDocumentTable
*/
PhysicalDataMng::~PhysicalDataMng()
{
	if (this->xmlDocumentTable) delete this->xmlDocumentTable;
    if (this->xmlNameTable) delete this->xmlNameTable;
}

/** 
* Access  Method
* Get the volumnID where the database is on
*/
lvid_t PhysicalDataMng::getVolumeID()
{
	return this->volumeID;
}

/**
* Process Method
* Begin a transaction in the SHORE/BerkeleyDB.
* This function, together with endTransaction, allow the user of PhysicalDataMng to control the 
* scope of a transaction. 
* 
* TRICK: To avoid portential error, such as begin transaction inside an active transaction, a variable "inTransaction"
* is kept in PhysicalDataMng. The begin_xct is called only when it is not currently inside an active transaction. 
* The variable is set to be true if begin_xct is called and is done successfully. 
*/
void PhysicalDataMng::beginTransaction()
{
    if (this->inTransaction) 
	{
		// if it is currently inside an active transaction, do nothing.
        globalErrorInfo.insertProblem(ERR_TYPE_WARNING,__LINE__,"PhysicalDataMng::beginTransaction",__FILE__,"Already in active transaction");
		return;
	}

	rc_t rc = ss_m::begin_xct();
	if (rc)
	{
        globalErrorInfo.insertProblem(ERR_TYPE_WARNING,__LINE__,"PhysicalDataMng::beginTransaction",__FILE__,"Error reported after begin transaction");
	}

	// set the inTransaction flag.
	this->inTransaction = true;
}

/**
* Process Method
* End a transaction in the SHORE/BerkeleyDB.
* This function, together with beginTransaction, allow the user of PhysicalDataMng to control the 
* scope of a transaction. 
* 
* TRICK: To avoid portential error, such as calling end transaction while there is no active transaction,
* a variable "inTransaction" is kept in PhysicalDataMng. The commit_xct is called only when it is currently 
* inside an active transaction. The variable is set to be false if commit_xct is called and is done 
* successfully. 
*/
void PhysicalDataMng::endTransaction()
{
	if (!this->inTransaction) 
	{
		// if it is not currently inside an active transaction, do nothing.
        globalErrorInfo.insertProblem(ERR_TYPE_WARNING,__LINE__,"PhysicalDataMng::endTransaction",__FILE__,"Currrently not in an active transaction");
		return;
	}

	rc_t rc = ss_m::commit_xct();
	if (rc)
	{
        globalErrorInfo.insertProblem(ERR_TYPE_WARNING,__LINE__,"PhysicalDataMng::endTransaction",__FILE__,"Error reported after commit transaction");
	}

	// set the inTransaction flag.
	this->inTransaction = false;
}	

/**
* Process Method
* Abort a transaction in the SHORE/BerkeleyDB.
* This function, together with beginTransaction and endTransaction, allow the user of PhysicalDataMng to control the 
* scope of a transaction and enforce . 
* 
* TRICK: To avoid portential error, such as calling end transaction while there is no active transaction,
* a variable "inTransaction" is kept in PhysicalDataMng. The abort_xact is called only when it is currently 
* inside an active transaction. The variable is set to be false if abort_xct is called and is done 
* successfully. 
*/
void PhysicalDataMng::abortTransaction()
{
	if (!this->inTransaction) 
	{
		// if it is not currently inside an active transaction, do nothing.
        globalErrorInfo.insertProblem(ERR_TYPE_WARNING,__LINE__,"PhysicalDataMng::abortTransaction",__FILE__,"Currrently not in an active transaction");
		return;
	}

	rc_t rc = ss_m::abort_xct();
	if (rc)
	{
        globalErrorInfo.insertProblem(ERR_TYPE_WARNING,__LINE__,"PhysicalDataMng::abortTransaction",__FILE__,"Cannot properly abort a transaction");
	}

	// set the inTransaction flag.
	this->inTransaction = false;
}
/* ----------------------------------------------------------- */
/*						file interface					       */
/* ----------------------------------------------------------- */

/**
* File Interface
* 
* Find out whether XML document with the given name exists in the database or not. 
*
*@param filename The name of the file to look for.
*@returns A boolean value which indicate whether the file exists in the database or not. 
*/
bool PhysicalDataMng::fileExist(char* filename)
{
	// The variable getinxcthere means "get in transaction here". 
	// It indicate whether we enter a transaction in this function, trigered by PhysicalDataMng.
	// If so, we will commit this transaction at the end of the function. 
	// This variable is used in all functions in PhysicalDataMng. Will not comment it later. 

	bool getinxcthere = false;	
	if (!this->inTransaction)
	{
		// start transaction, since we are about to access record in the database
		this->beginTransaction();
		getinxcthere = true;
	}

	// find out whether the file exists, through xmlDocumentTable.
	bool exist = this->xmlDocumentTable->fileExist(filename);

	// commit the transaction is we enter a transaction here. 
	if (getinxcthere) this->endTransaction();
	return exist;
}

/**
* File Interface
* 
* Get the information about an XML document in the database.
* 
*@param filename The name of the file whose information is to be obtained.
*@returns The information about the file, in FileInfoType. Return NULL when the file does not exist in the database.
*
*@seealso FileInfoType
*/
FileInfoType* PhysicalDataMng::getFileInfo(char* filename)
{
	bool getinxcthere = false;
	if (!this->inTransaction)
	{
		this->beginTransaction();
		getinxcthere = true;
	}

	// get the information of the file through xmlDocumentTable.
	FileInfoType* fileinfo =  this->xmlDocumentTable->getFileInfo(filename);

	if (getinxcthere) this->endTransaction();
	return fileinfo;
}

/**
* File Interface
* 
* Reset the fileinfo when the information about a file is changed. 
* The following are some example of the changes: new document is appended to an existing document, which
* changes the node num, max level, etc. of the existing document; update happens and move some node to the 
* overflow section.
* 
*@param filename The name of the file whose information is to be reset.
*@param fileinfo The new information about the file. 
*@return Error code.
*/
int PhysicalDataMng::resetFileInfo(char* filename, FileInfoType* fileinfo)
{
	bool getinxcthere = false;
	if (!this->inTransaction)
	{
		this->beginTransaction();
		getinxcthere = true;
	}

	// reset the file information through the xmlDocuemntTable. 
	int retval = this->xmlDocumentTable->setFileInfo(filename, fileinfo);

	if (getinxcthere) this->endTransaction();
	return retval;
}

/**
* File Interface
* 
* Delete an XML docuemnt from the database
*
* @param filename The name of the file to be deleted
* @returns Whether this deletion operation is done successfully.
*/
int PhysicalDataMng::deleteFile(char* filename)
{
	bool getinxcthere = false;
	if (!this->inTransaction)
	{
		this->beginTransaction();
		getinxcthere = true;
	}

	// get the information about the file
	FileInfoType* fileinfo = this->xmlDocumentTable->getFileInfo(filename);
	if (fileinfo == NULL)
	{
		// if the file does not exist, do nothing, return -1.
        globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"PhysicalDataMng::deleteFile: nonexist file",__FILE__,filename);
		if (getinxcthere) this->endTransaction();
		return -1;
	}

	// delete the key index built on the nodes in the xml document
	rc_t rc = ss_m::destroy_index(this->volumeID, fileinfo->keyIndex);
	if (rc)
	{
        globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"PhysicalDataMng::deleteFile",__FILE__,"Error destroy index");
		if (getinxcthere) this->endTransaction();
		return -1;
	}

	// delete the data file that contains the nodes in the xml document 
	rc = ss_m::destroy_file(this->volumeID, fileinfo->fid);
	if (rc)
	{
        globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"PhysicalDataMng::deleteFile",__FILE__,"Error destroy file");
		if (getinxcthere) this->endTransaction();
		return -1;
	}

	// Delete the file information obtained.
	// This step is just to release the space occupied by the materialized inforamtion.
	// It has nothing to do with the data in database. 
	delete fileinfo;

	// delete the item associated with the XML document in xmlDocumentTable.
	bool success = this->xmlDocumentTable->deleteFile(filename);
	if (getinxcthere) this->endTransaction();
	return success;
}

/**
* File Interface 
*
* Reorganize a file (most possiblly after updates), to 
* make sure nodes are stored in key order.
*
* This is done by scan key index, and fetch the correspondent 
* node, and store the node in right order to a new file. 
* 
* @param filename The name of the file to be reorganized.
* @returns Error code.
*/
int PhysicalDataMng::reorganizeFile(char* filename)
{
	bool getinxcthere = false;
	if (!this->inTransaction)
	{
		this->beginTransaction();
		getinxcthere = true;
	}

	// variable definition

	// the informtion of the file to be reorganized
	FileInfoType* fileinfo = NULL;

	// the information for the new file, after reogranization
	FileInfoType* newFileInfo = NULL;

	// index scan handler that scans the key index
	scan_index_i* indexScanHandler;

	// file scan handler that scans the file to be reorganized. 
	scan_file_i* fileScanHandler = NULL;
	pin_i* scanPinHandler = NULL;

	// append handler that append nodes to the new data file. 
	append_file_i* appendHandler = NULL;

	// pin handler that pin a node when the node is not stored in the key order in the old data file.
	pin_i pinHandler;
	rc_t rc;

	DM_DataNode* node = NULL;
	KeyType rootkey;
	KeyType rootEndKey;
	KeyType nodeKey;

	// get the information of the old data file
	fileinfo = this->getFileInfo(filename);
	if (fileinfo == NULL)
	{
		// if the files does not exist, do nothing.
        globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"PhysicalDataMng::reorganizeFile",__FILE__,"File not exist");
		return -1;
	}

	if (!fileinfo->overflow)
	{
		// if there is no overflow section, there is no need to do the reorganization. 
		globalErrorInfo.insertProblem(ERR_TYPE_WARNING,__LINE__,"PhysicalDataMng::reorganizeFile",__FILE__,"No need to reorganize the file, all nodes are ordered by start key (there is no overflow area)");
		if (getinxcthere) this->endTransaction();
		return -1;
	}

	rootkey = fileinfo->rootKey;

	// create a new file and a new index

	// initialized the file info
	newFileInfo = new FileInfoType;
	strcpy(newFileInfo->key, filename);
	newFileInfo->rootKey = rootkey;
	newFileInfo->maxDepth = 0;
	//newFileInfo->maxKey = rootkey;
	//appendNodeToDBFile sets the maxKey for newFileInfo:
	newFileInfo->maxKey = 0;
	//we're not doing renumbering here, so maxKey can remain the same:
	//newFileInfo->maxKey = fileinfo->rootKey;
	newFileInfo->dataSize = 0;
	newFileInfo->recNum = 0;
	newFileInfo->overflow = false;
	newFileInfo->firstOverflowNodeKey = -1;

	// create a new data file
 	rc = ss_m::create_file(this->volumeID, newFileInfo->fid, ss_m::t_regular);
	if (rc)
	{
		// error happens while create the new data file
        globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"PhysicalDataMng::reorganizeFile",__FILE__,"Error creating a new data file");
		delete newFileInfo;
		delete fileinfo;
		if (getinxcthere) this->endTransaction();
		return -1;
	}

	// create a new key index
	rc = ss_m::create_index(this->volumeID, ss_m::t_uni_btree, ss_m::t_regular,
							SHORE_INDEX_KEY_TYPE_OPT, 0, newFileInfo->keyIndex);
	if (rc)
	{
		// error happens while creating key index
        globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"PhysicalDataMng::reorganizeFile",__FILE__,"Error creating a new key index");
		ss_m::destroy_file(this->volumeID, newFileInfo->fid);
		delete newFileInfo;
		delete fileinfo;
		if (getinxcthere) this->endTransaction();
		return -1;
	}

	// open scan on the key index of the old file

	// get the key/endkey of the root node
	node = this->fetchDataNodeFromDBFile((const FileInfoType) *fileinfo, rootkey);
	if (node == NULL)
	{
        globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,
			"PhysicalDataMng::reorganizeFile",__FILE__,
			"Error fetching a data node from the DB file. ");
		ss_m::destroy_file(this->volumeID, newFileInfo->fid);
		delete newFileInfo;
		delete fileinfo;
		if (getinxcthere) this->endTransaction();
		return -1;
	}

	rootEndKey = node->getEndKey();

	// using the key/endkey of the rootkey as the boundary
	vec_t indexUpperBound(&rootkey, sizeof(KeyType));
	vec_t indexLowerBound(&rootEndKey, sizeof(KeyType));

	// start an index scan. 
	indexScanHandler = new scan_index_i(volumeID, fileinfo->keyIndex, ss_m::ge,	indexUpperBound, ss_m::le, indexLowerBound);	
	if (indexScanHandler->error_code())
	{
        globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"PhysicalDataMng::reorganizeFile",__FILE__,"Error starting index scan");
		ss_m::destroy_index(this->volumeID, newFileInfo->keyIndex);
		ss_m::destroy_file(this->volumeID, newFileInfo->fid);
		delete newFileInfo;
		delete fileinfo;
		if (getinxcthere) this->endTransaction();
		return -1;
	}

	// start a file scan on the old data file
	fileScanHandler = new scan_file_i(this->volumeID, fileinfo->fid);
	if (fileScanHandler->error_code())
	{
        globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"PhysicalDataMng::reorganizeFile",__FILE__,"Error opening scan");		
		ss_m::destroy_index(this->volumeID, newFileInfo->keyIndex);
		ss_m::destroy_file(this->volumeID, newFileInfo->fid);
		delete newFileInfo;
		delete fileinfo;
		indexScanHandler->finish();
		delete indexScanHandler;
		if (getinxcthere) this->endTransaction();
		return -1;
	}

	// prepare the append handler for insert node to new data file
	appendHandler = new append_file_i(this->volumeID, newFileInfo->fid);
	if (!appendHandler)
	{
		// error occurs on file appending
        globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"PhysicalDataMng::reorganizeFile",__FILE__,"Error preparing append handler to new file");		
		ss_m::destroy_index(this->volumeID, newFileInfo->keyIndex);
		ss_m::destroy_file(this->volumeID, newFileInfo->fid);
		delete newFileInfo;
		delete fileinfo;
		indexScanHandler->finish();
		delete indexScanHandler;
		fileScanHandler->finish();
		delete fileScanHandler;
		if (getinxcthere) this->endTransaction();
		return -1;
	}

	// Start to reorganize nodes in the file. It is done in the following way: 
	// Scan the key index on the old data file and the old data file at the same time. 
	// Compare the key of the current index item under the scan head and the key of the node currently
	// under the scan head of the file scan. 
	// If the are the same, store the node to new file, and advance both scan.
	// if they are the key from index is smaller than the key from data file, that means the node with the key
	// from index is in the overflow section. Get that node from the overflow section and insert it to 
	// the new data file. 
	// If the key from index is larger than the key from the data file. that means something is wrong with 
	// the old data file/ key index. When this happens, stop the reorganization and report error. 

	bool finish = false;
	bool endofIndex = false;
	bool success = false;
	//we use endOfFile to determine if the file scan arrives at the end of file before the index scan
	//but for "correctness" we use numIndexNodesScanned and numFileNodesAppended
	//this is because the overflow section makes it a little tricky when trying to use endOfFile for this
	bool endofFile = false;
	long int numIndexNodesScanned = 0;
	long int numFileNodesAppended = 0;

	serial_t srid;

	// the key from index and the key from file scan.
	KeyType indexKey, nodekey;
	
	int keySize = sizeof(KeyType);
	vec_t* vecIndexKey = new vec_t(&indexKey, keySize);
	int ridSize = sizeof(serial_t);
	vec_t* vecRid = new vec_t(&srid, ridSize);

	// fetch the first node from index scan
	rc = indexScanHandler->next(endofIndex);
	if (rc)
	{
        globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"PhysicalDataMng::reorganizeFile",__FILE__,"Error getting the next item from index");
		finish = true;
		success = false;
	}
	else if (!endofIndex)
		numIndexNodesScanned++;

	// fetch the first node from file scan
	rc = fileScanHandler->next(scanPinHandler, 0, endofFile);
	if (rc)
	{
        globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"PhysicalDataMng::reorganizeFile",__FILE__,"Error fileScanHandler->next");
		finish = true;
		success = false;
	}

	// the following statements judges whether the process is successful, based on the fact that both 
	// scan just started. 
	// the predicate and conclusion is not true if it is in the middle of the process. 
	if (endofIndex && endofFile)
	{
		// if the end of the index scan and the end of file scan is reached at 
        // the same time, the process is done successfully. 
		success = true;
		finish = true;
	}
	else if (!endofIndex && !endofFile) finish = false;
	else
	{
		// this means one of the index/file is empty, while the other is not.
		// something must be wrong with the system. 
        globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,
			"PhysicalDataMng::reorganizeFile",__FILE__,
			"Key Index and Data File are not consistant, detected in the reorganizing process.");

		success = false;
		finish = true;
	}

	// keep examing the item fetched from index and the item fetched from file
	// if there is a match, get the node from file and store it into new file.
	// otherwise, get the node (from overflow section) and store it into new file. 
	while (!finish)
	{
		// get the key from index
		rc = indexScanHandler->curr(vecIndexKey, (unsigned long &)keySize, vecRid, (unsigned long &)ridSize);

		if (rc)
		{
			globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,
				"PhysicalDataMng::reorganizeFile",__FILE__,
				"Error reported when getting a key from the key index.");
			success = false;
			finish = true;
		}

		// get the key of the node from file
		node = DM_DataNode::unwrap((char*) scanPinHandler->body());

		if (node == NULL)
		{
			globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,
				"PhysicalDataMng::reorganizeFile",__FILE__,
				"Error fetching a data node from the DB file.");
			success = false;
			finish = true;
		}

		nodeKey = node->getKey();

        // if the key from the index matches the key of the node from file
		// store the node into the new fhile
		if (indexKey == nodeKey)
		{

			// append the node to new file and create key index for it. 
			int retval = this->appendNodeToDBFile(newFileInfo, appendHandler, node);
			if (retval < 0)
			{
                globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"PhysicalDataMng::reorganizeFile",__FILE__,"Error append node to DB file");
				if (getinxcthere) this->endTransaction();
				return -1;
			}
			else
				numFileNodesAppended++;

			delete node;
		
			// advance file scan			
			rc = fileScanHandler->next(scanPinHandler, 0, endofFile);
			if (rc)
			{
                globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"PhysicalDataMng::reorganizeFile",__FILE__,"Error fileScanHandler->next");
				finish = true;
				success = false;
			}

			if (!endofFile) node = DM_DataNode::unwrap((char*) scanPinHandler->body());
		}

		// otherwise, fetch the node with the key (from index) 
		// and store it into the new file
		else
		{
			DM_DataNode* nodeInOverFlow = this->fetchDataNodeFromDBFile((const FileInfoType) *fileinfo, indexKey);
			if (nodeInOverFlow == NULL)
			{
                globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"PhysicalDataMng::reorganizeFile: key not in file",__FILE__,indexKey.toString());
				success = false;
				finish = true;
			}

			// append the node to new file and create key index for it. 
			int retval = this->appendNodeToDBFile(newFileInfo, appendHandler, nodeInOverFlow);
			if (retval < 0)
			{
                globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"PhysicalDataMng::reorganizeFile",__FILE__,"Error append node to DB file");
				if (getinxcthere) this->endTransaction();
				return -1;
			}
			else
				numFileNodesAppended++;

			delete nodeInOverFlow;
		}

		// advance index scan
		rc = indexScanHandler->next(endofIndex);
		if (rc)
		{
            globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"PhysicalDataMng::reorganizeFile",__FILE__,"Error indexScanHandler->next");
			success = false;
			finish = true;
		}
		else if (!endofIndex)
			numIndexNodesScanned++;

		if (endofIndex)
		{
			// in case the end of index scan is reached, whether the reorganization is done successfully
			// depends on whether the file scan is done at the same time. 
			if (numIndexNodesScanned == numFileNodesAppended)
				success = true;
			else
				success = false;
			finish = true;
		}
	}

	// delete the old file and old index
	ss_m::destroy_file(this->volumeID, fileinfo->fid);
	ss_m::destroy_index(this->volumeID, fileinfo->keyIndex);

	// clean up and finish
	delete appendHandler;

	fileScanHandler->finish();
	delete fileScanHandler;

	indexScanHandler->finish();
	delete indexScanHandler;

	newFileInfo->overflow = false;
	newFileInfo->firstOverflowNodeKey = -1;

	this->xmlDocumentTable->setFileInfo(filename, newFileInfo);

	if (getinxcthere) this->endTransaction();

	if (!success) 
		return -1;
	else return NO_ERROR;
}

/**
* File Interface 
* 
* Get the names of all files in the database
* 
* @param num The totally number of files in the database (used as return value).
* @returns List of file names.
*/
char** PhysicalDataMng::getFileNames(int* num)
{
	bool getinxcthere = false;
	if (!this->inTransaction)
	{
		this->beginTransaction();
		getinxcthere = true;
	}

	// get the file names through xmlDocumentTable.
	char** names = this->xmlDocumentTable->getFileNames(num);

	if (getinxcthere) this->endTransaction();
	return names;
}

/* ----------------------------------------------------------- */
/*						loading interface					   */
/* ----------------------------------------------------------- */

/** 
* Loading Interface
* 
* Load an XML document into database
* 
*@param XMLfile The name (with path) of the XML docuemnt to be loaded
*@param maxdepth The maximum depth of the XML docuemnt, default value is 100. 
*@param convertmulticolor The flag saying whether to convert pointer into multicolor model (Nuwee added 07/14/03
*@returns Whether the loading process is done successfully. 
*/
int PhysicalDataMng::loadXMLFile(char* XMLfile, int maxdepth, bool convertmulticolor)
{
	bool getinxcthere = false;
	if (!this->inTransaction)
	{
		this->beginTransaction();
		getinxcthere = true;
	}

	char XMLfilename[MAX_FILE_NAME_LENGTH];
	char XMLfilepath[MAX_FILE_PATH_LENGTH];

	// Parse the name (with path) of the XML docuemnt, separate the path and the file name
	parse_name(XMLfile, XMLfilepath, XMLfilename);

	// The loading is done by function loadXMLFileToDBFile.
	int retval = loadXMLFileToDBFile(XMLfile, XMLfilename, maxdepth, convertmulticolor);

	if (getinxcthere) this->endTransaction();
	return retval;
}

/**
* Loading Interface
* 
* Append a XML document to an existing data file in the database.
*
* The data (nodes) in the new documents will be added to the existing data file. The root of the XML document
* will become the last child of the merge node. 
* Only merge at root is implemented right now. It should not be hard to extend it to merge at any given node. 
*
* @param newXMLFile The name (with path) of the XML document to be merged into database.
* @param maxdepth The estimated depth of the new XML document. 
* @param appendToXMLFile The name of the data file in the database to which the new data is to be appended.
* @param mergeAt The key of the node which will become the parent of the root of the new XML document. Since
*			only merge at root is implemented, this is reserved for future use. 
* @param rootStartKey The start key of the root node of the new document (return value).
* @param rootEndKey The end key of the root node of the new document (return value).
* @returns Error code. 
*/
int PhysicalDataMng::appendXMLFile(char* newXMLFile,
								   int maxdepth, 
								   char* appendToXMLFile,
								   KeyType mergeAt, 
								   KeyType* rootStartKey,
								   KeyType* rootEndKey)
{
	bool getinxcthere = false;
	if (!this->inTransaction)
	{
		this->beginTransaction();
		getinxcthere = true;
	}

	// check to see whether the data file to be appended to is in the database
	FileInfoType* appendtoFileinfo = this->xmlDocumentTable->getFileInfo(appendToXMLFile);	
	if (appendtoFileinfo == NULL)
	{
		ostringstream oss;
		oss << appendToXMLFile << " does not exist in the database";

		// if not, report error
        globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"PhysicalDataMng::appendXMLFile",__FILE__,oss.str().c_str());
		//if (getinxcthere) 
			//this->endTransaction();
		//getinxcthere will be false if we entered this method inside a transaction,
		//but we want to abort the transaction regardless
		if (this->inTransaction)
			this->abortTransaction();
		return -1;
	}

	// prepare node stack at the node to be merged in
	
	int maxd;
	if (maxdepth < appendtoFileinfo->maxDepth) maxd = appendtoFileinfo->maxDepth;
	else maxd = maxdepth;

	NodeStack* nodestack = new NodeStack(maxd);

	if (!nodestack)
	{
	    globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,
			"PhysicalDataMng::appendXMLFile",__FILE__,
			"Error reported when constructing an instance of a node stack.");
		if (this->inTransaction)
			this->abortTransaction();
		return -1;
	}	

	KeyType rootkey = appendtoFileinfo->rootKey;

	// push the document node to stack
	serial_t docrid;
	DM_DataNode* docnode = this->fetchDataNodeFromDBFile((const FileInfoType) *appendtoFileinfo, rootkey, &docrid);
	NodeStackItem* docitem = new NodeStackItem(docnode);
	docitem->setDescendantDepth(docnode->getDescendantDepth());
	docitem->setNodeRid(docrid);
	nodestack->push(docitem);

	// if document node has child, push the last child into the stack, 
    // as the lastchild of the node at the top of the stack. 
	if (docnode->getChildNumber() > 0)
	{
		serial_t lchildrid;
		DM_DataNode* lchildnode = this->fetchDataNodeFromDBFile((const FileInfoType) *appendtoFileinfo, docnode->getLastChild(), &lchildrid);
		docitem->setLastChild(lchildnode);
		docitem->setLastChildRid(lchildrid);
	}

	// parse the XML document, append it to the data file. 
	MSXMLParser* xmlParser = new MSXMLParser(this->volumeID);
	FileInfoType* retFileinfo = xmlParser->parseXML(newXMLFile, maxd, OP_PARSE_APPEND, appendtoFileinfo, 
        nodestack, NULL, rootStartKey, rootEndKey, false, this->xmlNameTable);
	if (retFileinfo == NULL)
	{
		// in case there is error in the loading process, return error
        globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"PhysicalDataMng::appendXMLFile",__FILE__,"Error in Loading/Parsing. Possibly not a well-formed XML document");
		//if (getinxcthere)
			//this->endTransaction();
		if (this->inTransaction)
			this->abortTransaction();
		return -1;
	}

	// reset the file info to system catalog
	this->xmlDocumentTable->setFileInfo(appendToXMLFile, retFileinfo);
	if (getinxcthere) this->endTransaction();
	return NO_ERROR;
}

/*--------------------------------------------------------------
 * Single Node Access Interface
 -------------------------------------------------------------*/

/**
* Single Node Access Interface
* 
* Store a new node to SHORE/BerkeleyDB by appending the node to the end of the file.
* It changes the fileinfo if it is the first time a node is expended to the file after loading.
*
*@param fileinfo The information of the file to which the new node is to be inserted.
*@param node The node to be appened to the file. 
*@returns A boolean value which indicate whether a the process is done successfully. 
*/
int PhysicalDataMng::storeNodeToDBFile(FileInfoType* fileinfo, DM_DataNode* node)
{
	bool getinxcthere = false;
	if (!this->inTransaction)
	{
		this->beginTransaction();
		getinxcthere = true;
	}

	// the append handler of SHORE/BerkeleyDB
	append_file_i* apdHandler;

	// The append handler is set to deal with appending new record to data file (indicated by fid)
	// on the volumn. 
	apdHandler = new append_file_i(this->volumeID, fileinfo->fid);

	// append the node to the file, which is done by appendNodeToDBFile. 
	int retval = appendNodeToDBFile(fileinfo,  apdHandler, node);
	if (retval < 0)
	{
        globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"PhysicalDataMng::storeNodeToDBFile",__FILE__,"Error appendNodeToDBFile");
		if (getinxcthere) this->endTransaction();
		return -1;
	}

	// change the information about the data file.
	//AN: both of these are done in appendNodeToDBFile as well:
	//if (node->getKey() > fileinfo->maxKey) fileinfo->maxKey = node->getKey();
	//if (node->getLevel() > fileinfo->maxDepth) fileinfo->maxDepth = node->getLevel();

	//fileinfo->recNum++; //AN: this is already done in appendNodeToDBFile above!


	// if the current file does not have an overflow section, now, it has. 
	if (!fileinfo->overflow)
	{
		fileinfo->overflow = true;
		fileinfo->firstOverflowNodeKey = node->getKey();
	}

	// release the append handler. 
	delete apdHandler;

	if (getinxcthere) this->endTransaction();
	return NO_ERROR;
}

/**
* Single Node Access Interface
* 
* Fetch a data node from the database, given the node key. Also return the record id of the node
* 
* @param fileinfo The information about the data file. What we need is the fileid in it.
* @param nodekey The key of the node to be fetched.
* @param nrid A pointer to a variable with type serial_t. If the input is NULL, that means no rid is requested.
*		When it is not NULL, the record id of the record that contains the node with the key is to be returned 
*		in this variable. 
* @returns The data node with the given key. Return NULL is node with such key does not exist in the database.
*/
DM_DataNode* PhysicalDataMng::fetchDataNodeFromDBFile(const FileInfoType fileinfo, KeyType nodekey, serial_t* nrid)
{
	bool getinxcthere = false;
	if (!this->inTransaction)
	{
		this->beginTransaction();
		getinxcthere = true;
	}

	// the pointer to data node.
	DM_DataNode* nodepnt;

	// the following three variable will be used as parameters to the SHORE/BerkeleyDB function calls. 
	bool found = false;
	serial_t noderid;
	smsize_t id_len = sizeof(noderid);

	// find the record id of the record that contains the node with the given key.
	rc_t rc = ss_m::find_assoc(this->volumeID, fileinfo.keyIndex, vec_t(&nodekey, sizeof(KeyType)), &noderid, id_len, found);
	if (rc)
	{
        globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"PhysicalDataMng::fetchDataNodeFromDBFile",__FILE__,"Error find_assoc");
		if (getinxcthere) this->endTransaction();
		return NULL;
	}

	if (!found)
	{
		//the plans that are passed to the update iterators may ask us to fetch nodes that have been
		//deleted already (e.g. we may be asked to delete the same node more than once, even from
		//a valid plan, due to the way we do pattern tree matching)
		//so we don't want to signal an error here, but we should still return NULL here, so that
		//the calling methods can decide what to do in response to the failed node retrieval:

		//ostringstream outStream;
		//outStream << "Could not fetch the data node with key=" << nodekey.toDouble();

		// in case that a node with the given key could not be found in the database, return NULL. 
		//globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"PhysicalDataMng::fetchDataNodeFromDBFile",__FILE__,outStream.str().c_str());
		//globalErrorInfo.insertProblem(ERR_TYPE_WARNING,__LINE__,"PhysicalDataMng::fetchDataNodeFromDBFile",__FILE__,outStream.str().c_str());
		
		if (getinxcthere) this->endTransaction();
		return NULL;
	}
	else
	{
		// if nrid is not NULL, this means the calling function expect the rid be returned.
		if (nrid != NULL) *nrid = noderid;

		// get the record with the rid just found. 
		pin_i handler;
		rc = handler.pin(this->volumeID, noderid, 0);
		if (rc)
		{
			// process error
            globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"PhysicalDataMng::fetchDataNodeFromDBFile",__FILE__,"Error after handler.pin");
			if (getinxcthere) this->endTransaction();
			return NULL;
		}

		// rebuild the node using the string obtained from the database. 
		nodepnt = DM_DataNode::unwrap((char*) handler.body());
		handler.unpin();
	}

	if (getinxcthere) this->endTransaction();
	return nodepnt;
}

/**
* Single Node Access Interface
* 
* Delete a node with given key from the data file.
*
* @param fileinfo The information about the data file from which the node is to be deleted. 
* @param nodekey The key of the node to be deleted.
* @returns The error code.
*/
int PhysicalDataMng::deleteNodeFromDBFile(FileInfoType* fileinfo, KeyType nodekey)
{
	bool getinxcthere = false;
	if (!this->inTransaction)
	{
		this->beginTransaction();
		getinxcthere = true;
	}

	rc_t rc;
	
	// find out whether the node is in the database, and obtain its rid. 
	bool found;
	serial_t rid = this->getNodeRid(*fileinfo, nodekey, &found);
	if (!found)
	{
        globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"PhysicalDataMng::deleteNodeFromDBFile",__FILE__,"getNodeRid");
		if (getinxcthere) this->endTransaction();
		return -1;
	}

	if (fileinfo->overflow && (fileinfo->firstOverflowNodeKey == nodekey))
	{
		// If the node to delete is the first  node in the overflow area, its rid is kept 
		// in file info to facilitate future scan. In this case, need to find the next node in the 
		// overflow area to replace it. 
		
		// starting scan from this node to be deleted.
		scan_file_i* scanhandler = new scan_file_i(this->volumeID, fileinfo->fid, rid);

		pin_i* pinHandler;
		bool eof = false;

		// get the first node in the overflow
		rc = scanhandler->next(pinHandler, 0, eof);
		// get the second node... this will be the new first node in the overflow
		rc = scanhandler->next(pinHandler, 0, eof);
		if (rc)
		{
			// handle error
            globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"PhysicalDataMng::deleteNodeFromDBFile",__FILE__,"scanhandler->next");
			scanhandler->finish();
			delete scanhandler;
			if (getinxcthere) this->endTransaction();
			return -1;
		}

		// eof is true. it means the node to delete is the last record in the overflow section.
		// We also know that it is the first node in overflow section. 
		// So, deleteing the node, the data file will not have overflow section any more. 
		if (eof) {
			fileinfo->overflow = false;
			fileinfo->firstOverflowNodeKey = -1;
		}
		else 
		{
			// Get the node next to the node to delete in the data file, and set it to be the first node 
			// in the overflow section. 
			DM_DataNode* nodepnt = DM_DataNode::unwrap((char*) pinHandler->body());
			fileinfo->firstOverflowNodeKey = nodepnt->getKey();
			delete nodepnt;
		}
		
		// clean the scan that looks for the next node in the overflow section after the node to delete. 
		scanhandler->finish();
		delete scanhandler;
	}

	// remove the item in the key index that is associated with the node to delete. 
	vec_t indexkey(&nodekey, sizeof(KeyType));
	rc = ss_m::destroy_assoc(this->volumeID, fileinfo->keyIndex, vec_t(&nodekey, sizeof(KeyType)), vec_t(&rid, sizeof(serial_t)));
	if (rc) 
	{
        globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"PhysicalDataMng::deleteNodeFromDBFile",__FILE__,"destroy_assoc");
		if (getinxcthere) this->endTransaction();
		return -1;
	}

	// delete the record of the node in the data file.
	rc = ss_m::destroy_rec(this->volumeID, rid);
	if (rc)
	{
        globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"PhysicalDataMng::deleteNodeFromDBFile",__FILE__,"destroy_rec");
		if (getinxcthere) this->endTransaction();
		return -1;
	}

	if (getinxcthere) this->endTransaction();

	//update the FileInfo
	fileinfo->recNum--;

	return NO_ERROR;
}

/**
* Single Node Access Interface
* 
* Modify a node in the database, given the key of the node to be modified and the new nodes. 
* The new node has to have the same key as the node to be modified.
* 
*@param fileinfo The information of the file to be modified.
*@param nodekey THe key of the node to be modified.
*@param newnode The node that is used to replace the node with the given key in the database. 
*@returns Error code.
*/
int PhysicalDataMng::modifyNodeInDBFile(FileInfoType* fileinfo, KeyType nodekey, DM_DataNode* newnode)
{
	this->deleteNodeFromDBFile(fileinfo, nodekey);
	this->storeNodeToDBFile(fileinfo, newnode);
	return NO_ERROR;
}

/**
* this method is used to modify nodes in the database "in place".
* in this way, we avoid moving nodes to the overflow area when they are modified.
* when serialized, the node cannot be longer (is shorter ok?) than it's current length
* in the database.  If so, use modifyNodeInDBFile instead.
*/
int PhysicalDataMng::fixedSizeModifyNodeInDBFile(DM_DataNode* updatedDataNode, serial_t srid)
{
	if (srid == NULL || updatedDataNode == NULL) {
		return -1;
	}

	bool getinxcthere = false;
	if (!this->inTransaction)
	{
		this->beginTransaction();
		getinxcthere = true;
	}

	///////////////

	// pin the node in the database
	pin_i pinHandler;
	rc_t rc = pinHandler.pin(this->volumeID, srid, 0);

	if (rc) {
		globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"PhysicalDataMng::fixedSizeModifyNodeInDBFile",__FILE__,"Pinning a record failed");
		if (getinxcthere) this->abortTransaction();
		return -1;
	}

	//wrap up the modified node as a string:
	int stringLength;
	char* nodeAsString = updatedDataNode->wrap(&stringLength);

	// update the record with the string generated from the new node:
	vec_t data(nodeAsString, stringLength);
	rc = pinHandler.update_rec(0, data);

	if (rc) {
		ostringstream oss;
		oss << "Could not update the node with sk=" << updatedDataNode->getKey().toString() << ", ek=" << updatedDataNode->getEndKey().toString();
		globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"PhysicalDataMng::fixedSizeModifyNodeInDBFile",__FILE__,oss.str().c_str());
		if (getinxcthere) this->abortTransaction();
		return -1;
	}

	// unpin the node
	pinHandler.unpin();	

	delete [] nodeAsString;

	if (getinxcthere) this->endTransaction();

	return NO_ERROR;
}

/*
int MSXMLParserHandlers::modifyNodeInDB(serial_t srid, DM_DataNode* node)
{
#ifdef DEBUG_PARSER
	this->modifyCount++;
#endif

	// pin the node in the database
	rc_t rc = this->pinHandler.pin(this->volumeID, srid, 0);

#ifdef DEBUG_PARSER
	{
		cout << "----------pinHandler.pin" << endl;
		this->pinCount++;
	}
#endif

	if (rc)
	{
		globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"MSXMLParserHandlers::modifyNodeInDB",__FILE__,"Pinning a record failed");
		return E_FAIL;
	}

	// wrap the new node into a string
	this->nodeInStr = node->wrap(&(this->nodeInStrLen));

#ifdef DEBUG_PARSER
	{
		cout << "wrap node (key=" << node->getKey().toString() << "), length = " << this->nodeInStrLen << endl;

		DM_DataNode* tempnode = DM_DataNode::unwrap(this->nodeInStr);
		cout << "\nwrap node: key=" << node->getKey().toString() << " , endkey =" << node->getEndKey().toString() << endl;
		node->printValue();

		cout << "\nwrap node: key=" << tempnode->getKey().toString() << " , endkey =" << tempnode->getEndKey().toString() << endl;
		tempnode->printValue();
		deleteNode(tempnode);
	}
#endif

	// update the record with the string generated from the new node. 
	vec_t data(this->nodeInStr, this->nodeInStrLen); 				
	this->pinHandler.update_rec(0, data);

#ifdef DEBUG_PARSER
	cout << "----------pinHandler.update_rec" << endl;
#endif			

	// unpin the node
	this->pinHandler.unpin();	

#ifdef DEBUG_PARSER
	{
		cout << "----------pinHandler.unpin" << endl;
		this->unpinCount++;
	}
#endif	

	delete [] this->nodeInStr;
	return S_OK;
}
*/

/*-------------------------------------------------------------------------------
 * scan interface
 --------------------------------------------------------------------------------*/

/**
* Scan Interface
* 
* Start a scan
* 
* Scan result can be fetched only when this method is called explicitly to start the scan.
* This function takes the scan condition and other scan criteria, such as the subtree root, the scan range, etc.
* process them and produce ScanInfo. Later, this ScanInfo is used  as the unique identification of scan
* for data fetching and scan termination. 
*
* @param fileinfo The Information of the file in which scan is to be done.
* @param nodekey The key of the node which is the root of the subtree to be scanned
* @param scanmethod The scan method (reserved for later use)
* @param depth The depth to get into the subtree. Only nodes within "depth" to the subtree root can be result of the scan.					 
* @param scanrange A list of ranges. Only nodes fall in to  the scan range can be result of the scan. 
* @param condition The scan condition in CNF format.
* @returns The scaninfo which contains the inforamtion about the scan, and is to be used later for data fetching. 
*		returns NULL is the scan is illegal, so, something is wrong in the process. 
*/
ScanInfo* PhysicalDataMng::startScan(FileInfoType* fileinfo, 
							        const KeyType nodekey,
							        const int scanmethod,
							        const int depth,
							        ScanRange* scanrange,
							        SelectionCondition* condition,
									bool considerOverflow)
{
	ScanInfo* scaninfo;

	bool getinxcthere = false;
	if (!this->inTransaction)
	{
		this->beginTransaction();
		getinxcthere = true;
	}

	// check whether the scan condition is a valid condition
	if (!condition->isValid())
	{
		// if the scan condition is not valid, do nothing.
        globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"PhysicalDataMng::startScan",__FILE__,"Condition not valid");
		if (getinxcthere) this->endTransaction();
		return NULL;
	}

	// get the root node of the subtree to be scanned.
	serial_t noderid;
	DM_DataNode* node = this->fetchDataNodeFromDBFile(*fileinfo, nodekey, &noderid);
	if (node == NULL)
	{
		// if the node does not exist in the database, do nothing.
        globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"PhysicalDataMng::startScan",__FILE__,"fetchDataNodeFromDBFile");
		if (getinxcthere) this->endTransaction();
		return NULL;
	}
	else
	{	
		// determine the scan boundaries on key and level, based on 
        // the key/endkey of the rootkey, and the depth. 
		KeyType endkey = node->getEndKey();
		int startlevel;
		int endlevel;
		
		if (depth == -1)
		{
			// depth =  -1 means that the user does not specify the depth for scan. 
			// so, the start level is the level of the root node and the endlevel 
            // is the maximum level of the document.
			startlevel = node->getLevel();
			endlevel = gSettings->getIntegerValue("MAXDEPTH",100) +1;
		}
		else
		{
			// if user specifis the depth of scan, the start level is the level of the root node.
			// and the endleve is "depth" from the start level.
			startlevel = node->getLevel();
			endlevel = startlevel + depth -1;
		}

		// determing the scan range. 
		ScanRange* sorted_scanrange;
		int rangeCursor = 0;
		if (scanrange == NULL) sorted_scanrange = NULL;
		else 
		{
			// sort/merge the scan range, by calling the sortScanRange function. 
			scanrange->sortScanRange();

			// cut the scan range using the startkey/endkey of the root node
			// knowing that only nodes fall between this internal could be scan result. 
			scanrange->cutScanRange(nodekey, endkey);
			sorted_scanrange = scanrange;

			// find the first node in the first scan ranges. scan will start from here. 
			// when there is scan range, the node where the scan start is not necessary the root node.
			KeyType scanKey;
			bool success = false;
			bool found = false;
			
			success = this->findFirstKeyInScanRange(fileinfo, scanrange, 0, &found, &rangeCursor, &scanKey);
			// if the process  of finding first key in scan range fails, or nothing is found, 
			// return NULL, since there will be no valid result of this scan. 
			if (!success || !found) return NULL;

			// get the record id of the first node in the scan range. 
			bool foundNode = false;
			noderid = this->getNodeRid(*fileinfo, scanKey, &foundNode);
		
			if (!foundNode) return NULL;
		}

		// find out whether the root node itself is in the overflow range
		bool rootInOverflow;
		if (!fileinfo->overflow) rootInOverflow = false;
		else
		{
			bool found;
			serial_t overflowRid = this->getNodeRid((const FileInfoType) *fileinfo, fileinfo->firstOverflowNodeKey, &found);
			if (overflowRid <= noderid) rootInOverflow = true; //AN: should be <=
			else rootInOverflow = false;
		}

		if (!rootInOverflow)
		{
			// if the scan root is not in overflow range, start scan from the scan root
			// the overflow section will be taken care of later. 

			// create an instance of scan_file_i, starting from the node found (it maybe the root know of
			// the subtree, or the first node in the scan range). 
			scan_file_i* scanhandler = new scan_file_i(this->volumeID, fileinfo->fid, noderid);

			// create an instance of the ScanInfo with the information about the scan
			scaninfo = new ScanInfo(fileinfo, condition, scanmethod, nodekey, endkey, 
                                    startlevel, endlevel, sorted_scanrange, rangeCursor,scanhandler,
									false, considerOverflow); //inOverflow=false,considerOverflow is either true or false
		}
		else
		{
			bool found;
			int foundInCursor;
			KeyType scanKey;

			//sorted_scanrange might be NULL here (whole scan) which would be bad.
			//just make scanrange the whole document range
			//if (sorted_scanrange == NULL) {
			//	ScanRangeType tempRange = 
			//	ScanRange tempScanRange = new ScanRange(1, &tempRange);
			//	sorted_scanrange = new ScanRange(0);
			//}

			if (sorted_scanrange != NULL) {
				//the final 'true' parameter tells the method to only look in the sorted portion of the file:
				this->findFirstKeyInScanRange(fileinfo, sorted_scanrange, 0, &found, &foundInCursor, &scanKey, true);
			}
			else {
				//if sorted_scanrange is NULL then anything should match within the range of the root of the subtree
				//construct this range and pass it in to fidnFirstKeyInScanRange

				ScanRange* scanRanges;
				ScanRangeType* scanRange;
				scanRanges = new ScanRange(1);
				scanRange = new ScanRangeType();
				scanRange->startPos = nodekey;
				scanRange->endPos = endkey;
				scanRanges->setScanRangeAt(0, scanRange);
				scanRanges->sortScanRange();

				this->findFirstKeyInScanRange(fileinfo, scanRanges, 0, &found, &foundInCursor, &scanKey, true);
				delete scanRanges;
			}

			//if a node in the scan range is found in the sorted section, then start the scan at that node:
			//note: if considerOverflow==false we won't get all of the nodes (the root for instance), unless
			//we combine this scan with an overflow scan
			if (found) {
				bool foundNode = false;
				noderid = this->getNodeRid(*fileinfo, scanKey, &foundNode);
		
				if (!foundNode) return NULL;

				scan_file_i* scanhandler = new scan_file_i(this->volumeID, fileinfo->fid, noderid);
				// create an instance of the ScanInfo with the information about the scan
				scaninfo = new ScanInfo(fileinfo, condition, scanmethod, nodekey, //scanKey,
					sorted_scanrange?
					sorted_scanrange->getScanRangeAt(sorted_scanrange->getScanRangeNumber()-1)->endPos
					:endkey, //if we have a scanrange use its last end key, otherwise use the endkey of the subtree root
					startlevel, endlevel, sorted_scanrange, foundInCursor, scanhandler,
					false, considerOverflow); //inOverflow==false, considerOverflow is either true or false
			}
			//otherwise, just scan the overflow section (if considerOverflow == true):
			else if (considerOverflow) {
				// get the record id of the first node in the overflow section. 
				bool found;
				serial_t rid = this->getNodeRid(*fileinfo, fileinfo->firstOverflowNodeKey, &found);
				if (!found) return NULL;

				// start a new file scan in the overflow section. 
				scan_file_i* scanhandler = new scan_file_i(this->volumeID, fileinfo->fid, rid);

				//the final 'true' parameter indicates that we will scan the overflow section:
				scaninfo = new ScanInfo(fileinfo, condition, scanmethod, nodekey, //scanKey,
					sorted_scanrange?
					sorted_scanrange->getScanRangeAt(sorted_scanrange->getScanRangeNumber()-1)->endPos
					:endkey, //if we have a scanrange use its last end key, otherwise use the endkey of the subtree root
					startlevel, endlevel, sorted_scanrange, 0, scanhandler,
					true, true); //inOverflow == true, considerOverflow == true
			}
			//if the node might be in the overflow, but we don't want to scan the overflow section:
			else {
				return NULL;
			}
		}

		// release space occupied by node.
		delete node;

		if (getinxcthere) this->endTransaction();
		return scaninfo;
	}
}

//nodekey is the key of the node which is the root of the subtree to be scanned
ScanInfo* PhysicalDataMng::startOverflowScan(FileInfoType* fileinfo, 
							        const KeyType nodekey,
							        const int scanmethod,
							        const int depth,
							        SelectionCondition* condition)
{
	//this could possibly start a scan in the ordered section, which we don't want...
	//return this->startScan(fileinfo, nodekey, scanmethod, depth, NULL, condition, true);
	//so we'll have to do the following:

	if (!fileinfo->overflow) return NULL;

	ScanInfo* scaninfo = NULL;

	bool getinxcthere = false;
	if (!this->inTransaction)
	{
		this->beginTransaction();
		getinxcthere = true;
	}

	// check whether the scan condition is a valid condition
	if (!condition->isValid())
	{
		// if the scan condition is not valid, do nothing.
        globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"PhysicalDataMng::startOverflowScan",__FILE__,"Condition not valid");
		if (getinxcthere) this->endTransaction();
		return NULL;
	}

	// get the root node of the subtree to be scanned.
	serial_t noderid;
	DM_DataNode* node = this->fetchDataNodeFromDBFile(*fileinfo, nodekey, &noderid);
	if (node == NULL)
	{
		// if the node does not exist in the database, do nothing.
        globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"PhysicalDataMng::startOverflowScan",__FILE__,"fetchDataNodeFromDBFile");
		if (getinxcthere) this->endTransaction();
		return NULL;
	}
	else
	{
		// determine the scan boundaries on key and level, based on 
        // the key/endkey of the rootkey, and the depth. 
		KeyType endkey = node->getEndKey();
		int startlevel;
		int endlevel;
		
		if (depth == -1)
		{
			// depth =  -1 means that the user does not specify the depth for scan. 
			// so, the start level is the level of the root node and the endlevel 
            // is the maximum level of the document.
			startlevel = node->getLevel();
			endlevel = gSettings->getIntegerValue("MAXDEPTH",100) +1;
		}
		else
		{
			// if user specifis the depth of scan, the start level is the level of the root node.
			// and the endleve is "depth" from the start level.
			startlevel = node->getLevel();
			endlevel = startlevel + depth -1;
		}


		// get the record id of the first node in the overflow section. 
		bool found;
		serial_t rid = this->getNodeRid(*fileinfo, fileinfo->firstOverflowNodeKey, &found);
		if (!found) return NULL;

		// start a new file scan in the overflow section. 
		scan_file_i* scanhandler = new scan_file_i(this->volumeID, fileinfo->fid, rid);

		//the final 'true' parameter indicates that we will scan the overflow section:
		scaninfo = new ScanInfo(fileinfo, condition, scanmethod, nodekey, //fileinfo->firstOverflowNodeKey,
			endkey, startlevel, endlevel, NULL, 0, scanhandler,
			true, true); //inOverflow == true, considerOverflow == true
	}

	delete node;

	if (getinxcthere) this->endTransaction();
	return scaninfo;
}

/**
* Scan Interface
* Finish a scan.
*
* Every scan, after all or some of the result are fetched, should be closed explicitly by
* calling this method. No more fetching can be done when a scan is closed.
* 
* @param scaninfo The information about the scan to be finished
* @returns Error code
*/
int PhysicalDataMng::clearScan(ScanInfo* scaninfo)
{
	bool getinxcthere = false;
	if (!this->inTransaction)
	{
		this->beginTransaction();
		getinxcthere = true;
	}

	// delete the scaninfo. 
	// In the destructor of ScanInfo, the scan handler will be finished and deleted. 
	// Other variables of scaninfo, such as scancond, scanrange.... will all be deleted.
	delete scaninfo;
	if (getinxcthere) this->endTransaction();
	return NO_ERROR;
}



/**
* Scan Interface
* 
* Fetch the next result of the scan.
*
* This function can only be called when the scaninfo is refer to a valid scan. That is, it is 
* returned from startScan, and no clearScan has been called on it.
*
* @param scaninfo The information of the scan.
* @returns The next result node in the scan. NULL if all nodes have been fetched already. 
*/
DM_DataNode* PhysicalDataMng::scanFetchNext(ScanInfo* scaninfo)
{
    if (scaninfo == NULL) return NULL;

	bool getinxcthere = false;
	if (!this->inTransaction)
	{
		this->beginTransaction();
		getinxcthere = true;
	}

	// get the related information from the scaninfo

	// the information about the data file.
	FileInfoType* fileinfo = scaninfo->getFileInfo();

	// the scan handler
	scan_file_i* scanHandler = scaninfo->getScanHandler();

	// the scan condition. 
	// SelectionCondition* cond = scaninfo->getScanCond();

	// the scan range
	ScanRange* scanRange = scaninfo->getScanRange();

	DM_DataNode* nodepnt = NULL;
	pin_i* pinHandler;
	bool eof = true;

	// the next scan result is found by fetching nodes from linear file scan of the data file
	// verifying the scan condition, including scan range, and returning the first node
	// that satisfies the scan. 
	bool find = false;
	while (!find)
	{
		// get the next node in the file scan.
		rc_t rc = scanHandler->next(pinHandler, 0, eof);
		if (rc)
		{
            globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"PhysicalDataMng::scanFetchNext",__FILE__,"scanHandler->next");
			if (getinxcthere) this->endTransaction();
			return NULL;
		}

		// jump out the loop is the file scan reaches the end of the file. 
		if (eof) break;
		else 
		{
			// materialize the node, using the information wrapped in the record. 
			nodepnt = DM_DataNode::unwrap((char*) pinHandler->body());
			KeyType nodekey = nodepnt->getKey();
			//KeyType nodeEndKey = nodepnt->getKey();

			if (!scaninfo->shouldScanOverflow()) {
				if (nodekey == fileinfo->firstOverflowNodeKey) {
					if (getinxcthere) this->endTransaction();
					return NULL;				
				}
			}
//if (nodekey == fileinfo->firstOverflowNodeKey)
//        cout << "*********\n1st OVERFLOW NODE: " << nodekey.toString() << endl;

			if (scaninfo->shouldScanOverflow() && scaninfo->isScanningInOverflowSection()) {
				if (nodekey > scaninfo->getEndKeyBoundary() || nodepnt->getEndKey() < scaninfo->getStartKeyBoundary()) {
					delete nodepnt;
					nodepnt = NULL;
					continue;
				}
			}

			// check whether the node satisfy the condition
			if (nodekey > scaninfo->getEndKeyBoundary())
			{
				delete nodepnt;
				nodepnt = NULL;

				// in case there is no overflow section in the file, this is the end of scan
				// or if we do not want to scan in the overflow, we are done as well
				if (!fileinfo->overflow || !scaninfo->shouldScanOverflow())
				{
					if (getinxcthere) this->endTransaction();
					return NULL;
				}

				// otherwise
				else
				{
					// if we are already scanning the overflow section, need to continue, since the 
					// nodes in the overflow section are not ordered
					//if (scaninfo->isScanningInOverflowSection()) continue;

					// otherwise, if and the currrent scan handler is not scanning the overflow section
					// need to start scanning the overflow section (at the end of the shore file)
					// (we always assume that the scan starts in the ordered section (which is not true), 
					// so we have some inefficiency here of recreating an overflow scan) -> AN: Fixed
					//else
					//{	
						// finished the current file scan.
						scanHandler->finish();
						delete scanHandler;
						
						// get the record id of the first node in the overflow section. 
						bool found;
						serial_t rid = this->getNodeRid(*fileinfo, fileinfo->firstOverflowNodeKey, &found);
						if (!found) return NULL;

						// start a new file scan in the overflow section. 
						scanHandler = new scan_file_i(this->volumeID, fileinfo->fid, rid);

						// set the new scanHandler to the scan
						// (note: true means scaninfo->isScanningInOverflowSection will be true)
						scaninfo->setScanHandler(scanHandler, true);

						// go back to fetch another node from the new scanHandler
						continue;
					//}
				}
			} //if nodeKey > endKeyBoundary

			// check scan ranges	

			bool inrange = false;
			if (scanRange == NULL) inrange = true;
			else inrange = scanRange->inScanRange(nodekey);

			if (!inrange)
			{
				// if it is not in the scan range, move to the next range

				// finish the current file scan. 
				delete nodepnt;

				// move on to the next scan range
				bool innewrange = false;
				int rangeCursor = scaninfo->getRangeCursor();

				while (!innewrange)
				{
					rangeCursor++;
					// already out of the last range the scan reaches its end.
					if (rangeCursor == scaninfo->getScanRange()->getScanRangeNumber()) return NULL;
					else
					{
						// otherwise, move on to the next range, trying to find the next node to start scan with
						scanHandler->finish();
						delete scanHandler;

						KeyType scanKey;
						bool found = false;
						
						// find the first node in the new scan range that we can start file scan with. 
						bool success = this->findFirstKeyInScanRange(fileinfo, scaninfo->getScanRange(), rangeCursor, &found, &rangeCursor, &scanKey);

                        // if no such node is found in the range, loop around and move on to the next range. 
						if (!success || !found) continue;

						bool foundNode = false;
						serial_t noderid = this->getNodeRid(*fileinfo, scanKey, &foundNode);
						// can not get the  node with the key returned by findFirstKeyInScanRange.
						// this means an error happens. so, return NULL.
						if (!foundNode) return NULL;

						// start a new file scan in the new scan range. 
						scanHandler = new scan_file_i(this->volumeID, fileinfo->fid, noderid);
						if (scanHandler == NULL)
						{
							// error happens on starting a new file scan
                            globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"PhysicalDataMng::scanFetchNext",__FILE__,"Error starting a new file scan");
							return NULL;
						}
						else innewrange = true;
					}
				}
				
				// set the new scanHandler to the scan
				// AN: why are we setting inOverflow to true here?:
				scaninfo->setScanHandler(scanHandler, true);
				scaninfo->setRangeCursor(rangeCursor);

				// already get into a new scan range, continue with the file scan,
				// to get the next node and verify conditions. 
				continue;
			} //if not in range


			// check level boundary
			int nodelevel = nodepnt->getLevel();
			if (!(nodelevel >= scaninfo->getScanMinLevel()) && (nodelevel <= scaninfo->getScanMaxLevel()))
			{
				// in case the node does not satisfy the level constraint, loop around and get the next node
				// in the file scan. 
				delete nodepnt;
				continue;
			}

			//AN: really only need startkey stuff based on logic found above...
			if (scaninfo->getStartKeyBoundary() > nodepnt->getKey() || scaninfo->getEndKeyBoundary() < nodepnt->getEndKey()) {
				delete nodepnt;
				nodepnt = NULL;
				continue;
			}

			// check scan condition
			bool satisfy = false;
			if (scaninfo->getScanCond() == NULL) satisfy = true;
			else satisfy = checkCond(*fileinfo, nodepnt, scaninfo->getScanCond());

			KeyType resultnodekey;
			if (satisfy)
			{
				switch (scaninfo->getScanCond()->getReturnType())
				{
				case SCAN_RETURN_THISNODE: break;

                case SCAN_RETURN_PARENTNODE:
					resultnodekey = nodepnt->getParent();
					delete nodepnt;
					nodepnt = this->fetchDataNodeFromDBFile(*fileinfo, resultnodekey);
					break;
					
				case SCAN_RETURN_ELEMENTNODE:
					if ((nodepnt->getFlag() == ATTRIBUTE_NODE) || (nodepnt->getFlag() == TEXT_NODE))
					{
						resultnodekey = nodepnt->getParent();
						delete nodepnt;
						nodepnt = this->fetchDataNodeFromDBFile(*fileinfo, resultnodekey);
					}
					else 
					{
                        globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"PhysicalDataMng::scanFetchNext",__FILE__,"Error return type");
						delete nodepnt;
						nodepnt = NULL;
					}
					break;
					
				case SCAN_RETURN_ATTRIBUTENODE:
					// if the return request is to return attribute node, the node 
                    // on which the condition applies has to be an element node.
					if (nodepnt->getFlag() == ELEMENT_NODE)
					{
						resultnodekey = ((DM_ElementNode*) nodepnt)->getAttributes();
						delete nodepnt;
						nodepnt = this->fetchDataNodeFromDBFile(*fileinfo, resultnodekey);
					}
					else 
					{
                        globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"PhysicalDataMng::scanFetchNext",__FILE__,"Error return type");
						delete nodepnt;
						nodepnt = NULL;
					}
					break;
					
				default:
                    globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"PhysicalDataMng::scanFetchNext",__FILE__,"Error return type");
					delete nodepnt;
					nodepnt = NULL;
					break;
				}
				find = true;
			}

			// if the no node is found in this around, release the nodepnt and loop around to get
			// the next node in the file scan. 
			if (!find) delete nodepnt;
		}
	}

	if (getinxcthere) this->endTransaction();
	if (!find) return NULL;
	return nodepnt;
}

/**
* @return xmlNameTable
*/
XMLNameTable* PhysicalDataMng::getXMLNameTable()
{
    return this->xmlNameTable;
}

/*-----------------------------------------------------------------
* Internal Methods
 ------------------------------------------------------------------*/

/**
* Internal Method
*
* In support of the Loading Interface.
* 
* Load an XML document into the database.
* 
* @param XMLFile The XML document name, with path.
* @param targetName The name of the data file in the database that will stored the nodes in the XML document.
* @param maxdepth The maximum depth of the XML document.
* @param convertmulticolor The flag saying whether to convert pointer-based to multicolor model (Nuwee added: 07/14/03)
* @returns Error Code.
*/
int PhysicalDataMng::loadXMLFileToDBFile(char* XMLfile, char* targetName, int maxdepth, bool convertmulticolor)
{
	bool getinxcthere = false;
	if (!this->inTransaction)
	{
		this->beginTransaction();
		getinxcthere = true;
	}

	// Check whether a data file with the same name already exists in the database
	FileInfoType* fileinfo; 
	fileinfo = this->xmlDocumentTable->getFileInfo(targetName);
	if (fileinfo != NULL)
	{
		// if a data file with the same name is in the database already, can not finish the loading. 
        globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"PhysicalDataMng::loadXMLFileToDBFile",__FILE__,"Error file already exists");
		if (getinxcthere) this->endTransaction();
        delete fileinfo;
		return -1;
	}

	// create a new instance of the MSXMLParser. 
	MSXMLParser* xmlParser = new MSXMLParser(this->volumeID);

	// parse the XML document, and store the nodes into the database
	FileInfoType* retFileinfo = xmlParser->parseXML(XMLfile, maxdepth, OP_PARSE_STORE, fileinfo, 
        NULL, NULL, NULL, NULL, convertmulticolor, this->xmlNameTable);
	// release the XML parser. 
	delete xmlParser;

	if (retFileinfo == NULL)
	{
		// this indicates that there is error in the loading process.
		//not necessarily a well-formedness problem:
		//globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"PhysicalDataMng::loadXMLFileToDBFile",__FILE__,"File not well-formed");
		globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"PhysicalDataMng::loadXMLFileToDBFile",__FILE__,"Error loading file. File was not loaded (transaction aborted)");
		if (getinxcthere) this->abortTransaction();
		return -1;
	}

	// add the file to the xmlDocumentTable
	this->xmlDocumentTable->insertFile(targetName, retFileinfo);

	if (getinxcthere) this->endTransaction();
	return NO_ERROR;
}

/**
* Internal Method
* 
* In support of the single node access interface, the loading interface the the update interface
* 
* Append a node to the tail of the data file.
* 
* @param fileinfo The information of the file where the node is to be appended to. 
* @param apdHandler An append handler on the data file.
* @param node The node to be appended to the data file. 
* @returns Error code 
*/
int PhysicalDataMng::appendNodeToDBFile(FileInfoType* fileinfo, append_file_i* apdHandler, DM_DataNode* node)
{
	bool getinxcthere = false;
	if (!this->inTransaction)
	{
		this->beginTransaction();
		getinxcthere = true;
	}

	char* nodeInStr;
	int nodeInStrLen;

	KeyType key = node->getKey();


	//AN: maxKey is the largest endKey + 1 after loading.  the append operation also makes this assumption
	//so while this is not really correct (maxKey should probably be the largest startKey in the document),
	//it's easier to change this method (which affects reorganization and updates),
	//rather than changing the xml parsing code.
	//So, change this:
	//if (key > fileinfo->maxKey) fileinfo->maxKey = key;
	//to this:
	if (node->getEndKey() >= fileinfo->maxKey) fileinfo->maxKey = static_cast<int>(node->getEndKey().toDouble() + 1);
	if (node->getLevel() > fileinfo->maxDepth) fileinfo->maxDepth = node->getLevel();
	fileinfo->recNum++;

	// wrap the node into a string
	nodeInStr = node->wrap(&(nodeInStrLen));	

	// create a record in the database, append it to the tail of the data file. 
	vec_t data(nodeInStr, nodeInStrLen); 	
	lrid_t rid; 
	rc_t rc = apdHandler->create_rec(vec_t(), nodeInStrLen, data, rid);
	if (rc)
	{
		// error handling
        globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"PhysicalDataMng::appendNodeToDBFile",__FILE__,"create_rec");
		if (getinxcthere) this->endTransaction();
		return -1;
	}
			
	// release the string
	delete [] nodeInStr;

	serial_t srid = rid.serial;
	if (key == fileinfo->rootKey) fileinfo->firstRid = srid;

	// create an item in the key index to associate the key of the node with the record. 
	rc = ss_m::create_assoc(this->volumeID, fileinfo->keyIndex, vec_t(&key, sizeof(KeyType)), vec_t(&srid, sizeof(srid)));
	if (rc) 
	{
        globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"PhysicalDataMng::appendNodeToDBFile",__FILE__,"create_assoc");
		if (getinxcthere) this->endTransaction();
		return -1;				
	}

	if (getinxcthere) this->endTransaction();
	return NO_ERROR;
}

/**
* Internal Process Method
* 
* Get the record id of a node with given key. 
* 
* @param fileinfo The information of the data file that contains the node.
* @param nodekey The key of the node whose record id is to be found. 
* @param found The is a return value, which indicate whether the node exist in the databse or not. 
* @returns The record id of the node, if found is true. 
*/
serial_t PhysicalDataMng::getNodeRid(FileInfoType fileinfo, KeyType nodekey, bool* found)
{
	bool getinxcthere = false;
	if (!this->inTransaction)
	{
		this->beginTransaction();
		getinxcthere = true;
	}

	serial_t noderid;
	smsize_t id_len = sizeof(noderid);

	// find the existence of the node, and the record id by searching in the key index. 
	rc_t rc = ss_m::find_assoc(this->volumeID, fileinfo.keyIndex, vec_t(&nodekey, sizeof(KeyType)), &noderid, id_len, *found);
	if (rc)
	{
        globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"PhysicalDataMng::getNodeRid",__FILE__,"find_assoc");
		if (getinxcthere) this->endTransaction();
		*found = false;
		return NULL;
	}

	if (getinxcthere) this->endTransaction();
	return noderid;
}


/**
* Internal Method
*
* In support of checkCond()
* 
* Apply a predicate (one predicate within the scan condition) against a node, 
* determine whether the node meet the predicate or not.
*
* @param fileinfo The inforamtion about the file where the node is from.  
* @param node The node to be checked
* @param predicate The predicate (part of a selection condition)
* @returns A boolean value which indicate whether the node meets the predicate or not.
* 
* @see checkCond
*/
bool PhysicalDataMng::checkPredicate(const FileInfoType fileinfo, DM_DataNode* node, PredicateCondition* predicate)
{
	// a node is considered meeting the predicate if it is empty. 
	if (predicate == NULL) return true;

	bool getinxcthere = false;
	if (!this->inTransaction)
	{
		this->beginTransaction();
		getinxcthere = true;
	}

	bool retval;

	// check whether the node meet the predicate. 
	// different kind of node is processed differently. 
	switch (node->getFlag())
	{
	case DOCUMENT_NODE:
		retval = checkPredDoc(node, predicate);
		break;
	case ELEMENT_NODE:
		retval = checkPredEle(fileinfo, node, predicate);
		break;
	case ATTRIBUTE_NODE:
		retval = checkPredAttr(node, predicate);
		break;
	case TEXT_NODE:
	case COMMENT_NODE:
		retval = checkPredChar(node, predicate);
		break;
	default:
        globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"PhysicalDataMng::checkPredicate",__FILE__,"Error node type in condition");
		retval = false;
	}

	if (getinxcthere) this->endTransaction();
	return retval;
}

/**
* Internal Method
*
* In support of the checkCond.
*
* Apply a predicate (one predicate within the selection condition) against a CharNode, 
* determine whether the node meet the predicate.
*
* @param node The node to check, it should be guaranteed to be a DM_CharNode
* @param predicate The predicate (part of the selection condition)
* @returns A boolean value which indicate whether the node meet the predicate or not.
* 
* @see checkCond
* @see checkPredicate
*/
bool PhysicalDataMng::checkPredChar(DM_DataNode* node, PredicateCondition* predicate)
{
	bool retval = false;
	Value* rightvalue = predicate->getRightValue();

    switch (predicate->getLeftValue())
    {
    case SCAN_LEFTVALUE_VALUE:
        {    
            // the left value is a string value
            char* leftchar = ((DM_CharNode*) node)->getCharValue();
            Value leftvalue(STRING_VALUE);
            leftvalue.setStrValue(leftchar);
            retval = leftvalue.compareValue(predicate->getOperator(), rightvalue);	
        }
        break;

    case SCAN_LEFTVALUE_LENGTH:
        {
            // the left value is the length of the string
            Value* rightvalue = predicate->getRightValue();
            Value leftvalue(INT_VALUE);
            leftvalue.setIntValue((int)strlen(((DM_CharNode*) node)->getCharValue()));
            retval = leftvalue.compareValue(predicate->getOperator(), rightvalue);
        }
        break;

    default:
        globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"PhysicalDataMng::checkPredChar",__FILE__,"Error left value type");
        retval = false;
        break;

    }
    return retval;
}

/**
* Internal Method
*
* In support of the checkCond.
*
* Apply a predicate (one predicate within the selection condition) against a document node, 
* determine whether the node meet the predicate.
*
* @param node The node to check, it should be guaranteed to be a DM_DocumentNode
* @param predicate The predicate (part of the selection condition)
* @returns A boolean value which indicate whether the node meet the predicate or not.
* 
* @see checkCond
* @see checkPredicate
*/
bool PhysicalDataMng::checkPredDoc(DM_DataNode* node, PredicateCondition* predicate)
{
	bool getinxcthere = false;
	if (!this->inTransaction)
	{
		this->beginTransaction();
		getinxcthere = true;
	}

	bool retval = false;
	char* leftchar;
	Value* leftvalue;
	Value* rightvalue = predicate->getRightValue();

	// the process is different for different left value
	switch (predicate->getLeftValue())
	{
	case SCAN_LEFTVALUE_XMLFILENAME:
		// to compare the XML file name with the right value
		leftchar = ((DM_DocumentNode*) node)->getXMLFileName();
		leftvalue = new Value(STRING_VALUE);
		leftvalue->setStrValue(leftchar);
		retval = leftvalue->compareValue(predicate->getOperator(), rightvalue);
        delete leftvalue;
		break;

    default:
        globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"PhysicalDataMng::checkPredDoc",__FILE__,"Error left value type");
        retval = false;
        break;

	}

	if (getinxcthere) this->endTransaction();
	return retval;
}

/**
* Internal Method
*
* In support of the checkCond.
*
* Apply a predicate (one predicate within the selection condition) against a element node, 
* determine whether the node meet the predicate.
*
* @param node The node to check, it should be guaranteed to be a DM_ElementNode
* @param predicate The predicate (part of the selection condition)
* @returns A boolean value which indicate whether the node meet the predicate or not.
* 
* @see checkCond
* @see checkPredicate
*/
bool PhysicalDataMng::checkPredEle(const FileInfoType fileinfo, 	
								   DM_DataNode* node, 
								   PredicateCondition* predicate)
{
	bool getinxcthere = false;
	if (!this->inTransaction)
	{
		this->beginTransaction();
		getinxcthere = true;
	}

	bool retval=false;
	Value* rightvalue = predicate->getRightValue();

	// the process is different for different left value
	switch (predicate->getLeftValue())
	{
	case SCAN_LEFTVALUE_NODETAG:
		{
			// compare the node tag with the right value
            //TODO: modify here - Cong 06/04/2004
			//char* leftchar = ((DM_ElementNode*) node)->getTag(xmlNameTable);
			//Value *leftvalue = new Value(STRING_VALUE);
			//leftvalue->setStrValue(leftchar);
			//retval = leftvalue->compareValue(predicate->getOperator(), rightvalue);
			//delete leftvalue;
            int leftint = ((DM_ElementNode*)node)->getTag();
            Value *leftvalue =  new Value(INT_VALUE);
            leftvalue->setIntValue(leftint);
            retval = leftvalue->compareValue(predicate->getOperator(), rightvalue);
            // end of modification
		}
		break;

	case SCAN_LEFTVALUE_CHILDNUMBER:
		{
			// compare the child number with the right value
			Value* leftvalue = new Value(INT_VALUE);
			leftvalue->setIntValue(node->getChildNumber());
			retval = leftvalue->compareValue(predicate->getOperator(), rightvalue);
			delete leftvalue;
		}
		break;
		
	case SCAN_LEFTVALUE_ATTRIBUTENUMBER:
		{
			// compare the attribute number with the right value
			Value* leftvalue = new Value(INT_VALUE);
			leftvalue->setIntValue(node->getAttributeNumber());
			retval = leftvalue->compareValue(predicate->getOperator(), rightvalue);
			delete leftvalue;
		}
		break;
	
	case SCAN_LEFTVALUE_HASCHILD:
		{
			// check whether the element has a child with the given tag/content
			if (node->getChildNumber() == 0)
			{
				retval = false;
				break;
			}
			else
			{	
				bool find = false;
				
				// fetch the first child of the element node
				KeyType childkey = node->getFirstChild();
				DM_DataNode* childnode = fetchDataNodeFromDBFile(fileinfo, childkey);

				// keep fetching child of the element node, until such a node is found or 
				// all children have been checked. 
				while ((!find) && (childnode != NULL))
				{
					if (childnode != NULL)
					{
						// children of different types are treated differently.
						switch (childnode->getFlag())
						{
						case ELEMENT_NODE:
							{
								// for element node, compare the node tag
								// TODO: modify here - Cong 06/04/2004
								//Value* leftvalue = new Value(STRING_VALUE);
								//leftvalue->setStrValue(childnode->getTag(xmlNameTable));
								//retval = leftvalue->compareValue(predicate->getOperator(), rightvalue);
								//if (retval == true) find = true;
                                Value* leftvalue = new Value(INT_VALUE);
                                leftvalue->setIntValue(childnode->getTag());
                                retval = leftvalue->compareValue(predicate->getOperator(), rightvalue);
                                if (retval == true) find = true;
                                // end of modification
							}
							break;
							
						case TEXT_NODE:
						case COMMENT_NODE:
							{
								// for text node and comment node, compare the content
								Value* leftvalue = new Value(STRING_VALUE);
								leftvalue->setStrValue(((DM_CharNode*) childnode)->getCharValue());
								retval = leftvalue->compareValue(predicate->getOperator(), rightvalue);
								if (retval == true) find = true;
							}
							break;
							
						default:
							break;
						}
					}
					
					// fetch the next child, following the sibling link
					KeyType siblingKey = childnode->getNextSibling();
				
					//Nuwee added: 06/30/2003 for Multicolor
					//If key is not valid , and it is char node, and attribute key is valid
					if ((!siblingKey.isValid()) && 
						((childnode->getFlag() == TEXT_NODE) || (childnode->getFlag() == COMMENT_NODE)) &&
						(((DM_CharNode*)childnode)->getAttributes().isValid())) {
							// it is part of the children of Multicolor node
							//go to that attribute node to get next sibling of this char node
							DM_DataNode* attrnode;
							attrnode = fetchDataNodeFromDBFile(fileinfo, ((DM_CharNode*)childnode)->getAttributes());
							siblingKey = ((DM_AttributeNode*)attrnode)->getMCTNextSibling(node->getKey(),childnode->getKey());
							delete attrnode;
						}
					//end Multicolor

					if (siblingKey < 0) childnode = NULL;
					else childnode = fetchDataNodeFromDBFile(fileinfo, siblingKey);
				}
			}
			break;
		}

	case SCAN_LEFTVALUE_HASATTRIBUTE:
		{
			// check whether the element has an attribute with the given name
			KeyType attrKey = ((DM_ElementNode*) node)->getAttributes();
			if (attrKey < 0) retval = false;
			else
			{
				// get the attribute node
				DM_AttributeNode* attrNode = (DM_AttributeNode*) this->fetchDataNodeFromDBFile(fileinfo, attrKey);
				if (attrNode == NULL) return false;
				else
				{
					// the number of attribute
					int attrNum = attrNode->getAttributeNumber();

					Value* leftvalue = new Value(STRING_VALUE);
					
					// go over the attribute one by one, searching for the name
					for (short i=0; i<attrNum; i++)
					{
						leftvalue->setStrValue(attrNode->getAttributeNameAt(i));
						retval = leftvalue->compareValue(predicate->getOperator(), rightvalue);
						if (retval == true) break;
					}
					delete leftvalue;
				}				
				delete attrNode; //Nuwee added 09/02/03
			}
		}
		break;

	case SCAN_LEFTVALUE_ELEMENTCONTENT:
		{
			// check whether the element content meet the predicate
			// remember that one element may have more than one text child. 
			// get child one by one, until one that satisfies the predicate is found, or all 
			// children have been checked. 

			KeyType childKey = node->getFirstChild();
			while (childKey.isValid())
			{
				// get the child node
				DM_DataNode* childNode = this->fetchDataNodeFromDBFile(fileinfo, childKey);

				if (childNode->getFlag() == TEXT_NODE)
				{
					// do condition checking only when the child is a text node
					Value leftvalue(STRING_VALUE);
					leftvalue.setStrValue(((DM_TextNode*) childNode)->getCharValue());
					retval = leftvalue.compareValue(predicate->getOperator(), rightvalue);

					// jump out of the loop is such a child is found. 
					if (retval == true) break;
				}

				// move to the next child, following sibling link
				childKey = childNode->getNextSibling();
				
				//Nuwee added: 06/30/2003 for Multicolor
				//If key is not valid , and it is char node, and attribute key is valid
                if ((!childKey.isValid()) && 
                    ((childNode->getFlag() == TEXT_NODE) || (childNode->getFlag() == COMMENT_NODE)) &&
                    (((DM_CharNode*)childNode)->getAttributes().isValid())) 
                {
                    // it is part of the children of Multicolor node
                    //go to that attribute node to get next sibling of this char node
                    DM_DataNode* attrnode;
                    attrnode = fetchDataNodeFromDBFile(fileinfo, ((DM_CharNode*)childNode)->getAttributes());
                    childKey = ((DM_AttributeNode*)attrnode)->getMCTNextSibling(node->getKey(),childNode->getKey());
                    delete attrnode;
                }
				//end Multicolor
			}
		}
		break;

	default:
		break;
	}
	if (getinxcthere) this->endTransaction();
	return retval;
}

/**
* Internal Method
*
* In support of the checkCond.
*
* Apply a predicate (one predicate within the selection condition) against an attribute node, 
* determine whether the node meet the predicate.
*
* @param node The node to check, it should be guaranteed to be a DM_AttributeNode
* @param predicate The predicate (part of the selection condition)
* @returns A boolean value which indicate whether the node meet the predicate or not.
* 
* @see checkCond
* @see checkPredicate
*/
bool PhysicalDataMng::checkPredAttr(DM_DataNode* node, PredicateCondition* predicate)
{
	bool retval=false;
	Value* rightvalue = predicate->getRightValue();

	// the process is different for different left value
	switch (predicate->getLeftValue())
	{
	case SCAN_LEFTVALUE_ATTRIBUTENUMBER:
		{
			// compare the attribute number with the right value
			Value leftvalue(INT_VALUE);
			leftvalue.setIntValue(((DM_AttributeNode*) node)->getAttributeNumber());
			retval = leftvalue.compareValue(predicate->getOperator(), rightvalue);		
		}
		break;

	case SCAN_LEFTVALUE_HASATTRIBUTE:
		{
			// find whether the attribute node contains an attribute with the name given
			int attrnum = ((DM_AttributeNode*) node)->getAttributeNumber();
			if (attrnum <= 0) return false;
	
			Value leftvalue(STRING_VALUE);

			// go over the attributes, looking for the given name
			for (short i=0; i<attrnum; i++)
			{
				leftvalue.setStrValue(((DM_AttributeNode*) node)->getAttributeNameAt(i));
				retval = leftvalue.compareValue(predicate->getOperator(), rightvalue);
				if (retval == true) break;
			}
		}
		break;

	case SCAN_LEFTVALUE_VALUE:
	case SCAN_LEFTVALUE_LENGTH:
	case SCAN_LEFTVALUE_XMLFILENAME:
	case SCAN_LEFTVALUE_NODETAG:
	case SCAN_LEFTVALUE_CHILDNUMBER:
	case SCAN_LEFTVALUE_HASCHILD:
	case SCAN_LEFTVALUE_ELEMENTCONTENT:
		{
			// other left values are not valid for attribute node. 
            globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"PhysicalDataMng::checkPredAttr",__FILE__,"Left value of the predicate does not apply to AttributeNode");
			retval = false;
		}
		break;

	default: 
		// if the left value is not of any of the pre-defined code, it is a pointer to a string 
		// which is interpreted as attribute name, and the value of that attribute is to be
		// compared with the right value. 
		{

#pragma warning(disable:4312) // disable the warning for casting int to char * for the leftValue
			char* leftval = (char*) predicate->getLeftValue();
#pragma warning(default:4312)

			// get the value of the attribute with the given name.
			Value* attrvalue = ((DM_AttributeNode*) node)->getAttr(leftval);
			if (attrvalue == NULL)
			{
				// no such attribute is found
               	retval = false;
			}
			else 
			{
				// compare the value
				Value* rightvalue = predicate->getRightValue();
				retval = attrvalue->compareValue(predicate->getOperator(), rightvalue);
			}
		}
	}
	return retval;
}


/**
* Internal Method
* 
* In supprot of checkCond, which part of the scan interface, and can also be called along.
* 
* Apply a selection condition in conjunctive expression (a part of the selection condition) against 
* a node, determine whether the node meet the predicate.
* 
* @param fileinfo The information of the file which contains the node to be checked. 
* @param node The node to be checked.
* @param concond The condition in conjunctive expression (part of the selection condition)
* @returns A boolean value which indicate whether the node meet the condition or not.
*
* @see checkCond
* @see checkDisCond
* @see checkPredicate
*/
bool PhysicalDataMng::checkConCond(const FileInfoType fileinfo, DM_DataNode* node, ConjunctiveCondition* concond)
{
	bool getinxcthere = false;
	if (!this->inTransaction)
	{
		this->beginTransaction();
		getinxcthere = true;
	}

	// if the condition is empty, the node is considered as satisfying the condition
	if (concond == NULL)
	{
		if (getinxcthere) this->endTransaction();
		return true;
	}

	bool retval = true;

	// check whether the node satisfies each predicate in the condition.
	// a node satisfies a conjunctive condition only when it satisfies all predicates in the condition. 
	for (int i =0; i<concond->getNumber(); i++)
	{
		retval = checkPredicate(fileinfo, node, concond->getCondAt(i));
		if (retval == false) 
		{
			if (getinxcthere) this->endTransaction();
			return false;
		}
	}

	if (getinxcthere) this->endTransaction();
	return retval;
}

/**
* Process Method
* 
* Apply a selection condition against a node, determine whether the node meet the predicate.
* 
* @param fileinfo The information of the file which contains the node to be checked. 
* @param node The node to be checked.
* @param scancond The condition to be applied on the node
* @returns A boolean value which indicate whether the node meet the condition or not.
*
* @see checkConCond
* @see checkPredicate
* @see scanfetchNext
*/
bool PhysicalDataMng::checkCond(const FileInfoType fileinfo, DM_DataNode* node, SelectionCondition* scancond)
{
	bool getinxcthere = false;
	if (!this->inTransaction)
	{
		this->beginTransaction();
		getinxcthere = true;
	}

	if (scancond->getNodeType() != SCAN_ALLNODES)
	{
		// if the condition is not to be applied on all type of nodes, eliminate other type of nodes here. 
		int nodetype = node->getFlag();
		if (scancond->getNodeType() != nodetype) 
		{
			if (getinxcthere) this->endTransaction();
			return false;
		}
	}

	if (getinxcthere) this->endTransaction();

	// call checkDisCond to varify the condition itself. 
	return checkDisCond(fileinfo, node, scancond->getCondition());
}

/**
* Internal Method
* 
* In supprot of checkCond, which part of the scan interface, and can also be called along.
* 
* Apply a selection condition in disjunctive expression (a part of the selection condition) against 
* a node, determine whether the node meet the predicate.
* 
* @param fileinfo The information of the file which contains the node to be checked. 
* @param node The node to be checked.
* @param concond The condition in disnjunctive expression (part of the selection condition)
* @returns A boolean value which indicate whether the node meet the condition or not.
*
* @see checkCond
* @see checkCondsCond
* @see checkPredicate
*/
bool PhysicalDataMng::checkDisCond(const FileInfoType fileinfo, DM_DataNode* node, DisjunctiveCondition* discond)
{
	bool getinxcthere = false;
	if (!this->inTransaction)
	{
		this->beginTransaction();
		getinxcthere = true;
	}

	// if the condition is empty, the node is considered satisfying the condition 
	if (discond == NULL)
	{
		if (getinxcthere) this->endTransaction();
		return true;
	}
	else if (discond->getNumber() == 0)
	{
		if (getinxcthere) this->endTransaction();
		return true;
	}

	bool retval = true;;

	// the node satisfies the condition as long as it satisfies one of the conjunctive 
	// condition in the disjunctive condition
	for (int i=0; i<discond->getNumber(); i++)
	{
		retval = checkConCond(fileinfo, node, discond->getCondAt(i));
		if (retval == true) 
		{
			if (getinxcthere) this->endTransaction();
			return true;
		}
	}
	if (getinxcthere) this->endTransaction();

	return retval;
}


/**
* Internal Method
* 
* In support of scan and update
* 
* Find the first node in the scan range. 
* 
* Given a scan range (a set of start keys pairs), it is not necessary that there is a node in the data file whose 
* key is the same as the start key on the boundary. and it is not necessarily true that there is any node
* in the first range in the range set. This function find the first node that falls in the scan range. 
* 
* @param fileinfo The information of the data file.
* @param scanrange A scan range (set of ranges (key pairs)).
* @param startCursor A pointer to a range in the scan range that we are currently looking at.
* @param foundKey A boolean value which indicate whether a node is found (return value)
* @param foundInCursor A pointer to a range in which the first node is found (return value)
* @param scankey The key found (return value)
* @param sortedFileOnly If true, we only look for the node in the sorted portion of the file, and ignore the overflow area
* @returns A boolean value which indicate whether the process is done successfully. 
*		return false means something wrong happends and all values returned through parameter are meaningless. 
*		return true means the searching is done successfully. if foundKey is false, that means nothing is found. 
*/
bool PhysicalDataMng::findFirstKeyInScanRange(FileInfoType* fileinfo, ScanRange* scanrange, int startCursor, 
											  bool* foundKey, int* foundInCursor, KeyType* scanKey, bool sortedFileOnly)
{
	int crtCursor = startCursor;
	rc_t rc;

	int rangeNum = scanrange->getScanRangeNumber();
	if (crtCursor >= rangeNum)
	{
		// if the startCursor is pointed out of the scan ranges. no key can be found. 
		*foundKey = false;
		return true;
	}

	// get the range pointed by the range cursor
	KeyType cntStartKey = scanrange->getScanRangeAt(crtCursor)->startPos;
	KeyType cntEndKey = scanrange->getScanRangeAt(crtCursor)->endPos;

	// start an index scan, within the scope of the range. 
    scan_index_i* indexScanHandler = new scan_index_i(volumeID, fileinfo->keyIndex, ss_m::ge, vec_t(&cntStartKey, sizeof(KeyType)), 
                                                      ss_m::le, vec_t(&cntEndKey, sizeof(KeyType)));
	if (indexScanHandler->error_code())
	{
		// error happend in index scan.
        globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"PhysicalDataMng::findFirstKeyInScanRange",__FILE__,"Error start index scan");
		return false;
	}

	// prepare for getting item from index.
	serial_t srid;
	KeyType indexKey, nodekey;
	int keySize = sizeof(KeyType);
	vec_t* vecIndexKey = new vec_t(&indexKey, keySize);
	int ridSize = sizeof(serial_t);
	vec_t* vecRid = new vec_t(&srid, ridSize);

	bool found = false;
	bool eof = false;
	while (!found)
	{
		// move the index scan to the next item. 
		rc = indexScanHandler->next(eof);
		if (rc)
		{
            globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"PhysicalDataMng::findFirstKeyInScanRange",__FILE__,"Error get next item from index");
			return false;;
		}

		if (eof) 
		{
			*foundKey = false;
			return true;
		}

		// get an item from the index scan
		rc = indexScanHandler->curr(vecIndexKey, (unsigned long &)keySize, vecRid, (unsigned long &)ridSize);
		if (rc)
		{
            globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"PhysicalDataMng::findFirstKeyInScanRange",__FILE__,"Error start index scan");
			return false;
		}				

		if (indexKey > cntEndKey)
		{
			// already out of the current range. should move on to the next range

			// finish the current index scan
			indexScanHandler->finish();
			delete indexScanHandler;

			crtCursor ++;
			if (crtCursor >= rangeNum)
			{
				*foundKey = false;
				return true;
			}

			// start another index scan. 
			cntStartKey = scanrange->getScanRangeAt(crtCursor)->startPos;
			cntEndKey = scanrange->getScanRangeAt(crtCursor)->endPos;
			indexScanHandler = new scan_index_i(volumeID, fileinfo->keyIndex, ss_m::ge, vec_t(&cntStartKey, sizeof(KeyType)), 
                                                ss_m::le, vec_t(&cntEndKey, sizeof(KeyType)));	
			if (indexScanHandler->error_code())
			{
                globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"PhysicalDataMng::findFirstKeyInScanRange",__FILE__,"Error start index scan");
				return false;
			}	
		}

		else
		{
			if (sortedFileOnly) {
				bool foundNode = false;
				bool foundOverflowNode = false;

				serial_t noderid = this->getNodeRid(*fileinfo, indexKey, &foundNode);
				serial_t overflowRid = this->getNodeRid((const FileInfoType)*fileinfo,
					fileinfo->firstOverflowNodeKey, &foundOverflowNode);

				if (foundOverflowNode && overflowRid <= noderid) {
					found = false;
					continue;
				}
			}

			// found the key. 
			*foundKey = true;
			*foundInCursor = crtCursor; 
			*scanKey = indexKey;
			found = true;
		}
	}
	
	// finish index scan. 
	indexScanHandler->finish();
	delete indexScanHandler;

	return true;		
}


/**
* Internal Method
* 
* Parser the name of XML  document with path, split it to filename and file path
* 
*@param str The filename with path
*@param path The path (return value).
*@param filename The filename (return value).
*/
const void PhysicalDataMng::parse_name(char* str, char* path, char* filename)
{
	char* strpos;
	int pos;

	strpos = strrchr(str, '/');
    // Modified by Cong: "/" is UNIX convention, need to deal with "\" as well
    if (strpos == NULL) strpos = strrchr(str, '\\');
    // end of modification
#pragma warning(disable:4312 4311) // disable the warning for casting int to char * for the leftValue
	pos = (int) strpos - (int) str + 1;
#pragma warning(default:4312 4311)
	if (pos >=0)
	{
		strncpy(path, str, pos);
		path[pos] = '\0';
		strcpy(filename, strpos+1);
	}
	else 
    {
        strcpy(path, "./");
        strcpy(filename, str);
    }
}