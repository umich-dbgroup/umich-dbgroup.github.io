/*
COPYRIGHT  (c) 2000-2004 
THE REGENTS OF THE UNIVERSITY OF MICHIGAN
ALL RIGHTS RESERVED

PERMISSION IS GRANTED TO USE, COPY, CREATE DERIVATIVE WORKS AND
REDISTRIBUTE THIS SOFTWARE AND SUCH DERIVATIVE WORKS FOR NONCOMMERCIAL
EDUCATION AND RESEARCH PURPOSES, SO LONG AS NO FEE IS CHARGED, AND SO LONG
AS THE COPYRIGHT NOTICE ABOVE, THIS GRANT OF PERMISSION, AND THE
DISCLAIMER BELOW APPEAR IN ALL COPIES MADE; AND SO LONG AS THE NAME OF THE
UNIVERSITY OF MICHIGAN IS NOT USED IN ANY ADVERTISING OR PUBLICITY
PERTAINING TO THE USE OR DISTRIBUTION OF THIS SOFTWARE WITHOUT SPECIFIC,
WRITTEN PRIOR AUTHORIZATION.

THIS SOFTWARE IS PROVIDED AS IS, WITHOUT REPRESENTATION FROM THE
UNIVERSITY OF MICHIGAN AS TO ITS FITNESS FOR ANY PURPOSE, AND WITHOUT
WARRANTY BY THE UNIVERSITY OF MICHIGAN OF ANY KIND, EITHER EXPRESS OR
IMPLIED, INCLUDING WITHOUT LIMITATION THE IMPLIED WARRANTIES OF
MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE. THE REGENTS OF THE
UNIVERSITY OF MICHIGAN SHALL NOT BE LIABLE FOR ANY DAMAGES, INCLUDING
SPECIAL, INDIRECT, INCIDENTAL, OR CONSEQUENTIAL DAMAGES, WITH RESPECT TO
ANY CLAIM ARISING OUT OF OR IN CONNECTION WITH THE USE OF THE SOFTWARE,
EVEN IF IT HAS BEEN OR IS HEREAFTER ADVISED OF THE POSSIBILITY OF SUCH
DAMAGES.
*/

/**
 * @author Yuqing (Melanie) Wu
 */

#include "DisjunctiveCondition.h"
#include "../../Utilities/ErrorInfoClass.h"
extern ErrorInfoClass globalErrorInfo;

/**
* class DisjunctiveCondition
* 
* This class represent seleciton condition that is a set of ConjunctiveCondition with OR relation between them. 
* This class provide functions for store, access the information of a DisjunctiveCondition, as well as functions 
* that validate, wrap/unwrap the condition to a string, and the function that compare one condition to another
* trying to find the containment relationship between them. 
*
* @see SelectionCondition
* @see ConjunctiveCondition
*/

/** 
* Constructor
* Construct a blank instance of the condition
*/
DisjunctiveCondition::DisjunctiveCondition()
{
	this->disjunctiveNumber = 0;
}

/** 
* Constructor
* Construct a blank instance of the condition, given the number of ConjunctiveCondition in the condition. 
*
* @param num The number of ConjunctiveCondition that will be in this DisjunctiveCondition
*/
DisjunctiveCondition::DisjunctiveCondition(int num)
{
	this->disjunctiveNumber = num;
	this->conjunctiveConditionList = new ConjunctiveCondition*[this->disjunctiveNumber];
	for (int i=0; i<this->disjunctiveNumber; i++)
		this->conjunctiveConditionList[i] = NULL;
}

/**
* Constructor
* Create an instance of the DisjunctiveCondition, using the information wrapped in a string
* @param buffer The string that contains the information about the condition. 
*/
DisjunctiveCondition::DisjunctiveCondition(char* buffer)
{
	int cursor = 0;
	memcpy(&(this->disjunctiveNumber), buffer, sizeof(int));
	cursor += sizeof(int);
	this->conjunctiveConditionList = new ConjunctiveCondition*[this->disjunctiveNumber];

	for (int i=0; i<this->disjunctiveNumber; i++)
	{
		int length;
		memcpy(&length, buffer+cursor, sizeof(int));
		cursor += sizeof(int);
		this->conjunctiveConditionList[i] = new ConjunctiveCondition(buffer+cursor);
		cursor += length;
	}

}

/**
* Constructor
* Create an instance of the DisjunctiveCondition, by copying info from another instance.
* @param cond The disjunctive condition to be copied. 
*/
DisjunctiveCondition::DisjunctiveCondition(DisjunctiveCondition* cond)
{
	this->disjunctiveNumber = cond->getNumber();
	this->conjunctiveConditionList 
		= new ConjunctiveCondition*[this->disjunctiveNumber];
	for (int i=0; i<this->disjunctiveNumber; i++)
		this->conjunctiveConditionList[i] 
			= new ConjunctiveCondition(cond->getCondAt(i));
}

/**
* Destructor
* Release space taken by the ConjunctiveCondition
*/
DisjunctiveCondition::~DisjunctiveCondition()
{
	if (this->disjunctiveNumber != 0)
	{
		for (int i=0; i<this->disjunctiveNumber; i++) {
			delete this->conjunctiveConditionList[i];
			this->conjunctiveConditionList[i] = NULL;
		}
		delete [] this->conjunctiveConditionList;
		this->conjunctiveConditionList = NULL;
	}
}

/**
* Access Method
* Get the information about the number of ConjunctiveCondition
*/
int DisjunctiveCondition::getNumber()
{
	return this->disjunctiveNumber;
}

/**
* Access Method
* Get all the ConjunctiveCondition in the DisjunctiveCondition
* @returns The list of ConjunctiveCondition in the DisjunctiveCondition.
*/
ConjunctiveCondition** DisjunctiveCondition::getCondList()
{
	return this->conjunctiveConditionList;
}

/**
* Access Method
* Get the ConjunctiveCondition at a certain position
* @param index Indicate which ConjunctiveCondition to get
* @returns THe index'th ConjunctiveCondition in the DisjunctiveCondition.
*/
ConjunctiveCondition* DisjunctiveCondition::getCondAt(int index)
{
	if (index > this->disjunctiveNumber)
		return NULL;
	else
		return this->conjunctiveConditionList[index];
}

/**
* Set Method
* Set the number of ConjunctiveCondition in the DisjunctiveCondition
* Changing the number of ConjunctiveCondition in the DisjunctiveCondition will result in the deletion of all ConjunctiveCondition
* currently in the DisjunctiveCondition and reallocation space according to  the number given. 
* 
* @param num The number of ConjunctiveCondition to be in the DisjunctiveCondition
*/
void DisjunctiveCondition::setNumber(int num)
{
	// remove old ConjunctiveCondition
	if (this->disjunctiveNumber != 0)
	{
		delete [] this->conjunctiveConditionList;
		delete this->conjunctiveConditionList;
	}

	// allocate space according to the number given. 
	this->disjunctiveNumber = num;
	this->conjunctiveConditionList = new ConjunctiveCondition*[this->disjunctiveNumber];
	for (int i=0; i<this->disjunctiveNumber; i++)
		this->conjunctiveConditionList[i] = NULL;
}

/**
* Set Method
* Set ConjunctiveCondition to the DisjunctiveCondition, at a given position in the list
* 
* @param index The place to put the ConjunctiveCondition
* @param cond The ConjunctiveCondition to be placed in DisjunctiveCondition.
*/
void DisjunctiveCondition::setCond(int index, ConjunctiveCondition* cond)
{
	if (index < this->disjunctiveNumber)
	{
		// if the index is within the current ConjunctiveCondition number, remove the
		// old ConjunctiveCondition and replace it with the new one
		if (this->conjunctiveConditionList[index] != NULL)
			delete this->conjunctiveConditionList[index];
		this->conjunctiveConditionList[index] = cond;
	}
	else 
	{
		// otherwise, extend the space reserved for the ConjunctiveCondition list, to be large then to hold the new
		// ConjunctiveCondition at its assigned position. 
        globalErrorInfo.insertProblem(ERR_TYPE_WARNING,__LINE__,"DisjunctiveCondition::setCond",__FILE__,
                                      "Position value is larger than reserved space, automatically increase space");
		// a new list that is large enough
		ConjunctiveCondition** templist = new ConjunctiveCondition*[index+1];

		// move the old ConjunctiveCondition to the templist
		for (int i=0; i<this->disjunctiveNumber; i++)
			templist[i] = this->conjunctiveConditionList[i];
		
		// put the new ConjunctiveCondition at its assigned place
		templist[index] = cond;

		// remove the old list
		delete [] this->conjunctiveConditionList;
		delete this->conjunctiveConditionList;

		// replace it with the new list. 
		this->conjunctiveConditionList = templist;
	}
}

/**
* Process Method
* Insert a new ConjunctiveCondition into the DisjunctiveCondition.
* The new ConjunctiveCondition is always put at the first available place in the list. 
* In case the list is currently full, extend the list to hold the new one. 
* 
* @param cond The predicate to be inserted
*/
void DisjunctiveCondition::insertCond(ConjunctiveCondition* cond)
{
	// find the first available place and put the ConjunctiveCondition there. 
	for (int i=0; i<this->disjunctiveNumber; i++)
    {
		if (this->conjunctiveConditionList[i] == NULL)
		{
			this->conjunctiveConditionList[i] = cond;
			return;
		}
    }	
	this->disjunctiveNumber++;

	// In case the list is currently full, extend the list to hold the new one. 
    globalErrorInfo.insertProblem(ERR_TYPE_WARNING,__LINE__,"DisjunctiveCondition::insertCond",__FILE__,
                                  "Reserved space full, automatically increase space");
	ConjunctiveCondition** templist = new ConjunctiveCondition*[this->disjunctiveNumber];

	for (i=0; i<this->disjunctiveNumber-1; i++)
		templist[i] = this->conjunctiveConditionList[i];
	templist[this->disjunctiveNumber-1] = cond;

	delete [] this->conjunctiveConditionList;
	delete this->conjunctiveConditionList;

	this->conjunctiveConditionList = templist;
}

/**
* Process Method
* Remove a ConjunctiveCondition from the list. 
* @param A position in the list. THe ConjunctiveCondition currently sit on that position is to be removed. 
*/
void DisjunctiveCondition::deleteCond(int index)
{
	if (index < this->disjunctiveNumber)
	{
		if (this->conjunctiveConditionList[index] != NULL)
			delete this->conjunctiveConditionList[index];
	}
	else
	{
        globalErrorInfo.insertProblem(ERR_TYPE_WARNING,__LINE__,"DisjunctiveCondition::deleteCond",__FILE__,"No valid condition to be deleted");
	}
}

/**
* Process Method
* Given two DisjunctiveCondition, compare them and find out whether they have any inclusion relationship. 
* 
* @param pred The DisjunctiveCondition to be compared with the DisjunctiveCondition represented by this class. 
* @returns code that indicate the relationship between the two DisjunctiveCondition. It can be: 
*		SELECTION_COND_FULL_MATCH	
*		SELECTION_COND_SUBSET_MATCH	
*		SELECTION_COND_SUPERSET_MATCH
*		SELECTION_COND_NOT_MATCH
*/
int DisjunctiveCondition::matchDisjunctiveCondition(DisjunctiveCondition* cond)
{
	int i,j;

	const int cond1_num = this->disjunctiveNumber;
	const int cond2_num = cond->getNumber();

	int** relationMatrix = new int*[cond1_num];
	for (i=0; i<cond1_num; i++)
		relationMatrix[i] = new int[cond2_num];

	for (i=0; i<cond1_num; i++)
    {
		for (j=0; j<cond2_num; j++)
		{
			int rel = matchCondition(this->conjunctiveConditionList[i],
									 cond->getCondAt(j));
			relationMatrix[i][j] = rel;
		}
    }
	int relation12 = SELECTION_COND_NOT_MATCH;
	int relation21 = SELECTION_COND_NOT_MATCH;
	for (i=0; i<cond1_num; i++)
	{
		bool cond1_contains_cond2 = true;
		for (j=0; j<cond2_num; j++)
		{
			if ((relationMatrix[i][j] == SELECTION_COND_SUBSET_MATCH) ||
				(relationMatrix[i][j] == SELECTION_COND_NOT_MATCH))
			{
				cond1_contains_cond2 = false;
				break;
			}
		}
		if (cond1_contains_cond2) 
		{
			relation12 = SELECTION_COND_SUPERSET_MATCH;
			break;
		}
	}

	for (j=0; j<cond2_num; j++)
	{
		bool cond2_contains_cond1 = true;
		for (i=0; i<cond1_num; i++)
		{
			if ((relationMatrix[i][j] == SELECTION_COND_SUPERSET_MATCH) ||
				(relationMatrix[i][j] == SELECTION_COND_NOT_MATCH))
			{
				cond2_contains_cond1 = false;
				break;
			}
		}
		if (cond2_contains_cond1) 
		{
			relation21 = SELECTION_COND_SUPERSET_MATCH;
			break;
		}
	}

	if ((relation12 == SELECTION_COND_SUPERSET_MATCH) &
		(relation21 == SELECTION_COND_SUPERSET_MATCH))
		return SELECTION_COND_FULL_MATCH;

	if (relation12 == SELECTION_COND_SUPERSET_MATCH)
		return SELECTION_COND_SUPERSET_MATCH;

	if (relation21 == SELECTION_COND_SUPERSET_MATCH)
		return SELECTION_COND_SUBSET_MATCH;

	return SELECTION_COND_NOT_MATCH;

}

/**
* Process Method
* Validate the DisjunctiveCondition. 
* 
* @param nodeType The type of node that the DisjunctiveCondition is to be applied on.
* @returns A boolean value that indicate whether the DisjunctiveCondition is valid, based on 
* whether each of the ConjunctiveCondition in the list is valid. 
*/
bool DisjunctiveCondition::isValid(int nodeType)
{
	bool valid = true;
	for (int i =0; i<this->disjunctiveNumber; i++)
	{
		if (!this->conjunctiveConditionList[i]->isValid(nodeType))
		{
			valid = false;
			break;
		}
	}
	return valid;
}

/**
* Process Method
* Given two DisjunctiveCondition, compare them and find out whether they have any inclusion relationship,
* allowing one or both of to be NULL. 
* 
* @param pred The DisjunctiveCondition to be compared with the DisjunctiveCondition represented by this class. 
* @returns code that indicate the relationship between the two DisjunctiveCondition. It can be: 
*		SELECTION_COND_FULL_MATCH	
*		SELECTION_COND_SUBSET_MATCH	
*		SELECTION_COND_SUPERSET_MATCH
*		SELECTION_COND_NOT_MATCH
*/
int DisjunctiveCondition::matchCondition(ConjunctiveCondition* cond1, ConjunctiveCondition* cond2)
{
	if ((cond1 == NULL) && (cond2 == NULL))
		return SELECTION_COND_FULL_MATCH;

	if ((cond1 == NULL) && (cond2 != NULL))
		return SELECTION_COND_SUPERSET_MATCH;

	if ((cond1 != NULL) && (cond2 == NULL))
		return SELECTION_COND_SUBSET_MATCH;

	if ((cond1 != NULL) && (cond2 != NULL))
		return cond1->matchConjunctiveCondition(cond2);

	return SELECTION_COND_NOT_MATCH;
}
	
/**
* Process Method
* Wrap the content of the DisjunctiveCondition into a string
* @param bufferlength The length of the result string (return value)
* @return The string that contains information bout the DisjunctiveCondition.
*/
char* DisjunctiveCondition::wrap(int* bufferlength)
{
	char* buffer;
	int size = 0;
	char** conjbuffer = new char*[this->disjunctiveNumber];
	int* conjbufferlength = new int[this->disjunctiveNumber];

	for (int i=0; i<this->disjunctiveNumber; i++)
	{
		conjbuffer[i] = this->conjunctiveConditionList[i]->wrap(&(conjbufferlength[i]));
		size = size + sizeof(int) + conjbufferlength[i];
	}
	size = size + sizeof(int);

	buffer = new char[size];

	int cursor = 0;
	memcpy(buffer, &(this->disjunctiveNumber), sizeof(int));
	cursor += sizeof(int);

	for (i=0; i<this->disjunctiveNumber; i++)
	{
		memcpy(buffer+cursor, &(conjbufferlength[i]), sizeof(int));
		cursor += sizeof(int);
		memcpy(buffer+cursor, conjbuffer[i], conjbufferlength[i]);
		cursor += conjbufferlength[i];
		delete conjbuffer[i];
	}

	delete conjbuffer;
	delete conjbufferlength;

	*bufferlength = size;
	
	return buffer;
}

/**
* Debug Methods
* Print the DisjunctiveCondition.
*/
void DisjunctiveCondition::printDisjunctiveCondition()
{
	for (int i=0; i<this->disjunctiveNumber; i++)
	{
		if (i!=0) cout << "OR";
		this->conjunctiveConditionList[i]->printConjunctiveCondition();
	}
}
