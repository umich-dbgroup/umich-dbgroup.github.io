/*
COPYRIGHT  (c) 2000-2004 
THE REGENTS OF THE UNIVERSITY OF MICHIGAN
ALL RIGHTS RESERVED

PERMISSION IS GRANTED TO USE, COPY, CREATE DERIVATIVE WORKS AND
REDISTRIBUTE THIS SOFTWARE AND SUCH DERIVATIVE WORKS FOR NONCOMMERCIAL
EDUCATION AND RESEARCH PURPOSES, SO LONG AS NO FEE IS CHARGED, AND SO LONG
AS THE COPYRIGHT NOTICE ABOVE, THIS GRANT OF PERMISSION, AND THE
DISCLAIMER BELOW APPEAR IN ALL COPIES MADE; AND SO LONG AS THE NAME OF THE
UNIVERSITY OF MICHIGAN IS NOT USED IN ANY ADVERTISING OR PUBLICITY
PERTAINING TO THE USE OR DISTRIBUTION OF THIS SOFTWARE WITHOUT SPECIFIC,
WRITTEN PRIOR AUTHORIZATION.

THIS SOFTWARE IS PROVIDED AS IS, WITHOUT REPRESENTATION FROM THE
UNIVERSITY OF MICHIGAN AS TO ITS FITNESS FOR ANY PURPOSE, AND WITHOUT
WARRANTY BY THE UNIVERSITY OF MICHIGAN OF ANY KIND, EITHER EXPRESS OR
IMPLIED, INCLUDING WITHOUT LIMITATION THE IMPLIED WARRANTIES OF
MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE. THE REGENTS OF THE
UNIVERSITY OF MICHIGAN SHALL NOT BE LIABLE FOR ANY DAMAGES, INCLUDING
SPECIAL, INDIRECT, INCIDENTAL, OR CONSEQUENTIAL DAMAGES, WITH RESPECT TO
ANY CLAIM ARISING OUT OF OR IN CONNECTION WITH THE USE OF THE SOFTWARE,
EVEN IF IT HAS BEEN OR IS HEREAFTER ADVISED OF THE POSSIBILITY OF SUCH
DAMAGES.
*/

/**
 * @author Yuqing (Melanie) Wu
 */

#ifndef __DisjunctiveCondition_H
#define __DisjunctiveCondition_H

#include "ConjunctiveCondition.h"

/**
* class DisjunctiveCondition
* 
* This class represent seleciton condition that is a set of ConjunctiveCondition with OR relation between them. 
* This class provide functions for store, access the information of a DisjunctiveCondition, as well as functions 
* that validate, wrap/unwrap the condition to a string, and the function that compare one condition to another
* trying to find the containment relationship between them. 
*
* @see SelectionCondition
* @see ConjunctiveCondition
*/
class DisjunctiveCondition
{
public:
	/** 
	* Constructor
	* Construct a blank instance of the condition
	*/	
	DisjunctiveCondition();
	
	/** 
	* Constructor
	* Construct a blank instance of the condition, given the number of ConjunctiveCondition in the condition. 
	*
	* @param num The number of ConjunctiveCondition that will be in this DisjunctiveCondition
	*/	
	DisjunctiveCondition(int num);
	
	/**
	* Constructor
	* Create an instance of the DisjunctiveCondition, using the information wrapped in a string
	* @param buffer The string that contains the information about the condition. 
	*/
	DisjunctiveCondition(char* buffer);

	/**
	* Constructor
	* Create an instance of the DisjunctiveCondition, by copying info from another instance.
	* @param cond The disjunctive condition to be copied. 
	*/
	DisjunctiveCondition(DisjunctiveCondition* cond);

	/**
	* Destructor
	* Release space taken by the ConjunctiveCondition
	*/
	~DisjunctiveCondition();
		
	/**
	* Access Method
	* Get the information about the number of ConjunctiveCondition
	*/
	int getNumber();

	/**
	* Access Method
	* Get all the ConjunctiveCondition in the DisjunctiveCondition
	* @returns The list of ConjunctiveCondition in the DisjunctiveCondition.
	*/
	ConjunctiveCondition** getCondList();

	/**
	* Access Method
	* Get the ConjunctiveCondition at a certain position
	* @param index Indicate which ConjunctiveCondition to get
	* @returns THe index'th ConjunctiveCondition in the DisjunctiveCondition.
	*/
	ConjunctiveCondition* getCondAt(int index);

	/**
	* Set Method
	* Set the number of ConjunctiveCondition in the DisjunctiveCondition
	* Changing the number of ConjunctiveCondition in the DisjunctiveCondition will result in the deletion of all ConjunctiveCondition
	* currently in the DisjunctiveCondition and reallocation space according to  the number given. 
	* 
	* @param num The number of ConjunctiveCondition to be in the DisjunctiveCondition
	*/
	void setNumber(int num);

	/**
	* Set Method
	* Set ConjunctiveCondition to the DisjunctiveCondition, at a given position in the list
	* 
	* @param index The place to put the ConjunctiveCondition
	* @param cond The ConjunctiveCondition to be placed in DisjunctiveCondition.
	*/
	void setCond(int index, ConjunctiveCondition* cond);

	/**
	* Process Method
	* Insert a new ConjunctiveCondition into the DisjunctiveCondition.
	* The new ConjunctiveCondition is always put at the first available place in the list. 
	* In case the list is currently full, extend the list to hold the new one. 
	* 
	* @param cond The predicate to be inserted
	*/
	void insertCond(ConjunctiveCondition* cond);

	/**
	* Process Method
	* Remove a ConjunctiveCondition from the list. 
	* @param A position in the list. THe ConjunctiveCondition currently sit on that position is to be removed. 
	*/
	void deleteCond(int index);

	/**
	* Process Method
	* Validate the DisjunctiveCondition. 
	* 
	* @param nodeType The type of node that the DisjunctiveCondition is to be applied on.
	* @returns A boolean value that indicate whether the DisjunctiveCondition is valid, based on 
	* whether each of the ConjunctiveCondition in the list is valid. 
	*/	
	bool isValid(int nodeType);

	/**
	* Process Method
	* Given two DisjunctiveCondition, compare them and find out whether they have any inclusion relationship. 
	* 
	* @param pred The DisjunctiveCondition to be compared with the DisjunctiveCondition represented by this class. 
	* @returns code that indicate the relationship between the two DisjunctiveCondition. It can be: 
	*		SELECTION_COND_FULL_MATCH	
	*		SELECTION_COND_SUBSET_MATCH	
	*		SELECTION_COND_SUPERSET_MATCH
	*		SELECTION_COND_NOT_MATCH
	*/
	int matchDisjunctiveCondition(DisjunctiveCondition* cond);
		
	/**
	* Process Method
	* Wrap the content of the DisjunctiveCondition into a string
	* @param bufferlength The length of the result string (return value)
	* @return The string that contains information bout the DisjunctiveCondition.
	*/
	char* wrap(int* bufferlength);

	/**
	* Debug Methods
	* Print the DisjunctiveCondition.
	*/
	void printDisjunctiveCondition();

private:
	/**
	* Number of conjunctive expressions in the disjunctive expression
	*/
	int disjunctiveNumber;

	/**
	* The list of conjunctive expressions
	*/
	ConjunctiveCondition** conjunctiveConditionList;

	/**
	* Process Method
	* Given two DisjunctiveCondition, compare them and find out whether they have any inclusion relationship,
	* allowing one or both of to be NULL. 
	* 
	* @param pred The DisjunctiveCondition to be compared with the DisjunctiveCondition represented by this class. 
	* @returns code that indicate the relationship between the two DisjunctiveCondition. It can be: 
	*		SELECTION_COND_FULL_MATCH	
	*		SELECTION_COND_SUBSET_MATCH	
	*		SELECTION_COND_SUPERSET_MATCH
	*		SELECTION_COND_NOT_MATCH
	*/	
	int matchCondition(ConjunctiveCondition* cond1, ConjunctiveCondition* cond2);

} ;

#endif
