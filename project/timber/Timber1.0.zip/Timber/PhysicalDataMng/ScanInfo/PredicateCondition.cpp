/*
COPYRIGHT  (c) 2000-2004 
THE REGENTS OF THE UNIVERSITY OF MICHIGAN
ALL RIGHTS RESERVED

PERMISSION IS GRANTED TO USE, COPY, CREATE DERIVATIVE WORKS AND
REDISTRIBUTE THIS SOFTWARE AND SUCH DERIVATIVE WORKS FOR NONCOMMERCIAL
EDUCATION AND RESEARCH PURPOSES, SO LONG AS NO FEE IS CHARGED, AND SO LONG
AS THE COPYRIGHT NOTICE ABOVE, THIS GRANT OF PERMISSION, AND THE
DISCLAIMER BELOW APPEAR IN ALL COPIES MADE; AND SO LONG AS THE NAME OF THE
UNIVERSITY OF MICHIGAN IS NOT USED IN ANY ADVERTISING OR PUBLICITY
PERTAINING TO THE USE OR DISTRIBUTION OF THIS SOFTWARE WITHOUT SPECIFIC,
WRITTEN PRIOR AUTHORIZATION.

THIS SOFTWARE IS PROVIDED AS IS, WITHOUT REPRESENTATION FROM THE
UNIVERSITY OF MICHIGAN AS TO ITS FITNESS FOR ANY PURPOSE, AND WITHOUT
WARRANTY BY THE UNIVERSITY OF MICHIGAN OF ANY KIND, EITHER EXPRESS OR
IMPLIED, INCLUDING WITHOUT LIMITATION THE IMPLIED WARRANTIES OF
MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE. THE REGENTS OF THE
UNIVERSITY OF MICHIGAN SHALL NOT BE LIABLE FOR ANY DAMAGES, INCLUDING
SPECIAL, INDIRECT, INCIDENTAL, OR CONSEQUENTIAL DAMAGES, WITH RESPECT TO
ANY CLAIM ARISING OUT OF OR IN CONNECTION WITH THE USE OF THE SOFTWARE,
EVEN IF IT HAS BEEN OR IS HEREAFTER ADVISED OF THE POSSIBILITY OF SUCH
DAMAGES.
*/

/**
 * @author Yuqing (Melanie) Wu
 */

#include "PredicateCondition.h"
#include "../../Utilities/ErrorInfoClass.h"
extern ErrorInfoClass globalErrorInfo;

/**
* PredicateCondition
* 
* A Predicate, which contains a left value, a right value and a comparason operator, is the smallest unit for
* a selection condition. 
* 
* This class provide the storage, access, validation, wrapping/unwrapping of a predicate. 
* 
* @see SelectionCondition
*/

/**
* Constructor
* For a blank predicate
*/
PredicateCondition::PredicateCondition()
{
	leftValue = NULL;
	rightValue = NULL;
}

/**
* Constructor
* Initialize a predicate with the given left value, operator and right value
*/
PredicateCondition::PredicateCondition(int leftval, int op, Value* rightval)
{
	this->leftValue = leftval;
	this->predicateOperator = op;
	this->rightValue = rightval;
}

/**
* Constructor
* Create an instance of the PredicateCondition, using the information wrapped in a string
* @param buffer The string that contains the information about the predicate. 
*/
PredicateCondition::PredicateCondition(char* buffer)
{
	memcpy(&(this->leftValue), buffer, sizeof(int));
	memcpy(&(this->predicateOperator), buffer+sizeof(int), sizeof(int));
	this->rightValue = new Value(buffer+sizeof(int)*2);
}

/**
* Constructor
* Create an instance of the PredicateCondition, by copying info from another instance.
* @param predicate The predicate condition to be copied. 
*/
PredicateCondition::PredicateCondition(PredicateCondition* predicate)
{
	//this->leftValue = predicate->getLeftValue();
	//this->predicateOperator = predicate->getOperator();
	//this->rightValue = new Value(predicate->getRightValue());
    int lVal = predicate->getLeftValue();
    switch (lVal)
	{
	case SCAN_LEFTVALUE_VALUE:
	case SCAN_LEFTVALUE_LENGTH:
	case SCAN_LEFTVALUE_CHILDNUMBER:
	case SCAN_LEFTVALUE_ATTRIBUTENUMBER:
	case SCAN_LEFTVALUE_XMLFILENAME:
	case SCAN_LEFTVALUE_DTDFILENAME:
	case SCAN_LEFTVALUE_NODETAG:
	case SCAN_LEFTVALUE_HASCHILD:
	case SCAN_LEFTVALUE_HASATTRIBUTE:
	case SCAN_LEFTVALUE_ELEMENTCONTENT:
		this->leftValue = lVal;
		break;
	default:
#pragma warning(disable:4312 4311) // disable the warning for casting int to char * for the leftValue
		{
			char* lValStr = (char*) lVal;
	        char* newLValStr = new char[(int) strlen(lValStr)+1];
			strcpy(newLValStr, lValStr);
			this->leftValue = (int) newLValStr;
		}
#pragma warning(default:4312 4311)
		break;
	}

	this->predicateOperator = predicate->getOperator();
	this->rightValue = new Value(predicate->getRightValue());
}

/**
* Destructor
* Release space taken by the right value.
*/
PredicateCondition::~PredicateCondition()
{
	delete rightValue;
    // MEM INIT: free leftValue when it is a string	
    switch (leftValue)
	{
	case SCAN_LEFTVALUE_VALUE:
	case SCAN_LEFTVALUE_LENGTH:		
	case SCAN_LEFTVALUE_CHILDNUMBER:	
	case SCAN_LEFTVALUE_ATTRIBUTENUMBER:
	case SCAN_LEFTVALUE_XMLFILENAME:			
	case SCAN_LEFTVALUE_DTDFILENAME:		
	case SCAN_LEFTVALUE_NODETAG:		
	case SCAN_LEFTVALUE_HASCHILD:	
	case SCAN_LEFTVALUE_HASATTRIBUTE:	
	case SCAN_LEFTVALUE_ELEMENTCONTENT:
		break;
	default:
#pragma warning(disable:4312) // disable the warning for casting int to char * for the leftValue
		char *tmp = (char*) leftValue;
        delete [] tmp;
#pragma warning(default:4312)
		break;
	}
}

/**
* Access Method
* Get the information of left value, operator and right value
*/
int PredicateCondition::getLeftValue()
{
	return leftValue;
}

int PredicateCondition::getOperator()
{
	return predicateOperator;
}

Value* PredicateCondition::getRightValue()
{
	return rightValue;
}
	
/**
* Set Methods
* Set the values for left value, operator and right value
*/
void PredicateCondition::setLeftValue(int leftval)
{
	this->leftValue = leftval;
}

void PredicateCondition::setOperator(int op)
{
	this->predicateOperator = op;
}

void PredicateCondition::setRightValue(Value* rightval)
{
	if (rightValue != NULL)
		delete rightValue;
	this->rightValue = rightval;
}

/**
* Process Method
* Validate the predicate. 
* 
* @param nodeType The type of node that predicate is to be applied on.
* @returns A boolean value that indicate whether the predicate is valid, based on whether the
*		node type, the left value, the operator and the right values can go with each other.
*/
bool PredicateCondition::isValid(int nodeType)
{
	bool valid = true;

	// first, check whether the left value matches with the node type
	switch (nodeType)
	{
	case SCAN_ALLNODES:
		valid = true;
		break;

	case DOCUMENT_NODE:
		switch (this->leftValue)
		{
		case SCAN_LEFTVALUE_XMLFILENAME:
		case SCAN_LEFTVALUE_DTDFILENAME:
		case SCAN_LEFTVALUE_CHILDNUMBER:
		case SCAN_LEFTVALUE_HASCHILD:
			valid = true;
			break;
			
		case SCAN_LEFTVALUE_HASATTRIBUTE:
		case SCAN_LEFTVALUE_ELEMENTCONTENT:
		case SCAN_LEFTVALUE_VALUE:
		case SCAN_LEFTVALUE_LENGTH:
		case SCAN_LEFTVALUE_NODETAG:
		case SCAN_LEFTVALUE_ATTRIBUTENUMBER:
		default:
            globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"PredicateCondition::isValid",__FILE__,"Invalid left value type for DOCUMENT");
			valid = false;
			break;
		}
		break;

	case ELEMENT_NODE:
		switch (this->leftValue)
		{
		case SCAN_LEFTVALUE_NODETAG:
		case SCAN_LEFTVALUE_CHILDNUMBER:
		case SCAN_LEFTVALUE_ATTRIBUTENUMBER:
		case SCAN_LEFTVALUE_HASCHILD:
		case SCAN_LEFTVALUE_HASATTRIBUTE:
		case SCAN_LEFTVALUE_ELEMENTCONTENT:
			valid = true;
			break;

		case SCAN_LEFTVALUE_VALUE:
		case SCAN_LEFTVALUE_LENGTH:
		case SCAN_LEFTVALUE_XMLFILENAME:
		case SCAN_LEFTVALUE_DTDFILENAME:
		default: 
            globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"PredicateCondition::isValid",__FILE__,"Invalid left value type for ELEMENT");
			valid = false;
			break;
		}
		break;

	case ATTRIBUTE_NODE:
		switch (this->leftValue)
		{
		case SCAN_LEFTVALUE_ATTRIBUTENUMBER:
		case SCAN_LEFTVALUE_HASATTRIBUTE:
			valid = true;
			break;
			
		case SCAN_LEFTVALUE_VALUE:
		case SCAN_LEFTVALUE_LENGTH:
		case SCAN_LEFTVALUE_XMLFILENAME:
		case SCAN_LEFTVALUE_DTDFILENAME:
		case SCAN_LEFTVALUE_NODETAG:
		case SCAN_LEFTVALUE_CHILDNUMBER:
		case SCAN_LEFTVALUE_HASCHILD:
		case SCAN_LEFTVALUE_ELEMENTCONTENT:
            globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"PredicateCondition::isValid",__FILE__,"Invalid left value type for ATTRIBUTE");
			valid = false;
			break;
		}
		break;

	case TEXT_NODE:
	case COMMENT_NODE:
	case CHAR_NODE:
		switch (this->leftValue)
		{
		case SCAN_LEFTVALUE_VALUE:
		case SCAN_LEFTVALUE_LENGTH:
			valid = true;
			break;

		case SCAN_LEFTVALUE_NODETAG:
		case SCAN_LEFTVALUE_CHILDNUMBER:
		case SCAN_LEFTVALUE_ATTRIBUTENUMBER:
		case SCAN_LEFTVALUE_HASCHILD:
		case SCAN_LEFTVALUE_HASATTRIBUTE:
		case SCAN_LEFTVALUE_ELEMENTCONTENT:
		case SCAN_LEFTVALUE_XMLFILENAME:
		case SCAN_LEFTVALUE_DTDFILENAME:
		default:			
            globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"PredicateCondition::isValid",__FILE__,"Invalid left value type for TEXT");
			valid = false;
			break;			
		}
		break;

	default:
        globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"PredicateCondition::isValid",__FILE__,"Invalid nodetype");
		valid = false;
		break;
	}

	// in case that the nodeType and the left value of the predicate is OK,
	// check whether the left value goes with the operator and the right value
	
	if (!valid) return valid;
	
	if ((this->predicateOperator >= SCAN_OP_LT) && (this->predicateOperator <= SCAN_OP_STARTWITH))
	{
		switch (this->leftValue)
		{
		case SCAN_LEFTVALUE_VALUE:
		case SCAN_LEFTVALUE_HASCHILD:
			valid = true; 
			break;

		case SCAN_LEFTVALUE_LENGTH:
		case SCAN_LEFTVALUE_CHILDNUMBER:
		case SCAN_LEFTVALUE_ATTRIBUTENUMBER:
			switch (this->predicateOperator)
			{
			case SCAN_OP_LT:
			case SCAN_OP_LE:
			case SCAN_OP_GT:
			case SCAN_OP_GE:
			case SCAN_OP_EQ:
			case SCAN_OP_NE:
				valid = true;
				break;
			case SCAN_OP_CONTAINS:
			case SCAN_OP_CONTAINEDBY:
			case SCAN_OP_STARTWITH:
			default:
                globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"PredicateCondition::isValid",__FILE__,"No string comparison on numeric type");
				valid = false;
				break;
			}
			break;

		case SCAN_LEFTVALUE_NODETAG:
		case SCAN_LEFTVALUE_HASATTRIBUTE:
		case SCAN_LEFTVALUE_ELEMENTCONTENT:
		case SCAN_LEFTVALUE_XMLFILENAME:
		case SCAN_LEFTVALUE_DTDFILENAME:						
			switch (this->predicateOperator)
			{
			case SCAN_OP_LT:
			case SCAN_OP_LE:
			case SCAN_OP_GT:
			case SCAN_OP_GE:
                globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"PredicateCondition::isValid",__FILE__,"No numeric comparison on string type");
				valid = false;
				break;
				
			case SCAN_OP_EQ:
			case SCAN_OP_NE:
			case SCAN_OP_CONTAINS:
			case SCAN_OP_CONTAINEDBY:
			case SCAN_OP_STARTWITH:
			default:
				valid = true;
				break;
			}
			break;			
		}

	}
	else valid = false;

	// if the above is OK, check whether the operator works with the right value
	if (!valid) return valid;

	switch (this->rightValue->getValueType())
	{
	case INT_VALUE:
	case REAL_VALUE:
	case DATE_VALUE:
		switch (this->predicateOperator)
		{
		case SCAN_OP_LT:
		case SCAN_OP_LE:
		case SCAN_OP_GT:
		case SCAN_OP_GE:
		case SCAN_OP_EQ:
		case SCAN_OP_NE:
			valid = true;
			break;
		case SCAN_OP_CONTAINS:
		case SCAN_OP_CONTAINEDBY:
		case SCAN_OP_STARTWITH:
		default:
            globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"PredicateCondition::isValid",__FILE__,"No string comparison on numeric type");
			valid = false;
			break;
		}
		break;

	case STRING_VALUE:
		switch (this->predicateOperator)
		{
		case SCAN_OP_LT:
		case SCAN_OP_LE:
		case SCAN_OP_GT:
		case SCAN_OP_GE:
            globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"PredicateCondition::isValid",__FILE__,"No numeric comparison on string type");
			valid = false;
			break;
			
		case SCAN_OP_EQ:
		case SCAN_OP_NE:
		case SCAN_OP_CONTAINS:
		case SCAN_OP_CONTAINEDBY:
		case SCAN_OP_STARTWITH:
		default:
			valid = true;
			break;
		}
		break;		

	default: 
        globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"PredicateCondition::isValid",__FILE__,"Invalid data type for right value");
		valid = false;
		break;
	}

	return valid;

}

/**
* Process Method
* Given two predicate, compare them and find out whether they have any inclusion relationship. 
* 
* @param pred The predicate to be compared with the predicate represented by this class. 
* @returns code that indicate the relationship between the predicates. It can be: 
*		SELECTION_COND_FULL_MATCH	
*		SELECTION_COND_SUBSET_MATCH	
*		SELECTION_COND_SUPERSET_MATCH
*		SELECTION_COND_NOT_MATCH
*/
int PredicateCondition::matchPredicateCondition(PredicateCondition* pred)
{
	// if the predicate applies on different attributes, there is no
	// way to compare them. 
	if (this->leftValue != pred->getLeftValue())
		return SELECTION_COND_NOT_MATCH;
	
	Value* val1 = this->rightValue;
	Value* val2 = pred->getRightValue();

	// if the right value are of different type, the two predicates
	// can not be matched.
	if (val1->getValueType() != val2->getValueType())
		return SELECTION_COND_NOT_MATCH;
	
	int op1 = this->predicateOperator;
	int op2 = pred->getOperator();

	// when left value and right value are comparable, compare the scope
	// of the two predicates. 


	// find out whether the left value is a numericValue or a string value
	bool numericValue = false;
	switch (this->leftValue)
	{
	case SCAN_LEFTVALUE_VALUE:
		if (this->rightValue->getValueType() == STRING_VALUE) numericValue = false;
		else numericValue = true;
		break;

	case SCAN_LEFTVALUE_LENGTH:
	case SCAN_LEFTVALUE_CHILDNUMBER:
	case SCAN_LEFTVALUE_ATTRIBUTENUMBER:
		numericValue = true;
		break;
	
	case SCAN_LEFTVALUE_XMLFILENAME:
	case SCAN_LEFTVALUE_DTDFILENAME:
	case SCAN_LEFTVALUE_NODETAG:
	case SCAN_LEFTVALUE_HASCHILD:
	case SCAN_LEFTVALUE_HASATTRIBUTE:
		numericValue = false;
		break;
	}	
		
	// when the left value is numeric value, compare the right value of the two predicates
	if (numericValue)
	{
		switch (op1)
		{
		case SCAN_OP_GT:
			switch (op2)
			{
			case SCAN_OP_GT:
				if (val1->equal(val2))
					return SELECTION_COND_FULL_MATCH;
				if (val1->greaterThan(val2))
					return SELECTION_COND_SUBSET_MATCH;
				else return SELECTION_COND_SUPERSET_MATCH;
				break;

			case SCAN_OP_GE:
				if (val1->equal(val2))
					return SELECTION_COND_SUBSET_MATCH;
				if (val1->greaterThan(val2))
					return SELECTION_COND_SUBSET_MATCH;
				else return SELECTION_COND_SUPERSET_MATCH;
				break;

			case SCAN_OP_LT:
				return 	SELECTION_COND_NOT_MATCH;
				break;

			case SCAN_OP_LE:
				return 	SELECTION_COND_NOT_MATCH;
				break;

			case SCAN_OP_EQ:
				if (val1->greaterEqual(val2))
					return SELECTION_COND_NOT_MATCH;
				else return SELECTION_COND_SUPERSET_MATCH;
				break;

			case SCAN_OP_NE:
				if (val1->greaterEqual(val2))
					return SELECTION_COND_SUBSET_MATCH;
				return SELECTION_COND_NOT_MATCH;
				break;
			}
			break;

		case SCAN_OP_GE:
			switch (op2)
			{
			case SCAN_OP_GT:
				if (val1->equal(val2))
					return SELECTION_COND_SUPERSET_MATCH;
				if (val1->greaterThan(val2))
					return SELECTION_COND_SUBSET_MATCH;
				else return SELECTION_COND_SUPERSET_MATCH;
				break;

			case SCAN_OP_GE:
				if (val1->equal(val2))
					return SELECTION_COND_FULL_MATCH;
				if (val1->greaterThan(val2))
					return SELECTION_COND_SUBSET_MATCH;
				else return SELECTION_COND_SUPERSET_MATCH;
				break;

			case SCAN_OP_LT:
				return 	SELECTION_COND_NOT_MATCH;
				break;

			case SCAN_OP_LE:
				return 	SELECTION_COND_NOT_MATCH;
				break;

			case SCAN_OP_EQ:
				if (val1->equal(val2))
					return SELECTION_COND_SUPERSET_MATCH;
				if (val1->greaterThan(val2))
					return SELECTION_COND_NOT_MATCH;
				else return SELECTION_COND_SUPERSET_MATCH;
				break;

			case SCAN_OP_NE:
				if (val1->greaterThan(val2))
					return SELECTION_COND_SUBSET_MATCH;
				return SELECTION_COND_NOT_MATCH;
				break;
			}
			break;

		case SCAN_OP_LT:
			switch (op2)
			{
			case SCAN_OP_GT:
				return SELECTION_COND_NOT_MATCH;
				break;

			case SCAN_OP_GE:
				return SELECTION_COND_NOT_MATCH;
				break;

			case SCAN_OP_LT:
				if (val1->equal(val2))
					return SELECTION_COND_FULL_MATCH;
				if (val1->greaterThan(val2))
					return SELECTION_COND_SUPERSET_MATCH;
				else return SELECTION_COND_SUBSET_MATCH;
				break;

			case SCAN_OP_LE:
				if (val1->equal(val2))
					return SELECTION_COND_SUBSET_MATCH;
				if (val1->greaterThan(val2))
					return SELECTION_COND_SUPERSET_MATCH;
				else return SELECTION_COND_SUBSET_MATCH;
				break;

			case SCAN_OP_EQ:
				if (val1->greaterThan(val2))
					return SELECTION_COND_SUPERSET_MATCH;
				else return SELECTION_COND_NOT_MATCH;
				break;

				break;

			case SCAN_OP_NE:
				if (val1->lessEqual(val2))
					return SELECTION_COND_SUBSET_MATCH;
				return SELECTION_COND_NOT_MATCH;
				break;
			}
			break;

		case SCAN_OP_LE:
			switch (op2)
			{
			case SCAN_OP_GT:
				return SELECTION_COND_NOT_MATCH;
				break;
			case SCAN_OP_GE:
				return SELECTION_COND_NOT_MATCH;
				break;
			case SCAN_OP_LT:
				if (val1->equal(val2))
					return SELECTION_COND_SUPERSET_MATCH;
				if (val1->greaterThan(val2))
					return SELECTION_COND_SUPERSET_MATCH;
				else return SELECTION_COND_SUBSET_MATCH;
				break;

			case SCAN_OP_LE:
				if (val1->equal(val2))
					return SELECTION_COND_FULL_MATCH;
				if (val1->greaterThan(val2))
					return SELECTION_COND_SUPERSET_MATCH;
				else return SELECTION_COND_SUBSET_MATCH;
				break;

			case SCAN_OP_EQ:
				if (val1->greaterEqual(val2))
					return SELECTION_COND_SUPERSET_MATCH;
				else return SELECTION_COND_NOT_MATCH;
				break;

			case SCAN_OP_NE:
				if (val1->lessThan(val2))
					return SELECTION_COND_SUBSET_MATCH;
				return SELECTION_COND_NOT_MATCH;
				break;
			}
			break;

		case SCAN_OP_EQ:
			switch (op2)
			{
			case SCAN_OP_GT:
				if (val1->greaterThan(val2))
					return SELECTION_COND_SUBSET_MATCH;
				else return SELECTION_COND_NOT_MATCH;
				break;

			case SCAN_OP_GE:
				if (val1->greaterEqual(val2))
					return SELECTION_COND_SUBSET_MATCH;
				else return SELECTION_COND_NOT_MATCH;
				break;

			case SCAN_OP_LT:
				if (val1->lessThan(val2))
					return SELECTION_COND_SUBSET_MATCH;
				else return SELECTION_COND_NOT_MATCH;
				break;

			case SCAN_OP_LE:
				if (val1->lessEqual(val2))
					return SELECTION_COND_SUBSET_MATCH;
				else return SELECTION_COND_NOT_MATCH;
				break;

			case SCAN_OP_EQ:
				if (val1->equal(val2))
					return SELECTION_COND_FULL_MATCH;
				else return SELECTION_COND_NOT_MATCH;
				break;

			case SCAN_OP_NE:
				if (val1->equal(val2))
					return SELECTION_COND_NOT_MATCH;
				else return SELECTION_COND_SUBSET_MATCH;
				break;	
			}
			break;

		case SCAN_OP_NE:
			switch (op2)
			{
			case SCAN_OP_GT:
				if (val1->lessEqual(val2))
					return SELECTION_COND_SUPERSET_MATCH;
				else return SELECTION_COND_NOT_MATCH;
				break;

			case SCAN_OP_GE:
				if (val1->lessThan(val2))
					return SELECTION_COND_SUPERSET_MATCH;
				else return SELECTION_COND_NOT_MATCH;
				break;

			case SCAN_OP_LT:
				if (val1->greaterEqual(val2))
					return SELECTION_COND_SUPERSET_MATCH;
				else return SELECTION_COND_NOT_MATCH;
				break;

			case SCAN_OP_LE:
				if (val1->greaterThan(val2))
					return SELECTION_COND_SUPERSET_MATCH;
				return SELECTION_COND_NOT_MATCH;
				break;

			case SCAN_OP_EQ:
				if (val1->equal(val2))
					return SELECTION_COND_NOT_MATCH;
				else return SELECTION_COND_SUPERSET_MATCH;

			case SCAN_OP_NE:
				if (val1->equal(val2))
					return SELECTION_COND_FULL_MATCH;
				else return SELECTION_COND_NOT_MATCH;

			}
			break;

		}
	}

	else
	{
		// this is for string values
		switch (op1)
		{
		case SCAN_OP_EQ:
			switch (op2)
			{
			case SCAN_OP_EQ:
				if (val1->equal(val2))
					return SELECTION_COND_FULL_MATCH;
				else return SELECTION_COND_NOT_MATCH;
				break;

			case SCAN_OP_NE:
				if (val1->equal(val2))
					return SELECTION_COND_NOT_MATCH;
				else return SELECTION_COND_SUBSET_MATCH;
				break;

			case SCAN_OP_CONTAINS:
				if (val1->equal(val2))
					return SELECTION_COND_SUBSET_MATCH;
				if (val1->contains(val2))
					return SELECTION_COND_SUBSET_MATCH;
				else return SELECTION_COND_NOT_MATCH;
				break;

			case SCAN_OP_CONTAINEDBY:
				if (val1->equal(val2))
					return SELECTION_COND_SUBSET_MATCH;
				if (val1->containedBy(val2))
					return SELECTION_COND_SUBSET_MATCH;
				else return SELECTION_COND_NOT_MATCH;
				break;

			case SCAN_OP_STARTWITH:
				if (val1->equal(val2))
					return SELECTION_COND_SUBSET_MATCH;
				if (val1->startWith(val2))
					return SELECTION_COND_SUBSET_MATCH;
				else return SELECTION_COND_NOT_MATCH;
				break;

			}
			break;

		case SCAN_OP_NE:
			switch (op2)
			{
			case SCAN_OP_EQ:
				if (val1->equal(val2))
					return SELECTION_COND_NOT_MATCH;
				else return SELECTION_COND_SUPERSET_MATCH;
				
			case SCAN_OP_NE:
				if (val1->equal(val2))
					return SELECTION_COND_FULL_MATCH;
				else return SELECTION_COND_NOT_MATCH;
				break;

			case SCAN_OP_CONTAINS:
				if (val1->equal(val2))
					return SELECTION_COND_NOT_MATCH;
				if (val1->contains(val2))
					return SELECTION_COND_NOT_MATCH;
				else return SELECTION_COND_SUPERSET_MATCH;
				break;

			case SCAN_OP_CONTAINEDBY:
				if (val1->equal(val2))
					return SELECTION_COND_NOT_MATCH;
				if (val1->containedBy(val2))
					return SELECTION_COND_NOT_MATCH;
				else return SELECTION_COND_SUPERSET_MATCH;
				break;

			case SCAN_OP_STARTWITH:
				if (val1->equal(val2))
					return SELECTION_COND_NOT_MATCH;
				if (val1->startWith(val2))
					return SELECTION_COND_NOT_MATCH;
				else return SELECTION_COND_SUPERSET_MATCH;
				break;
			}
			break;

		case SCAN_OP_CONTAINS:
			switch (op2)
			{
			case SCAN_OP_EQ:
				if (val1->equal(val2))
					return SELECTION_COND_SUPERSET_MATCH;
				if (val1->containedBy(val2))
					return SELECTION_COND_SUPERSET_MATCH;
				else return SELECTION_COND_NOT_MATCH;
				break;

			case SCAN_OP_NE:
				if (val1->equal(val2))
					return SELECTION_COND_NOT_MATCH;
				if (val1->containedBy(val2))
					return SELECTION_COND_NOT_MATCH;
				else return SELECTION_COND_SUBSET_MATCH;
				break;

			case SCAN_OP_CONTAINS:
				if (val1->equal(val2))
					return SELECTION_COND_FULL_MATCH;
				if (val1->contains(val2))
					return SELECTION_COND_SUBSET_MATCH;
				if (val1->containedBy(val2))
					return SELECTION_COND_SUPERSET_MATCH;
				else return SELECTION_COND_NOT_MATCH;
				break;

			case SCAN_OP_CONTAINEDBY:
				return SELECTION_COND_NOT_MATCH;
				break;

			case SCAN_OP_STARTWITH:
				if (val1->equal(val2))
					return SELECTION_COND_SUPERSET_MATCH;
				if (val1->containedBy(val2))
					return SELECTION_COND_SUPERSET_MATCH;
				else return SELECTION_COND_NOT_MATCH;
				break;
			}
			break;

		case SCAN_OP_CONTAINEDBY:
			switch (op2)
			{
			case SCAN_OP_EQ:
				if (val1->equal(val2))
					return SELECTION_COND_SUPERSET_MATCH;
				if (val1->contains(val2))
					return SELECTION_COND_SUPERSET_MATCH;
				else return SELECTION_COND_NOT_MATCH;
				break;

			case SCAN_OP_NE:
				if (val1->equal(val2))
					return SELECTION_COND_NOT_MATCH;
				if (val1->contains(val2))
					return SELECTION_COND_NOT_MATCH;
				else return SELECTION_COND_SUBSET_MATCH;
				break;

			case SCAN_OP_CONTAINS:
				return SELECTION_COND_NOT_MATCH;
				break;

			case SCAN_OP_CONTAINEDBY:
				if (val1->equal(val2))
					return SELECTION_COND_FULL_MATCH;
				if (val1->contains(val2))
					return SELECTION_COND_SUPERSET_MATCH;
				if (val1->containedBy(val2))
					return SELECTION_COND_SUBSET_MATCH;
				else return SELECTION_COND_NOT_MATCH;
				break;

			case SCAN_OP_STARTWITH:
				return SELECTION_COND_NOT_MATCH;
				break;
			}
			break;


		case SCAN_OP_STARTWITH:
			switch (op2)
			{
			case SCAN_OP_EQ:
				if (val1->equal(val2))
					return SELECTION_COND_SUPERSET_MATCH;
				if (val2->startWith(val1))
					return SELECTION_COND_SUPERSET_MATCH;
				else return SELECTION_COND_NOT_MATCH;
				break;

			case SCAN_OP_NE:
				if (val1->equal(val2))
					return SELECTION_COND_NOT_MATCH;
				if (val2->startWith(val1))
					return SELECTION_COND_NOT_MATCH;
				else return SELECTION_COND_SUBSET_MATCH;
				break;

			case SCAN_OP_CONTAINS:
				if (val1->equal(val2))
					return SELECTION_COND_SUBSET_MATCH;
				if (val1->contains(val2))
					return SELECTION_COND_SUBSET_MATCH;
				else return SELECTION_COND_NOT_MATCH;
				break;

			case SCAN_OP_CONTAINEDBY:
				return SELECTION_COND_NOT_MATCH;
				break;

			case SCAN_OP_STARTWITH:
				if (val1->equal(val2))
					return SELECTION_COND_FULL_MATCH;
				if (val1->startWith(val2))
					return SELECTION_COND_SUBSET_MATCH;
				if (val2->startWith(val1))
					return SELECTION_COND_SUPERSET_MATCH;
				else return SELECTION_COND_NOT_MATCH;
			}
			break;

		}
	}

	return SELECTION_COND_NOT_MATCH;
}

/**
* Process Method
* Wrap the content of the predicate into a string
* @param bufferlength The length of the result string (return value)
* @return The string that contains information bout the predicate.
*/
char* PredicateCondition::wrap(int* bufferlength)
{
	char* buffer;
	int size;
	char* valuebuffer;
	int valuesize;

	valuebuffer = this->rightValue->wrap(&valuesize);
	size = valuesize + 2*sizeof(int);
	
	buffer = new char[size];
	memcpy(buffer, &(this->leftValue), sizeof(int));
	memcpy(buffer+sizeof(int), &(this->predicateOperator), sizeof(int));
	memcpy(buffer+2*sizeof(int), valuebuffer, valuesize);

	delete valuebuffer;

	*bufferlength = size;
	return buffer;
}

void PredicateCondition::printPredicateCondition()
{
	printLeftValue();
	printOperator();
	printRightValue();
}

/**
* Debug Methods
* Print the predicate.
*/
void PredicateCondition::printLeftValue()
{
	cout << "leftvalue: ";
	switch (this->leftValue)
	{
	case SCAN_LEFTVALUE_VALUE:
		cout << "SCAN_LEFTVALUE_VALUE";
		break;

	case SCAN_LEFTVALUE_LENGTH:		
		cout << "SCAN_LEFTVALUE_LENGTH";
		break;

	case SCAN_LEFTVALUE_CHILDNUMBER:	
		cout << "SCAN_LEFTVALUE_CHILDNUMBER ";
		break;

	case SCAN_LEFTVALUE_ATTRIBUTENUMBER:
		cout << "SCAN_LEFTVALUE_ATTRIBUTENUMBER";
		break;
	
	case SCAN_LEFTVALUE_XMLFILENAME:			
		cout << "SCAN_LEFTVALUE_XMLFILENAME";
		break;
	
	case SCAN_LEFTVALUE_DTDFILENAME:		
		cout << "SCAN_LEFTVALUE_DTDFILENAME";
		break;
	
	case SCAN_LEFTVALUE_NODETAG:		
		cout << "SCAN_LEFTVALUE_NODETAG";
		break;
	
	case SCAN_LEFTVALUE_HASCHILD:	
		cout << "SCAN_LEFTVALUE_HASCHILD";
		break;
	
	case SCAN_LEFTVALUE_HASATTRIBUTE:	
		cout << "SCAN_LEFTVALUE_HASATTRIBUTE";
		break;

	case SCAN_LEFTVALUE_ELEMENTCONTENT:
		cout << "SCAN_LEFTVALUE_ELEMENTCONTENT";
		break;

	default:
#pragma warning(disable:4312) // disable the warning for casting int to char * for the leftValue
		cout << (char*) this->leftValue;
#pragma warning(default:4312)
		break;
	}
	cout << endl;
}

void PredicateCondition::printOperator()
{
	cout << "opertor: ";
	switch (this->predicateOperator)
	{
	case SCAN_OP_GT:
		cout << "Larger Than (>) ";
		break;

	case SCAN_OP_GE:
		cout << "Larger and Equal Than (>=) ";
		break;

	case SCAN_OP_LT:
		cout << "less Than (<) ";
		break;

	case SCAN_OP_LE:
		cout << "less and Equal Than (<=) ";
		break;

	case SCAN_OP_EQ:
		cout << "Equal To (=) ";
		break;

	case SCAN_OP_NE:
		cout << "Not Equal To (!=) ";
		break;

	case SCAN_OP_CONTAINS:
		cout << "Contain ";
		break;

	case SCAN_OP_CONTAINEDBY:
		cout << "Contained By ";
		break;

	case SCAN_OP_STARTWITH:
		cout << "Start With ";
		break;
	}
	cout << "" << endl;

}

void PredicateCondition::printRightValue()
{
	cout << "\t\trightval: ";
	this->rightValue->printValue();
	cout << "" << endl;
}
