/*
COPYRIGHT  (c) 2000-2004 
THE REGENTS OF THE UNIVERSITY OF MICHIGAN
ALL RIGHTS RESERVED

PERMISSION IS GRANTED TO USE, COPY, CREATE DERIVATIVE WORKS AND
REDISTRIBUTE THIS SOFTWARE AND SUCH DERIVATIVE WORKS FOR NONCOMMERCIAL
EDUCATION AND RESEARCH PURPOSES, SO LONG AS NO FEE IS CHARGED, AND SO LONG
AS THE COPYRIGHT NOTICE ABOVE, THIS GRANT OF PERMISSION, AND THE
DISCLAIMER BELOW APPEAR IN ALL COPIES MADE; AND SO LONG AS THE NAME OF THE
UNIVERSITY OF MICHIGAN IS NOT USED IN ANY ADVERTISING OR PUBLICITY
PERTAINING TO THE USE OR DISTRIBUTION OF THIS SOFTWARE WITHOUT SPECIFIC,
WRITTEN PRIOR AUTHORIZATION.

THIS SOFTWARE IS PROVIDED AS IS, WITHOUT REPRESENTATION FROM THE
UNIVERSITY OF MICHIGAN AS TO ITS FITNESS FOR ANY PURPOSE, AND WITHOUT
WARRANTY BY THE UNIVERSITY OF MICHIGAN OF ANY KIND, EITHER EXPRESS OR
IMPLIED, INCLUDING WITHOUT LIMITATION THE IMPLIED WARRANTIES OF
MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE. THE REGENTS OF THE
UNIVERSITY OF MICHIGAN SHALL NOT BE LIABLE FOR ANY DAMAGES, INCLUDING
SPECIAL, INDIRECT, INCIDENTAL, OR CONSEQUENTIAL DAMAGES, WITH RESPECT TO
ANY CLAIM ARISING OUT OF OR IN CONNECTION WITH THE USE OF THE SOFTWARE,
EVEN IF IT HAS BEEN OR IS HEREAFTER ADVISED OF THE POSSIBILITY OF SUCH
DAMAGES.
*/

/**
 * @author Yuqing (Melanie) Wu
 */

#ifndef __ConjunctiveCondition_H
#define __ConjunctiveCondition_H

#include "PredicateCondition.h"

/**
* class ConjunctiveCondition
* 
* This class represent seleciton condition that is a set of predicates with AND relation between them. 
* This class provide functions for store, access the information of a ConjunctiveCondition, as well as functions 
* that validate, wrap/unwrap the condition to a string, and the function that compare one condition to another
* trying to find the containment relationship between them. 
*
* @see SelectionCondition
* @see PredicateCondition
*/
class ConjunctiveCondition 
{
public:
	/** 
	* Constructor
	* Construct a blank instance of the condition
	*/
	ConjunctiveCondition();

	/** 
	* Constructor
	* Construct a blank instance of the conditio, given the number of predicates in the condition. 
	*
	* @param num The number of predicates that will be in this ConjunctiveCondition
	*/
	ConjunctiveCondition(int num);
	
	/**
	* Constructor
	* Create an instance of the ConjunctiveCondition, using the information wrapped in a string
	* @param buffer The string that contains the information about the condition. 
	*/
	ConjunctiveCondition(char* buffer);
	
	/**
	* Constructor
	* Create an instance of the ConjunctiveCondition, by copying info from another instance.
	* @param cond The conjunctive condition to be copied. 
	*/
	ConjunctiveCondition(ConjunctiveCondition* cond);

	/**
	* Destructor
	* Release space taken by the predicates
	*/
	~ConjunctiveCondition();

	/**
	* Access Method
	* Get the information about the number of predicate
	*/
	int getNumber();
	
	/**
	* Access Method
	* Get all the predicates in the ConjunctiveCondition
	* @returns The list of predicates in the ConjunctiveCondition.
	*/
	PredicateCondition** getCondList();
	
	/**
	* Access Method
	* Get the predicate at a certain position
	* @param index Indicate which predicate to get
	* @returns THe index'th predicate in the ConjunctiveCondition.
	*/
	PredicateCondition* getCondAt(int index);

	/**
	* Set Method
	* Set the number of predicates in the ConjunctiveCondition
	* Changing the number of predicates in the ConjunctiveCondition will result in the deletion of all predicates
	* currently in the ConjunctiveCondition and reallocation space according to  the number given. 
	* 
	* @param num The number of predicates to be in the ConjunctiveCondition
	*/
	void setNumber(int num);
	
	/**
	* Set Method
	* Set predicates to the ConjunctiveCondition, at a given position in the list
	* 
	* @param index The place to put the predicate
	* @param cond The predicate to be placed in ConjunctiveCondition.
	*/
	void setCond(int index, PredicateCondition* cond);
	
	/**
	* Process Method
	* Insert a new predicate into the ConjunctiveCondition.
	* The new predicate is always put at the first available place in the list. 
	* In case the list is currently full, extend the list to hold the new one. 
	* 
	* @param cond The predicate to be inserted
	*/
	void insertCond(PredicateCondition* cond);
	
	/**
	* Process Method
	* Remove a predicate from the list. 
	* @param A position in the list. THe predicate currently sit on that position is to be removed. 
	*/
	void deleteCond(int index);

	/**
	* Process Method
	* Validate the ConjunctiveCondition. 
	* 
	* @param nodeType The type of node that predicate is to be applied on.
	* @returns A boolean value that indicate whether the ConjunctiveCondition is valid, based on 
	* whether each of the predicate in the list is valid. 
	*/
	bool isValid(int nodeType);

	/**
	* Process Method
	* Given two ConjunctiveCondition, compare them and find out whether they have any inclusion relationship. 
	* 
	* @param pred The ConjunctiveCondition to be compared with the ConjunctiveCondition represented by this class. 
	* @returns code that indicate the relationship between the two ConjunctiveCondition. It can be: 
	*		SELECTION_COND_FULL_MATCH	
	*		SELECTION_COND_SUBSET_MATCH	
	*		SELECTION_COND_SUPERSET_MATCH
	*		SELECTION_COND_NOT_MATCH
	*/
	int matchConjunctiveCondition(ConjunctiveCondition* cond);

	/**
	* Process Method
	* Given two ConjunctiveCondition, compare them and find out whether they have any inclusion relationship,
	* allowing one or both of to be NULL. 
	* 
	* @param pred The ConjunctiveCondition to be compared with the ConjunctiveCondition represented by this class. 
	* @returns code that indicate the relationship between the two ConjunctiveCondition. It can be: 
	*		SELECTION_COND_FULL_MATCH	
	*		SELECTION_COND_SUBSET_MATCH	
	*		SELECTION_COND_SUPERSET_MATCH
	*		SELECTION_COND_NOT_MATCH
	*/
	char* wrap(int* bufferlength);

	/**
	* Debug Methods
	* Print the ConjunctiveCondition.
	*/
	void printConjunctiveCondition();

private:
	/**
	* Number of predicates in the conjunctive expression
	*/
	int conjunctiveNumber;
	
	/**
	* The list of the predicates
	*/
	PredicateCondition** predicateList;

	/**
	* Process Method
	* Given two ConjunctiveCondition, compare them and find out whether they have any inclusion relationship,
	* allowing one or both of to be NULL. 
	* 
	* @param pred The ConjunctiveCondition to be compared with the ConjunctiveCondition represented by this class. 
	* @returns code that indicate the relationship between the two ConjunctiveCondition. It can be: 
	*		SELECTION_COND_FULL_MATCH	
	*		SELECTION_COND_SUBSET_MATCH	
	*		SELECTION_COND_SUPERSET_MATCH
	*		SELECTION_COND_NOT_MATCH
	*/
	int matchCondition(PredicateCondition* cond1, PredicateCondition* cond2);
} ;

#endif
