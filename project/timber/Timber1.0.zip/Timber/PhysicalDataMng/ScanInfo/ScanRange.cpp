/*
COPYRIGHT  (c) 2000-2004 
THE REGENTS OF THE UNIVERSITY OF MICHIGAN
ALL RIGHTS RESERVED

PERMISSION IS GRANTED TO USE, COPY, CREATE DERIVATIVE WORKS AND
REDISTRIBUTE THIS SOFTWARE AND SUCH DERIVATIVE WORKS FOR NONCOMMERCIAL
EDUCATION AND RESEARCH PURPOSES, SO LONG AS NO FEE IS CHARGED, AND SO LONG
AS THE COPYRIGHT NOTICE ABOVE, THIS GRANT OF PERMISSION, AND THE
DISCLAIMER BELOW APPEAR IN ALL COPIES MADE; AND SO LONG AS THE NAME OF THE
UNIVERSITY OF MICHIGAN IS NOT USED IN ANY ADVERTISING OR PUBLICITY
PERTAINING TO THE USE OR DISTRIBUTION OF THIS SOFTWARE WITHOUT SPECIFIC,
WRITTEN PRIOR AUTHORIZATION.

THIS SOFTWARE IS PROVIDED AS IS, WITHOUT REPRESENTATION FROM THE
UNIVERSITY OF MICHIGAN AS TO ITS FITNESS FOR ANY PURPOSE, AND WITHOUT
WARRANTY BY THE UNIVERSITY OF MICHIGAN OF ANY KIND, EITHER EXPRESS OR
IMPLIED, INCLUDING WITHOUT LIMITATION THE IMPLIED WARRANTIES OF
MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE. THE REGENTS OF THE
UNIVERSITY OF MICHIGAN SHALL NOT BE LIABLE FOR ANY DAMAGES, INCLUDING
SPECIAL, INDIRECT, INCIDENTAL, OR CONSEQUENTIAL DAMAGES, WITH RESPECT TO
ANY CLAIM ARISING OUT OF OR IN CONNECTION WITH THE USE OF THE SOFTWARE,
EVEN IF IT HAS BEEN OR IS HEREAFTER ADVISED OF THE POSSIBILITY OF SUCH
DAMAGES.
*/

/**
 * @author Yuqing (Melanie) Wu
 */

#include "ScanRange.h"

/** 
* Constructor
* 
* Set the number of ranges in the ScanRange, and initialize the ranges all be -1.
*/

ScanRange::ScanRange(int num)
{
	this->rangeNum = num;
	this->ranges = new ScanRangeType[this->rangeNum];
	for (int i=0; i<this->rangeNum; i++)
	{
		this->ranges[i].startPos = -1;
		this->ranges[i].endPos = -1;
	}
	sorted = false;
}

/**
* Constructor
*
* Initialize the ScanRange with given ranges.
*/

ScanRange::ScanRange(int num, ScanRangeType** ranges)
{
	this->rangeNum = num;
	this->ranges = new ScanRangeType[this->rangeNum];
	for (int i=0; i<this->rangeNum; i++)
	{
		this->ranges[i].startPos = ranges[i]->startPos;
		this->ranges[i].endPos = ranges[i]->endPos;
	}

	sorted = false;
}

/** 
* Destructor
*
* Release the space taken by ranges
*/
ScanRange::~ScanRange()
{
	delete [] this->ranges;
}

/** 
* Access Method
* Get the number of ranges in ScanRange
*/

int ScanRange::getScanRangeNumber()
{
	return this->rangeNum;
}

/**
* Access Method
* Get the i'th range in the list
*/
ScanRangeType* ScanRange::getScanRangeAt(int i)
{
	if (i<this->rangeNum)
		return &(this->ranges[i]);
	else return NULL;
}

/**
* Access Method
* Get the ranges as a list.
*/
ScanRangeType* ScanRange::getScanRange()
{
	return this->ranges;
}

/**
* Set the number of ranges in ScanRange
*
* If the new range number if smaller than the original range number, remove all the ranges. 
* If the new number is larger than the number of ranges currently in ScanRange, extend the ranges to make it larger
*/
void ScanRange::setScanRangeNumber(int num)
{
	if (this->rangeNum > num)
	{
		// when the new number is smaller, delete all ranges, and re-set the rangeNum
		delete this->ranges;
		this->rangeNum = num;
		this->ranges = new ScanRangeType[this->rangeNum];
		for (int i=0; i<this->rangeNum; i++)
		{
			this->ranges[i].startPos = -1;
			this->ranges[i].endPos = -1;
		}
	}

	else
	{
		// otherwise, extend the space and keep the original ranges.

		ScanRangeType* newranges = new ScanRangeType[num];
		for (int i=0; i<this->rangeNum; i++)
		{
			newranges[i].startPos = this->ranges[i].startPos;
			newranges[i].endPos = this->ranges[i].endPos;
		}
		for (i=this->rangeNum; i<num; i++)
		{
			newranges[i].startPos = -1;
			newranges[i].endPos = -1;
		}
		delete this->ranges;
		this->ranges = newranges;
		this->rangeNum = num;
	}
}

/**
* Set the i'th scan range to be the range given.
*/
void ScanRange::setScanRangeAt(int i, ScanRangeType* range)
{
	if (i<this->rangeNum)
	{
		this->ranges[i].startPos = range->startPos;
		this->ranges[i].endPos = range->endPos;
	}
}

/**
* Process Method
* 
* Check whether a node falls into the ranges.
* 
* Given the key of a node, find out whether this node is in the scan range
* 
* @param startkey The key of the node
* @returns A boolean value which indicate whether the node is in the scan ranges. 
*/
bool ScanRange::inScanRange(KeyType startkey)
{
	if (this->rangeNum == 0) return true;

	// the process for finding out whether a node is in the scan 
    // range is different, depending on whether the ranges are sorted or not.
	bool inrange = false;

	if (sorted)
	{
		// if the ranges are sorted, can use binary search
		int min = 0; 
		int max = this->rangeNum-1;
		int searchAt = (int) ((min+max)/2);

        bool finished = false;
		while (!finished)
		{
			if ((startkey >= this->ranges[searchAt].startPos) &&
				(startkey <= this->ranges[searchAt].endPos))
			{
				inrange = true;
                finished = true;
			}
			else
			{
				if (min == max) 
				{
					inrange = false;
                    finished= true;
					break;
				}

				if (startkey < this->ranges[searchAt].startPos)
					max = searchAt-1;
				else 
					min = searchAt+1;
				searchAt = (int) ((min+max)/2);
			}
		}
	}

	else
	{
		// if the ranges are not sorted, need to use linear search
		for (int i=0; i< this->rangeNum; i++)
		{
			if ((startkey >= this->ranges[i].startPos) &&
				(startkey <= this->ranges[i].endPos))
			{
				inrange = true;
				break;
			}
		}
	}

	return inrange;

}

/**
* Process Method
*
* Sort the ranges in the ScanRange, also merge them if two/more ranges have overlap. 
* The final result is a list of ranges that don't have any overlap between them, and are ordered by the start key.
* The resulting ScanRange should represent the same scan restriction as the original ScanRange. 
*/
void ScanRange::sortScanRange()
{
	// if the range is sorted, nothing needs to be done.
	if (this->sorted) return;

	// sort the ranges selected, by the start pos of the ranges
	for (int i=0; i<this->rangeNum; i++)
		for (int j=i; j<this->rangeNum; j++)
		{
			if (this->ranges[i].startPos > this->ranges[j].startPos)
			{
				KeyType temp;
				temp = this->ranges[i].startPos;
				this->ranges[i].startPos = this->ranges[j].startPos;
				this->ranges[j].startPos = temp;

				temp = this->ranges[i].endPos;
				this->ranges[i].endPos = this->ranges[j].endPos;
				this->ranges[j].endPos = temp;
			}
		}

	// merges the ranges is there is overlap
	int cursor1 = 0;
	int cursor2 = 1;

	while (cursor2 < this->rangeNum)
	{
		if (this->ranges[cursor2].startPos <= this->ranges[cursor1].endPos)
		{
			// merge range2 into range1
			this->ranges[cursor1].endPos = this->ranges[cursor2].endPos;
			// delete range2
			this->ranges[cursor2].startPos = -1; 
			cursor2++;
		}

		else // two range has no overlap
		{
			cursor1 = cursor2;
			cursor2++;
		}
	}

	this->sorted = true;
}


/**
* Process Method
* 
* Change the ScanRange by cutting it with another range, leaving only the 
* scan ranges that fall into the curring range.
*
* @param startkey/endkey The boundary of the cutting range
*/
void ScanRange::cutScanRange(KeyType startkey, KeyType endkey)
{
	sortScanRange();

	ScanRangeType* intermediate_ranges = new ScanRangeType[this->rangeNum];
	
	int cursor = 0;
	for (int i=0; i<this->rangeNum; i++)
	{
		// when the range has no overlap with the subtree, get delete it
		if ((this->ranges[i].endPos < startkey) || (this->ranges[i].startPos > endkey))
			continue;
		else
		{
			intermediate_ranges[cursor].startPos 
				= (this->ranges[i].startPos >= startkey) ? this->ranges[i].startPos : startkey;
			intermediate_ranges[cursor].endPos 
				= (this->ranges[i].endPos <= endkey) ? this->ranges[i].endPos : endkey;
			cursor++;
		}
	}

	delete [] this->ranges; 
	this->ranges = intermediate_ranges;
}
