/*
COPYRIGHT  (c) 2000-2004 
THE REGENTS OF THE UNIVERSITY OF MICHIGAN
ALL RIGHTS RESERVED

PERMISSION IS GRANTED TO USE, COPY, CREATE DERIVATIVE WORKS AND
REDISTRIBUTE THIS SOFTWARE AND SUCH DERIVATIVE WORKS FOR NONCOMMERCIAL
EDUCATION AND RESEARCH PURPOSES, SO LONG AS NO FEE IS CHARGED, AND SO LONG
AS THE COPYRIGHT NOTICE ABOVE, THIS GRANT OF PERMISSION, AND THE
DISCLAIMER BELOW APPEAR IN ALL COPIES MADE; AND SO LONG AS THE NAME OF THE
UNIVERSITY OF MICHIGAN IS NOT USED IN ANY ADVERTISING OR PUBLICITY
PERTAINING TO THE USE OR DISTRIBUTION OF THIS SOFTWARE WITHOUT SPECIFIC,
WRITTEN PRIOR AUTHORIZATION.

THIS SOFTWARE IS PROVIDED AS IS, WITHOUT REPRESENTATION FROM THE
UNIVERSITY OF MICHIGAN AS TO ITS FITNESS FOR ANY PURPOSE, AND WITHOUT
WARRANTY BY THE UNIVERSITY OF MICHIGAN OF ANY KIND, EITHER EXPRESS OR
IMPLIED, INCLUDING WITHOUT LIMITATION THE IMPLIED WARRANTIES OF
MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE. THE REGENTS OF THE
UNIVERSITY OF MICHIGAN SHALL NOT BE LIABLE FOR ANY DAMAGES, INCLUDING
SPECIAL, INDIRECT, INCIDENTAL, OR CONSEQUENTIAL DAMAGES, WITH RESPECT TO
ANY CLAIM ARISING OUT OF OR IN CONNECTION WITH THE USE OF THE SOFTWARE,
EVEN IF IT HAS BEEN OR IS HEREAFTER ADVISED OF THE POSSIBILITY OF SUCH
DAMAGES.
*/

/**
 * @author Yuqing (Melanie) Wu
 */

#include "ConjunctiveCondition.h"
#include "../../Utilities/ErrorInfoClass.h"
extern ErrorInfoClass globalErrorInfo;

/**
* class ConjunctiveCondition
* 
* This class represent seleciton condition that is a set of predicates with AND relation between them. 
* This class provide functions for store, access the information of a ConjunctiveCondition, as well as functions 
* that validate, wrap/unwrap the condition to a string, and the function that compare one condition to another
* trying to find the containment relationship between them. 
*
* @see SelectionCondition
* @see PredicateCondition
*/

/** 
* Constructor
* Construct a blank instance of the condition
*/
ConjunctiveCondition::ConjunctiveCondition()
{
	this->conjunctiveNumber = 0;
}

/** 
* Constructor
* Construct a blank instance of the condition, given the number of predicates in the condition. 
*
* @param num The number of predicates that will be in this ConjunctiveCondition
*/
ConjunctiveCondition::ConjunctiveCondition(int num)
{
	this->conjunctiveNumber = num;

	// allocate space for the predicates
	this->predicateList = new PredicateCondition*[this->conjunctiveNumber];
	for (int i=0; i<this->conjunctiveNumber; i++)
		this->predicateList[i] = NULL;
}

/**
* Constructor
* Create an instance of the ConjunctiveCondition, using the information wrapped in a string
* @param buffer The string that contains the information about the condition. 
*/
ConjunctiveCondition::ConjunctiveCondition(char* buffer)
{
	int cursor = 0;
	memcpy(&(this->conjunctiveNumber), buffer, sizeof(int));
	cursor += sizeof(int);
	this->predicateList = new PredicateCondition*[this->conjunctiveNumber];

	for (int i=0; i<this->conjunctiveNumber; i++)
	{
		int length;
		memcpy(&length, buffer+cursor, sizeof(int));
		cursor += sizeof(int);
		this->predicateList[i] = new PredicateCondition(buffer+cursor);
		cursor += length;
	}
}

/**
* Constructor
* Create an instance of the DisjunctiveCondition, by copying info from another instance.
* @param cond The disjunctive condition to be copied. 
*/
ConjunctiveCondition::ConjunctiveCondition(ConjunctiveCondition* cond)
{
	this->conjunctiveNumber = cond->getNumber();
	this->predicateList = new PredicateCondition*[this->conjunctiveNumber];
	for (int i=0; i<this->conjunctiveNumber; i++)
		this->predicateList[i] = new PredicateCondition(cond->getCondAt(i));
}

/**
* Destructor
* Release space taken by the predicates
*/
ConjunctiveCondition::~ConjunctiveCondition()
{
	if (this->conjunctiveNumber != 0)
	{
		for (int i=0; i<this->conjunctiveNumber; i++){
			delete this->predicateList[i];
			this->predicateList[i] = NULL;
		}
		delete [] this->predicateList;
		this->predicateList = NULL;
	}
}

/**
* Access Method
* Get the information about the number of predicate
*/
int ConjunctiveCondition::getNumber()
{
	return this->conjunctiveNumber;
}

/**
* Access Method
* Get all the predicates in the ConjunctiveCondition
* @returns The list of predicates in the ConjunctiveCondition.
*/
PredicateCondition** ConjunctiveCondition::getCondList()
{
	return this->predicateList;
}

/**
* Access Method
* Get the predicate at a certain position
* @param index Indicate which predicate to get
* @returns THe index'th predicate in the ConjunctiveCondition.
*/
PredicateCondition* ConjunctiveCondition::getCondAt(int index)
{
	if (index > this->conjunctiveNumber)
		return NULL;
	else
		return this->predicateList[index];
}

/**
* Set Method
* Set the number of predicates in the ConjunctiveCondition
* Changing the number of predicates in the ConjunctiveCondition will result in the deletion of all predicates
* currently in the ConjunctiveCondition and reallocation space according to  the number given. 
* 
* @param num The number of predicates to be in the ConjunctiveCondition
*/
void ConjunctiveCondition::setNumber(int num)
{
	// remove old predicates
	if (this->conjunctiveNumber != 0)
	{
		delete [] this->predicateList;
		delete this->predicateList;
	}

	// allocate space according to the number given. 
	this->conjunctiveNumber = num;
	this->predicateList = new PredicateCondition*[this->conjunctiveNumber];
	for (int i=0; i<this->conjunctiveNumber; i++)
		this->predicateList[i] = NULL;

}

/**
* Set Method
* Set predicates to the ConjunctiveCondition, at a given position in the list
* 
* @param index The place to put the predicate
* @param cond The predicate to be placed in ConjunctiveCondition.
*/
void ConjunctiveCondition::setCond(int index,
								   PredicateCondition* cond)
{
	if (index < this->conjunctiveNumber)
	{
		// if the index is within the current predicate number, remove the
		// old predicate and replace it with the new one
		if (this->predicateList[index] != NULL)
			delete this->predicateList[index];
		this->predicateList[index] = cond;
	}
	else 
	{
		// otherwise, extend the space reserved for the predicate list, to be large then to hold the new
		// predicate at its assigned position. 
        globalErrorInfo.insertProblem(ERR_TYPE_WARNING,__LINE__,"ConjunctiveCondition::setCond",__FILE__,
                                      "Position value is larger than reserved space, automatically increase space");

		// a new list that is large enough
		PredicateCondition** templist = new PredicateCondition*[index+1];

		// move the old predicates to the templist
		for (int i=0; i<this->conjunctiveNumber; i++)
			templist[i] = this->predicateList[i];

		// put the new predicate at its assigned place
		templist[index] = cond;

		// remove the old list
		delete [] this->predicateList;
		delete this->predicateList;

		// replace it with the new list. 
		this->predicateList = templist;
	}
}

/**
* Process Method
* Insert a new predicate into the ConjunctiveCondition.
* The new predicate is always put at the first available place in the list. 
* In case the list is currently full, extend the list to hold the new one. 
* 
* @param cond The predicate to be inserted
*/
void ConjunctiveCondition::insertCond(PredicateCondition* cond)
{
	// find the first available place and put the predicate there. 
	for (int i=0; i<this->conjunctiveNumber; i++)
    {
		if (this->predicateList[i] == NULL)
		{
			this->predicateList[i] = cond;
			return;
		}
    }
		
	this->conjunctiveNumber++;

	// In case the list is currently full, extend the list to hold the new one. 
    globalErrorInfo.insertProblem(ERR_TYPE_WARNING,__LINE__,"ConjunctiveCondition::insertCond",__FILE__,
                                  "Reserved space full, automatically increase space");
	PredicateCondition** templist = new PredicateCondition*[this->conjunctiveNumber];

	for (i=0; i<this->conjunctiveNumber-1; i++)
		templist[i] = this->predicateList[i];
	templist[this->conjunctiveNumber-1] = cond;

	//delete [] this->predicateList;
	if (this->conjunctiveNumber-1 > 0) delete this->predicateList;

	this->predicateList = templist;
}

/**
* Process Method
* Remove a predicate from the list. 
* @param A position in the list. The predicate currently sit on that position is to be removed. 
*/
void ConjunctiveCondition::deleteCond(int index)
{
	if (index < this->conjunctiveNumber)
	{
		if (this->predicateList[index] != NULL)
			delete this->predicateList[index];
	}
	else
	{
        globalErrorInfo.insertProblem(ERR_TYPE_WARNING,__LINE__,"ConjunctiveCondition::deleteCond",__FILE__,"No valid condition to be deleted");
	}
}

/**
* Process Method
* Validate the ConjunctiveCondition. 
* 
* @param nodeType The type of node that predicate is to be applied on.
* @returns A boolean value that indicate whether the ConjunctiveCondition is valid, based on 
* whether each of the predicate in the list is valid. 
*/
bool ConjunctiveCondition::isValid(int nodeType)
{
	bool valid = true;
	for (int i =0; i<this->conjunctiveNumber; i++)
	{
		if (!this->predicateList[i]->isValid(nodeType))
		{
			valid = false;
			break;
		}
	}
	return valid;
}


/**
* Process Method
* Given two ConjunctiveCondition, compare them and find out whether they have any inclusion relationship. 
* 
* @param pred The ConjunctiveCondition to be compared with the ConjunctiveCondition represented by this class. 
* @returns code that indicate the relationship between the two ConjunctiveCondition. It can be: 
*		SELECTION_COND_FULL_MATCH	
*		SELECTION_COND_SUBSET_MATCH	
*		SELECTION_COND_SUPERSET_MATCH
*		SELECTION_COND_NOT_MATCH
*/
int ConjunctiveCondition::matchConjunctiveCondition(ConjunctiveCondition* cond)
{
	int i,j;

	const int cond1_num = this->conjunctiveNumber;
	const int cond2_num = cond->getNumber();

	int** relationMatrix =  new int*[cond1_num];
	for (i=0; i<cond1_num; i++)
		relationMatrix[i] = new int[cond2_num];

	// match each pair of predicates in the two ConjunctiveConditions
	for (i=0; i<cond1_num; i++)
    {
		for (j=0; j<cond2_num; j++)
		{
			int rel = matchCondition(this->predicateList[i], cond->getCondAt(j));
			relationMatrix[i][j] = rel;
		}
    }

	int relation12 = SELECTION_COND_NOT_MATCH;
	int relation21 = SELECTION_COND_NOT_MATCH;
	for (i=0; i<cond1_num; i++)
	{
		bool cond1_containedby_cond2 = true;
		for (j=0; j<cond2_num; j++)
		{
			if ((relationMatrix[i][j] == SELECTION_COND_SUPERSET_MATCH) ||
				(relationMatrix[i][j] == SELECTION_COND_NOT_MATCH))
			{
				cond1_containedby_cond2 = false;
				break;
			}
		}
		if (cond1_containedby_cond2) 
		{
			relation12 = SELECTION_COND_SUBSET_MATCH;
			break;
		}
	}

	for (j=0; j<cond2_num; j++)
	{
		bool cond2_containedby_cond1 = true;
		for (i=0; i<cond1_num; i++)
		{
			if ((relationMatrix[i][j] == SELECTION_COND_SUBSET_MATCH) ||
				(relationMatrix[i][j] == SELECTION_COND_NOT_MATCH))
			{
				cond2_containedby_cond1 = false;
				break;
			}
		}
		if (cond2_containedby_cond1) 
		{
			relation21 = SELECTION_COND_SUBSET_MATCH;
			break;
		}
	}

	if ((relation12 == SELECTION_COND_SUBSET_MATCH) &
		(relation21 == SELECTION_COND_SUBSET_MATCH))
		return SELECTION_COND_FULL_MATCH;

	if (relation12 == SELECTION_COND_SUBSET_MATCH)
		return SELECTION_COND_SUBSET_MATCH;

	if (relation21 == SELECTION_COND_SUBSET_MATCH)
		return SELECTION_COND_SUPERSET_MATCH;

	return SELECTION_COND_NOT_MATCH;
}


/**
* Process Method
* Given two ConjunctiveCondition, compare them and find out whether they have any inclusion relationship,
* allowing one or both of to be NULL. 
* 
* @param pred The ConjunctiveCondition to be compared with the ConjunctiveCondition represented by this class. 
* @returns code that indicate the relationship between the two ConjunctiveCondition. It can be: 
*		SELECTION_COND_FULL_MATCH	
*		SELECTION_COND_SUBSET_MATCH	
*		SELECTION_COND_SUPERSET_MATCH
*		SELECTION_COND_NOT_MATCH
*/
int ConjunctiveCondition::matchCondition(PredicateCondition* cond1,
										 PredicateCondition* cond2)
{
	if ((cond1 == NULL) && (cond2 == NULL))
		return SELECTION_COND_FULL_MATCH;

	if ((cond1 == NULL) && (cond2 != NULL))
		return SELECTION_COND_SUPERSET_MATCH;

	if ((cond1 != NULL) && (cond2 == NULL))
		return SELECTION_COND_SUBSET_MATCH;

	if ((cond1 != NULL) && (cond2 != NULL))
		return cond1->matchPredicateCondition(cond2);

	return SELECTION_COND_NOT_MATCH;
}


/**
* Process Method
* Wrap the content of the ConjunctiveCondition into a string
* @param bufferlength The length of the result string (return value)
* @return The string that contains information bout the ConjunctiveCondition.
*/
char* ConjunctiveCondition::wrap(int* bufferlength)
{
	char* buffer;
	int size = sizeof(int);

	char** predicatebuffer = new char*[this->conjunctiveNumber];
	int* predicatebufferlength = new int[this->conjunctiveNumber];

	for (int i=0; i<this->conjunctiveNumber; i++)
	{
		predicatebuffer[i] = this->predicateList[i]->wrap(&(predicatebufferlength[i]));
		size = size + sizeof(int) + predicatebufferlength[i];
	}

	buffer = new char[size];

	int cursor = 0;
	memcpy(buffer, &(this->conjunctiveNumber), sizeof(int));
	cursor += sizeof(int);

	for (i=0; i<this->conjunctiveNumber; i++)
	{
		memcpy(buffer+cursor, &(predicatebufferlength[i]), sizeof(int));
		cursor += sizeof(int);
		memcpy(buffer+cursor, predicatebuffer[i], predicatebufferlength[i]);
		cursor += predicatebufferlength[i];
		delete predicatebuffer[i];
	}

	delete predicatebuffer;
	delete predicatebufferlength;

	*bufferlength = size;
	return buffer;
}

/**
* Debug Methods
* Print the ConjunctiveCondition.
*/
void ConjunctiveCondition::printConjunctiveCondition()
{
	for (int i=0; i<this->conjunctiveNumber; i++)
	{
		if (i!= 0) cout << " AND " << endl;
		this->predicateList[i]->printPredicateCondition();
	}
}
