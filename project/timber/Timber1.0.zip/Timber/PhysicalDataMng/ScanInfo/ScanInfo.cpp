/*
COPYRIGHT  (c) 2000-2004 
THE REGENTS OF THE UNIVERSITY OF MICHIGAN
ALL RIGHTS RESERVED

PERMISSION IS GRANTED TO USE, COPY, CREATE DERIVATIVE WORKS AND
REDISTRIBUTE THIS SOFTWARE AND SUCH DERIVATIVE WORKS FOR NONCOMMERCIAL
EDUCATION AND RESEARCH PURPOSES, SO LONG AS NO FEE IS CHARGED, AND SO LONG
AS THE COPYRIGHT NOTICE ABOVE, THIS GRANT OF PERMISSION, AND THE
DISCLAIMER BELOW APPEAR IN ALL COPIES MADE; AND SO LONG AS THE NAME OF THE
UNIVERSITY OF MICHIGAN IS NOT USED IN ANY ADVERTISING OR PUBLICITY
PERTAINING TO THE USE OR DISTRIBUTION OF THIS SOFTWARE WITHOUT SPECIFIC,
WRITTEN PRIOR AUTHORIZATION.

THIS SOFTWARE IS PROVIDED AS IS, WITHOUT REPRESENTATION FROM THE
UNIVERSITY OF MICHIGAN AS TO ITS FITNESS FOR ANY PURPOSE, AND WITHOUT
WARRANTY BY THE UNIVERSITY OF MICHIGAN OF ANY KIND, EITHER EXPRESS OR
IMPLIED, INCLUDING WITHOUT LIMITATION THE IMPLIED WARRANTIES OF
MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE. THE REGENTS OF THE
UNIVERSITY OF MICHIGAN SHALL NOT BE LIABLE FOR ANY DAMAGES, INCLUDING
SPECIAL, INDIRECT, INCIDENTAL, OR CONSEQUENTIAL DAMAGES, WITH RESPECT TO
ANY CLAIM ARISING OUT OF OR IN CONNECTION WITH THE USE OF THE SOFTWARE,
EVEN IF IT HAS BEEN OR IS HEREAFTER ADVISED OF THE POSSIBILITY OF SUCH
DAMAGES.
*/

/**
 * @author Yuqing (Melanie) Wu
 */

#include "ScanInfo.h"

/**
* Constructor
*
* Construct an instance of ScanInfo with the information about a scan
* 
*@param fileinfo The information about the XML document (in database) scanned. It is an instance of the FileInfoType.
*@param scancond The scan condition. Each node within the scan range is checked with the condition and only the ones that satisfy the condition belongs to the scan result. 
*@param scanmethod Left for later usage
*@param nodekey The key of the node which is the root of the subtree to be scanned.
*@param endkeyboundary The key that is the end boundary for the scan. This is usually the end key of the node whose key is nodekey. In case the scan range is set, the end boundary should be set to the end boundary of the last range. 
*@param minlevel, maxlevel The level range of nodes to be scanned. 
*@param scanrange A set of key intervals which specifies that only nodes fall in the ranges are to be checked.
*@param rangecursor A pointer to the scanrange which indicate nodes in which range are under examining. 
*@param scanhandler The Shore/BerkeleyDB scan handler that does linear scan of the data file. 
*/
ScanInfo::ScanInfo(FileInfoType* fileinfo, 
				   SelectionCondition* scancond, 
				   int scanmethod, 
				   KeyType nodekey,
				   KeyType endkeyboundary,
				   int minlevel,
				   int maxlevel, 
				   ScanRange* scanrange,
				   int rangecursor,
				   scan_file_i* scanhandler,
				   bool inOverflow,
				   bool considerOverflow)
{
	this->fileinfo = fileinfo; 
	this->scanMethod = scanmethod;
	this->startKeyBoundary = nodekey;
	this->endKeyBoundary = endkeyboundary;
	this->minLevel = minlevel;
	this->maxLevel = maxlevel;

	this->scanCond = scancond;

	if (scanrange == NULL)
	{
		this->scanRange = NULL;
		this->rangeCursor = -1;
	}
	else
	{
		this->scanRange = scanrange;
		this->rangeCursor = rangecursor;
	}

	this->scanHandler = scanhandler;

	// overflow section appear when the data file is updated, and before it has been rearranged.
	// the overflow section is at the end of the data file. 
	// to make sure that all nodes that are qualified as the scan result (in the specified subtree, 
	// within the specified level, in scanrange, if any, and satisfy the scan condition) are returned
	// in the scan result, the overflow section should be scanned. 
	// when scan starts, always assume that it is not in the overflow section. 
	//this->inOverflowSection = false;
	this->inOverflowSection = inOverflow;

	//true by default:
	this->considerOverflow = considerOverflow;
}

/**
 * Destructor
 *
 * Free the space taken by the scan condition, scan range, and release scan handler
**/

ScanInfo::~ScanInfo()
{
	if (this->scanCond != NULL) {
		delete this->scanCond;
		this->scanCond = NULL;
	}

	if (this->scanRange != NULL)
		delete this->scanRange;

	if (this->scanHandler != NULL)
	{
		scanHandler->finish();
		delete this->scanHandler;
	}
}

/**
* Access Method
* Get the information of the file being scanned.
* @returns the instance of FileInfoType which contains the inforamtion of the data file. 
*/
FileInfoType* ScanInfo::getFileInfo()
{
	return this->fileinfo;
}

/**
* Access Method
* Get the scan method of the scan.
* @returns the scan method of the scan
*/
int ScanInfo::getScanMethod()
{
	return this->scanMethod;
}

/**
* Access Method
* Get the scan condition of the scan.
* @returns the scan condition of the scan
*/
SelectionCondition* ScanInfo::getScanCond()
{
	return this->scanCond;
}

/**
* Access Method
* Get the scan range of the scan.
* @returns the scan range of the scan
*/
ScanRange* ScanInfo::getScanRange()
{
	return this->scanRange;
}

/**
* Access Method
* Get the boundary of the end key of the scan.
* @returns the boundary of the end key of the scan
*/
KeyType ScanInfo::getEndKeyBoundary()
{
	return this->endKeyBoundary;
}

KeyType ScanInfo::getStartKeyBoundary()
{
	return this->startKeyBoundary;
}

/**
* Access Method
* Get the minimum level of the nodes that can be result of the scan 
* @returns the minimum level of the nodes that can be result of the scan. 
*/
int ScanInfo::getScanMinLevel()
{
	return this->minLevel;
}

/**
* Access Method
* Get the maximum level of the nodes that can be result of the scan 
* @returns the maximum level of the nodes that can be result of the scan. 
*/
int ScanInfo::getScanMaxLevel()
{
	return this->maxLevel;
}

/**
* Access Method
* Get the scan handler of shore/berkeleyDB for the scan.
* @returns The scan handler.
*/
scan_file_i* ScanInfo::getScanHandler()
{
	return this->scanHandler;
}

/**
* Access Method
* Get the cursor which points to the scan range in which the next result may fall. 
* @returns An integer which is the cursor pointing to the scan range  
*	with nodes in which currently under scaning by the scan handler.
*/
int ScanInfo::getRangeCursor()
{
	return this->rangeCursor;
}

/** 
* Access Method
*
* Report whether the scan is currently scanning in the overflow section.
*
*@returns A boolean value which indicate whether the scan is currently scanning in the overflow section.
*/
bool ScanInfo::isScanningInOverflowSection()
{
	return this->inOverflowSection;
}

bool ScanInfo::shouldScanOverflow() {
	return considerOverflow;
}

/**
* Set Method
*
* Set the scan handler.
* A new scan handler may move the scan into the overflow section of the data file. That is why a boolean
* value should also be passed in and set.
*
*@param scanhandler The Shore scan handler
*@param inoverflow	Whether the current scan handler is scanning the overflow section
*/
void ScanInfo::setScanHandler(scan_file_i* scanhandler, bool inoverflow)
{
	this->scanHandler = scanhandler;
	this->inOverflowSection = inoverflow;
}

/**
* Set Method
*
* Set the range cursor, a pointer which indicate which range should consider
*
* @param cursor The range cursor
*/
void ScanInfo::setRangeCursor(const int cursor)
{
	this->rangeCursor = cursor;
}
