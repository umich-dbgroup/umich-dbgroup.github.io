/*
COPYRIGHT  (c) 2000-2004 
THE REGENTS OF THE UNIVERSITY OF MICHIGAN
ALL RIGHTS RESERVED

PERMISSION IS GRANTED TO USE, COPY, CREATE DERIVATIVE WORKS AND
REDISTRIBUTE THIS SOFTWARE AND SUCH DERIVATIVE WORKS FOR NONCOMMERCIAL
EDUCATION AND RESEARCH PURPOSES, SO LONG AS NO FEE IS CHARGED, AND SO LONG
AS THE COPYRIGHT NOTICE ABOVE, THIS GRANT OF PERMISSION, AND THE
DISCLAIMER BELOW APPEAR IN ALL COPIES MADE; AND SO LONG AS THE NAME OF THE
UNIVERSITY OF MICHIGAN IS NOT USED IN ANY ADVERTISING OR PUBLICITY
PERTAINING TO THE USE OR DISTRIBUTION OF THIS SOFTWARE WITHOUT SPECIFIC,
WRITTEN PRIOR AUTHORIZATION.

THIS SOFTWARE IS PROVIDED AS IS, WITHOUT REPRESENTATION FROM THE
UNIVERSITY OF MICHIGAN AS TO ITS FITNESS FOR ANY PURPOSE, AND WITHOUT
WARRANTY BY THE UNIVERSITY OF MICHIGAN OF ANY KIND, EITHER EXPRESS OR
IMPLIED, INCLUDING WITHOUT LIMITATION THE IMPLIED WARRANTIES OF
MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE. THE REGENTS OF THE
UNIVERSITY OF MICHIGAN SHALL NOT BE LIABLE FOR ANY DAMAGES, INCLUDING
SPECIAL, INDIRECT, INCIDENTAL, OR CONSEQUENTIAL DAMAGES, WITH RESPECT TO
ANY CLAIM ARISING OUT OF OR IN CONNECTION WITH THE USE OF THE SOFTWARE,
EVEN IF IT HAS BEEN OR IS HEREAFTER ADVISED OF THE POSSIBILITY OF SUCH
DAMAGES.
*/

/**
 * @author Yuqing (Melanie) Wu
 */

#ifndef __ScanRange_H
#define __ScanRange_H

#include "../stdafx.h"

/**
* ScanRangeType
* a ScanRangeType is a pair of keys, which specify an interval in which the scan result should fall.
* @see ScanRange
*/
typedef struct {
	/**
	* Start point of the range
	*/
	KeyType		startPos;
	/**
	* End point of the range
	*/
	KeyType		endPos;
} ScanRangeType;

/**
* ScanRange 
* 
* A list of ranges of ScanRangType, which defines the physical boundary in which scan results should fall
* It is allowed that the ranges in ScanRange overlap with each other. PhysicalDataMng::StartScan will take care of it. 
* 
* the functions provided by this class includes:
*   inScanRange: given a key, find out whether it is in the ScanRange. 
*	sortScanRange: changing the represenation of the ScanRange to be a list of detacted ranges, ordered by
*		the startkey of the ranges, by means of sort / merge / change boundary of the ranges,
*   cutScanRange: change the scan range to be a subset of it that falls into a given boundary. 
*   
* @see ScanRangeType
* @see PhysicalDataMng::startScan
*/
class ScanRange {
public:
	ScanRange(int num);
	ScanRange(int num, ScanRangeType** ranges);
	~ScanRange();

	int getScanRangeNumber();
	ScanRangeType* getScanRangeAt(int i);
	ScanRangeType* getScanRange();
	
	/**
	* Setting Methods
	* 
	* The following methods set value to variables in ScanRange
	*/
	void setScanRangeNumber(int num);
	void setScanRangeAt(int i, ScanRangeType* range);

	/**
	* Process Method
	*
	* Sort the ranges in the ScanRange, also merge them if two/more ranges have overlap. 
	* The final result is a list of ranges that don't have any overlap between them, and are ordered by the start key.
	* The resulting ScanRange should represent the same scan restriction as the original ScanRange. 
	*/
	void sortScanRange();
	
	/**
	* Process Method
	* 
	* Change the ScanRange by cutting it with another range, leaving only the scan ranges that fall into the curring range.
	*
	* @param startkey/endkey The boundary of the cutting range
	*/	
	void cutScanRange(KeyType startkey, KeyType endkey);

	/**
	* Process Method
	* 
	* Check whether a node falls into the ranges.
	* 
	* Given the key of a node, find out whether this node is in the scan range
	* 
	* @param startkey The key of the node
	* @returns A boolean value which indicate whether the node is in the scan ranges. 
	*/
	bool inScanRange(KeyType startkey);

private:
	/**
	* Number of ranges in the ScanRanges
	*/
	int rangeNum;
	
	/**
	* The list of scan ranges
	*/
	ScanRangeType* ranges;

	/**
	* A boolean variable which indicate whether the ranges are sorted or not. 
	*/
	bool sorted;
};

#endif
