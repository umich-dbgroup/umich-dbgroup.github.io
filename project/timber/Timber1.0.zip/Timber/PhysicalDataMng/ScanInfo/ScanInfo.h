/*
COPYRIGHT  (c) 2000-2004 
THE REGENTS OF THE UNIVERSITY OF MICHIGAN
ALL RIGHTS RESERVED

PERMISSION IS GRANTED TO USE, COPY, CREATE DERIVATIVE WORKS AND
REDISTRIBUTE THIS SOFTWARE AND SUCH DERIVATIVE WORKS FOR NONCOMMERCIAL
EDUCATION AND RESEARCH PURPOSES, SO LONG AS NO FEE IS CHARGED, AND SO LONG
AS THE COPYRIGHT NOTICE ABOVE, THIS GRANT OF PERMISSION, AND THE
DISCLAIMER BELOW APPEAR IN ALL COPIES MADE; AND SO LONG AS THE NAME OF THE
UNIVERSITY OF MICHIGAN IS NOT USED IN ANY ADVERTISING OR PUBLICITY
PERTAINING TO THE USE OR DISTRIBUTION OF THIS SOFTWARE WITHOUT SPECIFIC,
WRITTEN PRIOR AUTHORIZATION.

THIS SOFTWARE IS PROVIDED AS IS, WITHOUT REPRESENTATION FROM THE
UNIVERSITY OF MICHIGAN AS TO ITS FITNESS FOR ANY PURPOSE, AND WITHOUT
WARRANTY BY THE UNIVERSITY OF MICHIGAN OF ANY KIND, EITHER EXPRESS OR
IMPLIED, INCLUDING WITHOUT LIMITATION THE IMPLIED WARRANTIES OF
MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE. THE REGENTS OF THE
UNIVERSITY OF MICHIGAN SHALL NOT BE LIABLE FOR ANY DAMAGES, INCLUDING
SPECIAL, INDIRECT, INCIDENTAL, OR CONSEQUENTIAL DAMAGES, WITH RESPECT TO
ANY CLAIM ARISING OUT OF OR IN CONNECTION WITH THE USE OF THE SOFTWARE,
EVEN IF IT HAS BEEN OR IS HEREAFTER ADVISED OF THE POSSIBILITY OF SUCH
DAMAGES.
*/

/**
 * @author Yuqing (Melanie) Wu
 */

#ifndef __ScanInfo_H
#define __ScanInfo_H

#include "SelectionCondition.h"

/**
* class ScanInfo
*
* This class is an item in ScanMap that keeps the information for a single scan
*
* TRICK: the number of total result maybe too large to store in memory
*		and it is not efficient to scan one node at the time when fetchnext() is called
*		my decision is to scan a certain number of node at a time, and store
*		the results in ResultList. 
*		scan is resumed when the list is empty (at the beginning, or when all results
*		has been fetched).
*
* @see SelectionCondition
* @see ScanMap
*/
class ScanInfo  
{
public:
	/**
	* Constructor
	*
	* Consttruct an instance of ScanInfo with the information about a scan
	* 
	*@param fileinfo The information about the XML document (in database) scanned. It is an instance of the FileInfoType.
	*@param scancond The scan condition. Each node within the scan range is checked with the condition and only the ones that satisfy the condition belongs to the scan result. 
	*@param scanmethod Left for later usage
	*@param nodekey The key of the node which is the root of the subtree to be scanned.
	*@param endkeyboundary The key that is the end boundary for the scan. This is usually the end key of the node whose key is nodekey. In case the scan range is set, the end boundary should be set to the end boundary of the last range. 
	*@param minlevel, maxlevel The level range of nodes to be scanned. 
	*@param scanrange A set of key intervals which specifies that only nodes fall in the ranges are to be checked.
	*@param rangecursor A pointer to the scanrange which indicate nodes in which range are under examining. 
	*@param scanhandler The Shore/BerkeleyDB scan handler that does linear scan of the data file. 
	*/	
	ScanInfo(FileInfoType* fileinfo, 
		SelectionCondition* scancond, 
		int scanmethod, 
		KeyType nodekey, 
		KeyType endkey, 
		int minlevel, 
		int maxlevel, 
		ScanRange* scanrange,
		int rangeCursor, 
		scan_file_i* scanhandler,
		bool inOverflow = false,
		bool considerOverflow = true);

	/**
	* Destructor
	*
	* Free the space taken by the scan condition, scan range, and release scan handler
	**/
	virtual ~ScanInfo();

	/**
	* Access Method
	* Get the information of the file being scanned.
	* @returns the instance of FileInfoType which contains the inforamtion of the data file. 
	*/
	FileInfoType* getFileInfo();

	/**
	* Access Method
	*
	* Get the scan condition of the scan.
	* @returns the scan condition of the scan
	*/
	SelectionCondition*	getScanCond();

	/**
	* Access Method
	*
	* Get the scan range of the scan.
	* @returns the scan range of the scan
	*/
	ScanRange* getScanRange();

	/**
	* Access Method
	*
	* Get the scan range cursor of the scan.
	* @returns the scan range cursor of the scan
	*/
	int getRangeCursor();

	/**
	* Access Method
	*
	* Get the scan method of the scan.
	* @returns the scan method of the scan
	*/
	int getScanMethod();
	
	/**
	* Access Method
	*
	* Get the minimum level of the nodes that can be result of the scan 
	* @returns the minimum level of the nodes that can be result of the scan. 
	*/
	int getScanMinLevel();
	
	/**
	* Access Method
	*
	* Get the maximum level of the nodes that can be result of the scan 
	* @returns the maximum level of the nodes that can be result of the scan. 
	*/
	int getScanMaxLevel();

	/**
	* Access Method
	*
	* Get the boundary of the end key of the scan.
	* @returns the boundary of the end key of the scan
	*/
	KeyType getEndKeyBoundary();
	KeyType getStartKeyBoundary();

	/**
	* Access Method
	* Get the scan handler of shore/berkeleyDB for the scan.
	* @returns The scan handler.
	*/
	scan_file_i* getScanHandler();

	/** 
	* Access Method
	*
	* Report whether the scan is currently scanning in the overflow section.
	*
	*@returns A boolean value which indicate whether the scan is currently scanning in the overflow section.
	*/
	bool isScanningInOverflowSection();

	bool shouldScanOverflow();

	/**
	* Set Method
	*
	* Set the range cursor, a pointer which indicate which range should consider
	*
	* @param cursor The range cursor
	*/

	void setRangeCursor(const int cursor);

	/**
	* Set Method
	*
	* Set the scan handler
	*
	*@param scanhandler The Shore scan handler
	*@param inoverflow	Whether the current scan handler is scanning the overflow section
	*/
	void setScanHandler(scan_file_i* scanhandler, bool inoverflow);


private:

	/**
	* Information about the file that is scanned
	*/
	FileInfoType* fileinfo; 

	/**
	* Scan condition
	*/
	SelectionCondition* scanCond;
	
	/**
	* scan method   (reserved for later use)
	*/
	int scanMethod;

	/**
	* A variable used to keep track of the end boundary.
	* Usually, itis the end key of the subtree root
	*/
	KeyType endKeyBoundary;
	KeyType startKeyBoundary;

	/**
	* the minimum level of nodes to be scanned
	*/
	int minLevel;
	
	/**
	* the maximum level of nodes to be scanned
	*/
	int maxLevel;
	
	/**
	* Scan range, define by a list of ranges of key value.
	* Only nodes which falls into at least one of the range can be scan result
	*/
	ScanRange* scanRange;
	
	/**
	* Cursor that moves in the list of scan range,
	* which indicate which range we should check the nodes with
	* Check scan condition only on the node that falls into the current range
	* Cursor moves on when the new nodes does not fall in the current range
	*/
	int rangeCursor;

	/**
	* scan handler of SHORE/BerkeleyDB
	*/
	scan_file_i* scanHandler;

	/**
	* a flag that indicate whether the scan handler is scaning in the overflow section or not
	*/
	bool inOverflowSection;
	bool considerOverflow;
};

#endif
