/*
COPYRIGHT  (c) 2000-2004 
THE REGENTS OF THE UNIVERSITY OF MICHIGAN
ALL RIGHTS RESERVED

PERMISSION IS GRANTED TO USE, COPY, CREATE DERIVATIVE WORKS AND
REDISTRIBUTE THIS SOFTWARE AND SUCH DERIVATIVE WORKS FOR NONCOMMERCIAL
EDUCATION AND RESEARCH PURPOSES, SO LONG AS NO FEE IS CHARGED, AND SO LONG
AS THE COPYRIGHT NOTICE ABOVE, THIS GRANT OF PERMISSION, AND THE
DISCLAIMER BELOW APPEAR IN ALL COPIES MADE; AND SO LONG AS THE NAME OF THE
UNIVERSITY OF MICHIGAN IS NOT USED IN ANY ADVERTISING OR PUBLICITY
PERTAINING TO THE USE OR DISTRIBUTION OF THIS SOFTWARE WITHOUT SPECIFIC,
WRITTEN PRIOR AUTHORIZATION.

THIS SOFTWARE IS PROVIDED AS IS, WITHOUT REPRESENTATION FROM THE
UNIVERSITY OF MICHIGAN AS TO ITS FITNESS FOR ANY PURPOSE, AND WITHOUT
WARRANTY BY THE UNIVERSITY OF MICHIGAN OF ANY KIND, EITHER EXPRESS OR
IMPLIED, INCLUDING WITHOUT LIMITATION THE IMPLIED WARRANTIES OF
MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE. THE REGENTS OF THE
UNIVERSITY OF MICHIGAN SHALL NOT BE LIABLE FOR ANY DAMAGES, INCLUDING
SPECIAL, INDIRECT, INCIDENTAL, OR CONSEQUENTIAL DAMAGES, WITH RESPECT TO
ANY CLAIM ARISING OUT OF OR IN CONNECTION WITH THE USE OF THE SOFTWARE,
EVEN IF IT HAS BEEN OR IS HEREAFTER ADVISED OF THE POSSIBILITY OF SUCH
DAMAGES.
*/

/**
 * @author Yuqing (Melanie) Wu
 */

#include "SelectionCondition.h"
#include "../../Utilities/ErrorInfoClass.h"
extern ErrorInfoClass globalErrorInfo;

/**
* class SelectionCondition
* 
* This class represent a selection condition, which is used in scan, buidling index, creating histogram, etc. 
*
* A selection condition is stored in a CNF, which is in form like (A AND B) OR (C AND D), where A,B,C,D are 
* all predicates. 
*
* This class provide functions that deals with storing, accessing, wrapping/unwrapping, validating and comparason of
* selection conditions. 
* 
* @see PredicateCondition
* @see ConjunctiveCondition
* @see DisjunctiveCondition
* @see PhysicalDataMng::startScan
* @see PhysicalDataMng::checkCond
*/

/**
* Constructor
* Construct a blank selection condition
*/
SelectionCondition::SelectionCondition()
{
	this->condition = NULL;
}

/**
* Constructor
* Construct a selection condition with the given node type, condition and return type
*
* @param nodetype The type of node where the condition is to be applied on. 
* @param cond The condition in CNF form. 
* @param returntype The node to be returned when condition is satisfied. Note that a node may
*		be returned as result when its relative node satisfy a certain condition. 
*/
SelectionCondition::SelectionCondition(int nodetype, DisjunctiveCondition* cond, int returntype)
{
	this->nodeType = nodetype;
	this->condition = cond;
	this->returnType = returntype;
}

/**
* Constructor
* Construct an instance of the SelectionCondition using information wrapped in a string
* @ param buffer The string that contains information about the selection condition
*/

SelectionCondition::SelectionCondition(char* buffer)
{
	memcpy(&(this->nodeType), buffer, sizeof(int));
	memcpy(&(this->returnType), buffer+sizeof(int), sizeof(int));
	
	int len;
	memcpy(&len, buffer+sizeof(int)*2, sizeof(int));

	// unwrap the condition
	if (len == 0)
		this->condition = NULL;
	else 
		this->condition = new DisjunctiveCondition(buffer+sizeof(int)*3);
}

/**
* Constructor
* Construct an instance of the SelectionCondition by copying from another instance
* @ param cond The selection condition to be copied.
*/
SelectionCondition::SelectionCondition(SelectionCondition* cond)
{
	this->nodeType = cond->getNodeType();
	this->condition = new DisjunctiveCondition(cond->getCondition());
	this->returnType = cond->getReturnType();
}

/**
* Destructor
* Release the space taking by the condition
*/
SelectionCondition::~SelectionCondition()
{
	if (this->condition != NULL) {
		delete this->condition;
		condition = NULL;
	}
}

/**
* Access Methods
* Get the component of the SelectionCondition
*/
int SelectionCondition::getNodeType()
{
	return this->nodeType;
}

DisjunctiveCondition* SelectionCondition::getCondition()
{
	return this->condition;
}

int SelectionCondition::getReturnType()
{
	return this->returnType;
}

/**
* Set Methods
* Set the component of the SelectionCondition
*/
void SelectionCondition::setNodeType(int nodetype)
{
	this->nodeType = nodetype;
}

void SelectionCondition::setCondition(DisjunctiveCondition* cond)
{
	this->condition = cond;
}

void SelectionCondition::setReturnType(int returntype)
{
	this->returnType = returntype;
}

/**
* Process Method
* Match  two SelectionCondition, finding out whether they have certain inclusion relationship.
*
* @param cond The SelectionCondition to be compared with the SelectionCondition represented by the instance. 
* @returns A code which indicate the relationship between the two SelectionCondition.
*/
int SelectionCondition::matchSelectionCondition(SelectionCondition* cond)
{
	if (this->returnType != cond->returnType)
	{
		// if the return node is different, the two selection conditions
		// are not comparable
		return SELECTION_COND_NOT_MATCH;
	}

	// for the conditions whose return type are the same, consider the 
	// node type on which the condition would apply
	if (((this->nodeType != SCAN_ALLNODES) && (cond->nodeType != SCAN_ALLNODES)) ||
		((this->nodeType != SCAN_ALLNODES) && (cond->nodeType != SCAN_ALLNODES)))
	{
		// when the node scope are either overlap or interleave.
		if (this->nodeType != cond->nodeType)
		{
			// if two selection condition are defined on different kinds of nodes 
			// can not compare them. 
			return SELECTION_COND_NOT_MATCH;
		}
		
		if (this->nodeType == cond->nodeType)
		{
			// when the nodetype and returntype are all the same, 
			// the relation of the two selection condition is determined
			// by the relation of the condition itself.
			return matchCondition(this->condition, cond->condition);
		}
	}

	if ((this->nodeType == SCAN_ALLNODES) && (cond->nodeType != SCAN_ALLNODES))
	{
		int rel = matchCondition(this->condition, cond->condition);
		switch (rel)
		{
		case SELECTION_COND_FULL_MATCH:
			return SELECTION_COND_SUPERSET_MATCH;

		case SELECTION_COND_SUBSET_MATCH:
			return SELECTION_COND_SUBSET_MATCH;

		case SELECTION_COND_SUPERSET_MATCH:
			return SELECTION_COND_SUPERSET_MATCH;

		case SELECTION_COND_NOT_MATCH:
			return SELECTION_COND_NOT_MATCH;

		default:
			break;
		}
	}

	if ((this->nodeType != SCAN_ALLNODES) && (cond->nodeType == SCAN_ALLNODES))
	{
		int rel = matchCondition(this->condition, cond->condition);
		switch (rel)
		{
		case SELECTION_COND_FULL_MATCH:
			return SELECTION_COND_SUBSET_MATCH;

		case SELECTION_COND_SUBSET_MATCH:
			return SELECTION_COND_SUBSET_MATCH;

		case SELECTION_COND_SUPERSET_MATCH:
			return SELECTION_COND_SUPERSET_MATCH;

		case SELECTION_COND_NOT_MATCH:
			return SELECTION_COND_NOT_MATCH;

		default:
			break;
		}
	}

	return SELECTION_COND_NOT_MATCH;
}

/**
* Process Method
* Validate a SelectionCondition.
* The validation not considers the condition, but also the nodetype and return value specification. 
* 
* @returns A boolean value which indicate whether the condition is valid or not
*/
bool SelectionCondition::isValid()
{
	// check whether nodetype is valid 
	if (!((this->nodeType == SCAN_ALLNODES) || (this->nodeType == DOCUMENT_NODE) |
		(this->nodeType == ELEMENT_NODE) || (this->nodeType == ATTRIBUTE_NODE) |
		(this->nodeType == TEXT_NODE) || (this->nodeType == COMMENT_NODE) |
		(this->nodeType == CHAR_NODE)))
	{
        globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"SelectionCondition::isValid",__FILE__,"Invalid return node type");
		return false;
	}

	// check whether the return value specification is valid
	if (!((this->returnType == SCAN_RETURN_THISNODE) || (this->returnType == SCAN_RETURN_PARENTNODE) |
		(this->returnType == SCAN_RETURN_ELEMENTNODE) || (this->returnType == SCAN_RETURN_ATTRIBUTENODE) |
		(this->returnType == SCAN_RETURN_SUBTREE)))
	{
        globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"SelectionCondition::isValid",__FILE__,"Invalid return node type");
		return false;
	}

	// check whether the condition is valid. 
	if (this->condition == NULL)
		return true;
	else
		return this->condition->isValid(this->nodeType);
}

/**
* Process Method
* Match two SelectionCondition, allowing one or both of them to be NULL
* @returns Code which indicate the relationship of the two SelectionCondition. 
*/
int SelectionCondition::matchCondition(DisjunctiveCondition* cond1, DisjunctiveCondition* cond2)
{
	if ((cond1 == NULL) && (cond2 == NULL))
		return SELECTION_COND_FULL_MATCH;

	if ((cond1 == NULL) && (cond2 != NULL))
		return SELECTION_COND_SUPERSET_MATCH;

	if ((cond1 != NULL) && (cond2 == NULL))
		return SELECTION_COND_SUBSET_MATCH;

	if ((cond1 != NULL) && (cond2 != NULL))
		return cond1->matchDisjunctiveCondition(cond2);

	return SELECTION_COND_NOT_MATCH;
}

/**
* Process Method
* Wrap the SelectionCondition into a string.
* 
* @param bufferlength The length of the result string which contains the information about the SelectionCondition.
* @returns The result string which contains the information about the SelectionCondition.
*/
char* SelectionCondition::wrap(int* bufferlength)
{
	char* buffer;
	int size = 0;
	char* condbuffer = NULL;
	int condlength;

	// wrap the condition. 
	if (this->condition == NULL)
		condlength = 0;
	else 
		condbuffer = this->condition->wrap(&condlength);

	// compute the size of the result string
	size = condlength + 3*sizeof(int);

	buffer = new char[size];

	// node type
	memcpy(buffer, &(this->nodeType), sizeof(int));

	// return type
	memcpy(buffer+sizeof(int), &(this->returnType), sizeof(int));

	// length of the condition string
	memcpy(buffer+sizeof(int)*2, &condlength, sizeof(int));

	// the string for the condition
	if (condlength > 0)
		memcpy(buffer+sizeof(int)*3, condbuffer, condlength);

	if (condlength != NULL) delete condbuffer;
	*bufferlength = size;
	return buffer;
}
	
/**
* Debug Method
* Print the content of the SelectionCondition.
*/
void SelectionCondition::printSelectionCondition()
{
	cout << "Selection Condition:" << endl;
	cout << "Node Type: ";
	switch (this->nodeType)
	{
	case SCAN_ALLNODES:
		cout << "ALL nodes";
		break;
	case DOCUMENT_NODE:
		cout << "Document nodes";
		break;
	case ELEMENT_NODE:
		cout << "Element nodes";
		break;
	case ATTRIBUTE_NODE:
		cout << "Attribute nodes";
		break;
	case TEXT_NODE:
		cout << "Text nodes";
		break;
	case COMMENT_NODE:
		cout << "Comment nodes";
		break;
	case CHAR_NODE:
		cout << "Char nodes";
		break;
	}
	cout << "" << endl;

	cout << "Return Node Type: ";
	switch (this->returnType)
	{
	case SCAN_RETURN_THISNODE:
		cout << "This node";
		break;
	case SCAN_RETURN_PARENTNODE:
		cout << "Parent node";
		break;
	case SCAN_RETURN_ELEMENTNODE:
		cout << "Element node";
		break;
	case SCAN_RETURN_ATTRIBUTENODE:
		cout << "Attribute node";
		break;
	}
	cout << "" << endl;

	if (condition != NULL)
		this->condition->printDisjunctiveCondition();
	else cout << "condition = NULL" << endl;
}
