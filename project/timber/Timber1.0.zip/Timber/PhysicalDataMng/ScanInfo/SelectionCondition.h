/*
COPYRIGHT  (c) 2000-2004 
THE REGENTS OF THE UNIVERSITY OF MICHIGAN
ALL RIGHTS RESERVED

PERMISSION IS GRANTED TO USE, COPY, CREATE DERIVATIVE WORKS AND
REDISTRIBUTE THIS SOFTWARE AND SUCH DERIVATIVE WORKS FOR NONCOMMERCIAL
EDUCATION AND RESEARCH PURPOSES, SO LONG AS NO FEE IS CHARGED, AND SO LONG
AS THE COPYRIGHT NOTICE ABOVE, THIS GRANT OF PERMISSION, AND THE
DISCLAIMER BELOW APPEAR IN ALL COPIES MADE; AND SO LONG AS THE NAME OF THE
UNIVERSITY OF MICHIGAN IS NOT USED IN ANY ADVERTISING OR PUBLICITY
PERTAINING TO THE USE OR DISTRIBUTION OF THIS SOFTWARE WITHOUT SPECIFIC,
WRITTEN PRIOR AUTHORIZATION.

THIS SOFTWARE IS PROVIDED AS IS, WITHOUT REPRESENTATION FROM THE
UNIVERSITY OF MICHIGAN AS TO ITS FITNESS FOR ANY PURPOSE, AND WITHOUT
WARRANTY BY THE UNIVERSITY OF MICHIGAN OF ANY KIND, EITHER EXPRESS OR
IMPLIED, INCLUDING WITHOUT LIMITATION THE IMPLIED WARRANTIES OF
MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE. THE REGENTS OF THE
UNIVERSITY OF MICHIGAN SHALL NOT BE LIABLE FOR ANY DAMAGES, INCLUDING
SPECIAL, INDIRECT, INCIDENTAL, OR CONSEQUENTIAL DAMAGES, WITH RESPECT TO
ANY CLAIM ARISING OUT OF OR IN CONNECTION WITH THE USE OF THE SOFTWARE,
EVEN IF IT HAS BEEN OR IS HEREAFTER ADVISED OF THE POSSIBILITY OF SUCH
DAMAGES.
*/

/**
 * @author Yuqing (Melanie) Wu
 */

#ifndef __SelectionCondition_H
#define __SelectionCondition_H

#include "DisjunctiveCondition.h"
#include "ScanRange.h"

/**
* class SelectionCondition
* 
* This class represent a selection condition, which is used in scan, buidling index, creating histogram, etc. 
*
* A selection condition is stored in a CNF, which is in form like (A AND B) OR (C AND D), where A,B,C,D are 
* all predicates. 
*
* This class provide functions that deals with storing, accessing, wrapping/unwrapping, validating and comparason of
* selection conditions. 
* 
* @see PredicateCondition
* @see ConjunctiveCondition
* @see DisjunctiveCondition
* @see PhysicalDataMng::startScan
* @see PhysicalDataMng::checkCond
*/
class SelectionCondition 
{
public:
	/**
	* Constructor
	* Construct a blank selection condition
	*/	
	SelectionCondition();
	
	/**
	* Constructor
	* Construct a selection condition with the given node type, condition and return type
	*
	* @param nodetype The type of node where the condition is to be applied on. 
	* @param cond The condition in CNF form. 
	* @param returntype The node to be returned when condition is satisfied. Note that a node may
	*		be returned as result when its relative node satisfy a certain condition. 
	*/
	SelectionCondition(int nodetype, DisjunctiveCondition* cond, int returntype);

	/**
	* Constructor
	* Construct an instance of the SelectionCondition using information wrapped in a string
	* @ param buffer The string that contains information about the selection condition
	*/
	SelectionCondition(char* buffer);

	/**
	* Constructor
	* Construct an instance of the SelectionCondition by copying from another instance
	* @ param cond The selection condition to be copied.
	*/
	SelectionCondition(SelectionCondition* cond);

	/**
	* Destructor
	* Release the space taking by the condition
	*/
	~SelectionCondition();

	/**
	* Access Methods
	* Get the component of the SelectionCondition
	*/	
	int getNodeType();
	DisjunctiveCondition* getCondition();
	int getReturnType();

	/**
	* Set Methods
	* Set the component of the SelectionCondition
	*/
	void setNodeType(int nodetype);
	void setCondition(DisjunctiveCondition* cond);
	void setReturnType(int returntype);

	/**
	* Process Method
	* Validate a SelectionCondition.
	* The validation not considers the condition, but also the nodetype and return value specification. 
	* 
	* @returns A boolean value which indicate whether the condition is valid or not
	*/
	bool isValid();

	/**
	* Process Method
	* Match  two SelectionCondition, finding out whether they have certain inclusion relationship.
	*
	* @param cond The SelectionCondition to be compared with the SelectionCondition represented by the instance. 
	* @returns A code which indicate the relationship between the two SelectionCondition.
	*/	
	int matchSelectionCondition(SelectionCondition* cond);
	
	/**
	* Process Method
	* Wrap the SelectionCondition into a string.
	* 
	* @param bufferlength The length of the result string which contains the information about the SelectionCondition.
	* @returns The result string which contains the information about the SelectionCondition.
	*/
	char* wrap(int* bufferlength);

	/**
	* Debug Method
	* Print the content of the SelectionCondition.
	*/
	void printSelectionCondition();

private:
	/**
	* The type of nodes to be matched with the condition.
	* It can be one of the following:
	* ALLNODES, DOCUMENT_NODE, ELEMENT_NODE, ATTRIBUTE_NODE, 
	* TEXT_NODE, COMMENT_NODE...
	*/
	int nodeType;
	
	/**
	* Scan condition in CNF.
	*/
	DisjunctiveCondition* condition;
	
	/**
	* The node(s) to return. It can be one of the following value:
	* THISNODE, PARENTNODE, ELEMENTNODE, ATTRIBUTENODE, SUBTREE
	*/
	int returnType;

	/**
	* Process Method
	* Match two SelectionCondition, allowing one or both of them to be NULL
	* @returns Code which indicate the relationship of the two SelectionCondition. 
	*/	
	int matchCondition(DisjunctiveCondition* cond1, DisjunctiveCondition* cond2);
};

#endif
