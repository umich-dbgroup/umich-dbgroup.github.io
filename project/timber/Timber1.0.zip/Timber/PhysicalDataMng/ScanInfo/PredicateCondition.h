/*
COPYRIGHT  (c) 2000-2004 
THE REGENTS OF THE UNIVERSITY OF MICHIGAN
ALL RIGHTS RESERVED

PERMISSION IS GRANTED TO USE, COPY, CREATE DERIVATIVE WORKS AND
REDISTRIBUTE THIS SOFTWARE AND SUCH DERIVATIVE WORKS FOR NONCOMMERCIAL
EDUCATION AND RESEARCH PURPOSES, SO LONG AS NO FEE IS CHARGED, AND SO LONG
AS THE COPYRIGHT NOTICE ABOVE, THIS GRANT OF PERMISSION, AND THE
DISCLAIMER BELOW APPEAR IN ALL COPIES MADE; AND SO LONG AS THE NAME OF THE
UNIVERSITY OF MICHIGAN IS NOT USED IN ANY ADVERTISING OR PUBLICITY
PERTAINING TO THE USE OR DISTRIBUTION OF THIS SOFTWARE WITHOUT SPECIFIC,
WRITTEN PRIOR AUTHORIZATION.

THIS SOFTWARE IS PROVIDED AS IS, WITHOUT REPRESENTATION FROM THE
UNIVERSITY OF MICHIGAN AS TO ITS FITNESS FOR ANY PURPOSE, AND WITHOUT
WARRANTY BY THE UNIVERSITY OF MICHIGAN OF ANY KIND, EITHER EXPRESS OR
IMPLIED, INCLUDING WITHOUT LIMITATION THE IMPLIED WARRANTIES OF
MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE. THE REGENTS OF THE
UNIVERSITY OF MICHIGAN SHALL NOT BE LIABLE FOR ANY DAMAGES, INCLUDING
SPECIAL, INDIRECT, INCIDENTAL, OR CONSEQUENTIAL DAMAGES, WITH RESPECT TO
ANY CLAIM ARISING OUT OF OR IN CONNECTION WITH THE USE OF THE SOFTWARE,
EVEN IF IT HAS BEEN OR IS HEREAFTER ADVISED OF THE POSSIBILITY OF SUCH
DAMAGES.
*/

/**
 * @author Yuqing (Melanie) Wu
 */

#ifndef __PredicateCondition_H
#define __PredicateCondition_H

#include "stdlib.h"
#include "stdio.h"
#include "../stdafx.h"

// scan node type
#define SCAN_ALLNODES						10

// left value of predicate
#define SCAN_LEFTVALUE_VALUE				0
#define SCAN_LEFTVALUE_LENGTH				1
#define SCAN_LEFTVALUE_XMLFILENAME			2
#define SCAN_LEFTVALUE_DTDFILENAME			3
#define SCAN_LEFTVALUE_NODETAG				4
#define SCAN_LEFTVALUE_CHILDNUMBER			5
#define SCAN_LEFTVALUE_ATTRIBUTENUMBER		6
#define SCAN_LEFTVALUE_HASCHILD				7
#define SCAN_LEFTVALUE_HASATTRIBUTE			8
#define SCAN_LEFTVALUE_ELEMENTCONTENT		9

// operator in predicate
#define SCAN_OP_LT					VALUE_COMP_OP_LT	
#define SCAN_OP_LE					VALUE_COMP_OP_LE				
#define SCAN_OP_GT					VALUE_COMP_OP_GT				
#define SCAN_OP_GE					VALUE_COMP_OP_GE				
#define SCAN_OP_EQ					VALUE_COMP_OP_EQ				
#define SCAN_OP_NE					VALUE_COMP_OP_NE				
#define SCAN_OP_CONTAINS			VALUE_COMP_OP_CONTAINS		
#define SCAN_OP_CONTAINEDBY			VALUE_COMP_OP_CONTAINEDBY	
#define SCAN_OP_STARTWITH			VALUE_COMP_OP_STARTWITH		

// right value of predicate
#define SCAN_RETURN_THISNODE			0
#define SCAN_RETURN_PARENTNODE			1
#define SCAN_RETURN_ELEMENTNODE			2
#define SCAN_RETURN_ATTRIBUTENODE		3
#define SCAN_RETURN_SUBTREE				4

#define SELECTION_COND_FULL_MATCH		0
#define SELECTION_COND_SUBSET_MATCH		1
#define SELECTION_COND_SUPERSET_MATCH	2	
#define SELECTION_COND_NOT_MATCH		3

/**
* PredicateCondition
* 
* A Predicate, which contains a left value, a right value and a comparason operator, is the smallest unit for
* a selection condition. 
* 
* This class provide the storage, access, validation, wrapping/unwrapping of a predicate. 
* 
* @see SelectionCondition
*/
class PredicateCondition 
{
friend class Value;

public:
	/**
	* Constructor
	* For a blank predicate
	*/
	PredicateCondition();

	/**
	* Constructor
	* Initialize a predicate with the given left value, operator and right value
	*/
	PredicateCondition(int leftval, int op, Value* rightval);

	/**
	* Constructor
	* Create an instance of the PredicateCondition, using the information wrapped in a string
	* @param buffer The string that contains the information about the predicate. 
	*/
	PredicateCondition(char* buffer);

	/**
	* Constructor
	* Create an instance of the PredicateCondition, by copying info from another instance.
	* @param predicate The predicate condition to be copied. 
	*/
	PredicateCondition(PredicateCondition* predicate);

	/**
	* Destructor
	* Release space taken by the right value.
	*/
	~PredicateCondition();

	/**
	* Access Method
	* Get the information of left value, operator and right value
	*/
	int getLeftValue();
	int getOperator();
	Value* getRightValue();
	
	/**
	* Set Methods
	* Set the values for left value, operator and right value
	*/
	void setLeftValue(int leftval);
	void setOperator(int op);
	void setRightValue(Value* rightval);
	
	/**
	* Process Method
	* Validate the predicate. 
	* 
	* @param nodeType The type of node that predicate is to be applied on.
	* @returns A boolean value that indicate whether the predicate is valid, based on whether the
	*		node type, the left value, the operator and the right values can go with each other.
	*/
	bool isValid(int nodeType);

	/**
	* Process Method
	* Given two predicate, compare them and find out whether they have any inclusion relationship. 
	* 
	* @param pred The predicate to be compared with the predicate represented by this class. 
	* @returns code that indicate the relationship between the predicates. It can be: 
	*		SELECTION_COND_FULL_MATCH	
	*		SELECTION_COND_SUBSET_MATCH	
	*		SELECTION_COND_SUPERSET_MATCH
	*		SELECTION_COND_NOT_MATCH
	*/
	int matchPredicateCondition(PredicateCondition* pred);
		
	/**
	* Process Method\
	* Wrap the content of the predicate into a string
	* @param bufferlength The length of the result string (return value)
	* @return The string that contains information bout the predicate.
	*/
	char* wrap(int* bufferlength);

	/**
	* Debug Methods
	* Print the predicate.
	*/
	void printPredicateCondition();

private:
	/**
	* The left value of the predicate, it can be one of the following
	* VALUE, LENGTH, XMLFILENAME, DTDFILENAME, NODETAG, CHILDNUMBER,
	* ATTRIBUTENUMBER, HASCHILD, HASATTRIBUTE
	* if it is none of the above, it is a pointer to the string (char*) which contains the attribute name.
	*/
	int leftValue;

	/**
	* The operator of the predicate, it can be one of the following:
	* LT, LE,ST, SE, EQ, NE, CONTAIN, CONTAINEDBY, STARTWITH
	*/
	int predicateOperator;

	/**
	* The right value of the predicate, it is an instance of the Value class
	*/
	Value* rightValue;

	/**
	* Debug Methods
	* Print the predicate.
	*/
	void printLeftValue();
	void printOperator();
	void printRightValue();

};

#endif
