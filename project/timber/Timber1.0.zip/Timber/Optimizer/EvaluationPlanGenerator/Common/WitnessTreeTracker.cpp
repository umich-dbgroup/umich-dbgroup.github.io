/**  
COPYRIGHT  � 2000-2004
THE REGENTS OF THE UNIVERSITY OF MICHIGAN ALL RIGHTS RESERVED

PERMISSION IS GRANTED TO USE, COPY, CREATE DERIVATIVE WORKS A
ND REDISTRIBUTE THIS SOFTWARE AND SUCH DERIVATIVE WORKS FOR 
NONCOMMERCIAL EDUCATION AND RESEARCH PURPOSES, SO LONG AS NO 
FEE IS CHARGED, AND SO LONG AS THE COPYRIGHT NOTICE ABOVE, 
THIS GRANT OF PERMISSION, AND THE DISCLAIMER BELOW APPEAR IN 
ALL COPIES MADE; AND SO LONG AS THE NAME OF THE UNIVERSITY OF 
MICHIGAN IS NOT USED IN ANY ADVERTISING OR PUBLICITY PERTAINING 
TO THE USE OR DISTRIBUTION OF THIS SOFTWARE WITHOUT SPECIFIC, 
WRITTEN PRIOR AUTHORIZATION.

THIS SOFTWARE IS PROVIDED AS IS, WITHOUT REPRESENTATION FROM 
THE UNIVERSITY OF MICHIGAN AS TO ITS FITNESS FOR ANY PURPOSE, 
AND WITHOUT WARRANTY BY THE UNIVERSITY OF MICHIGAN OF ANY KIND, 
EITHER EXPRESS OR IMPLIED, INCLUDING WITHOUT LIMITATION THE 
IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A 
PARTICULAR PURPOSE. THE REGENTS OF THE UNIVERSITY OF MICHIGAN 
SHALL NOT BE LIABLE FOR ANY DAMAGES, INCLUDING SPECIAL, INDIRECT, 
INCIDENTAL, OR CONSEQUENTIAL DAMAGES, WITH RESPECT TO ANY CLAIM 
ARISING OUT OF OR IN CONNECTION WITH THE USE OF THE SOFTWARE, 
EVEN IF IT HAS BEEN OR IS HEREAFTER ADVISED OF THE POSSIBILITY 
OF SUCH DAMAGES.
*/

#pragma warning(disable:4702)
 
#include "WitnessTreeTracker.h"

WitnessTreeTracker::WitnessTreeTracker(void)
{
}

WitnessTreeTracker::~WitnessTreeTracker(void)
{
}

/**
 * Find out whether a node with the given LCL is in the witness tree.
 *@param wtTree The witness tree.
 *@param lcl The LCL to look for.
 *@returns A boolean value which indicate whether a node with the given LCL is in the witness tree.
 */
bool WitnessTreeTracker::findNode(LCLWTTreeMapType* wtTree, 
								  LCLType lcl)
{
	LCLWTTreeMapType::iterator mapItem;
	
	// do map look up 
	mapItem = wtTree->find(lcl);
	if (mapItem != wtTree->end()) 
		return true;
	else return false;
}


/**
 * Find out whether a node with the given LCL is active in the witness tree.
 *@param wtTree The witness tree.
 *@param lcl The LCL to look for.
 *@returns A boolean value which indicate whether a node with the given LCL is active in the witness tree.
 */
bool WitnessTreeTracker::nodeIsActive(LCLWTTreeMapType* wtTree, 
									  LCLType lcl)
{
	LCLWTTreeMapType::iterator mapItem;
	
	// do map lookup
	mapItem = wtTree->find(lcl);
	if (mapItem != wtTree->end()) 
	{
		WitnessTreeNode wtNode = mapItem->second;
		
		// return the active flag of the node, if it is in the witness tree. 
		return wtNode.isActive();
	}
	// otherwise, return false. 
	else return false;
}

/**
 * given a LCL, find the node type of the node with the given LCL in the witness tree.
 *@param wtTree The witness tree.
 *@param lcl The LCL to look for.
 *@returns The type of the node with the given LCL.
 */
int WitnessTreeTracker
::getWitnessTreeNodeType(LCLWTTreeMapType* wtTree,
						 LCLType lcl)
{
	LCLWTTreeMapType::iterator mapItem;

	// do map lookup
	mapItem = wtTree->find(lcl);
	if (mapItem != wtTree->end())
	{
		// return the node type if it is in the witness tree. 
		WitnessTreeNode wtNode = mapItem->second;
		return wtNode.getNodeType();
	}
	// otherwise, return -1.
	else 
		return -1;
}

/**
 * given a LCL, where the LCL is defined at (PsPt)
 *@param wtTree The witness tree.
 *@param lcl The LCL to look for.
 *@returns The ProcessTreeNodeID and PatterTreeNodeID where the LCL is defined at. 
 */
PsPt WitnessTreeTracker
::getDefineAt(LCLWTTreeMapType* wtTree,
			  LCLType lcl)
{
	PsPt definedAt;
	definedAt.psTreeNodeID = -1;
	definedAt.ptTreeNodeID = -1;

	LCLWTTreeMapType::iterator mapItem;

	// do map lookup
	mapItem = wtTree->find(lcl);
	if (mapItem != wtTree->end())
	{
		// return the node type if it is in the witness tree. 
		WitnessTreeNode wtNode = mapItem->second;
		definedAt = wtNode.getDefinedAt();
	}
	
	return definedAt;
}


/**
 * Given a LCL, get the attribute name attached to the node with the given LCL 
 * in the witness tree, if it is an attribute node. 
 *@param wtTree The witness tree.
 *@param lcl The LCL to look for.
 *@returns The attribute name, or NULL is not such node exists in the witness tree or the node is not an attribute node. 
 */
char* WitnessTreeTracker::getAttrName(LCLWTTreeMapType* wtTree,
									  ProcessTree* psTree,
									  LCLType lcl)
{
	char* attrname = NULL;

	LCLWTTreeMapType::iterator mapItem;

	// do map lookup to find the witness tree node
	mapItem = wtTree->find(lcl);
	if (mapItem != wtTree->end())
	{
		WitnessTreeNode wtNode = mapItem->second;

		if ((wtNode.getNodeType() == WT_ATTRIBUTE_NODE) && wtNode.definedByPtNode())
		{
			ProcessTreeNode* psNode = psTree->getPsNodeWithID(wtNode.getDefinedAt().psTreeNodeID);
			if (psNode == NULL)
			{
				goto exit;
			}

			PatternTreeNode* ptNode;

			switch (psNode->getPsNodeType())
			{
			case PROCESS_TREE_SELECT_NODE:
				ptNode = (PatternTreeNode*) ((ProcessTreeConstructNode*) psNode)->getPatternTree()
							->getNodeWithID(wtNode.getDefinedAt().ptTreeNodeID);
				goto ptselectnode;
			case PROCESS_TREE_JOIN_NODE:
				ptNode = (PatternTreeNode*) ((ProcessTreeJoinNode*) psNode)->getPatternTree()
							->getNodeWithID(wtNode.getDefinedAt().ptTreeNodeID);
				goto ptselectnode;
			case PROCESS_TREE_MLCA_NODE:
				ptNode = (PatternTreeNode*) ((ProcessTreeMLCANode*) psNode)->getPatternTree()
							->getNodeWithID(wtNode.getDefinedAt().ptTreeNodeID);
ptselectnode:
				if (ptNode != NULL)
				{
					if (ptNode->getPtTreeNodeType() == MARKED_PATTERN_TREE_SELECTION_NODE)
					{
						char* attr = ((MarkedPatternTreeSelectionNode*) ptNode)->getAttributeName();

						if (attr != NULL)
						{
							attrname = new char[strlen(attr)+1];
							strcpy(attrname, attr);
						}
					}
				}
			break;
							
			case PROCESS_TREE_CONSTRUCT_NODE:
				{
					ptNode = (PatternTreeNode*) ((ProcessTreeConstructNode*) psNode)->getPatternTree()
							->getNodeWithID(wtNode.getDefinedAt().ptTreeNodeID);
					if (ptNode != NULL)
					{
						if (ptNode->getPtTreeNodeType() == PATTERN_TREE_CONSTRUCT_NODE)
						{
							switch (((PatternTreeConstructNode*) ptNode)->getConstructNodeType())
							{
							case CONSTRUCT_ELEMENT: 
								goto exit;
							case CONSTRUCT_ATTRIBUTE:
								{
									char* attr = ((PatternTreeConstructNode*) ptNode)->getNodeTag();
									attrname = new char[strlen(attr)+1];
									strcpy(attrname, attr);
								}
								break;
							case CONSTRUCT_REFERENCE:
								{
									attrname = this->getAttrName(wtTree, psTree, 
										((PatternTreeConstructNode*) ptNode)->getLCLRefered());
								}
								break;
							}
						}
					}			
				}
				break;

			case PROCESS_TREE_PROJECT_NODE:
			case PROCESS_TREE_DUPLICATE_ELIMINATION_NODE:
			case PROCESS_TREE_AGGREGATE_FUNCTION_NODE:
			case PROCESS_TREE_FILTER_NODE:
			case PROCESS_TREE_SORT_NODE:
			case PROCESS_TREE_SET_NODE:
			case PROCESS_TREE_UPDATE_NODE:
			case PROCESS_TREE_DELETE_NODE:
			case PROCESS_TREE_INSERT_NODE:
				goto exit;
			}
		}
	}
 
exit:
	return attrname; 
}


/**
 * Given a LCL, get the file name as the source of the node with the given LCL 
 * in the witness tree, if it matches to an element/attribute, etc. in an XML 
 * document in the database. 
 *@param wtTree The witness tree.
 *@param lcl The LCL to look for.
 *@returns The file name, or NULL is not such node exists in the witness tree or 
 * the node is a constructed node, via aggragate function, construction, etc. 
 */

char* WitnessTreeTracker::getFileName(LCLWTTreeMapType* wtTree,
									  ProcessTree* psTree,
									  LCLType lcl)
{
	char* fileName = NULL;

	LCLWTTreeMapType::iterator mapItem;

	// do map lookup to find the witness tree node
	mapItem = wtTree->find(lcl);
	if (mapItem != wtTree->end())
	{
		WitnessTreeNode wtNode = mapItem->second;

		if (wtNode.definedByPtNode())
		{
			ProcessTreeNode* psNode = psTree->getPsNodeWithID(wtNode.getDefinedAt().psTreeNodeID);
			if (psNode == NULL)
			{
				goto exit;
			}

			PatternTreeNode* ptNode;

			switch (psNode->getPsNodeType())
			{
			case PROCESS_TREE_SELECT_NODE:
				ptNode = (PatternTreeNode*) ((ProcessTreeConstructNode*) psNode)->getPatternTree()
							->getNodeWithID(wtNode.getDefinedAt().ptTreeNodeID);
				goto ptselectnode;
			case PROCESS_TREE_JOIN_NODE:
				ptNode = (PatternTreeNode*) ((ProcessTreeJoinNode*) psNode)->getPatternTree()
							->getNodeWithID(wtNode.getDefinedAt().ptTreeNodeID);
				goto ptselectnode;
			case PROCESS_TREE_MLCA_NODE:
				ptNode = (PatternTreeNode*) ((ProcessTreeMLCANode*) psNode)->getPatternTree()
							->getNodeWithID(wtNode.getDefinedAt().ptTreeNodeID);
ptselectnode:
				if (ptNode != NULL)
				{
					if (ptNode->getPtTreeNodeType() == MARKED_PATTERN_TREE_SELECTION_NODE)
					{
						char* fname = ((MarkedPatternTreeSelectionNode*) ptNode)->getFileName();

						if (fname != NULL)
						{
							fileName = new char[strlen(fname)+1];
							strcpy(fileName, fname);
						}
					}
				}
			break;
							
			case PROCESS_TREE_CONSTRUCT_NODE:
				{
					ptNode = (PatternTreeNode*) ((ProcessTreeConstructNode*) psNode)->getPatternTree()
							->getNodeWithID(wtNode.getDefinedAt().ptTreeNodeID);
					if (ptNode != NULL)
					{
						if (ptNode->getPtTreeNodeType() == PATTERN_TREE_CONSTRUCT_NODE)
						{
							switch (((PatternTreeConstructNode*) ptNode)->getConstructNodeType())
							{
							case CONSTRUCT_ELEMENT: 
								goto exit;
							case CONSTRUCT_ATTRIBUTE:
								goto exit;
							case CONSTRUCT_REFERENCE:
								{
									char* fname = this->getElementTag(wtTree, psTree, 
										((PatternTreeConstructNode*) ptNode)->getLCLRefered());
									if (fname != NULL)
									{
										fileName = new char[strlen(fname)+1];
										strcpy(fileName, fname);
									}								}
								break;
							}
						}
					}			
				}
				break;

			case PROCESS_TREE_PROJECT_NODE:
			case PROCESS_TREE_DUPLICATE_ELIMINATION_NODE:
			case PROCESS_TREE_AGGREGATE_FUNCTION_NODE:
			case PROCESS_TREE_FILTER_NODE:
			case PROCESS_TREE_SORT_NODE:
			case PROCESS_TREE_SET_NODE:
			case PROCESS_TREE_UPDATE_NODE:
			case PROCESS_TREE_DELETE_NODE:
			case PROCESS_TREE_INSERT_NODE:
				goto exit;
			}
		}
	}

exit:
	return fileName; 
}


/**
 * Given a LCL, get the element tag of the node with the given LCL 
 * in the witness tree, if it is an element node. 
 *@param wtTree The witness tree.
 *@param lcl The LCL to look for.
 *@returns The element tag, or NULL is not such node exists in the witness tree or the node is not an element node. 
 */

char* WitnessTreeTracker::getElementTag(LCLWTTreeMapType* wtTree,
									    ProcessTree* psTree,
									    LCLType lcl)
{
	char* eleTag = NULL;

	LCLWTTreeMapType::iterator mapItem;

	// do map lookup to find the witness tree node
	mapItem = wtTree->find(lcl);
	if (mapItem != wtTree->end())
	{
		WitnessTreeNode wtNode = mapItem->second;

		if ((wtNode.getNodeType() == WT_ELEMENT_NODE) && wtNode.definedByPtNode())
		{
			ProcessTreeNode* psNode = psTree->getPsNodeWithID(wtNode.getDefinedAt().psTreeNodeID);
			if (psNode == NULL)
			{
				goto exit;
			}

			PatternTreeNode* ptNode;

			switch (psNode->getPsNodeType())
			{
			case PROCESS_TREE_SELECT_NODE:
				ptNode = (PatternTreeNode*) ((ProcessTreeConstructNode*) psNode)->getPatternTree()
							->getNodeWithID(wtNode.getDefinedAt().ptTreeNodeID);
				goto ptselectnode;
			case PROCESS_TREE_JOIN_NODE:
				ptNode = (PatternTreeNode*) ((ProcessTreeJoinNode*) psNode)->getPatternTree()
							->getNodeWithID(wtNode.getDefinedAt().ptTreeNodeID);
				goto ptselectnode;
			case PROCESS_TREE_MLCA_NODE:
				ptNode = (PatternTreeNode*) ((ProcessTreeMLCANode*) psNode)->getPatternTree()
							->getNodeWithID(wtNode.getDefinedAt().ptTreeNodeID);
ptselectnode:
				if (ptNode != NULL)
				{
					if (ptNode->getPtTreeNodeType() == MARKED_PATTERN_TREE_SELECTION_NODE)
					{
						char* tag = ((MarkedPatternTreeSelectionNode*) ptNode)->getElementTag();

						if (tag != NULL)
						{
							eleTag = new char[strlen(tag)+1];
							strcpy(eleTag, tag);
						}
					}
				}
			break;
							
			case PROCESS_TREE_CONSTRUCT_NODE:
				{
					ptNode = (PatternTreeNode*) ((ProcessTreeConstructNode*) psNode)->getPatternTree()
							->getNodeWithID(wtNode.getDefinedAt().ptTreeNodeID);
					if (ptNode != NULL)
					{
						if (ptNode->getPtTreeNodeType() == PATTERN_TREE_CONSTRUCT_NODE)
						{
							switch (((PatternTreeConstructNode*) ptNode)->getConstructNodeType())
							{
							case CONSTRUCT_ELEMENT: 
								{
									char* constrTag = ((PatternTreeConstructNode*) ptNode)->getNodeTag();
									if (constrTag != NULL)
									{
										eleTag = new char[strlen(constrTag)+1];
										strcpy(eleTag, constrTag);
									}
								}
								break;
							case CONSTRUCT_ATTRIBUTE:
								goto exit;

							case CONSTRUCT_REFERENCE:
								{
									char* tag = this->getElementTag(wtTree, psTree, 
										((PatternTreeConstructNode*) ptNode)->getLCLRefered());
									if (tag != NULL)
									{
										eleTag = new char[strlen(tag)+1];
										strcpy(eleTag, tag);
									}
								}
								break;
							}
						}
					}			
				}
				break;

			case PROCESS_TREE_PROJECT_NODE:
			case PROCESS_TREE_DUPLICATE_ELIMINATION_NODE:
			case PROCESS_TREE_AGGREGATE_FUNCTION_NODE:
			case PROCESS_TREE_FILTER_NODE:
			case PROCESS_TREE_SORT_NODE:
			case PROCESS_TREE_SET_NODE:
			case PROCESS_TREE_UPDATE_NODE:
			case PROCESS_TREE_DELETE_NODE:
			case PROCESS_TREE_INSERT_NODE:
				goto exit;
			}
		}
	}

exit:
	return eleTag; 
}



/**
 * Initialize a witness tree with a single node, given the lcl, node type and attr name
 * of the node.
 *@param LCL The LCL of the witness tree node
 *@param nodetype The node type of the witness tree node
 *@param name The attribute name attached to a witness tree node
 *@returns A witness tree with one node. 
 */

LCLWTTreeMapType* WitnessTreeTracker
::createOneNodeWitnessTree(LCLType lcl,
						   int nodetype,
						   PsPt def)
{
	// construct a one node witness tree. 
	LCLWTTreeMapType* wtTree = new LCLWTTreeMapType;
	wtTree->insert(LCLWTTreeMapType::value_type(lcl, WitnessTreeNode(lcl, nodetype, def)));

	return wtTree;
}

/**
 * Manipulate a witness tree with filter operation. 
 * A filter operation does not change the structure of a witness tree. 
 */
LCLWTTreeMapType* WitnessTreeTracker
::filterWitnessTree(LCLWTTreeMapType* wtTree)
{
	LCLWTTreeMapType* newWtTree = this->copyWitnessTree(wtTree);
	return newWtTree;
}

/**
 * Manipulate a witness tree with duplicate elimination operation. 
 * A duplicate elimination operation does not change the structure 
 * of a witness tree. 
 */

LCLWTTreeMapType* WitnessTreeTracker
::deWitnessTree(LCLWTTreeMapType* wtTree)
{
	LCLWTTreeMapType* newWtTree = this->copyWitnessTree(wtTree);
	return newWtTree;
}

/**
 * Manipulate a witness tree with sort operation. 
 * A sort operation does not change the structure of a witness tree. 
 */
LCLWTTreeMapType* WitnessTreeTracker
::sortWitnessTree(LCLWTTreeMapType* wtTree)
{
	LCLWTTreeMapType* newWtTree = this->copyWitnessTree(wtTree);
	return newWtTree;
}


/**
 * Manipulate a witness tree with join operation. 
 * When two witness trees joined by structural join, the witness tree of 
 * the two branches to be joined are merged into one witness tree. 
 *@param wtTreeAncs The witness tree from the ancestor branch in the join. 
 *@param wtTreeDesc The witness tree from the descendant branch in the join. 
 *@param joinAncs The LCL of the ancestor node participates in the join. 
 *@param joinDesc The LCL of the descendant node participates in the join. 
 *@returns The witness tree of the joined result.
 */
LCLWTTreeMapType* WitnessTreeTracker
::structuralJoinWitnessTrees(LCLWTTreeMapType* wtTreeAncs, 
							 LCLWTTreeMapType* wtTreeDesc)
{
	// merge the witness trees of the two branches. 
	LCLWTTreeMapType* newWtTree = this->mergeWitnessTree(wtTreeAncs,wtTreeDesc);
	return newWtTree;
}

/**
 * Manipulate a witness tree with value join operation. 
 * When two witness trees joined by value join, the witness tree of 
 * the two branches to be joined are merged into one witness tree, 
 * and the join node becomes the new root. 
 *@param joinNodeLCL The LCL of the root node, which will be the root of the new witness tree. 
 *@param wtTreeLeft The witness tree from the left branch in the join. 
 *@param wtTreeRight The witness tree from the right branch in the join. 
 *@returns The witness tree of the join result.
 */
LCLWTTreeMapType* WitnessTreeTracker
::valueJoinWitnessTrees(LCLType joinNodeLCL, 
						PsPt def,
						LCLWTTreeMapType* wtTreeLeft, 
						LCLWTTreeMapType* wtTreeRight)
{

	LCLWTTreeMapType* wtTree = this->mergeWitnessTree(wtTreeLeft, wtTreeRight);

	// add the new root to the new witness tree. 
	wtTree->insert(LCLWTTreeMapType::value_type(joinNodeLCL, 
		WitnessTreeNode(joinNodeLCL, WT_VALUEJOIN_NODE, def)));

	return wtTree;
}

/**
 * Manipulate a witness tree with set operation. 
 * When two witness trees are operated by set operation, the result
 * are not uniformed. A new set operation node is added to the new witness tree. 
 *@param setNodeLCL The LCL of the set operation node.
 *@param wtTreeLeft The witness tree from the left branch in the set opeartion. 
 *@param wtTreeRight The witness tree from the right branch in the set operation. 
 *@returns The witness tree of the result.
 */
LCLWTTreeMapType* WitnessTreeTracker
::setOpWitnessTrees(LCLWTTreeMapType* wtTreeLeft, 
					LCLWTTreeMapType* wtTreeRight)
{
	LCLWTTreeMapType* wtTree = this->mergeWitnessTree(wtTreeLeft, wtTreeRight);
	return wtTree;	
}


/**
 * Manipulate a witness tree with projection operation. 
 * A projection operation inactive the nodes that are projected out.
 * For Debugging purpose, we still keep the inactivated nodes in the 
 * witness tree for now. 
 *@param wtTree The witness tree before projection. 
 *@param projNum The number of nodes to keep. 
 *@param projLCLs The LCLs of the nodes to keep in the projection. 
 *@returns The witness tree after projection. 
 */
LCLWTTreeMapType* WitnessTreeTracker
::projectWitnessTree(LCLWTTreeMapType* wtTree, 
					 int projNum, 
					 LCLType* projLCLs)
{
	// go over the nodes in witness tree, inactivate nodes that are not in the projectoin
	// LCL list. 
	LCLWTTreeMapType* newWtTree = new LCLWTTreeMapType;
	LCLWTTreeMapType::iterator mapItem;

	mapItem = wtTree->begin();
	while (mapItem != wtTree->end())
	{
		LCLType	nodeLCL = mapItem->first;
		WitnessTreeNode wtNode = mapItem->second;

		if (wtNode.isActive())
		{
			bool inProjList = false;
			for (int i=0; i<projNum; i++)
				if (projLCLs[i] == nodeLCL)
				{
					inProjList = true;
					break;
				}
			if (!inProjList)
				wtNode.inactivate();
		}
		
		newWtTree->insert(LCLWTTreeMapType::value_type(nodeLCL, wtNode));

		mapItem++;
	}

	return newWtTree;
}


/**
 * Manipulate a witness tree with aggregate functions
 * An aggregate function applied on a witness tree introduce
 * a new aggregate function node to it, with the rest of the witness
 * tree unchanged in strucgture. 
 *@param wtTree The witness tree before operation. 
 *@param resultNodeLCL The LCL of the node that holds the result of the aggregate function.  
 *@param resultNodeTag The name of the aggregate function. 
 *@returns The witness tree after aggregate function. 
 */
LCLWTTreeMapType*  WitnessTreeTracker
::aggrFuncWitnessTree(LCLWTTreeMapType* wtTree,
					  LCLType resultNodeLCL,
					  PsPt def) 
{
	LCLWTTreeMapType* newWtTree = this->copyWitnessTree(wtTree);

	// add the aggregate function node to the witness tree

	WitnessTreeNode aggrFuncNodeInfo(resultNodeLCL, 
									 WT_AGGRFUNC_NODE, 
									 def);
	newWtTree->insert(LCLWTTreeMapType::value_type(resultNodeLCL, aggrFuncNodeInfo));

	return newWtTree;
}

/**
 * Manipulate a witness tree with a mlca operation
 * An mlca operator merges multiple witness trees and add a dummy
 * mlca root to be the root of the result witness tree.
 *@param mlcaNodeLCL The LCL of the mlca root. 
 *@param wtTree The witness tree before operation. 
 *@param branchNum The number of input witness trees.
 *@param wtTrees The branches to be merged in the MLCA operation. 
 *@returns The witness tree after aggregate function. 
 */
LCLWTTreeMapType* WitnessTreeTracker
::mlcaWitnessTree(LCLType mlcaNodeLCL,
				  PsPt def, 
				  int branchNum,
				  LCLWTTreeMapType** wtTrees)
{
	LCLWTTreeMapType* newWtTree = this->mergeWitnessTree(branchNum, wtTrees);

	// add the mlca node to the witness tree

	newWtTree->insert(LCLWTTreeMapType::value_type(mlcaNodeLCL, 
		WitnessTreeNode(mlcaNodeLCL, WT_MLCA_NODE, def)));

	return newWtTree;
}


/**
 * This operation add consturction nodes to witness trees. 
 * This happens when a construction happens in the middle of 
 * a query, in which the result of the construction will be refered 
 * in outer query. 
 *@param wtTree The input witness tree.
 *@param nodeNum The number of nodes to be inserted
 *@param constructedLCLs The LCLs of the constructed nodes. 
 *@returns The witness tree after the construct operation . 
 */
LCLWTTreeMapType* WitnessTreeTracker
::addConstructNodeToWitnessTree(LCLWTTreeMapType* wtTree,
								NodeIDType psNodeID,
								PatternTree* ptTree)
{
	LCLWTTreeMapType* newWtTree = this->copyWitnessTree(wtTree);

	// add the new constructed nodes to the witness tree

	int nodeNum = ptTree->getNodeNumber();
	for (int i=0; i<nodeNum; i++)
	{
		PatternTreeConstructNode* ptNode = (PatternTreeConstructNode*) ptTree->getNodeAtIndex(i);
		LCLType nodeLCL = ptNode->getLCL();
		PsPt def;

		def.psTreeNodeID = psNodeID;
		def.ptTreeNodeID = ptNode->getNodeID();
		
		newWtTree->insert(LCLWTTreeMapType::value_type(nodeLCL, 
			WitnessTreeNode(nodeLCL, WT_CONSTRUCTED_NODE, def)));
	}

	return newWtTree;
}

LCLWTTreeMapType* WitnessTreeTracker
::addConstructNodeToWitnessTree(LCLWTTreeMapType* wtTree,
								int nodeNum,
								WitnessTreeNode* wtTreeNodes)
{
	LCLWTTreeMapType* newWtTree = this->copyWitnessTree(wtTree);
	for (int i=0; i<nodeNum; i++)
	{
		newWtTree->insert(LCLWTTreeMapType::value_type(wtTreeNodes[i].getNodeLCL(), 
			WitnessTreeNode(wtTreeNodes[i].getNodeLCL(),
			wtTreeNodes[i].getNodeType(), 
			wtTreeNodes[i].getDefinedAt())));
	}
	return newWtTree;
}





/**
 * Make a copy of a witness tree. 
 *@param wtTree The witness tree to copy. 
 *@returns A copy of the witness tree. 
 */
LCLWTTreeMapType* WitnessTreeTracker::copyWitnessTree(LCLWTTreeMapType* wtTree)
{
	LCLWTTreeMapType* newWtTree = new LCLWTTreeMapType(wtTree->begin(), wtTree->end());
	return newWtTree;
}


LCLWTTreeMapType* WitnessTreeTracker
::mergeWitnessTree(int wtTreeNum,
				   LCLWTTreeMapType** wtTrees)
{
	LCLWTTreeMapType* newWtTree = new LCLWTTreeMapType(wtTrees[0]->begin(), 
													   wtTrees[0]->end());

	for (int i=1; i<wtTreeNum; i++)
		newWtTree->insert(wtTrees[i]->begin(), wtTrees[i]->end());

	return newWtTree;
}

LCLWTTreeMapType* WitnessTreeTracker
::mergeWitnessTree(LCLWTTreeMapType* wtTree1,
				   LCLWTTreeMapType* wtTree2)
{
	LCLWTTreeMapType* newWtTree = new LCLWTTreeMapType(wtTree1->begin(), 
													   wtTree1->end());

	newWtTree->insert(wtTree2->begin(), wtTree2->end());

	return newWtTree;
}


/**
 * print the witness tree
 *@param wtTree The witness tree to print. 
 */
void WitnessTreeTracker::printWitnessTree(LCLWTTreeMapType* wtTree)
{
	cout << endl << "--------------------- witness tree info --------------------" << endl;
	cout << "number of items in the map: " << (int) wtTree->size() << endl;

	LCLWTTreeMapType::iterator mapItem;

	mapItem = wtTree->begin();
	while (mapItem != wtTree->end())
	{
		WitnessTreeNode wtNode = mapItem->second;
		wtNode.printWitnessTreeNode();
		//cout << "pattern tree node id=" << mapItem->first << endl;
		//cout << endl;
		mapItem++;
	}

}