/**
COPYRIGHT  � 2000-2004
THE REGENTS OF THE UNIVERSITY OF MICHIGAN ALL RIGHTS RESERVED

PERMISSION IS GRANTED TO USE, COPY, CREATE DERIVATIVE WORKS A
ND REDISTRIBUTE THIS SOFTWARE AND SUCH DERIVATIVE WORKS FOR 
NONCOMMERCIAL EDUCATION AND RESEARCH PURPOSES, SO LONG AS NO 
FEE IS CHARGED, AND SO LONG AS THE COPYRIGHT NOTICE ABOVE, 
THIS GRANT OF PERMISSION, AND THE DISCLAIMER BELOW APPEAR IN 
ALL COPIES MADE; AND SO LONG AS THE NAME OF THE UNIVERSITY OF 
MICHIGAN IS NOT USED IN ANY ADVERTISING OR PUBLICITY PERTAINING 
TO THE USE OR DISTRIBUTION OF THIS SOFTWARE WITHOUT SPECIFIC, 
WRITTEN PRIOR AUTHORIZATION.

THIS SOFTWARE IS PROVIDED AS IS, WITHOUT REPRESENTATION FROM 
THE UNIVERSITY OF MICHIGAN AS TO ITS FITNESS FOR ANY PURPOSE, 
AND WITHOUT WARRANTY BY THE UNIVERSITY OF MICHIGAN OF ANY KIND, 
EITHER EXPRESS OR IMPLIED, INCLUDING WITHOUT LIMITATION THE 
IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A 
PARTICULAR PURPOSE. THE REGENTS OF THE UNIVERSITY OF MICHIGAN 
SHALL NOT BE LIABLE FOR ANY DAMAGES, INCLUDING SPECIAL, INDIRECT, 
INCIDENTAL, OR CONSEQUENTIAL DAMAGES, WITH RESPECT TO ANY CLAIM 
ARISING OUT OF OR IN CONNECTION WITH THE USE OF THE SOFTWARE, 
EVEN IF IT HAS BEEN OR IS HEREAFTER ADVISED OF THE POSSIBILITY 
OF SUCH DAMAGES.
*/

#ifndef __WitnessTreeNode_H
#define __WitnessTreeNode_H

#include "EvaluationPlanGenerator_includes.h"

// witness tree node type
#define WT_ELEMENT_NODE				ELEMENT_NODE
#define WT_ATTRIBUTE_NODE			ATTRIBUTE_NODE
#define WT_DOCUMENT_NODE			DOCUMENT_NODE
#define WT_AGGRFUNC_NODE				11
#define WT_VALUEJOIN_NODE				12
#define WT_SET_NODE						13
#define WT_MLCA_NODE					14
#define WT_CONSTRUCTED_NODE				21
#define WT_CONSTRUCTED_NODE_WITH_TEXT	22

typedef struct 
{
	NodeIDType psTreeNodeID;
	NodeIDType ptTreeNodeID;
} PsPt;


/**
 * class WitnessTreeNode
 * This class defined a witness tree node. It specifies 
 * the LCL and type of a witness tree node, and whether 
 * the node is active. 
 *@author Yuqing Melanie Wu
 */
class WitnessTreeNode
{
public:
	WitnessTreeNode();
	WitnessTreeNode(LCLType lcl,
		int nodetype, 
		PsPt def);
	~WitnessTreeNode(void);

	LCLType getNodeLCL();
	int getNodeType();
	PsPt getDefinedAt();
	bool definedByPtNode();
	bool definedByPsNode();

	bool isActive();
	void inactivate();
	void printWitnessTreeNode();

protected: 
	/*
	 * The LCL of the node
	 */
	LCLType nodeLCL;

	/* 
	 * The type of a witness tree node. 
	 * A node in a witness tree can be a node from XML document,
	 * such as element node, It may also be a derived node,
	 * such as a join root, or a node that holds the aggregate 
	 * result. 
	 */
	int witnessTreeNodeType;

	/*
	 * Where the witness tree node is defined. 
	 */
	PsPt definedAt;

	/*
	 * Whether the node is active in the witness tree.
	 * An active node is visible to other physical operator and
	 * can participate in operations. 
	 * A node can because inactive because of many reasons, such as
	 * being projected out, being shadowed, etc. 
	 */
	bool active;

	friend class SimplePlanGenerator;
};

#endif