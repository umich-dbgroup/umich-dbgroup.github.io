/**
COPYRIGHT  � 2000-2004
THE REGENTS OF THE UNIVERSITY OF MICHIGAN ALL RIGHTS RESERVED

PERMISSION IS GRANTED TO USE, COPY, CREATE DERIVATIVE WORKS A
ND REDISTRIBUTE THIS SOFTWARE AND SUCH DERIVATIVE WORKS FOR 
NONCOMMERCIAL EDUCATION AND RESEARCH PURPOSES, SO LONG AS NO 
FEE IS CHARGED, AND SO LONG AS THE COPYRIGHT NOTICE ABOVE, 
THIS GRANT OF PERMISSION, AND THE DISCLAIMER BELOW APPEAR IN 
ALL COPIES MADE; AND SO LONG AS THE NAME OF THE UNIVERSITY OF 
MICHIGAN IS NOT USED IN ANY ADVERTISING OR PUBLICITY PERTAINING 
TO THE USE OR DISTRIBUTION OF THIS SOFTWARE WITHOUT SPECIFIC, 
WRITTEN PRIOR AUTHORIZATION.

THIS SOFTWARE IS PROVIDED AS IS, WITHOUT REPRESENTATION FROM 
THE UNIVERSITY OF MICHIGAN AS TO ITS FITNESS FOR ANY PURPOSE, 
AND WITHOUT WARRANTY BY THE UNIVERSITY OF MICHIGAN OF ANY KIND, 
EITHER EXPRESS OR IMPLIED, INCLUDING WITHOUT LIMITATION THE 
IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A 
PARTICULAR PURPOSE. THE REGENTS OF THE UNIVERSITY OF MICHIGAN 
SHALL NOT BE LIABLE FOR ANY DAMAGES, INCLUDING SPECIAL, INDIRECT, 
INCIDENTAL, OR CONSEQUENTIAL DAMAGES, WITH RESPECT TO ANY CLAIM 
ARISING OUT OF OR IN CONNECTION WITH THE USE OF THE SOFTWARE, 
EVEN IF IT HAS BEEN OR IS HEREAFTER ADVISED OF THE POSSIBILITY 
OF SUCH DAMAGES.
*/



#include "partialevaluationplan.h"

/**
 * Constructor
 */
PartialEvaluationPlan::PartialEvaluationPlan(char* subplan, 
											 LCLWTTreeMapType* wtTree,
											 OrderKey* orderkey)
{
	if (subplan != NULL)
	{
		this->subPlanString = new char[strlen(subplan) + 1];
		strcpy(this->subPlanString, subplan);
	}
	this->wtTree = wtTree;
	this->orderKey = orderkey;
}

/**
 * Constructor
 * construct a new partial evaluation plan by copying another plan
 */
PartialEvaluationPlan
::PartialEvaluationPlan(PartialEvaluationPlan* plan)
{
	char* evStr = plan->getEvaluationPlan();
	if (evStr != NULL)
	{
		this->subPlanString = new char[strlen(evStr) + 1];
		strcpy(this->subPlanString, evStr);
	}

	WitnessTreeTracker wtTracker;
	this->wtTree = wtTracker.copyWitnessTree(plan->getWTTree());
	OrderKey* orderkey = plan->getOrderKey();
	if (orderkey == NULL)
		this->orderKey = NULL;
	else 
		this->orderKey = new OrderKey(orderkey);
}

/**
 * Destructor
 */
PartialEvaluationPlan::~PartialEvaluationPlan(void)
{
	delete [] this->subPlanString;
	if (this->orderKey != NULL)
		delete this->orderKey;

	delete this->wtTree;
}


/**
 * Get the evaluation plan in string format
 */
char* PartialEvaluationPlan::getEvaluationPlan()
{
	return this->subPlanString;
}

/**
 * Get the witness tree
 */
LCLWTTreeMapType* PartialEvaluationPlan::getWTTree()
{
	return this->wtTree;
}

/**
 * Get the order key of the result produced by the partial plan. 
 */
OrderKey* PartialEvaluationPlan::getOrderKey()
{
	return this->orderKey;
}

/**
 * Check whether the result is sorted by the given node, with the specified type (id or value)
 */
bool PartialEvaluationPlan::orderby(NodeIDType nodeid, int valueType)
{
	int retval = false;
	if (valueType == ID_VALUE)
		retval = this->orderbyStartKeyOfNode(nodeid);
	else retval = this->orderbyValueOfNode(nodeid);
	return retval;
}


/**
 * Find out whether the result is ordered primarily by the start key of the given node. 
 */
bool PartialEvaluationPlan::orderbyStartKeyOfNode(LCLType lcl) 
{
	if (this->orderKey == NULL)
		return false;
	else return this->orderKey->primarilyByStartKeyOfNode(lcl);
}

/**
 * Find out whether the result is ordered primarily by the value of the given node. 
 */
bool PartialEvaluationPlan::orderbyValueOfNode(LCLType lcl) 
{
	if (this->orderKey == NULL)
		return false;
	else return this->orderKey->primarilyByValueOfNode(lcl);
}


/**
 * print the partial plan, including the plan and the plan property. 
 */
void PartialEvaluationPlan::printPartialEvPlan()
{
	cout << endl << "-------------- partial evaluation plan---------------" << endl;

	if (this->subPlanString != NULL)
		cout << this->subPlanString << endl;

	cout << "Order Key: " << endl;
	this->orderKey->printOrderKey();

	cout << "Witness tree position info: " << endl;
	WitnessTreeTracker::printWitnessTree(this->wtTree);
}