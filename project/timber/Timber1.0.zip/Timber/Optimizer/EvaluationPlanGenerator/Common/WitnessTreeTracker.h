/**
COPYRIGHT  � 2000-2004
THE REGENTS OF THE UNIVERSITY OF MICHIGAN ALL RIGHTS RESERVED

PERMISSION IS GRANTED TO USE, COPY, CREATE DERIVATIVE WORKS A
ND REDISTRIBUTE THIS SOFTWARE AND SUCH DERIVATIVE WORKS FOR 
NONCOMMERCIAL EDUCATION AND RESEARCH PURPOSES, SO LONG AS NO 
FEE IS CHARGED, AND SO LONG AS THE COPYRIGHT NOTICE ABOVE, 
THIS GRANT OF PERMISSION, AND THE DISCLAIMER BELOW APPEAR IN 
ALL COPIES MADE; AND SO LONG AS THE NAME OF THE UNIVERSITY OF 
MICHIGAN IS NOT USED IN ANY ADVERTISING OR PUBLICITY PERTAINING 
TO THE USE OR DISTRIBUTION OF THIS SOFTWARE WITHOUT SPECIFIC, 
WRITTEN PRIOR AUTHORIZATION.

THIS SOFTWARE IS PROVIDED AS IS, WITHOUT REPRESENTATION FROM 
THE UNIVERSITY OF MICHIGAN AS TO ITS FITNESS FOR ANY PURPOSE, 
AND WITHOUT WARRANTY BY THE UNIVERSITY OF MICHIGAN OF ANY KIND, 
EITHER EXPRESS OR IMPLIED, INCLUDING WITHOUT LIMITATION THE 
IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A 
PARTICULAR PURPOSE. THE REGENTS OF THE UNIVERSITY OF MICHIGAN 
SHALL NOT BE LIABLE FOR ANY DAMAGES, INCLUDING SPECIAL, INDIRECT, 
INCIDENTAL, OR CONSEQUENTIAL DAMAGES, WITH RESPECT TO ANY CLAIM 
ARISING OUT OF OR IN CONNECTION WITH THE USE OF THE SOFTWARE, 
EVEN IF IT HAS BEEN OR IS HEREAFTER ADVISED OF THE POSSIBILITY 
OF SUCH DAMAGES.
*/

#ifndef __WitnessTreeTracker_H
#define __WitnessTreeTracker_H


#include "WitnessTreeNode.h"



/**
 * This is a map that maps LCL to witness tree node.
 * this map describes a witness tree. 
 */
typedef map <LCLType, WitnessTreeNode> 	LCLWTTreeMapType;

/**
 * class WitnessTreeTracker
 * 
 * This class manuplate witnessTreeInfo, based on the physical 
 * operations applied on the witness tree. 
 * 
 * This class does not contain any witness tree info itself. 
 * It provide methods that manipulate witness trees. 
 * 
 *@see LCLWtTreeMapType
 *@see WitnessTreeNode
 *@author Yuqing Melanie Wu
 */
class WitnessTreeTracker
{
public:
	WitnessTreeTracker(void);
	~WitnessTreeTracker(void);

	bool findNode(LCLWTTreeMapType* wtTree, LCLType lcl);
	int getWitnessTreeNodeType(LCLWTTreeMapType* wtTree, LCLType lcl);
	char* getFileName(LCLWTTreeMapType* wtTree, 
		ProcessTree* psTree, LCLType lcl);
	char* getAttrName(LCLWTTreeMapType* wtTree, 
		ProcessTree* psTree, LCLType lcl);
	char* getElementTag(LCLWTTreeMapType* wtTree, 
		ProcessTree* psTree, LCLType lcl);
	PsPt getDefineAt(LCLWTTreeMapType* wtTree, LCLType lcl);

	bool nodeIsActive(LCLWTTreeMapType* wtTree, LCLType lcl);

	LCLWTTreeMapType* createOneNodeWitnessTree(LCLType lcl, 
		int nodetype, 
		PsPt def); 
	LCLWTTreeMapType* copyWitnessTree(LCLWTTreeMapType* wtTree);
	LCLWTTreeMapType* mergeWitnessTree(int wtTreeNum, 
		LCLWTTreeMapType** wtTrees);
		
	LCLWTTreeMapType* mergeWitnessTree(LCLWTTreeMapType* wtTree1,
		LCLWTTreeMapType* wtTree2);

	LCLWTTreeMapType* filterWitnessTree(LCLWTTreeMapType* wtTree);
	LCLWTTreeMapType* deWitnessTree(LCLWTTreeMapType* wtTree);
	LCLWTTreeMapType* sortWitnessTree(LCLWTTreeMapType* wtTree);

	LCLWTTreeMapType* structuralJoinWitnessTrees(LCLWTTreeMapType* wtTree1, 
		LCLWTTreeMapType* wtTree2);

	LCLWTTreeMapType* valueJoinWitnessTrees(LCLType joinNodeID, 
		PsPt def, 
		LCLWTTreeMapType* wtTree1, 
		LCLWTTreeMapType* wtTree2);

	LCLWTTreeMapType* setOpWitnessTrees(
		LCLWTTreeMapType* wtTree1, 
		LCLWTTreeMapType* wtTree2);

	LCLWTTreeMapType* projectWitnessTree(LCLWTTreeMapType* wtTree,
		int projNum,
		LCLType* projPtNodeIDs);

	LCLWTTreeMapType* aggrFuncWitnessTree(LCLWTTreeMapType* wtTree,
		LCLType resultNodeLCL,
		PsPt def);

	LCLWTTreeMapType* mlcaWitnessTree(LCLType mlcaNodeLCL,
		PsPt def, 
		int branchNum,
		LCLWTTreeMapType** wtTrees);

	LCLWTTreeMapType* addConstructNodeToWitnessTree(LCLWTTreeMapType* wtTree,
		NodeIDType psNodeID,
		PatternTree* ptTree);

	LCLWTTreeMapType* addConstructNodeToWitnessTree(LCLWTTreeMapType* wtTree,
		NodeIDType psNodeID,
		WitnessTreeNode* wtTreeNodes);

	static LCLWTTreeMapType* copyWTTree(LCLWTTreeMapType* wtTree);

	static void printWitnessTree(LCLWTTreeMapType* wtTree);


private: 

};

#endif