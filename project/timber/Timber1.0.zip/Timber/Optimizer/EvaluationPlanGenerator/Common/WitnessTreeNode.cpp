/**
COPYRIGHT  � 2000-2004
THE REGENTS OF THE UNIVERSITY OF MICHIGAN ALL RIGHTS RESERVED

PERMISSION IS GRANTED TO USE, COPY, CREATE DERIVATIVE WORKS A
ND REDISTRIBUTE THIS SOFTWARE AND SUCH DERIVATIVE WORKS FOR 
NONCOMMERCIAL EDUCATION AND RESEARCH PURPOSES, SO LONG AS NO 
FEE IS CHARGED, AND SO LONG AS THE COPYRIGHT NOTICE ABOVE, 
THIS GRANT OF PERMISSION, AND THE DISCLAIMER BELOW APPEAR IN 
ALL COPIES MADE; AND SO LONG AS THE NAME OF THE UNIVERSITY OF 
MICHIGAN IS NOT USED IN ANY ADVERTISING OR PUBLICITY PERTAINING 
TO THE USE OR DISTRIBUTION OF THIS SOFTWARE WITHOUT SPECIFIC, 
WRITTEN PRIOR AUTHORIZATION.

THIS SOFTWARE IS PROVIDED AS IS, WITHOUT REPRESENTATION FROM 
THE UNIVERSITY OF MICHIGAN AS TO ITS FITNESS FOR ANY PURPOSE, 
AND WITHOUT WARRANTY BY THE UNIVERSITY OF MICHIGAN OF ANY KIND, 
EITHER EXPRESS OR IMPLIED, INCLUDING WITHOUT LIMITATION THE 
IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A 
PARTICULAR PURPOSE. THE REGENTS OF THE UNIVERSITY OF MICHIGAN 
SHALL NOT BE LIABLE FOR ANY DAMAGES, INCLUDING SPECIAL, INDIRECT, 
INCIDENTAL, OR CONSEQUENTIAL DAMAGES, WITH RESPECT TO ANY CLAIM 
ARISING OUT OF OR IN CONNECTION WITH THE USE OF THE SOFTWARE, 
EVEN IF IT HAS BEEN OR IS HEREAFTER ADVISED OF THE POSSIBILITY 
OF SUCH DAMAGES.
*/


#include "WitnessTreeNode.h"

WitnessTreeNode::WitnessTreeNode()
{
	this->nodeLCL = -1;
	this->witnessTreeNodeType = -1;
	this->definedAt.psTreeNodeID = -1;
	this->definedAt.ptTreeNodeID = -1;
	this->active = false;
}

/**
 * Constructor
 * Construct a witness tree node, given its LCL, node type and
 * attribute name, if available. 
 */
WitnessTreeNode::WitnessTreeNode(LCLType lcl,
								 int nodetype, 
								 PsPt def)
{
	this->nodeLCL = lcl;
	this->witnessTreeNodeType = nodetype;
	this->definedAt = def;
	this->active = true;
}

/**
 * Destructor
 */
WitnessTreeNode::~WitnessTreeNode(void)
{
}

/*
 * Check whether the witness tree node is active. 
 */
bool WitnessTreeNode::isActive()
{
	return (this->active);
}

/*
 * Get the LCL of the witness tree node
 */
LCLType WitnessTreeNode::getNodeLCL()
{
	return this->nodeLCL;
}

/*
 * Get the node type of the witness tree node
 */
int WitnessTreeNode::getNodeType()
{
	return this->witnessTreeNodeType;
}

/**
 * Get the information about where the witness tree node is defined in the logical plan.
 */
PsPt WitnessTreeNode::getDefinedAt()
{
	return this->definedAt;
}

/**
 * Find out whether the witness tree node is defined by a process tree node. 
 */

bool WitnessTreeNode::definedByPsNode()
{
	return (this->definedAt.ptTreeNodeID == -1);
}

/**
 * Find out whether the witness tree node is defined by a pattern tree node. 
 */

bool WitnessTreeNode::definedByPtNode()
{
	return (this->definedAt.ptTreeNodeID >= 0);
}


/**
 * Inactivate the witness tree node.
 * mark it to be inactive. 
 */
void WitnessTreeNode::inactivate()
{
	this->active = false;
}

/**
 * print the info of a witness tree node. 
 */
void WitnessTreeNode::printWitnessTreeNode()
{
	cout << "witness tree node:" << endl;
	cout << "    LCL = " << this->nodeLCL << endl;
	cout << "    nodetype = ";

	switch (this->witnessTreeNodeType)
	{
	case WT_ELEMENT_NODE: cout << "ELEMENT_NODE" << endl; break;
	case WT_ATTRIBUTE_NODE: cout << "ATTRIBUTE_NODE" << endl; break;
	case WT_DOCUMENT_NODE: cout << "DOCUMENT_NODE" << endl; break;
	case WT_AGGRFUNC_NODE: cout << "AGGRFUNC_NODE" << endl; break;
	case WT_VALUEJOIN_NODE: cout << "VALUEJOIN_NODE" << endl; break;
	case WT_SET_NODE: cout << "SET_NODE" << endl; break;
	case WT_CONSTRUCTED_NODE: cout << "CONSTRUCTED_NODE" << endl; break;
	}

	cout << "    Active: ";
	if (this->active) cout << "TRUE" << endl;
	else cout << "FALSE" << endl;
}