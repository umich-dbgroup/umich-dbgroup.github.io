/** 
COPYRIGHT  ?2000-2004
THE REGENTS OF THE UNIVERSITY OF MICHIGAN ALL RIGHTS RESERVED

PERMISSION IS GRANTED TO USE, COPY, CREATE DERIVATIVE WORKS A
ND REDISTRIBUTE THIS SOFTWARE AND SUCH DERIVATIVE WORKS FOR 
NONCOMMERCIAL EDUCATION AND RESEARCH PURPOSES, SO LONG AS NO 
FEE IS CHARGED, AND SO LONG AS THE COPYRIGHT NOTICE ABOVE, 
THIS GRANT OF PERMISSION, AND THE DISCLAIMER BELOW APPEAR IN 
ALL COPIES MADE; AND SO LONG AS THE NAME OF THE UNIVERSITY OF 
MICHIGAN IS NOT USED IN ANY ADVERTISING OR PUBLICITY PERTAINING 
TO THE USE OR DISTRIBUTION OF THIS SOFTWARE WITHOUT SPECIFIC, 
WRITTEN PRIOR AUTHORIZATION.

THIS SOFTWARE IS PROVIDED AS IS, WITHOUT REPRESENTATION FROM 
THE UNIVERSITY OF MICHIGAN AS TO ITS FITNESS FOR ANY PURPOSE, 
AND WITHOUT WARRANTY BY THE UNIVERSITY OF MICHIGAN OF ANY KIND, 
EITHER EXPRESS OR IMPLIED, INCLUDING WITHOUT LIMITATION THE 
IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A 
PARTICULAR PURPOSE. THE REGENTS OF THE UNIVERSITY OF MICHIGAN 
SHALL NOT BE LIABLE FOR ANY DAMAGES, INCLUDING SPECIAL, INDIRECT, 
INCIDENTAL, OR CONSEQUENTIAL DAMAGES, WITH RESPECT TO ANY CLAIM 
ARISING OUT OF OR IN CONNECTION WITH THE USE OF THE SOFTWARE, 
EVEN IF IT HAS BEEN OR IS HEREAFTER ADVISED OF THE POSSIBILITY 
OF SUCH DAMAGES.
*/

// disable warning 4312 since we need to do int <--> char* transfer
// because of the variable overload on the leftValue in 
// PredicateCondition
#pragma warning(disable: 4312)

#include "plansegmentgenerator.h"

PlanSegmentGenerator::PlanSegmentGenerator(void)
{

}

PlanSegmentGenerator::~PlanSegmentGenerator(void)
{
}

/**
 * Generate plan for a pattern tree selection node
 * The physical plan for evaluating a pattern tree selection node
 * may be a sequence of statement in the physical plan. 
 *
 *@param selectionNode A marked pattern tree selection node, with index info. 
 *@param generateEvString A boolean value which indicates whether the plan is to be generated as a string.
 *@param genearteEvTree A boolean value which indicates whether the plan should be generated as a tree. 
 *@returns The partial plan that evaluate the selection node. 
 */
PartialEvaluationPlan* PlanSegmentGenerator
::generatePlanForPtSelectionNode(MarkedPatternTreeSelectionNode* selectionNode,
								 NodeIDType psNodeID)
{
	// a pattern tree selection node becomes an index/file access, 
	// plus a filter, if necessary.

	PartialEvaluationPlan* partialPlan = NULL;
	char* evStr = NULL;

	bool success = true;

	int indexStatus = selectionNode->getIndexStatus();

	bool orderByStartKey = true;

	// whether filter is needed depends on the index availability. 
	switch (indexStatus)
	{
	case FULLY_INDEXED:
	case PARTIALLY_INDEXED:
		// When the predicates associated with the selection node
		// is fully indexed or partially indexed, index matching information
		// if available in the marked pattern tree node. 
		// If more than one indexmatching is specified, the matching to 
		// the pattern tree node is the intersection of the index 
		// scan results. 
		{
			int imNum = selectionNode->getIndexMatchingNumber();
			char** indexAccessStrs = new char*[imNum];
			char* setOpStr = "T,I,-1";
			int indexOnlyPlanLength = 0;

			if (imNum > 1) 
				orderByStartKey = false; 

			for (int i=0; i<imNum; i++)
			{
				IndexMatchingInfo* imInfo = selectionNode->getIndexMatchingInfoAt(i);

				if (imInfo->getIndexValueMin()->compareValue(VALUE_COMP_OP_NE,
					imInfo->getIndexValueMax()))
					orderByStartKey = false; 

				indexAccessStrs[i]
					= this->generateIndexAccessStr(imInfo->getIndexName(),
												   selectionNode->getNodeID(),
												   selectionNode->getFileName(),
												   imInfo->getIndexType(),
												   imInfo->getIndexServerType(),
												   imInfo->getIndexValueMin(),
												   imInfo->getIndexValueMax());
	
				if (indexAccessStrs[i] == NULL) 
				{
					success = false;
					globalErrorInfo.insertProblem(ERR_TYPE_ERROR, __LINE__, 
						"PlanSegmentGenerator::generatePlanForPtSelectionNode", __FILE__,
						"Error happens on constructing an index access string."); 
					goto exit;
				}

				indexOnlyPlanLength += (int) strlen(indexAccessStrs[i])+1;
				if (i>=1) indexOnlyPlanLength += (int) strlen(setOpStr)+2;
				if (i<imNum) indexOnlyPlanLength += 1;
			}
			
			char* indexOnlyPlanStr = new char[indexOnlyPlanLength];
			for (int i=0; i<imNum; i++)
			{
				strcpy(indexOnlyPlanStr, indexAccessStrs[i]);
				if (i>=1)
				{
					strcat(indexOnlyPlanStr, "\n");
					strcat(indexOnlyPlanStr, setOpStr);
					if (i<imNum) strcat(indexOnlyPlanStr, "\n");
				}
				delete [] indexAccessStrs[i];
			}

			delete [] indexAccessStrs;

			// if the pattern tree node is fully-indexed, index scan is all 
			// what we need to do. 
			if (indexStatus == FULLY_INDEXED) 
			{
				evStr = new char[strlen(indexOnlyPlanStr)+1];
				strcpy(evStr, indexOnlyPlanStr);
				delete [] indexOnlyPlanStr;
				break;
			}

			// If the predicates associated with the selection node is partially
			// indexed, the plan that evaluate the selection node is index access + filter	
			// construct the filter statement:
				
			if (selectionNode->getNonIndexedCondition()->getCondition()->getNumber() != 1)
			{
				success = false;
				globalErrorInfo.insertProblem(ERR_TYPE_ERROR, __LINE__, 
					"PlanSegmentGenerator::generatePlanForPtSelectionNode", __FILE__,
					"Complex filter condition not supported in SimplePlanGenerator."); 
				goto exit;
			}
			else if (selectionNode->getNonIndexedCondition()->getCondition()->getCondAt(0)->getNumber() != 1)
			{
				success = false;
				globalErrorInfo.insertProblem(ERR_TYPE_ERROR, __LINE__, 
					"PlanSegmentGenerator::generatePlanForPtSelectionNode", __FILE__,
					"Complex filter condition not supported in SimplePlanGenerator."); 
				goto exit;
			}

			// transform the condition left to PO_FilterPredicate

			SelectionCondition* condLeft = selectionNode->getNonIndexedCondition();
			int orNum;
			int* andNums;
			PO_FilterPredicate*** filterCond;

			orNum = condLeft->getCondition()->getNumber();
			andNums = new int[orNum];
			filterCond = new PO_FilterPredicate**[orNum];
			for (int i=0; i<orNum; i++)
			{
				andNums[i] = condLeft->getCondition()->getCondAt(i)->getNumber();
				filterCond[i] = new PO_FilterPredicate*[andNums[i]];

				for (int j=0; j<andNums[i]; j++)
				{
					PredicateCondition* pred = condLeft->getCondition()->getCondAt(i)->getCondAt(j);
					filterCond[i][j] = new PO_FilterPredicate;
					filterCond[i][j]->leftValueLCL = selectionNode->getLCL();
					char* attrname = selectionNode->getAttributeName();
					if (attrname == NULL)
						filterCond[i][j]->leftAttrName = NULL;
					else
					{
						filterCond[i][j]->leftAttrName = new char[strlen(attrname)+1];
						strcpy(filterCond[i][j]->leftAttrName, attrname);
					}
					filterCond[i][j]->rightAttrName = NULL;
					filterCond[i][j]->rightValueOption = CONSTANT_VALUE;
					filterCond[i][j]->rightValueConstant = new Value(pred->getRightValue());
					filterCond[i][j]->filterOperatorDataType = pred->getRightValue()->getValueType();
					filterCond[i][j]->filterOperator = pred->getOperator();
					filterCond[i][j]->filterOption = FILTER_OPTION_SOME;
					filterCond[i][j]->rightValueLCL = -1;
				}
			}
			
			char* filterStr = this->generateFilterStr(orNum, andNums, filterCond, NULL);

			for (int i=0; i<orNum; i++)
			{
				for (int j=0; j<andNums[i]; j++)
					delete filterCond[i][j];
				delete [] filterCond[i];
			}
			delete [] filterCond;
			delete [] andNums;

			if (filterStr == NULL) 
			{
				success = false;
				globalErrorInfo.insertProblem(ERR_TYPE_ERROR, __LINE__, 
					"PlanSegmentGenerator::generatePlanForPtSelectionNode", __FILE__,
					"Error happens on constructing a filter string."); 
				goto exit;
			}

			evStr = new char[strlen(indexOnlyPlanStr) + strlen(filterStr) + 3];
			strcpy(evStr, filterStr);
			strcat(evStr, "\n");
			strcat(evStr, indexOnlyPlanStr);
			delete [] indexOnlyPlanStr;
			delete [] filterStr;
		}	
		break;

	case NO_INDEX:
		// When there is no index available to evaluate the selection node
		// use file scan. 
		{
			char* scanAccessStr = this->generateScanAccessStr(selectionNode->getNodeID(),
				selectionNode->getFileName(),
				selectionNode->getNonIndexedCondition());
			if (scanAccessStr == NULL) 	
			{
				success = false;
				globalErrorInfo.insertProblem(ERR_TYPE_ERROR, __LINE__, 
					"PlanSegmentGenerator::generatePlanForPtSelectionNode", __FILE__,
					"Error happens on constructing a scan access string."); 
				goto exit;
			}

			evStr = new char[strlen(scanAccessStr)+1];
			strcpy(evStr, scanAccessStr);
			delete [] scanAccessStr;
		}
		break;
	}

	// construct a witness tree with one node. 

	PsPt def;
	def.psTreeNodeID =psNodeID;
	def.ptTreeNodeID = selectionNode->getNodeID();

	LCLWTTreeMapType* wtTree = this->wtTracker.createOneNodeWitnessTree(
		selectionNode->getLCL(),
		selectionNode->getNodeType(), 
		def);

	// if the pattern tree node is evaluted by 
	// (1) file scan
	// (2) index scan (on single value)
	// (3) index scan (on single value), plus filter
	// the result is ordered by the startkey of the node
	// otherwise, when the pattern tree node is evaluated by 
	// (1) index scan (on a range of values)
	// (2) multiple index scans. 
	// the result is not guaranteed to be ordered by any node in the witness tree. 
	
	OrderKey* orderKey = NULL;
	if (orderByStartKey) 
		orderKey = new OrderKey(selectionNode->getLCL());
		
	// construct the partial plan. 
	partialPlan = new PartialEvaluationPlan(evStr, wtTree, orderKey);

	if (evStr != NULL) delete [] evStr;

exit: 
	return partialPlan;
}


/**
 * Generate plan for a reference node.
 * A reference node refers to the LCL of a node that is already computed
 * and in witness tree. 
 * So the task here is to find the node in the witness tree and refer to it. 
 *@param referenceNode The reference node in a pattern tree that is to be evaluated.
 *@inputeWitnessTreeNumber The number of witness trees as input. 
 *@partialEvPlanForInputWitnessTrees The partial plans that compute the input witness trees. 
 *@returns A plan that compute the reference node. 
 */
PartialEvaluationPlan* PlanSegmentGenerator
::generatePlanForPtReferenceNode(PatternTreeReferenceNode* referenceNode,
								 int inputWitnessTreeNumber,
								 PartialEvaluationPlan** partialEvPlanForInputWitnessTrees)
{
	LCLType referedNodeID = referenceNode->getReference();

	// find the partialEvPlan in the inputEvPlanForWitnessTrees that contains the refered node.

	bool found = false;
	PartialEvaluationPlan* referedPlan = NULL;
	for (int i=0; i<inputWitnessTreeNumber; i++)
	{
		LCLWTTreeMapType* wtTree = partialEvPlanForInputWitnessTrees[i]->getWTTree();
		if (this->wtTracker.findNode(wtTree, referedNodeID))
		{
			found = true;
			if (this->wtTracker.nodeIsActive(wtTree, referedNodeID))
			{
				referedPlan = new PartialEvaluationPlan(partialEvPlanForInputWitnessTrees[i]);
				break;
			}
			else
			{
				sprintf(this->errMsg, "The refered node (nodeid = %d) is not an active node in the input witness tree. It may have been projected out, or be referenced by other node.", referedNodeID );
				globalErrorInfo.insertProblem(ERR_TYPE_ERROR, __LINE__, 
					"PlanSegmentGenerator::generatePlanForPtReferenceNode", __FILE__,
					this->errMsg);
				return NULL;
			}
		}
	}

	if (!found)
	{
		sprintf(this->errMsg, "Pattern tree reference node (id=%d) refers to node (id=%d). However, the refered node is not in the subtree (rooted at the process tree node which contains this reference) processtree).", 
			referenceNode->getNodeID(), referedNodeID);
		globalErrorInfo.insertProblem(ERR_TYPE_ERROR, __LINE__, 
			"PlanSegmentGenerator::generatePlanForPtReferenceNode", __FILE__,
			this->errMsg);
		return NULL;
	}
		
	PartialEvaluationPlan* partialEvPlan = referedPlan;
	return partialEvPlan;
}



/**
 * Generate a statement in physical plan for structural join operation. 
 *@param ancsLCL The LCL of the ancestor node.
 *@param descLCL The LCL of the descendant node.
 *@param relationwithParent The structural relationship to be established, parent-child or ancestor-descendant.
 *@param joinAlgo The join algoirhtm to use. 
 *@param resultOpt The result option, keep one or keep both. 
 *@returns A statement in physical plan for structural join operation. 
 */

char*  PlanSegmentGenerator
::generateStructuralJoinStr(NodeIDType ancsLCL,
							NodeIDType descLCL,
							int relationwithParent,
							int joinAlgo, 
							bool nested,
							int resultOpt)
{
	char strucJoinStr[1000];
	
	// the keyword for structure join. 
	strcpy(strucJoinStr, "J,");

	// join algorithm. 
	switch (joinAlgo)
	{
	case JOIN_ALGORITHM_STACK_ANCS: strcat(strucJoinStr, "A,"); break;
	case JOIN_ALGORITHM_STACK_OUTERANCS: strcat(strucJoinStr, "a,"); break;
	case JOIN_ALGORITHM_STACK_DESC: strcat(strucJoinStr, "D,"); break;
	}

	// ancestor, descendant, sibling (left,right), estimated size.
	sprintf(strucJoinStr+strlen(strucJoinStr), "%d,%d,-1,-1,-1,", ancsLCL, descLCL);

	// structural relationship
	switch (relationwithParent)
	{
	case PTTREE_RELATION_PARENT:	strcat(strucJoinStr, "P,"); break;
	case PTTREE_RELATION_ANCS: strcat(strucJoinStr, "A,"); break;
	default:
		sprintf(this->errMsg, "%d is not a valid structural join option on relationship between nodes.", relationwithParent);
		globalErrorInfo.insertProblem(ERR_TYPE_ERROR, __LINE__, 
			"PlanSegmentGenerator::generateStructuralJoinStr", __FILE__,
			this->errMsg);
		return NULL;
	}

	// result option. 
	switch (resultOpt)
	{
	case JOIN_PROJECTION_ANCESTOR:	strcat(strucJoinStr, "A"); break;
	case JOIN_PROJECTION_DESCENDANT:strcat(strucJoinStr, "D"); break;
	case JOIN_PROJECTION_BOTH:		strcat(strucJoinStr, "B"); break;
	}

	if (nested)
		strcat(strucJoinStr, ",N");

	char* evStr = new char[strlen(strucJoinStr)+1];
	strcpy(evStr, strucJoinStr);
	return evStr;
}

/**
 * Construct a statement in physical plan for index scan operation. 
 *@param indexname The Name of the index to access. 
 *@param LCL The LCL of the node in witness tree. 
 *@param filename The XML document to query.
 *@param indexType The index type (int, double, string, etc). 
 *@param indexServerType The index server (GIST or SHORE). 
 *@param minVal The minimum index key. 
 *@param maxVal The maximum index key. 
 *@returns A statement for index scan. 
 */
char* PlanSegmentGenerator
::generateIndexAccessStr(char* indexname, 
						 LCLType lcl,
						 char* filename, 
						 int indexType, 
						 int indexServerType, 
						 Value* minVal,
						 Value* maxVal)
{
	char indexAccessStr[1000];
	sprintf(indexAccessStr, "I,%d,%s,%s,", lcl, indexname, filename);

	switch (indexServerType)
	{
	case GIST_INDEX:	strcat(indexAccessStr, "GIST,"); break;
	case SHORE_INDEX:	strcat(indexAccessStr, "SHORE,"); break;
	default:	
        globalErrorInfo.insertProblem(ERR_TYPE_ERROR, __LINE__, 
			"PlanSegmentGenerator::generateIndexAccessStr", __FILE__,
			"Invalid index server type.");
		return false;
	}

	switch (indexType)
	{
	case INT_INDEX:		strcat(indexAccessStr, "INT,"); break;
	case STRING_INDEX:  strcat(indexAccessStr, "STR,"); break;
	case FLOAT_INDEX:	strcat(indexAccessStr, "FLT,"); break;
	case DOUBLE_INDEX:	strcat(indexAccessStr, "DBL,"); break;
	default:
		sprintf(this->errMsg, "%d is not a valid index type", indexType);
        globalErrorInfo.insertProblem(ERR_TYPE_ERROR, __LINE__, 
			"PlanSegmentGenerator::generateIndexAccessStr", __FILE__,
			this->errMsg);
		return false;
	}

	char* valStr = minVal->valueToString();
	if (strlen(valStr) == 0)
		strcat(indexAccessStr, "<EMPTY>");
	strcat(indexAccessStr, valStr);
	delete [] valStr;

	if (minVal->compareValue(VALUE_COMP_OP_NE, maxVal))
	{
		strcat(indexAccessStr, ",");
		char* valStr = maxVal->valueToString();
		if (strlen(valStr) == 0)
			strcat(indexAccessStr, "<EMPTY>");
		strcat(indexAccessStr, valStr);
		delete [] valStr;
	}

	char* evStr = new char[strlen(indexAccessStr)+1];
	strcpy(evStr, indexAccessStr);
	return evStr;
}

/**
 * Construct a filter statement
 *@param orNum The number of disjunctions in the filter predicate
 *@param andNums The number of conjunctions in each disjunctive portion. 
 *@param filterCond The individual predicates
 *returns A filter statement. 
 */
char* PlanSegmentGenerator
::generateFilterStr(int orNum, 
					int* andNums,
					PO_FilterPredicate*** filterCond, 
					LCLWTTreeMapType* wtTree)
{
	char filterStr[1000];
	sprintf(filterStr, "f,%d,", orNum); 

	// loop through the individual predicates, 
	for (int i=0; i<orNum; i++)
	{
		sprintf(filterStr+strlen(filterStr), "%d,", andNums[i]);

		for (int j=0; j<andNums[i]; j++)
		{
			PO_FilterPredicate* pred = filterCond[i][j];

			// the filter option
			switch (pred->filterOption)
			{
			case FILTER_OPTION_EVERY:
				strcat(filterStr, "E,");
				break;

			case FILTER_OPTION_SOME:
				strcat(filterStr, "AO,");
				break;

			case FILTER_OPTION_EXACTLYONE:
				strcat(filterStr, "EO,");
				break;
			}

			// determine left value data type
			bool leftValueDone = false;
			if (pred->filterOperatorDataType == ID_VALUE)
			{
				strcat(filterStr, "SK,");
				sprintf(filterStr+strlen(filterStr), "%d,-1,NULL,", pred->leftValueLCL);
				leftValueDone = true;
			}
			else if (pred->leftAttrName != NULL)
			{
				strcat(filterStr, "V,");
				sprintf(filterStr+strlen(filterStr), "%d,-1,", pred->leftValueLCL);
				strcat(filterStr, pred->leftAttrName);
				strcat(filterStr, ",");
				leftValueDone = true;
			}
			else if (wtTree != NULL)
			{
				if (this->wtTracker.getWitnessTreeNodeType(wtTree, pred->leftValueLCL) == WT_AGGRFUNC_NODE)
				{
					strcat(filterStr, "V,");
					sprintf(filterStr+strlen(filterStr), "%d,-1,NULL,", pred->leftValueLCL);
					leftValueDone = true;
				}
			} 
			
			if (!leftValueDone)
			{
				strcat(filterStr, "T,");
				sprintf(filterStr+strlen(filterStr), "%d,-1,NULL,", pred->leftValueLCL);
			}

			// for the operator for filter. 
			bool isStr = (pred->filterOperatorDataType == STRING_VALUE);
			switch (pred->filterOperator)
			{
			case SCAN_OP_LT: 
				if (isStr) strcat(filterStr, "LTS,");
				else  strcat(filterStr, "LTN,");
				break;
			case SCAN_OP_LE:
				if (isStr) strcat(filterStr, "LES,");
				else  strcat(filterStr, "LEN,");
				break;
			case SCAN_OP_GT		:
				if (isStr) strcat(filterStr, "GTS,");
				else  strcat(filterStr, "GTN,");
				break;
			case SCAN_OP_GE		:							
				if (isStr) strcat(filterStr, "GES,");
				else  strcat(filterStr, "GEN,");
				break;
			case SCAN_OP_EQ:
				if (isStr) strcat(filterStr, "EQS,");
				else  strcat(filterStr, "EQN,");
				break;
			case SCAN_OP_NE:
				if (isStr) strcat(filterStr, "NES,");
				else  strcat(filterStr, "NEN,");
				break;
			case SCAN_OP_CONTAINS:
				strcat(filterStr, "C,");
				break;
			case SCAN_OP_CONTAINEDBY:
				strcat(filterStr, "D,");
				break;
			case SCAN_OP_STARTWITH:
				strcat(filterStr, "S,");
				break;
			}

			// for the right value
			bool rightValeuDone = false;
			if (pred->filterOperatorDataType == ID_VALUE)
			{
				strcat(filterStr, "SK,");
				sprintf(filterStr+strlen(filterStr), "%d,-1,NULL,", pred->rightValueLCL);
				rightValeuDone = true;
			}
			else if (pred->rightAttrName != NULL)
			{
				strcat(filterStr, "V,");
				sprintf(filterStr+strlen(filterStr), "%d,-1,", pred->rightValueLCL);
				strcat(filterStr, pred->rightAttrName);
				strcat(filterStr, ",");
				rightValeuDone = true;
			}
			else if (wtTree != NULL)
			{
				if (this->wtTracker.getWitnessTreeNodeType(wtTree, pred->rightValueLCL) == WT_AGGRFUNC_NODE)
				{
					strcat(filterStr, "V,");
					sprintf(filterStr+strlen(filterStr), "%d,-1,NULL,", pred->rightValueLCL);
					rightValeuDone = true;
				}
			} 

			if (!rightValeuDone)
			{
				switch (pred->rightValueOption)
				{
				case REFERENCE_VALUE:
					strcat(filterStr, "T,");
					sprintf(filterStr+strlen(filterStr), "%d,-1,NULL,", pred->rightValueLCL);
					break;
				case CONSTANT_VALUE:
					{
						char* valStr = pred->rightValueConstant->valueToString();
						switch (pred->rightValueConstant->getValueType())
						{
						case STRING_VALUE:
							if (strlen(valStr) == NULL)
								strcat(filterStr, "C,-1,-1,<EMPTY>,");
							sprintf(filterStr+strlen(filterStr), "C,-1,-1,%s,", valStr);
							break;
						case INT_VALUE:
						case REAL_VALUE:
							sprintf(filterStr+strlen(filterStr), "C,-1,%s,NULL,", valStr);
							break;
						}
						delete valStr;
					break;
					}
				}
			}

			if (pred->useJoinIndex)
			{
				strcat(filterStr, pred->indexName);
				strcat(filterStr, ",");
				strcat(filterStr, pred->fileName);
			}
			else strcat(filterStr, "NULL,NULL");

			if (j < andNums[i]-1) 
				sprintf(filterStr+strlen(filterStr), ",");
		}
		
		if (i < orNum-1) 
				sprintf(filterStr+strlen(filterStr), ",");

	}
	char* evStr = new char[strlen(filterStr)+3];
	strcpy(evStr, filterStr);
	return evStr;				
}

/** 
 * Construct a file scan statement
 *@param lcl the LCL of the node in witness tree. 
 *@param filename The XML document to be scanned. 
 *@param cond The selection condition to be applied on scanning. 
 *@returns A file scan statement. 
 */
char* PlanSegmentGenerator
::generateScanAccessStr(LCLType lcl, 
						char* filename, 
						SelectionCondition* cond)
{
	char scanAccessStr[1000];
	sprintf(scanAccessStr, "S,%d,%s,0,", lcl, filename);

	// construct the scan condition. 
	switch (cond->getNodeType())
	{
	case SCAN_ALLNODES:		strcat(scanAccessStr, "ALL_NODES,"); break;
	case ELEMENT_NODE:		strcat(scanAccessStr, "ELEMENT_NODE,"); break;
	case DOCUMENT_NODE:		strcat(scanAccessStr, "DOCUMENT_NODE,"); break;
	case ATTRIBUTE_NODE:	strcat(scanAccessStr, "ATTRIBUTE_NODE,"); break;
	case TEXT_NODE:			strcat(scanAccessStr, "TEXT_NODE,"); break;
	}

	switch (cond->getReturnType())
	{
	case SCAN_RETURN_THISNODE:		strcat(scanAccessStr, "THISNODE,"); break;
	case SCAN_RETURN_PARENTNODE	:	strcat(scanAccessStr, "PARENTNODE,"); break;
	case SCAN_RETURN_ELEMENTNODE:	strcat(scanAccessStr, "ELEMENTNODE,"); break;
	case SCAN_RETURN_ATTRIBUTENODE: strcat(scanAccessStr, "ATTRIBUTENODE,"); break;
	case SCAN_RETURN_SUBTREE:		strcat(scanAccessStr, "SUBTREE,"); break;
	}

	int disjNum = cond->getCondition()->getNumber();

	sprintf(scanAccessStr+strlen(scanAccessStr), "%d,", disjNum);

	for (int i=0; i<disjNum; i++)
	{
		ConjunctiveCondition* conjCond = cond->getCondition()->getCondAt(i);
		int conjNum = conjCond->getNumber();
		sprintf(scanAccessStr+strlen(scanAccessStr), "%d,", conjNum);

		for (int j=0; j<conjNum; j++)
		{
			PredicateCondition* pred = conjCond->getCondAt(j);

			switch (pred->getLeftValue())
			{
			case SCAN_LEFTVALUE_VALUE:			strcat(scanAccessStr, "VALUE,"); break;
			case SCAN_LEFTVALUE_LENGTH:			strcat(scanAccessStr, "LENGTH,"); break;
			case SCAN_LEFTVALUE_XMLFILENAME:	strcat(scanAccessStr, "XMLFILENAME,"); break;	
			case SCAN_LEFTVALUE_NODETAG:		strcat(scanAccessStr, "NODETAG,"); break;		
			case SCAN_LEFTVALUE_CHILDNUMBER:	strcat(scanAccessStr, "CHILDNUMBER,"); break;		
			case SCAN_LEFTVALUE_ATTRIBUTENUMBER:strcat(scanAccessStr, "ATTRIBUTENUMBER,"); break;		
			case SCAN_LEFTVALUE_HASCHILD:		strcat(scanAccessStr, "HASCHILD,"); break;	
			case SCAN_LEFTVALUE_HASATTRIBUTE:	strcat(scanAccessStr, "HAS_ATTRIBUTE,"); break;	
			case SCAN_LEFTVALUE_ELEMENTCONTENT:	strcat(scanAccessStr, "ELEMENTCONTENT,"); break;
			default: sprintf(scanAccessStr+strlen(scanAccessStr), "ATTRIBUTE_VALUE,%s,", (char*) (pred->getLeftValue())); break;
			}

			switch (pred->getOperator())
			{
			case SCAN_OP_LT: 			strcat(scanAccessStr, "LT,"); break;						
			case SCAN_OP_LE:			strcat(scanAccessStr, "LE,"); break;							
			case SCAN_OP_GT:			strcat(scanAccessStr, "GT,"); break;							
			case SCAN_OP_GE:			strcat(scanAccessStr, "GE,"); break;							
			case SCAN_OP_EQ:			strcat(scanAccessStr, "EQ,"); break;							
			case SCAN_OP_NE:			strcat(scanAccessStr, "NE,"); break;							
			case SCAN_OP_CONTAINS:		strcat(scanAccessStr, "CONTAINS,"); break;				
			case SCAN_OP_CONTAINEDBY:	strcat(scanAccessStr, "CONTAINEDBY,"); break;				
			case SCAN_OP_STARTWITH:		strcat(scanAccessStr, "STARTWITH,"); break;	
			}

			switch (pred->getRightValue()->getValueType())
			{
			case STRING_VALUE:			strcat(scanAccessStr, "STR,"); break;	
			case INT_VALUE:				strcat(scanAccessStr, "INT,"); break;	
			case REAL_VALUE:			strcat(scanAccessStr, "FLT,"); break;
			}
			
			char* valStr = pred->getRightValue()->valueToString();
			if (strlen(valStr) == 0)
				strcat(scanAccessStr, "<EMPTY>");
			strcat(scanAccessStr, valStr);
			delete [] valStr;

			if (j!=conjNum-1) 
				strcat(scanAccessStr, ",");
		}
			
		if (i!=disjNum-1) 
			strcat(scanAccessStr, ",");
	}

	// for scan range
	strcat(scanAccessStr, ",0,0,0"); 

	char* evStr = new char[strlen(scanAccessStr)+1];
	strcpy(evStr, scanAccessStr);
	return evStr;				

}


/**
 * Construct a projection statement.
 *@param num The number of nodes to keep in the projection. 
 *@param list The LCLs of the nodes to keep in the projection. 
 *@returns A projection statement. 
 */
char* PlanSegmentGenerator
::generateProjectionStr(int num, 
						LCLType* list)
{
	char projStr[1000];
	sprintf(projStr, "P,%d,", num);

	for (int i=0; i<num; i++)
		sprintf(projStr+strlen(projStr), "%d,", list[i]);

	// preserbe project order
	strcat(projStr, "1");

	char* evStr = new char[strlen(projStr)+1];
	strcpy(evStr, projStr);
	return evStr;				
		
}

/**
 * Construct a duplicate elimination statement
 *@param opt The duplication elimination option. 
 *@param deLCL The node to apply duplicate elimination on. 
 *@param attrName The attribute name, in case the node for duplicate elimination is an attribute node. 
 *@returns A duplicate elimination statement. 
 */
char* PlanSegmentGenerator
::generateDuplicateEliminationStr(int opt,
								  LCLType deLCL,
								  char* attrName)
{
	char deStr[1000];

	strcpy(deStr, "D,");
	
	switch (opt)
	{
	case OPERATE_ON_ID: 
		sprintf(deStr+strlen(deStr), "TR,%d,-1,NULL,1", deLCL); 
		break;
	case OPERATE_ON_CONTENT: 
		if (attrName == NULL)
			sprintf(deStr+strlen(deStr), "TS,%d,-1,NULL,1", deLCL); 
		else sprintf(deStr+strlen(deStr), "AS,%d,-1,%s,1", deLCL, attrName); 
		break;
	default: 
		sprintf(this->errMsg, "%d is not a valid duplicate elimination option.", opt);
        globalErrorInfo.insertProblem(ERR_TYPE_ERROR, __LINE__, 
			"PlanSegmentGenerator::generateDuplicateEliminationStr", __FILE__,
			this->errMsg);
		return false;
	}

	char* evStr = new char[strlen(deStr)+1];
	strcpy(evStr, deStr);
	return evStr;				

}

/**
 * Construct a value join statement.
 *@parem rootLCL The LCL of the join root. 
 *@param leftLCL The LCL of the left value in the join. 
 *@param rightLCL The LCL of the right value in the join. 
 *@param op The value join operator. 
 *@param opDataType The type of the operator.
 *@param leftAttrName The attribute node attached to the left value, if it is an attribute node. 
 *@param rightAttrName The attribute node attached to the right value, if it is an attribute node. 
 *@param fileName The XML document name. 
 *@param indexName The name of the join index. 
 *@param joinOpt The join option (nested, outer, etc)
 *@param anyJoin Whether this is an anyjoin.
 *@param inputSorted Whether the input are sorted by the join value. 
 *@returns A value join statement. 
 */
char* PlanSegmentGenerator
::generateValueJoinStr(LCLType rootLCL,
					   LCLType leftLCL,
					   LCLType rightLCL, 
					   int op,
					   int opDataType,
					   char* leftAttrName, 
					   char* rightAttrName,
					   char* fileName,
					   char* indexName,
					   int joinOpt,
					   bool anyJoin,
					   bool inputSorted)
{
	char valueJoinStr[1000];

	sprintf(valueJoinStr, "j,%d,%d,NULL,%d,NULL,-1,", rootLCL, 
						leftLCL, rightLCL);

	char leftValueSpec = '0';
	char rightValueSpec = '0';
	char opSpec[10];

	if (leftAttrName == NULL)
		sprintf(valueJoinStr+strlen(valueJoinStr), "NULL,");
	else 
		sprintf(valueJoinStr+strlen(valueJoinStr), "%s,",leftAttrName);

	if (rightAttrName == NULL)
		sprintf(valueJoinStr+strlen(valueJoinStr), "NULL,");
	else 
		sprintf(valueJoinStr+strlen(valueJoinStr), "%s,",rightAttrName);

	switch(opDataType)
	{
	case ID_VALUE:
		leftValueSpec = 'S';
		rightValueSpec = 'S';
		switch (op)
		{
		case SCAN_OP_EQ: strcpy(opSpec, "EQN"); break;
		case SCAN_OP_NE: strcpy(opSpec, "NEN"); break;
		case SCAN_OP_LT: strcpy(opSpec, "LTN"); break;
		case SCAN_OP_LE: strcpy(opSpec, "LEN"); break;
		case SCAN_OP_GT: strcpy(opSpec, "GTN"); break;
		case SCAN_OP_GE: strcpy(opSpec, "GEN"); break;
		default:
			sprintf(this->errMsg, "%d is not a valid value join operator", op);
			globalErrorInfo.insertProblem(ERR_TYPE_ERROR, __LINE__, 
				"PlanSegmentGenerator::generateValueJoinStr", __FILE__,
				this->errMsg);		
			return NULL;
		}	
		break;

	case REAL_VALUE: 
		if (leftAttrName == NULL)
			leftValueSpec = 'T';
		else 
			leftValueSpec = 'V';

		if (rightAttrName == NULL)
			rightValueSpec = 'T';
		else 
			rightValueSpec = 'V';
		switch (op)
		{
		case SCAN_OP_EQ: strcpy(opSpec, "EQN"); break;
		case SCAN_OP_NE: strcpy(opSpec, "NEN"); break;
		case SCAN_OP_LT: strcpy(opSpec, "LTN"); break;
		case SCAN_OP_LE: strcpy(opSpec, "LEN"); break;
		case SCAN_OP_GT: strcpy(opSpec, "GTN"); break;
		case SCAN_OP_GE: strcpy(opSpec, "GEN"); break;
		default:
			sprintf(this->errMsg, "%d is not a valid value join operator", op);
			globalErrorInfo.insertProblem(ERR_TYPE_ERROR, __LINE__, 
				"PlanSegmentGenerator::generateValueJoinStr", __FILE__,
				this->errMsg);		
			return NULL;
		}	
		break;


	case STRING_VALUE:
		if (leftAttrName == NULL)
			leftValueSpec = 'T';
		else 
			leftValueSpec = 'V';

		if (rightAttrName == NULL)
			rightValueSpec = 'T';
		else 
			rightValueSpec = 'V';
		switch (op)
		{
		case SCAN_OP_EQ: strcpy(opSpec, "EQS"); break;
		case SCAN_OP_NE: strcpy(opSpec, "NES"); break;
		case SCAN_OP_LT: strcpy(opSpec, "LTS"); break;
		case SCAN_OP_LE: strcpy(opSpec, "LES"); break;
		case SCAN_OP_GT: strcpy(opSpec, "GTS"); break;
		case SCAN_OP_GE: strcpy(opSpec, "GES"); break;
		case SCAN_OP_CONTAINS:	strcpy(opSpec, "C"); break;
		case SCAN_OP_CONTAINEDBY: strcpy(opSpec, "CB"); break;
		default:
			sprintf(this->errMsg, "%d is not a valid value join operator", op);
			globalErrorInfo.insertProblem(ERR_TYPE_ERROR, __LINE__, 
				"PlanSegmentGenerator::generateValueJoinStr", __FILE__,
				this->errMsg);		
			return NULL;
		}	
		break;

	case -1: // cartesian product
		leftValueSpec = 'N';
		rightValueSpec = 'N';
		strcpy(opSpec,"EQN");
		break;

	default:
		sprintf(this->errMsg, "%d is not a valid value type for participating in value join.", opDataType);
		globalErrorInfo.insertProblem(ERR_TYPE_ERROR, __LINE__, 
			"PlanSegmentGenerator::generateValueJoinStr", __FILE__,
			this->errMsg);		
		return NULL;	
	}

	sprintf(valueJoinStr+strlen(valueJoinStr), "%s,%c,%c,", 
			opSpec, leftValueSpec, rightValueSpec);

	// input is sorted
	if (inputSorted)
		strcat(valueJoinStr, "1,");
	else strcat(valueJoinStr, "0,");

	if (indexName == NULL)
		strcat(valueJoinStr, "NULL,NULL");
	else
		sprintf(valueJoinStr+strlen(valueJoinStr), "%s,%s", fileName, indexName);

	// determine nest/outer join
				
	switch (joinOpt)
    {
	case PTTREE_OPERATION_ONLYONE:
		break;

	case PTTREE_OPERATION_ZEROORONE:
		strcat(valueJoinStr,",O");
		break;

	case PTTREE_OPERATION_ZEROORMORE:                                                                                             
		strcat(valueJoinStr,",N,O");
		break;

	case PTTREE_OPERATION_ONEORMORE:
		strcat(valueJoinStr,",N");
		break;
	}	

	if (anyJoin)
		strcat(valueJoinStr, ",A");

	char* evStr = new char[strlen(valueJoinStr)+1];
	strcpy(evStr, valueJoinStr);
	return evStr;				

}


/**
 * Construct a hashed value join statement.
 *@parem rootLCL The LCL of the join root. 
 *@param leftLCL The LCL of the left value in the join. 
 *@param rightLCL The LCL of the right value in the join. 
 *@param fileName The XML document name. 
 *@param indexName The name of the join index. 
 *@param joinOpt The join option (nest, outer, etc)
 *@param anyJoin Whether this is an anyjoin. 
 *@returns A hashed value join statement. 
 */
char* PlanSegmentGenerator
::generateHashedValueJoinStr(LCLType rootLCL,
					   LCLType leftLCL,
					   LCLType rightLCL, 
					   char* fileName,
					   char* indexName,
					   int joinOpt, 
					   bool anyJoin)
{
	char valueJoinStr[1000];

	sprintf(valueJoinStr, "H,-1,%s,%s,%d,%d,%d", 
						indexName, fileName, 
						leftLCL, rightLCL,rootLCL);

	switch (joinOpt)
    {
	case PTTREE_OPERATION_ONLYONE:
	case PTTREE_OPERATION_ZEROORONE:
		globalErrorInfo.insertProblem(ERR_TYPE_ERROR, __LINE__, 
			"PlanSegmentGenerator::generateHashedValueJoinStr", __FILE__,
			"Hashed value join only handles nest joins. "); 
		break;

	case PTTREE_OPERATION_ZEROORMORE:                                                                                             
		strcat(valueJoinStr,",O");
		break;

	case PTTREE_OPERATION_ONEORMORE:
		break;
	}	


	if (anyJoin)
		strcat(valueJoinStr, ",A");

	char* evStr = new char[strlen(valueJoinStr)+1];
	strcpy(evStr, valueJoinStr);
	return evStr;				

}


/**
 * Construct an aggregate function statement
 *@param func The aggregate function to apply. 
 *@param attrname The name of the attribute, in case it is an attribute node. 
 *@param operandLCL The LCL of the operand of the function. 
 *@param resultLCL The LCL of the result node. 
 *@returns An aggregate function statement
 */
char* PlanSegmentGenerator
::generateAggregateFuncStr(int func,
						   LCLType operandLCL,
						   char* attrName,
						   int operandType, 
						   LCLType resultLCL)
{
	char aggrFuncStr[1000];

	// the aggregate function node in the logical opeartor deals one
	// aggregate function at a time. 
	sprintf(aggrFuncStr, "F,1,");

	switch(func)
	{
	case AGGREGATE_FUNCTION_COUNT: strcat(aggrFuncStr, "C,"); break;
	case AGGREGATE_FUNCTION_MIN: strcat(aggrFuncStr, "m,"); break;
	case AGGREGATE_FUNCTION_MAX: strcat(aggrFuncStr, "M,"); break;
	case AGGREGATE_FUNCTION_SUM: strcat(aggrFuncStr, "S,"); break;
	case AGGREGATE_FUNCTION_AVERAGE: strcat(aggrFuncStr, "A,"); break;
	}

	if (attrName == NULL)
		if (operandType == WT_CONSTRUCTED_NODE_WITH_TEXT)
			strcat(aggrFuncStr, "LT,NULL,");
		else
			strcat(aggrFuncStr, "T,NULL,");

	else 
		if (operandType == WT_CONSTRUCTED_NODE)
			sprintf(aggrFuncStr+strlen(aggrFuncStr), "LA,%s,", attrName);
		else
			sprintf(aggrFuncStr+strlen(aggrFuncStr), "V,%s,", attrName);

	sprintf(aggrFuncStr+strlen(aggrFuncStr), "%d,%d,1", 
			operandLCL, resultLCL);

	char* evStr = new char[strlen(aggrFuncStr)+1];
	strcpy(evStr, aggrFuncStr);
	return evStr;	
}

/**
 * Construct a sort statement
 *@param simplesort Whether the sort keys are all node identifier (startkey). 
 *@param orderkey The sortby key. 
 *@retuns A sort Statement.
 */
char* PlanSegmentGenerator::generateSortStr(bool simplesort,
											OrderKey* orderkey)					
{
	char sortStr[1000];
	int sortNum = orderkey->getOrderbyNodeNum();
	OrderbyNode** sortbyNodes = orderkey->getOrderbyNodes();

	if (simplesort)
	{
		// sort keys are all on the start key of the nodes. 
		sprintf(sortStr, "R,-1,K,%d,", sortNum);
		for (int i=0; i<sortNum; i++)
		{
			sprintf(sortStr+strlen(sortStr), "%d,",
				sortbyNodes[i]->orderbyLCL);
			switch(sortbyNodes[i]->orderSpec)
			{
			case ORDER_SPEC_ASCENDING: 
				strcat(sortStr, "A,");
				break;
			case ORDER_SPEC_DESCENDING: 
				strcat(sortStr, "D,"); 
				break;
			}
				
			switch(sortbyNodes[i]->nullOption)
			{
			case ORDER_NULL_LEAST:
				strcat(sortStr, "B");
				break;
			case ORDER_NULL_GREATEST:	
				strcat(sortStr, "E");
				break;
			}

			if (i < sortNum-1)
				strcat(sortStr, ",");
		}

		if (gSettings->getBooleanValue("USE_EXTERNAL_SORT", true))
			strcat(sortStr, ",X");

	}
	else
	{			
		// sort by value or combination of key and value. 
		sprintf(sortStr, "r,-1,%d,", sortNum);
		for (int i=0; i<sortNum; i++)
		{
			switch (sortbyNodes[i]->orderbyOption)
			{
			case ORDER_BY_KEY:
				strcat(sortStr, "SK,");
				break;
			case ORDER_BY_VALUE:
				if (sortbyNodes[i]->attrName == NULL)
					strcat(sortStr, "TS,");
				else strcat(sortStr, "VS,");
				break;		
			}

			sprintf(sortStr+strlen(sortStr), "%d,",	sortbyNodes[i]->orderbyLCL);
			
			switch(sortbyNodes[i]->orderSpec)
			{
			case ORDER_SPEC_ASCENDING: 
				strcat(sortStr, "A,");
				break;
			case ORDER_SPEC_DESCENDING: 
				strcat(sortStr, "D,"); 
				break;
			}

			if (sortbyNodes[i]->attrName == NULL)
				strcat(sortStr, "NULL,");
			else sprintf(sortStr+strlen(sortStr), "%s,",sortbyNodes[i]->attrName);
				
			switch(sortbyNodes[i]->nullOption)
			{
			case ORDER_NULL_LEAST:
				strcat(sortStr, "B");
				break;
			case ORDER_NULL_GREATEST:	
				strcat(sortStr, "E");
				break;
			}	

			if (i < sortNum-1)
				strcat(sortStr, ",");
		}

		if (gSettings->getBooleanValue("USE_EXTERNAL_SORT", true))
			strcat(sortStr, ",X");
	}
	char* evStr = new char[strlen(sortStr)+1];
	strcpy(evStr, sortStr);
	return evStr;	
}

/**
 * Construct a MLCA statement.
 * The MLCA operator takes a set of witness trees as input, identify one node
 * in each witness tree and compute their MLCA. A dummy root is added. 
 *@param rootLCL The LCL of the MLCA root. 
 *@param mlcaNodeNum The number of nodes whose MLCA is to be computed.
 *@param mlcaNodeLCLs The LCL os the nodes whose MLCA is to be computer.
 *@returns A MLCA statement. 
 */
char* PlanSegmentGenerator::generateMLCAStr(LCLType rootLCL, 
											int mlcaNodeNum, 
											LCLType* mlcaNodeLCLs)
{
	char mlcaStr[1000];

	sprintf(mlcaStr, "m,%d,",mlcaNodeNum);

	for (int i=0; i<mlcaNodeNum; i++)
		sprintf(mlcaStr+strlen(mlcaStr), "%d,", mlcaNodeLCLs[i]);

	sprintf(mlcaStr+strlen(mlcaStr), "%d,100,10",rootLCL);

	char* evStr = new char[strlen(mlcaStr)+1];
	strcpy(evStr, mlcaStr);
	return evStr;	
}


/**
 * Construct a update statement
 *@param lcl The LCL of the node to be updated. 
 *@param attrname The attribute name, in case the node to be updated is an attribute node. 
 *@param dataSource Where the new value comes from, a constant value or by refering other nodes. 
 *@param newDataLCL The LCL of the node whose value is to be used as new value in update. 
 *@param newDataConst A constant value which is to be used as new value in update. 
 *@returns A update statement. 
 */
char* PlanSegmentGenerator::generateUpdateStr(LCLType lcl,
											  char* attrName, 
											  int dataSource,
											  LCLType newDataLCL,
											  char* refAttrName,
											  Value* newDataConst)
{
	char updateStr[1000];

	strcpy(updateStr, "U,");

	if (attrName == NULL)
		sprintf(updateStr+strlen(updateStr), "ModTNode,%d,", lcl);
	else sprintf(updateStr+strlen(updateStr), "ModANode,%d,%s,",lcl,attrName);

	switch (dataSource)
	{
	case REFERENCE_VALUE:
		sprintf(updateStr+strlen(updateStr), "REF,%d", newDataLCL);
		if (refAttrName != NULL)
			sprintf(updateStr+strlen(updateStr), ",%s", refAttrName);
		break;
	case CONSTANT_VALUE:
		sprintf(updateStr+strlen(updateStr), "CONST,%s", newDataConst->getStrValue());
		break;
	}

	char* evStr = new char[strlen(updateStr)+1];
	strcpy(evStr, updateStr);
	return evStr;	
}

/**
 * Construct an insert statement
 *@param insertAt The LCL of the node which will be the parent node of the new node/subtree inserted
 *@param insertOpt Insert a file for a node.
 *@param fileName The name of the XML document to be inserted. 
 *@param element The element node to be inserted
 *@param attrNum The number of attribute of the element to be inserted
 *@param attributes The attributes of the element to be inserted. 
 *@returns An insert statement. 
 */
char* PlanSegmentGenerator::generateInsertStr(LCLType insertAt,
											   int insertOpt,
											   char* fileName,
											   InsertValueUnit* element,
											   int attrNum,
											   InsertValueUnit** attributes)
{
	char insertStr[1000];

	strcpy(insertStr, "U,");

	switch (insertOpt)
	{
	case INSERT_FILE:
		// insert an XML document. 
		sprintf(insertStr+strlen(insertStr), "InsFile,%d,%s",insertAt,fileName);
		break;

	case INSERT_ELEMENT:
		// insert an element
		{
			// element name
			sprintf(insertStr+strlen(insertStr), "InsENode,%d,%s,",
					insertAt, element->name);

			// element content 
			switch (element->valueSource)
			{
			case REFERENCE_VALUE:
				sprintf(insertStr+strlen(insertStr),"REF,%d",element->LCL);
				if (element->attrName != NULL)
					sprintf(insertStr+strlen(insertStr),",%s", element->attrName);
				else strcat(insertStr,",X");
				break;
			case CONSTANT_VALUE:
				if (strlen(element->constValue->getStrValue()) == 0)
					strcat(insertStr, "<NOVAL>");
				else
					sprintf(insertStr+strlen(insertStr),"CONST,%s",element->constValue->getStrValue());
				break;
			default:
				strcat(insertStr, "<NOVAL>");
			}

			// attributes
			if (attrNum > 0) strcat(insertStr, ",");

			for (int i=0; i<attrNum; i++)
			{
				// attribute name
				sprintf(insertStr+strlen(insertStr), "%s,", attributes[i]->name);
				
				// attribute value
				
				switch (attributes[i]->valueSource)
				{
				case REFERENCE_VALUE:
					sprintf(insertStr+strlen(insertStr),"REF,%d",attributes[i]->LCL);
					if (attributes[i]->attrName != NULL)
						sprintf(insertStr+strlen(insertStr),",%s", attributes[i]->attrName);
					else 
						strcat(insertStr, ",X");
					break;
				case CONSTANT_VALUE:
					if (strlen(attributes[i]->constValue->getStrValue()) == 0)
						strcat(insertStr, "<NOVAL>");
					else
						sprintf(insertStr+strlen(insertStr),"CONST,%s",attributes[i]->constValue->getStrValue());
					break;
				}
				
				if (i<attrNum-1) 
					strcat(insertStr, ",");
			}
		}
		break;

	case INSERT_ATTRIBUTE:
		// insert an attribute
		{
			// element name
			sprintf(insertStr+strlen(insertStr), "InsAttr,%d,",	insertAt);

			// attributes

			// attribute name
			sprintf(insertStr+strlen(insertStr), "%s,", attributes[0]->name);
				
			// attribute value
				
			switch (attributes[0]->valueSource)
			{
			case REFERENCE_VALUE:
				sprintf(insertStr+strlen(insertStr),"REF,%d",attributes[0]->LCL);
				if (attributes[0]->attrName != NULL)
				{
					strcat(insertStr, ",");
					strcat(insertStr, attributes[0]->attrName);
				}
				break;
			case CONSTANT_VALUE:
				if (strlen(attributes[0]->constValue->getStrValue()) == 0)
					strcat(insertStr, "<NOVAL>");
				else
					sprintf(insertStr+strlen(insertStr),"CONST,%s",attributes[0]->constValue->getStrValue());
				break;
			}				
		}
		break;
	}

	char* evStr = new char[strlen(insertStr)+1];
	strcpy(evStr, insertStr);
	return evStr;	
}

/**
 * Constrct a delete statement. 
 *@param rootLCL the LCL of the node to be deleted, or the root of the subtree to be deleted. 
 *@param attrName The attribute name, in case the node is an attribute node
 *@param deleteOption The delete option, node or subtree. 
 *@returns A delete statement.
 */ 
char* PlanSegmentGenerator::generateDeleteStr(LCLType rootLCL,
											  char* attrName,
											  int deleteOption)
{
	char deleteStr[1000];

	strcpy(deleteStr, "U,");

	switch (deleteOption)
	{
	case OPERATE_ON_SUBTREE:
		if (attrName == NULL)
			sprintf(deleteStr+strlen(deleteStr), "DelTree,%d", rootLCL);
		else 
			sprintf(deleteStr+strlen(deleteStr), "DelAttr,%d,%s", rootLCL,attrName);
		break;
	case OPERATE_ON_CONTENT:
		if (attrName == NULL)
			sprintf(deleteStr+strlen(deleteStr), "DelTNode,%d", rootLCL);
		else
			sprintf(deleteStr+strlen(deleteStr), "DelAttrValue,%d,%s", rootLCL,attrName);
		break;
	}

	char* evStr = new char[strlen(deleteStr)+1];
	strcpy(evStr, deleteStr);
	return evStr;	
}

