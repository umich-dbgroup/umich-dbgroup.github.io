/**
COPYRIGHT  � 2000-2004
THE REGENTS OF THE UNIVERSITY OF MICHIGAN ALL RIGHTS RESERVED

PERMISSION IS GRANTED TO USE, COPY, CREATE DERIVATIVE WORKS A
ND REDISTRIBUTE THIS SOFTWARE AND SUCH DERIVATIVE WORKS FOR 
NONCOMMERCIAL EDUCATION AND RESEARCH PURPOSES, SO LONG AS NO 
FEE IS CHARGED, AND SO LONG AS THE COPYRIGHT NOTICE ABOVE, 
THIS GRANT OF PERMISSION, AND THE DISCLAIMER BELOW APPEAR IN 
ALL COPIES MADE; AND SO LONG AS THE NAME OF THE UNIVERSITY OF 
MICHIGAN IS NOT USED IN ANY ADVERTISING OR PUBLICITY PERTAINING 
TO THE USE OR DISTRIBUTION OF THIS SOFTWARE WITHOUT SPECIFIC, 
WRITTEN PRIOR AUTHORIZATION.

THIS SOFTWARE IS PROVIDED AS IS, WITHOUT REPRESENTATION FROM 
THE UNIVERSITY OF MICHIGAN AS TO ITS FITNESS FOR ANY PURPOSE, 
AND WITHOUT WARRANTY BY THE UNIVERSITY OF MICHIGAN OF ANY KIND, 
EITHER EXPRESS OR IMPLIED, INCLUDING WITHOUT LIMITATION THE 
IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A 
PARTICULAR PURPOSE. THE REGENTS OF THE UNIVERSITY OF MICHIGAN 
SHALL NOT BE LIABLE FOR ANY DAMAGES, INCLUDING SPECIAL, INDIRECT, 
INCIDENTAL, OR CONSEQUENTIAL DAMAGES, WITH RESPECT TO ANY CLAIM 
ARISING OUT OF OR IN CONNECTION WITH THE USE OF THE SOFTWARE, 
EVEN IF IT HAS BEEN OR IS HEREAFTER ADVISED OF THE POSSIBILITY 
OF SUCH DAMAGES.
*/
#ifndef __PlanSegmentGenerator_H
#define __PlanSegmentGenerator_H

#include "WitnessTreeTracker.h"
#include "PartialEvaluationPlan.h"

/**
 * class PlanSegmentGenerator
 * This class provide functions that generate plan segment 
 * (one or more statement in the physical plan (evaluator interface)). 
 * This can be used for simple plan generator, as well as other 
 * optimized plan generators. 
 * 
 *@see WitnessTreeTracker
 *@see PartialEvaluationPlan
 *
 *@author Yuqing Melanie Wu
 */
class PlanSegmentGenerator
{
public:
	PlanSegmentGenerator(void);
	~PlanSegmentGenerator(void);

	// the following functions generate plan for a specific pattern tree node
	PartialEvaluationPlan* generatePlanForPtSelectionNode(
		MarkedPatternTreeSelectionNode* selectionNode,
		NodeIDType psNodeID);

	PartialEvaluationPlan* generatePlanForPtReferenceNode(PatternTreeReferenceNode* referenceNode,
		int inputWitnessTreeNum, 
		PartialEvaluationPlan** partialEvPlanForInputWitnessTree);

	// the following functions generate evaluation plan for one single iterator, in string format. 
	char* generateIndexAccessStr(char* indexname, 
		LCLType lcl,
		char* filename, 
		int indexType, 
		int indexServerType, 
		Value* minVal,
		Value* maxVal);

	char* generateScanAccessStr(LCLType lcl, 
		char* filename, SelectionCondition* cond);

	char* generateStructuralJoinStr(NodeIDType ancsLCL,
		NodeIDType descLCL,
		int relationwithParent,
		int joinAlgo, 
		bool nested,
		int resultOpt);

	// this is the one that generate filter string (a general case)
	char* generateFilterStr(int OrNum, 
		int* andNums,
		PO_FilterPredicate*** filterCond,
		LCLWTTreeMapType* wtTree);

	char* generateProjectionStr(int num,
		LCLType* list);

	char* generateDuplicateEliminationStr(int opt, 
		LCLType deLCL,
		char* attrName);

	char* generateValueJoinStr(LCLType rootLCL,
		LCLType leftLCL,
		LCLType rightLCL, 
		int op,
		int opDataType,
		char* leftAttrName, 
		char* rightAttrName,
		char* fileName,
		char* indexName,
		int joinOpt,
		bool anyJoin,
		bool inputSorted);

	char* generateHashedValueJoinStr(LCLType rootLCL,
		LCLType leftLCL,
		LCLType rightLCL, 
		char* fileName,
		char* indexName,
		int joinOpt,
		bool anyJoin);

	char* generateAggregateFuncStr(int func,
		LCLType operandLCL,
		char* attrName,				   
		int operandType, 
		LCLType resultLCL);

	char* generateSortStr(bool simplesort,
		OrderKey* orderkey);		

	char* generateMLCAStr(LCLType rootLCL, 
		int mlcaNodeNum, 
		LCLType* mlcaNodeLCLs);

	char* generateUpdateStr(LCLType lcl,
		char* attrname, 
		int dataSource,
		LCLType newDataLCL,
		char* refAttrName,
		Value* newDataValue);

	char* generateInsertStr(LCLType insertAt,
		int insertOpt,
		char* fileName,
		InsertValueUnit* element,
		int attrNum,
		InsertValueUnit** attributes);

	char* generateDeleteStr(LCLType rootLCL,
		char* attrName,
		int deleteOption);

private: 
	WitnessTreeTracker wtTracker;

	/**
	 * For constructing error message
	 */
	char errMsg[1000];

friend class Value;
};

#endif