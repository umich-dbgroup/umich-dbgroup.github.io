/**
COPYRIGHT  ?2000-2004
THE REGENTS OF THE UNIVERSITY OF MICHIGAN ALL RIGHTS RESERVED

PERMISSION IS GRANTED TO USE, COPY, CREATE DERIVATIVE WORKS A
ND REDISTRIBUTE THIS SOFTWARE AND SUCH DERIVATIVE WORKS FOR 
NONCOMMERCIAL EDUCATION AND RESEARCH PURPOSES, SO LONG AS NO 
FEE IS CHARGED, AND SO LONG AS THE COPYRIGHT NOTICE ABOVE,  
THIS GRANT OF PERMISSION, AND THE DISCLAIMER BELOW APPEAR IN 
ALL COPIES MADE; AND SO LONG AS THE NAME OF THE UNIVERSITY OF 
MICHIGAN IS NOT USED IN ANY ADVERTISING OR PUBLICITY PERTAINING 
TO THE USE OR DISTRIBUTION OF THIS SOFTWARE WITHOUT SPECIFIC, 
WRITTEN PRIOR AUTHORIZATION.

THIS SOFTWARE IS PROVIDED AS IS, WITHOUT REPRESENTATION FROM 
THE UNIVERSITY OF MICHIGAN AS TO ITS FITNESS FOR ANY PURPOSE, 
AND WITHOUT WARRANTY BY THE UNIVERSITY OF MICHIGAN OF ANY KIND, 
EITHER EXPRESS OR IMPLIED, INCLUDING WITHOUT LIMITATION THE 
IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A 
PARTICULAR PURPOSE. THE REGENTS OF THE UNIVERSITY OF MICHIGAN 
SHALL NOT BE LIABLE FOR ANY DAMAGES, INCLUDING SPECIAL, INDIRECT, 
INCIDENTAL, OR CONSEQUENTIAL DAMAGES, WITH RESPECT TO ANY CLAIM 
ARISING OUT OF OR IN CONNECTION WITH THE USE OF THE SOFTWARE, 
EVEN IF IT HAS BEEN OR IS HEREAFTER ADVISED OF THE POSSIBILITY 
OF SUCH DAMAGES.
*/

// wield warning4701 on line1700, variable i. 
#pragma warning(disable: 4701)


#include "SimplePlanGenerator.h"

/**
 * Constructor
 */
SimplePlanGenerator::SimplePlanGenerator(IndexMng* indexmng)
{
	this->indexMng = indexmng;
	this->indexMatching = new IndexMatching(this->indexMng);
}

/**
 * Destructor
 */
SimplePlanGenerator::~SimplePlanGenerator(void)
{
	delete this->indexMatching;
}

/**
 * Given a logical plan (process tree), generate a physical plan 
 * that evaluate the query. 
 *@param psTree The logical plan (process tree).
 *@param planGenOpt How to generate the plan, now, we only support simple plan generation. 
 *@param planFormatOpt What the output is, tree or string. 
 *@param EvTree The evaluation tree (output). 
 *@param EvPlan The plan in string (output). 
 *@returns A boolean variable which indicate whether the plan generation is finished successfully. 
 */
bool SimplePlanGenerator
::generateSimplePlan(ProcessTree* psTree,
					 int planGenOpt, 
					 char** EvPlan)
{
	bool success = true;

	// check whether the plan is marked, Simple Plan generator takes only marked process tree as input. 
	if (!this->psTreeIsMarked(psTree))
	{
		globalErrorInfo.insertProblem(ERR_TYPE_ERROR, __LINE__, 
			"SimplePlanGenerator::generateSimplePlan", __FILE__,
			"The Simple Plan Generator takes a process tree with marked pattern tree as input. Please run IndexSelection first.");
		success = false;
		goto exit;
	}

	this->planGenOption = planGenOpt;
	
	// generate physical plan
	this->PsTree = psTree;
	PartialEvaluationPlan* partialPlan = this->generateSimplePlanForProcessTree();
	
	if (partialPlan == NULL)
	{
		success = false;	
		globalErrorInfo.insertProblem(ERR_TYPE_ERROR, __LINE__, 
			"SimplePlanGenerator::generateSimplePlan", __FILE__,
			"Error reported when generating simple plan for a process tree." );
		goto exit;
	}

	char* evPlan = partialPlan->getEvaluationPlan();
	*EvPlan = new char[strlen(evPlan)+1];
	strcpy(*EvPlan, evPlan);
	delete partialPlan; 

exit:
	return success;
}

/**
 * Generate simple plan for a process tree. 
 * This is the starting point for recursive called to generate physical plan
 * for subtrees, given the root of the tree. 
 *@returns The partial plan that compute the process tree. 
 */
PartialEvaluationPlan* SimplePlanGenerator
::generateSimplePlanForProcessTree()
{
	return this->generateSimplePlanForProcessTreeRootedAt(
		this->PsTree->getRootID(),
		NULL, NULL);	// without carry in plan for value join. 
}

/**
 * This method is called recursively during physical plan generation. 
 *@param rootid The id of the root node of the sub process tree to be processed.
 *@returns The partial plan that compute the sub process tree. 
 */
PartialEvaluationPlan* SimplePlanGenerator
::generateSimplePlanForProcessTreeRootedAt(NodeIDType rootid,
										   char* carryinJoinIndexName,
										   PartialEvaluationPlan* partialEvPlanForValueJoin)
{
	PartialEvaluationPlan* partialPlan;

	// generate the plan for evaluation the subtree rooted at its children	
	ProcessTreeNode* psNode = this->PsTree->getPsNodeWithID(rootid);
	int childNum = psNode->getChildNumber();

	PartialEvaluationPlan** partialEvPlanForChildren = new PartialEvaluationPlan*[childNum];

	for (int i=0; i<childNum; i++)
		partialEvPlanForChildren[i] = NULL;

	for (int i=0; i<childNum; i++)
	{
		partialEvPlanForChildren[i] = this->generateSimplePlanForProcessTreeRootedAt(
			psNode->getChildIDAt(i), NULL, NULL);
		if (partialEvPlanForChildren[i] == NULL)
		{
			partialPlan = NULL;
			sprintf(this->errMsg, "Error reported when generting simple plan for the %dth child of process tree node (id=%d).", 
				i, rootid);
			globalErrorInfo.insertProblem(ERR_TYPE_ERROR, __LINE__, 
				"SimplePlanGenerator::generateSimplePlanForProcessTreeRootedAt", __FILE__,
				this->errMsg);
			goto exit;
		}
	}

	// generate the plan for the root node that stitch the children nodes together. 
	partialPlan = this->generateSimplePlanForProcessTreeNode(
		this->PsTree->getPsNodeWithID(rootid), 
		childNum, 
		partialEvPlanForChildren,
		carryinJoinIndexName,
		partialEvPlanForValueJoin);

exit:
	// remove the partial plans for the children nodes. 
	for (i=0; i<childNum; i++)
		if (partialEvPlanForChildren[i] != NULL)
			delete partialEvPlanForChildren[i];
	delete [] partialEvPlanForChildren;

	return partialPlan;
}

/**
 * Generate the physical plan for a single process tree node. 
 *@param psNode The process tree node to be processed.
 *@param inputWitnessTreeNumber The number of witness trees that may provide input to the process tree node. 
 *@param partialEvPlanForChildren The evaluation plan that compute the witness trees. 
 *@returns The partial evaluation plan that compute the process tree node. 
 */
PartialEvaluationPlan* SimplePlanGenerator
::generateSimplePlanForProcessTreeNode(ProcessTreeNode* psNode,
									   int inputWitnessTreeNumber, 
									   PartialEvaluationPlan** partialEvPlanForChildren,
									   char* carryinJoinIndexName,
									   PartialEvaluationPlan* partialEvPlanForValueJoin)
{
	PartialEvaluationPlan* partialEvPlan;

	// We don't handle carry-in plan for one-side value join for process 
	// tree node other than process tree select node.
	
	if ((psNode->getPsNodeType() != PROCESS_TREE_SELECT_NODE) 
		&& (partialEvPlanForValueJoin != NULL))
	{
		globalErrorInfo.insertProblem(ERR_TYPE_ERROR, __LINE__, 
			"SimplePlanGenerator::generateSimplePlanForProcessTreeNode", __FILE__,
			"We don't handle carry-in plan for one-side value join for process tree node other than process tree select node.");
		partialEvPlan = NULL;
		goto exit;
	}

	// generate plan for the pattern tree associated with this process tree node.
	// then, add on the operation associated with the process tree node (such as projection, etc).

	switch (psNode->getPsNodeType())
	{
	case PROCESS_TREE_SELECT_NODE:
	case PROCESS_TREE_JOIN_NODE:
		{
			// a process tree selection node can have more than one child
			partialEvPlan = this->generateSimplePlanForPsSelectNode(
									(ProcessTreeSelectNode*) psNode,
									inputWitnessTreeNumber,
									partialEvPlanForChildren,
									carryinJoinIndexName,
									partialEvPlanForValueJoin);
		}
		break;

	case PROCESS_TREE_PROJECT_NODE:
		{
			if (psNode->getChildNumber() != 1)
			{
				globalErrorInfo.insertProblem(ERR_TYPE_ERROR, __LINE__, 
					"SimplePlanGenerator::generateSimplePlanForProcessTreeNode", __FILE__,
					"Process tree projection node can not have more than one process tree node as chlidren.");
				partialEvPlan = NULL;
				goto exit;
			}

			partialEvPlan = this->generateSimplePlanForPsProjectNode(
									(ProcessTreeProjectNode*) psNode,
									partialEvPlanForChildren[0]);
		}
		break;

	case PROCESS_TREE_AGGREGATE_FUNCTION_NODE:
		{
			if (psNode->getChildNumber() != 1)
			{
				globalErrorInfo.insertProblem(ERR_TYPE_ERROR, __LINE__, 
					"SimplePlanGenerator::generateSimplePlanForProcessTreeNode", __FILE__,
					"Process tree aggregate function node can not have more than one process tree node as chlidren.");
				partialEvPlan = NULL;
				goto exit;
			}

			partialEvPlan = this->generateSimplePlanForPsAggregateFunctionNode(
									(ProcessTreeAggregateFunctionNode*) psNode,
									partialEvPlanForChildren[0]);
		}
		break;

	case PROCESS_TREE_DUPLICATE_ELIMINATION_NODE:
		{		
			if (psNode->getChildNumber() != 1)
			{								
				globalErrorInfo.insertProblem(ERR_TYPE_ERROR, __LINE__, 
					"SimplePlanGenerator::generateSimplePlanForProcessTreeNode", __FILE__,
					"Process tree duplicate elimination node can not have more than one process tree node as chlidren.");
				partialEvPlan = NULL;
				goto exit;
			}
			partialEvPlan = this->generateSimplePlanForPsDuplicateEliminationNode(
									(ProcessTreeDuplicateEliminationNode*) psNode,
									partialEvPlanForChildren[0]);
		}
		break;

	case PROCESS_TREE_FILTER_NODE:
		{		
			if (psNode->getChildNumber() != 1)
			{
				globalErrorInfo.insertProblem(ERR_TYPE_ERROR, __LINE__, 
					"SimplePlanGenerator::generateSimplePlanForProcessTreeNode", __FILE__,
					"Process tree filter node can not have more than one process tree node as chlidren.");
				partialEvPlan = NULL;
				goto exit;
			}
			
			partialEvPlan = this->generateSimplePlanForPsFilterNode(
									(ProcessTreeFilterNode*) psNode,
									partialEvPlanForChildren[0]);
		}
		break;

	case PROCESS_TREE_SORT_NODE:
		{		
			if (psNode->getChildNumber() != 1)
			{
				globalErrorInfo.insertProblem(ERR_TYPE_ERROR, __LINE__, 
					"SimplePlanGenerator::generateSimplePlanForProcessTreeNode", __FILE__,
					"Process tree sort node can not have more than one process tree node as chlidren.");
				partialEvPlan = NULL;
				goto exit;
			}
			
			partialEvPlan = this->generateSimplePlanForPsSortNode(
									(ProcessTreeSortNode*) psNode,
									partialEvPlanForChildren[0]);
		}
		break;

	case PROCESS_TREE_SET_NODE:
		{		
			if (psNode->getChildNumber() != 2)
			{
				globalErrorInfo.insertProblem(ERR_TYPE_ERROR, __LINE__, 
					"SimplePlanGenerator::generateSimplePlanForProcessTreeNode", __FILE__,
					"Process tree set node must have two chlidren.");
				partialEvPlan = NULL;
				goto exit;
			}
			
			partialEvPlan = this->generateSimplePlanForPsSetNode(
									inputWitnessTreeNumber,
									partialEvPlanForChildren);
		}
		break;

	case PROCESS_TREE_CONSTRUCT_NODE:
		{		
			if (psNode->getChildNumber() != 1)
			{
				globalErrorInfo.insertProblem(ERR_TYPE_ERROR, __LINE__, 
					"SimplePlanGenerator::generateSimplePlanForProcessTreeNode", __FILE__,
					"Process tree construct node can not have more than one process tree node as chlidren.");
				partialEvPlan = NULL;
				goto exit;
			}
			
			partialEvPlan = this->generateSimplePlanForPsConstructNode(
									(ProcessTreeConstructNode*) psNode,
									partialEvPlanForChildren[0]);
		}
		break;

	case PROCESS_TREE_MLCA_NODE:
		{
			int childNum = psNode->getChildNumber();
			PartialEvaluationPlan* inputplan = NULL;

			if (childNum == 0)
				inputplan = NULL;
			else if (childNum == 1)
				inputplan = partialEvPlanForChildren[0];
			else 
			{
				globalErrorInfo.insertProblem(ERR_TYPE_ERROR, __LINE__, 
					"SimplePlanGenerator::generateSimplePlanForProcessTreeNode", __FILE__,
					"Process tree MLCA node can not have more than one process tree node as chlidren.");
				partialEvPlan = NULL;
				goto exit;
			}				
			partialEvPlan = this->generateSimplePlanForPsMLCANode(
									(ProcessTreeMLCANode*) psNode,
									inputplan);
		}
		break;

	case PROCESS_TREE_UPDATE_NODE:
		{
			if (psNode->getChildNumber() != 1)
			{
				globalErrorInfo.insertProblem(ERR_TYPE_ERROR, __LINE__, 
					"SimplePlanGenerator::generateSimplePlanForProcessTreeNode", __FILE__,
					"Process tree update node can not have more than one process tree node as chlidren.");
				partialEvPlan = NULL;
				goto exit;
			}									   
			partialEvPlan = this->generateSimplePlanForPsUpdateNode(
									(ProcessTreeUpdateNode*) psNode,
									partialEvPlanForChildren[0]);
		}
		break;

	case PROCESS_TREE_DELETE_NODE:
		{
			if (psNode->getChildNumber() != 1)
			{
				globalErrorInfo.insertProblem(ERR_TYPE_ERROR, __LINE__, 
					"SimplePlanGenerator::generateSimplePlanForProcessTreeNode", __FILE__,
					"Process tree delete node can not have more than one process tree node as chlidren.");
				partialEvPlan = NULL;
				goto exit;
			}									   
			partialEvPlan = this->generateSimplePlanForPsDeleteNode(
									(ProcessTreeDeleteNode*) psNode,
									partialEvPlanForChildren[0]);
		}
		break;

 	case PROCESS_TREE_INSERT_NODE:
		{
			if (psNode->getChildNumber() != 1)
			{
				globalErrorInfo.insertProblem(ERR_TYPE_ERROR, __LINE__, 
					"SimplePlanGenerator::generateSimplePlanForProcessTreeNode", __FILE__,
					"Process tree insert node can not have more than one process tree node as chlidren.");
				partialEvPlan = NULL;
				goto exit;
			}									   
			partialEvPlan = this->generateSimplePlanForPsInsertNode(
									(ProcessTreeInsertNode*) psNode,
									partialEvPlanForChildren[0]);
		}
		break;
  
	default:
		sprintf(this->errMsg, "%d is not a valid Process Tree node type", 
			psNode->getPsNodeType());
		globalErrorInfo.insertProblem(ERR_TYPE_ERROR, __LINE__, 
			"SimplePlanGenerator::generateSimplePlanForProcessTreeNode", __FILE__,
			this->errMsg);
		partialEvPlan = NULL;
		goto exit;
		break;
	}

exit:
	return partialEvPlan;
}

/**
 * Generate partial plan for a process tree selection node. 
 *@param psSelectionNode The process tree selection node to be processed.
 *@param inputWitnessTreeNumber The number of witness trees that may provide input to the process tree node. 
 *@param partialEvPlanForChildren The evaluation plan that compute the witness trees. 
 *@returns The partial evaluation plan that compute the process tree selection node. 
 */
PartialEvaluationPlan* SimplePlanGenerator
::generateSimplePlanForPsSelectNode(ProcessTreeSelectNode* psSelectionNode,
									int inputWitnessTreeNumber, 
									PartialEvaluationPlan** partialEvPlanForInputWitnessTrees,
									char* carryinJoinIndexName,
									PartialEvaluationPlan* partialEvPlanForValueJoin)
{
	// each process tree selection node has an associtated pattern tree. 
	PatternTree* ptTree = psSelectionNode->getPatternTree();

	PartialEvaluationPlan* partialPlan;
	switch (ptTree->getPatternTreeType())
	{
	case PATTERN_TREE_NORMAL:
		{
			// for a normal pattern tree, generate plan for the pattern tree. 
			partialPlan = this->generateSimplePlanForPatternTree(ptTree,
				psSelectionNode->getNodeID(),
				inputWitnessTreeNumber,
				partialEvPlanForInputWitnessTrees,
				carryinJoinIndexName,
				partialEvPlanForValueJoin);
		}
		break;

	case PATTERN_TREE_CONSTRUCT_TAGGING:
			globalErrorInfo.insertProblem(ERR_TYPE_ERROR, __LINE__, 
			"SimplePlanGenerator::generateSimplePlanForPsSelectNode", __FILE__,
			"A pattern tree for construct (tagging) should be processed in generateSimplePlanForPsConstructNode rather than here.");
		partialPlan = NULL;
		break;

	default: 
		sprintf(this->errMsg, "%d is not a valid pattern tree type.", ptTree->getPatternTreeType());
		globalErrorInfo.insertProblem(ERR_TYPE_ERROR, __LINE__, 
			"SimplePlanGenerator::generateSimplePlanForPsSelectNode", __FILE__,
			this->errMsg);
		partialPlan = NULL;
		break;
	}

	return partialPlan;
}

/**
 * Generate plan for a process tree project node. 
 *@param projNode The process tree project node to be processed. 
 *@param partialEvPlanForInputWitnessTree The partial plan which compute the input witness tree to the projection operation. 
 *@param A partial plan that compute the projection. 
 */
PartialEvaluationPlan* SimplePlanGenerator
::generateSimplePlanForPsProjectNode(ProcessTreeProjectNode* projNode,
									 PartialEvaluationPlan* partialEvPlanForInputWitnessTree)
{
	int projNum = projNode->getProjectionNumber();
	LCLType* projLCLs = projNode->getProjectionLCLs();

	char* evStr = NULL;
	bool success = true;
	PartialEvaluationPlan* partialEvPlan = NULL;

	char* projStr = this->planSegmentGenerator.generateProjectionStr(
			projNum, projLCLs);

	if (projStr == NULL) 
	{
		success = false;
		globalErrorInfo.insertProblem(ERR_TYPE_ERROR, __LINE__, 
			"SimplePlanGenerator::generateSimplePlanForPsProjectNode", __FILE__,
			"Error reported when generating projection statement." );
		goto exit;
	}

	evStr = new char[strlen(projStr) + strlen(partialEvPlanForInputWitnessTree->getEvaluationPlan())+3];
	strcpy(evStr, projStr);
	strcat(evStr, "\n");
	strcat(evStr, partialEvPlanForInputWitnessTree->getEvaluationPlan());

	delete [] projStr;
	
	// construct the witnesstree after projection
	LCLWTTreeMapType* wtTree 
		= this->wtTracker.projectWitnessTree(partialEvPlanForInputWitnessTree->getWTTree(),
												   projNum, projLCLs);

	// construct the partial plan that includes the computation of the projection.
	partialEvPlan = new PartialEvaluationPlan(evStr, wtTree, 
									NULL);						// order by node id

	if (partialEvPlan == NULL)
	{
		success = false;
		globalErrorInfo.insertProblem(ERR_TYPE_ERROR, __LINE__, 
			"SimplePlanGenerator::generateSimplePlanForPsProjectNode", __FILE__,
			"Error reported when generating plan for process tree projection node." );
		goto exit;
	}

exit:
	// clean up
	if (evStr != NULL) delete [] evStr;

	// return
	if (success)
		return partialEvPlan;
	else return NULL;
}

/**
 * Generate plan for process tree duplicate elimination node. 
 *@param deNode The process tree duplicate elimination node to be processed. 
 *@param partialEvPlanForInputWitnessTree The partial plan which compute the input witness tree to the duplication elimination operation. 
 *@param A partial plan that compute the duplicate elimination. 
 */
PartialEvaluationPlan* SimplePlanGenerator
::generateSimplePlanForPsDuplicateEliminationNode(
	ProcessTreeDuplicateEliminationNode* deNode,
	PartialEvaluationPlan* partialEvPlanForInputWitnessTree)
{
	char* evStr = NULL;
	bool success = true;
	PartialEvaluationPlan* partialEvPlan = NULL;

	// get the attribute name
	char* attrName = this->wtTracker.getAttrName(
		partialEvPlanForInputWitnessTree->getWTTree(),
		this->PsTree,
		deNode->getDELCL());


	// generate the duplicate elimination statment (string)
	char* deStr = this->planSegmentGenerator.generateDuplicateEliminationStr(
										deNode->getDEOption(),
										deNode->getDELCL(),
										attrName);
	if (deStr == NULL) 
	{
		success = false;
		globalErrorInfo.insertProblem(ERR_TYPE_ERROR, __LINE__, 
			"SimplePlanGenerator::generateSimplePlanForPsDuplicateEliminationNode", __FILE__,
			"Error reported when generating duplicate elimination statement." );
		goto exit;
	}

	evStr = new char[strlen(deStr) + strlen(partialEvPlanForInputWitnessTree->getEvaluationPlan())+2];
	strcpy(evStr, deStr);
	strcat(evStr, "\n");
	strcat(evStr, partialEvPlanForInputWitnessTree->getEvaluationPlan());

	delete [] deStr;
	
	LCLWTTreeMapType* wtTree = this->wtTracker.deWitnessTree(partialEvPlanForInputWitnessTree->getWTTree());

	OrderKey* newOrderKey;
	if (partialEvPlanForInputWitnessTree->getOrderKey() == NULL)
		newOrderKey = NULL;
	else newOrderKey = new OrderKey(partialEvPlanForInputWitnessTree->getOrderKey());


	partialEvPlan = new PartialEvaluationPlan(evStr, wtTree, 
									newOrderKey);

	if (partialEvPlan == NULL)
	{
		success = false;
		globalErrorInfo.insertProblem(ERR_TYPE_ERROR, __LINE__, 
			"SimplePlanGenerator::generateSimplePlanForPsDuplicateEliminationNode", __FILE__,
			"Error reported when generating plan for process tree duplicate elimination node." );
		goto exit;
	}


exit:
	// clean up
	if (evStr != NULL) delete [] evStr;	
	if (attrName != NULL) delete [] attrName;

	// return
	if (success) 
		return partialEvPlan;
	else return NULL;
}

/**
 * Construct physical plan for aggregate function. 
 *@param aggrNode The process tree aggregate function node to be processed. 
 *@param partialEvPlanForInputWitnessTree The partial plan which compute the input witness tree to the aggregate function.
 *@param A partial plan that compute the aggregate function. 
 */
PartialEvaluationPlan* SimplePlanGenerator
::generateSimplePlanForPsAggregateFunctionNode(
	ProcessTreeAggregateFunctionNode* aggrNode,
	PartialEvaluationPlan* partialEvPlanForInputWitnessTree)
{
	char* evStr = NULL;
	bool success = true;
	PartialEvaluationPlan* partialEvPlan = NULL;

	// get the LCL of the operand and result of the aggregate function. 
	LCLType resultLCL = aggrNode->getResultNodeLCL();
	LCLType operandLCL = aggrNode->getOperandNode();

	// get the attribut name, if applied 
	char* attrName = this->wtTracker.getAttrName(
		partialEvPlanForInputWitnessTree->getWTTree(), this->PsTree,
		operandLCL);

	// get the node type of the operand in the witness tree.
	int operandType = this->wtTracker.getWitnessTreeNodeType(
		partialEvPlanForInputWitnessTree->getWTTree(), 
		operandLCL);

	// generate an aggregate function statement
	char* prevEvStr = partialEvPlanForInputWitnessTree->getEvaluationPlan();

	char* groupbyStr = this->planSegmentGenerator.generateAggregateFuncStr(
		aggrNode->getAggregateFunction(),
		operandLCL,
		attrName,
		operandType,
		aggrNode->getResultNodeLCL());
		
	if (groupbyStr == NULL) 
	{
		success = false;
		globalErrorInfo.insertProblem(ERR_TYPE_ERROR, __LINE__, 
			"SimplePlanGenerator::generateSimplePlanForPsAggregateFunctionNode", __FILE__,
			"Error reported when generating group by statement." );
		goto exit;
	}
		
	evStr = new char[strlen(groupbyStr) + strlen(prevEvStr) + 2];
	strcpy(evStr, groupbyStr);
	strcat(evStr, "\n");
	strcat(evStr, prevEvStr);

	delete [] groupbyStr;

	// construct the new witness tree after aggregate function. 
	PsPt def;
	def.psTreeNodeID = aggrNode->getNodeID();
	def.ptTreeNodeID = -1;
	
	LCLWTTreeMapType* wtTree 
		= this->wtTracker.aggrFuncWitnessTree(partialEvPlanForInputWitnessTree->getWTTree(),
											  resultLCL, 
											  def);

	// construct the partial evaluation plan
	partialEvPlan = new PartialEvaluationPlan(evStr, wtTree, NULL);

exit:
	// clean up
	if (evStr != NULL) delete [] evStr;	
	if (attrName != NULL) delete [] attrName;

	// return
	if (success) 
		return partialEvPlan;
	else return NULL;
}

/**
 * Construct physical plan for filter operation. 
 *@param filterNode The process tree filter node to be processed. 
 *@param partialEvPlanForInputWitnessTree The partial plan which compute the input witness tree to the filter.
 *@param A partial plan that compute the filter operation. 
 */
PartialEvaluationPlan* SimplePlanGenerator
::generateSimplePlanForPsFilterNode(ProcessTreeFilterNode* filterNode,
								   PartialEvaluationPlan* partialEvPlanForInputWitnessTree)
{
	char* evStr = NULL;
	bool success = true;
	PartialEvaluationPlan* partialEvPlan = NULL;

	// fill the blank of the attribute name in the filter predicates
	int orNum = filterNode->getOrNum();
	int* andNums = filterNode->getAndNums();
	for (int i=0; i<orNum; i++)
		for (int j=0; j<andNums[i]; j++)
		{
			PO_FilterPredicate* pred = filterNode->getFilterPredicateAt(i,j);
			char* leftFileName = NULL;
			char* rightFileName = NULL;

			// get the attribute name of the two predicate if they are
			// attribute node
			LCLType leftLCL = pred->leftValueLCL;
			pred->leftAttrName = this->wtTracker.getAttrName(
				partialEvPlanForInputWitnessTree->getWTTree(),
				this->PsTree,
				leftLCL);

			LCLType rightLCL = pred->rightValueLCL;
			if (pred->rightValueOption != CONSTANT_VALUE)
				pred->rightAttrName = this->wtTracker.getAttrName(
					partialEvPlanForInputWitnessTree->getWTTree(),
					this->PsTree,
					rightLCL);
			else pred->rightAttrName = NULL;

			// find out whether there is any join index available. 
			
			if (pred->rightValueOption == CONSTANT_VALUE)
			{
				// if the right value is a constant value, we can not use join index. 
				pred->useJoinIndex = false;
				goto clearupForIndexMatching;
			}

			leftFileName = this->wtTracker.getFileName(
				partialEvPlanForInputWitnessTree->getWTTree(),
				this->PsTree,
				leftLCL);
			if (leftFileName == NULL)
			{
				pred->useJoinIndex = false;
				goto clearupForIndexMatching;
			}

			rightFileName = this->wtTracker.getFileName(
				partialEvPlanForInputWitnessTree->getWTTree(),
				this->PsTree,
				rightLCL);
			if (rightFileName == NULL)
			{
				pred->useJoinIndex = false;
				goto clearupForIndexMatching;
			}

			if (strcmp(leftFileName, rightFileName) == 0)
			{
				int leftNodeType = -1; 
				int rightNodeType = -1;
				char* leftStr = NULL;
				char* rightStr = NULL;
				int leftJoinIndexType = -1;
				int rightJoinIndexType = -1;
						
				leftNodeType = this->wtTracker.getWitnessTreeNodeType(
					partialEvPlanForInputWitnessTree->getWTTree(),leftLCL);
						
				if (leftNodeType == WT_ELEMENT_NODE)
				{
					leftStr = this->wtTracker.getElementTag(
						partialEvPlanForInputWitnessTree->getWTTree(),
						this->PsTree,
						leftLCL);
					leftJoinIndexType = JOININDEX_ELEMENTCONTENT;
				}
				else 
				{
					leftStr = this->wtTracker.getAttrName(
						partialEvPlanForInputWitnessTree->getWTTree(),
						this->PsTree,
						leftLCL);
					leftJoinIndexType = JOININDEX_ATTRIBUTEVALUE;
				}

				if (leftStr == NULL)
				{
					pred->useJoinIndex = false;
					goto clearupForIndexMatching;
				}

				rightNodeType = this->wtTracker.getWitnessTreeNodeType(
					partialEvPlanForInputWitnessTree->getWTTree(), rightLCL);
						
				if (rightNodeType == WT_ELEMENT_NODE)
				{
					rightStr = this->wtTracker.getElementTag(
						partialEvPlanForInputWitnessTree->getWTTree(),
						this->PsTree,
						rightLCL);
					rightJoinIndexType = JOININDEX_ELEMENTCONTENT;
				}
				else 
				{
					rightStr = this->wtTracker.getAttrName(
						partialEvPlanForInputWitnessTree->getWTTree(),
						this->PsTree,
						rightLCL);
					rightJoinIndexType = JOININDEX_ATTRIBUTEVALUE;
				}
				if (rightStr == NULL)
				{
					delete [] leftStr;
					pred->useJoinIndex = false;
					goto clearupForIndexMatching;
				}

				IndexMatchingType* im = NULL;
				this->indexMatching->matchJoinIndex(
						leftFileName, 
						leftStr, leftJoinIndexType,
						rightStr, rightJoinIndexType,
						im);


				if (im != NULL)
				{
					pred->useJoinIndex = true;
					pred->fileName = new char[strlen(leftFileName)+1];
					strcpy(pred->fileName, leftFileName);
					pred->indexName = new char[strlen(im->indexName)+1];
					strcpy(pred->indexName, im->indexName);
					delete im;
				}
				else 
				{
					// considering switch the position of the two operand,
					// when the filter option is SOME
					if (pred->filterOption == FILTER_OPTION_SOME)
					{
						this->indexMatching->matchJoinIndex(
							leftFileName, 
							rightStr, rightJoinIndexType,
							leftStr, leftJoinIndexType,
							im);

						if (im != NULL)
						{
							pred->useJoinIndex = true;
							pred->fileName = new char[strlen(leftFileName)+1];
							strcpy(pred->fileName, leftFileName);
							pred->indexName = new char[strlen(im->indexName)+1];
							strcpy(pred->indexName, im->indexName);

							// need to switch the two operand of the predicate
							LCLType tempLCL = pred->leftValueLCL;
							pred->leftValueLCL = pred->rightValueLCL;
							pred->rightValueLCL = tempLCL;

							char* tempAttrName = pred->leftAttrName;
							pred->leftAttrName = pred->rightAttrName;
							pred->rightAttrName = tempAttrName;

							delete im;
						}
						else 
							// no join index matches the two operand in the predicate
							// after switching
							pred->useJoinIndex = false;
					}
					else
						// if the filter option is not SOME, we cannot switch operands
						pred->useJoinIndex = false;
						
				}

				delete [] leftStr;
				delete [] rightStr;

			}
			else 
				// in case the two nodes are not from the same document, there is no 
				// join index available
				pred->useJoinIndex = false;
			
clearupForIndexMatching:
			if (leftFileName != NULL)
				delete [] leftFileName;
			if (rightFileName != NULL)
				delete [] rightFileName;
	
		}

	// generate the filter statement
	char* prevEvStr = partialEvPlanForInputWitnessTree->getEvaluationPlan();

	char* filterStr = this->planSegmentGenerator.generateFilterStr(
								filterNode->getOrNum(),
								filterNode->getAndNums(),
								filterNode->getFilterCondition(),
								partialEvPlanForInputWitnessTree->getWTTree());
		
	if (filterStr == NULL) 
	{
		success = false;
		globalErrorInfo.insertProblem(ERR_TYPE_ERROR, __LINE__, 
			"SimplePlanGenerator::generateSimplePlanForPsFilterNode", __FILE__,
			"Error reported when generating filter statement." );
		goto exit;
	}

	evStr = new char[strlen(filterStr) + strlen(prevEvStr) + 2];
	strcpy(evStr, filterStr);
	strcat(evStr, "\n");
	strcat(evStr, prevEvStr);

	delete [] filterStr;

	// generate the partial plan
	LCLWTTreeMapType* wtTree = this->wtTracker.filterWitnessTree(partialEvPlanForInputWitnessTree->getWTTree());

	OrderKey* newOrderKey;
	if (partialEvPlanForInputWitnessTree->getOrderKey() == NULL)
		newOrderKey = NULL;
	else newOrderKey = new OrderKey(partialEvPlanForInputWitnessTree->getOrderKey());

	partialEvPlan = new PartialEvaluationPlan(evStr, wtTree,
									newOrderKey);  // orderby key

	if (partialEvPlan == NULL)
	{
		success = false;
		globalErrorInfo.insertProblem(ERR_TYPE_ERROR, __LINE__, 
			"SimplePlanGenerator::generateSimplePlanForPsFilterNode", __FILE__,
			"Error reported when generating plan for process tree filter node." );
		goto exit;
	}

exit:
    if (evStr != NULL) delete [] evStr;	

	if (success)
		return partialEvPlan;
	else return NULL;
}

/**
 * Construct physical plan for sort operation.  
 *@param sortNode The process tree sort node to be processed. 
 *@param partialEvPlanForInputWitnessTree The partial plan which compute the input witness tree to the sort operation.
 *@param A partial plan that compute the set operation. 
 */
PartialEvaluationPlan* SimplePlanGenerator
::generateSimplePlanForPsSetNode(int inputWitnessTreeNum, 
								 PartialEvaluationPlan** partialEvPlanForInputWitnessTrees)
{
	if (inputWitnessTreeNum != 2)
		return NULL;

	char* evStr = NULL;
	PartialEvaluationPlan* partialEvPlan = NULL;

	char* setOpStr = "T,I,-1\n";
	char* leftBranchStr = partialEvPlanForInputWitnessTrees[0]->getEvaluationPlan();
	char* rightBranchStr = partialEvPlanForInputWitnessTrees[1]->getEvaluationPlan();

	int evStrLen = (int) strlen(setOpStr)  + 3
			+ (int) strlen(leftBranchStr) + (int) strlen(rightBranchStr);
					
	evStr = new char[evStrLen];
	strcpy(evStr, setOpStr);
	strcat(evStr, leftBranchStr);
	strcat(evStr, "\n");
	strcat(evStr, rightBranchStr);

	// generate the partial plan
	LCLWTTreeMapType* wtTree = this->wtTracker.setOpWitnessTrees(
		partialEvPlanForInputWitnessTrees[0]->getWTTree(),
		partialEvPlanForInputWitnessTrees[1]->getWTTree());

	partialEvPlan = new PartialEvaluationPlan(evStr, wtTree,
									NULL);  // orderby key

	if (partialEvPlan == NULL)
		globalErrorInfo.insertProblem(ERR_TYPE_ERROR, __LINE__, 
			"SimplePlanGenerator::generateSimplePlanForPsSetNode", __FILE__,
			"Error reported when generating plan for process tree set node." );

	return partialEvPlan;
}


/**
 * Construct physical plan for sort operation.  
 *@param sortNode The process tree sort node to be processed. 
 *@param partialEvPlanForInputWitnessTree The partial plan which compute the input witness tree to the sort operation.
 *@param A partial plan that compute the sort. 
 */
PartialEvaluationPlan* SimplePlanGenerator
::generateSimplePlanForPsSortNode(ProcessTreeSortNode* sortNode,
								 PartialEvaluationPlan* partialEvPlanForInputWitnessTree)
{
	char* evStr = NULL;
	bool success = true;
	PartialEvaluationPlan* partialEvPlan = NULL;
	char* sortStr;
					
	// compare the order requirement of the sortNode with the order specification 
	// of the witness tree, see whether this sort is needed

	OrderKey* orderRequirement = sortNode->getSortbyKey();
	OrderKey* wtTreeOrder = partialEvPlanForInputWitnessTree->getOrderKey();
	
	if (wtTreeOrder != NULL)
		if (orderRequirement->covers(wtTreeOrder))
		{
			partialEvPlan = new PartialEvaluationPlan(partialEvPlanForInputWitnessTree);
			if (partialEvPlan == NULL)
			{
				success = false;
				globalErrorInfo.insertProblem(ERR_TYPE_ERROR, __LINE__, 
					"SimplePlanGenerator::generateSimplePlanForPsSortNode", __FILE__,
					"Error reported when generating plan for process tree sort node." );
				goto exit;
			}	
			goto exit;
		}
	
	// generate sort statement

	sortStr = this->planSegmentGenerator.generateSortStr(
			sortNode->sortAllByNodeKey(),
			sortNode->getSortbyKey());
					
	if (sortStr == NULL) 
	{
		success = false;
		globalErrorInfo.insertProblem(ERR_TYPE_ERROR, __LINE__, 
			"SimplePlanGenerator::generateSimplePlanForPsSortNode", __FILE__,
			"Error reported when generating sort statement." );
		goto exit;
	}

	char* prevEvStr = partialEvPlanForInputWitnessTree->getEvaluationPlan();

	evStr = new char[strlen(sortStr) + strlen(prevEvStr) + 2];
	strcpy(evStr, sortStr);
	strcat(evStr, "\n");
	strcat(evStr, prevEvStr);

	delete [] sortStr;

	// generate the new witness tree. 
	LCLWTTreeMapType* wtTree = this->wtTracker.sortWitnessTree(partialEvPlanForInputWitnessTree->getWTTree());

	// generate the partial plan
	partialEvPlan = new PartialEvaluationPlan(evStr, wtTree,
					new OrderKey(sortNode->getSortbyKey()));

	if (partialEvPlan == NULL)
	{
		success = false;
		globalErrorInfo.insertProblem(ERR_TYPE_ERROR, __LINE__, 
			"SimplePlanGenerator::generateSimplePlanForPsSortNode", __FILE__,
			"Error reported when generating plan for process tree sort node." );
		goto exit;
	}

exit:
	if (evStr != NULL) delete [] evStr;	
	if (success)
		return partialEvPlan;
	else return NULL;
}

/**
 * Construct physical plan for reuslt/intermedicate result consturction. 
 *@param constructNode The process tree construct node to be processed. 
 *@param partialEvPlanForInputWitnessTree The partial plan which compute the input witness tree to the construct.
 *@param A partial plan that performs the result construction. 
 */
PartialEvaluationPlan* SimplePlanGenerator
::generateSimplePlanForPsConstructNode(ProcessTreeConstructNode* constructNode,
									   PartialEvaluationPlan* partialEvPlanForInputWitnessTree)
{
	bool success = true;
	PartialEvaluationPlan* partialEvPlan = NULL;

	PatternTree* ptTree = constructNode->getPatternTree();

	char* evStr = NULL;
	WitnessTreeNode* wtTreeNodes = NULL;
	
	char* constructStr = this->generateConstructStrTagging(ptTree, 
														   partialEvPlanForInputWitnessTree->getWTTree(),
														   constructNode->getNodeID(),
														   &wtTreeNodes);
		
	if (constructStr == NULL)
	{
		success = false;
		globalErrorInfo.insertProblem(ERR_TYPE_ERROR, __LINE__, 
			"SimplePlanGenerator::generateSimplePlanForPsConstructNode", __FILE__,
			"Error reported when generating construct statement." );
		goto exit;
	}

	char* prevEvStr = partialEvPlanForInputWitnessTree->getEvaluationPlan();

	evStr = new char[strlen(constructStr) + strlen(prevEvStr) + 2];
	strcpy(evStr, constructStr);
	strcat(evStr, "\n");
	strcat(evStr, prevEvStr);

	delete [] constructStr;

	// add the new constructed node to the witness tree

	LCLWTTreeMapType* wtTree = this->wtTracker.addConstructNodeToWitnessTree(
		partialEvPlanForInputWitnessTree->getWTTree(),
		constructNode->getPatternTree()->getNodeNumber(),
		wtTreeNodes);

	delete [] wtTreeNodes;
	
	// construct the partial plan 

	partialEvPlan = new PartialEvaluationPlan(evStr, wtTree,																		
									NULL);

	if (partialEvPlan == NULL)
	{
		success = false;
		globalErrorInfo.insertProblem(ERR_TYPE_ERROR, __LINE__, 
			"SimplePlanGenerator::generateSimplePlanForPsConstructNode", __FILE__,
			"Error reported when generating plan for process tree construct node." );
		goto exit;
	}

exit:
	if (evStr != NULL) delete [] evStr;	
	if (success)
		return partialEvPlan;
	else return NULL;
}

/**
 * Construct physical plan for MLCA.
 *@param mlcaNode The process tree MLCA node to be processed. 
 *@param partialEvPlanForInputWitnessTree The partial plan which compute the input witness tree to the MLCA operation
 *@param A partial plan that compute the MLCA.
 */
PartialEvaluationPlan* SimplePlanGenerator
::generateSimplePlanForPsMLCANode(ProcessTreeMLCANode* mlcaNode,
                                  PartialEvaluationPlan* partialEvPlanForInputWitnessTree)
{
	bool success = true;
	PartialEvaluationPlan* partialEvPlan = NULL;
	char* evStr = NULL;

	// go over each branches in the pattern tree, generate plan
	// that compute the pattern matching for each branch,
	// then, top them with a MLCA function that compute the MLCA root

	int mlcaNodeNum = mlcaNode->getMLCANodeNum();
	LCLType* mlcaNodeLCLs = mlcaNode->getMLCANodeLCLs();
	PatternTree* mlcaPtTree = mlcaNode->getPatternTree();
	PatternTreeNode* mlcaRootNode = mlcaPtTree->getRoot();

	// generate plan for each branch

	PartialEvaluationPlan** mlcaBranchPlans = new PartialEvaluationPlan*[mlcaNodeNum];

	for (int i=0; i<mlcaNodeNum; i++)
	{
		PartialEvaluationPlan* planForBranch
			= this->generateSimplePlanForSubPatternRootedAt(
									mlcaPtTree, 
									mlcaRootNode->getChildIDAt(i),
									mlcaNode->getNodeID(),
									1,
									&partialEvPlanForInputWitnessTree,
									NULL,
									NULL);
		if (planForBranch == NULL)	
		{
			success = false;
			globalErrorInfo.insertProblem(ERR_TYPE_ERROR, __LINE__, 
				"SimplePlanGenerator::generateSimplePlanForPsMLCANode", __FILE__,
				"Error reported when generating plan for a mlca branch." );
			goto exit;
		}

		// need to sort the result that matches the branch by the mlca node, 
		// if it is not already so. 

		if (!planForBranch->orderbyStartKeyOfNode(mlcaNodeLCLs[i]))
		{
			mlcaBranchPlans[i] = this->addonSort(planForBranch, 
												 mlcaNodeLCLs[i],
												 true);  // sort by start key

			delete planForBranch;
			if (mlcaBranchPlans[i] == NULL)	
			{
				success = false;
				globalErrorInfo.insertProblem(ERR_TYPE_ERROR, __LINE__, 
					"SimplePlanGenerator::generateSimplePlanForPsMLCANode", __FILE__,
					"Error reported when adding sort to the plan for a mlca branch." );
				goto exit;
			}
		}
		else
			mlcaBranchPlans[i] = planForBranch;

	}

	// generate physical operator for MLCA

	// generate the MLCA statement
	char* mlcaStr 
		= this->planSegmentGenerator.generateMLCAStr(mlcaNode->getMLCARootLCL(),
													 mlcaNodeNum,
													 mlcaNodeLCLs);
		
	if (mlcaStr == NULL) 
	{
		success = false;
		globalErrorInfo.insertProblem(ERR_TYPE_ERROR, __LINE__, 
			"SimplePlanGenerator::generateSimplePlanForPsMLCANode", __FILE__,
			"Error reported when generating mlca statement." );
		goto exit;
	}

	// put the MLCA statement and the partial plans for the branches together. 
	char* prevEvStr = NULL; 
	if (partialEvPlanForInputWitnessTree == NULL)
		prevEvStr = NULL;
	else prevEvStr = partialEvPlanForInputWitnessTree->getEvaluationPlan();

	int evStrLen = (int) strlen(mlcaStr) + 1;

	if (prevEvStr != NULL)
		evStrLen += ((int) strlen(prevEvStr) + 1);

	for (int i=0; i<mlcaNodeNum; i++)
		evStrLen += ((int) strlen(mlcaBranchPlans[i]->getEvaluationPlan())+1);

	evStr = new char[evStrLen];
	strcpy(evStr, mlcaStr);
	strcat(evStr, "\n");
	for (int i=0; i<mlcaNodeNum; i++)
	{
		strcat(evStr, mlcaBranchPlans[i]->getEvaluationPlan());
		if (i < mlcaNodeNum-1)
			strcat(evStr, "\n");
	}

	if (prevEvStr != NULL)
	{
		strcat(evStr, "/n");
		strcat(evStr, prevEvStr);
	}

	delete [] mlcaStr;
	
	// build the witness tree for the result of mlca

	int branchNum = mlcaRootNode->getChildNumber();
	if (partialEvPlanForInputWitnessTree != NULL)
		branchNum++;

	LCLWTTreeMapType** branchWTTrees = new LCLWTTreeMapType*[branchNum];

	for (int i=0; i<mlcaRootNode->getChildNumber(); i++)
	{
		branchWTTrees[i] = mlcaBranchPlans[i]->getWTTree();
	}

	if (partialEvPlanForInputWitnessTree != NULL)
	{
		branchWTTrees[branchNum-1] 
			= partialEvPlanForInputWitnessTree->getWTTree();
	}

	PsPt def;
	def.psTreeNodeID = mlcaNode->getNodeID();
	def.ptTreeNodeID = mlcaRootNode->getNodeID();

	LCLWTTreeMapType* wtTree = this->wtTracker.mlcaWitnessTree(
		mlcaNode->getMLCARootLCL(),
		def,
		branchNum,
		branchWTTrees);
	delete [] branchWTTrees;

	// generate the partial plan
	partialEvPlan = new PartialEvaluationPlan(evStr, wtTree,
									new OrderKey(mlcaNode->getMLCARootLCL()));

	if (partialEvPlan == NULL)
	{
		success = false;
		globalErrorInfo.insertProblem(ERR_TYPE_ERROR, __LINE__, 
			"SimplePlanGenerator::generateSimplePlanForPsMLCANode", __FILE__,
			"Error reported when generating plan for process tree mlca node." );
		goto exit;
	}

exit:
	// clean up
	if (evStr != NULL) delete [] evStr;	
	for (int i=0; i<mlcaNodeNum; i++)
		delete mlcaBranchPlans[i];
	delete [] mlcaBranchPlans;

	// return
	if (success)
		return partialEvPlan;
	else return NULL;
}
				
/**
 * Construct physical plan for update operation
 *@param updateNode The process tree update node to be processed. 
 *@param partialEvPlanForInputWitnessTree The partial plan which compute the input witness tree to the update.
 *@param A partial plan that compute the update.
 */
PartialEvaluationPlan* SimplePlanGenerator
::generateSimplePlanForPsUpdateNode(ProcessTreeUpdateNode* updateNode,
									PartialEvaluationPlan* partialEvPlanForInputWitnessTree)
{
	bool success = true;
	PartialEvaluationPlan* partialEvPlan = NULL;

	// get the LCL of the node to update, find out whether it is element
	// node or attribute node, get attribute name if necessary.

	LCLType LCLtoUpdate = updateNode->getTargetLCL();

	char* attrName = this->wtTracker.getAttrName(
		partialEvPlanForInputWitnessTree->getWTTree(), 
		this->PsTree,
		LCLtoUpdate);

	char* refAttrName = NULL;
	if (updateNode->getUpdateOption() == REFERENCE_VALUE)
		refAttrName= this->wtTracker.getAttrName(
			partialEvPlanForInputWitnessTree->getWTTree(), 
			this->PsTree,
			updateNode->getReferedLCL());

	// generate plan for update, based on the update option

	char* evStr = NULL;

	// generate the update statement. 
	char* updateStr = this->planSegmentGenerator.generateUpdateStr(
									updateNode->getTargetLCL(),
									attrName,
									updateNode->getUpdateOption(),
									updateNode->getReferedLCL(),
									refAttrName,
									updateNode->getUpdateConst());
		
	if (updateStr == NULL) 
	{
		success = false;
		globalErrorInfo.insertProblem(ERR_TYPE_ERROR, __LINE__, 
			"SimplePlanGenerator::generateSimplePlanForPsUpdateNode", __FILE__,
			"Error reported when generating update statement." );
		goto exit;
	}

	char* prevEvStr = partialEvPlanForInputWitnessTree->getEvaluationPlan();

	evStr = new char[(int) strlen(updateStr) + (int) strlen(prevEvStr) + 2];
	strcpy(evStr, updateStr);
	strcat(evStr, "\n");
	strcat(evStr, prevEvStr);

	delete [] updateStr; 

	if (attrName != NULL)
		delete [] attrName;
	if (refAttrName != NULL)
		delete [] refAttrName;

	// witness tree does not change after delete operation
	LCLWTTreeMapType* newWtTree 
		= this->wtTracker.copyWitnessTree(partialEvPlanForInputWitnessTree->getWTTree());

	partialEvPlan = new PartialEvaluationPlan(evStr, 
				newWtTree,
				NULL); 

	if (partialEvPlan == NULL)
	{
		success = false;
		globalErrorInfo.insertProblem(ERR_TYPE_ERROR, __LINE__, 
			"SimplePlanGenerator::generateSimplePlanForPsUpdateNode", __FILE__,
			"Error reported when generating plan for process tree update node." );
		goto exit;
	}


exit:
	if (evStr != NULL) delete [] evStr;	

	if (success) 
		return partialEvPlan;
	else return NULL;
}


/**
 * Construct physical plan for insert.
 *@param isnertNode The process tree isnert node to be processed. 
 *@param partialEvPlanForInputWitnessTree The partial plan which compute the input witness tree to the insertion.
 *@param A partial plan that performs the insert.
 */
PartialEvaluationPlan* SimplePlanGenerator
::generateSimplePlanForPsInsertNode(ProcessTreeInsertNode* insertNode,
									PartialEvaluationPlan* partialEvPlanForInputWitnessTree)
{
	bool success = true;
	PartialEvaluationPlan* partialEvPlan = NULL;

	char* evStr = NULL;

	// prepare parameter, add attribute name to the insert element

	if (insertNode->getElement() != NULL)
	{
		InsertValueUnit* element = insertNode->getElement();
		if (element->valueSource == REFERENCE_VALUE)
			element->attrName = this->wtTracker.getAttrName(
				partialEvPlanForInputWitnessTree->getWTTree(),
				this->PsTree,
				element->LCL);
	}
		
	if (insertNode->getAttributeNumber() > 0)
	{
		InsertValueUnit** attrs = insertNode->getAttributes();
		for (int i=0; i<insertNode->getAttributeNumber(); i++)
			if (attrs[i]->valueSource == REFERENCE_VALUE)
				attrs[i]->attrName = this->wtTracker.getAttrName(
					partialEvPlanForInputWitnessTree->getWTTree(),
					this->PsTree,
					attrs[i]->LCL);
	}
	
	char* insertStr = this->planSegmentGenerator.generateInsertStr(
							insertNode->getParentLCL(),
							insertNode->getInsertOption(),
							insertNode->getXMLFileName(), 
							insertNode->getElement(),
							insertNode->getAttributeNumber(),
							insertNode->getAttributes());
		
	if (insertStr == NULL) 
	{
		success = false;
		globalErrorInfo.insertProblem(ERR_TYPE_ERROR, __LINE__, 
			"SimplePlanGenerator::generateSimplePlanForPsInsertNode", __FILE__,
			"Error reported when generating insert statement." );
		goto exit;
	}

	char* prevEvStr = partialEvPlanForInputWitnessTree->getEvaluationPlan();

	evStr = new char[strlen(insertStr) + strlen(prevEvStr) + 2];
	strcpy(evStr, insertStr);
	strcat(evStr, "\n");
	strcat(evStr, prevEvStr);

	delete [] insertStr;

	// witness tree does not change after delete operation

	LCLWTTreeMapType* newWtTree 
		= this->wtTracker.copyWitnessTree(partialEvPlanForInputWitnessTree->getWTTree());

	partialEvPlan = new PartialEvaluationPlan(evStr, 
				newWtTree,
				NULL); 

	if (partialEvPlan == NULL)
	{
		success = false;
		globalErrorInfo.insertProblem(ERR_TYPE_ERROR, __LINE__, 
			"SimplePlanGenerator::generateSimplePlanForPsInsertNode", __FILE__,
			"Error reported when generating plan for process tree insert node." );
		goto exit;
	}

exit:
	if (evStr != NULL) delete [] evStr;	
	if (success)
		return partialEvPlan;
	else return NULL;
}

/**
 * Construct physical plan for deletion.
 *@param deleteNode The process tree delete node to be processed. 
 *@param partialEvPlanForInputWitnessTree The partial plan which compute the input witness tree to the deletion. 
 *@param A partial plan that performs deletion.
 */									
PartialEvaluationPlan* SimplePlanGenerator
::generateSimplePlanForPsDeleteNode(ProcessTreeDeleteNode* deleteNode,
									PartialEvaluationPlan* partialEvPlanForInputWitnessTree)
{
	bool success = true;
	PartialEvaluationPlan* partialEvPlan = NULL;

	// get the LCL of the node to delete, find out whether it is element
	// node or attribute node, get attribute name if necessary.

	LCLType LCLtoDelete = deleteNode->getDeleteLCL();
	int deleteOpt = deleteNode->getDeleteOption();
	char* attrName = NULL;

	attrName = this->wtTracker.getAttrName(
		partialEvPlanForInputWitnessTree->getWTTree(),this->PsTree,
		LCLtoDelete);

	char* evStr = NULL;

	// generate the delete statement
	char* deleteStr = this->planSegmentGenerator.generateDeleteStr(
								LCLtoDelete,
								attrName,
								deleteOpt);
		
	if (deleteStr == NULL) 
	{
		success = false;
		globalErrorInfo.insertProblem(ERR_TYPE_ERROR, __LINE__, 
			"SimplePlanGenerator::generateSimplePlanForPsDeleteNode", __FILE__,
			"Error reported when generating delete statement." );
		goto exit;
	}

	char* prevEvStr = partialEvPlanForInputWitnessTree->getEvaluationPlan();

	evStr = new char[strlen(deleteStr) + strlen(prevEvStr) + 2];
	strcpy(evStr, deleteStr);
	strcat(evStr, "\n");
	strcat(evStr, prevEvStr);

	delete [] deleteStr;

	// witness tree does not change after delete operation

	LCLWTTreeMapType* newWtTree 
		= this->wtTracker.copyWitnessTree(partialEvPlanForInputWitnessTree->getWTTree());

	partialEvPlan = new PartialEvaluationPlan(evStr, 
				newWtTree,
				NULL);

	if (partialEvPlan == NULL)
	{
		success = false;
		globalErrorInfo.insertProblem(ERR_TYPE_ERROR, __LINE__, 
			"SimplePlanGenerator::generateSimplePlanForPsDeleteNode", __FILE__,
			"Error reported when generating plan for process tree delete node." );
		goto exit;
	}



exit:
	if (evStr != NULL) delete [] evStr;	
	if (attrName != NULL) delete [] attrName;

	if (success)
		return partialEvPlan;
	else return NULL;
}

/**
 * Generate physical plan for a given pattern tree. 
 *@param ptTree The pattern tree to be processed. 
 *@param inputWitnessTreeNumber The number of input witness trees to the pattern tree matching. 
 *@param partialEvPlanForInputWitnessTrees The partial plans that compute the witness trees. 
 *@return The partial plan that compute the pattern tree matching. 
 */
PartialEvaluationPlan* SimplePlanGenerator
::generateSimplePlanForPatternTree(PatternTree* ptTree,
								   NodeIDType psNodeID,
								   int inputWitnessTreeNumber, 
								   PartialEvaluationPlan** partialEvPlanForInputWitnessTrees,
								   char* carryinJoinIndexName,
								   PartialEvaluationPlan* partialEvPlanForValueJoin)
{
	// do a bottom up structural join, in a recursive mode
	PartialEvaluationPlan* partialEvPlan 
		= this->generateSimplePlanForSubPatternRootedAt(
			ptTree, 
			ptTree->getRootID(), 
			psNodeID,
			inputWitnessTreeNumber,
			partialEvPlanForInputWitnessTrees,
			carryinJoinIndexName,
			partialEvPlanForValueJoin);

	return partialEvPlan;
}

/**
 * Generate physical plan for a sub pattern tree, rooted at a given node
 * recursively generate plans for the children sub-patterns of the root, generate
 * physical plan to evaluate the root node and put them together via structural join 
 * or value join. 
 * 
 *@param ptTree The pattern tree, which contains the sub pattern to be processed. 
 *@param rootid The id of the root node of the sub pattern to be processed. 
 *@param inputWitnessTreeNumber The number of input witness trees to the pattern tree matching. 
 *@param partialEvPlanForInputWitnessTrees The partial plans that compute the witness trees. 
 *@return The partial plan that compute the pattern tree matching to the sub pattern
 */
PartialEvaluationPlan* SimplePlanGenerator
::generateSimplePlanForSubPatternRootedAt(PatternTree* ptTree, 
										  NodeIDType rootid,
										  NodeIDType psNodeID, 
										  int inputWitnessTreeNumber, 
										  PartialEvaluationPlan** partialEvPlanForInputWitnessTrees,
										  char* carryinJoinIndexName,
										  PartialEvaluationPlan* partialEvPlanForValueJoin)
{
	bool success = true;
	PartialEvaluationPlan* partialEvPlan = NULL;

	PatternTreeNode* rootNode = ptTree->getPtNodeWithID(rootid);
	LCLType rootLCL = rootNode->getLCL();
	int rootNodeType = rootNode->getPtTreeNodeType();

	// generate physical plan for the root node, depending on its type. 
	switch (rootNodeType)
	{
	case PATTERN_TREE_SELECTION_NODE:		
		globalErrorInfo.insertProblem(ERR_TYPE_ERROR, __LINE__, 
			"SimplePlanGenerator::generateSimplePlanForSubPatternRootedAt", __FILE__,
			"The Simple Plan Generator takes a process tree with marked pattern tree as input.");
		success = false;
		goto exit;
		break;

	case PATTERN_TREE_CARTESIAN_NODE:
		// construct plan for the two child branches, then, the cartesian product
		{
			// check whether it is a valid cartesian product node
			if (rootNode->getChildNumber() != 2)
			{
				sprintf(this->errMsg,"The pattern tree node (id=%d) is not a valid cartesian product node. It has %d children....", rootid, rootNode->getChildNumber());
				globalErrorInfo.insertProblem(ERR_TYPE_ERROR, __LINE__, 
					"SimplePlanGenerator::generateSimplePlanForSubPatternRootedAt", __FILE__,
					this->errMsg);
				success = false;
				goto cartesianexit;
			}			

			// collect info about the join
			char* evStr = NULL;

			PatternTreeNode* rightChild = ptTree->getPtNodeWithID(rootNode->getChildIDAt(1));

			PartialEvaluationPlan* partialEvPlanForLeftBranch = NULL;
			PartialEvaluationPlan* partialEvPlanForRightBranch = NULL;

			// generate evaluation plan for the subpattern rooted at the children. 
			partialEvPlanForLeftBranch
				= this->generateSimplePlanForSubPatternRootedAt(
					ptTree, 
					rootNode->getChildIDAt(0), 
					psNodeID,
					inputWitnessTreeNumber,
					partialEvPlanForInputWitnessTrees,
					NULL,
					NULL);

			if (partialEvPlanForLeftBranch == NULL) 
			{
				success = false;
				globalErrorInfo.insertProblem(ERR_TYPE_ERROR, __LINE__, 
					"SimplePlanGenerator::generateSimplePlanForSubPatternRootedAt", __FILE__,
					"Error reported when generating simple plan for the left branch of a value join.");
				goto cartesianexit;
			}

			partialEvPlanForRightBranch
				= this->generateSimplePlanForSubPatternRootedAt(
					ptTree, 
					rootNode->getChildIDAt(1),
					psNodeID,
					inputWitnessTreeNumber,
					partialEvPlanForInputWitnessTrees,
					NULL,
					NULL);

			if (partialEvPlanForRightBranch == NULL) 
			{
				globalErrorInfo.insertProblem(ERR_TYPE_ERROR, __LINE__, 
					"SimplePlanGenerator::generateSimplePlanForSubPatternRootedAt", __FILE__,
					"Error reported when generating plan for the right branch of the join node." );
				success = false;
				goto cartesianexit;
			}

			// construct the cartesian product statement
			
			char* leftEvStr = partialEvPlanForLeftBranch->getEvaluationPlan();
			char* rightEvStr = partialEvPlanForRightBranch->getEvaluationPlan();
			char* cartesianStr;

			cartesianStr = this->planSegmentGenerator.generateValueJoinStr(
							rootLCL,
							-1,					// left LCL
							-1,					// right LCL
							-1,					// operator
							-1,					// data type
							NULL,				// leftAttrName
							NULL,				// rightAttrName
							NULL,				// file name
							NULL,				// index name
							rightChild->getJoinOption(), 
							false,				// any join
							false);				// input sorted
							
			if (cartesianStr == NULL) 
			{
				success = false;
				globalErrorInfo.insertProblem(ERR_TYPE_ERROR, __LINE__, 
					"SimplePlanGenerator::generateSimplePlanForSubPatternRootedAt", __FILE__,
					"Error reported when generating cartesian product statement." );
				goto cartesianexit;
			}
				
			evStr = new char[strlen(leftEvStr) + strlen(rightEvStr) 
						+ strlen(cartesianStr) + 100];
					
			strcpy(evStr, cartesianStr);
			strcat(evStr, "\n");
			strcat(evStr, leftEvStr);
			strcat(evStr, "\n");
			strcat(evStr, rightEvStr);

			delete [] cartesianStr;

			// construct the witnesstree info for the subpattern  after cartesian product
			PsPt def;
			def.psTreeNodeID = psNodeID;
			def.ptTreeNodeID = rootNode->getNodeID();

			LCLWTTreeMapType* wtTree 
				= this->wtTracker.valueJoinWitnessTrees(rootLCL, 
						def,
						partialEvPlanForLeftBranch->getWTTree(),
						partialEvPlanForRightBranch->getWTTree());

			if (wtTree == NULL)
			{
				success = false;
				globalErrorInfo.insertProblem(ERR_TYPE_ERROR, __LINE__, 
					"SimplePlanGenerator::generateSimplePlanForSubPatternRootedAt", __FILE__,
					"Error reported when generating witness tree for the result of a cartesian product." );
				goto cartesianexit;
			}

			// construct the partial plan 
			partialEvPlan = new PartialEvaluationPlan(evStr, 
													  wtTree, 
													  NULL);			//  orderby node id

			if (partialEvPlan == NULL)
			{
				success = false;
				globalErrorInfo.insertProblem(ERR_TYPE_ERROR, __LINE__, 
					"SimplePlanGenerator::generateSimplePlanForSubPatternRootedAt", __FILE__,
					"Error reported when generating plan for cartesian product." );
				goto cartesianexit;
			}

cartesianexit:
			// clean up 
			if (evStr != NULL) delete [] evStr;
			delete partialEvPlanForLeftBranch;
			delete partialEvPlanForRightBranch;
		}
		break;

	case PATTERN_TREE_VALUEJOIN_NODE:
		{
			// check whether it is a valid value join node
			if (rootNode->getChildNumber() != 2)
			{
				sprintf(this->errMsg,"The pattern tree node (id=%d) is not a valid value join node. It has %d children....", rootid, rootNode->getChildNumber());
				globalErrorInfo.insertProblem(ERR_TYPE_ERROR, __LINE__, 
					"SimplePlanGenerator::generateSimplePlanForSubPatternRootedAt", __FILE__,
					this->errMsg);
				success = false;
				goto joinexit;
			}

			// variable for evaluating value join
			char* evStr = NULL;

			LCLType leftLCL, rightLCL;
			char* leftAttrName = NULL;
			char* rightAttrName = NULL;
			char* fileName = NULL;
			char* indexName = NULL;

			// collect info about the join
			PatternTreeValueJoinNode* valueJoinNode = (PatternTreeValueJoinNode*) rootNode;
			ValueJoinConditionType* valueJoinCond = valueJoinNode->getValueJoinCondition();
			leftLCL = valueJoinCond->leftReference;
			rightLCL = valueJoinCond->rightReference;

			PatternTreeNode* rightChild = ptTree->getPtNodeWithID(rootNode->getChildIDAt(1));

			PatternTreeNode* rightJoinNodeDef = NULL;	// the definition (extract from DB) of the right operand			
			PatternTreeNode* rightJoinNodeInPtTree = NULL; // the right join node, if it is in the same pattern tree. 
			PatternTreeNode* rightJoinNodeRef = NULL; // the right join node, if it is defined in another pattern tree. 

			PartialEvaluationPlan* partialEvPlanForLeftBranch = NULL;
			PartialEvaluationPlan* partialEvPlanForRightBranch = NULL;

			rightJoinNodeInPtTree = (PatternTreeNode*) ((PatternTree*) ptTree)->getPtNodeWithLCL(rightLCL);

			// generate evaluation plan for the subpattern rooted at the children. 
			partialEvPlanForLeftBranch
				= this->generateSimplePlanForSubPatternRootedAt(
					ptTree, 
					rootNode->getChildIDAt(0), 
					psNodeID,
					inputWitnessTreeNumber,
					partialEvPlanForInputWitnessTrees,
					NULL,
					NULL);

			if (partialEvPlanForLeftBranch == NULL) 
			{
				success = false;
				globalErrorInfo.insertProblem(ERR_TYPE_ERROR, __LINE__, 
					"SimplePlanGenerator::generateSimplePlanForSubPatternRootedAt", __FILE__,
					"Error reported when generating simple plan for the left branch of a value join.");
				goto joinexit;
			}

			partialEvPlanForRightBranch
				= this->generateSimplePlanForSubPatternRootedAt(
					ptTree, 
					rootNode->getChildIDAt(1),
					psNodeID,
					inputWitnessTreeNumber,
					partialEvPlanForInputWitnessTrees,
					NULL,
					NULL);

			if (partialEvPlanForRightBranch == NULL) 
			{
				globalErrorInfo.insertProblem(ERR_TYPE_ERROR, __LINE__, 
					"SimplePlanGenerator::generateSimplePlanForSubPatternRootedAt", __FILE__,
					"Error reported when generating plan for the right branch of the join node." );
				success = false;
				goto joinexit;
			}

			// if the join is a value join and the comparison operator is EQ, 
			// consider using the join index.

			// a few judgement to make
			bool hasJoinIndex = false;
			bool valueJoinUsingJoinIndex = false;
			bool hashedValueJoinUsingJoinIndex = false; /* for nest-join */
			bool valueJoinBeforeRightBranchInPtTree = false;
			bool valueJoinBeforeRightBranchInPsTree = false;
			bool inputSorted = false;

			// variables helping making the judgement

			int op = valueJoinNode->getValueJoinCondition()->operaror;
			bool anyJoin = valueJoinNode->getValueJoinCondition()->anyJoin;
			int joinOpt = rightChild->getJoinOption();
				
			bool outerJoin = ((joinOpt == PTTREE_OPERATION_ZEROORONE)
					       || (joinOpt == PTTREE_OPERATION_ZEROORMORE));
			bool oneToOneJoin = (joinOpt == PTTREE_OPERATION_ONLYONE);	
			bool equiJoin = (op == SCAN_OP_EQ);
			char* leftFileName = NULL;
			char* rightFileName = NULL;
			int leftNodeType = -1;
			int rightNodeType = -1;
			char* leftStr = NULL;
			char* rightStr = NULL;
			int leftJoinIndexType = -1;
			int rightJoinIndexType = -1;
			
			if (!equiJoin)
			{
				// if the value join is a non-equi, cannot use value index
				hasJoinIndex = false;
				goto cleanupForJoinIndexMatching;
			}

			// see whether any index is available. 
			
			leftFileName = this->wtTracker.getFileName(
						partialEvPlanForLeftBranch->getWTTree(),
						this->PsTree,
						leftLCL);
			if (leftFileName == NULL)
			{
				hasJoinIndex = false;
				goto cleanupForJoinIndexMatching;
			}

			rightFileName = this->wtTracker.getFileName(
						partialEvPlanForRightBranch->getWTTree(),
						this->PsTree,
						rightLCL);
			if (rightFileName == NULL)
			{
				hasJoinIndex = false;
				goto cleanupForJoinIndexMatching;
			}

			if (strcmp(leftFileName, rightFileName) != 0)
			{
				hasJoinIndex = false;
				goto cleanupForJoinIndexMatching;
			}

						
			leftNodeType = this->wtTracker.getWitnessTreeNodeType(
					partialEvPlanForLeftBranch->getWTTree(),
					leftLCL);
						
			if (leftNodeType == WT_ELEMENT_NODE)
			{
				leftStr = this->wtTracker.getElementTag(
							partialEvPlanForLeftBranch->getWTTree(),
							this->PsTree,
							leftLCL);
				leftJoinIndexType = JOININDEX_ELEMENTCONTENT;
			}
			else 
			{
				leftStr = this->wtTracker.getAttrName(
							partialEvPlanForLeftBranch->getWTTree(),
							this->PsTree,
							leftLCL);
				leftJoinIndexType = JOININDEX_ATTRIBUTEVALUE;
			}

			if (leftStr == NULL)
			{
				hasJoinIndex = false;
				goto cleanupForJoinIndexMatching;
			}
									
			rightNodeType = this->wtTracker.getWitnessTreeNodeType(
							partialEvPlanForRightBranch->getWTTree(),
							rightLCL);
						
			if (rightNodeType == WT_ELEMENT_NODE)
			{
				rightStr = this->wtTracker.getElementTag(
							partialEvPlanForRightBranch->getWTTree(),
							this->PsTree,
							rightLCL);
				rightJoinIndexType = JOININDEX_ELEMENTCONTENT;
			}
			else 
			{
				rightStr = this->wtTracker.getAttrName(
							partialEvPlanForRightBranch->getWTTree(),
							this->PsTree,
							rightLCL);
				rightJoinIndexType = JOININDEX_ATTRIBUTEVALUE;
			}

			if (rightStr == NULL)
			{
				hasJoinIndex = false;
				goto cleanupForJoinIndexMatching;
			}

			IndexMatchingType* im = NULL;
			this->indexMatching->matchJoinIndex(
						leftFileName, 
						leftStr, leftJoinIndexType,
						rightStr, rightJoinIndexType,
						im);

			if (im != NULL)
			{
				hasJoinIndex = true;
				fileName = new char[strlen(leftFileName)+1];
				strcpy(fileName, leftFileName);
				indexName = new char[strlen(im->indexName)+1];
				strcpy(indexName, im->indexName);
				delete im;
			}						
			else hasJoinIndex = false;


cleanupForJoinIndexMatching: 
			if (leftStr != NULL) delete [] leftStr;
			if (rightStr != NULL) delete [] rightStr;

			if (leftFileName != NULL) delete [] leftFileName;
			if (rightFileName != NULL) delete [] rightFileName;
				
			// if there is join index to use, see how can we use it:
			// option 1: do the value join before evaluating the right branch. 
			// option 2: compute the two branches first, then, use join index to evalute the value join. 

			if (hasJoinIndex)
			{
				if (!oneToOneJoin)
				{
					// if the join is not a one-to-one join, can only do it after
					// the two branches are evaluated, use hashed value join
					valueJoinUsingJoinIndex = false;
					hashedValueJoinUsingJoinIndex = true;
					valueJoinBeforeRightBranchInPtTree = false;
					valueJoinBeforeRightBranchInPsTree = false;
					goto generatePlanForValueJoin;
				}

				if (outerJoin)
				{
					// if the join is a one-to-one outer join, can only do it after
					// the two branches are evaluated, use value join with join index
					valueJoinUsingJoinIndex = true;
					hashedValueJoinUsingJoinIndex = false;
					valueJoinBeforeRightBranchInPtTree = false;
					valueJoinBeforeRightBranchInPsTree = false;
					goto generatePlanForValueJoin;
				}
				
				// We perform value join (using join index) before evaluating the right branch 
				// in the same pattern tree only when 
				// 1. right operand in the value join condition is defined in this pattern tree;
				// 2. The right operand is not evaluated by a value index. 
				// 3. the path from the right operand to the value join node is all one-to-one join. 

				if (rightJoinNodeInPtTree != NULL)
				{
					if (rightJoinNodeInPtTree->getPtTreeNodeType() 
						== MARKED_PATTERN_TREE_SELECTION_NODE)
					{
						// check whether the right operand can be evaluted by a value index.

						if (((MarkedPatternTreeSelectionNode*) rightJoinNodeInPtTree)->useValueIndex())
						{
							// if value (content) index is used to evaluate the node, we don't
							// enforce using the join index before evaluating the right branch
							valueJoinUsingJoinIndex = true;
							valueJoinBeforeRightBranchInPtTree = false;
							goto generatePlanForValueJoin;
						}			
							
						// check whether the edge on the path from the right operand to the 
						// value join node are all one-to-one join. 
						PatternTreeNode* crtNode = rightJoinNodeInPtTree;
						bool allOneToOne = true;
						while (crtNode->getNodeID() != valueJoinNode->getNodeID())
						{
							if (crtNode->getJoinOption() != PTTREE_OPERATION_ONLYONE)
							{
								allOneToOne = false;
								break;
							}

							NodeIDType parentID = crtNode->getParentID();
							PatternTreeNode* parentNode = (PatternTreeNode*) ptTree->getNodeWithID(parentID);
							if (parentNode == NULL)
							{
								globalErrorInfo.insertProblem(ERR_TYPE_ERROR, __LINE__, 
									"SimplePlanGenerator::generateSimplePlanForSubPatternRootedAt", __FILE__,
									"Encounter a NULL when tracing nodes up along the path from the definition of the right join operand to the value join node.");
								goto joinexit;
							}
							crtNode = parentNode;
						}
							
						if (allOneToOne)
						{
							valueJoinUsingJoinIndex = false;
							valueJoinBeforeRightBranchInPtTree = true;
							rightJoinNodeDef = rightJoinNodeInPtTree;
							goto generatePlanForValueJoin;
						}
						else 
						{
							valueJoinUsingJoinIndex = true;
							valueJoinBeforeRightBranchInPtTree = false;
							goto generatePlanForValueJoin;
						}
					}
				}


				// We perform value join (using join index) before evaluating the right branch 
				// in which the right operand is defined in a different pattern tree only when
				// 1. the right operand in the value join condition is defined in the process tree 
				//		node right below the value join node.
				// 2. The right operand is not evaluated by a value index. 
				// 3. the path from the node that refer to the right operand in the value join 
				//		pattern tree, to the value join node is all one-to-one join. 
				// 4. the join relationship along the path between the node being refered in the value join pattern tree and the definition of the right operand are all one-to-one. 

				else  // when (rightJoinNode == NULL)
				{
					// the right operand of the value joins is brought into this pattern
					// tree by refereing to another pattern tree.

					// The right branch of the value join node referes to the root of 
					// the pattern tree where the right operand is defined. 
					// we already know that the right branch has a one-to-one relation
					// with the value join node. otherwise, we will not consider 
					// one-side value join at all.

					// find where the right operand is defined
					LCLType refLCL = ((PatternTreeReferenceNode*) rightChild)->getReference();
					ProcessTreeNode* refPsNode = this->PsTree->getPsNodeWithPtTreeRootAs(refLCL);
					PatternTree* refPtTree = this->PsTree->getPtTreeRootedAtLCL(refLCL);

					// if the process tree node is not the right child of the process tree node
					// where the value join is define, we don't consider doing one-side value join
					if (refPsNode->getParentID() != psNodeID)
					{
						valueJoinUsingJoinIndex = true;
						valueJoinBeforeRightBranchInPsTree = false;
						goto generatePlanForValueJoin;
					}

					rightJoinNodeRef = refPtTree->getPtNodeWithLCL(rightLCL);

					if (rightJoinNodeRef->getPtTreeNodeType() != MARKED_PATTERN_TREE_SELECTION_NODE)
					{
						// if the right operand of the value join is still not defined in 
						// this pattern tree. we quit considering one-side value join and 
						// perform the value join after the two branches are evaluated.
						valueJoinUsingJoinIndex = true;
						valueJoinBeforeRightBranchInPsTree = false;
						goto generatePlanForValueJoin;
					}

					// verify condition 2: The right operand is not evaluated by a value index. 

					if (((MarkedPatternTreeSelectionNode*) rightJoinNodeRef)->useValueIndex())
					{
						// if value (content) index is used to evaluate the node, we don't
						// enforce using the join index before evaluating the right branch
						valueJoinUsingJoinIndex = true;
						valueJoinBeforeRightBranchInPsTree = false;
						goto generatePlanForValueJoin;
					}			
					
					// verify condition 4: the join relationship along the path between 
					//		the node being refered in the value join pattern tree and 
					//		the definition of the right operand are all one-to-one. 

					PatternTreeNode* crtNode = rightJoinNodeRef;
					bool allOneToOne = true;
					while (crtNode->getNodeID() != refPtTree->getRootID())
					{
						if (crtNode->getJoinOption() != PTTREE_OPERATION_ONLYONE)
						{
							allOneToOne = false;
							break;
						}

						NodeIDType parentID = crtNode->getParentID();
						PatternTreeNode* parentNode = (PatternTreeNode*) refPtTree->getNodeWithID(parentID);
						if (parentNode == NULL)
						{
							globalErrorInfo.insertProblem(ERR_TYPE_ERROR, __LINE__, 
								"SimplePlanGenerator::generateSimplePlanForSubPatternRootedAt", __FILE__,
								"Encounter a NULL when tracing nodes up along the path from the definition of the right join operand to the root node of the pattern tree it is in.");
							goto joinexit;
						}
						crtNode = parentNode;
					}
						
					if (allOneToOne)
					{
						valueJoinUsingJoinIndex = false;
						valueJoinBeforeRightBranchInPsTree = true;
						rightJoinNodeDef = rightJoinNodeRef;
					}
					else 
					{
						valueJoinUsingJoinIndex = true;
						valueJoinBeforeRightBranchInPsTree = false;
					}
				}
			}

generatePlanForValueJoin:
			char* leftEvStr = NULL;
			char* rightEvStr = NULL;
			char* valueJoinStr ;
			OrderKey* orderbyKey;
			leftAttrName = this->wtTracker.getAttrName(
				partialEvPlanForLeftBranch->getWTTree(),this->PsTree,
				leftLCL);

			rightAttrName = this->wtTracker.getAttrName(
				partialEvPlanForRightBranch->getWTTree(),this->PsTree,
				rightLCL);

			// based on the value join condition, availability of join index, etc.
			// we may generate plans in the following style:
			// 1. plan for branches -> valuejoin (sort-merge)
			// 2. plan for branches -> valuejoin (nested-loop)
			// 3. plan for branches -> valuejoin (use join index)
			// 4. plan for branches -> hashed value join (for nest-join)
			// 5. plan for left branch -> use join index -> plan for right branch (in the same PtTree)
			// 6. plan for left branch -> use join index -> plan for right branch (cross pattern tree)

			bool valueJoinAfterBranches = false;
			if (!hasJoinIndex)
			{
				if (equiJoin && !anyJoin)
				{
					// plan1: plan for branches -> valuejoin (sort-merge)
					// need to sort the input by value
					int orderbyType = valueJoinNode->getValueJoinCondition()->operatorDataType;
					int orderByID = (orderbyType == ID_VALUE);

					// for the left branch
					if (!partialEvPlanForLeftBranch->orderby(leftLCL, orderbyType)) 
					{
						PartialEvaluationPlan* partialEvPlanForleftBranchWithSort
							= this->addonSort(partialEvPlanForLeftBranch, leftLCL, orderByID);
						if (partialEvPlanForleftBranchWithSort == NULL)
						{										
							globalErrorInfo.insertProblem(ERR_TYPE_ERROR, __LINE__, 
								"SimplePlanGenerator::generateSimplePlanForSubPatternRootedAt", __FILE__,
								"Error reported when adding sort to the plan for the left branch of the join node.");
							success = false;
							goto joinexit;
						}

						delete partialEvPlanForLeftBranch;
						partialEvPlanForLeftBranch = partialEvPlanForleftBranchWithSort;
					}

					// for the right branch
					if (!partialEvPlanForRightBranch->orderby(rightLCL, orderbyType)) 
					{
						PartialEvaluationPlan* partialEvPlanForRightBranchWithSort
							= this->addonSort(partialEvPlanForRightBranch, rightLCL, orderByID);
						if (partialEvPlanForRightBranchWithSort == NULL)
						{
							globalErrorInfo.insertProblem(ERR_TYPE_ERROR, __LINE__, 
								"SimplePlanGenerator::generateSimplePlanForSubPatternRootedAt", __FILE__,
								"Error reported when adding sort to the plan for the right branch of the join node.");
							success = false;
							goto joinexit;
						}

						delete partialEvPlanForRightBranch;
						partialEvPlanForRightBranch = partialEvPlanForRightBranchWithSort;
					}
						
					inputSorted = true;

					OrderbyNode** orderbyNodes = new OrderbyNode*[1];
					orderbyNodes[0] = new OrderbyNode();
					orderbyNodes[0]->orderbyLCL = leftLCL;
					orderbyNodes[0]->orderbyOption = ORDER_BY_VALUE;
					orderbyNodes[0]->orderSpec = ORDER_SPEC_ASCENDING;
					orderbyNodes[0]->nullOption = ORDER_NULL_GREATEST;
					if (leftAttrName == NULL)
						orderbyNodes[0]->attrName = NULL;
					else
					{
						orderbyNodes[0]->attrName = new char[strlen(leftAttrName)+1];
						strcpy(orderbyNodes[0]->attrName, leftAttrName);
					}
					orderbyKey = new OrderKey(1,orderbyNodes);

					valueJoinAfterBranches = true;
				}

				else 
				{
					// plan2: plan for branches -> valuejoin (nested-loop)
					// no need to do any preparation.
					orderbyKey = NULL;
					valueJoinAfterBranches = true;
				}
			}   // when no join index is avaiable

			if (hasJoinIndex && valueJoinUsingJoinIndex)
			{
				// plan3: plan for branches -> valuejoin (use join index)
				// need to sort the right branch by start key. 
				
				if (!partialEvPlanForRightBranch->orderby(rightLCL, ID_VALUE)) 
				{
					PartialEvaluationPlan* partialEvPlanForRightBranchWithSort
						= this->addonSort(partialEvPlanForRightBranch, rightLCL, true);
					if (partialEvPlanForRightBranchWithSort == NULL)
					{
						globalErrorInfo.insertProblem(ERR_TYPE_ERROR, __LINE__, 
							"SimplePlanGenerator::generateSimplePlanForSubPatternRootedAt", __FILE__,
							"Error reported when adding sort to the plan for the right branch of the join node.");
						success = false;
						goto joinexit;
					}

					delete partialEvPlanForRightBranch;
					partialEvPlanForRightBranch = partialEvPlanForRightBranchWithSort;

					// the result will be ordered the same as how the left branch
					// is ordered
					if (partialEvPlanForLeftBranch->getOrderKey() == NULL)
						orderbyKey = NULL;
					else orderbyKey = new OrderKey(partialEvPlanForLeftBranch->getOrderKey());
				}

				valueJoinAfterBranches = true;
			}

			// generate plan for the first three plan styles (branches -> value join)
			// prepare parameters
			
			if (valueJoinAfterBranches)
			{
				valueJoinStr = this->planSegmentGenerator.generateValueJoinStr(
							rootLCL,
							leftLCL, 
							rightLCL, 
							valueJoinCond->operaror,
							valueJoinCond->operatorDataType,
							leftAttrName, 
							rightAttrName, 
							fileName, 
							indexName, 
							joinOpt,
							anyJoin,
							inputSorted);

							
				if (valueJoinStr == NULL) 
				{
					success = false;
					globalErrorInfo.insertProblem(ERR_TYPE_ERROR, __LINE__, 
						"SimplePlanGenerator::generateSimplePlanForSubPatternRootedAt", __FILE__,
						"Error reported when generating value join statement." );
					goto joinexit;
				}

				leftEvStr = partialEvPlanForLeftBranch->getEvaluationPlan();
				rightEvStr = partialEvPlanForRightBranch->getEvaluationPlan();

				evStr = new char[strlen(leftEvStr) + strlen(rightEvStr) + strlen(valueJoinStr) + 100];
						
				strcpy(evStr, valueJoinStr);
				strcat(evStr, "\n");
				strcat(evStr, leftEvStr);
				strcat(evStr, "\n");
				strcat(evStr, rightEvStr);

				delete [] valueJoinStr;

				// construct the witnesstree info for the subpattern  after join
				PsPt def;
				def.psTreeNodeID = psNodeID;
				def.ptTreeNodeID = rootNode->getNodeID();

				LCLWTTreeMapType* wtTree 
					= this->wtTracker.valueJoinWitnessTrees(rootLCL, 
							def,
							partialEvPlanForLeftBranch->getWTTree(),
							partialEvPlanForRightBranch->getWTTree());

				// construct the partial plan 
				partialEvPlan = new PartialEvaluationPlan(evStr, wtTree, 
														orderbyKey);			

				if (partialEvPlan == NULL)
				{
					success = false;
					globalErrorInfo.insertProblem(ERR_TYPE_ERROR, __LINE__, 
						"SimplePlanGenerator::generateSimplePlanForSubPatternRootedAt", __FILE__,
						"Error reported when generating plan for value join." );
					goto joinexit;
				}
			}

			// plan 4: both branches -> hashed value join

			if (hasJoinIndex && hashedValueJoinUsingJoinIndex)
			{
				valueJoinStr = this->planSegmentGenerator.generateHashedValueJoinStr(
							rootLCL,
							leftLCL, 
							rightLCL, 
							fileName, 
							indexName, 
							joinOpt,
							anyJoin);
							
				if (valueJoinStr == NULL) 
				{
					success = false;
					globalErrorInfo.insertProblem(ERR_TYPE_ERROR, __LINE__, 
						"SimplePlanGenerator::generateSimplePlanForSubPatternRootedAt", __FILE__,
						"Error reported when generating value join statement." );
					goto joinexit;
				}

				leftEvStr = partialEvPlanForLeftBranch->getEvaluationPlan();
				rightEvStr = partialEvPlanForRightBranch->getEvaluationPlan();

				evStr = new char[strlen(leftEvStr) + strlen(rightEvStr) + strlen(valueJoinStr) + 100];
						
				strcpy(evStr, valueJoinStr);
				strcat(evStr, "\n");
				strcat(evStr, leftEvStr);
				strcat(evStr, "\n");
				strcat(evStr, rightEvStr);

				delete [] valueJoinStr;

				// construct the witnesstree info for the subpattern  after join
				PsPt def;
				def.psTreeNodeID = psNodeID;
				def.ptTreeNodeID = rootNode->getNodeID();

				LCLWTTreeMapType* wtTree 
					= this->wtTracker.valueJoinWitnessTrees(rootLCL, 
							def,
							partialEvPlanForLeftBranch->getWTTree(),
							partialEvPlanForRightBranch->getWTTree());

				// construct the partial plan 
				partialEvPlan = new PartialEvaluationPlan(evStr, wtTree, NULL);			

				if (partialEvPlan == NULL)
				{
					success = false;
					globalErrorInfo.insertProblem(ERR_TYPE_ERROR, __LINE__, 
						"SimplePlanGenerator::generateSimplePlanForSubPatternRootedAt", __FILE__,
						"Error reported when generating plan for value join." );
					goto joinexit;
				}				
			}

			// plan 5: left branch -> value join -> right branch
			if (hasJoinIndex && valueJoinBeforeRightBranchInPtTree)
			{
				
				// generate statement for the oneside value join (using join index)
				int vjSize = (int) strlen(indexName) + (int) strlen(fileName) + 3*sizeof(LCLType) + 100;
				valueJoinStr = new char[vjSize];
				sprintf(valueJoinStr, "O,%s,%s,%d,%d,%d", 
					indexName, fileName, 
					leftLCL, rightLCL, rootLCL);

				leftEvStr = partialEvPlanForLeftBranch->getEvaluationPlan();
				int size = (int) strlen(leftEvStr) + (int) strlen(valueJoinStr) + 3;
				char* leftBranchWithValueJoinStr = new char[size];
				strcpy(leftBranchWithValueJoinStr, valueJoinStr);
				strcat(leftBranchWithValueJoinStr, "\n");
				strcat(leftBranchWithValueJoinStr, leftEvStr);

				delete [] valueJoinStr;

				// generate partial plan for leftbranch+valuejoin
				PsPt rootDef, rOperandDef;
				rootDef.psTreeNodeID = psNodeID;
				rootDef.ptTreeNodeID = rootNode->getNodeID();
				rOperandDef.psTreeNodeID = psNodeID;
				rOperandDef.ptTreeNodeID = rightJoinNodeDef->getNodeID();

				LCLWTTreeMapType* rWtTree 
					= this->wtTracker.createOneNodeWitnessTree(rightLCL, 
					((MarkedPatternTreeSelectionNode*) rightJoinNodeDef)->getNodeType(), 
					rOperandDef);

				LCLWTTreeMapType* lvjWtTree 
					= this->wtTracker.valueJoinWitnessTrees(rootLCL, 
						rootDef,
						partialEvPlanForLeftBranch->getWTTree(),
						rWtTree);

				delete rWtTree;

				PartialEvaluationPlan* evPlanForLeftBranchWithValueJoin 
					= new PartialEvaluationPlan(leftBranchWithValueJoinStr, 
							lvjWtTree, NULL);

				delete [] leftBranchWithValueJoinStr;

				if (evPlanForLeftBranchWithValueJoin == NULL)
				{
					globalErrorInfo.insertProblem(ERR_TYPE_ERROR, __LINE__, 
						"SimplePlanGenerator::generateSimplePlanForSubPatternRootedAt", __FILE__,
						"Error reported when generating simple plan for the left branch, with value join.");
					goto joinexit;
				}

				// generate plan for the right branch, taking the value join result
				// as input

				PartialEvaluationPlan* evPlanForRightBranchWithValueJoin
					= this->generateSimplePlanForSubPatternRootedAt(ptTree,
						rightChild->getNodeID(),
						psNodeID, 
						inputWitnessTreeNumber, 
						partialEvPlanForInputWitnessTrees,
						indexName,
						evPlanForLeftBranchWithValueJoin);

				delete evPlanForLeftBranchWithValueJoin;

				if (evPlanForRightBranchWithValueJoin == NULL)
				{
					globalErrorInfo.insertProblem(ERR_TYPE_ERROR, __LINE__, 
						"SimplePlanGenerator::generateSimplePlanForSubPatternRootedAt", __FILE__,
						"Error reported when generating simple plan for the right branch of a value join, taking the value join result as input.");
					goto joinexit;
				}

				partialEvPlan = evPlanForRightBranchWithValueJoin;

			}

			// plan 6: left branch -> value join -> right branch (cross pattern tree)
			if (hasJoinIndex && valueJoinBeforeRightBranchInPsTree)
			{				
				// generate statement for the oneside value join (using join index)
				int vjSize = (int) strlen(indexName) + (int) strlen(fileName) + 3*sizeof(LCLType) + 100;
				valueJoinStr = new char[vjSize];
				sprintf(valueJoinStr, "O,%s,%s,%d,%d,%d", 
					indexName, fileName, 
					leftLCL, rightLCL, rootLCL);

				leftEvStr = partialEvPlanForLeftBranch->getEvaluationPlan();
				int size = (int) strlen(leftEvStr) + (int) strlen(valueJoinStr) + 3;
				char* leftBranchWithValueJoinStr = new char[size];
				strcpy(leftBranchWithValueJoinStr, valueJoinStr);
				strcat(leftBranchWithValueJoinStr, "\n");
				strcat(leftBranchWithValueJoinStr, leftEvStr);

				delete [] valueJoinStr;

				// generate partial plan for leftbranch+valuejoin
				PsPt rootDef, rOperandDef;
				rootDef.psTreeNodeID = psNodeID;
				rootDef.ptTreeNodeID = rootNode->getNodeID();
				rOperandDef.psTreeNodeID = psNodeID;
				rOperandDef.ptTreeNodeID = rightJoinNodeDef->getNodeID();

				LCLWTTreeMapType* rWtTree 
					= this->wtTracker.createOneNodeWitnessTree(rightLCL, 
					((MarkedPatternTreeSelectionNode*) rightJoinNodeDef)->getNodeType(), 
					rOperandDef);

				LCLWTTreeMapType* lvjWtTree 
					= this->wtTracker.valueJoinWitnessTrees(rootLCL, 
						rootDef,
						partialEvPlanForLeftBranch->getWTTree(),
						rWtTree);

				delete rWtTree;

				PartialEvaluationPlan* evPlanForLeftBranchWithValueJoin 
					= new PartialEvaluationPlan(leftBranchWithValueJoinStr, 
							lvjWtTree, NULL);

				delete [] leftBranchWithValueJoinStr;

				if (evPlanForLeftBranchWithValueJoin == NULL)
				{
					globalErrorInfo.insertProblem(ERR_TYPE_ERROR, __LINE__, 
						"SimplePlanGenerator::generateSimplePlanForSubPatternRootedAt", __FILE__,
						"Error reported when generating simple plan for the left branch, with value join.");
					goto joinexit;
				}

				// generate plan for the right branch, taking the value join result
				// as input

				// redo the generation of the right branch (in process tree)

				LCLType refLCL = ((PatternTreeReferenceNode*) rightChild)->getReference();
				ProcessTreeNode* refPsNode = this->PsTree->getPsNodeWithPtTreeRootAs(refLCL);

				PartialEvaluationPlan* evPlanForRightPsBranchWithValueJoin
					= this->generateSimplePlanForProcessTreeRootedAt(
						refPsNode->getNodeID(),
						indexName,
						evPlanForLeftBranchWithValueJoin);

				delete evPlanForLeftBranchWithValueJoin;
					
				if (evPlanForRightPsBranchWithValueJoin == NULL)
				{
					globalErrorInfo.insertProblem(ERR_TYPE_ERROR, __LINE__, 
						"SimplePlanGenerator::generateSimplePlanForSubPatternRootedAt", __FILE__,
						"Error reported when generating simple plan for the right branch of a value join (in the process tree below the value join), taking the value join result as input.");
					goto joinexit;
				}
	

				// redo the right branch (in the same pattern tree)
				PartialEvaluationPlan* evPlanForRightBranchWithValueJoin
					= this->generateSimplePlanForSubPatternRootedAt(ptTree,
						rightChild->getNodeID(),
						psNodeID, 
						1, 
						&evPlanForRightPsBranchWithValueJoin,
						NULL,
						NULL);

				delete evPlanForRightPsBranchWithValueJoin;

				if (evPlanForRightBranchWithValueJoin == NULL)
				{
					globalErrorInfo.insertProblem(ERR_TYPE_ERROR, __LINE__, 
						"SimplePlanGenerator::generateSimplePlanForSubPatternRootedAt", __FILE__,
						"Error reported when generating simple plan for the right branch of a value join, taking the value join result as input.");
					goto joinexit;
				}

				partialEvPlan = evPlanForRightBranchWithValueJoin;

			}

joinexit:
			// clean up 
			if (leftAttrName != NULL) delete [] leftAttrName;
			if (rightAttrName != NULL) delete [] rightAttrName;
			if (fileName != NULL) delete [] fileName;
			if (indexName != NULL) delete [] indexName;
			if (evStr != NULL) delete [] evStr;
			if (partialEvPlanForLeftBranch != NULL)
				delete partialEvPlanForLeftBranch;
			if (partialEvPlanForRightBranch != NULL)
				delete partialEvPlanForRightBranch;
		}
		break;

	case PATTERN_TREE_CONSTRUCT_NODE:	
		sprintf(this->errMsg, "PatternTreeConstructNode (nodeid = %d) should not appear in a selection pattern tree.", rootid);		
		globalErrorInfo.insertProblem(ERR_TYPE_ERROR, __LINE__, 
			"SimplePlanGenerator::generateSimplePlanForSubPatternRootedAt", __FILE__,
			this->errMsg);
		success = false;
		goto exit;
		break;

	case PATTERN_TREE_REFERENCE_NODE:
	case MARKED_PATTERN_TREE_SELECTION_NODE:
		{
			char* evStr = NULL;                        
			PartialEvaluationPlan* childPartialPlan = NULL;
			PartialEvaluationPlan* newPartialEvPlan = NULL;

			int childNum = 0;
			PartialEvaluationPlan* partialEvPlanForRootNode = NULL;
		
			// get the partialplan for root node;

			bool nodeEvalutedByCarryinPlan = false;
			if (partialEvPlanForValueJoin != NULL)
			{
				// if a plan for the value join, which provide a super set of
				// a node in the right branch, has been carried in, for each node
				// first check whether it has been evaluted by the carry in plan
				if (this->wtTracker.findNode(partialEvPlanForValueJoin->getWTTree(), rootNode->getLCL()))
				{
					nodeEvalutedByCarryinPlan = true;

					// find out whether there is any condition left
					// if the selection node is only on element node or attribute name
					// it has been evaluted by the carry-in plan.
					// if the selection node has other predicate, need a filter.

					ConjunctiveCondition* conjCondLeft = NULL;

					// ???? call some indexmatching function to compute the condLeft
				
					SelectionCondition* orgCond =
						((MarkedPatternTreeSelectionNode*) rootNode)->getOriginalCondition();
					orgCond->printSelectionCondition();

					this->indexMatching->conditionLeftFromJoinIndex(
						carryinJoinIndexName, 
						NULL,
						orgCond->getCondition()->getCondAt(0),
						conjCondLeft);

					//????condLeft = ((MarkedPatternTreeSelectionNode*) rootNode)->getNonIndexedCondition();

					if (conjCondLeft == NULL)
					{
						partialEvPlanForRootNode = new PartialEvaluationPlan(partialEvPlanForValueJoin);
						if (partialEvPlanForRootNode == NULL)
						{
							success = false;
							globalErrorInfo.insertProblem(ERR_TYPE_ERROR, __LINE__, 
								"SimplePlanGenerator::generateSimplePlanForSubPatternRootedAt", __FILE__,
								"Error reported when copying the plan for left branch (of a value join) with join index access as the plan to evalute the right operand node.");
							goto selectexit;
						}
					}
					else
					{
						// construct filter condition
						int andNum;
						PO_FilterPredicate*** filterCond;

						andNum = conjCondLeft->getNumber();
						filterCond = new PO_FilterPredicate**[1];
						filterCond[0] = new PO_FilterPredicate*[andNum];

						for (int i=0; i<andNum; i++)
						{
							PredicateCondition* pred = conjCondLeft->getCondAt(i);
							filterCond[0][i] = new PO_FilterPredicate;
							filterCond[0][i]->leftValueLCL = rootNode->getLCL();
							char* attrname = ((MarkedPatternTreeSelectionNode*) rootNode)->getAttributeName();
							if (attrname == NULL)
								filterCond[0][i]->leftAttrName = NULL;
							else
							{
								filterCond[0][i]->leftAttrName = new char[strlen(attrname)+1];
								strcpy(filterCond[0][i]->leftAttrName, attrname);
							}
							filterCond[0][i]->rightAttrName = NULL;
							filterCond[0][i]->rightValueOption = CONSTANT_VALUE;
							filterCond[0][i]->rightValueConstant = new Value(pred->getRightValue());
							filterCond[0][i]->filterOperatorDataType = pred->getRightValue()->getValueType();
							filterCond[0][i]->filterOperator = pred->getOperator();
							filterCond[0][i]->filterOption = FILTER_OPTION_SOME;
							filterCond[0][i]->rightValueLCL = -1;
						}
						
						char* filterStr = this->planSegmentGenerator.generateFilterStr(
								1, &andNum, filterCond, NULL);

						for (int i=0; i<andNum; i++)
							delete filterCond[0][i];
						delete [] filterCond[0];
						delete [] filterCond;

						if (filterStr == NULL) 
						{
							success = false;
							globalErrorInfo.insertProblem(ERR_TYPE_ERROR, __LINE__, 
								"SimplePlanGenerator::generateSimplePlanForSubPatternRootedAt", __FILE__,
								"Error happens on constructing a filter string."); 
							goto exit;
						}

						char* joinIndexStr = partialEvPlanForValueJoin->getEvaluationPlan();
						evStr = new char[strlen(joinIndexStr) + strlen(filterStr) + 3];
						strcpy(evStr, filterStr);
						strcat(evStr, "\n");
						strcat(evStr, joinIndexStr);
						delete [] filterStr;

						// construct a witness tree for the filter result
						LCLWTTreeMapType* wtTree = this->wtTracker.filterWitnessTree(
							partialEvPlanForValueJoin->getWTTree());

						// construct the partial plan. 
						partialEvPlanForRootNode = new PartialEvaluationPlan(evStr, wtTree,
							partialEvPlanForValueJoin->getOrderKey());

						if (evStr != NULL) delete [] evStr;

					}
				}
			}

			if (!nodeEvalutedByCarryinPlan)
			{
				partialEvPlanForRootNode
					= this->generateSimplePlanForPatternTreeNode(rootNode, 
															psNodeID,
															inputWitnessTreeNumber,
															partialEvPlanForInputWitnessTrees);

				if (partialEvPlanForRootNode == NULL) 
				{
					success = false;
					globalErrorInfo.insertProblem(ERR_TYPE_ERROR, __LINE__, 
						"SimplePlanGenerator::generateSimplePlanForSubPatternRootedAt", __FILE__,
						"Error reported when generating plan for a sub pattern tree." );
					goto selectexit;
				}
			}

			// set the partrialPlan to be the plan of the root. 
			partialEvPlan = partialEvPlanForRootNode;

			// get the evaluation plan for subtree rooted at each child node (pattern tree node), 
			// then join root node and the child sub tree, using the partial plan of the root node 
			// and the partial plan for the subtree rooted at the child node. 

			childNum = rootNode->getChildNumber();

			for (int i=0; i<childNum; i++)
			{
				//PartialEvaluationPlan* childPartialPlan = NULL;
				//PartialEvaluationPlan* newPartialEvPlan = NULL;

				NodeIDType childNodeID = rootNode->getChildIDAt(i);
				PatternTreeNode* childNode = ptTree->getPtNodeWithID(childNodeID);
				LCLType childLCL = childNode->getLCL();

				if (nodeEvalutedByCarryinPlan)
					childPartialPlan = this->generateSimplePlanForSubPatternRootedAt(
						ptTree, 
						childNodeID,
						psNodeID,
						inputWitnessTreeNumber,
						partialEvPlanForInputWitnessTrees,
						NULL,
						NULL);
				else 
					childPartialPlan = this->generateSimplePlanForSubPatternRootedAt(
						ptTree, 
						childNodeID,
						psNodeID,
						inputWitnessTreeNumber,
						partialEvPlanForInputWitnessTrees,
						carryinJoinIndexName,
						partialEvPlanForValueJoin);

				
				if (childPartialPlan == NULL) 
				{
					success = false;
					globalErrorInfo.insertProblem(ERR_TYPE_ERROR, __LINE__, 
						"SimplePlanGenerator::generateSimplePlanForSubPatternRootedAt", __FILE__,
						"Error reported when generating plan for a sub pattern." );
					goto selectexit;
				}

				// join the root with the subpattern. 
				//char* evStr = NULL;

				// generate structural join statement
				char* ancsEvStr = partialEvPlan->getEvaluationPlan();
				char* descEvStr = childPartialPlan->getEvaluationPlan();

				char* ancsSortStr = NULL;
				char* descSortStr = NULL;
				bool ancsSorted, descSorted;

				if (!partialEvPlan->orderbyStartKeyOfNode(rootLCL))
				{
					// if the plan is not ordered by the ancestor node,
					OrderKey* orderKey = new OrderKey(rootLCL);
					// do a sort here
					ancsSortStr = this->planSegmentGenerator.generateSortStr(true,
						orderKey);
					delete orderKey;
					if (ancsSortStr == NULL) 
					{
						success = false;
						globalErrorInfo.insertProblem(ERR_TYPE_ERROR, __LINE__, 
							"SimplePlanGenerator::generateSimplePlanForSubPatternRootedAt", __FILE__,
							"Error reported when generating sort statement." );
						goto selectexit;
					}
					ancsSorted = true;
				}

				else
				{
					ancsSortStr = new char[2];
					ancsSortStr[0] = '\0';
					ancsSorted = false;
				}

				if (!childPartialPlan->orderbyStartKeyOfNode(childLCL))
				{
					// if the plan is not ordered by the descendant node,
					// do a sort here
					OrderKey* orderbyKey = new OrderKey(childLCL);
					descSortStr = this->planSegmentGenerator.generateSortStr(true, orderbyKey);
					delete orderbyKey;
					if (descSortStr == NULL) 
					{
						success = false;
						globalErrorInfo.insertProblem(ERR_TYPE_ERROR, __LINE__, 
							"SimplePlanGenerator::generateSimplePlanForSubPatternRootedAt", __FILE__,
							"Error reported when generating a sort statement." );
						goto selectexit;
					}
					descSorted = true;
				}

				else 
				{
					descSortStr = new char[2];
					descSortStr[0] = '\0';
					descSorted = false;
				}

				int joinAlgo = JOIN_ALGORITHM_STACK_ANCS;
                bool nested = false;
					
				switch (childNode->getJoinOption())
                {
                case PTTREE_OPERATION_ONLYONE:
                     joinAlgo = JOIN_ALGORITHM_STACK_ANCS;
                     nested = false;
                     break;

                case PTTREE_OPERATION_ZEROORONE:
                     joinAlgo = JOIN_ALGORITHM_STACK_OUTERANCS;
                     nested = false;
                     break;

                case PTTREE_OPERATION_ZEROORMORE:                                                                                               
                     joinAlgo = JOIN_ALGORITHM_STACK_OUTERANCS;
                     nested = true;
                     break;

                case PTTREE_OPERATION_ONEORMORE:
                     joinAlgo = JOIN_ALGORITHM_STACK_ANCS;
                     nested = true;
                     break;
                 }

				char* strucJoinStr 
					= this->planSegmentGenerator.generateStructuralJoinStr(
								rootNode->getLCL(),
								childNode->getLCL(),
								childNode->getRelationWithParent(),
								joinAlgo, nested,
								JOIN_PROJECTION_BOTH);
					
				if (strucJoinStr == NULL)
				{
					success = false;
					globalErrorInfo.insertProblem(ERR_TYPE_ERROR, __LINE__, 
						"SimplePlanGenerator::generateSimplePlanForSubPatternRootedAt", __FILE__,
						"Error reported when generating a structural join statement." );
					goto selectexit;
				}

				int evStrSize = (int) strlen(strucJoinStr) 
								+ (int) strlen(ancsEvStr) 
								+ (int) strlen(descEvStr)
								+ (int) strlen(ancsSortStr) 
								+ (int) strlen(descSortStr) + 10;
				evStr = new char[evStrSize];
					
				strcpy(evStr, strucJoinStr);
				strcat(evStr, "\n");
				if (ancsSorted)
				{
					strcat(evStr, ancsSortStr);
					strcat(evStr, "\n");
				}
				strcat(evStr, ancsEvStr);
				strcat(evStr, "\n");
				if (descSorted)
				{
					strcat(evStr, descSortStr);
					strcat(evStr, "\n");
				}
				strcat(evStr, descEvStr);

				delete [] ancsSortStr;
				delete [] descSortStr;
				delete [] strucJoinStr;
				
				// construct the witnesstree info for the subpattern  after join
				LCLWTTreeMapType* wtTree 
						= this->wtTracker.structuralJoinWitnessTrees(partialEvPlan->getWTTree(),
																	childPartialPlan->getWTTree());

				newPartialEvPlan = new PartialEvaluationPlan(evStr, wtTree, 
						new OrderKey(rootNode->getLCL()));

				if (newPartialEvPlan == NULL)
				{
					success = false;
					globalErrorInfo.insertProblem(ERR_TYPE_ERROR, __LINE__, 
						"SimplePlanGenerator::generateSimplePlanForSubPatternRootedAt", __FILE__,
						"Error reported when generating plan for a sub pattern." );
					goto selectexit;
				}
	
selectexit:
				// clean up
				if (evStr != NULL)	delete [] evStr;

				if (partialEvPlan != NULL) delete partialEvPlan;
				if (childPartialPlan != NULL) delete childPartialPlan;

				partialEvPlan = newPartialEvPlan;

				// if not success, jump out of the loop
				if (!success) break;

			} // end of FOR loop on each child of the root node
		} 	
		break; // end of cases for reference node and selection node

		case PATTERN_TREE_MLCAROOT_NODE: 
			// nothing need to be done here. 
			break;

		default: 
			sprintf(this->errMsg, "%s is not a valid pattern tree node type.", rootNodeType);
			globalErrorInfo.insertProblem(ERR_TYPE_ERROR, __LINE__, 
				"SimplePlanGenerator::generateSimplePlanForSubPatternRootedAt", __FILE__,
				this->errMsg);
			goto exit;
	}	// end of switch on the pattern tree node type of the root node. 
		
exit: 
	if (success) 
		return partialEvPlan;
	else return NULL;
}

/**
 * Generate physical plan for a pattern tree node
 *@param ptTreeNode The pattern tree node to be processed. 
 *@param inputWitnessTreeNumber The number of input witness trees to the pattern tree matching. 
 *@param partialEvPlanForInputWitnessTrees The partial plans that compute the witness trees. 
 *@return The partial plan that compute the pattern tree node.
 */
PartialEvaluationPlan* SimplePlanGenerator
::generateSimplePlanForPatternTreeNode(PatternTreeNode* ptTreeNode,
									   NodeIDType psNodeID,
									   int inputWitnessTreeNumber,
									   PartialEvaluationPlan** partialEvPlanForInputWitnessTrees)
{
	PartialEvaluationPlan* partialPlan = NULL;

	switch (ptTreeNode->getPtTreeNodeType())
	{
	case PATTERN_TREE_SELECTION_NODE:		
		globalErrorInfo.insertProblem(ERR_TYPE_ERROR, __LINE__, 
			"SimplePlanGenerator::generateSimplePlanForPatternTreeNode", __FILE__,
			"The Simple Plan Generator takes a process tree with marked pattern tree as input.." );
		partialPlan = NULL;
		break;

	case PATTERN_TREE_VALUEJOIN_NODE:
		globalErrorInfo.insertProblem(ERR_TYPE_ERROR, __LINE__, 
			"SimplePlanGenerator::generateSimplePlanForPatternTreeNode", __FILE__,
			"value join node is handled in GenerateSimplePlanForPatternTreeRootedAt(). It should not be passed in to generateSimplePlanForPattherTreeNode()" );
		partialPlan = NULL;
		break;

	case PATTERN_TREE_CONSTRUCT_NODE:
		break;

	case PATTERN_TREE_REFERENCE_NODE:
		partialPlan = this->planSegmentGenerator.generatePlanForPtReferenceNode((PatternTreeReferenceNode*) ptTreeNode, 
																 inputWitnessTreeNumber,
																 partialEvPlanForInputWitnessTrees);
		break;

	case MARKED_PATTERN_TREE_SELECTION_NODE:
		partialPlan = this->planSegmentGenerator.generatePlanForPtSelectionNode(
			(MarkedPatternTreeSelectionNode*) ptTreeNode, 
			psNodeID);
		break;

	default: 
		sprintf(this->errMsg, "%d is not a valid pattern tree node type", ptTreeNode->getPtTreeNodeType());
		globalErrorInfo.insertProblem(ERR_TYPE_ERROR, __LINE__, 
			"SimplePlanGenerator::generateSimplePlanForSubPatternRootedAt", __FILE__,
			this->errMsg);
		partialPlan = NULL;
		break;
	}

	return partialPlan;
}



/**
 * check whether a process tree is marked (index selection is done)
 *@param psTree The process tree to be checked. 
 *@return A boolean variable which indicate whether the patterns tree nodes in the process tree are marked. 
 */
bool SimplePlanGenerator::psTreeIsMarked(ProcessTree* psTree)
{
	int i, j;

	int psTreeNodeNum = psTree->getNodeNumber();

	// go over each process tree node. 
	for (i=0; i<psTreeNodeNum; i++)
	{
		ProcessTreeNode* psTreeNode = psTree->getPsNodeAtIndex(i);

		// take only the process tree node that may have pattern tree. 
		if (psTreeNode->getPsNodeType() == PROCESS_TREE_SELECT_NODE)
		{
			PatternTree* ptTree = ((ProcessTreeSelectNode*) psTreeNode)->getPatternTree();

			int ptTreeNodeNum = ptTree->getNodeNumber();

			// go over the pattern tree nodes
			for (j=0; j<ptTreeNodeNum; j++)
			{
				PatternTreeNode* ptTreeNode = ptTree->getPtNodeAtIndex(j);

				if (ptTreeNode->getPtTreeNodeType() == PATTERN_TREE_SELECTION_NODE)
					return false;
			}
		}
	}

	return true;
}


/**
 * Generate physical plan that performs construct. 
 *@param ptTree The construct pattern tree to be processed. 
 *@inputWitnessTree The witness tree as the input to the construction
 *@return The construct statement. 
 */
char* SimplePlanGenerator
::generateConstructStrTagging(PatternTree* ptTree, 
							  LCLWTTreeMapType* inputWitnessTree, 
							  NodeIDType psNodeID,
							  WitnessTreeNode** wtNodes)
{
	bool success = true;
	char* evStr = NULL;
		
	char constructStr[1000];

	int ptNodeNum = ptTree->getNodeNumber();

	// use wtNodes to hold the info about the witness tree nodes produced by construct.
	WitnessTreeNode* wtTreeNodes = new WitnessTreeNode[ptNodeNum];

	// create a depth first node list of the nodes in the construct pattern tree. 
	NodeIDType* depthFirstNodeIDList = ptTree->getDepthFirstNodeList();

	sprintf(constructStr, "s,%d,", ptNodeNum);

	// go over the pattern tree nodes in the construct pattern tree. 
	for (int i=0; i<ptNodeNum; i++)
	{
		NodeIDType nodeid = depthFirstNodeIDList[i];
		PatternTreeConstructNode* ptNode = (PatternTreeConstructNode*) ptTree->getNodeWithID(nodeid);
		int nodeDepth = ptTree->getDepthOfNode(ptNode->getNodeID())+1;

		// initialize the witness tree node
		wtTreeNodes[i].nodeLCL = ptNode->getLCL();
		wtTreeNodes[i].definedAt.psTreeNodeID = psNodeID;
		wtTreeNodes[i].definedAt.ptTreeNodeID = ptNode->getNodeID();
		wtTreeNodes[i].witnessTreeNodeType = WT_CONSTRUCTED_NODE; // default

		// nodes are treated differently based on their type. 
		switch (ptNode->getConstructNodeType())
		{
		case CONSTRUCT_ELEMENT:
			sprintf(constructStr+strlen(constructStr), "%d,E,C,%d,%s", 
				nodeDepth, ptNode->getLCL(), ptNode->getNodeTag());
			break;

		case CONSTRUCT_ATTRIBUTE:
			{
				// a constrction attribute node refer to other node in the witness tree for its value. 

				// find the LCL of the node being refered.
				LCLType nodeLCL = ptNode->getLCL();
				LCLType refLCL = ptNode->getLCLRefered();
				if (!this->wtTracker.findNode(inputWitnessTree, refLCL))
				{
					sprintf(this->errMsg, "Pattern tree node (id=%d) refered by construct pattern tree node (id=%d) is not in the input witness tree.", refLCL, nodeid);
					globalErrorInfo.insertProblem(ERR_TYPE_ERROR, __LINE__, 
						"SimplePlanGenerator::generateConstructStrTagging", __FILE__,
						this->errMsg);
					success = false;
					goto exit;
				}
				else if (!this->wtTracker.nodeIsActive(inputWitnessTree, refLCL))
				{
					sprintf(this->errMsg, "Pattern tree node (id=%d) refered by construct pattern tree node (id=%d) is not active in the input witness tree.", refLCL, nodeid);
					globalErrorInfo.insertProblem(ERR_TYPE_ERROR, __LINE__, 
						"SimplePlanGenerator::generateConstructStrTagging", __FILE__,
						this->errMsg);
					success = false;
					goto exit;
				}
				else 
				{		
					// construct the portion of the statement for this attribute
					sprintf(constructStr+strlen(constructStr), "%d,A,R,%d,%s,%d,0,",
						nodeDepth, nodeLCL, ptNode->getNodeTag(), refLCL);

					switch (ptNode->getConstructPtOption())
					{
					case CONSTRUCT_OPTION_NODE: 
						strcat(constructStr, "S"); 
						break;  

					case CONSTRUCT_OPTION_CONTENT: 
						{
							// the flag used in the statement depends on the source of the attribute value. 

							int nodeType = this->wtTracker.getWitnessTreeNodeType(
													inputWitnessTree,
													refLCL);
							switch (nodeType)
							{
							case WT_AGGRFUNC_NODE:
								strcat(constructStr, "I");
								break;

							case WT_ELEMENT_NODE:
							case WT_DOCUMENT_NODE:
								strcat(constructStr, "T");
								break;

							case WT_ATTRIBUTE_NODE:
								{ 
									// if the node to be refered is an attribute node, get the attribute name.

									char* attrName = this->wtTracker.getAttrName(
															inputWitnessTree,
															this->PsTree,
															refLCL);
							
									if (attrName == NULL)
									{
										sprintf(this->errMsg, "Witness tree node (LCL=%d) is an attribute node, but the name is not available.", refLCL);
										globalErrorInfo.insertProblem(ERR_TYPE_ERROR, __LINE__, 
											"SimplePlanGenerator::generateConstructStrTagging", __FILE__,
											this->errMsg);
										success = false;
										goto exit;

									}
									else
										sprintf(constructStr+strlen(constructStr), "A,%s", attrName);
							
									if (attrName != NULL) 
										delete [] attrName;
								}
								break;

							default:
								globalErrorInfo.insertProblem(ERR_TYPE_ERROR, __LINE__, 
									"SimplePlanGenerator::generateConstructStrTagging", __FILE__,
									"The witness tree node type is not a valid type to be refered in construct.");
								success = false;
								goto exit;
							}
						}
						break;

					case CONSTRUCT_OPTION_SUBTREE: 
						{
							int nodeType = this->wtTracker.getWitnessTreeNodeType(
													inputWitnessTree,
													refLCL);
							switch (nodeType)
							{
							case WT_AGGRFUNC_NODE:
								strcat(constructStr, "I");
								break;

							case WT_ATTRIBUTE_NODE:
								{ 
									// if the node to be refered is an attribute node, get the attribute name.

									char* attrName = this->wtTracker.getAttrName(
															inputWitnessTree,
															this->PsTree,
															refLCL);
							
									if (attrName == NULL)
									{
										sprintf(this->errMsg, "Witness tree node (LCL=%d) is an attribute node, but the name is not available.", refLCL);			
										globalErrorInfo.insertProblem(ERR_TYPE_ERROR, __LINE__, 
											"SimplePlanGenerator::generateConstructStrTagging", __FILE__,
											this->errMsg);
										success = false;
										goto exit;

									}
									else
										sprintf(constructStr+strlen(constructStr), "S,%s", attrName);
							
									if (attrName != NULL) 
										delete [] attrName;
								}
								break;

							default:
								strcat(constructStr, "S"); 
							}
						}
						break;

					case CONSTRUCT_OPTION_OUTER: 
						strcat(constructStr, "L");
						break;

					default:
						globalErrorInfo.insertProblem(ERR_TYPE_ERROR, __LINE__, 
							"SimplePlanGenerator::generateConstructStrTagging", __FILE__,
							"The construct option is not a valid one.");
						success = false;
						goto exit;
					}
				}	
			}
			break;

		case CONSTRUCT_REFERENCE:
			{		
				// this construct the element content in the result. 

				LCLType nodeLCL = ptNode->getLCL();
				LCLType refLCL = ptNode->getLCLRefered();
				bool contentMaterialized = false;
	
				if (!this->wtTracker.findNode(inputWitnessTree, refLCL))
				{
					sprintf(this->errMsg, "Pattern tree node (id=%d) refered by construct pattern tree node (id=%d) is not in the input witness tree", refLCL, nodeid);
					globalErrorInfo.insertProblem(ERR_TYPE_ERROR, __LINE__, 
						"SimplePlanGenerator::generateConstructStrTagging", __FILE__,
						this->errMsg);
					success = false;
					goto exit;
				}
				else if (!this->wtTracker.nodeIsActive(inputWitnessTree, refLCL))
				{
					sprintf(this->errMsg, "Pattern tree node (id=%d) refered by construct pattern tree node (id=%d) is not active in the input witness tree", refLCL, nodeid);
					globalErrorInfo.insertProblem(ERR_TYPE_ERROR, __LINE__, 
						"SimplePlanGenerator::generateConstructStrTagging", __FILE__,
						this->errMsg);
					success = false;
					goto exit;
				}
				else 
				{	
					// construct the portion of the statement for the element content. 
					switch (ptNode->getConstructPtOption())
					{
					case CONSTRUCT_OPTION_NODE: 
						sprintf(constructStr+strlen(constructStr), "%d,C,R,%d,%d,0,I",
							nodeDepth, nodeLCL, refLCL );
						wtTreeNodes[i].definedAt = this->wtTracker.getDefineAt(inputWitnessTree, refLCL);
						wtTreeNodes[i].witnessTreeNodeType = this->wtTracker.getWitnessTreeNodeType(inputWitnessTree, refLCL);
						break;

					case CONSTRUCT_OPTION_CONTENT: 
						{
							int nodeType = this->wtTracker.getWitnessTreeNodeType(
													inputWitnessTree,
													refLCL);

							switch (nodeType)
							{
							case WT_AGGRFUNC_NODE:
								sprintf(constructStr+strlen(constructStr), 
									"%d,C,R,%d,%d,0,I",
									nodeDepth, nodeLCL, refLCL );
								contentMaterialized = true;
								break;

							case WT_ELEMENT_NODE:
							case WT_DOCUMENT_NODE:
								sprintf(constructStr+strlen(constructStr), 
									"%d,C,R,%d,%d,0,T",
									nodeDepth, nodeLCL, refLCL );
																
								// if use T to fetch the node in construct, the content of the element
								// is also in the witness tree. 
								wtTreeNodes[i].witnessTreeNodeType = WT_CONSTRUCTED_NODE_WITH_TEXT;
								contentMaterialized = true;
								break;

							case WT_ATTRIBUTE_NODE:
								{ 
									char* attrName = this->wtTracker.getAttrName(
															inputWitnessTree,
															this->PsTree,
															refLCL);
							
									if (attrName == NULL)
									{
										sprintf(this->errMsg, "Witness tree node (LCL=%d) is an attribute node, but the name is not available.", refLCL);
										globalErrorInfo.insertProblem(ERR_TYPE_ERROR, __LINE__, 
											"SimplePlanGenerator::generateConstructStrTagging", __FILE__,
											this->errMsg);
										success = false;
										goto exit;
									}
									else
									{
										sprintf(constructStr+strlen(constructStr), 
											"%d,C,R,%d,%d,0,V,%s",
											nodeDepth, nodeLCL, refLCL, attrName);
										contentMaterialized = true;
									}
									if (attrName != NULL) 
										delete [] attrName;
								}
								break;
							}
						}
						break;

					case CONSTRUCT_OPTION_SUBTREE: 
						{
							int nodeType = this->wtTracker.getWitnessTreeNodeType(
													inputWitnessTree,
													refLCL);

							switch (nodeType)
							{
							case WT_AGGRFUNC_NODE:
								sprintf(constructStr+strlen(constructStr), 
									"%d,C,R,%d,%d,0,I",
									nodeDepth, nodeLCL, refLCL );
								contentMaterialized = true;
								break;

							case WT_ATTRIBUTE_NODE:
								{ 
									char* attrName = this->wtTracker.getAttrName(
															inputWitnessTree,
															this->PsTree,
															refLCL);
							
									if (attrName == NULL)
									{
										sprintf(this->errMsg, "Witness tree node (LCL=%d) is an attribute node, but the name is not available", refLCL);
										globalErrorInfo.insertProblem(ERR_TYPE_ERROR, __LINE__, 
											"SimplePlanGenerator::generateConstructStrTagging", __FILE__,
											this->errMsg);
										success = false;
										goto exit;
									}
									else
										sprintf(constructStr+strlen(constructStr), 
											"%d,OA,R,%d,%s,%d,0,V,%s",
											nodeDepth, nodeLCL, attrName, refLCL, attrName );
							
									if (attrName != NULL) 
										delete [] attrName;
								}
								break;
							
							default:
								sprintf(constructStr+strlen(constructStr), 
									"%d,C,R,%d,%d,0,S",
									nodeDepth, nodeLCL, refLCL);
								contentMaterialized = true;
							}
						}
						break;

					case CONSTRUCT_OPTION_OUTER:
						sprintf(constructStr+strlen(constructStr), 
								"%d,C,R,%d,%d,0,L",
								nodeDepth, nodeLCL, refLCL);		
						break;
					
					default: 
						globalErrorInfo.insertProblem(ERR_TYPE_ERROR, __LINE__, 
							"SimplePlanGenerator::generateConstructStrTagging", __FILE__,
							"The construct option is not a valid one.");
						success = false;
						goto exit;
					}

					// if we just constructed an element content, no matter how we did it:
					// getting it from element content, aggragate function, attribute value
					// or the whole subtree, now, the parent element in the constructed tree
					// have content (text node) in witness tree. need to mark this in the
					// witness tree

					if (contentMaterialized)
					{
						NodeIDType parentID = ptNode->getParentID();
						if (parentID >= 0)
						{
							LCLType parentLCL = ((PatternTreeConstructNode*) ptTree->getNodeWithID(parentID))->getLCL();
							for (int k=0; k<ptNodeNum; k++)
								if (wtTreeNodes[k].nodeLCL == parentLCL) 
								{
									wtTreeNodes[k].witnessTreeNodeType = WT_CONSTRUCTED_NODE_WITH_TEXT;
									break;
								}
						}
					}

				}
			}
			break;
		}
		if (i < ptNodeNum -1)
			strcat(constructStr, ",");
	}
		
	delete [] depthFirstNodeIDList;

	evStr = new char[strlen(constructStr)+1];
	strcpy(evStr, constructStr);

	*wtNodes = wtTreeNodes;

exit:
	if (success)
		return evStr;		
	else return NULL;
}

PartialEvaluationPlan* SimplePlanGenerator
::addonSort(PartialEvaluationPlan* partialEvPlanForInputWitnessTree, 
			LCLType sortbyLCL,
			bool sortByStartKey)
{
	char* evStr = NULL;
	bool success = true;
	PartialEvaluationPlan* partialEvPlan = NULL;
					
	// prepare the sort key. 
	OrderKey* orderKey = NULL;
	
	if (sortByStartKey)
		orderKey = new OrderKey(sortbyLCL);
	else
	{
		OrderbyNode** orderbyNodes = new OrderbyNode*[1];

		orderbyNodes[0] = new OrderbyNode();
		orderbyNodes[0]->orderbyLCL = sortbyLCL;
		orderbyNodes[0]->orderbyOption = ORDER_BY_VALUE;
		orderbyNodes[0]->orderSpec = ORDER_SPEC_ASCENDING;
		orderbyNodes[0]->attrName = this->wtTracker.getAttrName(
					partialEvPlanForInputWitnessTree->getWTTree(),
					this->PsTree,
					sortbyLCL);
		orderbyNodes[0]->nullOption = ORDER_NULL_GREATEST;

		orderKey = new OrderKey(1, orderbyNodes);
	}

	// generate sort statement
	char* sortStr;

	sortStr = this->planSegmentGenerator.generateSortStr(
		sortByStartKey, 
		orderKey);
				
	if (sortStr == NULL) 
	{
		globalErrorInfo.insertProblem(ERR_TYPE_ERROR, __LINE__, 
			"SimplePlanGenerator::addonSort", __FILE__,
			"Error reported when generating a sort statement." );
		success = false;
		goto exit;
	}

	char* prevEvStr = partialEvPlanForInputWitnessTree->getEvaluationPlan();

	evStr = new char[strlen(sortStr) + strlen(prevEvStr) + 2];
	strcpy(evStr, sortStr);
	strcat(evStr, "\n");
	strcat(evStr, prevEvStr);
	delete [] sortStr;

	// generate the new witness tree. 
	LCLWTTreeMapType* wtTree = this->wtTracker.sortWitnessTree(partialEvPlanForInputWitnessTree->getWTTree());

	// generate the partial plan
	partialEvPlan = new PartialEvaluationPlan(evStr, wtTree,
									orderKey);

	if (partialEvPlan == NULL)
	{
		success = false;
				globalErrorInfo.insertProblem(ERR_TYPE_ERROR, __LINE__, 
					"SimplePlanGenerator::addonSort", __FILE__,
					"Error reported when generating plan with an add-on sort" );
		goto exit;
	}

exit:
	if (evStr != NULL) delete [] evStr;	
	if (success)
		return partialEvPlan;
	else return NULL;
}

