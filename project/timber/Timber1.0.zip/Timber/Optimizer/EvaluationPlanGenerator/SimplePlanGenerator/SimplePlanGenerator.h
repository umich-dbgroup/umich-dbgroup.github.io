/**
COPYRIGHT  � 2000-2004
THE REGENTS OF THE UNIVERSITY OF MICHIGAN ALL RIGHTS RESERVED

PERMISSION IS GRANTED TO USE, COPY, CREATE DERIVATIVE WORKS A
ND REDISTRIBUTE THIS SOFTWARE AND SUCH DERIVATIVE WORKS FOR 
NONCOMMERCIAL EDUCATION AND RESEARCH PURPOSES, SO LONG AS NO 
FEE IS CHARGED, AND SO LONG AS THE COPYRIGHT NOTICE ABOVE, 
THIS GRANT OF PERMISSION, AND THE DISCLAIMER BELOW APPEAR IN 
ALL COPIES MADE; AND SO LONG AS THE NAME OF THE UNIVERSITY OF 
MICHIGAN IS NOT USED IN ANY ADVERTISING OR PUBLICITY PERTAINING 
TO THE USE OR DISTRIBUTION OF THIS SOFTWARE WITHOUT SPECIFIC, 
WRITTEN PRIOR AUTHORIZATION.

THIS SOFTWARE IS PROVIDED AS IS, WITHOUT REPRESENTATION FROM 
THE UNIVERSITY OF MICHIGAN AS TO ITS FITNESS FOR ANY PURPOSE, 
AND WITHOUT WARRANTY BY THE UNIVERSITY OF MICHIGAN OF ANY KIND, 
EITHER EXPRESS OR IMPLIED, INCLUDING WITHOUT LIMITATION THE 
IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A 
PARTICULAR PURPOSE. THE REGENTS OF THE UNIVERSITY OF MICHIGAN 
SHALL NOT BE LIABLE FOR ANY DAMAGES, INCLUDING SPECIAL, INDIRECT, 
INCIDENTAL, OR CONSEQUENTIAL DAMAGES, WITH RESPECT TO ANY CLAIM 
ARISING OUT OF OR IN CONNECTION WITH THE USE OF THE SOFTWARE, 
EVEN IF IT HAS BEEN OR IS HEREAFTER ADVISED OF THE POSSIBILITY 
OF SUCH DAMAGES.
*/


#ifndef __SimplePlanGenerator_H
#define __SimplePlanGenerator_H

#include "../Common/PlanSegmentGenerator.h"




/**
 * class SimplePlanGenerator
 * This class generate simple (not well optimized) physical plan
 * given a logical plan. 
 *@see IndexSelection
 *@see ProcessTree
 *@see PatternTree
 *@see PartialEvaluationPlan
 *@see WitnessTreeTracker
 *@author Yuqing Melanie Wu
 */
class SimplePlanGenerator
{
public:
	SimplePlanGenerator(IndexMng* indexMng);
	~SimplePlanGenerator(void);

	bool generateSimplePlan(ProcessTree* markedpsTree, 
		int planGenOpt, 
		char** EvPlan);

private:
	/** 
	 * The index manager
	 */
	IndexMng* indexMng;

	/*
	 * For index matching
	 */
	IndexMatching* indexMatching;

	/**
	 * plan generation options
	 */
	bool planGenOption;		

	/**
	 * Process tree -- Logical Plan
	 */
	ProcessTree* PsTree;

	/**
	 * Tools for plan generation: to track the witness tree,
	 * to generate plan segment, etc.
	 */
	WitnessTreeTracker wtTracker;
	PlanSegmentGenerator planSegmentGenerator;

	/**
	 * For constructing error message
	 */
	char errMsg[1000];

	/**
	 * The following are internal methods.
	 */
	bool psTreeIsMarked(ProcessTree* psTree);

	PartialEvaluationPlan* generateSimplePlanForProcessTree();

	PartialEvaluationPlan* generateSimplePlanForProcessTreeRootedAt(
		NodeIDType rootid,
		char* carryinJoinIndexName,
		PartialEvaluationPlan* partialEvPlanForValueJoin);

	PartialEvaluationPlan* generateSimplePlanForProcessTreeNode(
		ProcessTreeNode* psNode,
		int inputWitnessTreeNum, 
		PartialEvaluationPlan** partialEvPlanForChildren,
		char* carryinJoinIndexName,
		PartialEvaluationPlan* partialEvPlanForValueJoin);

	PartialEvaluationPlan* generateSimplePlanForPsSelectNode(
		ProcessTreeSelectNode* selectNode,
		int inputWitnessTreeNum, 
		PartialEvaluationPlan** partialEvPlanForInputWitnessTrees,
		char* carryinJoinIndexName,
		PartialEvaluationPlan* partialEvPlanForValueJoin);

	PartialEvaluationPlan* generateSimplePlanForPsProjectNode(
		ProcessTreeProjectNode* projNode,
		PartialEvaluationPlan* partialEvPlanForInputWitnessTree);

	PartialEvaluationPlan* generateSimplePlanForPsAggregateFunctionNode(
		ProcessTreeAggregateFunctionNode* aggrNode,
		PartialEvaluationPlan* partialEvPlanForInputWitnessTree);

	PartialEvaluationPlan* generateSimplePlanForPsDuplicateEliminationNode(
		ProcessTreeDuplicateEliminationNode* deNode,
		PartialEvaluationPlan* partialEvPlanForInputWitnessTree);

	PartialEvaluationPlan* generateSimplePlanForPsFilterNode(
		ProcessTreeFilterNode* filterNode,
		PartialEvaluationPlan* partialEvPlanForInputWitnessTree);

	PartialEvaluationPlan* generateSimplePlanForPsSortNode(
		ProcessTreeSortNode* sortNode,
		PartialEvaluationPlan* partialEvPlanForInputWitnessTree);

	PartialEvaluationPlan* generateSimplePlanForPsSetNode(
		int inputWitnessTreeNum, 
		PartialEvaluationPlan** partialEvPlanForInputWitnessTrees);

	PartialEvaluationPlan* generateSimplePlanForPsConstructNode(
		ProcessTreeConstructNode* constructionNode,
		PartialEvaluationPlan* partialEvPlanForInputWitnessTree);

	PartialEvaluationPlan* generateSimplePlanForPsMLCANode(
		ProcessTreeMLCANode* mlcaNode,
		PartialEvaluationPlan* partialEvPlanForInputWitnessTree);

	PartialEvaluationPlan* generateSimplePlanForPsUpdateNode(
		ProcessTreeUpdateNode* updateNode,
		PartialEvaluationPlan* partialEvPlanForInputWitnessTree);

	PartialEvaluationPlan* generateSimplePlanForPsInsertNode(
		ProcessTreeInsertNode* insertNode,
		PartialEvaluationPlan* partialEvPlanForInputWitnessTree);

	PartialEvaluationPlan* generateSimplePlanForPsDeleteNode(
		ProcessTreeDeleteNode* deleteNode,
		PartialEvaluationPlan* partialEvPlanForInputWitnessTree);

	PartialEvaluationPlan* generateSimplePlanForPatternTree(
		PatternTree* ptTree, 
		NodeIDType psNodeID,
		int inputWitnessTreeNum, 
		PartialEvaluationPlan** partialEvPlanForInputWitnessTree,
		char* carryinJoinIndexName,
		PartialEvaluationPlan* partialEvPlanForValueJoin);

	PartialEvaluationPlan* generateSimplePlanForSubPatternRootedAt(
		PatternTree* ptTree, 
		NodeIDType rootid,										  
		NodeIDType psNodeid, 
		int inputWitnessTreeNum, 
		PartialEvaluationPlan** partialEvPlanForInputWitnessTree,
		char* carryinJoinIndexName,
		PartialEvaluationPlan* partialEvPlanForValueJoin);

	PartialEvaluationPlan* generateSimplePlanForPatternTreeNode(
		PatternTreeNode* ptNode, 		
		NodeIDType psNodeID,
		int inputWitnessTreeNum, 
		PartialEvaluationPlan** partialEvPlanForInputWitnessTree);

	char* generateConstructGetWhatString();

	char* generateConstructStrTagging(PatternTree* ptTree, 
		LCLWTTreeMapType* inputWitnessTreePosMap,
		NodeIDType psNodeID,
		WitnessTreeNode** wtNodes);

	// the following function add a sort to the top of the plan
	PartialEvaluationPlan* addonSort(
		PartialEvaluationPlan* partialEvPlanForInputWitnessTree, 
		LCLType sortbyLCL,
		bool sortbyStartKey);

	friend class WitnessTreeNode;
};


#endif