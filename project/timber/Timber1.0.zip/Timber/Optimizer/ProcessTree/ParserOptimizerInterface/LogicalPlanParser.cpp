/**
COPYRIGHT  � 2000-2004
THE REGENTS OF THE UNIVERSITY OF MICHIGAN ALL RIGHTS RESERVED

PERMISSION IS GRANTED TO USE, COPY, CREATE DERIVATIVE WORKS A
ND REDISTRIBUTE THIS SOFTWARE AND SUCH DERIVATIVE WORKS FOR 
NONCOMMERCIAL EDUCATION AND RESEARCH PURPOSES, SO LONG AS NO 
FEE IS CHARGED, AND SO LONG AS THE COPYRIGHT NOTICE ABOVE, 
THIS GRANT OF PERMISSION, AND THE DISCLAIMER BELOW APPEAR IN 
ALL COPIES MADE; AND SO LONG AS THE NAME OF THE UNIVERSITY OF 
MICHIGAN IS NOT USED IN ANY ADVERTISING OR PUBLICITY PERTAINING 
TO THE USE OR DISTRIBUTION OF THIS SOFTWARE WITHOUT SPECIFIC, 
WRITTEN PRIOR AUTHORIZATION.

THIS SOFTWARE IS PROVIDED AS IS, WITHOUT REPRESENTATION FROM 
THE UNIVERSITY OF MICHIGAN AS TO ITS FITNESS FOR ANY PURPOSE, 
AND WITHOUT WARRANTY BY THE UNIVERSITY OF MICHIGAN OF ANY KIND, 
EITHER EXPRESS OR IMPLIED, INCLUDING WITHOUT LIMITATION THE 
IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A 
PARTICULAR PURPOSE. THE REGENTS OF THE UNIVERSITY OF MICHIGAN 
SHALL NOT BE LIABLE FOR ANY DAMAGES, INCLUDING SPECIAL, INDIRECT, 
INCIDENTAL, OR CONSEQUENTIAL DAMAGES, WITH RESPECT TO ANY CLAIM 
ARISING OUT OF OR IN CONNECTION WITH THE USE OF THE SOFTWARE, 
EVEN IF IT HAS BEEN OR IS HEREAFTER ADVISED OF THE POSSIBILITY 
OF SUCH DAMAGES.
*/

#pragma warning(disable: 4312)
#pragma warning(disable: 4702)

#include "LogicalPlanParser.h"

/**
 * Constructor
 * Initialize the dictionary and the local variables for 
 * a logical plan parser
 *
 *@see LogicalPlanParser::initKeywordMap
 */
LogicalPlanParser::LogicalPlanParser(void)
{
	this->initKeywordMap();
	this->psTreeNodes = NULL;
	this->psTree = NULL;
	this->ptTreeNodes = NULL;
	this->ptTrees = NULL;
}

/**
 * Distructor
 */
LogicalPlanParser::~LogicalPlanParser(void)
{
	if (this->ptTreeNodes != NULL)
		delete [] this->ptTreeNodes;
	if (this->psTreeNodes != NULL)
		delete [] this->psTreeNodes;
	if (this->ptTrees != NULL)
		delete [] this->ptTrees;

	this->keywordDictionary.clear(); 
}

/**
 * Interface I
 * given a logical plan in a local file, read the file and build
 * a process tree.
 *
 *@param filename The name of the local file that contains the string representation of a logical plan
 *@returns A process tree. NULL if there is any syntax error in the logical plan
 *
 *@see LogicalPlanParser::getProcessTreeFromString
 */
ProcessTree* LogicalPlanParser
::getProcessTreeFromFile(char* filename)
{
	ProcessTree* psTree = NULL;
	std::fstream fStream;
	fStream.open(filename, std::ios::in);
	if (fStream.is_open() == 0)
    {
		sprintf(this->errMsg, "File %s cannot be opened.", filename);
        globalErrorInfo.insertProblem(ERR_TYPE_ERROR, __LINE__, 
			"LogicalPlanParser::getProcessTreeFromFile", __FILE__, 
			this->errMsg);
		goto exit;
    }

	psTree = this->getProcessTreeFromString(&fStream);
	fStream.close();

exit:
	return psTree;
}

/**
 * Interface II
 * Given a string or stream, build process tree. 
 *
 * A string representation of a logical tree is in the following format: 
 *	ptTreeNodeNum ptTreeNum psTreeNodeNum
 *	list of pattern tree nodes
 *	list of pattern trees
 *	list of process tree nodes.
 *
 *@papam inputStream The stream that contains the string representation of a logical plan
 *@returns A process tree. NULL if there is any syntax error in the logical plan
 */

ProcessTree* LogicalPlanParser
::getProcessTreeFromString(void* inputStream)
{
	this->pTreeStream = (std::iostream*) inputStream;

	// read the numbers  for pattern tree node, pattern tree and process tree node

	this->skipComment();
	if (this->checkEOF()) 
	{
		this->success = false;
		globalErrorInfo.insertProblem(ERR_TYPE_ERROR, __LINE__, 
			"LogicalPlanParser::getProcessTreeFromString", __FILE__, 
			"EOF comes before the end of the logical plan.");
		goto exit;
	}

	*(this->pTreeStream) >> this->ptTreeNodeNum 
						 >> this->ptTreeNum 
						 >> this->psTreeNodeNum;
	bool charRead = this->skipTill('\n');

	if (charRead)
	{		
		globalErrorInfo.insertProblem(ERR_TYPE_ERROR, __LINE__, 
			"LogicalPlanParser::getProcessTreeFromString", __FILE__, 
			"There should be no other input on the line after the procdess tree node number.");
		this->success = false;
		goto exit;
	}

	if (this->checkEOF()) 
	{
		globalErrorInfo.insertProblem(ERR_TYPE_ERROR, __LINE__, 
			"LogicalPlanParser::getProcessTreeFromString", __FILE__, 
			"EOF comes before the end of the logical plan.");
		this->success = false;
		goto exit;
	}

	if ((this->ptTreeNodeNum < 0) || 
		(this->ptTreeNum < 0) ||
		(this->psTreeNodeNum < 0))
	{
		globalErrorInfo.insertProblem(ERR_TYPE_ERROR, __LINE__, 
			"LogicalPlanParser::getProcessTreeFromString", __FILE__, 
			"None of the pattern tree node number, pattern tree number or process tree node number can be less than zero.");
		this->success = false;
		goto exit;
	}

	// Allocate space for the pattern tree nodes, pattern trees and process tree nodes;
	this->ptTreeNodes = new PatternTreeNode*[this->ptTreeNodeNum];
	for (int i=0; i<this->ptTreeNodeNum; i++)
		this->ptTreeNodes[i] = NULL;

	this->ptTrees = new PatternTree*[this->ptTreeNum];
	for (int i=0; i<this->ptTreeNum; i++)
		this->ptTrees[i] = NULL;

	this->psTreeNodes = new ProcessTreeNode*[this->psTreeNodeNum];
	for (int i=0; i<this->psTreeNodeNum; i++)
		this->psTreeNodes[i] = NULL;

	if ((this->ptTreeNodes == NULL) ||
		(this->ptTrees == NULL) ||
		(this->psTreeNodes == NULL))
	{
		globalErrorInfo.insertProblem(ERR_TYPE_ERROR, __LINE__, 
			"LogicalPlanParser::getProcessTreeFromString", __FILE__, 
			"Error reported while allocating space for the process tree components.");
		this->success = false;
		goto exit;

	}

	// read pattern tree nodes
	for (int i=0; i<this->ptTreeNodeNum; i++)
	{			
		this->skipComment();
		this->success = this->readPatternTreeNode(i);
		if (!this->success)
		{
			sprintf(this->errMsg, "Error reported while reading the %d'th pattern tree node.", i);
			globalErrorInfo.insertProblem(ERR_TYPE_ERROR, __LINE__, 
				"LogicalPlanParser::getProcessTreeFromString", __FILE__, 
				this->errMsg);
			this->psTree = NULL;
			this->success = false;
			goto exit;
		}
	}

	// read pattern trees
	for (i=0; i<this->ptTreeNum; i++)
	{
		this->skipComment();
		this->success = this->readPatternTree(i);
		if (!this->success)
		{
			globalErrorInfo.insertProblem(ERR_TYPE_ERROR, __LINE__, 
				"LogicalPlanParser::getProcessTreeFromString", __FILE__, 
				"Error reported while reading the pattern tree.");
			this->psTree = NULL;
			this->success = false;
			goto exit;
		}
	}

	// read process tree nodes
	for (i=0; i<this->psTreeNodeNum; i++)
	{
		this->skipComment();
		this->success = this->readProcessTreeNode(i);
		if (!this->success)
		{
			globalErrorInfo.insertProblem(ERR_TYPE_ERROR, __LINE__, 
				"LogicalPlanParser::getProcessTreeFromString", __FILE__, 
				"Error reported while reading process tree node");
			this->psTree = NULL;
			this->success = false;
			goto exit;
		}
	}

	// read process tree
	this->skipComment();
	this->success = this->readProcessTree();
	if (!this->success)
	{
		globalErrorInfo.insertProblem(ERR_TYPE_ERROR, __LINE__, 
			"LogicalPlanParser::getProcessTreeFromString", __FILE__, 
			"Error reported while reading the process tree strcuture");
		this->psTree = NULL;
		this->success = false;
		goto exit;
	}

exit:
	/**
	 * clearn up all the space used by the parsing process
	 */
	if (!success)
		this->cleanup();
    return this->psTree;
}

/**
 * Read a pattern tree node
 * This method is called from LogicalPlanParser::getProcessTreeFromString
 * which loops through the pattern tree nodes and read them
 * one by one through this method. 
 *
 *@returns A boolean value which indicate whether the reading process is successful. 
 *@see LogicalPlanParser::getProcessTreeFromString.
 */
bool LogicalPlanParser::readPatternTreeNode(int index)
{
	this->success = true;

	// local variables

	NodeIDType nodeid = -1;
	/** 
	 * The following are local variable that holds the input 
	 * components of a pattern tree node. 
	 */
	char cNodeType[20];
	char cFileName[MAX_FILE_NAME_LENGTH];
	char cTag[MAX_NODETAG_LENGTH];
	char cOp[50];
	char cRightVal[MAX_TEXT_VALUE_LENGTH];
	char cRelation[50];
	char cJoinOpt[50];
	char* eleTag = NULL;
	char* attrName = NULL;

	// read the node id and the node type (string). 
	*(this->pTreeStream) >> nodeid >> cNodeType;
	
	if (this->checkEOF()) 
	{
		this->success = false;
		globalErrorInfo.insertProblem(ERR_TYPE_ERROR, __LINE__, 
			"LogicalPlanParser::readPatternTreeNode", __FILE__, 
			"EOF comes before the end of the logical plan");
		goto exit;
	}
	
	int ptTreeNodeType = -1;
	int secondaryNodeType = -1;

	/*
	 * Look up the pattern tree node type and sub-type from 
	 * in the dictionary, given the cNodeType read in. 
	 */
	this->parseKeyword(cNodeType, &ptTreeNodeType, &secondaryNodeType);

	/**
	 * deal with pattern tree node of different type, based on 
	 * their primiary ptTreeNodeType. 
	 */
	switch (ptTreeNodeType)
	{
	case PATTERN_TREE_SELECTION_NODE: 
		/* 
		 * This is for the pattern tree selection node
		 * keyword "ELEMENT", "DOCUMENT" and "ATTRIBUTE"
		 * matches to this node. 
		 */
		{
			*(this->pTreeStream) >> cFileName;
			if (this->checkEOF()) 
			{
				this->success = false;
				globalErrorInfo.insertProblem(ERR_TYPE_ERROR, __LINE__, 
					"LogicalPlanParser::readPatternTreeNode", __FILE__, 
					"EOF comes before the end of the logical plan");
				goto exit;
			}
			
			/*
			 * local variables for selection node
			 */
			SelectionCondition* cond = NULL;
			PredicateCondition* pred = NULL;
			ConjunctiveCondition* conj = NULL;
			DisjunctiveCondition* disj = NULL;

			/*
			 * deal with secondary node type
			 */
			switch (secondaryNodeType)
			{
			case DOCUMENT_NODE:
				// for document node, need to read the document name
				{
					Value* rightVal = new Value(STRING_VALUE);
					rightVal->setStrValue(cFileName);

					// build the predicate on document name
					PredicateCondition* pred = new PredicateCondition(SCAN_LEFTVALUE_XMLFILENAME, SCAN_OP_EQ, rightVal);
					conj = new ConjunctiveCondition(1);
					conj->insertCond(pred);
					disj = new DisjunctiveCondition(1);
					disj->insertCond(conj);
	
					cond = new SelectionCondition(secondaryNodeType, disj, SCAN_RETURN_THISNODE);

					attrName = NULL;
				}
				break;

			case ELEMENT_NODE:
				/*
				 * for element node, need to read the element tag
				 * and predicate on element content, if there is any. 
				 */ 
				{
					// read the element tag and the operator for the predicate
					*(this->pTreeStream) >> cTag >> cOp;			
					if (this->checkEOF()) 
					{
						this->success = false;
						globalErrorInfo.insertProblem(ERR_TYPE_ERROR, __LINE__, 
							"LogicalPlanParser::readPatternTreeNode", __FILE__, 
							"EOF comes before the end of the logical plan");
						goto exit;
					}

					eleTag = new char[strlen(cTag)+1];
					strcpy(eleTag, cTag);

					// build a predicate on the element tag. 
					Value* rightVal = new Value(STRING_VALUE);
					rightVal->setStrValue(cTag);
					pred = new PredicateCondition(SCAN_LEFTVALUE_NODETAG, SCAN_OP_EQ,  rightVal);

					// Look up the dictionary to interpret the operator
					int op = -1;
					int valuetype= -1;
					this->parseKeyword(cOp, &valuetype, &op);
					if ((valuetype == -1) || (op == -1))
					{
						sprintf(this->errMsg, "%s is not a valid operator for the preicate assoicated with a pattern tree node.", cOp);
						globalErrorInfo.insertProblem(ERR_TYPE_ERROR, __LINE__, 
							"LogicalPlanParser::readPatternTreeNode", __FILE__, 
							this->errMsg);
						this->success = false;
						goto exit;
					}

					/*
					 * in case the operator is NULL
					 * the predicate on element tag is the only predicate for the node
					 */
					if (op == PO_INTERFACE_NULL)
					{
						// still input the rightvalue, but ignor their value
						*(this->pTreeStream) >> cRightVal;

						if (this->checkEOF()) 
						{
							this->success = false;
							globalErrorInfo.insertProblem(ERR_TYPE_ERROR, __LINE__, 
								"LogicalPlanParser::readPatternTreeNode", __FILE__, 
								"EOF comes before the end of the logical plan");
							goto exit;
						}

						conj = new ConjunctiveCondition(1);
						conj->insertCond(pred);
						disj = new DisjunctiveCondition(1);
						disj->insertCond(conj);
					}
					
					/**
					 * otherwise, there is predicate on element content
					 */
					else
					{												
						// read the right value
						Value* rightVal = this->readRightValue(valuetype==STRING_VALUE);						
						
						if (this->checkEOF() || (rightVal == NULL))
						{
							this->success = false;
							globalErrorInfo.insertProblem(ERR_TYPE_ERROR, __LINE__, 
								"LogicalPlanParser::readPatternTreeNode", __FILE__, 
								"EOF comes before the end of the logical plan");
							goto exit;
						}

						// build the predicate on the element content
						PredicateCondition* pred1 = NULL;
						pred1 = new PredicateCondition(SCAN_LEFTVALUE_ELEMENTCONTENT, op, rightVal);

						conj = new ConjunctiveCondition(2);
						conj->insertCond(pred);
						conj->insertCond(pred1);
						disj = new DisjunctiveCondition(1);
						disj->insertCond(conj);
					}

					// construct the selection condition for the selection node. 
					cond = new SelectionCondition(secondaryNodeType, disj, SCAN_RETURN_THISNODE);

					// attrname is NULL for element node
					attrName = NULL;
				}
				break;
	
			case  ATTRIBUTE_NODE:
				/*
				 * for attribute name, need to read the attribute name and 
				 * the value (if there is any)in order to construct the selection condition
				 */
				{
					// read the attribute name and the operator
					*(this->pTreeStream) >> cTag >> cOp;			
					if (this->checkEOF())
					{
						this->success = false;
						globalErrorInfo.insertProblem(ERR_TYPE_ERROR, __LINE__, 
							"LogicalPlanParser::readPatternTreeNode", __FILE__, 
							"EOF comes before the end of the logical plan");
						goto exit;
					}

					// assign the attribute name
					attrName = new char[strlen(cTag)+1];
					strcpy(attrName, cTag);

					int leftVal = -1;
					Value* rightVal = NULL;
					int op = -1;
	
					// look up the dictionary to interpret the operator
					if (this->parseKeyword(cOp) == PO_INTERFACE_NULL)
					{
						/**
						 * in case the operator is NULL, the predicate associated with the pattern tree
						 * node is on the attribute name
						 * still input the rightvalue, but ignor their value
						 */

						// read the right value anyway
						*(this->pTreeStream) >> cRightVal;

						if (this->checkEOF()) 
						{
							this->success = false;
							globalErrorInfo.insertProblem(ERR_TYPE_ERROR, __LINE__, 
								"LogicalPlanParser::readPatternTreeNode", __FILE__, 
								"EOF comes before the end of the logical plan");
							goto exit;
						}

						// assign the component for a predicate
						leftVal = SCAN_LEFTVALUE_HASATTRIBUTE;
						rightVal = new Value(STRING_VALUE);
						// the attribute name is the rightvalue here. 
						rightVal->setStrValue(cTag);
						op = SCAN_OP_EQ;
					}

					else 
					{
						/*
						 * otherwise, there is value predicate 
						 * on the attribute with the given name (left value)
						 */
 
						int valuetype = -1;
						this->parseKeyword(cOp, &valuetype, &op);

						// the attribute name is the left value here. 
						leftVal = (int) new char[strlen(cTag) + 1];
						strcpy((char*) leftVal, cTag);

						// the right value is the attribute value to match
						rightVal = this->readRightValue(valuetype==STRING_VALUE);		
						if (this->checkEOF()) 
						{
							this->success = false;
							globalErrorInfo.insertProblem(ERR_TYPE_ERROR, __LINE__, 
								"LogicalPlanParser::readPatternTreeNode", __FILE__, 
								"EOF comes before the end of the logical plan");
							goto exit;
						}
						if (rightVal == NULL) 
						{
							this->success = false;
							globalErrorInfo.insertProblem(ERR_TYPE_ERROR, __LINE__, 
								"LogicalPlanParser::readPatternTreeNode", __FILE__, 
								"Error reported while reading right value.");
							goto exit;
						}
					}
					
					// construct the predicate. 
					pred = new PredicateCondition(leftVal, op, rightVal);
					conj = new ConjunctiveCondition(1);
					conj->insertCond(pred);
					disj = new DisjunctiveCondition(1);
					disj->insertCond(conj);
					cond = new SelectionCondition(secondaryNodeType, disj, SCAN_RETURN_THISNODE);
					
				}
				break;
			} // done with the part that are different for nodes that have different 
				// secondary node type. 
			
			/*
			 * all selectio nodes specify the relationship with parent and join option. 
			 */
			*(this->pTreeStream) >> cRelation >> cJoinOpt;

			// dictionary lookup. 
			int relationWithParent = this->parseKeyword(cRelation);
			if (relationWithParent < 0)
			{
				sprintf(this->errMsg, "%s is not a valid relationship with parent.", cRelation);
				globalErrorInfo.insertProblem(ERR_TYPE_ERROR, __LINE__, 
					"LogicalPlanParser::readPatternTreeNode", __FILE__, 
					this->errMsg);
				this->success = false;
				goto exit;		
			}			
			
			int joinOpt = this->parseKeyword(cJoinOpt);
			if (joinOpt < 0)
			{
				sprintf(this->errMsg, "%s is not a valid join option.", cJoinOpt);
				globalErrorInfo.insertProblem(ERR_TYPE_ERROR, __LINE__, 
					"LogicalPlanParser::readPatternTreeNode", __FILE__, 
					this->errMsg);
				this->success = false;
				goto exit;		
			}	

			// construct a selection node. 
			PatternTreeSelectionNode* selectPtNode
				= new PatternTreeSelectionNode(nodeid, -1, 0, NULL, 
											   cFileName,
											   relationWithParent,
											   joinOpt,
											   secondaryNodeType,
											   cond, 
											   eleTag,
											   attrName);	

			// release space for attribute node. 
			if (eleTag != NULL)
				delete [] eleTag;
			if (attrName != NULL)
				delete [] attrName;
	   
			if (selectPtNode == NULL)
			{
				globalErrorInfo.insertProblem(ERR_TYPE_ERROR, __LINE__, 
					"LogicalPlanParser::readPatternTreeNode", __FILE__, 
					"Error happens while creating a new PatternTreeSelectionNode.");
				if (attrName != NULL)
					delete [] attrName;
				delete cond;
				this->success = false;
				goto exit;
			}
			else
			{
				this->ptTreeNodes[index] = selectPtNode;			
			}
		}
		break;
		
	case PATTERN_TREE_REFERENCE_NODE:
		/* 
		 * for pattern tree reference node
		 */
		{
			// read the LCL of the node to be refered. 
			LCLType reference = this->readPtNodeReference();

			// read the relationship to parent and join option. 
			*(this->pTreeStream) >> cRelation >> cJoinOpt; 
			
			if (this->checkEOF())
			{
				this->success = false;
				globalErrorInfo.insertProblem(ERR_TYPE_ERROR, __LINE__, 
					"LogicalPlanParser::readPatternTreeNode", __FILE__, 
					"EOF comes before the end of the logical plan.");
				goto exit;
			}

			// construct a reference node. 
			int relation = this->parseKeyword(cRelation);
			if (relation < 0)
			{
				sprintf(this->errMsg, "%s is not a valid relationship with parent.", cRelation);
				globalErrorInfo.insertProblem(ERR_TYPE_ERROR, __LINE__, 
					"LogicalPlanParser::readPatternTreeNode", __FILE__, 
					this->errMsg);
				this->success = false;
				goto exit;
			}

			int joinOpt = this->parseKeyword(cJoinOpt);
			if (joinOpt < 0)
			{
				sprintf(this->errMsg, "%s is not a valid join option.", cJoinOpt);
				globalErrorInfo.insertProblem(ERR_TYPE_ERROR, __LINE__, 
					"LogicalPlanParser::readPatternTreeNode", __FILE__, 
					this->errMsg);
				this->success = false;
				goto exit;
			}
			
			PatternTreeReferenceNode* refPtNode
				= new PatternTreeReferenceNode(nodeid, -1, 0, NULL, 
											   relation, joinOpt,
											   reference);

			if (refPtNode == NULL)
			{
				globalErrorInfo.insertProblem(ERR_TYPE_ERROR, __LINE__, 
					"LogicalPlanParser::readPatternTreeNode", __FILE__, 
					"Error happens while creating a new PatternTreeReferenceNode.");
				this->success = false;
				goto exit;
			}
			else
			{
				this->ptTreeNodes[index] = refPtNode;					
			}
		}
		break;

	case PATTERN_TREE_VALUEJOIN_NODE:
		/*
		 * for value join node. 
		 */
		{
			char cJoinMode[10];
			int joinMode;
			LCLType leftRef, rightRef;

			// read the join mode (ANY or ONE)
			*(this->pTreeStream) >> cJoinMode;
			if (this->checkEOF()) 
			{
				globalErrorInfo.insertProblem(ERR_TYPE_ERROR, __LINE__, 
					"LogicalPlanParser::readPatternTreeNode", __FILE__, 
					"EOF comes before the end of the logical plan.");
				this->success = false;
				goto exit;				
			}

			joinMode = this->parseKeyword(cJoinMode);
			if (!((joinMode == ANY_JOIN) || (joinMode == ONE_JOIN)))
			{
				sprintf(this->errMsg, "%s is not a valid join mode for value join. It has to be either ANY or ONE.", cJoinMode);
				globalErrorInfo.insertProblem(ERR_TYPE_ERROR, __LINE__, 
					"LogicalPlanParser::readPatternTreeNode", __FILE__, 
					this->errMsg);
				this->success = false;
				goto exit;				
			}

			// read the LCL of the left node
			leftRef = this->readPtNodeReference();			
	
			if (this->checkEOF()) 
			{
				this->success = false;
				globalErrorInfo.insertProblem(ERR_TYPE_ERROR, __LINE__, 
					"LogicalPlanParser::readPatternTreeNode", __FILE__, 
					"EOF comes before the end of the logical plan.");
				goto exit;
			}
	
			// read the operator
			char cOp[100];
			*(this->pTreeStream) >> cOp;
			if (this->checkEOF()) 
			{
				globalErrorInfo.insertProblem(ERR_TYPE_ERROR, __LINE__, 
					"LogicalPlanParser::readPatternTreeNode", __FILE__, 
					"EOF comes before the end of the logical plan.");
				this->success = false;
				goto exit;				
			}

			// dictionary lookup. 
			int optype, op;
			this->parseKeyword(cOp, &optype, &op);
			if (op < 0)
			{
				sprintf(this->errMsg, "%s is not a valid operator.", cOp);
				globalErrorInfo.insertProblem(ERR_TYPE_ERROR, __LINE__, 
					"LogicalPlanParser::readPatternTreeNode", __FILE__, 
					this->errMsg);
				this->success = false;
				goto exit;
			}

			// read the LCL of the right node
			rightRef = this->readPtNodeReference();			
	
			if (this->checkEOF()) 
			{
				this->success = false;
				globalErrorInfo.insertProblem(ERR_TYPE_ERROR, __LINE__, 
					"LogicalPlanParser::readPatternTreeNode", __FILE__, 
					"EOF comes before the end of the logical plan.");
				goto exit;
			}
		
			// construct a value join condtion
			ValueJoinConditionType* valueJoinCond = new ValueJoinConditionType;
			valueJoinCond->leftReference = leftRef;
			valueJoinCond->rightReference = rightRef;
			valueJoinCond->operatorDataType = optype;
			valueJoinCond->operaror = op;
			valueJoinCond->anyJoin = (joinMode == ANY_JOIN);

			// construct a join node. 
			PatternTreeValueJoinNode* valueJoinNode 
				= new PatternTreeValueJoinNode(nodeid, -1, 0, NULL,  valueJoinCond);

			if (valueJoinNode == NULL)
			{
				globalErrorInfo.insertProblem(ERR_TYPE_ERROR, __LINE__, 
					"LogicalPlanParser::readPatternTreeNode", __FILE__, 
					"Error happens while creating a new PatternTreeValueJoinNode.");
				delete valueJoinCond;
				this->success = false;
				goto exit;
				
			}
			else
			{
				this->ptTreeNodes[index] = valueJoinNode;					
			}
		}
		break;

	case PATTERN_TREE_CARTESIAN_NODE:
		// for cartesian product node. 
		{
			// no other input, consturct the pattern tree node. 
			PatternTreeValueJoinNode* valueJoinNode 
				= new PatternTreeValueJoinNode(nodeid, -1, 0, NULL, NULL);

			if (valueJoinNode == NULL)
			{
				globalErrorInfo.insertProblem(ERR_TYPE_ERROR, __LINE__, 
					"LogicalPlanParser::readPatternTreeNode", __FILE__, 
					"Error happens while creating a new PatternTreeValueJoinNode (for cartesian product)." );
				this->success = false;
				goto exit;				
			}
			else
			{
				this->ptTreeNodes[index] = valueJoinNode;					
			}
		}
		break;

	case PATTERN_TREE_MLCAROOT_NODE:
		// for MLCA root node
		{
			// this is a dummy node, no other input. 
			PatternTreeNode* mlcaNode 
				= new PatternTreeNode(nodeid, -1, 0, NULL,  
									  PATTERN_TREE_MLCAROOT_NODE);

			if (mlcaNode == NULL)
			{
				globalErrorInfo.insertProblem(ERR_TYPE_ERROR, __LINE__, 
					"LogicalPlanParser::readPatternTreeNode", __FILE__, 
					"Error happens while creating a new PatternTreeNode (for mlca root).");
				this->success = false;
				goto exit;				
			}
			else
			{
				this->ptTreeNodes[index] = mlcaNode;					
			}
		}
		break;

	case PATTERN_TREE_CONSTRUCT_NODE:
		// for construct node
		{
			// handle different kind of construct node based on secondary node type. 
	
			switch (secondaryNodeType)
			{
			case CONSTRUCT_ELEMENT:
				// construct element node construct an element, given element tag
				{
					// read the element tag
					*(this->pTreeStream) >> cTag;

					if (this->checkEOF()) 
					{
						this->success = false;
						globalErrorInfo.insertProblem(ERR_TYPE_ERROR, __LINE__, 
							"LogicalPlanParser::readPatternTreeNode", __FILE__, 
							"EOF comes before the end of the logical plan.");
						goto exit;
					}
					
					PatternTreeConstructNode* constrPtNode 
						= new PatternTreeConstructNode(nodeid, -1, 0, NULL, 
													   secondaryNodeType, 
													   cTag, -1, -1);
					
					if (constrPtNode == NULL)
					{
						globalErrorInfo.insertProblem(ERR_TYPE_ERROR, __LINE__, 
							"LogicalPlanParser::readPatternTreeNode", __FILE__, 
							"Error happens while creating a new PatternTreeConstructNode.");
						this->success = false;
						goto exit;						
					}
					else 
					{
						this->ptTreeNodes[index] = constrPtNode;		
					}
				}
				break;

			case CONSTRUCT_ATTRIBUTE:
				{			
					/*
					 * a construct attribute node consturct an attribute, given 
					 * the attribute name and the source of the attribute value. 
					 */

					// read the attribute name
					*(this->pTreeStream) >> cTag;

					if (this->checkEOF()) 
					{
						this->success = false;
						globalErrorInfo.insertProblem(ERR_TYPE_ERROR, __LINE__, 
							"LogicalPlanParser::readPatternTreeNode", __FILE__, 
							"EOF comes before the end of the logical plan.");
						goto exit;
					}

					// read the LCL of the node where the attribute value is from. 
					LCLType refnodeid = this->readPtNodeReference();
					if (this->checkEOF()) 
					{
						this->success = false;
						globalErrorInfo.insertProblem(ERR_TYPE_ERROR, __LINE__, 
							"LogicalPlanParser::readPatternTreeNode", __FILE__, 
							"EOF comes before the end of the logical plan.");
						goto exit;
					}

					// build the construct node. 
					PatternTreeConstructNode* constrPtNode 
						= new PatternTreeConstructNode(nodeid, -1, 0, NULL,
													   secondaryNodeType, 
													   cTag, 
													   refnodeid,
													   CONSTRUCT_OPTION_CONTENT);
			
					if (constrPtNode == NULL)
					{					
						globalErrorInfo.insertProblem(ERR_TYPE_ERROR, __LINE__, 
							"LogicalPlanParser::readPatternTreeNode", __FILE__, 
							"Error happens while creating a new PatternTreeConstructNode.");
						this->success = false;
						goto exit;						
					}
					else 
					{
						this->ptTreeNodes[index] = constrPtNode;			
					}
				}
				break;

			case CONSTRUCT_REFERENCE:
				/*
				 * a construct reference node build element content, by providing
				 * the source of the value
				 */

				{			
					// read the LCL of the source. 
					LCLType refnodeid = this->readPtNodeReference();

					if (this->checkEOF())
					{
						this->success = false;
						globalErrorInfo.insertProblem(ERR_TYPE_ERROR, __LINE__, 
							"LogicalPlanParser::readPatternTreeNode", __FILE__, 
							"EOF comes before the end of the logical plan.");
						goto exit;
					}

					// read the construct option. 
					char cConstrOpt[50];
					*(this->pTreeStream) >> cConstrOpt;
					if (this->checkEOF()) 
					{
						this->success = false;
						globalErrorInfo.insertProblem(ERR_TYPE_ERROR, __LINE__, 
							"LogicalPlanParser::readPatternTreeNode", __FILE__, 
							"EOF comes before the end of the logical plan.");
						goto exit;
					}
	
					// build a construct node. 
					int constrOpt = this->parseKeyword(cConstrOpt);
					if (constrOpt < 0)
					{
						sprintf(this->errMsg, "%s is not a valid construction option.", cConstrOpt);
						globalErrorInfo.insertProblem(ERR_TYPE_ERROR, __LINE__, 
							"LogicalPlanParser::readPatternTreeNode", __FILE__, 
							this->errMsg);
						this->success = false;
						goto exit;
					}

					PatternTreeConstructNode* constrPtNode 
						= new PatternTreeConstructNode(nodeid, -1, 0, NULL,
													   secondaryNodeType, 
													   NULL, 
													   refnodeid,
													   constrOpt);
			
					if (constrPtNode == NULL)
					{
						globalErrorInfo.insertProblem(ERR_TYPE_ERROR, __LINE__, 
							"LogicalPlanParser::readPatternTreeNode", __FILE__, 
							"Error happens while creating a new PatternTreeConstructNode.");
						this->success = false;
						goto exit;
					}
					else 
					{
						this->ptTreeNodes[index] = constrPtNode;			
					}
				}
				break;

			}
		}
		break;

	default:
		{
			// syntax error.
			sprintf(this->errMsg, "%s is not a valid keyword for pattern tree node type.", cNodeType);
			globalErrorInfo.insertProblem(ERR_TYPE_ERROR, __LINE__, 
				"LogicalPlanParser::readPatternTreeNode", __FILE__, 
				this->errMsg);
			this->success = false;
			goto exit;
		}
		break;
	}	
	
	bool charRead = this->skipTill('\n');
	if (charRead)
	{		
		globalErrorInfo.insertProblem(ERR_TYPE_ERROR, __LINE__, 
			"LogicalPlanParser::readPatternTreeNode", __FILE__, 
			"There should be no other input on the line after the last meaningful parameter of a pattern tree node.");
		this->success = false;
		goto exit;
	}

exit:
	return this->success;
}

/**
 * Read a pattern tree
 * This method is called from LogicalPlanParser::getProcessTreeFromString
 * which loops through the pattern trees and read them one by one through this method. 
 *
 *@returns A boolean value which indicate whether the reading process is successful. 
 *@see LogicalPlanParser::getProcessTreeFromString.
 */
bool LogicalPlanParser::readPatternTree(int index)
{
	this->success = true;

	// local variables
	TreeIDType treeid;
	int ptnodenum;
	NodeIDType rootid;
	char cPtTreeType[100];

	NodeIDType nodeid;
	NodeIDType parentid;
	PatternTreeNode** ptNodes = NULL;

	/* 
	 * read the tree id, number of nodes in the tree, the id of the 
	 * root node and the pattern tree node type
	 */
	*(this->pTreeStream) >> treeid >> ptnodenum >> rootid >> cPtTreeType;
	bool charRead = this->skipTill('\n');

	if (charRead)
	{		
		sprintf(this->errMsg, "There should be no other input on the line after pattern tree node type, for pattern tree (id=%d).", treeid);
		globalErrorInfo.insertProblem(ERR_TYPE_ERROR, __LINE__, 
			"LogicalPlanParser::readPatternTree", __FILE__, 
			this->errMsg);
		this->success = false;
		goto exit;
	}

	if (ptnodenum < 0)
	{
		this->success = false;
		globalErrorInfo.insertProblem(ERR_TYPE_ERROR, __LINE__, 
			"LogicalPlanParser::readPatternTree", __FILE__, 
			"The number of pattern tree node in a pattern tree can not be less than zero.");
		goto exit;}

	if (this->checkEOF()) 
	{			
		globalErrorInfo.insertProblem(ERR_TYPE_ERROR, __LINE__, 
			"LogicalPlanParser::readPatternTree", __FILE__, 
			"EOF comes before the end of the logical plan.");
		this->success = false;
		goto exit;
	}

	// lookup the pattern tree type in dictionary
	int ptTreeType = this->parseKeyword(cPtTreeType);
	if ((ptTreeType != PATTERN_TREE_NORMAL) &&
		(ptTreeType != PATTERN_TREE_CONSTRUCT_TAGGING) &&
		(ptTreeType != PATTERN_TREE_MLCA))
	{
		sprintf(this->errMsg, "%s is not a valid pattern tree type.", cPtTreeType);
		globalErrorInfo.insertProblem(ERR_TYPE_ERROR, __LINE__, 
			"LogicalPlanParser::readPatternTree", __FILE__, 
			this->errMsg);
		this->success = false;
		goto exit;
	}

	// allocate space for the pattren nodes node list 
	ptNodes = new PatternTreeNode*[ptnodenum];

	// read node one by one. 
	for (int i=0; i<ptnodenum; i++)
	{
		this->skipComment();

		// read the node id and the id of the parent node of the node. 
		*(this->pTreeStream) >> nodeid >> parentid;

		if (this->checkEOF()) 
		{
			globalErrorInfo.insertProblem(ERR_TYPE_ERROR, __LINE__, 
				"LogicalPlanParser::readPatternTree", __FILE__, 
				"EOF comes before the end of the logical plan.");
			this->success = false;
			goto exit;
		}
	
		PatternTreeNode* ptNode = this->findPtTreeNodeWithID(nodeid);
		PatternTreeNode* parentNode = this->findPtTreeNodeWithID(parentid);
		if (ptNode == NULL)
		{
			/*
			 * if the node identified in the tree is not one that has been read
			 * throw an error
			 */
			sprintf(this->errMsg, "Error in pattern tree input: The pattern tree node with id=%d has not been input in pattern tree node list.", nodeid);
			globalErrorInfo.insertProblem(ERR_TYPE_ERROR, __LINE__, 
				"LogicalPlanParser::readPatternTree", __FILE__, 
				this->errMsg);
			this->success = false;
			goto exit;
		}

		else if (parentid == -1)
			// it is OK that parentid is NULL, this means the node is the root. 			
			ptNode->setParentID(parentid);

		else if (parentNode == NULL)
		{
			/*
			* if the node identified as the parent node is not one that has been read
			* throw an error.
			*/
			sprintf(this->errMsg, "Error in pattern tree input: The pattern tree node with id=%d has not been input in pattern tree node list.", nodeid);
			globalErrorInfo.insertProblem(ERR_TYPE_ERROR, __LINE__, 
				"LogicalPlanParser::readPatternTree", __FILE__, 
				this->errMsg);
			this->success = false;
			goto exit;		
		}
		else
			// if the node has a parent, insert it as a child to the parent node. 
			parentNode->insertChild(ptNode);

		ptNodes[i] = ptNode;
		bool charRead = this->skipTill('\n');
		if (charRead)
		{		
			sprintf(this->errMsg, "There should be no other input on the line after the last meaningful parameter describing pattern tree node (id=%d) in the pattern tree.", ptNode->getNodeID());
			globalErrorInfo.insertProblem(ERR_TYPE_ERROR, __LINE__, 
				"LogicalPlanParser::readPatternTree", __FILE__, 
				this->errMsg);
			this->success = false;
			goto exit;
		}	
	}

	// construct a pattern tree. 
	PatternTree* ptTree = new PatternTree(treeid, rootid, ptnodenum, ptNodes, ptTreeType);

	if (ptTree == NULL)
	{
		sprintf(this->errMsg, "Error happens while generating pattern tree (id=%d).", treeid);
		globalErrorInfo.insertProblem(ERR_TYPE_ERROR, __LINE__, 
			"LogicalPlanParser::readPatternTree", __FILE__, 
			this->errMsg);
		this->success = false;
		goto exit;		
	}
	else
	{
		this->ptTrees[index] = ptTree;
	}

exit:
	delete [] ptNodes;
	return this->success;
}

/**
 * Read a process tree node
 * This method is called from LogicalPlanParser::getProcessTreeFromString
 * which loops through the process tree nodes and read them one by one through this method. 
 *
 *@returns A boolean value which indicate whether the reading process is successful. 
 *@see LogicalPlanParser::getProcessTreeFromString.
 */
bool LogicalPlanParser::readProcessTreeNode(int index)
{
	this->success = true;

	// local variables
	ProcessTreeNode* psTreeNode = NULL;

	NodeIDType nodeid = -1;
	char cNodeType[100];

	// read the process tree node id, and the node type
	*(this->pTreeStream) >> nodeid >> cNodeType;
	if (this->checkEOF()) 
	{
		globalErrorInfo.insertProblem(ERR_TYPE_ERROR, __LINE__, 
			"LogicalPlanParser::readProcessTreeNode", __FILE__, 
			"EOF comes before the end of the logical plan.");
		this->success = false;
		goto exit;		
	}
	
	int psTreeNodeType;
	int psTreeNodeType2; // secondary process tree node type

	/*
	 * look up the dictionary, given the nodetype (in string) and
	 * get the primiary and secondary process tree node type (code)
	 */
	this->parseKeyword(cNodeType, &psTreeNodeType, &psTreeNodeType2);
	
	// handle process tree nodes differently based on the primiary node type
	switch (psTreeNodeType)
	{
	case PROCESS_TREE_SELECT_NODE:
		// a selection node, it contains a pattern tree. 
		{
			TreeIDType ptTreeID;

			// read the pattern tree id. 
			*(this->pTreeStream) >> ptTreeID;

			// if the pattern tree is not among the ones that have been read, throw an error.
			
			PatternTree* ptTree = this->findPtTreeWithID(ptTreeID);
			if (ptTree == NULL)
			{
				sprintf(this->errMsg, "The pattern tree associated with the selection node (id=%d) has not been input.", nodeid);
				globalErrorInfo.insertProblem(ERR_TYPE_ERROR, __LINE__, 
					"LogicalPlanParser::readProcessTreeNode", __FILE__, 
					this->errMsg);
				this->success = false;
				goto exit;		
			}

			// construct a selection node. 
			ProcessTreeSelectNode* selectionNode 
				= new ProcessTreeSelectNode(nodeid, -1, 0, NULL, ptTree);

			if (selectionNode == NULL)
			{
				this->success = false;
				goto exit;		
			}
			psTreeNode = selectionNode;
		}
		break;

	case PROCESS_TREE_CONSTRUCT_NODE:
		// construct node, it contains a construct pattern tree. 
		{
			TreeIDType ptTreeID;

			// read the pattern tree id.
			*(this->pTreeStream) >> ptTreeID;

			// if the pattern tree is not among the ones that have been read, throw an error. 
			PatternTree* ptTree = this->findPtTreeWithID(ptTreeID);
			if (ptTree == NULL)
			{
				sprintf(this->errMsg, "The pattern tree associated with the selection node (id=%d) has not been input.", nodeid);
				globalErrorInfo.insertProblem(ERR_TYPE_ERROR, __LINE__, 
					"LogicalPlanParser::readProcessTreeNode", __FILE__, 
					this->errMsg);
				this->success = false;
				goto exit;		
			}

			// the pattern tree in the construct node has to be of type
			// PATTERN_TREE_CONSTRUCT_TAGGING
			if (ptTree->getPatternTreeType() != PATTERN_TREE_CONSTRUCT_TAGGING) 
			{
				sprintf(this->errMsg, "The pattern tree (id=%d) associated with the construct node (id=%d) is not of type PATTERN_TREE_CONSTRUCT.",
					ptTreeID, nodeid);				
				globalErrorInfo.insertProblem(ERR_TYPE_ERROR, __LINE__, 
					"LogicalPlanParser::readProcessTreeNode", __FILE__, 
					this->errMsg);

				this->success = false;
				goto exit;		
			}

			// build a construct node. 
			ProcessTreeConstructNode* constructNode 
				= new ProcessTreeConstructNode(nodeid, -1, 0, NULL, ptTree);

			if (constructNode == NULL)
			{
				globalErrorInfo.insertProblem(ERR_TYPE_ERROR, __LINE__, 
					"LogicalPlanParser::readProcessTreeNode", __FILE__, 
					"Error reported when creating a process tree construct node.");
				this->success = false;
				goto exit;		
			}
			psTreeNode = constructNode;
		}
		break;
		
	case PROCESS_TREE_PROJECT_NODE:
		// projection node, it specifies the nodes to be kept after projection
		{
			int nodenum;

			// read the number of projection node. 
			*(this->pTreeStream) >> nodenum;

			if (nodenum < 0)
			{
				this->success = false;
				globalErrorInfo.insertProblem(ERR_TYPE_ERROR, __LINE__, 
					"LogicalPlanParser::readProcessTree", __FILE__, 
					"The number of projection node can not be less than zero.");
				goto exit;
			}

			if (this->checkEOF()) 
			{
				globalErrorInfo.insertProblem(ERR_TYPE_ERROR, __LINE__, 
					"LogicalPlanParser::readProcessTreeNode", __FILE__, 
					"EOF comes before the end of the logical plan.");
				this->success = false;
				goto exit;		
			}

			// read the LCL of the projection nodes one by one. 
			LCLType* projLCLs = new LCLType[nodenum];
			for (int i=0; i<nodenum; i++)
			{
				*(this->pTreeStream) >> projLCLs[i];
				if (this->checkEOF())
				{
					globalErrorInfo.insertProblem(ERR_TYPE_ERROR, __LINE__, 
						"LogicalPlanParser::readProcessTreeNode", __FILE__, 
						"EOF comes before the end of the logical plan.");
					this->success = false;
					goto exit;		
				}
			}

			// build a projection node. 
			ProcessTreeProjectNode* projNode
				= new ProcessTreeProjectNode(nodeid, -1, 0, NULL, 
										     nodenum, projLCLs);
			delete [] projLCLs;
			if (projNode == NULL)
			{								
				globalErrorInfo.insertProblem(ERR_TYPE_ERROR, __LINE__, 
					"LogicalPlanParser::readProcessTreeNode", __FILE__, 
					"Error reported when creating a new instance of a projection node.");
				this->success = false;
				goto exit;		
			}
			psTreeNode = projNode;
		}
		break;

	case PROCESS_TREE_JOIN_NODE:
		// join node, both join node and cartesian project node map to this. 
		// it contains a seleciton pattern tree. 
		{
			TreeIDType ptTreeID;

			// read the pattern tree id. 
			*(this->pTreeStream) >> ptTreeID;

			// if the pattern tree is not among the ones that have been read, throw an error. 

			PatternTree* ptTree = this->findPtTreeWithID(ptTreeID);
			if (ptTree == NULL)
			{
				sprintf(this->errMsg, " The pattern tree associated with the join node (id=%d) has not been input.", nodeid);				
				globalErrorInfo.insertProblem(ERR_TYPE_ERROR, __LINE__, 
					"LogicalPlanParser::readProcessTreeNode", __FILE__, 
					this->errMsg);
				this->success = false;
				goto exit;						
			}
			ProcessTreeJoinNode* joinNode 
				= new ProcessTreeJoinNode(nodeid, -1, 0, NULL, ptTree);

			if (joinNode == NULL)
			{
				globalErrorInfo.insertProblem(ERR_TYPE_ERROR, __LINE__, 
					"LogicalPlanParser::readProcessTreeNode", __FILE__, 
					"Error reported when creating a process tree join node.");
				this->success = false;
				goto exit;		
			}
			psTreeNode = joinNode;
		}
		break;

	case PROCESS_TREE_DUPLICATE_ELIMINATION_NODE:
		// duplicate elimination node, it specifies the dupilicate elimination based (node set). 
		{
			char cOpt[100];

			// read the option (on ID or on value)
			*(this->pTreeStream) >> cOpt ;
			if (this->checkEOF()) 
			{
				globalErrorInfo.insertProblem(ERR_TYPE_ERROR, __LINE__, 
					"LogicalPlanParser::readProcessTreeNode", __FILE__, 
					"EOF comes before the end of the logical plan.");
				this->success = false;
				goto exit;		
			}

			// dictionary look up
			int deopt = this->parseKeyword(cOpt);
			if (deopt < 0)
			{
				sprintf(this->errMsg, "%s is not a valid duplicate elimination option.", cOpt);
				globalErrorInfo.insertProblem(ERR_TYPE_ERROR, __LINE__, 
					"LogicalPlanParser::readProcessTreeNode", __FILE__, 
					this->errMsg);
				this->success = false;
				goto exit;		
			}
			
			// read the node to LCL of the duplicate elimination base. 
			LCLType lcl = this->readPtNodeReference();
			if (this->checkEOF()) 
			{
				globalErrorInfo.insertProblem(ERR_TYPE_ERROR, __LINE__, 
					"LogicalPlanParser::readProcessTreeNode", __FILE__, 
					"EOF comes before the end of the logical plan.");
				this->success = false;
				goto exit;		
			}

			ProcessTreeDuplicateEliminationNode* deNode
				= new ProcessTreeDuplicateEliminationNode(nodeid, -1, 0, NULL,deopt,lcl);
			if (deNode == NULL)
			{								
				globalErrorInfo.insertProblem(ERR_TYPE_ERROR, __LINE__, 
					"LogicalPlanParser::readProcessTreeNode", __FILE__, 
					"Error reported when creating a process tree duplicate elimination node.");
				this->success = false;
				goto exit;		
			}
			psTreeNode = deNode;
		}
		break;

	case PROCESS_TREE_AGGREGATE_FUNCTION_NODE:
		// aggregate function node. it specify the operation, the operand and result node.
		{
			char cAggrFunc[100];

			// read the name of the aggregate function
			*(this->pTreeStream) >> cAggrFunc;
			if (this->checkEOF())
			{
				globalErrorInfo.insertProblem(ERR_TYPE_ERROR, __LINE__, 
					"LogicalPlanParser::readProcessTreeNode", __FILE__, 
					"EOF comes before the end of the logical plan.");
				this->success = false;
				goto exit;		
			}

			// dictionary lookup
			int aggrFunc = this->parseKeyword(cAggrFunc);
			if (aggrFunc < 0)
			{
				sprintf(this->errMsg, "%s is not a valid aggregate function.", cAggrFunc);
				globalErrorInfo.insertProblem(ERR_TYPE_ERROR, __LINE__, 
					"LogicalPlanParser::readProcessTreeNode", __FILE__, 
					this->errMsg);
				this->success = false;
				goto exit;		
			}

			// read the LCL of the operand
			LCLType operand = this->readPtNodeReference();
			if (this->checkEOF())
			{
				globalErrorInfo.insertProblem(ERR_TYPE_ERROR, __LINE__, 
					"LogicalPlanParser::readProcessTreeNode", __FILE__, 
					"EOF comes before the end of the logical plan.");
				this->success = false;
				goto exit;		
			}

			LCLType resultLCL;
			char resultnodetag[MAX_NODETAG_LENGTH];

			// read the result node LCL and result node tag. 
			*(this->pTreeStream) >> resultLCL >> resultnodetag;

			if (this->checkEOF()) 
			{
				globalErrorInfo.insertProblem(ERR_TYPE_ERROR, __LINE__, 
					"LogicalPlanParser::readProcessTreeNode", __FILE__, 
					"EOF comes before the end of the logical plan.");
				this->success = false;
				goto exit;		
			}
	
			ProcessTreeAggregateFunctionNode* funcNode 
				= new ProcessTreeAggregateFunctionNode(nodeid, -1, 0, NULL, 
													   aggrFunc, operand, 
													   resultLCL, 
													   resultnodetag);

			if (funcNode == NULL)
			{
				globalErrorInfo.insertProblem(ERR_TYPE_ERROR, __LINE__, 
					"LogicalPlanParser::readProcessTreeNode", __FILE__, 
					"Error reported when creating a process tree aggregate function node.");
				this->success = false;
				goto exit;		
			}

			psTreeNode = funcNode;
		}
		break;


	case PROCESS_TREE_FILTER_NODE:
		// filter node, it specifies filter condition
		{
			int orNum;
			int* andNums;
			PO_FilterPredicate*** filterCond;

			switch (psTreeNodeType2)
			{
			case SIMPLE_FILTER:
				// it is a simple filter (only one predicate)
				{
					orNum = 1;
					andNums = new int[1];
					andNums[0] = 1;

					// read only one predicate
					filterCond = new PO_FilterPredicate**[1];
					filterCond[0] = new PO_FilterPredicate*[1];
					filterCond[0][0] = this->readFilterPredicate();
					if (filterCond[0][0] == NULL)
					{
						this->success = false;
						globalErrorInfo.insertProblem(ERR_TYPE_ERROR, __LINE__, 
							"LogicalPlanParser::readProcessTreeNode", __FILE__, 
							"Error reported file reading filter predicate.");
						goto exit;
					}
				}
				break;

			case OR_FILTER:
				// it is a disjunctive expression
				{
					*(this->pTreeStream) >> orNum;
					if (orNum < 0)
					{
						this->success = false;
						globalErrorInfo.insertProblem(ERR_TYPE_ERROR, __LINE__, 
							"LogicalPlanParser::readProcessTreeNode", __FILE__, 
							"The Or number in a filter node can not be less than zero.");
						goto exit;
					}
					andNums = new int[orNum];
					filterCond = new PO_FilterPredicate**[orNum];

					// read predicate one by one. 
					for (int i=0; i<orNum; i++)
					{
						andNums[i] = 1;
						filterCond[i] = new PO_FilterPredicate*[1];
						filterCond[i][0] = this->readFilterPredicate();
						if (filterCond[i][0] == NULL)
						{
							this->success = false;											
							globalErrorInfo.insertProblem(ERR_TYPE_ERROR, __LINE__, 
								"LogicalPlanParser::readProcessTreeNode", __FILE__, 
								"Error reported file reading filter predicate.");
							goto exit;
						}
					}
				}
				break;

			default: 
				// the secondary type is not a valid one
				sprintf(this->errMsg, "%s is not a valid Filter node keyword.", cNodeType);
				globalErrorInfo.insertProblem(ERR_TYPE_ERROR, __LINE__, 
					"LogicalPlanParser::readProcessTreeNode", __FILE__, 
					this->errMsg);
				this->success = false;
				goto exit;

			}
			ProcessTreeFilterNode* filterNode 
				= new ProcessTreeFilterNode(nodeid, -1, 0, NULL, 
											orNum, andNums, filterCond);

			if (filterNode == NULL)
			{
				for (int i=0; i<orNum; i++)
				{
					for (int j=0; j<andNums[i]; j++)
						delete filterCond[i][j];
					delete [] filterCond[i];
				}
				delete [] filterCond;
				delete [] andNums;

				globalErrorInfo.insertProblem(ERR_TYPE_ERROR, __LINE__, 
					"LogicalPlanParser::readProcessTreeNode", __FILE__, 
					"Error reported when creating a process tree filter node.");
				this->success = false;
				goto exit;		
			}

			psTreeNode = filterNode;
		}
		break;

	case PROCESS_TREE_SORT_NODE:
		// sort node, it specifies the sort keys. 
		{
			int sortbyNodeNum;

			// get the number of sortby nodes in the sortkey. 
			*(this->pTreeStream) >> sortbyNodeNum;
			if (sortbyNodeNum < 0)
			{
				globalErrorInfo.insertProblem(ERR_TYPE_ERROR, __LINE__, 
					"LogicalPlanParser::readProcessTreeNode", __FILE__, 
					"The number of sortby node can not be less than zero.");
				this->success = false;
				goto exit;		
			}

			if (this->checkEOF()) 
			{
				globalErrorInfo.insertProblem(ERR_TYPE_ERROR, __LINE__, 
					"LogicalPlanParser::readProcessTreeNode", __FILE__, 
					"EOF comes before the end of the logical plan.");
				this->success = false;
				goto exit;		
			}

			// read sortby node one by one
			OrderbyNode** sortbyNodes = new OrderbyNode*[sortbyNodeNum];
			for (int i=0; i< sortbyNodeNum; i++)
			{
				sortbyNodes[i] = new OrderbyNode();

				// the LCL of the sortby node
				sortbyNodes[i]->orderbyLCL = this->readPtNodeReference();
				if (this->checkEOF()) 
				{
					this->success = false;
					globalErrorInfo.insertProblem(ERR_TYPE_ERROR, __LINE__, 
						"LogicalPlanParser::readProcessTreeNode", __FILE__, 
						"EOF comes before the end of the logical plan.");
					goto exit;
				}

				char cSortbyOpt[100];
				char cSortOrder[100];
				char cSortNullOpt[100];

				// read sort option, ordering and special option for dealing with NULL. 
				*(this->pTreeStream) >> cSortbyOpt >> cSortOrder >> cSortNullOpt;
				if (this->checkEOF())
				{
					this->success = false;
					globalErrorInfo.insertProblem(ERR_TYPE_ERROR, __LINE__, 
						"LogicalPlanParser::readProcessTreeNode", __FILE__, 
						"EOF comes before the end of the logical plan.");
					goto exit;
				}

				// dictionary lookup
				sortbyNodes[i]->orderbyOption = this->parseKeyword(cSortbyOpt);
				if (sortbyNodes[i]->orderbyOption < 0)
				{
					sprintf(this->errMsg, "%s is not a valid sortby option.", cSortbyOpt);
					globalErrorInfo.insertProblem(ERR_TYPE_ERROR, __LINE__, 
						"LogicalPlanParser::readProcessTreeNode", __FILE__, 
						this->errMsg);
					this->success = false;
					goto exit;		
				}

				sortbyNodes[i]->orderSpec = this->parseKeyword(cSortOrder);
				if (sortbyNodes[i]->orderSpec < 0)
				{
					sprintf(this->errMsg, "%s is not a valid sort order.", cSortOrder);
					globalErrorInfo.insertProblem(ERR_TYPE_ERROR, __LINE__, 
						"LogicalPlanParser::readProcessTreeNode", __FILE__, 
						this->errMsg);
					this->success = false;
					goto exit;		
				}

				sortbyNodes[i]->nullOption = this->parseKeyword(cSortNullOpt);
				if (!((sortbyNodes[i]->nullOption == ORDER_NULL_GREATEST)
					|| (sortbyNodes[i]->nullOption == ORDER_NULL_LEAST)))
				{
					sprintf(this->errMsg, "%s is not a valid option for the placement of empty value.", cSortNullOpt);
					globalErrorInfo.insertProblem(ERR_TYPE_ERROR, __LINE__, 
						"LogicalPlanParser::readProcessTreeNode", __FILE__, 
						this->errMsg);
					this->success = false;
					goto exit;		
				}	
			}

			// build sortkey
			OrderKey* sortbyKey = new OrderKey(sortbyNodeNum, sortbyNodes);

			// build a sort node
			ProcessTreeSortNode* sortNode 
				= new ProcessTreeSortNode(nodeid, -1, 0, NULL, sortbyKey);

			if (sortNode == NULL)
			{
				delete sortbyKey;
				globalErrorInfo.insertProblem(ERR_TYPE_ERROR, __LINE__, 
					"LogicalPlanParser::readProcessTreeNode", __FILE__, 
					"Error reported while creating a new instance of ProcessTreeSortNode.");
				this->success = false;
				goto exit;		
			}

			psTreeNode = sortNode;
		}
		break;

	case PROCESS_TREE_MLCA_NODE:
		// MLCA node, it takes a pattern tree and specify a list of node
		// whose MLCA is to be computed. 
		{
			TreeIDType ptTreeID;
			int MLCANodeNum;
			LCLType* MLCANodes;

			// read the pattern tree id. 
			*(this->pTreeStream) >> ptTreeID;							
			if (this->checkEOF()) 
			{
				globalErrorInfo.insertProblem(ERR_TYPE_ERROR, __LINE__, 
					"LogicalPlanParser::readProcessTreeNode", __FILE__, 
					"EOF comes before the end of the logical plan.");
				this->success = false;
				goto exit;		
			}

			// if the pattern tree is not among the ones that have been read in, throw an error. 
			PatternTree* ptTree = this->findPtTreeWithID(ptTreeID);
			if (ptTree == NULL)
			{
				sprintf(this->errMsg, "The pattern tree associated with the selection node (id=%d) has not been input.", nodeid);
				globalErrorInfo.insertProblem(ERR_TYPE_ERROR, __LINE__, 
					"LogicalPlanParser::readProcessTreeNode", __FILE__, 
					this->errMsg);
				this->success = false;
				goto exit;		
			}

			// read the number of MLCA nodes
			*(this->pTreeStream) >> MLCANodeNum;
			if (MLCANodeNum < 0)
			{
				globalErrorInfo.insertProblem(ERR_TYPE_ERROR, __LINE__, 
					"LogicalPlanParser::readProcessTreeNode", __FILE__, 
					"The number of MLCA nodes can not be less than zero.");
				this->success = false;
				goto exit;		
			}

			if (this->checkEOF())
			{
				globalErrorInfo.insertProblem(ERR_TYPE_ERROR, __LINE__, 
					"LogicalPlanParser::readProcessTreeNode", __FILE__, 
					"EOF comes before the end of the logical plan.");
				this->success = false;
				goto exit;		
			}

			// ATTENTION: the interface for logical plan counts the root as mlca node, 
			// remove it here
			MLCANodeNum--;

			LCLType MLCARoot; 
			*(this->pTreeStream) >> MLCARoot;
			if (this->checkEOF()) 
			{
				this->success = false;
				globalErrorInfo.insertProblem(ERR_TYPE_ERROR, __LINE__, 
					"LogicalPlanParser::readProcessTreeNode", __FILE__, 
					"EOF comes before the end of the logical plan.");
				goto exit;
			}

			// read the LCL of the MLCA nodes one by one. 
			MLCANodes = new LCLType[MLCANodeNum];
			for (int i=0; i< MLCANodeNum; i++)
			{
				*(this->pTreeStream) >> MLCANodes[i];
				if (this->checkEOF())
				{
					globalErrorInfo.insertProblem(ERR_TYPE_ERROR, __LINE__, 
						"LogicalPlanParser::readProcessTreeNode", __FILE__, 
						"EOF comes before the end of the logical plan.");
					this->success = false;
					goto exit;		
				}
			}

			// build a MLCA node
			ProcessTreeMLCANode* MLCANode 
				= new ProcessTreeMLCANode(nodeid, -1, 0, NULL, 
										  ptTree,
										  MLCARoot,
										  MLCANodeNum,
										  MLCANodes);
			delete MLCANodes;

			if (MLCANode == NULL)
			{
				globalErrorInfo.insertProblem(ERR_TYPE_ERROR, __LINE__, 
					"LogicalPlanParser::readProcessTreeNode", __FILE__, 
					"Error reported when creating a process tree MLCA node.");
				this->success = false;
				goto exit;		
			}
			psTreeNode = MLCANode;
		}
		break;

	case PROCESS_TREE_INSERT_NODE:
		// for insert node. this node specify the position to insert and what to insert.
		{
			// read the position (LCL of the parent node) to insert
			LCLType parentLCL = this->readPtNodeReference();
			if (this->checkEOF()) 
			{
				globalErrorInfo.insertProblem(ERR_TYPE_ERROR, __LINE__, 
					"LogicalPlanParser::readProcessTreeNode", __FILE__, 
					"EOF comes before the end of the logical plan.");
				this->success = false;
				goto exit;		
			}

			char* filename = NULL;
			InsertValueUnit* elementVal = NULL;
			int attrNum = 0;
			InsertValueUnit** attrs = NULL;

			// the secondary node type here is the insert option. 
			int insertOpt = psTreeNodeType2;
			switch (insertOpt)
			{
			case INSERT_ELEMENT:
				// insert an element
				{
					char cTag[MAX_NODETAG_LENGTH];

					// the element tag of the new element to be inserted
					*(this->pTreeStream) >> cTag;
					if (this->checkEOF()) 
					{
						globalErrorInfo.insertProblem(ERR_TYPE_ERROR, __LINE__, 
							"LogicalPlanParser::readProcessTreeNode", __FILE__, 
							"EOF comes before the end of the logical plan.");
						this->success = false;
						goto insert_exit;		
					}


					// option for the source of the value
					char cOpt[100];
					*(this->pTreeStream) >> cOpt ;
					if (this->checkEOF()) 
					{
						globalErrorInfo.insertProblem(ERR_TYPE_ERROR, __LINE__, 
							"LogicalPlanParser::readProcessTreeNode", __FILE__, 
							"EOF comes before the end of the logical plan.");
						this->success = false;
						goto insert_exit;		
					}

					// construct the insert unit. 
					elementVal = new InsertValueUnit;
					elementVal->name = new char[strlen(cTag) +1];
					strcpy(elementVal->name, cTag);

					// interpret the cOpt as the value source. 
					elementVal->valueSource = this->parseKeyword(cOpt);

					switch (elementVal->valueSource)
					{
					case REFERENCE_VALUE:
						// the element content comes from a reference
						elementVal->LCL = this->readPtNodeReference();
						elementVal->constValue = NULL;
						break;

					case CONSTANT_VALUE:
						// the element content is a constant value
						elementVal->LCL = -1;
						elementVal->constValue = this->readRightValue(true);
						break;

					default:
						sprintf(this->errMsg, "%s is not a valid insert value option.", cOpt);
						globalErrorInfo.insertProblem(ERR_TYPE_ERROR, __LINE__, 
							"LogicalPlanParser::readProcessTreeNode", __FILE__, 
							this->errMsg);
						this->success = false;
						goto insert_exit;						
					}
					
					if (this->checkEOF()) 
					{
						globalErrorInfo.insertProblem(ERR_TYPE_ERROR, __LINE__, 
							"LogicalPlanParser::readProcessTreeNode", __FILE__, 
							"EOF comes before the end of the logical plan.");
						this->success = false;
						goto insert_exit;		
					}

					// read the number of attribute of the element node to insert
					*(this->pTreeStream) >> attrNum;
					if (attrNum < 0)
					{
						globalErrorInfo.insertProblem(ERR_TYPE_ERROR, __LINE__, 
							"LogicalPlanParser::readProcessTreeNode", __FILE__, 
							"The attribute number can not be less than zero.");
						this->success = false;
						goto insert_exit;		
					}

					if (this->checkEOF()) 
					{
						globalErrorInfo.insertProblem(ERR_TYPE_ERROR, __LINE__, 
							"LogicalPlanParser::readProcessTreeNode", __FILE__, 
							"EOF comes before the end of the logical plan.");
						this->success = false;
						goto insert_exit;		
					}

					// read attribute one by one
					if (attrNum == 0)
						attrs = NULL;
					else 
						attrs = new InsertValueUnit*[attrNum];

					for (int i=0; i<attrNum; i++)
					{
						attrs[i] = new InsertValueUnit;
						string attrName;

						// attribute name
						*(this->pTreeStream) >> attrName;											
						if (this->checkEOF()) 
						{
						globalErrorInfo.insertProblem(ERR_TYPE_ERROR, __LINE__, 
							"LogicalPlanParser::readProcessTreeNode", __FILE__, 
							"EOF comes before the end of the logical plan.");
							this->success = false;
							goto insert_exit;		
						}

						attrs[i]->name = new char[strlen(attrName.c_str())+1];
						strcpy(attrs[i]->name, attrName.c_str());

						// value source for attribute value
						*(this->pTreeStream) >> cOpt ;
						if (this->checkEOF())
						{
							globalErrorInfo.insertProblem(ERR_TYPE_ERROR, __LINE__, 
								"LogicalPlanParser::readProcessTreeNode", __FILE__, 
								"EOF comes before the end of the logical plan.");
							this->success = false;
							goto insert_exit;		
						}

						attrs[i]->valueSource = this->parseKeyword(cOpt);

						switch (attrs[i]->valueSource)
						{
						case REFERENCE_VALUE:
							attrs[i]->LCL = this->readPtNodeReference();
							attrs[i]->constValue = NULL;
							break;

						case CONSTANT_VALUE:
							attrs[i]->LCL = -1;
							attrs[i]->constValue = this->readRightValue(true);
							break;

						default:
							sprintf(this->errMsg, "%s is not a valid insert value option.", cOpt);
							globalErrorInfo.insertProblem(ERR_TYPE_ERROR, __LINE__, 
								"LogicalPlanParser::readProcessTreeNode", __FILE__, 
								this->errMsg);
							this->success = false;
							goto insert_exit;		
						}

						if (this->checkEOF()) 
						{
							this->success = false;
							globalErrorInfo.insertProblem(ERR_TYPE_ERROR, __LINE__, 
								"LogicalPlanParser::readProcessTreeNode", __FILE__, 
								"EOF comes before the end of the logical plan.");
							goto insert_exit;		
						}
					}

					filename = NULL;
				}
				break;

			case INSERT_ATTRIBUTE:
				{
					attrNum = 1;
					attrs = new InsertValueUnit*[1];
					attrs[0] = new InsertValueUnit;
					//char attrName[MAX_ATTRIBUTE_NAME_LENGTH];
					string attrName;

					// attribute name
					*(this->pTreeStream) >> attrName;											
					if (this->checkEOF()) 
					{
					globalErrorInfo.insertProblem(ERR_TYPE_ERROR, __LINE__, 
						"LogicalPlanParser::readProcessTreeNode", __FILE__, 
						"EOF comes before the end of the logical plan.");
						this->success = false;
						goto insert_exit;		
					}

					attrs[0]->name = new char[strlen(attrName.c_str())+1];
					strcpy(attrs[0]->name, attrName.c_str());

					// value source for attribute value
					char cOpt[100];
					*(this->pTreeStream) >> cOpt ;
					if (this->checkEOF())
					{
						globalErrorInfo.insertProblem(ERR_TYPE_ERROR, __LINE__, 
							"LogicalPlanParser::readProcessTreeNode", __FILE__, 
							"EOF comes before the end of the logical plan.");
						this->success = false;
						goto insert_exit;		
					}

					attrs[0]->valueSource = this->parseKeyword(cOpt);

					switch (attrs[0]->valueSource)
					{
					case REFERENCE_VALUE:
						attrs[0]->LCL = this->readPtNodeReference();
						attrs[0]->constValue = NULL;
						break;

					case CONSTANT_VALUE:
						attrs[0]->LCL = -1;
						attrs[0]->constValue = this->readRightValue(true);
						break;

					default:
						sprintf(this->errMsg, "%s is not a valid insert value option.", cOpt);
						globalErrorInfo.insertProblem(ERR_TYPE_ERROR, __LINE__, 
							"LogicalPlanParser::readProcessTreeNode", __FILE__, 
							this->errMsg);
						this->success = false;
						goto insert_exit;		
					}

					if (this->checkEOF()) 
					{
						this->success = false;
						globalErrorInfo.insertProblem(ERR_TYPE_ERROR, __LINE__, 
							"LogicalPlanParser::readProcessTreeNode", __FILE__, 
							"EOF comes before the end of the logical plan.");
						goto insert_exit;		
					}
	
					filename = NULL;
				}
				break;

			case INSERT_FILE:
				// insert an XML document
				{
					filename = this->readbetween('"', '"');
					if (this->checkEOF()) 
					{
						globalErrorInfo.insertProblem(ERR_TYPE_ERROR, __LINE__, 
							"LogicalPlanParser::readProcessTreeNode", __FILE__, 
							"EOF comes before the end of the logical plan.");
						this->success = false;
						goto insert_exit;		
					}

					elementVal = NULL;
					attrNum = 0;
					attrs = NULL;
				}
				break;

			default: 
				sprintf(this->errMsg, "%s is not a valid insert option.", cNodeType);
				globalErrorInfo.insertProblem(ERR_TYPE_ERROR, __LINE__, 
					"LogicalPlanParser::readProcessTreeNode", __FILE__, 
					this->errMsg);
				this->success = false;
				goto insert_exit;		
			}

			// build a insertNode
			ProcessTreeInsertNode* insertNode
				= new ProcessTreeInsertNode(nodeid, -1, 0, NULL,
											parentLCL, insertOpt, 
											filename, elementVal, 
											attrNum, attrs);
			delete [] filename;

			if (insertNode == NULL)
			{
				globalErrorInfo.insertProblem(ERR_TYPE_ERROR, __LINE__, 
					"LogicalPlanParser::readProcessTreeNode", __FILE__, 
					"Error reported when creating a process tree insert node.");
				this->success = false;
				goto insert_exit;		
			}

			psTreeNode = insertNode;			

insert_exit:
			if (!success)
			{
				// if the reading of the INSERT_NODE does not go well, 
				// release the space allocated on the way. 
				if (filename != NULL)
					delete [] filename;
				if (elementVal != NULL)
					delete elementVal;
				if (attrs != NULL)
				{
					for (int i=0; i<attrNum; i++)
						delete attrs[i];
					delete [] attrs;
				}
				goto exit;
			}
		}
		break;

	case PROCESS_TREE_DELETE_NODE:
		// for delete node, it specify which node to delete and how to delete (content or subtree). 
		{
			// the LCL of the node to delete
			LCLType lcl = this->readPtNodeReference();
			if (this->checkEOF()) 
			{
				globalErrorInfo.insertProblem(ERR_TYPE_ERROR, __LINE__, 
					"LogicalPlanParser::readProcessTreeNode", __FILE__, 
					"EOF comes before the end of the logical plan.");
				this->success = false;
				goto exit;		
			}

			// delete option
			char cOpt[100];
			*(this->pTreeStream) >> cOpt ;
			if (this->checkEOF()) 
			{
				globalErrorInfo.insertProblem(ERR_TYPE_ERROR, __LINE__, 
					"LogicalPlanParser::readProcessTreeNode", __FILE__, 
					"EOF comes before the end of the logical plan.");
				this->success = false;
				goto exit;		
			}

			// dictionary lookup for the option. 
			int deleteOpt = this->parseKeyword(cOpt);
			if (deleteOpt < 0)
			{
				sprintf(this->errMsg, "%s is not a valid delete option.", cOpt);				
				globalErrorInfo.insertProblem(ERR_TYPE_ERROR, __LINE__, 
					"LogicalPlanParser::readProcessTreeNode", __FILE__, 
					this->errMsg);
				this->success = false;
				goto exit;		
			}
			
			// build a delete node
			ProcessTreeDeleteNode* deleteNode
				= new ProcessTreeDeleteNode(nodeid, -1, 0, NULL,lcl, deleteOpt);

			if (deleteNode == NULL)
			{
				globalErrorInfo.insertProblem(ERR_TYPE_ERROR, __LINE__, 
					"LogicalPlanParser::readProcessTreeNode", __FILE__, 
					"Error reported when creating a process tree delete node.");
				this->success = false;
				goto exit;		
			}

			psTreeNode = deleteNode;
		}
		break;

	case PROCESS_TREE_UPDATE_NODE:
		// for update node. it specifies which node to update, and the new value. 
		{
			// the LCL of the node to update. 
			LCLType targetLCL = this->readPtNodeReference();
			if (this->checkEOF()) 
			{
				globalErrorInfo.insertProblem(ERR_TYPE_ERROR, __LINE__, 
					"LogicalPlanParser::readProcessTreeNode", __FILE__, 
					"EOF comes before the end of the logical plan.");
				this->success = false;
				goto exit;		
			}

			// the update option is interpreted as the value source for the new value. 
			char cOpt[100];
			*(this->pTreeStream) >> cOpt ;
			if (this->checkEOF()) 
			{
				globalErrorInfo.insertProblem(ERR_TYPE_ERROR, __LINE__, 
					"LogicalPlanParser::readProcessTreeNode", __FILE__, 
					"EOF comes before the end of the logical plan.");
				this->success = false;
				goto exit;
			}

			// dictionary lookup
			int updateOpt = this->parseKeyword(cOpt);
			if (updateOpt < 0)
			{
				sprintf(this->errMsg, "%s is not a valid delete option.", cOpt);
				globalErrorInfo.insertProblem(ERR_TYPE_ERROR, __LINE__, 
					"LogicalPlanParser::readProcessTreeNode", __FILE__, 
					this->errMsg);
				this->success = false;
				goto exit;						
			}
			
			LCLType referedLCL;
			Value* value;
			switch (updateOpt)
			{
			case CONSTANT_VALUE: 
				referedLCL = -1;
				value = this->readRightValue(true);
				break;
			case REFERENCE_VALUE:
				referedLCL = this->readPtNodeReference();
				value = NULL;
				break;
			default: 
				this->success = false;
				sprintf(this->errMsg, "%s is not a valid update option.", cOpt);
				globalErrorInfo.insertProblem(ERR_TYPE_ERROR, __LINE__, 
					"LogicalPlanParser::readProcessTreeNode", __FILE__, 
					this->errMsg);
				goto exit;
			}

			// build an update node. 
			ProcessTreeUpdateNode* updateNode
				= new ProcessTreeUpdateNode(nodeid, -1, 0, NULL,
											targetLCL, updateOpt,
											referedLCL, value);

			if (updateNode == NULL)
			{
				globalErrorInfo.insertProblem(ERR_TYPE_ERROR, __LINE__, 
					"LogicalPlanParser::readProcessTreeNode", __FILE__, 
					"Error reported when creating a process tree update node.");
				this->success = false;
				goto exit;		
			}

			psTreeNode = updateNode;
		}
		break;

	default:
		sprintf(this->errMsg, "%s is not a valid process tree node type.", cNodeType);
		globalErrorInfo.insertProblem(ERR_TYPE_ERROR, __LINE__, 
			"LogicalPlanParser::readProcessTreeNode", __FILE__,
			this->errMsg);
		this->success = false;
		goto exit;		
	}

	if (!this->success)
	{
		globalErrorInfo.insertProblem(ERR_TYPE_ERROR, __LINE__, 
			"LogicalPlanParser::readProcessTreeNode", __FILE__, 
			"Error happens while creating process tree node.");
	}
	else 
	{
		this->psTreeNodes[index] = psTreeNode;
	}

	bool charRead = this->skipTill('\n');
	if (charRead)
	{		
		sprintf(this->errMsg, "There should be no other input on the line for process tree node (id=%d).", psTreeNode->getNodeID());
		globalErrorInfo.insertProblem(ERR_TYPE_ERROR, __LINE__, 
			"LogicalPlanParser::readProcessTreeNode", __FILE__, 
			this->errMsg);
		this->success = false;
		goto exit;
	}

exit: 
	return this->success;
}

/**
 * Read a process tree
 * This method is called from LogicalPlanParser::getProcessTreeFromString
 *
 *@returns A boolean value which indicate whether the reading process is successful. 
 *@see LogicalPlanParser::getProcessTreeFromString.
 */
bool LogicalPlanParser::readProcessTree()
{
	this->success = true;

	// local variables
	TreeIDType treeid;
	int psnodenum;
	NodeIDType rootid;

	NodeIDType nodeid;
	NodeIDType parentid;
	ProcessTreeNode** psNodes = NULL;

	// read the tree id, the number of nodes in the tree and the root node id. 
	*(this->pTreeStream) >> treeid >> psnodenum >> rootid;
	
	if (psnodenum < 0)
	{
		this->success = false;
		globalErrorInfo.insertProblem(ERR_TYPE_ERROR, __LINE__, 
			"LogicalPlanParser::readProcessTree", __FILE__, 
			"The number of process tree node in a process tree can not be less than zero.");
		goto exit;
	}

	if (this->checkEOF()) 
	{
		this->success = false;
		globalErrorInfo.insertProblem(ERR_TYPE_ERROR, __LINE__, 
			"LogicalPlanParser::readProcessTree", __FILE__, 
			"EOF comes before the end of the logical plan.");
		goto exit;
	}

	// allocate space for the pattren nodes node list 
	psNodes = new ProcessTreeNode*[psnodenum];

	// read nodes one by one
	for (int i=0; i<psnodenum; i++)
	{
		this->skipComment();
		// read the nodeid and the id of its parent. 
		*(this->pTreeStream) >> nodeid >> parentid;

		if (this->checkEOF() && (i != psnodenum-1))
		{
			globalErrorInfo.insertProblem(ERR_TYPE_ERROR, __LINE__, 
				"LogicalPlanParser::readProcessTree", __FILE__, 
				"EOF comes before the end of the logical plan.");
			this->success = false;
			goto exit;		
		}

		// if the node is not among the ones that have been read in, throw an error. 
		
		ProcessTreeNode* psNode = this->findPsTreeNodeWithID(nodeid);
		ProcessTreeNode* parentNode = this->findPsTreeNodeWithID(parentid);
		if (psNode == NULL)
		{
			sprintf(this->errMsg, "The process tree node with id=%d has not been input in process tree node list.", nodeid);
			globalErrorInfo.insertProblem(ERR_TYPE_ERROR, __LINE__, 
				"LogicalPlanParser::readProcessTree", __FILE__, 
				this->errMsg);
			this->success = false;
			goto exit;		
		}
		else if (parentid == -1)
			// it is OK to have parent id to be -1, it means the node is the root. 
			psNode->setParentID(parentid);

		else if (parentNode == NULL)
			// if the parent node is not among the node that have been read in, throw an error. 
		{
			sprintf(this->errMsg, "The process tree node with id=%d has not been input in pattern tree node list.", parentid);
			globalErrorInfo.insertProblem(ERR_TYPE_ERROR, __LINE__, 
				"LogicalPlanParser::readProcessTree", __FILE__, 
				this->errMsg);
			this->success = false;
			goto exit;		
		}
		else
			// if there is a parent node, add the node it the child list of the parent node. 
			parentNode->insertChild(psNode);

		psNodes[i] = psNode;
		bool charRead = this->skipTill('\n');
		if (charRead)
		{		
			sprintf(this->errMsg, "There should be no other input on the line after describing process tree node (id=%d) in the process tree.", nodeid);
			globalErrorInfo.insertProblem(ERR_TYPE_ERROR, __LINE__, 
				"LogicalPlanParser::readProcessTree", __FILE__, 
				this->errMsg);
			this->success = false;
			goto exit;
		}	
	}

	// build the process tree. 
	this->psTree = new ProcessTree(treeid, rootid, psnodenum, psNodes);

	if (this->psTree == NULL)
	{
		sprintf(this->errMsg, "Error happens while generating process tree (id=%d", treeid);
		globalErrorInfo.insertProblem(ERR_TYPE_ERROR, __LINE__, 
			"LogicalPlanParser::readProcessTree", __FILE__, 
			this->errMsg);
		this->success = false;
		goto exit;		
	}

exit: 
	delete [] psNodes;
	return this->success;
}

/**
 * read a line from the input, till the "return" key
 */
void LogicalPlanParser::readLine()
{
	(*(this->pTreeStream)).getline(this->lineBuffer, MAX_LINE_BUFFER_LENGTH);
	while (strncmp(this->lineBuffer, "//", 2) == 0)
		(*(this->pTreeStream)).getline(this->lineBuffer, MAX_LINE_BUFFER_LENGTH);
}

/**
 * skip comment line in the logical plan
 */
void LogicalPlanParser::skipComment()
{
	char chr;

	(*(this->pTreeStream)).get(chr);
	while (chr == '/')
	{
		this->skipTill('\n');
		(*(this->pTreeStream)).get(chr);
	}
	(*(this->pTreeStream)).putback(chr);	
}

/**
 * skip some part of the input, till the given character is seen. 
 *@param The character that should terminate the read
 *@return A boolean value which indicate whether any charactor, other than " " is read. 
 */
bool LogicalPlanParser::skipTill(char ch)
{
	char buf[1000];
	(*(this->pTreeStream)).getline(buf, 1000, ch);

	// check whether any character is read before the delim. 

	bool readChar = false;
	int i=0;
	while (buf[i] != '\0')
	{
		if (buf[i] != ' ')
		{
			readChar = true;
			break;
		}
		i++;
	}

	return readChar;
}

/**
 * read everything till the given character is seen the first time. 
 */
char* LogicalPlanParser::readTill(char ch)
{
	char buf[MAX_TEXT_VALUE_LENGTH];
	char* str = NULL;

	(*(this->pTreeStream)).getline(buf, MAX_TEXT_VALUE_LENGTH, ch);
	str = new char[strlen(buf) + 1];
	strcpy(str, buf);
	return str;
}

/**
 * read everything between the next appearance of the given start/stop char. 
 */
char* LogicalPlanParser::readbetween(char ch1, char ch2)
{
	bool charRead = this->skipTill(ch1);
	if (charRead)
	{		
		sprintf(this->errMsg, "There should be no other parameter before '%c'.",  ch1);
		globalErrorInfo.insertProblem(ERR_TYPE_ERROR, __LINE__, 
			"LogicalPlanParser::readbetween", __FILE__, 
			this->errMsg);
		this->success = false;
		return NULL;
	}

	char* str = this->readTill(ch2);
	return str;
}

/**
 * read a node reference (LCL). 
 */
LCLType LogicalPlanParser::readPtNodeReference()
{
	LCLType reference;
	*(this->pTreeStream) >> reference;
	return reference;
}

/**
 * read a value that is wrapped between "".
 */
Value* LogicalPlanParser::readRightValue(bool isStringValue)
{
	Value* rightVal = NULL;
	char* cRightVal = this->readbetween('"', '"');
						
	if (isStringValue)
	{
		rightVal = new Value(STRING_VALUE);
		rightVal->setStrValue(cRightVal);
	}

	else
	{
		bool isInt = true;

		for (unsigned int i=0; i<strlen(cRightVal); i++)
			if (cRightVal[i] == '.')
			{
				isInt = false;
				break;
			}
		
		if (isInt)
		{	
			rightVal = new Value(INT_VALUE);
			rightVal->setIntValue(atoi(cRightVal));	
		}
		else
		{
			rightVal = new Value(REAL_VALUE);
			rightVal->setRealValue(atof(cRightVal));
		}
	}

	delete [] cRightVal;

	return rightVal;
}

/**
 * read a filter predicate. 
 */
PO_FilterPredicate* LogicalPlanParser::readFilterPredicate()
{
	PO_FilterPredicate* pred = new PO_FilterPredicate;

	// read the left value (LCL)
	pred->leftValueLCL = this->readPtNodeReference();
	if (this->checkEOF()) 
	{
		globalErrorInfo.insertProblem(ERR_TYPE_ERROR, __LINE__, 
			"LogicalPlanParser::readFilterPredicate", __FILE__, 
			"EOF comes before the end of the logical plan.");
		this->success = false;
		goto exit;		
	}
	
	// read the operator and right value source
	char cOp[100];
	char cRightValOpt[100];
	*(this->pTreeStream) >> cOp >> cRightValOpt;

	if (this->checkEOF()) 
	{
		globalErrorInfo.insertProblem(ERR_TYPE_ERROR, __LINE__, 
			"LogicalPlanParser::readFilterPredicate", __FILE__, 
			"EOF comes before the end of the logical plan.");
		this->success = false;
		goto exit;		
	}

	// dictionary lookup
	this->parseKeyword(cOp, 
					   &(pred->filterOperatorDataType), 
					   &(pred->filterOperator));

	pred->rightValueOption = this->parseKeyword(cRightValOpt);

	// the source of right value. 
	switch (pred->rightValueOption)
	{
	case REFERENCE_VALUE:
		pred->rightValueLCL = this->readPtNodeReference();
		pred->rightValueConstant = NULL;
		break;
	case CONSTANT_VALUE:
		pred->rightValueConstant = this->readRightValue(pred->filterOperatorDataType==STRING_VALUE);
		pred->rightValueLCL = -1;
		break;
	default:
		sprintf(this->errMsg, "%s is not a valid right value option for filter.", cRightValOpt);
		globalErrorInfo.insertProblem(ERR_TYPE_ERROR, __LINE__, 
			"LogicalPlanParser::readFilterPredicate", __FILE__, 
			this->errMsg);
		this->success = false;
		goto exit;		
	}
					
	// read filter option (SOME, EVERY, etc). 
	char cFilterOption[100];
	*(this->pTreeStream) >> cFilterOption;
	pred->filterOption = this->parseKeyword(cFilterOption);
				
	if (pred->filterOption < 0)
	{
		sprintf(this->errMsg, "%s is not a valid filter option.", cFilterOption);
		globalErrorInfo.insertProblem(ERR_TYPE_ERROR, __LINE__, 
			"LogicalPlanParser::readProcessTreeNode", __FILE__, 
			this->errMsg);
		this->success = false;
		goto exit;		
	}	

	if (this->checkEOF()) 
	{
		globalErrorInfo.insertProblem(ERR_TYPE_ERROR, __LINE__, 
			"LogicalPlanParser::readFilterPredicate", __FILE__, 
			"EOF comes before the end of the logical plan.");
		this->success = false;
		goto exit;		
	}
exit:
	if (!this->success) return NULL;
	else return pred;
}

/**
 * Initialize the keyword disctionary. 
 */
void LogicalPlanParser::initKeywordMap()
{
	// for pattern tree node type
	this->keywordDictionary.insert(StringIntpairMapType::value_type("DOCUMENT", IntPair(PATTERN_TREE_SELECTION_NODE, DOCUMENT_NODE)));
	this->keywordDictionary.insert(StringIntpairMapType::value_type("ELEMENT", IntPair(PATTERN_TREE_SELECTION_NODE, ELEMENT_NODE)));
	this->keywordDictionary.insert(StringIntpairMapType::value_type("ATTRIBUTE", IntPair(PATTERN_TREE_SELECTION_NODE, ATTRIBUTE_NODE)));
	this->keywordDictionary.insert(StringIntpairMapType::value_type("REFERENCE", IntPair(PATTERN_TREE_REFERENCE_NODE, -1)));
	this->keywordDictionary.insert(StringIntpairMapType::value_type("VALUEJOIN", IntPair(PATTERN_TREE_VALUEJOIN_NODE, -1)));
	this->keywordDictionary.insert(StringIntpairMapType::value_type("CARTESIAN", IntPair(PATTERN_TREE_CARTESIAN_NODE, -1)));
	this->keywordDictionary.insert(StringIntpairMapType::value_type("C_ELEMENT", IntPair(PATTERN_TREE_CONSTRUCT_NODE, CONSTRUCT_ELEMENT)));
	this->keywordDictionary.insert(StringIntpairMapType::value_type("C_ATTRIBUTE", IntPair(PATTERN_TREE_CONSTRUCT_NODE, CONSTRUCT_ATTRIBUTE)));
	this->keywordDictionary.insert(StringIntpairMapType::value_type("C_REFERENCE", IntPair(PATTERN_TREE_CONSTRUCT_NODE, CONSTRUCT_REFERENCE)));
	this->keywordDictionary.insert(StringIntpairMapType::value_type("MLCA-ROOT", IntPair(PATTERN_TREE_MLCAROOT_NODE, -1)));

	// for operation option
	this->keywordDictionary.insert(StringIntpairMapType::value_type("ID", IntPair(OPERATE_ON_ID, -1)));
	this->keywordDictionary.insert(StringIntpairMapType::value_type("CONTENT", IntPair(OPERATE_ON_CONTENT, -1)));

	// operation scope choices
	this->keywordDictionary.insert(StringIntpairMapType::value_type("TEXT", IntPair(OPERATE_ON_CONTENT, -1)));
	this->keywordDictionary.insert(StringIntpairMapType::value_type("SUBTREE", IntPair(OPERATE_ON_SUBTREE, -1)));
	this->keywordDictionary.insert(StringIntpairMapType::value_type("NODE", IntPair(OPERATE_ON_NODE, -1)));
	this->keywordDictionary.insert(StringIntpairMapType::value_type("OUTER", IntPair(OPERATE_ON_OUTER, -1)));
	
	// operator in predicate associated with pattern tree node and filter node
	this->keywordDictionary.insert(StringIntpairMapType::value_type("EQS", IntPair(STRING_VALUE, SCAN_OP_EQ)));
	this->keywordDictionary.insert(StringIntpairMapType::value_type("NES", IntPair(STRING_VALUE, SCAN_OP_NE)));
	this->keywordDictionary.insert(StringIntpairMapType::value_type("GTS", IntPair(STRING_VALUE, SCAN_OP_GT)));
	this->keywordDictionary.insert(StringIntpairMapType::value_type("GES", IntPair(STRING_VALUE, SCAN_OP_GE)));
	this->keywordDictionary.insert(StringIntpairMapType::value_type("LTS", IntPair(STRING_VALUE, SCAN_OP_LT)));
	this->keywordDictionary.insert(StringIntpairMapType::value_type("LES", IntPair(STRING_VALUE, SCAN_OP_LE)));
	this->keywordDictionary.insert(StringIntpairMapType::value_type("CONTAINS", IntPair(STRING_VALUE, SCAN_OP_CONTAINS)));
	this->keywordDictionary.insert(StringIntpairMapType::value_type("CONTAINEDBY", IntPair(STRING_VALUE, SCAN_OP_CONTAINEDBY)));
	this->keywordDictionary.insert(StringIntpairMapType::value_type("STARTWITH", IntPair(STRING_VALUE, SCAN_OP_STARTWITH)));
	this->keywordDictionary.insert(StringIntpairMapType::value_type("EQN", IntPair(REAL_VALUE, SCAN_OP_EQ)));
	this->keywordDictionary.insert(StringIntpairMapType::value_type("NEN", IntPair(REAL_VALUE, SCAN_OP_NE)));
	this->keywordDictionary.insert(StringIntpairMapType::value_type("GTN", IntPair(REAL_VALUE, SCAN_OP_GT)));
	this->keywordDictionary.insert(StringIntpairMapType::value_type("GEN", IntPair(REAL_VALUE, SCAN_OP_GE)));
	this->keywordDictionary.insert(StringIntpairMapType::value_type("LTN", IntPair(REAL_VALUE, SCAN_OP_LT)));
	this->keywordDictionary.insert(StringIntpairMapType::value_type("LEN", IntPair(REAL_VALUE, SCAN_OP_LE)));
	this->keywordDictionary.insert(StringIntpairMapType::value_type("ID_EQ", IntPair(ID_VALUE, SCAN_OP_EQ)));
	this->keywordDictionary.insert(StringIntpairMapType::value_type("ID_NEQ", IntPair(ID_VALUE, SCAN_OP_NE)));
	this->keywordDictionary.insert(StringIntpairMapType::value_type("ID_GT", IntPair(ID_VALUE, SCAN_OP_GT)));
	this->keywordDictionary.insert(StringIntpairMapType::value_type("ID_GE", IntPair(ID_VALUE, SCAN_OP_GE)));
	this->keywordDictionary.insert(StringIntpairMapType::value_type("ID_LT", IntPair(ID_VALUE, SCAN_OP_LT)));
	this->keywordDictionary.insert(StringIntpairMapType::value_type("ID_LE", IntPair(ID_VALUE, SCAN_OP_LE)));

	// relationship of pattern tree node with parent node
	this->keywordDictionary.insert(StringIntpairMapType::value_type("ANCS", IntPair(PTTREE_RELATION_ANCS, -1)));
	this->keywordDictionary.insert(StringIntpairMapType::value_type("PARENT", IntPair(PTTREE_RELATION_PARENT, -1)));

	// choice of join operation of pattern tree node with its parent node
	this->keywordDictionary.insert(StringIntpairMapType::value_type("-", IntPair(PTTREE_OPERATION_ONLYONE, -1)));
	this->keywordDictionary.insert(StringIntpairMapType::value_type("?", IntPair(PTTREE_OPERATION_ZEROORONE, -1)));
	this->keywordDictionary.insert(StringIntpairMapType::value_type("*", IntPair(PTTREE_OPERATION_ZEROORMORE, -1)));
	this->keywordDictionary.insert(StringIntpairMapType::value_type("+", IntPair(PTTREE_OPERATION_ONEORMORE, -1)));

	// value join mode
	this->keywordDictionary.insert(StringIntpairMapType::value_type("ANY", IntPair(ANY_JOIN, -1)));
	this->keywordDictionary.insert(StringIntpairMapType::value_type("ONE", IntPair(ONE_JOIN, -1)));

	// for pattern tree type
	this->keywordDictionary.insert(StringIntpairMapType::value_type("PATTERN_TREE", IntPair(PATTERN_TREE_NORMAL, -1)));
	this->keywordDictionary.insert(StringIntpairMapType::value_type("CONSTRUCT_TREE", IntPair(PATTERN_TREE_CONSTRUCT_TAGGING, -1)));
	this->keywordDictionary.insert(StringIntpairMapType::value_type("MLCA_TREE", IntPair(PATTERN_TREE_MLCA, -1)));

	// process tree node type
	this->keywordDictionary.insert(StringIntpairMapType::value_type("SELECT", IntPair(PROCESS_TREE_SELECT_NODE, -1)));
	this->keywordDictionary.insert(StringIntpairMapType::value_type("PROJECT", IntPair(PROCESS_TREE_PROJECT_NODE, -1)));
	this->keywordDictionary.insert(StringIntpairMapType::value_type("DUPLICATE_ELIMINATION", IntPair(PROCESS_TREE_DUPLICATE_ELIMINATION_NODE, -1)));
	this->keywordDictionary.insert(StringIntpairMapType::value_type("JOIN", IntPair(PROCESS_TREE_JOIN_NODE, -1)));
	this->keywordDictionary.insert(StringIntpairMapType::value_type("AGGREGATE_FUNCTION", IntPair(PROCESS_TREE_AGGREGATE_FUNCTION_NODE, -1)));
	this->keywordDictionary.insert(StringIntpairMapType::value_type("FILTER", IntPair(PROCESS_TREE_FILTER_NODE, SIMPLE_FILTER)));
	this->keywordDictionary.insert(StringIntpairMapType::value_type("ORFILTER", IntPair(PROCESS_TREE_FILTER_NODE, OR_FILTER)));
	this->keywordDictionary.insert(StringIntpairMapType::value_type("SORT", IntPair(PROCESS_TREE_SORT_NODE, -1)));
	this->keywordDictionary.insert(StringIntpairMapType::value_type("CONSTRUCT", IntPair(PROCESS_TREE_CONSTRUCT_NODE, -1)));
	this->keywordDictionary.insert(StringIntpairMapType::value_type("UNION", IntPair(PROCESS_TREE_SET_NODE, SET_OP_UNION)));
	this->keywordDictionary.insert(StringIntpairMapType::value_type("INTERSECT", IntPair(PROCESS_TREE_SET_NODE, SET_OP_INTERSECT)));
	this->keywordDictionary.insert(StringIntpairMapType::value_type("DIFFERENCE", IntPair(PROCESS_TREE_SET_NODE, SET_OP_DIFFERENCE)));
	this->keywordDictionary.insert(StringIntpairMapType::value_type("MLCA", IntPair(PROCESS_TREE_MLCA_NODE, -1)));
	this->keywordDictionary.insert(StringIntpairMapType::value_type("UPDATE", IntPair(PROCESS_TREE_UPDATE_NODE, -1)));
	this->keywordDictionary.insert(StringIntpairMapType::value_type("DELETE", IntPair(PROCESS_TREE_DELETE_NODE, -1)));
	this->keywordDictionary.insert(StringIntpairMapType::value_type("INSERT_FILE", IntPair(PROCESS_TREE_INSERT_NODE, INSERT_FILE)));
	this->keywordDictionary.insert(StringIntpairMapType::value_type("INSERT_ELEMENT", IntPair(PROCESS_TREE_INSERT_NODE, INSERT_ELEMENT)));
	this->keywordDictionary.insert(StringIntpairMapType::value_type("INSERT_ATTRIBUTE", IntPair(PROCESS_TREE_INSERT_NODE, INSERT_ATTRIBUTE)));

	// aggregate functions
	this->keywordDictionary.insert(StringIntpairMapType::value_type("COUNT", IntPair(AGGREGATE_FUNCTION_COUNT, -1)));
	this->keywordDictionary.insert(StringIntpairMapType::value_type("MIN", IntPair(AGGREGATE_FUNCTION_MIN, -1)));
	this->keywordDictionary.insert(StringIntpairMapType::value_type("MAX", IntPair(AGGREGATE_FUNCTION_MAX, -1)));
	this->keywordDictionary.insert(StringIntpairMapType::value_type("SUM", IntPair(AGGREGATE_FUNCTION_SUM, -1)));
	this->keywordDictionary.insert(StringIntpairMapType::value_type("AVERAGE", IntPair(AGGREGATE_FUNCTION_AVERAGE, -1)));

	// value source
	this->keywordDictionary.insert(StringIntpairMapType::value_type("REF", IntPair(REFERENCE_VALUE, -1)));
	this->keywordDictionary.insert(StringIntpairMapType::value_type("CONST", IntPair(CONSTANT_VALUE, -1)));

	// filter option
	this->keywordDictionary.insert(StringIntpairMapType::value_type("EVERY", IntPair(FILTER_OPTION_EVERY, -1)));
	this->keywordDictionary.insert(StringIntpairMapType::value_type("SOME", IntPair(FILTER_OPTION_SOME, -1)));
	this->keywordDictionary.insert(StringIntpairMapType::value_type("EXACTLYONE", IntPair(FILTER_OPTION_EXACTLYONE, -1)));

	// for sort
	this->keywordDictionary.insert(StringIntpairMapType::value_type("KEY", IntPair(ORDER_BY_KEY, -1)));
	this->keywordDictionary.insert(StringIntpairMapType::value_type("VALUE", IntPair(ORDER_BY_VALUE, -1)));
	this->keywordDictionary.insert(StringIntpairMapType::value_type("ASCENDING", IntPair(ORDER_SPEC_ASCENDING, -1)));
	this->keywordDictionary.insert(StringIntpairMapType::value_type("DESCENDING", IntPair(ORDER_SPEC_DESCENDING, -1)));
	this->keywordDictionary.insert(StringIntpairMapType::value_type("LEAST", IntPair(ORDER_NULL_LEAST, -1)));
	this->keywordDictionary.insert(StringIntpairMapType::value_type("GREATEST", IntPair(ORDER_NULL_GREATEST, -1)));
 
	// for NULL value
	this->keywordDictionary.insert(StringIntpairMapType::value_type("NULL", IntPair(PO_INTERFACE_NULL, PO_INTERFACE_NULL)));
}

/**
 * dictionary lookup
 *@param word The word to be looked up. 
 *@param key1 The primiary key value (output)
 *@param key2 The secondary key value (output)
 */
void LogicalPlanParser::parseKeyword(char* word, int* key1, int* key2)
{
	StringIntpairMapType::iterator mapItem;

	mapItem = this->keywordDictionary.find(word);
	if (mapItem == this->keywordDictionary.end())
	{
		*key1 = -1;
		*key2 = -1;
	}
	else
	{
		*key1 = mapItem->second.key1;
		*key2 = mapItem->second.key2;
	}
}

/**
 * Dictionary lookup
 * @param word The word to lookup in the dictionary
 * @returns The primiary key. 
 */
int LogicalPlanParser::parseKeyword(char* word)
{
	StringIntpairMapType::iterator mapItem;

	mapItem = this->keywordDictionary.find(word);
	if (mapItem == this->keywordDictionary.end())
		return -1;
	else
		return mapItem->second.key1;
}


/**
 * Check whether we reach the end of the input stream.
 *@returns TRUE is it is. 
 */
bool LogicalPlanParser::checkEOF()
{
	if ((*(this->pTreeStream)).eof()) 
		return true;
	else return false;
}

/**
 * cleanup the memory allocated. 
 * this function maybe called when the reading of a logical plan fails. 
 */
void LogicalPlanParser::cleanup()
{
	int i;

	if (this->psTreeNodes != NULL)
	{
		for (i=0; i<this->psTreeNodeNum; i++)
			if (this->psTreeNodes[i] != NULL)
			{
				int nodetype = ((ProcessTreeNode*) this->psTreeNodes[i])->getPsNodeType();
				switch (nodetype)
				{
				case PROCESS_TREE_SELECT_NODE:
					this->markDeletedPtTree(((ProcessTreeSelectNode*) this->psTreeNodes[i])->getPatternTree()->getTreeID());
					delete ((ProcessTreeSelectNode*) this->psTreeNodes[i]);
					break;

				case PROCESS_TREE_PROJECT_NODE:
					delete ((ProcessTreeProjectNode*) this->psTreeNodes[i]);
					break;

				case PROCESS_TREE_DUPLICATE_ELIMINATION_NODE:
					delete ((ProcessTreeDuplicateEliminationNode*) this->psTreeNodes[i]);
					break;

				case PROCESS_TREE_JOIN_NODE:
					this->markDeletedPtTree(((ProcessTreeJoinNode*) this->psTreeNodes[i])->getPatternTree()->getTreeID());
					delete ((ProcessTreeJoinNode*) this->psTreeNodes[i]);
					break;

				case PROCESS_TREE_AGGREGATE_FUNCTION_NODE:
					delete ((ProcessTreeAggregateFunctionNode*) this->psTreeNodes[i]);
					break;

				case PROCESS_TREE_FILTER_NODE:
					delete ((ProcessTreeFilterNode*) this->psTreeNodes[i]);
					break;

				case PROCESS_TREE_SORT_NODE:
					delete ((ProcessTreeSortNode*) this->psTreeNodes[i]);
					break;

				case PROCESS_TREE_SET_NODE:
					delete ((ProcessTreeSetNode*) this->psTreeNodes[i]);
					break;

				case PROCESS_TREE_CONSTRUCT_NODE:
					this->markDeletedPtTree(((ProcessTreeConstructNode*) this->psTreeNodes[i])->getPatternTree()->getTreeID());
					delete ((ProcessTreeConstructNode*) this->psTreeNodes[i]);
					break;

				case PROCESS_TREE_MLCA_NODE:
					this->markDeletedPtTree(((ProcessTreeMLCANode*) this->psTreeNodes[i])->getPatternTree()->getTreeID());
					delete ((ProcessTreeMLCANode*) this->psTreeNodes[i]);
					break;

				case PROCESS_TREE_UPDATE_NODE:
					delete ((ProcessTreeUpdateNode*) this->psTreeNodes[i]);
					break;

				case PROCESS_TREE_DELETE_NODE:
					delete ((ProcessTreeDeleteNode*) this->psTreeNodes[i]);
					break;

				case PROCESS_TREE_INSERT_NODE:
					delete ((ProcessTreeInsertNode*) this->psTreeNodes[i]);
					break;
				}

				this->psTreeNodes[i] = NULL;
			}
		delete [] this->psTreeNodes;
	}

	if (this->ptTrees != NULL)
	{
		for (i=0; i<this->ptTreeNum; i++)
			if (this->ptTrees[i] != NULL)
			{
				this->markDeletedPtTreeNode(this->ptTrees[i]->getTreeID());
				delete this->ptTrees[i];
				this->ptTrees[i] = NULL;
			}
		delete [] this->ptTrees;
	}
	this->ptTrees = NULL;

	if (this->ptTreeNodes != NULL)
	{
		for (i=0; i<this->ptTreeNodeNum; i++)
			if (this->ptTreeNodes[i] != NULL)
			{
				int nodetype = ((PatternTreeNode*) this->ptTreeNodes[i])->getPtTreeNodeType();
				switch (nodetype)
				{
				case PATTERN_TREE_SELECTION_NODE:
					delete ((PatternTreeSelectionNode*) this->ptTreeNodes[i]);
					break;

				case PATTERN_TREE_VALUEJOIN_NODE:
					delete ((PatternTreeValueJoinNode*) this->ptTreeNodes[i]);
					break;

				case PATTERN_TREE_CONSTRUCT_NODE:
					delete ((PatternTreeConstructNode*) this->ptTreeNodes[i]);
					break;

				case PATTERN_TREE_REFERENCE_NODE:
					delete ((PatternTreeReferenceNode*) this->ptTreeNodes[i]);
					break;

				case PATTERN_TREE_CARTESIAN_NODE:
				case PATTERN_TREE_MLCAROOT_NODE:
					delete ((PatternTreeNode*) this->ptTreeNodes[i]);
					break;

				case MARKED_PATTERN_TREE_SELECTION_NODE:
					delete ((MarkedPatternTreeSelectionNode*) this->ptTreeNodes[i]);
					break;
				}
				this->ptTreeNodes[i] = NULL;
			}
		delete [] this->ptTreeNodes;
	}
	this->ptTreeNodes = NULL;

	this->psTreeNodes = NULL;
}

/**
 * Locate the process tree node with the given id, among all the process
 * tree nodes that has been read in. 
 *@param id The ID of the node to be located.
 *@returns A pointer to the process tree node with the given id, if such a node is found. or NULL if not such node exists.
 */
ProcessTreeNode* LogicalPlanParser::findPsTreeNodeWithID(NodeIDType id)
{
	for (int i=0; i< this->psTreeNodeNum; i++)
		if (this->psTreeNodes[i] == NULL) continue;
		else if (this->psTreeNodes[i]->getNodeID() == id)
			return this->psTreeNodes[i];
	return NULL;
}

/**
 * Locate the pattern tree node with the given id, among all the pattern
 * tree nodes that has been read in. 
 *@param id The ID of the node to be located.
 *@returns A pointer to the pattern tree node with the given id, if such a node is found. or NULL if not such node exists.
 */
PatternTreeNode* LogicalPlanParser::findPtTreeNodeWithID(NodeIDType id)
{
	for (int i=0; i< this->ptTreeNodeNum; i++)
		if (this->ptTreeNodes[i] == NULL) continue;
		else if (this->ptTreeNodes[i]->getNodeID() == id)
			return this->ptTreeNodes[i];
	return NULL;
}

/**
 * Locate the pattern tree with the given id, among all the pattern
 * trees that has been read in. 
 *@param id The ID of the tree to be located.
 *@returns A pointer to the pattern tree with the given id, if such a node is found. or NULL if not such tree exists.
 */
PatternTree* LogicalPlanParser::findPtTreeWithID(NodeIDType id)
{
	for (int i=0; i< this->ptTreeNum; i++)
		if (this->ptTrees[i] == NULL) continue;
		else if (this->ptTrees[i]->getTreeID() == id)
			return this->ptTrees[i];
	return NULL;
}

/**
 * Locate the process tree node with the given id, among all the process
 * tree nodes that has been read in. 
 *@param id The ID of the node to be located.
 *@returns A pointer to the process tree node with the given id, if such a node is found. or NULL if not such node exists.
 */
int LogicalPlanParser::findPsTreeNodeIndexWithID(NodeIDType id)
{
	for (int i=0; i< this->psTreeNodeNum; i++)
		if (this->psTreeNodes[i] == NULL) continue;
		else if (this->psTreeNodes[i]->getNodeID() == id)
			return i;
	return -1;
}

/**
 * Locate the pattern tree node with the given id, among all the pattern
 * tree nodes that has been read in. 
 *@param id The ID of the node to be located.
 *@returns A pointer to the pattern tree node with the given id, if such a node is found. or NULL if not such node exists.
 */
int LogicalPlanParser::findPtTreeNodeIndexWithID(NodeIDType id)
{
	for (int i=0; i< this->ptTreeNodeNum; i++)
	{
		if (this->ptTreeNodes[i] == NULL) continue;
		else if (this->ptTreeNodes[i]->getNodeID() == id)
			return i;
	}
	return -1;
}

/**
 * Locate the pattern tree with the given id, among all the pattern
 * trees that has been read in. 
 *@param id The ID of the tree to be located.
 *@returns A pointer to the pattern tree with the given id, if such a node is found. or NULL if not such tree exists.
 */
int LogicalPlanParser::findPtTreeIndexWithID(NodeIDType id)
{
	for (int i=0; i< this->ptTreeNum; i++)
		if (this->ptTrees[i] == NULL) continue;
		else if (this->ptTrees[i]->getTreeID() == id)
			return i;
	return -1;
}

void LogicalPlanParser::markDeletedPtTree(TreeIDType treeid)
{
	this->markDeletedPtTreeNode(treeid);
	this->ptTrees[this->findPtTreeIndexWithID(treeid)] = NULL;
}

void LogicalPlanParser::markDeletedPtTreeNode(TreeIDType treeid)
{
	int ptTreeIndex = this->findPtTreeIndexWithID(treeid);
	PatternTree* ptTree = this->ptTrees[ptTreeIndex];

	for (int i=0; i<ptTree->getNodeNumber(); i++)
	{
		Node* ptTreeNode = ptTree->getNodeAtIndex(i);
		if (ptTreeNode == NULL) continue;
		NodeIDType ptTreeNodeID = ptTreeNode->getNodeID();
		int ptTreeNodeIndex = this->findPtTreeNodeIndexWithID(ptTreeNodeID);
		if (ptTreeNodeIndex < 0)
		{
		}
		else this->ptTreeNodes[ptTreeNodeIndex] = NULL;
	}
}
