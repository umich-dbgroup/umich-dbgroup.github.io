/**
COPYRIGHT  � 2000-2004
THE REGENTS OF THE UNIVERSITY OF MICHIGAN ALL RIGHTS RESERVED

PERMISSION IS GRANTED TO USE, COPY, CREATE DERIVATIVE WORKS A
ND REDISTRIBUTE THIS SOFTWARE AND SUCH DERIVATIVE WORKS FOR 
NONCOMMERCIAL EDUCATION AND RESEARCH PURPOSES, SO LONG AS NO 
FEE IS CHARGED, AND SO LONG AS THE COPYRIGHT NOTICE ABOVE, 
THIS GRANT OF PERMISSION, AND THE DISCLAIMER BELOW APPEAR IN 
ALL COPIES MADE; AND SO LONG AS THE NAME OF THE UNIVERSITY OF 
MICHIGAN IS NOT USED IN ANY ADVERTISING OR PUBLICITY PERTAINING 
TO THE USE OR DISTRIBUTION OF THIS SOFTWARE WITHOUT SPECIFIC, 
WRITTEN PRIOR AUTHORIZATION.

THIS SOFTWARE IS PROVIDED AS IS, WITHOUT REPRESENTATION FROM 
THE UNIVERSITY OF MICHIGAN AS TO ITS FITNESS FOR ANY PURPOSE, 
AND WITHOUT WARRANTY BY THE UNIVERSITY OF MICHIGAN OF ANY KIND, 
EITHER EXPRESS OR IMPLIED, INCLUDING WITHOUT LIMITATION THE 
IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A 
PARTICULAR PURPOSE. THE REGENTS OF THE UNIVERSITY OF MICHIGAN 
SHALL NOT BE LIABLE FOR ANY DAMAGES, INCLUDING SPECIAL, INDIRECT, 
INCIDENTAL, OR CONSEQUENTIAL DAMAGES, WITH RESPECT TO ANY CLAIM 
ARISING OUT OF OR IN CONNECTION WITH THE USE OF THE SOFTWARE, 
EVEN IF IT HAS BEEN OR IS HEREAFTER ADVISED OF THE POSSIBILITY 
OF SUCH DAMAGES.
*/

#ifndef __LogicalPlanParser_H
#define __LogicalPlanParser_H

#include "../ProcessTreeInterface.h"


/**
 * define the NULL value in the logical plan interface
 */ 
#define PO_INTERFACE_NULL				99

/**
 * to separate simple filter from filter with disjunctive predicates
 */
#define SIMPLE_FILTER					0
#define OR_FILTER						1

/**
 * A keyword in the logical plan is interpret to a pair of 
 * internal key values. 
 * For example: the keyword "ELEMENT" in a pattern tree node is
 * interpreted into (PATTERN_TREE_SELECTION_NODE, ELEMENT_NODE)
 */
class IntPair 
{
public: 
	IntPair(int k1, int k2) {key1=k1; key2=k2;}
	int key1, key2;
}; 


/**
 * This is a dictionary that maps keyword in the interface to 
 * internal key value used in the process tree.
 */
typedef std::map <char*, IntPair, ltstr> StringIntpairMapType;


/**
 * class LogicalPlanParser
 * This class parses a logical plan (string) into a internal 
 * structure -- process tree.
 *
 *@see ProcessTree
 *@see PatternTree
 *@author: Yuqing Melanie Wu
 */

class LogicalPlanParser
{
public:
	LogicalPlanParser(void);
	~LogicalPlanParser(void);

	ProcessTree* getProcessTreeFromFile(char* filename);
	ProcessTree* getProcessTreeFromString(void* pTreeStream);


private:
	/**
	 * The string to be parserd
	 */
	std::iostream* pTreeStream;

	/*
	 * The process tree to be built based on the string input.
	 */
	ProcessTree* psTree;

	/**
	 * The list of all the process tree nodes
	 */
	ProcessTreeNode** psTreeNodes;

	/** 
	 * The list of pattern tree nodes in the process tree
	 */ 
	PatternTreeNode** ptTreeNodes;
	
	/**
	 * The list of pattern trees in the process tree
	 */
	PatternTree**	ptTrees;

	/**
	 * Pattern tree number
	 */
	int ptTreeNum;

	/**
	 * Pattern tree node number
	 */
	int ptTreeNodeNum;

	/**
	 * Process tree node number
	 */
	int psTreeNodeNum;

	/**
	 * The keyword dictionary
	 */ 
	StringIntpairMapType keywordDictionary;

	/**
	 * the buffer for the current reading pool. 
	 */ 
	char lineBuffer[MAX_LINE_BUFFER_LENGTH];

	/**
	 * A boolean variable which indicate whether the parseing
	 * of the logical plan is successful so far
	 */
	bool success;

	/** 
	 * For constructing the error message.
	 */
	char errMsg[1000];

	/**
	 * The following are internal methods that reads a building
	 * block of a process tree. 
	 */

	bool	readPatternTreeNode(int i);
	bool	readPatternTree(int i);
	bool	readProcessTreeNode(int i);
	bool	readProcessTree();

	/**
	 * Initialization
	 */
	void initKeywordMap();
	
	/**
	 * Internal Methods that deal with stream reading
	 */
	void readLine();
	void skipComment();
	bool skipTill(char ch);
	char* readTill(char ch);
	char* readbetween(char ch1, char ch2);
	bool checkEOF();
	
	/**
	 * Internal Methods that read a value block in a process tree
	 * such as a reference, a right value, a predicate, etc. 
	 */
	Value* readRightValue(bool isStringValue);
	LCLType readPtNodeReference();
	PO_FilterPredicate* readFilterPredicate();

	/**
	 * Dictionary lookup
	 */
	void parseKeyword(char* word, int* key1, int* key2);
	int parseKeyword(char* word);

	/**
	 * Cleanup
	 */
	void cleanup();
	void markDeletedPtTree(TreeIDType treeid);
	void markDeletedPtTreeNode(TreeIDType treeid);

	/**
	 * Locate the component in the list
	 */
	PatternTreeNode* findPtTreeNodeWithID(NodeIDType id);
	PatternTree* findPtTreeWithID(TreeIDType id);
	ProcessTreeNode* findPsTreeNodeWithID(NodeIDType id);

	int findPtTreeNodeIndexWithID(NodeIDType id);
	int findPtTreeIndexWithID(TreeIDType id);
	int findPsTreeNodeIndexWithID(NodeIDType id);

};

#endif