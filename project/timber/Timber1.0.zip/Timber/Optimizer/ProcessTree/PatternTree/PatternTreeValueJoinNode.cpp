/**
COPYRIGHT  � 2000-2004
THE REGENTS OF THE UNIVERSITY OF MICHIGAN ALL RIGHTS RESERVED

PERMISSION IS GRANTED TO USE, COPY, CREATE DERIVATIVE WORKS A
ND REDISTRIBUTE THIS SOFTWARE AND SUCH DERIVATIVE WORKS FOR 
NONCOMMERCIAL EDUCATION AND RESEARCH PURPOSES, SO LONG AS NO 
FEE IS CHARGED, AND SO LONG AS THE COPYRIGHT NOTICE ABOVE, 
THIS GRANT OF PERMISSION, AND THE DISCLAIMER BELOW APPEAR IN 
ALL COPIES MADE; AND SO LONG AS THE NAME OF THE UNIVERSITY OF 
MICHIGAN IS NOT USED IN ANY ADVERTISING OR PUBLICITY PERTAINING 
TO THE USE OR DISTRIBUTION OF THIS SOFTWARE WITHOUT SPECIFIC, 
WRITTEN PRIOR AUTHORIZATION.

THIS SOFTWARE IS PROVIDED AS IS, WITHOUT REPRESENTATION FROM 
THE UNIVERSITY OF MICHIGAN AS TO ITS FITNESS FOR ANY PURPOSE, 
AND WITHOUT WARRANTY BY THE UNIVERSITY OF MICHIGAN OF ANY KIND, 
EITHER EXPRESS OR IMPLIED, INCLUDING WITHOUT LIMITATION THE 
IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A 
PARTICULAR PURPOSE. THE REGENTS OF THE UNIVERSITY OF MICHIGAN 
SHALL NOT BE LIABLE FOR ANY DAMAGES, INCLUDING SPECIAL, INDIRECT, 
INCIDENTAL, OR CONSEQUENTIAL DAMAGES, WITH RESPECT TO ANY CLAIM 
ARISING OUT OF OR IN CONNECTION WITH THE USE OF THE SOFTWARE, 
EVEN IF IT HAS BEEN OR IS HEREAFTER ADVISED OF THE POSSIBILITY 
OF SUCH DAMAGES.
*/

#include "PatternTreeValueJoinNode.h"

/**
 * Default Constructor
 */

PatternTreeValueJoinNode::PatternTreeValueJoinNode(void)
{
}

/**
 * Constructor
 * 
 * Construct a pattern tree value join node by calling pattern tree node
 * constructor
 * 
 *@see PatternTreeNode::PatternTreeNode
 *
 *@param id The id of the node. 
 *@param parent the node id of the parent node of this node. 
 *@param childnum The number of children of the node.
 *@param children The node ids of the children of this node.
 *@param joinCond The join condition. 
 */
PatternTreeValueJoinNode
::PatternTreeValueJoinNode(NodeIDType id,
						   NodeIDType parent,
						   int childnum, 
						   NodeIDType* children,
						   ValueJoinConditionType* joinCond)
						   : PatternTreeNode(id, parent, childnum, children, 
						   PATTERN_TREE_VALUEJOIN_NODE)
{
	this->valueJoinCond = joinCond;
	
	// Cartesian product is a special case of value join, with 
	// on join condition. 
	if (joinCond == NULL)
		this->ptTreeNodeType = PATTERN_TREE_CARTESIAN_NODE;
}

/**
 * Destructor
 */
PatternTreeValueJoinNode::~PatternTreeValueJoinNode(void)
{
	if (this->valueJoinCond != NULL)
		delete this->valueJoinCond;
}

/**
 * Access Method
 * Get the value join condition.
 */
ValueJoinConditionType* PatternTreeValueJoinNode::getValueJoinCondition()
{
	return this->valueJoinCond;
}

/**
 * Debug Method
 * Print the information about a value join node
 */
void PatternTreeValueJoinNode::printPtNode()
{
	((PatternTreeNode*) this)->printPtNode();

	cout << "value join condition: "; 
	if (this->valueJoinCond == NULL) cout << "NULL" << endl;
	else
	{
		cout << "LCL:" << this->valueJoinCond->leftReference;
		switch (this->valueJoinCond->operaror)
		{
		case SCAN_OP_EQ: cout << "EQ"; break;
		case SCAN_OP_NE: cout << "NE"; break;
		case SCAN_OP_LT: cout << "LT"; break;
		case SCAN_OP_LE: cout << "LE"; break;
		case SCAN_OP_GT: cout << "GT"; break;
		case SCAN_OP_GE: cout << "GE"; break;
		}

		cout << "LCL:" << this->valueJoinCond->rightReference;

		switch(this->valueJoinCond->operatorDataType)
		{
		case ID_VALUE: cout << "on node key" << endl; break;
		case STRING_VALUE: cout << "one element content" << endl; break;
		}
	}
}
