/**
COPYRIGHT  � 2000-2004
THE REGENTS OF THE UNIVERSITY OF MICHIGAN ALL RIGHTS RESERVED

PERMISSION IS GRANTED TO USE, COPY, CREATE DERIVATIVE WORKS A
ND REDISTRIBUTE THIS SOFTWARE AND SUCH DERIVATIVE WORKS FOR 
NONCOMMERCIAL EDUCATION AND RESEARCH PURPOSES, SO LONG AS NO 
FEE IS CHARGED, AND SO LONG AS THE COPYRIGHT NOTICE ABOVE, 
THIS GRANT OF PERMISSION, AND THE DISCLAIMER BELOW APPEAR IN 
ALL COPIES MADE; AND SO LONG AS THE NAME OF THE UNIVERSITY OF 
MICHIGAN IS NOT USED IN ANY ADVERTISING OR PUBLICITY PERTAINING 
TO THE USE OR DISTRIBUTION OF THIS SOFTWARE WITHOUT SPECIFIC, 
WRITTEN PRIOR AUTHORIZATION.

THIS SOFTWARE IS PROVIDED AS IS, WITHOUT REPRESENTATION FROM 
THE UNIVERSITY OF MICHIGAN AS TO ITS FITNESS FOR ANY PURPOSE, 
AND WITHOUT WARRANTY BY THE UNIVERSITY OF MICHIGAN OF ANY KIND, 
EITHER EXPRESS OR IMPLIED, INCLUDING WITHOUT LIMITATION THE 
IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A 
PARTICULAR PURPOSE. THE REGENTS OF THE UNIVERSITY OF MICHIGAN 
SHALL NOT BE LIABLE FOR ANY DAMAGES, INCLUDING SPECIAL, INDIRECT, 
INCIDENTAL, OR CONSEQUENTIAL DAMAGES, WITH RESPECT TO ANY CLAIM 
ARISING OUT OF OR IN CONNECTION WITH THE USE OF THE SOFTWARE, 
EVEN IF IT HAS BEEN OR IS HEREAFTER ADVISED OF THE POSSIBILITY 
OF SUCH DAMAGES.
*/


#include "patterntree.h"

/**
 * Constructor
 * 
 * Construct a PatternTree by calling the Tree constructor
 * 
 *@see Tree::Tree
 *
 *@param id The id of the tree.
 *@param root The node id of the root node of the tree.
 *@param nodenum The number of nodes in the tree.
 *@param nodes The nodes of the tree. 
 *@param ptTreeType The type of the pattern tree. 
 *			possible values are: 
 *				PATTERN_TREE_NORMAL
 *				PATTERN_TREE_CONSTRUCT_TAGGING	
 *				PATTERN_TREE_MLCA
 */
PatternTree::PatternTree(TreeIDType id, 
						 NodeIDType root, 
						 int nodenum,
						 PatternTreeNode** nodes,
					     int ptTreeType)
						 : Tree(id, root, nodenum, (Node**) nodes)
{
	this->patternTreeType = ptTreeType;
}


/**
 * Constructor
 * 
 * Construct a PatternTree by calling the Tree constructor, given
 * the nodes ids in a compacted list and the nodes in a sparsed list. 
 * 
 *@see Tree::Tree
 *
 *@param id The id of the tree.
 *@param root The node id of the root node of the tree.
 *@param nodenum The number of nodes in the tree.
 *@param nodeids The ids of the nodes in the tree, in a compact list. 
 *@param nodes The nodes of the tree, in a sparse list. 
 *@param ptTreeType The type of the pattern tree. 
 *			possible values are: 
 *				PATTERN_TREE_NORMAL
 *				PATTERN_TREE_CONSTRUCT_TAGGING	
 *				PATTERN_TREE_MLCA
 */
PatternTree::PatternTree(TreeIDType id,
						 NodeIDType root, 
						 int nodeNum, 
						 NodeIDType* nodeids, 
						 PatternTreeNode** nodes,
					     int ptTreeType)
						 : Tree(id, root, nodeNum, nodeids, (Node**) nodes)
{
	this->patternTreeType = ptTreeType;
}

PatternTree::~PatternTree()
{
	for (int i=0; i<this->nodeNumber; i++)
	{
		int nodetype = ((PatternTreeNode*) this->nodes[i])->getPtTreeNodeType();
		switch (nodetype)
		{
		case PATTERN_TREE_SELECTION_NODE:
			delete ((PatternTreeSelectionNode*) this->nodes[i]);
			break;

		case PATTERN_TREE_VALUEJOIN_NODE:
			delete ((PatternTreeValueJoinNode*) this->nodes[i]);
			break;

		case PATTERN_TREE_CONSTRUCT_NODE:
			delete ((PatternTreeConstructNode*) this->nodes[i]);
			break;

		case PATTERN_TREE_REFERENCE_NODE:
			delete ((PatternTreeReferenceNode*) this->nodes[i]);
			break;

		case PATTERN_TREE_CARTESIAN_NODE:
		case PATTERN_TREE_MLCAROOT_NODE:
			delete ((PatternTreeNode*) this->nodes[i]);
			break;

		case MARKED_PATTERN_TREE_SELECTION_NODE:
			delete ((MarkedPatternTreeSelectionNode*) this->nodes[i]);
			break;

		}
	}

	delete [] this->nodes;

	this->nodeNumber = 0;
	this->nodes = NULL;

}

/**
 * Access Method
 * Get the pattern tree type
 */
int PatternTree::getPatternTreeType()
{
	return this->patternTreeType;
}

/**
 * Access Method
 * Get the root node. 
 */
PatternTreeNode* PatternTree::getRoot()
{
	return (PatternTreeNode*) this->getNodeWithID(root);
}

/**
 * Access Method
 * Get the pattern tree node at a given position in the node list
 *
 *@param i The position of the node in the node list
 *@returns A pointer to the pattern tree node. NULL if the given poisiton
 *		is beyond the list
 */
PatternTreeNode* PatternTree::getPtNodeAtIndex(int i)
{
	return (PatternTreeNode*) this->getNodeAtIndex(i);
}

/**
 * Access Method
 * Get the pattern tree node, given an id. 
 *
 *@param id The node id of the node to be found
 *@returns A pointer to the pattern tree node. NULL if there is
 *		no such node in the pattern tree. 
 */
PatternTreeNode* PatternTree::getPtNodeWithID(NodeIDType id)
{
	return (PatternTreeNode*) this->getNodeWithID(id);
}

/**
 * Access Method
 * Get the pattern tree node, given a LCL
 * There is no method in class Tree that serves this. 
 * Go over all the nodes in the pattern tree, compare the give LCL
 * with that of each node and find whhether three is such node exists. 
 */
PatternTreeNode* PatternTree::getPtNodeWithLCL(LCLType lcl)
{
	for (int i=0; i<this->nodeNumber; i++)
	{
		if (((PatternTreeNode*) this->nodes[i])->getLCL() == lcl)
			return ((PatternTreeNode*) this->nodes[i]);
	}
	return NULL;
}

/**
 * Access Method
 * Get the depth of the node, given the node id. 
 *
 *@param nodeid The id of the node whose depth is to be computed.
 *@returns The depth of the node in the tree. -1 if the node is not in the tree. 
 */
int PatternTree::getDepthOfNode(NodeIDType nodeid)
{
	int depth;

	int crtNodeID = nodeid;
	PatternTreeNode* crtNode = this->getPtNodeWithID(crtNodeID);
	if (crtNode == NULL)
		// if the node is not in the tree, return depth -1. 
		depth = -1;
	else if (crtNode->getNodeID() == this->root)
		depth = 0;
	else
	{
		// trace back to the root, and count the steps. 
		depth = 1;
		int parentNodeID = crtNode->getParentID();

		while ((parentNodeID != -1) && (parentNodeID != this->root))
		{
			crtNodeID = parentNodeID;
			crtNode = this->getPtNodeWithID(crtNodeID);
			parentNodeID = crtNode->getParentID();
			depth++;
		}
	}

	return depth;
}

/**
 * Access Method
 * 
 * Get the list of node ids of the nodes in the tree in depth-first order.
 *@returns The list of nodes ids. 
 */
NodeIDType* PatternTree::getDepthFirstNodeList()
{
	int num;
	NodeIDType* nodeIDList = this->getDepthFirstNodeListRootedAt(this->root, &num);
	if (num != this->nodeNumber)
		globalErrorInfo.insertProblem(ERR_TYPE_ERROR, __LINE__, 
			"PatternTree::getDepthFirstNodeList", __FILE__,
			"The depth first traversal does not retrieve all nodes.");
	return nodeIDList;
}


/**
 * Access Method
 * 
 * Get the list of node ids of the nodes of a subtree in the pattern 
 * tree, given the root of the subtree, in depth-first order.
 *
 *@param nodeid The id of the root node of the subtree. 
 *@param num (output) The number of nodes in the subtree. 
 *@returns The list of nodes ids. 
 */

NodeIDType* PatternTree::getDepthFirstNodeListRootedAt(NodeIDType nodeid,
													   int* num)
{
	PatternTreeNode* node = this->getPtNodeWithID(nodeid);
	// if there is no node with the given id, return NULL. 
	if (node == NULL)
	{
		*num = 0;
		return NULL;
	}

	// otherwise, get the list by recursively call this function. 
	NodeIDType* nodeIDList = new NodeIDType[this->nodeNumber];

	nodeIDList[0] = nodeid;
	int count = 1;

	for (int i=0; i<node->getChildNumber(); i++)
	{
		int subListSize;

		// get the list of nodes of one of the children. 
		NodeIDType* subList = this->getDepthFirstNodeListRootedAt(node->getChildIDAt(i), &subListSize);
		
		// copy the subList to the node id list. 
		for (int j=0; j<subListSize; j++)
		{
			nodeIDList[count] = subList[j];
			count++;
		}
		delete [] subList;
	}

	*num = count;
	return nodeIDList;
}

/**
 * Debug Method
 * 
 * Print the pattern tree. including the following info
 *	the tree id
 *  the pattern tree type
 *  the number of nodes in the tree
 *  the id of the roto node
 *  each pattern tree nodes. 
 */

void PatternTree::printPtTree()
{
	cout << endl << endl << "--------------- Pattern Tree ----------------" << endl;
	cout << "Pattern Tree ID: " << this->treeID << endl;
	
	cout << "Pattern Tree Type: ";
	switch (this->patternTreeType)
	{
	case PATTERN_TREE_NORMAL:
		cout << "PATTERN_TREE_NORMAL" << endl;
		break;

	case PATTERN_TREE_CONSTRUCT_TAGGING:
		cout << "PATTERN_TREE_CONSTRUCT_TAGGING" << endl;
		break;

	case PATTERN_TREE_MLCA: 
		cout << "PATTERN_TREE_MLCA" << endl;
		break;
	}
	
	cout << "Pattern Tree Node number: " << this->nodeNumber << endl;
	cout << "Root Node ID: " << this->root << endl;
	cout << "PatternTreeNodes: " << endl;

	for (int i=0; i<this->nodeNumber; i++)
	{
		PatternTreeNode* ptNode = (PatternTreeNode*) this->nodes[i];

		switch (ptNode->getPtTreeNodeType())
		{
		case PATTERN_TREE_SELECTION_NODE:
			((PatternTreeSelectionNode*) ptNode)->printPtNode();
			break;

		case PATTERN_TREE_VALUEJOIN_NODE:
			((PatternTreeValueJoinNode*) ptNode)->printPtNode();
			break;

		case PATTERN_TREE_CONSTRUCT_NODE:
			((PatternTreeConstructNode*) ptNode)->printPtNode();
			break;

		case PATTERN_TREE_REFERENCE_NODE:
			((PatternTreeReferenceNode*) ptNode)->printPtNode();
			break;

		case PATTERN_TREE_MLCAROOT_NODE:
			ptNode->printPtNode();
			break;

		case MARKED_PATTERN_TREE_SELECTION_NODE:
			((MarkedPatternTreeSelectionNode*) ptNode)->printPtNode();
			break;
		}			
	}
}

