/**
COPYRIGHT  � 2000-2004
THE REGENTS OF THE UNIVERSITY OF MICHIGAN ALL RIGHTS RESERVED

PERMISSION IS GRANTED TO USE, COPY, CREATE DERIVATIVE WORKS A
ND REDISTRIBUTE THIS SOFTWARE AND SUCH DERIVATIVE WORKS FOR 
NONCOMMERCIAL EDUCATION AND RESEARCH PURPOSES, SO LONG AS NO 
FEE IS CHARGED, AND SO LONG AS THE COPYRIGHT NOTICE ABOVE, 
THIS GRANT OF PERMISSION, AND THE DISCLAIMER BELOW APPEAR IN 
ALL COPIES MADE; AND SO LONG AS THE NAME OF THE UNIVERSITY OF 
MICHIGAN IS NOT USED IN ANY ADVERTISING OR PUBLICITY PERTAINING 
TO THE USE OR DISTRIBUTION OF THIS SOFTWARE WITHOUT SPECIFIC, 
WRITTEN PRIOR AUTHORIZATION.

THIS SOFTWARE IS PROVIDED AS IS, WITHOUT REPRESENTATION FROM 
THE UNIVERSITY OF MICHIGAN AS TO ITS FITNESS FOR ANY PURPOSE, 
AND WITHOUT WARRANTY BY THE UNIVERSITY OF MICHIGAN OF ANY KIND, 
EITHER EXPRESS OR IMPLIED, INCLUDING WITHOUT LIMITATION THE 
IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A 
PARTICULAR PURPOSE. THE REGENTS OF THE UNIVERSITY OF MICHIGAN 
SHALL NOT BE LIABLE FOR ANY DAMAGES, INCLUDING SPECIAL, INDIRECT, 
INCIDENTAL, OR CONSEQUENTIAL DAMAGES, WITH RESPECT TO ANY CLAIM 
ARISING OUT OF OR IN CONNECTION WITH THE USE OF THE SOFTWARE, 
EVEN IF IT HAS BEEN OR IS HEREAFTER ADVISED OF THE POSSIBILITY 
OF SUCH DAMAGES.
*/

#ifndef __PatternTreeReferenceNode_H
#define __PatternTreeReferenceNode_H

#include "patterntreenode.h"

/**
 * class PatternTreeReferenceNode
 * 
 * It is a sub-class of PatternTreeNode.
 * It is corresponding to a REFERECE node in the logical plan.
 * One property of a reference node is that its LCL is not the same 
 * as its node id. The node id is the unique id to identify this node
 * in the pattern tree/process tree. The LCL is how the node will be
 * refered in the query process. 
 *
 *@see PatternTreeNode
 *
 *@author: Yuqing Melanie Wu
 */

class PatternTreeReferenceNode :
	public PatternTreeNode
{
public:
	PatternTreeReferenceNode(void);
	
	PatternTreeReferenceNode(NodeIDType id, 
		NodeIDType parent,
		int childnum, 
		NodeIDType* children,
		int relation, 
		int joinopt,
		LCLType reference);

	~PatternTreeReferenceNode(void);

	LCLType getReference();
	void printPtNode();

private:
	/**
	 * The LCL this node refered to. 
	 */
	LCLType referenceLCL;
};

#endif