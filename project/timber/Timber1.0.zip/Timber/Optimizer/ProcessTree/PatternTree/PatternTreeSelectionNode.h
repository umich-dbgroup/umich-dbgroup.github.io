/**
COPYRIGHT  � 2000-2004
THE REGENTS OF THE UNIVERSITY OF MICHIGAN ALL RIGHTS RESERVED

PERMISSION IS GRANTED TO USE, COPY, CREATE DERIVATIVE WORKS A
ND REDISTRIBUTE THIS SOFTWARE AND SUCH DERIVATIVE WORKS FOR 
NONCOMMERCIAL EDUCATION AND RESEARCH PURPOSES, SO LONG AS NO 
FEE IS CHARGED, AND SO LONG AS THE COPYRIGHT NOTICE ABOVE, 
THIS GRANT OF PERMISSION, AND THE DISCLAIMER BELOW APPEAR IN 
ALL COPIES MADE; AND SO LONG AS THE NAME OF THE UNIVERSITY OF 
MICHIGAN IS NOT USED IN ANY ADVERTISING OR PUBLICITY PERTAINING 
TO THE USE OR DISTRIBUTION OF THIS SOFTWARE WITHOUT SPECIFIC, 
WRITTEN PRIOR AUTHORIZATION.

THIS SOFTWARE IS PROVIDED AS IS, WITHOUT REPRESENTATION FROM 
THE UNIVERSITY OF MICHIGAN AS TO ITS FITNESS FOR ANY PURPOSE, 
AND WITHOUT WARRANTY BY THE UNIVERSITY OF MICHIGAN OF ANY KIND, 
EITHER EXPRESS OR IMPLIED, INCLUDING WITHOUT LIMITATION THE 
IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A 
PARTICULAR PURPOSE. THE REGENTS OF THE UNIVERSITY OF MICHIGAN 
SHALL NOT BE LIABLE FOR ANY DAMAGES, INCLUDING SPECIAL, INDIRECT, 
INCIDENTAL, OR CONSEQUENTIAL DAMAGES, WITH RESPECT TO ANY CLAIM 
ARISING OUT OF OR IN CONNECTION WITH THE USE OF THE SOFTWARE, 
EVEN IF IT HAS BEEN OR IS HEREAFTER ADVISED OF THE POSSIBILITY 
OF SUCH DAMAGES.
*/

#ifndef __PatternTreeSelectionNode_H
#define __PatternTreeSelectionNode_H

#include "patterntreenode.h"

/**
 * class PatternTreeSelectionNode
 * 
 * The class for a selection node in a pattern tree. 
 * 
 * This is a subclass of PatternTreeNode.
 * A "DOCUMENT", "ELEMENT", or "ATTRIBUTE" node in the logical plan
 * is mapped to a pattern tree node.
 * 
 *@see PatternTreeNode
 *@author: Yuqing Melanie Wu
 */

class PatternTreeSelectionNode : public PatternTreeNode
{
public:
	PatternTreeSelectionNode(void);

	PatternTreeSelectionNode(NodeIDType id, 
		NodeIDType parent, 
		int childnum, 
		NodeIDType* children, 
		char* filename, 
		int relation, 
		int joinopt, 
		int nodetype, 
		SelectionCondition* cond,
		char* eleTag,
		char* attrName);

	~PatternTreeSelectionNode(void);

	char*	getFileName();
	int		getNodeType();
	char*   getElementTag();
	char*	getAttributeName();

	SelectionCondition* getSelectionCondition();

	void printPtNode();

private:
	/**
	 * The name of the XML document in which the selection will happen. 
	 */
	char filename[MAX_FILE_NAME_LENGTH];

	/**
	 * The type of node this selection is targeting at. 
	 * possible values are: DOCUMENT_NODE, ELEMENT_NODE, ATTRIBUTE_NODE
	 */
	int nodeType;

	/**
	 * The selection condition
	 */
	SelectionCondition* condition;
	
	/**
	 * The element tag, if the target of the selection is an element node. 
	 */
	char* elementTag;

	/**
	 * The attribute name, if the target of the selection is an attribute node. 
	 */
	char* attrName;
};


#endif