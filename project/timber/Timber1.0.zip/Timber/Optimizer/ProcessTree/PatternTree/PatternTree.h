/**
COPYRIGHT  � 2000-2004
THE REGENTS OF THE UNIVERSITY OF MICHIGAN ALL RIGHTS RESERVED

PERMISSION IS GRANTED TO USE, COPY, CREATE DERIVATIVE WORKS A
ND REDISTRIBUTE THIS SOFTWARE AND SUCH DERIVATIVE WORKS FOR 
NONCOMMERCIAL EDUCATION AND RESEARCH PURPOSES, SO LONG AS NO 
FEE IS CHARGED, AND SO LONG AS THE COPYRIGHT NOTICE ABOVE, 
THIS GRANT OF PERMISSION, AND THE DISCLAIMER BELOW APPEAR IN 
ALL COPIES MADE; AND SO LONG AS THE NAME OF THE UNIVERSITY OF 
MICHIGAN IS NOT USED IN ANY ADVERTISING OR PUBLICITY PERTAINING 
TO THE USE OR DISTRIBUTION OF THIS SOFTWARE WITHOUT SPECIFIC, 
WRITTEN PRIOR AUTHORIZATION.

THIS SOFTWARE IS PROVIDED AS IS, WITHOUT REPRESENTATION FROM 
THE UNIVERSITY OF MICHIGAN AS TO ITS FITNESS FOR ANY PURPOSE, 
AND WITHOUT WARRANTY BY THE UNIVERSITY OF MICHIGAN OF ANY KIND, 
EITHER EXPRESS OR IMPLIED, INCLUDING WITHOUT LIMITATION THE 
IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A 
PARTICULAR PURPOSE. THE REGENTS OF THE UNIVERSITY OF MICHIGAN 
SHALL NOT BE LIABLE FOR ANY DAMAGES, INCLUDING SPECIAL, INDIRECT, 
INCIDENTAL, OR CONSEQUENTIAL DAMAGES, WITH RESPECT TO ANY CLAIM 
ARISING OUT OF OR IN CONNECTION WITH THE USE OF THE SOFTWARE, 
EVEN IF IT HAS BEEN OR IS HEREAFTER ADVISED OF THE POSSIBILITY 
OF SUCH DAMAGES.
*/

#ifndef __PatternTree_H
#define __PatternTree_H

#include "../Tree/Tree.h"

#include "PatternTreeSelectionNode.h"
#include "PatternTreeConstructNode.h"
#include "PatternTreeReferenceNode.h"
#include "PatternTreeValueJoinNode.h"
#include "MarkedPatternTreeSelectionNode.h"

/**
 * class: PatternTree
 *
 * This class represent a pattern tree. 
 * It is a sub-class of Tree class. 
 *
 *@see Tree
 *@author: Yuqing Melanie Wu
 */

class PatternTree : public Tree
{
friend class PatternTreeNode;

public:
	PatternTree(void);

	PatternTree(TreeIDType id, 
		NodeIDType root, 
		int nodenum,
		PatternTreeNode** nodes, 
		int ptTreeType = PATTERN_TREE_NORMAL);

	PatternTree(TreeIDType id, 
		NodeIDType root, 
		int nodeNum, 
		NodeIDType* nodeids, 
		PatternTreeNode** nodes,
		int ptTreeType = PATTERN_TREE_NORMAL);

	~PatternTree(void);

	int					getPatternTreeType();
	PatternTreeNode*	getRoot();

	PatternTreeNode*	getPtNodeWithID(NodeIDType id);
	PatternTreeNode*    getPtNodeWithLCL(LCLType lcl); 
	PatternTreeNode*	getPtNodeAtIndex(int index);
	
	int					getDepthOfNode(NodeIDType nodeid);

	NodeIDType*			getDepthFirstNodeList();
	NodeIDType*			getDepthFirstNodeListRootedAt(NodeIDType nodeid,
													  int* nodenum);

	void printPtTree();


protected:
	/* 
	 * The type of the pattern Tree
	 * possible values are: 
	 * PATTERN_TREE_NORMAL, PATTERN_TREE_CONSTRUCT_TAGGING, PATTERN_TREE_MLCA	
	 */
	int patternTreeType; 

};

#endif