/**
COPYRIGHT  � 2000-2004
THE REGENTS OF THE UNIVERSITY OF MICHIGAN ALL RIGHTS RESERVED

PERMISSION IS GRANTED TO USE, COPY, CREATE DERIVATIVE WORKS A
ND REDISTRIBUTE THIS SOFTWARE AND SUCH DERIVATIVE WORKS FOR 
NONCOMMERCIAL EDUCATION AND RESEARCH PURPOSES, SO LONG AS NO 
FEE IS CHARGED, AND SO LONG AS THE COPYRIGHT NOTICE ABOVE, 
THIS GRANT OF PERMISSION, AND THE DISCLAIMER BELOW APPEAR IN 
ALL COPIES MADE; AND SO LONG AS THE NAME OF THE UNIVERSITY OF 
MICHIGAN IS NOT USED IN ANY ADVERTISING OR PUBLICITY PERTAINING 
TO THE USE OR DISTRIBUTION OF THIS SOFTWARE WITHOUT SPECIFIC, 
WRITTEN PRIOR AUTHORIZATION.

THIS SOFTWARE IS PROVIDED AS IS, WITHOUT REPRESENTATION FROM 
THE UNIVERSITY OF MICHIGAN AS TO ITS FITNESS FOR ANY PURPOSE, 
AND WITHOUT WARRANTY BY THE UNIVERSITY OF MICHIGAN OF ANY KIND, 
EITHER EXPRESS OR IMPLIED, INCLUDING WITHOUT LIMITATION THE 
IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A 
PARTICULAR PURPOSE. THE REGENTS OF THE UNIVERSITY OF MICHIGAN 
SHALL NOT BE LIABLE FOR ANY DAMAGES, INCLUDING SPECIAL, INDIRECT, 
INCIDENTAL, OR CONSEQUENTIAL DAMAGES, WITH RESPECT TO ANY CLAIM 
ARISING OUT OF OR IN CONNECTION WITH THE USE OF THE SOFTWARE, 
EVEN IF IT HAS BEEN OR IS HEREAFTER ADVISED OF THE POSSIBILITY 
OF SUCH DAMAGES.
*/


#include "patterntreenode.h"

/**
 * Default Constructor
 */
PatternTreeNode::PatternTreeNode(void) : Node()
{
}

/**
 * Constuctor
 * 
 * Constuct a PatternTreeNode by called correspondant Node constructor
 * 
 *@param id The id of the node. 
 *@param parent the node id of the parent node of this node. 
 *@param childnum The number of children of the node.
 *@param children The node ids of the children of this node.
 *@param ptnodetype The type of the pattern tree node
 */

PatternTreeNode::PatternTreeNode(NodeIDType id,
								 NodeIDType parent,
								 int childnum, 
								 NodeIDType* children,
								 int ptnodetype)
								 : Node(id, parent, childnum, children)
{
	this->ptTreeNodeType = ptnodetype;

	// Not all the nodes has this options. 
	// set default value -1. 
	this->relationWithParent = -1;
	this->joinOpt = -1;

	// default is the the LCL is the same as the nodeid.
	// It will be rewritten in the constructors of the nodes
	// when this is not true. 
	this->LCL = this->nodeID;
}

/**
 * Constuctor
 * 
 * Constuct a PatterTreeNode by called correspondant Node constructor
 * 
 *@param id The id of the node. 
 *@param parent the node id of the parent node of this node. 
 *@param childnum The number of children of the node.
 *@param children The node ids of the children of this node.
 *@param ptnodetype The type of the pattern tree node.
 *@param relation The structural relationship between the node and its parent. 
 *@param joinopt The structural join option between the node and its parent node. 
 */

PatternTreeNode::PatternTreeNode(NodeIDType id, 
								 NodeIDType parent, 
								 int childnum, 
								 NodeIDType* children,
								 int ptnodetype,
								 int relation,
								 int joinopt)
								 : Node(id, parent, childnum, children)
{
	this->ptTreeNodeType = ptnodetype;
	this->relationWithParent = relation;
	this->joinOpt = joinopt;

	// default is the the LCL is the same as the nodeid.
	// It will be rewritten in the constructors of the nodes
	// when this is not true. 
	this->LCL = this->nodeID;
}

/**
 * Destructor
 */
PatternTreeNode::~PatternTreeNode(void)
{
}

/**
 * Access Method
 * Get the pattern tree node type. 
 */
int PatternTreeNode::getPtTreeNodeType()
{
	return this->ptTreeNodeType;
}

/**
 * Access Method
 * Get the structural relationship between the node and its parent. 
 */
int PatternTreeNode::getRelationWithParent()
{
	return this->relationWithParent;
}

/**
 * Access Method
 * Get the structural join option between the node and its parent. 
 */
int PatternTreeNode::getJoinOption()
{
	return this->joinOpt;
}

/**
 * Access Method
 * Get the LCL assigned to the node. 
 */
LCLType PatternTreeNode::getLCL()
{
	return this->LCL;
}

/**
 * Debug Method
 * print the information of the pattern tree node, including: 
 * All the info about the node 
 *@see Node::printNode()
 * the structural relationship and structural join option between 
 * the node and its parent. 
 * the pattern tree node type. 
 */

void PatternTreeNode::printPtNode()
{
	cout << endl << "----------------------" << endl;
	this->printNode();

	cout << "relationship to Parent : ";
	switch (this->relationWithParent)
	{
	case PTTREE_RELATION_ANCS: 
		cout << "Ancestor-Descendant" << endl;
		break;
	case PTTREE_RELATION_PARENT:
		cout << "Parent-Child" << endl;
		break;
	default:
		cout << endl;
	}

	cout << "join Option with Parent : ";
	switch (this->joinOpt)
	{
	case PTTREE_OPERATION_ONLYONE:
		cout << "ONLY ONE" << endl;
		break;
	case PTTREE_OPERATION_ZEROORONE:
		cout << " ZERO OR ONE" << endl;
		break;
	case PTTREE_OPERATION_ZEROORMORE:
		cout << "ZERO OR MORE" << endl;
		break;
	case PTTREE_OPERATION_ONEORMORE:
		cout << "ONE OR MORE" << endl;
		break;
	default:
		cout << endl;
	}

	cout << "pattern tree node type: ";
	switch (this->ptTreeNodeType)
	{
	case PATTERN_TREE_SELECTION_NODE:
		cout << "PATTERN_TREE_SELECTION_NODE" << endl;
		break;

	case PATTERN_TREE_VALUEJOIN_NODE:
		cout << "PATTERN_TREE_VALUEJOIN_NODE" << endl;
		break;

	case PATTERN_TREE_CONSTRUCT_NODE:
		cout << "PATTERN_TREE_CONSTRUCT_NODE" << endl;
		break;

	case PATTERN_TREE_REFERENCE_NODE:
		cout << "PATTERN_TREE_REFERENCE_NODE" << endl;
		break;

	case PATTERN_TREE_MLCAROOT_NODE:
		cout << "PATTERN_TREE_MLCAROOT_NODE" << endl;
		break;

	case MARKED_PATTERN_TREE_SELECTION_NODE:
		cout << "MARKED_PATTERN_TREE_SELECTION_NODE" << endl;
		break;


	}

}


