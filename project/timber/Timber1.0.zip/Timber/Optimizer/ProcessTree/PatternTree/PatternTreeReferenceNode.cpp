/**
COPYRIGHT  � 2000-2004
THE REGENTS OF THE UNIVERSITY OF MICHIGAN ALL RIGHTS RESERVED

PERMISSION IS GRANTED TO USE, COPY, CREATE DERIVATIVE WORKS A
ND REDISTRIBUTE THIS SOFTWARE AND SUCH DERIVATIVE WORKS FOR 
NONCOMMERCIAL EDUCATION AND RESEARCH PURPOSES, SO LONG AS NO 
FEE IS CHARGED, AND SO LONG AS THE COPYRIGHT NOTICE ABOVE, 
THIS GRANT OF PERMISSION, AND THE DISCLAIMER BELOW APPEAR IN 
ALL COPIES MADE; AND SO LONG AS THE NAME OF THE UNIVERSITY OF 
MICHIGAN IS NOT USED IN ANY ADVERTISING OR PUBLICITY PERTAINING 
TO THE USE OR DISTRIBUTION OF THIS SOFTWARE WITHOUT SPECIFIC, 
WRITTEN PRIOR AUTHORIZATION.

THIS SOFTWARE IS PROVIDED AS IS, WITHOUT REPRESENTATION FROM 
THE UNIVERSITY OF MICHIGAN AS TO ITS FITNESS FOR ANY PURPOSE, 
AND WITHOUT WARRANTY BY THE UNIVERSITY OF MICHIGAN OF ANY KIND, 
EITHER EXPRESS OR IMPLIED, INCLUDING WITHOUT LIMITATION THE 
IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A 
PARTICULAR PURPOSE. THE REGENTS OF THE UNIVERSITY OF MICHIGAN 
SHALL NOT BE LIABLE FOR ANY DAMAGES, INCLUDING SPECIAL, INDIRECT, 
INCIDENTAL, OR CONSEQUENTIAL DAMAGES, WITH RESPECT TO ANY CLAIM 
ARISING OUT OF OR IN CONNECTION WITH THE USE OF THE SOFTWARE, 
EVEN IF IT HAS BEEN OR IS HEREAFTER ADVISED OF THE POSSIBILITY 
OF SUCH DAMAGES.
*/


#include "PatternTreeReferenceNode.h"

/**
 * Default Constructor
 */
PatternTreeReferenceNode::PatternTreeReferenceNode(void)
{
}

/**
 * Constructor
 * 
 * Construct a reference node by calling pattern tree node constructor.
 *
 *@see PatternTreeNode::PatternTreeNode
 *
 *@param id The id of the node. 
 *@param parent the node id of the parent node of this node. 
 *@param childnum The number of children of the node.
 *@param children The node ids of the children of this node.
 *@param relation The structural relationship between the node and its parent. 
 *@param joinopt The structural join option between the node and its parent node. 
 *@param reference The LCL being refered by this node. 
 */
PatternTreeReferenceNode
::PatternTreeReferenceNode(NodeIDType id, 
						   NodeIDType parent,
						   int childnum, 
						   NodeIDType* children,
						   int relation,
						   int joinopt,
						   LCLType reference)
						   : PatternTreeNode(id, parent, childnum, children,
						   PATTERN_TREE_REFERENCE_NODE, relation, joinopt)
{
	// set the LCL being refered 
	this->referenceLCL = reference;

	// set the lcl to be the id to be refered. 
	this->LCL = reference;
}

/**
 * Destructor
 */
PatternTreeReferenceNode::~PatternTreeReferenceNode(void)
{
}

/**
 * Access Method
 * Get the LCL being refered to. 
 */
LCLType PatternTreeReferenceNode::getReference()
{
	return this->referenceLCL;
}

/**
 * Debug Method
 * Print the information about the reference node
 */
void PatternTreeReferenceNode::printPtNode()
{
	((PatternTreeNode*) this)->printPtNode();

	cout << "refer to PatternTreeNode " << this->referenceLCL << endl;
}