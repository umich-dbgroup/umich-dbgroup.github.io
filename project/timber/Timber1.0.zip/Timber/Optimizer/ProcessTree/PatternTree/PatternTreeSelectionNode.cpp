/**
COPYRIGHT  � 2000-2004
THE REGENTS OF THE UNIVERSITY OF MICHIGAN ALL RIGHTS RESERVED

PERMISSION IS GRANTED TO USE, COPY, CREATE DERIVATIVE WORKS A
ND REDISTRIBUTE THIS SOFTWARE AND SUCH DERIVATIVE WORKS FOR 
NONCOMMERCIAL EDUCATION AND RESEARCH PURPOSES, SO LONG AS NO 
FEE IS CHARGED, AND SO LONG AS THE COPYRIGHT NOTICE ABOVE, 
THIS GRANT OF PERMISSION, AND THE DISCLAIMER BELOW APPEAR IN 
ALL COPIES MADE; AND SO LONG AS THE NAME OF THE UNIVERSITY OF 
MICHIGAN IS NOT USED IN ANY ADVERTISING OR PUBLICITY PERTAINING 
TO THE USE OR DISTRIBUTION OF THIS SOFTWARE WITHOUT SPECIFIC, 
WRITTEN PRIOR AUTHORIZATION.

THIS SOFTWARE IS PROVIDED AS IS, WITHOUT REPRESENTATION FROM 
THE UNIVERSITY OF MICHIGAN AS TO ITS FITNESS FOR ANY PURPOSE, 
AND WITHOUT WARRANTY BY THE UNIVERSITY OF MICHIGAN OF ANY KIND, 
EITHER EXPRESS OR IMPLIED, INCLUDING WITHOUT LIMITATION THE 
IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A 
PARTICULAR PURPOSE. THE REGENTS OF THE UNIVERSITY OF MICHIGAN 
SHALL NOT BE LIABLE FOR ANY DAMAGES, INCLUDING SPECIAL, INDIRECT, 
INCIDENTAL, OR CONSEQUENTIAL DAMAGES, WITH RESPECT TO ANY CLAIM 
ARISING OUT OF OR IN CONNECTION WITH THE USE OF THE SOFTWARE, 
EVEN IF IT HAS BEEN OR IS HEREAFTER ADVISED OF THE POSSIBILITY 
OF SUCH DAMAGES.
*/


#include "PatternTreeSelectionNode.h"

/**
 * Default Constructor
 */
PatternTreeSelectionNode::PatternTreeSelectionNode(void)
{
}

/**
 * Constructor
 *
 * Construct a pattern tree selection node by calling the 
 * pattern tree node constructor
 * 
 *@see PatternTreeNode::PatternTreeNode
 *
 *@param id The id of the node. 
 *@param parent the node id of the parent node of this node. 
 *@param childnum The number of children of the node.
 *@param children The node ids of the children of this node.
 *@param filename The name of the XML document to be queried. 
 *@param relation The structural relationship between the node and its parent. 
 *@param joinopt The structural join option between the node and its parent node. 
 *@param nodetype The type of node targeting at.
 *@param cond The selection condition. 
 *@parma eletag The element tag if the node to selection is an element node
 *@param attrname The attribute name if the node to select is an attribute name. 
 */
PatternTreeSelectionNode
::PatternTreeSelectionNode(NodeIDType id, 
						   NodeIDType parent, 
						   int childnum, 
						   NodeIDType* children, 
						   char* filename,
						   int relation, 
						   int joinopt, 
						   int nodetype,
						   SelectionCondition* cond,
						   char* eletag,
						   char* attrname)
						   : PatternTreeNode(id, parent, childnum, children,
						   PATTERN_TREE_SELECTION_NODE, relation, joinopt)

{
	strcpy(this->filename, filename);
	this->nodeType = nodetype;
	this->condition = cond;

	if (eletag != NULL)
	{
		this->elementTag = new char[strlen(eletag)+1];
		strcpy(this->elementTag, eletag);
	}
	else this->elementTag = NULL;

	if (attrname != NULL)
	{
		this->attrName = new char[strlen(attrname)+1];
		strcpy(this->attrName, attrname);
	}
	else this->attrName = NULL;
}

/**
 * Destructor
 * Release space assigned to the structure
 */

PatternTreeSelectionNode::~PatternTreeSelectionNode(void)
{
	if (this->elementTag != NULL)
		delete [] this->elementTag;

	if (this->attrName != NULL)
		delete [] this->attrName;

	if (this->condition != NULL)
		delete this->condition;
}

/**
 * Access Method
 * Get the XML document name to be queried.
 */
char* PatternTreeSelectionNode::getFileName()
{
	return this->filename;
}

/**
 * Access Method
 * Get the type of node targeting at. 
 */
int PatternTreeSelectionNode::getNodeType()
{
	return this->nodeType;
}

/**
 * Access Method
 * Get the element tag, if the target is an element node. 
 */
char* PatternTreeSelectionNode::getElementTag()
{
	return this->elementTag;
}

/**
 * Access Method
 * Get the attribute name, if the target is an attribute node. 
 */
char* PatternTreeSelectionNode::getAttributeName()
{
	return this->attrName;
}

/**
 * Access Method
 * Get the selection condition. 
 */
SelectionCondition* PatternTreeSelectionNode::getSelectionCondition()
{
	return this->condition;
}

/**
 * Debug Method
 * 
 * Print the information about the node. 
 */
void PatternTreeSelectionNode::printPtNode()
{
	((PatternTreeNode*) this)->printPtNode();
	cout << "XML file name: " << this->filename << endl;
	cout << "Node Type: ";
	switch (this->nodeType)
	{
	case DOCUMENT_NODE: cout << "DOCUMENT_NODE" << endl; break;
	case ELEMENT_NODE: cout << "ELEMENT_NODE" << endl; break;
	case ATTRIBUTE_NODE: cout << "ATTRIBUTE_NODE" << endl; break;
	}
	this->condition->printSelectionCondition();

	if (this->nodeType == ELEMENT_NODE)
		cout << "Element Tag: " << this->elementTag << endl;

	if (this->nodeType == ATTRIBUTE_NODE)
		cout << "Attribute name: " << this->attrName << endl;
}