/**
COPYRIGHT  � 2000-2004
THE REGENTS OF THE UNIVERSITY OF MICHIGAN ALL RIGHTS RESERVED

PERMISSION IS GRANTED TO USE, COPY, CREATE DERIVATIVE WORKS A
ND REDISTRIBUTE THIS SOFTWARE AND SUCH DERIVATIVE WORKS FOR 
NONCOMMERCIAL EDUCATION AND RESEARCH PURPOSES, SO LONG AS NO 
FEE IS CHARGED, AND SO LONG AS THE COPYRIGHT NOTICE ABOVE, 
THIS GRANT OF PERMISSION, AND THE DISCLAIMER BELOW APPEAR IN 
ALL COPIES MADE; AND SO LONG AS THE NAME OF THE UNIVERSITY OF 
MICHIGAN IS NOT USED IN ANY ADVERTISING OR PUBLICITY PERTAINING 
TO THE USE OR DISTRIBUTION OF THIS SOFTWARE WITHOUT SPECIFIC, 
WRITTEN PRIOR AUTHORIZATION.

THIS SOFTWARE IS PROVIDED AS IS, WITHOUT REPRESENTATION FROM 
THE UNIVERSITY OF MICHIGAN AS TO ITS FITNESS FOR ANY PURPOSE, 
AND WITHOUT WARRANTY BY THE UNIVERSITY OF MICHIGAN OF ANY KIND, 
EITHER EXPRESS OR IMPLIED, INCLUDING WITHOUT LIMITATION THE 
IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A 
PARTICULAR PURPOSE. THE REGENTS OF THE UNIVERSITY OF MICHIGAN 
SHALL NOT BE LIABLE FOR ANY DAMAGES, INCLUDING SPECIAL, INDIRECT, 
INCIDENTAL, OR CONSEQUENTIAL DAMAGES, WITH RESPECT TO ANY CLAIM 
ARISING OUT OF OR IN CONNECTION WITH THE USE OF THE SOFTWARE, 
EVEN IF IT HAS BEEN OR IS HEREAFTER ADVISED OF THE POSSIBILITY 
OF SUCH DAMAGES.
*/


#include "PatternTreeConstructNode.h"

/**
 * Default Constructor
 */
PatternTreeConstructNode::PatternTreeConstructNode(void)
{
}

/**
 * Constructor
 * Construct a PatternTreeConstructNode by calling PatternTreeNode constructor
 *
 *@see PatternTreeNode::PatternTreeNode
 *
 *@param id The id of the node. 
 *@param parent the node id of the parent node of this node. 
 *@param childnum The number of children of the node.
 *@param children The node ids of the children of this node.
 *@param constrType The construct node type. 
 *@param tag The tag name (or attribute node, depends on constrType)
 *@param refLCL The LCL where the value is from.
 *@param constrOpt The construct option -- what to get from witness tree.
 */
PatternTreeConstructNode
::PatternTreeConstructNode(NodeIDType id, 
						   NodeIDType parent,
						   int childnum, 
						   NodeIDType* children,
						   int constrType,
						   char* tag,
						   LCLType refLCL,
						   int constrOpt) 
						   : PatternTreeNode(id, parent, childnum, children,
						   PATTERN_TREE_CONSTRUCT_NODE)
{
	this->constructPtTreeNodeType = constrType;
	if ((constrType == CONSTRUCT_ELEMENT)
		|| (constrType == CONSTRUCT_ATTRIBUTE))
		strcpy(this->tag, tag);
	else 
		strcpy(this->tag, "");

	this->lclRefered = refLCL;
	this->constructPtOption = constrOpt;
}

/**
 * Destructor
 */
PatternTreeConstructNode::~PatternTreeConstructNode(void)
{
}

/**
 * Access Method
 * Get the construct node type. 
 */
int PatternTreeConstructNode::getConstructNodeType()
{
	return this->constructPtTreeNodeType;
}

/**
 * Access Method
 * Get the node tag/attribute name.
 */
char* PatternTreeConstructNode::getNodeTag()
{
	return this->tag;
}

/**
 * Access Method
 * Get the LCL refered to.
 */

LCLType PatternTreeConstructNode::getLCLRefered()
{
	return this->lclRefered;
}

/**
 * Access Method
 * Get the construct option. 
 */

int PatternTreeConstructNode::getConstructPtOption()
{
	return this->constructPtOption;
}

/**
 * Debug Method
 * print the information about the construct node, including: 
 *	construct type
 *  tag
 *  LCL refered to
 *  construct option. 
 */
void PatternTreeConstructNode::printPtNode()
{
	((PatternTreeNode*) this)->printPtNode();

	switch (this->constructPtTreeNodeType)
	{
	case CONSTRUCT_ELEMENT: 
		cout << "ELEMENT" << endl; 
		cout << "element tag: " << this->tag << endl;
		break;

	case CONSTRUCT_ATTRIBUTE: 
		cout << "ATTRIBUTE" << endl; 
		cout << "attribute name: " << this->tag << endl;
		cout << "refer to pattern tree node " << "LCL:" << this->lclRefered << endl;
		break;

	case CONSTRUCT_REFERENCE: 
		cout << "REFERENCE" << endl;
		cout << "refer to pattern tree node " << "LCL:" << this->lclRefered << endl;
		break;
	}

	switch (this->constructPtOption)
	{
	case CONSTRUCT_OPTION_NODE: cout << "the node" << endl; break;
	case CONSTRUCT_OPTION_CONTENT: cout << "the content" << endl; break;
	case CONSTRUCT_OPTION_SUBTREE: cout << "the whole subtree" << endl; break;
	}
}
