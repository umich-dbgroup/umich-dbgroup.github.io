/**
COPYRIGHT  � 2000-2004
THE REGENTS OF THE UNIVERSITY OF MICHIGAN ALL RIGHTS RESERVED

PERMISSION IS GRANTED TO USE, COPY, CREATE DERIVATIVE WORKS A
ND REDISTRIBUTE THIS SOFTWARE AND SUCH DERIVATIVE WORKS FOR 
NONCOMMERCIAL EDUCATION AND RESEARCH PURPOSES, SO LONG AS NO 
FEE IS CHARGED, AND SO LONG AS THE COPYRIGHT NOTICE ABOVE, 
THIS GRANT OF PERMISSION, AND THE DISCLAIMER BELOW APPEAR IN 
ALL COPIES MADE; AND SO LONG AS THE NAME OF THE UNIVERSITY OF 
MICHIGAN IS NOT USED IN ANY ADVERTISING OR PUBLICITY PERTAINING 
TO THE USE OR DISTRIBUTION OF THIS SOFTWARE WITHOUT SPECIFIC, 
WRITTEN PRIOR AUTHORIZATION.

THIS SOFTWARE IS PROVIDED AS IS, WITHOUT REPRESENTATION FROM 
THE UNIVERSITY OF MICHIGAN AS TO ITS FITNESS FOR ANY PURPOSE, 
AND WITHOUT WARRANTY BY THE UNIVERSITY OF MICHIGAN OF ANY KIND, 
EITHER EXPRESS OR IMPLIED, INCLUDING WITHOUT LIMITATION THE 
IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A 
PARTICULAR PURPOSE. THE REGENTS OF THE UNIVERSITY OF MICHIGAN 
SHALL NOT BE LIABLE FOR ANY DAMAGES, INCLUDING SPECIAL, INDIRECT, 
INCIDENTAL, OR CONSEQUENTIAL DAMAGES, WITH RESPECT TO ANY CLAIM 
ARISING OUT OF OR IN CONNECTION WITH THE USE OF THE SOFTWARE, 
EVEN IF IT HAS BEEN OR IS HEREAFTER ADVISED OF THE POSSIBILITY 
OF SUCH DAMAGES.
*/

#ifndef __PatternTreeValueJoinNode_H
#define __PatternTreeValueJoinNode_H

#include "PatternTreeReferenceNode.h"

/**
 * ID_VALUE IS yet another value type. 
 * stand on the same line with STRING_VALUE, INT_VALUE....
 * it is used in value join condition, 
 * to indicate the comparison is on the key value of nodes. 
 */
#define ID_VALUE			10


/**
 * The following structure defined a value join
 */
typedef struct
{
	LCLType leftReference;
	LCLType rightReference;
	int operatorDataType;
	int operaror;
	bool anyJoin;
} ValueJoinConditionType;

/**
 * class PatternTreeValueJoinNode
 * 
 * This is a subclass of PatternTreeNode
 * A value join or cartesian product node in the logical plan
 * maps to this node. 
 *
 *@see PatternTreeNode
 *@author: Yuqing Melanie Wu
 */
class PatternTreeValueJoinNode :
	public PatternTreeNode
{
public:
	PatternTreeValueJoinNode(void);

	PatternTreeValueJoinNode(NodeIDType id, 
		NodeIDType parent, 
		int childnum, 
		NodeIDType* children, 
		ValueJoinConditionType* joinCond);

	~PatternTreeValueJoinNode(void);

	ValueJoinConditionType* getValueJoinCondition();

	void printPtNode();

private:
	/**
	 * the value join condition. 
	 * This could be NULL for cartesian product. 
	 */
	ValueJoinConditionType* valueJoinCond;
};

#endif