/**
COPYRIGHT  � 2000-2004
THE REGENTS OF THE UNIVERSITY OF MICHIGAN ALL RIGHTS RESERVED

PERMISSION IS GRANTED TO USE, COPY, CREATE DERIVATIVE WORKS A
ND REDISTRIBUTE THIS SOFTWARE AND SUCH DERIVATIVE WORKS FOR 
NONCOMMERCIAL EDUCATION AND RESEARCH PURPOSES, SO LONG AS NO 
FEE IS CHARGED, AND SO LONG AS THE COPYRIGHT NOTICE ABOVE, 
THIS GRANT OF PERMISSION, AND THE DISCLAIMER BELOW APPEAR IN 
ALL COPIES MADE; AND SO LONG AS THE NAME OF THE UNIVERSITY OF 
MICHIGAN IS NOT USED IN ANY ADVERTISING OR PUBLICITY PERTAINING 
TO THE USE OR DISTRIBUTION OF THIS SOFTWARE WITHOUT SPECIFIC, 
WRITTEN PRIOR AUTHORIZATION.

THIS SOFTWARE IS PROVIDED AS IS, WITHOUT REPRESENTATION FROM 
THE UNIVERSITY OF MICHIGAN AS TO ITS FITNESS FOR ANY PURPOSE, 
AND WITHOUT WARRANTY BY THE UNIVERSITY OF MICHIGAN OF ANY KIND, 
EITHER EXPRESS OR IMPLIED, INCLUDING WITHOUT LIMITATION THE 
IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A 
PARTICULAR PURPOSE. THE REGENTS OF THE UNIVERSITY OF MICHIGAN 
SHALL NOT BE LIABLE FOR ANY DAMAGES, INCLUDING SPECIAL, INDIRECT, 
INCIDENTAL, OR CONSEQUENTIAL DAMAGES, WITH RESPECT TO ANY CLAIM 
ARISING OUT OF OR IN CONNECTION WITH THE USE OF THE SOFTWARE, 
EVEN IF IT HAS BEEN OR IS HEREAFTER ADVISED OF THE POSSIBILITY 
OF SUCH DAMAGES.
*/

#include "IndexMatchingInfo.h"


/**
 * Constructor
 *
 *
 * Construct an instance of an index matching info
 * 
 *@param indexname The name of the index to be used. 
 *@param indextype The type of the index (int, float or string)
 *@param indexservertype The index server (GIST OR SHORE)
 *@param minval The lower boundary for index scan.
 *@param maxval The upper boundary for index scan.
 */
IndexMatchingInfo
::IndexMatchingInfo(char* indexname,
					int indextype,		 
					int indexservertype, 
					Value* minval, 
					Value* maxval,
					bool vIndex)
{
	strcpy(this->indexName, indexname);
	this->indexType = indextype;
	this->indexServerType = indexservertype;
	this->indexValueMin = new Value(minval);
	this->indexValueMax = new Value(maxval);
	this->valueIndex = vIndex;
}

/**
 * Destructor
 */
IndexMatchingInfo::~IndexMatchingInfo(void)
{
	delete this->indexValueMin;
	delete this->indexValueMax;
}


/**
 * Access Method
 * Get the index name.
 */
char* IndexMatchingInfo::getIndexName()
{
	return indexName;
}

/**
 * Access Method
 * Get the index type. 
 */
int IndexMatchingInfo::getIndexType()
{
	return this->indexType;
}

/**
 * Access Method
 * Get the index server type.
 */
int IndexMatchingInfo::getIndexServerType()
{
	return this->indexServerType;
}

/**
 * Access Method
 * Get the minimum index scan boundary. 
 */
Value* IndexMatchingInfo::getIndexValueMin()
{
	return this->indexValueMin;
}

/**
 * Access Method
 * Get the maximum index scan boundary. 
 */
Value* IndexMatchingInfo::getIndexValueMax()
{
	return this->indexValueMax;
}

/**
 * Access Method
 * Whether this node is matched to a value index or not
 */
bool IndexMatchingInfo::isValueIndex()
{
	return this->valueIndex;
}


/**
 * Debug Method
 * Print the information of the Marked pattern tree selection node. 
 */
void IndexMatchingInfo::printIndexMatchingInfo()
{
	cout << "	index name: " << this->indexName << endl;
	cout << "	index type: ";
	switch (this->indexType)
	{
	case INT_INDEX: cout << "INTEGER index" << endl; break;
	case STRING_INDEX: cout << "STRING index" << endl; break;
	case FLOAT_INDEX: cout << "FLOAT index" << endl; break;
	case DOUBLE_INDEX: cout << "DOUBLE index" << endl; break;
	default: cout << "error with index type" << endl; break;
	}
	cout << "	index server type: ";
	switch (this->indexServerType)
	{
	case GIST_INDEX: cout << "GIST index" << endl; break;
	case SHORE_INDEX: cout << "SHORE index" << endl; break;
	case HASH_INDEX: cout << "HASH index" << endl; break;
	default: cout << "error with index server type" << endl; break;
	}
		
	cout << "	min value: " ;
	if (this->indexValueMin == NULL)
		cout << "NULL" << endl;
	else 
	{
		char* str = this->indexValueMin->valueToString();
		cout << str << endl;
		delete [] str;
	}

	cout << "	max value: ";
	if (this->indexValueMax == NULL)
		cout << "NULL" << endl;
	else 
	{
		char* str = this->indexValueMax->valueToString();
		cout << str << endl;
		delete [] str;
	}
}
