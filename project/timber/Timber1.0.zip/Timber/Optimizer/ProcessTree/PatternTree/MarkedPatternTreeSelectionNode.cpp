/**
COPYRIGHT  � 2000-2004
THE REGENTS OF THE UNIVERSITY OF MICHIGAN ALL RIGHTS RESERVED

PERMISSION IS GRANTED TO USE, COPY, CREATE DERIVATIVE WORKS A
ND REDISTRIBUTE THIS SOFTWARE AND SUCH DERIVATIVE WORKS FOR 
NONCOMMERCIAL EDUCATION AND RESEARCH PURPOSES, SO LONG AS NO 
FEE IS CHARGED, AND SO LONG AS THE COPYRIGHT NOTICE ABOVE, 
THIS GRANT OF PERMISSION, AND THE DISCLAIMER BELOW APPEAR IN 
ALL COPIES MADE; AND SO LONG AS THE NAME OF THE UNIVERSITY OF 
MICHIGAN IS NOT USED IN ANY ADVERTISING OR PUBLICITY PERTAINING 
TO THE USE OR DISTRIBUTION OF THIS SOFTWARE WITHOUT SPECIFIC, 
WRITTEN PRIOR AUTHORIZATION.

THIS SOFTWARE IS PROVIDED AS IS, WITHOUT REPRESENTATION FROM 
THE UNIVERSITY OF MICHIGAN AS TO ITS FITNESS FOR ANY PURPOSE, 
AND WITHOUT WARRANTY BY THE UNIVERSITY OF MICHIGAN OF ANY KIND, 
EITHER EXPRESS OR IMPLIED, INCLUDING WITHOUT LIMITATION THE 
IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A 
PARTICULAR PURPOSE. THE REGENTS OF THE UNIVERSITY OF MICHIGAN 
SHALL NOT BE LIABLE FOR ANY DAMAGES, INCLUDING SPECIAL, INDIRECT, 
INCIDENTAL, OR CONSEQUENTIAL DAMAGES, WITH RESPECT TO ANY CLAIM 
ARISING OUT OF OR IN CONNECTION WITH THE USE OF THE SOFTWARE, 
EVEN IF IT HAS BEEN OR IS HEREAFTER ADVISED OF THE POSSIBILITY 
OF SUCH DAMAGES.
*/

#include "MarkedPatternTreeSelectionNode.h"

/**
 * Default Constructor
 */
MarkedPatternTreeSelectionNode::MarkedPatternTreeSelectionNode(void)
{
	this->elementTag = NULL;
	this->attrName = NULL;
}

/**
 * Constructor
 *
 *
 * Construct a pattern tree selection node by calling the 
 * pattern tree node constructor
 * 
 *@see PatternTreeNode::PatternTreeNode
 *
 *@param ptNode The pattern tree selection node which is being marked.
 *@param indexstatus The index matching status.
 *@param imNum The number of indices to be matched to evaluated this node. 
 *@param im The info about the matching indices. 
 *@param condleft The selection condition that can not be satisfied by index.
 */
MarkedPatternTreeSelectionNode
::MarkedPatternTreeSelectionNode(PatternTreeSelectionNode* ptNode, 
								 int indexstatus,
								 int imNum,
								 IndexMatchingInfo** im,
								 SelectionCondition* condleft)
								 // use some info from the selection node.
								 : PatternTreeNode(ptNode->getNodeID(), 
								 ptNode->getParentID(), 
								 ptNode->getChildNumber(), 
								 ptNode->getChildren(),
								 MARKED_PATTERN_TREE_SELECTION_NODE,
								 ptNode->getRelationWithParent(),
								 ptNode->getJoinOption())

{
	strcpy(this->fileName, ptNode->getFileName());
	this->nodeType = ptNode->getNodeType();

	char* tag = ptNode->getElementTag();
	if (tag == NULL)
		this->elementTag = NULL;
	else 
	{
		this->elementTag = new char[strlen(tag) +1];
		strcpy(this->elementTag, tag);
	}

	char* attr = ptNode->getAttributeName();
	if (attr == NULL)
		this->attrName = NULL;
	else 
	{
		this->attrName = new char[strlen(attr) +1];
		strcpy(this->attrName, attr);
	}

	if (ptNode->getSelectionCondition() == NULL)
		this->originalCondition = NULL;
	else this->originalCondition = new SelectionCondition(ptNode->getSelectionCondition());

	this->indexStatus = indexstatus;

	this->indexMatchingNumber = imNum;
	this->imInfo = im;


	switch (this->indexStatus)
	{
	case FULLY_INDEXED: 
		this->nonIndexedCondition = NULL;
		break;

	case PARTIALLY_INDEXED:
		this->nonIndexedCondition = condleft;
		break;

	case NO_INDEX:
		this->nonIndexedCondition = new SelectionCondition(ptNode->getSelectionCondition());
		break;
	}
}

/**
 * Destructor
 */
MarkedPatternTreeSelectionNode::~MarkedPatternTreeSelectionNode(void)
{
	if (this->elementTag != NULL)
		delete [] this->elementTag;

	if (this->attrName != NULL)
		delete [] this->attrName;

	if (this->indexMatchingNumber > 0)
	{
		for (int i=0; i<this->indexMatchingNumber; i++)
			delete this->imInfo[i];
		delete this->imInfo;
	}
	if (this->nonIndexedCondition != NULL)
		delete this->nonIndexedCondition;
	if (this->originalCondition != NULL)
		delete this->originalCondition;
}

/**
 * Access Method
 * Get the name of the XML document to be queried
 */
char* MarkedPatternTreeSelectionNode::getFileName()
{
	return this->fileName;
}

/**
 * Access Method
 * Get the type of node being selected.
 */
int MarkedPatternTreeSelectionNode::getNodeType()
{
	return this->nodeType;
}

/**
 * Access Method
 * Get the element tag
 */
char* MarkedPatternTreeSelectionNode::getElementTag()
{
	return this->elementTag;
}

/**
 * Access Method
 * Get the name of the attribute. 
 */
char* MarkedPatternTreeSelectionNode::getAttributeName()
{
	return this->attrName;
}

/**
 * Access Method
 * Get the index matching status
 */
int MarkedPatternTreeSelectionNode::getIndexStatus()
{
	return this->indexStatus;
}

/**
 * Access Method
 * Get the index matching number.
 */
int MarkedPatternTreeSelectionNode::getIndexMatchingNumber()
{
	return this->indexMatchingNumber;
}

/**
 * Access Method
 * Get the index matching info for all index matchings. 
 */
IndexMatchingInfo** MarkedPatternTreeSelectionNode::getIndexMatchingInfo()
{
	return this->imInfo;
}

/**
 * Access Method
 * Get the index matching info for one index matching. 
 */
IndexMatchingInfo* MarkedPatternTreeSelectionNode::getIndexMatchingInfoAt(int i)
{
	if ((i<0) || (i>=this->indexMatchingNumber))
		return NULL;
	else return this->imInfo[i];
}

/**
 * Access Method
 * Get original selection condition. 
 */
SelectionCondition* MarkedPatternTreeSelectionNode::getOriginalCondition()
{
	return this->originalCondition;
}


/**
 * Access Method
 * Get unindexed condition. 
 */
SelectionCondition* MarkedPatternTreeSelectionNode::getNonIndexedCondition()
{
	return this->nonIndexedCondition;
}

/**
 * Access Method
 * get the info about whether a value (content) index is used to evaluate the node
 */
bool MarkedPatternTreeSelectionNode::useValueIndex()
{
	bool vIndexUsed = false;
	
	if ((this->indexStatus == FULLY_INDEXED)
		|| (this->indexStatus == PARTIALLY_INDEXED))
	{
		for (int i=0; i< this->indexMatchingNumber; i++)
		{
			if (this->imInfo[i]->isValueIndex())
			{
				vIndexUsed = true;
				break;
			}
		}
	}

	return vIndexUsed;
}


/**
 * Debug Method
 * Print the information of the Marked pattern tree selection node. 
 */
void MarkedPatternTreeSelectionNode::printPtNode()
{
	((PatternTreeNode*) this)->printPtNode();

	cout << "XML file name: " << this->fileName << endl;
	cout << "Node Type: ";
	switch (this->nodeType)
	{
	case DOCUMENT_NODE: cout << "DOCUMENT_NODE" << endl; break;
	case ELEMENT_NODE: cout << "ELEMENT_NODE" << endl; break;
	case ATTRIBUTE_NODE: cout << "ATTRIBUTE_NODE" << endl; break;
	}

	cout << "index status: ";
	switch (this->indexStatus)
	{
	case FULLY_INDEXED: 
		cout << "FULLY INDEXED" << endl;
		cout << "Index Number: " << this->indexMatchingNumber << endl;
		for (int i=0; i< this->indexMatchingNumber; i++)
		{
			cout << "Index Matching No. " << i << endl;
			this->imInfo[i]->printIndexMatchingInfo();
		}
		break;

	case PARTIALLY_INDEXED:
		cout << "PARTIALLY INDEXED" << endl; 

		cout << "Index Number: " << this->indexMatchingNumber << endl;
		for (int i=0; i< this->indexMatchingNumber; i++)
		{
			cout << "Index Matching No. " << i << endl;
			this->imInfo[i]->printIndexMatchingInfo();
		}

		if (this->indexStatus == PARTIALLY_INDEXED)
			this->nonIndexedCondition->printSelectionCondition();

		break;
		
	case NO_INDEX: 
		cout << "NO INDEX" << endl; 
		this->nonIndexedCondition->printSelectionCondition();
		break;

	default: 
		cout << "index status is not one of NO_INDEX, FULLY_INDEXED and PARTIALLY_INDEXED" << endl; 
		break;
	}

	cout << "element tag: ";
	if (this->elementTag != NULL)
		cout << this->elementTag << endl;
	else cout << "NULL" << endl;

	cout << "Attribute name: ";
	if (this->attrName != NULL)
		cout << this->attrName << endl;
	else cout << "NULL" << endl;
}
