/**
COPYRIGHT  � 2000-2004
THE REGENTS OF THE UNIVERSITY OF MICHIGAN ALL RIGHTS RESERVED

PERMISSION IS GRANTED TO USE, COPY, CREATE DERIVATIVE WORKS A
ND REDISTRIBUTE THIS SOFTWARE AND SUCH DERIVATIVE WORKS FOR 
NONCOMMERCIAL EDUCATION AND RESEARCH PURPOSES, SO LONG AS NO 
FEE IS CHARGED, AND SO LONG AS THE COPYRIGHT NOTICE ABOVE, 
THIS GRANT OF PERMISSION, AND THE DISCLAIMER BELOW APPEAR IN 
ALL COPIES MADE; AND SO LONG AS THE NAME OF THE UNIVERSITY OF 
MICHIGAN IS NOT USED IN ANY ADVERTISING OR PUBLICITY PERTAINING 
TO THE USE OR DISTRIBUTION OF THIS SOFTWARE WITHOUT SPECIFIC, 
WRITTEN PRIOR AUTHORIZATION.

THIS SOFTWARE IS PROVIDED AS IS, WITHOUT REPRESENTATION FROM 
THE UNIVERSITY OF MICHIGAN AS TO ITS FITNESS FOR ANY PURPOSE, 
AND WITHOUT WARRANTY BY THE UNIVERSITY OF MICHIGAN OF ANY KIND, 
EITHER EXPRESS OR IMPLIED, INCLUDING WITHOUT LIMITATION THE 
IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A 
PARTICULAR PURPOSE. THE REGENTS OF THE UNIVERSITY OF MICHIGAN 
SHALL NOT BE LIABLE FOR ANY DAMAGES, INCLUDING SPECIAL, INDIRECT, 
INCIDENTAL, OR CONSEQUENTIAL DAMAGES, WITH RESPECT TO ANY CLAIM 
ARISING OUT OF OR IN CONNECTION WITH THE USE OF THE SOFTWARE, 
EVEN IF IT HAS BEEN OR IS HEREAFTER ADVISED OF THE POSSIBILITY 
OF SUCH DAMAGES.
*/

#ifndef __MarkedPatternTreeSelectionNode_H
#define __MarkedPatternTreeSelectionNode_H

#include "PatternTreeSelectionNode.h"
#include "IndexMatchingInfo.h"

/**
 * Indicate the index matching status for a selection node. 
 */
#define FULLY_INDEXED		0
#define PARTIALLY_INDEXED	1
#define NO_INDEX			2

/**
 * class MarkedPatternTreeSelectionNode
 *
 * This node is a sub-class of the PatternTreeNode
 *
 * A selection node turned into a marked selection node after index matching
 * This node contains the index matching status, the index name, start
 * end searching key, and the condition that can not be satisfied
 * by the matching index. 
 * 
 *@see PatternTreeNode
 *
 *@author: Yuqing Melanie Wu
 */
class MarkedPatternTreeSelectionNode : public PatternTreeNode
{
public:
	MarkedPatternTreeSelectionNode(void);
	MarkedPatternTreeSelectionNode(PatternTreeSelectionNode* ptNode, 
		int indexStatus,
		int imNum,
		IndexMatchingInfo** im,
		SelectionCondition* condleft);

	~MarkedPatternTreeSelectionNode(void);

	char* getFileName();
	int getNodeType();
	char* getElementTag();
	char* getAttributeName();

	int getIndexStatus();

	int getIndexMatchingNumber();
	IndexMatchingInfo** getIndexMatchingInfo();
	IndexMatchingInfo* getIndexMatchingInfoAt(int i);

	SelectionCondition* getNonIndexedCondition();
	SelectionCondition* getOriginalCondition();

	bool useValueIndex();
	void printPtNode();

private:
	/**
	 * The name of the XML document to be queried. 
	 */
	char fileName[MAX_FILE_NAME_LENGTH];
	
	/**
	 * The type of node this selection is targeting at. 
	 * possible values are: DOCUMENT_NODE, ELEMENT_NODE, ATTRIBUTE_NODE
	 */
	int nodeType;

	/**
	 * The element tag, if the target of the selection is an element node
	 * One usage of this field is to be provided later for matching join index
	 */
	char* elementTag;

	/**
	 * The attribute name, if the target of the selection is a attribute node. 
	 */
	char* attrName;

	/**
	 * Index matching status. possible values are: 
	 *	FULLY_INDEXED, PARTIALLY_INDEXED, NO_INDEX	
	 */
	int indexStatus;

	int indexMatchingNumber;
	IndexMatchingInfo** imInfo;

	/**
	 * The condition that can not be satisfied by the index scan.
	 */
	SelectionCondition* nonIndexedCondition;

	/**
	 * The original seleciton condition
	 */
	SelectionCondition* originalCondition;
};

#endif