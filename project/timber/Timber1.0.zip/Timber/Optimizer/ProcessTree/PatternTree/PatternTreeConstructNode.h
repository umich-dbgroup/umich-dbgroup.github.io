/**
COPYRIGHT  � 2000-2004
THE REGENTS OF THE UNIVERSITY OF MICHIGAN ALL RIGHTS RESERVED

PERMISSION IS GRANTED TO USE, COPY, CREATE DERIVATIVE WORKS A
ND REDISTRIBUTE THIS SOFTWARE AND SUCH DERIVATIVE WORKS FOR 
NONCOMMERCIAL EDUCATION AND RESEARCH PURPOSES, SO LONG AS NO 
FEE IS CHARGED, AND SO LONG AS THE COPYRIGHT NOTICE ABOVE, 
THIS GRANT OF PERMISSION, AND THE DISCLAIMER BELOW APPEAR IN 
ALL COPIES MADE; AND SO LONG AS THE NAME OF THE UNIVERSITY OF 
MICHIGAN IS NOT USED IN ANY ADVERTISING OR PUBLICITY PERTAINING 
TO THE USE OR DISTRIBUTION OF THIS SOFTWARE WITHOUT SPECIFIC, 
WRITTEN PRIOR AUTHORIZATION.

THIS SOFTWARE IS PROVIDED AS IS, WITHOUT REPRESENTATION FROM 
THE UNIVERSITY OF MICHIGAN AS TO ITS FITNESS FOR ANY PURPOSE, 
AND WITHOUT WARRANTY BY THE UNIVERSITY OF MICHIGAN OF ANY KIND, 
EITHER EXPRESS OR IMPLIED, INCLUDING WITHOUT LIMITATION THE 
IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A 
PARTICULAR PURPOSE. THE REGENTS OF THE UNIVERSITY OF MICHIGAN 
SHALL NOT BE LIABLE FOR ANY DAMAGES, INCLUDING SPECIAL, INDIRECT, 
INCIDENTAL, OR CONSEQUENTIAL DAMAGES, WITH RESPECT TO ANY CLAIM 
ARISING OUT OF OR IN CONNECTION WITH THE USE OF THE SOFTWARE, 
EVEN IF IT HAS BEEN OR IS HEREAFTER ADVISED OF THE POSSIBILITY 
OF SUCH DAMAGES.
*/

#ifndef __PatternTreeConstructNode_H
#define __PatternTreeConstructNode_H

#include "PatternTreeReferenceNode.h"

/**
 * class PatternTreeConstructNode
 * 
 * This node is a sub-class of the PatternTreeNode
 *
 * All types of construct node in a logical plan maps to this node. 
 * 
 *@see PatternTreeNode
 *
 *@author: Yuqing Melanie Wu
 */

class PatternTreeConstructNode :
	public PatternTreeNode
{
public:
	PatternTreeConstructNode(void);

	PatternTreeConstructNode(NodeIDType id, 
		NodeIDType parent,
		int childnum, 
		NodeIDType* children,
		int constructPtTreeNodeType,
		char* tag,
		LCLType referenceNodeID,
		int constructPtOption);

	~PatternTreeConstructNode(void);

	int getConstructNodeType();
	char* getNodeTag();
	LCLType getLCLRefered();
	int getConstructPtOption();

	void printPtNode();

protected:
	/**
	 * The type of the construct node. 
	 * possible values are: 
	 *	CONSTRUCT_ELEMENT, CONSTRUCT_ATTRIBUTE, CONSTRUCT_REFERENCE
	 */
	int constructPtTreeNodeType;

	/**
	 * this is the element tag is the note type is element node
	 * or attribute name if it is an attribute
	 */
	char tag[MAX_NODETAG_LENGTH];	

	/**
	 * The LCL to refer to in order to get the value
	 * this is for CONSTRUCT_ATTRIBUTE and CONSTRUCT_REFERENCE
	 */
	LCLType lclRefered;

	/**
	 * What to take from the witness tree while constructing result
	 * possible values are: 
	 *	CONSTRUCT_OPTION_NODE, CONSTRUCT_OPTION_CONTENT, CONSTRUCT_OPTION_SUBTREE
	 */
	int constructPtOption;
};


#endif