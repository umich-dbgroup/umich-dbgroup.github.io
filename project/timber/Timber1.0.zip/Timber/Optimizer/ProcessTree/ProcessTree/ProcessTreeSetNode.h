#ifndef __ProcessTreeSetNode_H
#define __ProcessTreeSetNode_H

#include "ProcessTreeNode.h"
#include "../PatternTree/PatternTree.h"

/** 
 * class: ProcessTreeSetNode
 * This class represents a set operation node in a logical plan
 * (process tree)
 *
 *@see ProcessTreeNode
 *@author: Yuqing Melanie Wu
 */
class ProcessTreeSetNode : public ProcessTreeNode
{
public:
	ProcessTreeSetNode(NodeIDType id,
		NodeIDType parent,
		int childnum, 
		NodeIDType* children,
		int setop);

	~ProcessTreeSetNode(void);

	int getSetOp();
	void printSetNode();

	void setPatternTree(PatternTree* pttree);

private:
	/**
	 * The set operator
	 */
	int setOp;

};

#endif