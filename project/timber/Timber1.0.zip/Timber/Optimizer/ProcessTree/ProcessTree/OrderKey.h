/**
COPYRIGHT  � 2000-2004
THE REGENTS OF THE UNIVERSITY OF MICHIGAN ALL RIGHTS RESERVED

PERMISSION IS GRANTED TO USE, COPY, CREATE DERIVATIVE WORKS A
ND REDISTRIBUTE THIS SOFTWARE AND SUCH DERIVATIVE WORKS FOR 
NONCOMMERCIAL EDUCATION AND RESEARCH PURPOSES, SO LONG AS NO 
FEE IS CHARGED, AND SO LONG AS THE COPYRIGHT NOTICE ABOVE, 
THIS GRANT OF PERMISSION, AND THE DISCLAIMER BELOW APPEAR IN 
ALL COPIES MADE; AND SO LONG AS THE NAME OF THE UNIVERSITY OF 
MICHIGAN IS NOT USED IN ANY ADVERTISING OR PUBLICITY PERTAINING 
TO THE USE OR DISTRIBUTION OF THIS SOFTWARE WITHOUT SPECIFIC, 
WRITTEN PRIOR AUTHORIZATION.

THIS SOFTWARE IS PROVIDED AS IS, WITHOUT REPRESENTATION FROM 
THE UNIVERSITY OF MICHIGAN AS TO ITS FITNESS FOR ANY PURPOSE, 
AND WITHOUT WARRANTY BY THE UNIVERSITY OF MICHIGAN OF ANY KIND, 
EITHER EXPRESS OR IMPLIED, INCLUDING WITHOUT LIMITATION THE 
IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A 
PARTICULAR PURPOSE. THE REGENTS OF THE UNIVERSITY OF MICHIGAN 
SHALL NOT BE LIABLE FOR ANY DAMAGES, INCLUDING SPECIAL, INDIRECT, 
INCIDENTAL, OR CONSEQUENTIAL DAMAGES, WITH RESPECT TO ANY CLAIM 
ARISING OUT OF OR IN CONNECTION WITH THE USE OF THE SOFTWARE, 
EVEN IF IT HAS BEEN OR IS HEREAFTER ADVISED OF THE POSSIBILITY 
OF SUCH DAMAGES.
*/

#ifndef __OrderKey_H
#define __OrderKey_H


#include "../PatternTree/PatternTree.h"

/** 
 * The following three are order by specifications
 */


/**
 * This define an orderby node . 
 */
class OrderbyNode
{
public:
	// the order by node
	LCLType orderbyLCL;
	// by value or by id
	int orderbyOption;
	// ancs-desc
	int orderSpec;
	// how to treat NULL
	int nullOption;
	// if the order by node is attribute node, need to specify attr name. 
	char* attrName;

	OrderbyNode()
	{
		this->attrName = NULL;
	}

	OrderbyNode(OrderbyNode* orderbynode)
	{
		this->orderbyLCL = orderbynode->orderbyLCL;
		this->orderbyOption = orderbynode->orderbyOption;
		this->orderSpec = orderbynode->orderSpec;
		this->nullOption = orderbynode->nullOption;
		if (orderbynode->attrName == NULL)
			this->attrName = NULL;
		else 
		{
			this->attrName = new char[strlen(orderbynode->attrName)+1];
			strcpy(this->attrName, orderbynode->attrName);
		}
	}

	~OrderbyNode()
	{
		if (this->attrName != NULL)
			delete [] this->attrName;
	}

	bool equivalentTo(OrderbyNode* orderbyNode)
	{
		if (this->orderbyLCL != orderbyNode->orderbyLCL) return false;
		if (this->orderbyOption != orderbyNode->orderbyOption) return false;
		if (this->orderSpec != orderbyNode->orderSpec) return false;
		if (this->nullOption != orderbyNode->nullOption) return false;
		if (this->attrName == NULL)
			if (orderbyNode->attrName == NULL) return true;
			else return false;
		else if (orderbyNode->attrName == NULL) return false;
		else return (strcmp(this->attrName, orderbyNode->attrName) == 0);
	}


};

/**
 * class: OrderKey
 *
 * This class defines the order by key, which is a list of orderby nodes.
 */

class OrderKey
{
public: 
	OrderKey(int num, OrderbyNode** keys);
	OrderKey(OrderKey* key);
	OrderKey(LCLType onekey);
	~OrderKey();

	int getOrderbyNodeNum();
	OrderbyNode** getOrderbyNodes();
	bool sortAllByNodeKey();
	bool primarilyByStartKeyOfNode(NodeIDType nodeid);
	bool primarilyByValueOfNode(NodeIDType nodeid);
	bool orderby(NodeIDType nodeid, int valueType);
	bool covers(OrderKey* orderkey);
	void printOrderKey();

private:
	/**
	 * The number of nodes in the orderby key. 
	 */
	int orderKeyNum;
	
	/** 
	 * The order by nodes. 
	 */
	OrderbyNode** orderbyNodes;

	/**
	 * A boolean variable which indicate whether the sortby
	 * keys are all on the startkey of nodes (not value). 
	 */
	bool sortAllByStartKey;


};
#endif