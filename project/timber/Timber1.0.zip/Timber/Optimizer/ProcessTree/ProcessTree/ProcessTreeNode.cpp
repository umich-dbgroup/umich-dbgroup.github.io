/**
COPYRIGHT  � 2000-2004
THE REGENTS OF THE UNIVERSITY OF MICHIGAN ALL RIGHTS RESERVED

PERMISSION IS GRANTED TO USE, COPY, CREATE DERIVATIVE WORKS A
ND REDISTRIBUTE THIS SOFTWARE AND SUCH DERIVATIVE WORKS FOR 
NONCOMMERCIAL EDUCATION AND RESEARCH PURPOSES, SO LONG AS NO 
FEE IS CHARGED, AND SO LONG AS THE COPYRIGHT NOTICE ABOVE, 
THIS GRANT OF PERMISSION, AND THE DISCLAIMER BELOW APPEAR IN 
ALL COPIES MADE; AND SO LONG AS THE NAME OF THE UNIVERSITY OF 
MICHIGAN IS NOT USED IN ANY ADVERTISING OR PUBLICITY PERTAINING 
TO THE USE OR DISTRIBUTION OF THIS SOFTWARE WITHOUT SPECIFIC, 
WRITTEN PRIOR AUTHORIZATION.

THIS SOFTWARE IS PROVIDED AS IS, WITHOUT REPRESENTATION FROM 
THE UNIVERSITY OF MICHIGAN AS TO ITS FITNESS FOR ANY PURPOSE, 
AND WITHOUT WARRANTY BY THE UNIVERSITY OF MICHIGAN OF ANY KIND, 
EITHER EXPRESS OR IMPLIED, INCLUDING WITHOUT LIMITATION THE 
IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A 
PARTICULAR PURPOSE. THE REGENTS OF THE UNIVERSITY OF MICHIGAN 
SHALL NOT BE LIABLE FOR ANY DAMAGES, INCLUDING SPECIAL, INDIRECT, 
INCIDENTAL, OR CONSEQUENTIAL DAMAGES, WITH RESPECT TO ANY CLAIM 
ARISING OUT OF OR IN CONNECTION WITH THE USE OF THE SOFTWARE, 
EVEN IF IT HAS BEEN OR IS HEREAFTER ADVISED OF THE POSSIBILITY 
OF SUCH DAMAGES.
*/


#include "processtreenode.h"

/**
 * Default Constructor
 */
ProcessTreeNode::ProcessTreeNode(void)
{
}

/**
 * Constuctor
 * 
 * Constuct a PorcessTreeNode by called correspondant Node constructor
 * 
 *@param id The id of the node. 
 *@param parent the node id of the parent node of this node. 
 *@param childnum The number of children of the node.
 *@param children The node ids of the children of this node.
 *@param nodetype The type of the process tree node
 */
ProcessTreeNode::ProcessTreeNode(NodeIDType id,
								 NodeIDType parent,
								 int childnum, 
								 NodeIDType* children,
								 int nodetype)
								 : Node(id, parent, childnum, children)
{
	this->psTreeNodeType = nodetype;
}


/**
 * Destructor
 */
ProcessTreeNode::~ProcessTreeNode(void)
{

}

/**
 * Access Method
 * Get the process tree node type. 
 */
int ProcessTreeNode::getPsNodeType()
{
	return this->psTreeNodeType;
}

/**
 * Debug Method
 * print the information about the process tree node. 
 */
void ProcessTreeNode::printPsNode()
{
	cout << endl << "#########################" << endl;
	this->printNode();
	
	cout << "process tree node type: ";

	switch (this->psTreeNodeType)
	{
	case PROCESS_TREE_SELECT_NODE: 
		cout << "PROCESS_TREE_SELECT_NODE" << endl;
		break;
	case PROCESS_TREE_PROJECT_NODE:
		cout << "PROCESS_TREE_PROJECT_NODE" << endl;
		break;
	case PROCESS_TREE_DUPLICATE_ELIMINATION_NODE:
		cout << "PROCESS_TREE_DUPLICATE_ELIMINATION_NODE" << endl;
		break;
	case PROCESS_TREE_JOIN_NODE: 
		cout << "PROCESS_TREE_JOIN_NODE" << endl;
		break;
	case PROCESS_TREE_AGGREGATE_FUNCTION_NODE:
		cout << "PROCESS_TREE_AGGREGATE_FUNCTION_NODE" << endl;
		break;
	case PROCESS_TREE_FILTER_NODE: 
		cout << "PROCESS_TREE_FILTER_NODE" << endl;
		break;
	case PROCESS_TREE_SORT_NODE: 
		cout << "PROCESS_TREE_SORT_NODE" << endl;
		break;
	case PROCESS_TREE_SET_NODE: 
		cout << "PROCESS_TREE_SET_NODE" << endl;
		break;
	case PROCESS_TREE_CONSTRUCT_NODE:
		cout << "PROCESS_TREE_CONSTRUCT_NODE" << endl;
		break;
	case PROCESS_TREE_MLCA_NODE: 
		cout << "PROCESS_TREE_MLCA_NODE" << endl;
		break;
	case PROCESS_TREE_UPDATE_NODE: 
		cout << "PROCESS_TREE_UPDATE_NODE" << endl;
		break;
	case PROCESS_TREE_DELETE_NODE: 
		cout << "PROCESS_TREE_DELETE_NODE" << endl;
		break;
	case PROCESS_TREE_INSERT_NODE: 
		cout << "PROCESS_TREE_INSERT_NODE" << endl;
		break;

	default:
		cout << "Process tree node type " << this->psTreeNodeType
			<< " is not a valud process tree node type..." << endl;
	}


}
