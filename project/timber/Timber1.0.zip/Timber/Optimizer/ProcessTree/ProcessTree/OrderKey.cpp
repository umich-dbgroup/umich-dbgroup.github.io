/**
COPYRIGHT  � 2000-2004
THE REGENTS OF THE UNIVERSITY OF MICHIGAN ALL RIGHTS RESERVED

PERMISSION IS GRANTED TO USE, COPY, CREATE DERIVATIVE WORKS A
ND REDISTRIBUTE THIS SOFTWARE AND SUCH DERIVATIVE WORKS FOR 
NONCOMMERCIAL EDUCATION AND RESEARCH PURPOSES, SO LONG AS NO 
FEE IS CHARGED, AND SO LONG AS THE COPYRIGHT NOTICE ABOVE, 
THIS GRANT OF PERMISSION, AND THE DISCLAIMER BELOW APPEAR IN 
ALL COPIES MADE; AND SO LONG AS THE NAME OF THE UNIVERSITY OF 
MICHIGAN IS NOT USED IN ANY ADVERTISING OR PUBLICITY PERTAINING 
TO THE USE OR DISTRIBUTION OF THIS SOFTWARE WITHOUT SPECIFIC, 
WRITTEN PRIOR AUTHORIZATION.

THIS SOFTWARE IS PROVIDED AS IS, WITHOUT REPRESENTATION FROM 
THE UNIVERSITY OF MICHIGAN AS TO ITS FITNESS FOR ANY PURPOSE, 
AND WITHOUT WARRANTY BY THE UNIVERSITY OF MICHIGAN OF ANY KIND, 
EITHER EXPRESS OR IMPLIED, INCLUDING WITHOUT LIMITATION THE 
IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A 
PARTICULAR PURPOSE. THE REGENTS OF THE UNIVERSITY OF MICHIGAN 
SHALL NOT BE LIABLE FOR ANY DAMAGES, INCLUDING SPECIAL, INDIRECT, 
INCIDENTAL, OR CONSEQUENTIAL DAMAGES, WITH RESPECT TO ANY CLAIM 
ARISING OUT OF OR IN CONNECTION WITH THE USE OF THE SOFTWARE, 
EVEN IF IT HAS BEEN OR IS HEREAFTER ADVISED OF THE POSSIBILITY 
OF SUCH DAMAGES.
*/



#include "OrderKey.h"

/**
 * Constructor
 * 
 * Construct an order key, given the orderby nodes. 
 *
 *@see OrderbyNode
 *
 *@param num The number of order by nodes
 *@param orderbynodes The orderby nodes, the order of the nodes matters. 
 */
OrderKey::OrderKey(int num, 
				   OrderbyNode** orderbynodes)
{
	this->orderKeyNum = num;
	this->orderbyNodes = orderbynodes;

	this->sortAllByStartKey = true;

	for (int i=0; i<this->orderKeyNum; i++)
		if (this->orderbyNodes[i]->orderbyOption == ORDER_BY_VALUE)
		{
			this->sortAllByStartKey = false;
			break;
		}	
}

/**
 * Copy Method
 */
OrderKey::OrderKey(OrderKey* key)
{
	this->orderKeyNum = key->getOrderbyNodeNum();
	this->orderbyNodes = new OrderbyNode*[this->orderKeyNum];

	OrderbyNode** nodes = key->getOrderbyNodes();
	for (int i=0; i<this->orderKeyNum; i++)
	{
		this->orderbyNodes[i] = new OrderbyNode(nodes[i]);
	}
	this->sortAllByStartKey = key->sortAllByStartKey;
}

/**
 * Constructor
 * 
 * Construct a one node orderby key
 * The default setting is to order by the ID of the node.
 * this is used extensively to sort witness trees for structural join. 
 *
 *@param onekey The LCL of the node to be ordered by. 
 */
OrderKey::OrderKey(LCLType onekey)
{
	this->orderKeyNum = 1;
	this->orderbyNodes = new OrderbyNode*[1];

	this->orderbyNodes[0] = new OrderbyNode();
	this->orderbyNodes[0]->orderbyLCL = onekey;
	this->orderbyNodes[0]->orderbyOption = ORDER_BY_KEY;
	this->orderbyNodes[0]->orderSpec = ORDER_SPEC_ASCENDING;
	this->orderbyNodes[0]->nullOption = ORDER_NULL_GREATEST;
	this->orderbyNodes[0]->attrName = NULL;
	this->sortAllByStartKey = TRUE;
}

/**
 * Destructor
 */
OrderKey::~OrderKey()
{
	for (int i=0; i<this->orderKeyNum; i++)
		delete this->orderbyNodes[i];
	delete [] this->orderbyNodes;
}

/**
 * Access Method
 * get the number of orderby node.
 */
int OrderKey::getOrderbyNodeNum()
{
	return this->orderKeyNum;
}

/**
 * Access Method
 * get the specification of the orderby nodes
 */
OrderbyNode** OrderKey::getOrderbyNodes()
{
	return this->orderbyNodes;
}

/** 
 * Access Method
 * find out whether the sort keys are all on the startkey (node id). 
 */
bool OrderKey::sortAllByNodeKey()
{
	return this->sortAllByStartKey;
}

/**
 * Access Method
 * Check whether the witness tree is sorted by the given node, with the specified type (id or value)
 */
bool OrderKey::orderby(NodeIDType nodeid, int valueType)
{
	int retval = false;
	if (valueType == ID_VALUE)
		retval = this->primarilyByStartKeyOfNode(nodeid);
	else retval = this->primarilyByValueOfNode(nodeid);
	return retval;
}

/**
 * Access Method
 * Check whether the witness tree is sorted primarily by the start key given node
 */
bool OrderKey::primarilyByStartKeyOfNode(NodeIDType nodeid)
{
	if (this->orderKeyNum <= 0)
		return false;

	else if ((this->orderbyNodes[0]->orderbyLCL == nodeid)
		&& (this->orderbyNodes[0]->orderbyOption == ORDER_BY_KEY)
		&& (this->orderbyNodes[0]->orderSpec == ORDER_SPEC_ASCENDING)
		&& (this->orderbyNodes[0]->nullOption == ORDER_NULL_GREATEST))
		return true;

	else return false;

}

/**
 * Access Method
 * Check whether the witness tree is sorted primarily by the value of the given node
 */
bool OrderKey::primarilyByValueOfNode(NodeIDType nodeid)
{
	if (this->orderKeyNum <= 0)
		return false;

	else if ((this->orderbyNodes[0]->orderbyLCL == nodeid)
		&& (this->orderbyNodes[0]->orderbyOption == ORDER_BY_VALUE)
		&& (this->orderbyNodes[0]->orderSpec == ORDER_SPEC_ASCENDING))
		return true;

	else return false;

}

bool OrderKey::covers(OrderKey* orderkey)
{
	if (this->orderKeyNum < orderkey->getOrderbyNodeNum())
		return false;

	int odNum = orderkey->getOrderbyNodeNum();
	OrderbyNode** odNodes = orderkey->getOrderbyNodes();

	for (int i=0; i<odNum; i++)
	{
		if (!this->orderbyNodes[i]->equivalentTo(odNodes[i]))
			return false;
	}
	return true;
}


void OrderKey::printOrderKey()
{
	cout << "sort by node number: " << this->orderKeyNum << endl;
	
	for (int i=0; i< this->orderKeyNum; i++)
	{
		cout << "sort by node No. " << i << endl;
		cout << "    sort by node: " << this->orderbyNodes[i]->orderbyLCL << endl;
		cout << "    sort by : ";
		switch (this->orderbyNodes[i]->orderbyOption)
		{
		case ORDER_BY_KEY:
			cout << "ORDER_BY_KEY" << endl;
			break;
		case ORDER_BY_VALUE:
			cout << "ORDER_BY_VALUE" << endl;
			break;
		}

		cout << "    ordering: ";
		switch (this->orderbyNodes[i]->orderbyOption)
		{
		case ORDER_SPEC_ASCENDING:
			cout << "ORDER_SPEC_ASCENDING" << endl;
			break;
		case ORDER_SPEC_DESCENDING:
			cout << "ORDER_SPEC_DESCENDING" << endl;
			break;
		}
		
		cout << "    null option: ";
		switch (this->orderbyNodes[i]->orderbyOption)
		{
		case ORDER_NULL_LEAST:
			cout << "ORDER_NULL_LEAST" << endl;
			break;
		case ORDER_NULL_GREATEST:	
			cout << "ORDER_NULL_GREATEST" << endl;
			break;
		}
	}

	cout << "sort all by key: ";
	if (this->sortAllByStartKey) cout << "TRUE" << endl;
	else cout << "FALSE" << endl;

}
