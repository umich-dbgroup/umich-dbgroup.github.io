/**
COPYRIGHT  � 2000-2004
THE REGENTS OF THE UNIVERSITY OF MICHIGAN ALL RIGHTS RESERVED

PERMISSION IS GRANTED TO USE, COPY, CREATE DERIVATIVE WORKS A
ND REDISTRIBUTE THIS SOFTWARE AND SUCH DERIVATIVE WORKS FOR 
NONCOMMERCIAL EDUCATION AND RESEARCH PURPOSES, SO LONG AS NO 
FEE IS CHARGED, AND SO LONG AS THE COPYRIGHT NOTICE ABOVE, 
THIS GRANT OF PERMISSION, AND THE DISCLAIMER BELOW APPEAR IN 
ALL COPIES MADE; AND SO LONG AS THE NAME OF THE UNIVERSITY OF 
MICHIGAN IS NOT USED IN ANY ADVERTISING OR PUBLICITY PERTAINING 
TO THE USE OR DISTRIBUTION OF THIS SOFTWARE WITHOUT SPECIFIC, 
WRITTEN PRIOR AUTHORIZATION.

THIS SOFTWARE IS PROVIDED AS IS, WITHOUT REPRESENTATION FROM 
THE UNIVERSITY OF MICHIGAN AS TO ITS FITNESS FOR ANY PURPOSE, 
AND WITHOUT WARRANTY BY THE UNIVERSITY OF MICHIGAN OF ANY KIND, 
EITHER EXPRESS OR IMPLIED, INCLUDING WITHOUT LIMITATION THE 
IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A 
PARTICULAR PURPOSE. THE REGENTS OF THE UNIVERSITY OF MICHIGAN 
SHALL NOT BE LIABLE FOR ANY DAMAGES, INCLUDING SPECIAL, INDIRECT, 
INCIDENTAL, OR CONSEQUENTIAL DAMAGES, WITH RESPECT TO ANY CLAIM 
ARISING OUT OF OR IN CONNECTION WITH THE USE OF THE SOFTWARE, 
EVEN IF IT HAS BEEN OR IS HEREAFTER ADVISED OF THE POSSIBILITY 
OF SUCH DAMAGES.
*/

#ifndef __ProcessTree_H
#define __ProcessTree_H

#include "ProcessTreeSelectNode.h"
#include "ProcessTreeProjectNode.h"
#include "ProcessTreeDuplicateEliminationNode.h"
#include "ProcessTreeJoinNode.h"
#include "ProcessTreeFilterNode.h"
#include "ProcessTreeSortNode.h"
#include "ProcessTreeAggregateFunctionNode.h"
#include "ProcessTreeConstructNode.h"
#include "ProcessTreeSetNode.h"
#include "ProcessTreeMLCANode.h"
#include "ProcessTreeInsertNode.h"
#include "ProcessTreeUpdateNode.h"
#include "ProcessTreeDeleteNode.h"



#include "../Tree/Tree.h"

/**
 * Class: ProcessTree
 * 
 * A process tree is a logical plan that evaluate a query. 
 * It is the input to query optimizer. 
 * 
 *@see ProcessTreeNode
 *@see PatternTree
 *
 *@author: Yuqing Melanie Wu
 */
class ProcessTree : public Tree
{
public:
	ProcessTree(void);

	ProcessTree(TreeIDType id, 
		NodeIDType root, 
		int nodenum,
		ProcessTreeNode** nodes);

	ProcessTree(TreeIDType id, 
		NodeIDType root, 
		int nodeNum, 
		NodeIDType* nodeids, 
		ProcessTreeNode** nodes);

	~ProcessTree(void);

	ProcessTreeNode* getRoot();

	ProcessTreeNode* getPsNodeWithID(NodeIDType id);
	ProcessTreeNode* getPsNodeAtIndex(int index);
	ProcessTreeNode* getPsNodeWithPtTreeRootAs(LCLType lcl);
	PatternTreeNode* getPtNodeWithID(NodeIDType id);
	PatternTreeNode* getPtNodeWithLCL(LCLType lcl);
	PatternTree* getPtTreeRootedAtLCL(LCLType lcl);

	void printPsTree();

private:
};

#endif