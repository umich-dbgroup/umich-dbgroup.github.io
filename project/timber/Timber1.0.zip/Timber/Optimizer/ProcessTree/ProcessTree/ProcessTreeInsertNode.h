/**
COPYRIGHT  � 2000-2004
THE REGENTS OF THE UNIVERSITY OF MICHIGAN ALL RIGHTS RESERVED

PERMISSION IS GRANTED TO USE, COPY, CREATE DERIVATIVE WORKS A
ND REDISTRIBUTE THIS SOFTWARE AND SUCH DERIVATIVE WORKS FOR 
NONCOMMERCIAL EDUCATION AND RESEARCH PURPOSES, SO LONG AS NO 
FEE IS CHARGED, AND SO LONG AS THE COPYRIGHT NOTICE ABOVE, 
THIS GRANT OF PERMISSION, AND THE DISCLAIMER BELOW APPEAR IN 
ALL COPIES MADE; AND SO LONG AS THE NAME OF THE UNIVERSITY OF 
MICHIGAN IS NOT USED IN ANY ADVERTISING OR PUBLICITY PERTAINING 
TO THE USE OR DISTRIBUTION OF THIS SOFTWARE WITHOUT SPECIFIC, 
WRITTEN PRIOR AUTHORIZATION.

THIS SOFTWARE IS PROVIDED AS IS, WITHOUT REPRESENTATION FROM 
THE UNIVERSITY OF MICHIGAN AS TO ITS FITNESS FOR ANY PURPOSE, 
AND WITHOUT WARRANTY BY THE UNIVERSITY OF MICHIGAN OF ANY KIND, 
EITHER EXPRESS OR IMPLIED, INCLUDING WITHOUT LIMITATION THE 
IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A 
PARTICULAR PURPOSE. THE REGENTS OF THE UNIVERSITY OF MICHIGAN 
SHALL NOT BE LIABLE FOR ANY DAMAGES, INCLUDING SPECIAL, INDIRECT, 
INCIDENTAL, OR CONSEQUENTIAL DAMAGES, WITH RESPECT TO ANY CLAIM 
ARISING OUT OF OR IN CONNECTION WITH THE USE OF THE SOFTWARE, 
EVEN IF IT HAS BEEN OR IS HEREAFTER ADVISED OF THE POSSIBILITY 
OF SUCH DAMAGES.
*/

#ifndef __ProcessTreeInsertNode_H
#define __ProcessTreeInsertNode_H

#include "ProcessTreeNode.h"
#include "../PatternTree/PatternTree.h"

/** 
 * This structure represents a insert unit
 */
class InsertValueUnit {
public: 
	InsertValueUnit()
	{
		this->name = NULL;
		this->constValue = NULL;
		this->attrName = NULL;
	}

	~InsertValueUnit() 
	{
		if (this->name != NULL) delete [] this->name;
		if (this->constValue != NULL) delete this->constValue;
		if (this->attrName != NULL) delete [] this->attrName;
	}
	/** 
	 * The name, it maybe an element tag or an attribute name
	 */
	char* name; 
	/**
	 * Where the element content or attribute value comes from
	 * It may be a constant or an LCL
	 */
	int valueSource; 
	/**
	 * The LCL if the value source is LCL.
	 */
	LCLType LCL;
	/**
	 * The attribute name of the value source, in case the LCL refers to an attribute node
	 */
	char* attrName;
	/*
	 * The content, if the value source is constant value.
	 */
	Value* constValue;
} ;

/**
 * class: ProcessTreeInsertNode
 * This class represent an insert operation in a logical plan 
 * (Process tree).
 *@see ProcessTreeNode
 *@author: Yuqing Melanie Wu
 */
class ProcessTreeInsertNode : public ProcessTreeNode
{
public:
	ProcessTreeInsertNode(NodeIDType id,
		NodeIDType parent,
		int childnum, 
		NodeIDType* children,
		LCLType parentLCL,
		int insertOpt,
		char* filename,
		InsertValueUnit* element,
		int attrnum, 
		InsertValueUnit** attrs);

	~ProcessTreeInsertNode(void);

	LCLType getParentLCL();
	int getInsertOption();
	char* getXMLFileName();
	InsertValueUnit* getElement();
	int getAttributeNumber();
	InsertValueUnit** getAttributes();

	void printInsertNode();

private:
	/**
	 * Where the new nodes should be inserted
	 * it will be the last child of the node that matches the LCL
	 */
	LCLType parentLCL;
	/**
	 * Insert option. Possible values are: 
	 * INSERT_FILE: the content of the file will becomes the subtree
	 * under the parent node
	 * INSERT_ELEMENT: The new node will be a child of the parent node.
	 * INSERT_ATTRIBUTE: An Attribute will be inserted to be the attribute of the parent node. 
	 */ 
	int insertOpt;
	/**
	 * The name of the file, if INSERT_FILE
	 */
	char* fileName;
	/**
	 * The element, if INSERT_ELEMENT
	 */
	InsertValueUnit* element;
	/** 
	 * The number of attributes that that new node has
	 */
	int attrNum;
	/**
	 * The attributes
	 */
	InsertValueUnit** attributes;
};

#endif