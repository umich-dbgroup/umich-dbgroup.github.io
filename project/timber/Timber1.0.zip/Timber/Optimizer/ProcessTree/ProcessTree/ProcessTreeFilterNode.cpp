/**
COPYRIGHT  � 2000-2004
THE REGENTS OF THE UNIVERSITY OF MICHIGAN ALL RIGHTS RESERVED

PERMISSION IS GRANTED TO USE, COPY, CREATE DERIVATIVE WORKS A
ND REDISTRIBUTE THIS SOFTWARE AND SUCH DERIVATIVE WORKS FOR 
NONCOMMERCIAL EDUCATION AND RESEARCH PURPOSES, SO LONG AS NO 
FEE IS CHARGED, AND SO LONG AS THE COPYRIGHT NOTICE ABOVE, 
THIS GRANT OF PERMISSION, AND THE DISCLAIMER BELOW APPEAR IN 
ALL COPIES MADE; AND SO LONG AS THE NAME OF THE UNIVERSITY OF 
MICHIGAN IS NOT USED IN ANY ADVERTISING OR PUBLICITY PERTAINING 
TO THE USE OR DISTRIBUTION OF THIS SOFTWARE WITHOUT SPECIFIC, 
WRITTEN PRIOR AUTHORIZATION.

THIS SOFTWARE IS PROVIDED AS IS, WITHOUT REPRESENTATION FROM 
THE UNIVERSITY OF MICHIGAN AS TO ITS FITNESS FOR ANY PURPOSE, 
AND WITHOUT WARRANTY BY THE UNIVERSITY OF MICHIGAN OF ANY KIND, 
EITHER EXPRESS OR IMPLIED, INCLUDING WITHOUT LIMITATION THE 
IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A 
PARTICULAR PURPOSE. THE REGENTS OF THE UNIVERSITY OF MICHIGAN 
SHALL NOT BE LIABLE FOR ANY DAMAGES, INCLUDING SPECIAL, INDIRECT, 
INCIDENTAL, OR CONSEQUENTIAL DAMAGES, WITH RESPECT TO ANY CLAIM 
ARISING OUT OF OR IN CONNECTION WITH THE USE OF THE SOFTWARE, 
EVEN IF IT HAS BEEN OR IS HEREAFTER ADVISED OF THE POSSIBILITY 
OF SUCH DAMAGES.
*/



#include "processtreefilternode.h"

/**
 * Constructor
 * construct a filter node by calling the constructor of 
 * ProcessTreeNode
 *@see ProcessTreeNode::ProcessTreeNode
 */
ProcessTreeFilterNode
::ProcessTreeFilterNode(NodeIDType id,	
						NodeIDType parent,
						int childnum,
						NodeIDType* children,
						int ornum, 
						int* andnums,
						PO_FilterPredicate*** filtercond)										 
						: ProcessTreeNode(id, parent, childnum, children,
						PROCESS_TREE_FILTER_NODE)
{
	this->orNum = ornum;
	this->andNums = andnums;
	this->filterCondition = filtercond;
}

/** 
 * Destructor   
 */
ProcessTreeFilterNode::~ProcessTreeFilterNode(void)
{
	for (int i=0; i<this->orNum; i++)
	{
		for (int j=0; j<this->andNums[i]; j++)
			delete this->filterCondition[i][j];
		delete [] this->filterCondition[i];
	}
	delete [] this->filterCondition;
	delete [] this->andNums;		
}

/** 
 * Access method
 * Get the number of ORs in the filter condition
 */
int ProcessTreeFilterNode::getOrNum()
{
	return this->orNum;
}

/**
 * Access method
 * Get the number of ANDs for all the conjunctive expressions. 
 */
int* ProcessTreeFilterNode::getAndNums()
{
	return this->andNums;
}

/**
 * Access method
 * Get the number of ANDs in the i'th conjunctive expression
 * in the disjunctive form of the filter condition. 
 */
int ProcessTreeFilterNode::getAndNumAt(int i)
{
	return this->andNums[i];
}

/**
 * Access Method
 * Get all the filter predicates in the filter condition
 */
PO_FilterPredicate*** ProcessTreeFilterNode::getFilterCondition()
{
	return this->filterCondition;
}

/** Access Method
 * get the filter predicate which is in the j'th position in the
 * conjunctive expression that is at the i'th position in the disjunctive
 * expression.
 */
PO_FilterPredicate* ProcessTreeFilterNode::getFilterPredicateAt(int i, int j)
{
	return this->filterCondition[i][j];
}

/**
 * Debug Method
 * Print the content of a filter node
 */
void ProcessTreeFilterNode::printFilterNode()
{
	this->printPsNode();
	 
	cout << "Number of CNF predicates: " << this->orNum << endl;

	for (int i=0; i<this->orNum; i++)
	{
		cout << "CNF No. " << i << endl;
		cout << "   Number of CNF predicates: " << this->andNums[i] << endl;
		
		for (int j=0; j<this->andNums[i]; j++)
		{
			cout << "Predicate No. " << j << endl;

			cout << "      Filter left value: " << "LCL:" 
				 << this->filterCondition[i][j]->leftValueLCL << endl;
	
			cout << "      Filter operator's data type: ";
			switch (this->filterCondition[i][j]->filterOperatorDataType)
			{
			case INT_VALUE:		cout << "integer" << endl;	break;
			case STRING_VALUE:	cout << "string" << endl;	break;
			case REAL_VALUE:	cout << "float" << endl;	break;
			case ID_VALUE:		cout << "start key" << endl; break;
			}

			cout << "      Filter operator: ";
			switch (this->filterCondition[i][j]->filterOperator)
			{
			case SCAN_OP_EQ: cout << "=" << endl; break;
			case SCAN_OP_NE: cout << "!=" << endl; break;
			case SCAN_OP_GT: cout << ">" << endl; break;
			case SCAN_OP_GE: cout << ">=" << endl; break;
			case SCAN_OP_LT: cout << "<" << endl; break;
			case SCAN_OP_LE: cout << "<=" << endl; break;
			}

			cout << "      Filter right value: ";
			
			switch (this->filterCondition[i][j]->rightValueOption)
			{
			case REFERENCE_VALUE: 
				cout << "LCL:" << this->filterCondition[i][j]->rightValueLCL << endl;
				break;
			case CONSTANT_VALUE:
				{
					char* valStr = this->filterCondition[i][j]->rightValueConstant->valueToString();
					cout << valStr << endl;
					delete [] valStr;
				}
				break;
			}

			cout << "      Filter Option: ";
			switch (this->filterCondition[i][j]->filterOption)
			{
			case FILTER_OPTION_EVERY:
				cout << "EVERY" << endl;
				break;

			case FILTER_OPTION_SOME:
				cout << "SOME" << endl;
				break;

			case FILTER_OPTION_EXACTLYONE:
				cout << "EXACTLYONE" << endl;
				break;
			}
			cout << endl;
		}
	}
}