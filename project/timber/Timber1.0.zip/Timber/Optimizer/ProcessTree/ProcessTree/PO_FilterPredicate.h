/**
COPYRIGHT  � 2000-2004
THE REGENTS OF THE UNIVERSITY OF MICHIGAN ALL RIGHTS RESERVED

PERMISSION IS GRANTED TO USE, COPY, CREATE DERIVATIVE WORKS A
ND REDISTRIBUTE THIS SOFTWARE AND SUCH DERIVATIVE WORKS FOR 
NONCOMMERCIAL EDUCATION AND RESEARCH PURPOSES, SO LONG AS NO 
FEE IS CHARGED, AND SO LONG AS THE COPYRIGHT NOTICE ABOVE, 
THIS GRANT OF PERMISSION, AND THE DISCLAIMER BELOW APPEAR IN 
ALL COPIES MADE; AND SO LONG AS THE NAME OF THE UNIVERSITY OF 
MICHIGAN IS NOT USED IN ANY ADVERTISING OR PUBLICITY PERTAINING 
TO THE USE OR DISTRIBUTION OF THIS SOFTWARE WITHOUT SPECIFIC, 
WRITTEN PRIOR AUTHORIZATION.

THIS SOFTWARE IS PROVIDED AS IS, WITHOUT REPRESENTATION FROM 
THE UNIVERSITY OF MICHIGAN AS TO ITS FITNESS FOR ANY PURPOSE, 
AND WITHOUT WARRANTY BY THE UNIVERSITY OF MICHIGAN OF ANY KIND, 
EITHER EXPRESS OR IMPLIED, INCLUDING WITHOUT LIMITATION THE 
IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A 
PARTICULAR PURPOSE. THE REGENTS OF THE UNIVERSITY OF MICHIGAN 
SHALL NOT BE LIABLE FOR ANY DAMAGES, INCLUDING SPECIAL, INDIRECT, 
INCIDENTAL, OR CONSEQUENTIAL DAMAGES, WITH RESPECT TO ANY CLAIM 
ARISING OUT OF OR IN CONNECTION WITH THE USE OF THE SOFTWARE, 
EVEN IF IT HAS BEEN OR IS HEREAFTER ADVISED OF THE POSSIBILITY 
OF SUCH DAMAGES.
*/

#ifndef __PO_FilterPredicate_H
#define __PO_FilterPredicate_H


/**
 * This class represent a filter predicate in the logical plan
 * in the Optimizer
 */
class PO_FilterPredicate
{
public:
	PO_FilterPredicate()
	{
		this->leftAttrName = NULL;
		this->rightAttrName = NULL;
		this->rightValueConstant = NULL;
		this->useJoinIndex = false;
		this->fileName = NULL;
		this->indexName = NULL;
	}
	~PO_FilterPredicate()
	{
		if (this->leftAttrName != NULL)
			delete [] this->leftAttrName;
		if (this->rightAttrName != NULL)
			delete [] this->rightAttrName;
		if (this->rightValueConstant != NULL)
			delete this->rightValueConstant;

		if (useJoinIndex)
		{
			delete [] this->fileName;
			delete [] this->indexName;
		}

	}

	/**
	 * The left value (LCL)
	 */
	LCLType leftValueLCL;		
	/**
	 * The attribute node, if the LCL maps to an attribute name
	 */
	char* leftAttrName;			 
	/**
	 * The data type for the operator
	 */
	int filterOperatorDataType;
	/**
	 * The comparison operator
	 */
	int filterOperator;
	/** 
	 * The option for the right value, it can be a reference (LCL)
	 * or a constant value
	 */
	int rightValueOption;
	/**
	 * A LCL as right value
	 */
	LCLType rightValueLCL;
	/**
	 * The attribute node, if the LCL maps to an attribute name
	 */
	char* rightAttrName;			 
	/**
	 * A constant value, as right value
	 */
	Value* rightValueConstant;
	/** 
	 * The filter operator
	 * possible values are: FILTER_OPTION_EVERY, FILTER_OPTION_SOME
	 * FILETER_OPTION_EXACTLYONE
	 */
	int filterOption; 

	bool useJoinIndex;
	char* fileName;
	char* indexName;

} ;

#endif