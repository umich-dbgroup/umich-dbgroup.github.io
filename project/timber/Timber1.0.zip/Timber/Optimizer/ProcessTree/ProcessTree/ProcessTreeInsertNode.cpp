/**
COPYRIGHT  � 2000-2004
THE REGENTS OF THE UNIVERSITY OF MICHIGAN ALL RIGHTS RESERVED

PERMISSION IS GRANTED TO USE, COPY, CREATE DERIVATIVE WORKS A
ND REDISTRIBUTE THIS SOFTWARE AND SUCH DERIVATIVE WORKS FOR 
NONCOMMERCIAL EDUCATION AND RESEARCH PURPOSES, SO LONG AS NO 
FEE IS CHARGED, AND SO LONG AS THE COPYRIGHT NOTICE ABOVE, 
THIS GRANT OF PERMISSION, AND THE DISCLAIMER BELOW APPEAR IN 
ALL COPIES MADE; AND SO LONG AS THE NAME OF THE UNIVERSITY OF 
MICHIGAN IS NOT USED IN ANY ADVERTISING OR PUBLICITY PERTAINING 
TO THE USE OR DISTRIBUTION OF THIS SOFTWARE WITHOUT SPECIFIC, 
WRITTEN PRIOR AUTHORIZATION.

THIS SOFTWARE IS PROVIDED AS IS, WITHOUT REPRESENTATION FROM 
THE UNIVERSITY OF MICHIGAN AS TO ITS FITNESS FOR ANY PURPOSE, 
AND WITHOUT WARRANTY BY THE UNIVERSITY OF MICHIGAN OF ANY KIND, 
EITHER EXPRESS OR IMPLIED, INCLUDING WITHOUT LIMITATION THE 
IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A 
PARTICULAR PURPOSE. THE REGENTS OF THE UNIVERSITY OF MICHIGAN 
SHALL NOT BE LIABLE FOR ANY DAMAGES, INCLUDING SPECIAL, INDIRECT, 
INCIDENTAL, OR CONSEQUENTIAL DAMAGES, WITH RESPECT TO ANY CLAIM 
ARISING OUT OF OR IN CONNECTION WITH THE USE OF THE SOFTWARE, 
EVEN IF IT HAS BEEN OR IS HEREAFTER ADVISED OF THE POSSIBILITY 
OF SUCH DAMAGES.
*/


#include "ProcessTreeInsertNode.h"

/**
 * Constructor
 * construct a process tree insert node by calling the constructor
 * of ProcessTreeNode
 */

ProcessTreeInsertNode
::ProcessTreeInsertNode(NodeIDType id,
						NodeIDType parent,
						int childnum, 
						NodeIDType* children,
						LCLType parentlcl, 
						int insertOpt,
						char* filename,
						InsertValueUnit* element,
						int attrnum, 
						InsertValueUnit** attrs)
						: ProcessTreeNode(id, parent, childnum, children, 
						PROCESS_TREE_INSERT_NODE)
{
	this->parentLCL = parentlcl;
	this->insertOpt = insertOpt;
	switch (insertOpt)
	{
	case INSERT_FILE:
		this->fileName = new char[strlen(filename)+1];
		strcpy(this->fileName, filename);
		this->element = NULL;
		this->attrNum = 0;
		this->attributes = NULL;
		break;
		
	case INSERT_ELEMENT:
		this->fileName = NULL;
		this->element = element;
		this->attrNum = attrnum;
		this->attributes = attrs;
		break;

	case INSERT_ATTRIBUTE:
		this->fileName = NULL;
		this->element = NULL;
		this->attrNum = attrnum;
		this->attributes = attrs;
		break;
	}
}


/** 
 * Destructor
 */
ProcessTreeInsertNode::~ProcessTreeInsertNode(void)
{
	switch (this->insertOpt)
	{
	case INSERT_FILE: 
		delete [] this->fileName;
		break;
	case INSERT_ELEMENT:
		delete this->element;
		if (this->attrNum > 0)
		{
			for (int i=0; i<this->attrNum; i++)
				delete this->attributes[i];
			delete [] this->attributes;
		}
		break;
	case INSERT_ATTRIBUTE:
		if (this->attrNum > 0)
		{
			for (int i=0; i<this->attrNum; i++)
				delete this->attributes[i];
			delete [] this->attributes;
		}
		break;
	}
}

/**
 * Access Method
 * Get the LCL of the node that acts as parent node in the insertion
 */
LCLType ProcessTreeInsertNode::getParentLCL()
{
	return this->parentLCL;
}

/**
 * Access Method
 * Get insert option
 */
int ProcessTreeInsertNode::getInsertOption()
{
	return this->insertOpt;
}

/**
 * Access Method
 * Get the name of the MXL file to be inserted
 */
char* ProcessTreeInsertNode::getXMLFileName()
{
	return this->fileName;
}

/** 
 * Access Method
 * Get the element to be inserted
 */
InsertValueUnit* ProcessTreeInsertNode::getElement()
{
	return this->element;
}

/**
 * Access Method
 * Get the number of attribute of the element to be inserted. 
 */
int ProcessTreeInsertNode::getAttributeNumber()
{
	return this->attrNum;
}

/**
 * Access Method
 * Get the attributes of the elements to be inserted
 */
InsertValueUnit** ProcessTreeInsertNode::getAttributes()
{
	return this->attributes;
}

/**
 * Debug Method
 * Print the content of an insert node
 */
void ProcessTreeInsertNode::printInsertNode()
{
	this->printPsNode();

	cout << "Insert Option: " ;
	switch (insertOpt)
	{
	case INSERT_FILE:
		cout << "INESRT_FILE" << endl;
		cout << "filename: " << this->fileName << endl;
		break;
		
	case INSERT_ELEMENT:
		{
			cout << "INESRT_ELEMENT" << endl;
			cout << "element name: " << this->element->name << endl;
			cout << "element content: ";
			switch (this->element->valueSource)
			{
			case CONSTANT_VALUE:
				cout << "constant value: " << this->element->constValue->getStrValue() << endl;
				break;
			case REFERENCE_VALUE: 
				cout << "refer to LCL " << this->element->LCL << endl;
			}	

			cout << "attribute number: " << this->attrNum<< endl;

			for (int i=0; i< this->attrNum; i++)
			{
				cout << "   Attribute No. " << i+1 << ":" << endl;
				cout << "       name: " << this->attributes[i]->name << endl;
				cout << "       value: ";
				switch (this->attributes[i]->valueSource)
				{
				case CONSTANT_VALUE:
					cout << "constant value: " << this->attributes[i]->constValue->getStrValue() << endl;
					break;
				case REFERENCE_VALUE: 
					cout << "refer to LCL " << this->attributes[i]->LCL << endl;
				}		
			}
		}
		break;
	}
}