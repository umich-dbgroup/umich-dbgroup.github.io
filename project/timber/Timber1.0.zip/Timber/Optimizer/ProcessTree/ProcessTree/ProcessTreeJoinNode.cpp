/**
COPYRIGHT  � 2000-2004
THE REGENTS OF THE UNIVERSITY OF MICHIGAN ALL RIGHTS RESERVED

PERMISSION IS GRANTED TO USE, COPY, CREATE DERIVATIVE WORKS A
ND REDISTRIBUTE THIS SOFTWARE AND SUCH DERIVATIVE WORKS FOR 
NONCOMMERCIAL EDUCATION AND RESEARCH PURPOSES, SO LONG AS NO 
FEE IS CHARGED, AND SO LONG AS THE COPYRIGHT NOTICE ABOVE, 
THIS GRANT OF PERMISSION, AND THE DISCLAIMER BELOW APPEAR IN 
ALL COPIES MADE; AND SO LONG AS THE NAME OF THE UNIVERSITY OF 
MICHIGAN IS NOT USED IN ANY ADVERTISING OR PUBLICITY PERTAINING 
TO THE USE OR DISTRIBUTION OF THIS SOFTWARE WITHOUT SPECIFIC, 
WRITTEN PRIOR AUTHORIZATION.

THIS SOFTWARE IS PROVIDED AS IS, WITHOUT REPRESENTATION FROM 
THE UNIVERSITY OF MICHIGAN AS TO ITS FITNESS FOR ANY PURPOSE, 
AND WITHOUT WARRANTY BY THE UNIVERSITY OF MICHIGAN OF ANY KIND, 
EITHER EXPRESS OR IMPLIED, INCLUDING WITHOUT LIMITATION THE 
IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A 
PARTICULAR PURPOSE. THE REGENTS OF THE UNIVERSITY OF MICHIGAN 
SHALL NOT BE LIABLE FOR ANY DAMAGES, INCLUDING SPECIAL, INDIRECT, 
INCIDENTAL, OR CONSEQUENTIAL DAMAGES, WITH RESPECT TO ANY CLAIM 
ARISING OUT OF OR IN CONNECTION WITH THE USE OF THE SOFTWARE, 
EVEN IF IT HAS BEEN OR IS HEREAFTER ADVISED OF THE POSSIBILITY 
OF SUCH DAMAGES.
*/

#include "ProcessTreeJoinNode.h"

/**
 * Constructor
 * construct a process tree join node by calling the constructor 
 * of ProcessTreeNode
 */
ProcessTreeJoinNode
::ProcessTreeJoinNode(NodeIDType id,
					  NodeIDType parent,
					  int childnum, 
					  NodeIDType* children,
					  PatternTree* pttree)
					  : ProcessTreeNode(id, parent, childnum, children, 
					  PROCESS_TREE_JOIN_NODE)
{
	this->ptTree = pttree;
}

/**
 * Destructor
 */
ProcessTreeJoinNode::~ProcessTreeJoinNode(void)
{
	delete this->ptTree;
}

/**
 * Access Method
 * Get the pattern tree associated with the join node
 */
PatternTree* ProcessTreeJoinNode::getPatternTree()
{
	return this->ptTree;
}

/**
 * Debug Method
 * print the content of a process tree join node
 */
void ProcessTreeJoinNode::printJoinNode()
{
	this->printPsNode();

	cout << "associated pattern tree: " << endl;
	this->ptTree->printPtTree();
}