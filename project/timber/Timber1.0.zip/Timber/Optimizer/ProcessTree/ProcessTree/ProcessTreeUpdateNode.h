/**
COPYRIGHT  � 2000-2004
THE REGENTS OF THE UNIVERSITY OF MICHIGAN ALL RIGHTS RESERVED

PERMISSION IS GRANTED TO USE, COPY, CREATE DERIVATIVE WORKS A
ND REDISTRIBUTE THIS SOFTWARE AND SUCH DERIVATIVE WORKS FOR 
NONCOMMERCIAL EDUCATION AND RESEARCH PURPOSES, SO LONG AS NO 
FEE IS CHARGED, AND SO LONG AS THE COPYRIGHT NOTICE ABOVE, 
THIS GRANT OF PERMISSION, AND THE DISCLAIMER BELOW APPEAR IN 
ALL COPIES MADE; AND SO LONG AS THE NAME OF THE UNIVERSITY OF 
MICHIGAN IS NOT USED IN ANY ADVERTISING OR PUBLICITY PERTAINING 
TO THE USE OR DISTRIBUTION OF THIS SOFTWARE WITHOUT SPECIFIC, 
WRITTEN PRIOR AUTHORIZATION.

THIS SOFTWARE IS PROVIDED AS IS, WITHOUT REPRESENTATION FROM 
THE UNIVERSITY OF MICHIGAN AS TO ITS FITNESS FOR ANY PURPOSE, 
AND WITHOUT WARRANTY BY THE UNIVERSITY OF MICHIGAN OF ANY KIND, 
EITHER EXPRESS OR IMPLIED, INCLUDING WITHOUT LIMITATION THE 
IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A 
PARTICULAR PURPOSE. THE REGENTS OF THE UNIVERSITY OF MICHIGAN 
SHALL NOT BE LIABLE FOR ANY DAMAGES, INCLUDING SPECIAL, INDIRECT, 
INCIDENTAL, OR CONSEQUENTIAL DAMAGES, WITH RESPECT TO ANY CLAIM 
ARISING OUT OF OR IN CONNECTION WITH THE USE OF THE SOFTWARE, 
EVEN IF IT HAS BEEN OR IS HEREAFTER ADVISED OF THE POSSIBILITY 
OF SUCH DAMAGES.
*/

#ifndef __ProcessTreeUpdateNode_H
#define __ProcessTreeUpdateNode_H

#include "ProcessTreeNode.h"
#include "../PatternTree/PatternTree.h"

/**
 * class: ProcessTreeUpdateNode
 *
 * This class represent an update node in a logical plan (process tree). 
 *
 *@see ProcessTreeNode
 *@author: Yuqing Melanie Wu
 */
class ProcessTreeUpdateNode : public ProcessTreeNode
{
public:
	ProcessTreeUpdateNode(NodeIDType id,
		NodeIDType parent,
		int childnum, 
		NodeIDType* children,
		LCLType targetlcl,
		int updateopt,
		LCLType referedlcl,
		Value* value);

	~ProcessTreeUpdateNode(void);

	LCLType getTargetLCL();
	int getUpdateOption();
	LCLType getReferedLCL();
	Value* getUpdateConst();

	void printUpdateNode();

private:
	/**
	 * The LCL of the node to be updated
	 */
	LCLType targetLCL;
	/**
	 * Where the new value comes from. it can be a reference (LCL)
	 * or a constant. 
	 */
	int updateOption;
	/**
	 * the LCL which provides the new value for update
	 */
	LCLType referedLCL;
	/** 
	 * the constant value to be used to replace old value
	 */
	Value* updateConstant;

};

#endif