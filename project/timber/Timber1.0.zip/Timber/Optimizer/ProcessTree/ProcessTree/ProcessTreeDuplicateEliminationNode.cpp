/**
COPYRIGHT  � 2000-2004
THE REGENTS OF THE UNIVERSITY OF MICHIGAN ALL RIGHTS RESERVED

PERMISSION IS GRANTED TO USE, COPY, CREATE DERIVATIVE WORKS A
ND REDISTRIBUTE THIS SOFTWARE AND SUCH DERIVATIVE WORKS FOR 
NONCOMMERCIAL EDUCATION AND RESEARCH PURPOSES, SO LONG AS NO 
FEE IS CHARGED, AND SO LONG AS THE COPYRIGHT NOTICE ABOVE, 
THIS GRANT OF PERMISSION, AND THE DISCLAIMER BELOW APPEAR IN 
ALL COPIES MADE; AND SO LONG AS THE NAME OF THE UNIVERSITY OF 
MICHIGAN IS NOT USED IN ANY ADVERTISING OR PUBLICITY PERTAINING 
TO THE USE OR DISTRIBUTION OF THIS SOFTWARE WITHOUT SPECIFIC, 
WRITTEN PRIOR AUTHORIZATION.

THIS SOFTWARE IS PROVIDED AS IS, WITHOUT REPRESENTATION FROM 
THE UNIVERSITY OF MICHIGAN AS TO ITS FITNESS FOR ANY PURPOSE, 
AND WITHOUT WARRANTY BY THE UNIVERSITY OF MICHIGAN OF ANY KIND, 
EITHER EXPRESS OR IMPLIED, INCLUDING WITHOUT LIMITATION THE 
IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A 
PARTICULAR PURPOSE. THE REGENTS OF THE UNIVERSITY OF MICHIGAN 
SHALL NOT BE LIABLE FOR ANY DAMAGES, INCLUDING SPECIAL, INDIRECT, 
INCIDENTAL, OR CONSEQUENTIAL DAMAGES, WITH RESPECT TO ANY CLAIM 
ARISING OUT OF OR IN CONNECTION WITH THE USE OF THE SOFTWARE, 
EVEN IF IT HAS BEEN OR IS HEREAFTER ADVISED OF THE POSSIBILITY 
OF SUCH DAMAGES.
*/



#include "processtreeduplicateeliminationnode.h"

/**
 * Constructor
 * constrct a duplicate elimination node by calling the constructor
 * of ProcessTreeNode
 *@see ProcessTreeNode::ProcessTreeNode
 */
ProcessTreeDuplicateEliminationNode
::ProcessTreeDuplicateEliminationNode(NodeIDType id,
									  NodeIDType parent,
									  int childnum,
									  NodeIDType* children,
									  int deOpt,
									  LCLType lcl)
: ProcessTreeNode(id, parent, childnum, children, PROCESS_TREE_DUPLICATE_ELIMINATION_NODE)
{
	this->duplicateEliminationOption = deOpt;
	this->deLCL = lcl;
}																		 

/**
 * Destructor
 */
ProcessTreeDuplicateEliminationNode::~ProcessTreeDuplicateEliminationNode(void)
{
}


/**
 * Access Method
 * Get the duplicate elimination option
 */
int ProcessTreeDuplicateEliminationNode::getDEOption()
{
	return this->duplicateEliminationOption;
}

/**
 * Access Method
 * Get the LCL of the node to perform duplication elimination on
 */
LCLType ProcessTreeDuplicateEliminationNode::getDELCL()
{
	return this->deLCL;
}

/**
 * Debug Method
 * Print the content of a duplicate elimination node
 */
void ProcessTreeDuplicateEliminationNode::printDENode()
{
	this->printPsNode();

	cout << "duplicate elimination option: ";
	switch (this->duplicateEliminationOption)
	{
	case OPERATE_ON_ID: 
		cout << "ID" << endl;
		cout << "The root of the tree is " << this->deLCL << endl;
		break;

	case OPERATE_ON_CONTENT: 
		cout << "CONTENT" << endl;
		cout << "The node to eliminate duplicate value on is " << this->deLCL << endl;
		break;
	}
}
