/**
COPYRIGHT  � 2000-2004
THE REGENTS OF THE UNIVERSITY OF MICHIGAN ALL RIGHTS RESERVED

PERMISSION IS GRANTED TO USE, COPY, CREATE DERIVATIVE WORKS A
ND REDISTRIBUTE THIS SOFTWARE AND SUCH DERIVATIVE WORKS FOR 
NONCOMMERCIAL EDUCATION AND RESEARCH PURPOSES, SO LONG AS NO 
FEE IS CHARGED, AND SO LONG AS THE COPYRIGHT NOTICE ABOVE, 
THIS GRANT OF PERMISSION, AND THE DISCLAIMER BELOW APPEAR IN 
ALL COPIES MADE; AND SO LONG AS THE NAME OF THE UNIVERSITY OF 
MICHIGAN IS NOT USED IN ANY ADVERTISING OR PUBLICITY PERTAINING 
TO THE USE OR DISTRIBUTION OF THIS SOFTWARE WITHOUT SPECIFIC, 
WRITTEN PRIOR AUTHORIZATION.

THIS SOFTWARE IS PROVIDED AS IS, WITHOUT REPRESENTATION FROM 
THE UNIVERSITY OF MICHIGAN AS TO ITS FITNESS FOR ANY PURPOSE, 
AND WITHOUT WARRANTY BY THE UNIVERSITY OF MICHIGAN OF ANY KIND, 
EITHER EXPRESS OR IMPLIED, INCLUDING WITHOUT LIMITATION THE 
IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A 
PARTICULAR PURPOSE. THE REGENTS OF THE UNIVERSITY OF MICHIGAN 
SHALL NOT BE LIABLE FOR ANY DAMAGES, INCLUDING SPECIAL, INDIRECT, 
INCIDENTAL, OR CONSEQUENTIAL DAMAGES, WITH RESPECT TO ANY CLAIM 
ARISING OUT OF OR IN CONNECTION WITH THE USE OF THE SOFTWARE, 
EVEN IF IT HAS BEEN OR IS HEREAFTER ADVISED OF THE POSSIBILITY 
OF SUCH DAMAGES.
*/



#include "processtree.h"

/**
 * Default Constructor
 */
ProcessTree::ProcessTree(void)
{
}

/**
 * Constructor
 * Construct an instance of the class, given the tree id, root node id,
 * node numbers and the process tree nodes. 
 * 
 *@param id The id of the process tree. 
 *@param root The id of the root node in the process tree. 
 *@param nodenum The number of process tree nodes in the process tree. 
 *@param psnodes The list of process tree nodes in the tree. 
 */
ProcessTree::ProcessTree(TreeIDType id, 
						 NodeIDType root, 
						 int nodenum,
						 ProcessTreeNode** psnodes)
						 : Tree(id, root, nodenum, (Node**) psnodes)
{
}


ProcessTree::ProcessTree(TreeIDType id,
						 NodeIDType root, 
						 int nodeNum, 
						 NodeIDType* nodeids, 
						 ProcessTreeNode** nodes)
						 : Tree(id, root, nodeNum, nodeids, (Node**) nodes)
{

}

/**
 * Destructor
 */
ProcessTree::~ProcessTree(void)
{
	for (int i=0; i<this->nodeNumber; i++)
	{
		int nodetype = ((ProcessTreeNode*) this->nodes[i])->getPsNodeType();
		switch (nodetype)
		{
		case PROCESS_TREE_SELECT_NODE:
			delete ((ProcessTreeSelectNode*) this->nodes[i]);
			break;

		case PROCESS_TREE_PROJECT_NODE:
			delete ((ProcessTreeProjectNode*) this->nodes[i]);
			break;

		case PROCESS_TREE_DUPLICATE_ELIMINATION_NODE:
			delete ((ProcessTreeDuplicateEliminationNode*) this->nodes[i]);
			break;

		case PROCESS_TREE_JOIN_NODE:
			delete ((ProcessTreeJoinNode*) this->nodes[i]);
			break;

		case PROCESS_TREE_AGGREGATE_FUNCTION_NODE:
			delete ((ProcessTreeAggregateFunctionNode*) this->nodes[i]);
			break;

		case PROCESS_TREE_FILTER_NODE:
			delete ((ProcessTreeFilterNode*) this->nodes[i]);
			break;

		case PROCESS_TREE_SORT_NODE:
			delete ((ProcessTreeSortNode*) this->nodes[i]);
			break;

		case PROCESS_TREE_SET_NODE:
			delete ((ProcessTreeSetNode*) this->nodes[i]);
			break;

		case PROCESS_TREE_CONSTRUCT_NODE:
			delete ((ProcessTreeConstructNode*) this->nodes[i]);
			break;

		case PROCESS_TREE_MLCA_NODE:
			delete ((ProcessTreeMLCANode*) this->nodes[i]);
			break;

		case PROCESS_TREE_UPDATE_NODE:
			delete ((ProcessTreeUpdateNode*) this->nodes[i]);
			break;

		case PROCESS_TREE_DELETE_NODE:
			delete ((ProcessTreeDeleteNode*) this->nodes[i]);
			break;

		case PROCESS_TREE_INSERT_NODE:
			delete ((ProcessTreeInsertNode*) this->nodes[i]);
			break;
		}
	}

	delete [] this->nodes;

	this->nodeNumber = 0;
	this->nodes = NULL;
}

/** 
 * Access Method
 * Get the root node of the process tree. 
 */
ProcessTreeNode* ProcessTree::getRoot()
{
	return (ProcessTreeNode*) this->getNodeWithID(root);
}

/**
 * Access Method
 * Get the process tree node with a given id. 
 */
ProcessTreeNode* ProcessTree::getPsNodeWithID(NodeIDType id)
{
	return (ProcessTreeNode*) this->getNodeWithID(id);
}

/**
 * Access Method
 * Get the process tree node at a given position in the node list
 */
ProcessTreeNode* ProcessTree::getPsNodeAtIndex(int i)
{
	return (ProcessTreeNode*) this->getNodeAtIndex(i);
}

/** 
 * Access Method
 * Get the process tree node which contains a pattern tree whose root has the given LCL.
 */
ProcessTreeNode* ProcessTree::getPsNodeWithPtTreeRootAs(LCLType lcl)
{
	// loop through all the process tree nodes. 
	for (int i=0; i<this->nodeNumber; i++)
	{
		// get the process tree node
		ProcessTreeNode* psNode = (ProcessTreeNode*) this->nodes[i];

		// get the pattern tree in the process tree node, if there is any. 
		PatternTree* ptTree;
		if (psNode->getPsNodeType() == PROCESS_TREE_SELECT_NODE) 
			ptTree = ((ProcessTreeSelectNode*) psNode)->getPatternTree();
		else if (psNode->getPsNodeType() == PROCESS_TREE_JOIN_NODE)
			ptTree = ((ProcessTreeJoinNode*) psNode)->getPatternTree();
		else continue;

		if (ptTree->getRoot()->getLCL() == lcl)
			return psNode;
	}
	return NULL;
}

/**
 * Access Method
 * Get the pattern tree node with a given node id. 
 * 
 * This requires a searching through all the process tree nodes
 * that may contains a pattern tree, and look for the pattern tree
 * node in the pattern tree, till such a node is found, or till
 * all pattern trees are searched. 
 */
PatternTreeNode* ProcessTree::getPtNodeWithID(NodeIDType id)
{
	// loop through all the process tree nodes. 
	for (int i=0; i<this->nodeNumber; i++)
	{
		// get the process tree node
		ProcessTreeNode* psNode = (ProcessTreeNode*) this->nodes[i];

		// get the pattern tree in the process tree node, if there is any. 
		PatternTree* ptTree;
		if (psNode->getPsNodeType() == PROCESS_TREE_SELECT_NODE) 
			ptTree = ((ProcessTreeSelectNode*) psNode)->getPatternTree();
		else if (psNode->getPsNodeType() == PROCESS_TREE_JOIN_NODE)
			ptTree = ((ProcessTreeJoinNode*) psNode)->getPatternTree();
		else continue;

		// look for pattern tree node with the given LCL
		PatternTreeNode* ptNode;
		ptNode = ptTree->getPtNodeWithID(id);
		if (ptNode == NULL)
			continue;
		else return ptNode;
	}
	return NULL;
}

/**
 * Access Method
 * Get the pattern tree node with a given LCL. 
 * 
 * This requires a searching through all the process tree nodes
 * that may contains a pattern tree, and look for the pattern tree
 * node in the pattern tree, till such a node is found, or till
 * all pattern trees are searched. 
 */
PatternTreeNode* ProcessTree::getPtNodeWithLCL(LCLType LCL)
{
	// loop through all the process tree nodes. 
	for (int i=0; i<this->nodeNumber; i++)
	{
		// get the process tree node
		ProcessTreeNode* psNode = (ProcessTreeNode*) this->nodes[i];

		// get the pattern tree in the process tree node, if there is any. 
		PatternTree* ptTree;
		if (psNode->getPsNodeType() == PROCESS_TREE_SELECT_NODE) 
			ptTree = ((ProcessTreeSelectNode*) psNode)->getPatternTree();
		else if (psNode->getPsNodeType() == PROCESS_TREE_JOIN_NODE)
			ptTree = ((ProcessTreeJoinNode*) psNode)->getPatternTree();
		else continue;

		// look for pattern tree node with the given LCL
		PatternTreeNode* ptNode;
		ptNode = ptTree->getPtNodeWithLCL(LCL);
		if (ptNode == NULL)
			continue;
		else return ptNode;
	}
	return NULL;
}


/**
 * Access Method
 * Get the pattern tree whose root node has the given LCL. 
 * 
 * This requires a searching through all the process tree nodes
 * that may contains a pattern tree.
 */
PatternTree* ProcessTree::getPtTreeRootedAtLCL(LCLType lcl)
{
	// loop through all the process tree nodes. 
	for (int i=0; i<this->nodeNumber; i++)
	{
		// get the process tree node
		ProcessTreeNode* psNode = (ProcessTreeNode*) this->nodes[i];

		// get the pattern tree in the process tree node, if there is any. 
		PatternTree* ptTree;
		if (psNode->getPsNodeType() == PROCESS_TREE_SELECT_NODE) 
			ptTree = ((ProcessTreeSelectNode*) psNode)->getPatternTree();
		else if (psNode->getPsNodeType() == PROCESS_TREE_JOIN_NODE)
			ptTree = ((ProcessTreeJoinNode*) psNode)->getPatternTree();
		else continue;

		if (ptTree->getRoot()->getLCL() == lcl)
			return ptTree;
	}
	return NULL;
}



/** 
 * Debug Method
 * Print the content of a process tree
 */

void ProcessTree::printPsTree()
{
	int i;

	cout << endl << endl << "--------------- Process Tree ----------------" << endl;
	cout << "Process Tree ID: " << this->treeID << endl;
	cout << "Process Tree Node number: " << this->nodeNumber << endl;
	cout << "Root Node ID: " << this->root << endl;
	cout << "ProcessTreeNodes: " << endl;

	for (i=0; i< this->nodeNumber; i++)
	{
		ProcessTreeNode* psNode = (ProcessTreeNode*)(this->nodes[i]);

		switch (psNode->getPsNodeType())
		{
		case PROCESS_TREE_SELECT_NODE:
			((ProcessTreeSelectNode*) psNode)->printSelectionNode();
			break;

		case PROCESS_TREE_PROJECT_NODE:
			((ProcessTreeProjectNode*) psNode)->printProjectionNode();
			break;

		case PROCESS_TREE_DUPLICATE_ELIMINATION_NODE:
			((ProcessTreeDuplicateEliminationNode*) psNode)->printDENode();
			break;

		case PROCESS_TREE_JOIN_NODE:
			((ProcessTreeJoinNode*) psNode)->printJoinNode();
			break;

		case PROCESS_TREE_AGGREGATE_FUNCTION_NODE:
			((ProcessTreeAggregateFunctionNode*) psNode)->printAggregateFunctionNode();
			break;

		case PROCESS_TREE_FILTER_NODE:
			((ProcessTreeFilterNode*) psNode)->printFilterNode();
			break;

		case PROCESS_TREE_SORT_NODE:
			((ProcessTreeSortNode*) psNode)->printSortNode();
			break;

		case PROCESS_TREE_SET_NODE:
			((ProcessTreeSetNode*) psNode)->printSetNode();
			break;

		case PROCESS_TREE_CONSTRUCT_NODE:
			((ProcessTreeConstructNode*) psNode)->printConstructNode();
			break;

		case PROCESS_TREE_MLCA_NODE:
			((ProcessTreeMLCANode*) psNode)->printMLCANode();
			break;

		case PROCESS_TREE_DELETE_NODE:
			((ProcessTreeDeleteNode*) psNode)->printDeleteNode();
			break;

		case PROCESS_TREE_UPDATE_NODE:
			((ProcessTreeUpdateNode*) psNode)->printUpdateNode();
			break;

		case PROCESS_TREE_INSERT_NODE:
			((ProcessTreeInsertNode*) psNode)->printInsertNode();
			break;

		default: 
			cout << "Can not print process tree node of type " << psNode->getPsNodeType() << endl;
			break;
		}
	}

}
