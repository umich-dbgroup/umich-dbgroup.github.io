/**
COPYRIGHT  � 2000-2004
THE REGENTS OF THE UNIVERSITY OF MICHIGAN ALL RIGHTS RESERVED

PERMISSION IS GRANTED TO USE, COPY, CREATE DERIVATIVE WORKS A
ND REDISTRIBUTE THIS SOFTWARE AND SUCH DERIVATIVE WORKS FOR 
NONCOMMERCIAL EDUCATION AND RESEARCH PURPOSES, SO LONG AS NO 
FEE IS CHARGED, AND SO LONG AS THE COPYRIGHT NOTICE ABOVE, 
THIS GRANT OF PERMISSION, AND THE DISCLAIMER BELOW APPEAR IN 
ALL COPIES MADE; AND SO LONG AS THE NAME OF THE UNIVERSITY OF 
MICHIGAN IS NOT USED IN ANY ADVERTISING OR PUBLICITY PERTAINING 
TO THE USE OR DISTRIBUTION OF THIS SOFTWARE WITHOUT SPECIFIC, 
WRITTEN PRIOR AUTHORIZATION.

THIS SOFTWARE IS PROVIDED AS IS, WITHOUT REPRESENTATION FROM 
THE UNIVERSITY OF MICHIGAN AS TO ITS FITNESS FOR ANY PURPOSE, 
AND WITHOUT WARRANTY BY THE UNIVERSITY OF MICHIGAN OF ANY KIND, 
EITHER EXPRESS OR IMPLIED, INCLUDING WITHOUT LIMITATION THE 
IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A 
PARTICULAR PURPOSE. THE REGENTS OF THE UNIVERSITY OF MICHIGAN 
SHALL NOT BE LIABLE FOR ANY DAMAGES, INCLUDING SPECIAL, INDIRECT, 
INCIDENTAL, OR CONSEQUENTIAL DAMAGES, WITH RESPECT TO ANY CLAIM 
ARISING OUT OF OR IN CONNECTION WITH THE USE OF THE SOFTWARE, 
EVEN IF IT HAS BEEN OR IS HEREAFTER ADVISED OF THE POSSIBILITY 
OF SUCH DAMAGES.
*/


#include "node.h"

/**
 * Default Constructor
 */
Node::Node(void)
{
}

/**
 * Constructor
 * 
 * Construct a node, given the node id, parent id, and node ids of 
 * the children.
 *@param id The node id. 
 *@param parent The id of the parent node, "-1" is there is no parent. 
 *@param childnum The number of children. 
 *@param children The node ids of the children. 
 */
Node::Node(NodeIDType id, 
		   NodeIDType parent, 
		   int childnum, 
		   NodeIDType* children)
{
	this->nodeID = id;
	this->parent = parent;
	this->childNumber = childnum;

	// use 20 or the given childnum (if larger than 20) as the 
	// initial slot number, extend it as node number exceed 
	// this on insertaion. 
	if (this->childNumber > 20)
		this->slotNumber = this->childNumber;
	else this->slotNumber = 20;

	this->children = new NodeIDType[this->slotNumber];  
	for (int i=0; i<childnum; i++)
		this->children[i] = children[i];
}

Node::~Node(void)
{
	delete [] this->children;
}

/**
 * Access Method
 * Get the id of the node. 
 */
NodeIDType Node::getNodeID()
{
	return this->nodeID;
}

/**
 * Access Method
 * Get the id of the parent of the node. 
 */
NodeIDType Node::getParentID()
{
	return this->parent;
}

/**
 * Access Method
 * Get the numberf of children of the node. 
 */
int Node::getChildNumber()
{
	return this->childNumber;
}

/**
 * Access Method
 * Get the node id list of the children of the node. 
 */
NodeIDType* Node::getChildren()
{
	return this->children;
}

/**
 * Access Method
 * Get the id of the i'th child of the node. 
 * return -1 if i is less than 0 or larger than the total child number. 
 */
NodeIDType Node::getChildIDAt(int i)
{
	if ((i>=0) && (i<this->childNumber))
		return this->children[i];
	else return -1;
}

/**
 * Access Method
 * Set the parent id of the node. 
 */
void Node::setParentID(NodeIDType parentid)
{
	this->parent = parentid;
}

/**
 * Access Method
 * Insert a child to the node. 
 * Make it the last child of the node, and set the parent id to the 
 * child node. 
 */
void Node::insertChild(Node* child)
{
	// expend the list if needed
	if (this->childNumber == this->slotNumber)
	{
		int newSlotNum = this->slotNumber * 2;
		NodeIDType* newChildList = new NodeIDType[newSlotNum];
		for (int i=0; i<this->childNumber; i++)
			newChildList[i] = this->children[i];
		delete [] this->children;
		this->children = newChildList;
		this->slotNumber = newSlotNum;
	}

	this->children[this->childNumber] = child->getNodeID();
	this->childNumber++;
	child->setParentID(this->nodeID);
}

/**
 * Debug Method
 * Get the inforamtion about the node, including:
 * node id, parent id, child number and the id of the children. 
 */
void Node::printNode()
{
	cout << "Node: id=" << this->nodeID
		 << ", parent=" << this->parent << endl;

	cout << ", childnum=" << this->childNumber
		 << ", children=(";
	for (int i=0; i<this->childNumber; i++)
	{
		cout << this->children[i];
		if (i != this->childNumber-1)
			cout << ",";
	}
	cout << ")" << endl;
		 
}
