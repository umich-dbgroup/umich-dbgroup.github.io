/**
COPYRIGHT  � 2000-2004
THE REGENTS OF THE UNIVERSITY OF MICHIGAN ALL RIGHTS RESERVED

PERMISSION IS GRANTED TO USE, COPY, CREATE DERIVATIVE WORKS A
ND REDISTRIBUTE THIS SOFTWARE AND SUCH DERIVATIVE WORKS FOR 
NONCOMMERCIAL EDUCATION AND RESEARCH PURPOSES, SO LONG AS NO 
FEE IS CHARGED, AND SO LONG AS THE COPYRIGHT NOTICE ABOVE, 
THIS GRANT OF PERMISSION, AND THE DISCLAIMER BELOW APPEAR IN 
ALL COPIES MADE; AND SO LONG AS THE NAME OF THE UNIVERSITY OF 
MICHIGAN IS NOT USED IN ANY ADVERTISING OR PUBLICITY PERTAINING 
TO THE USE OR DISTRIBUTION OF THIS SOFTWARE WITHOUT SPECIFIC, 
WRITTEN PRIOR AUTHORIZATION.

THIS SOFTWARE IS PROVIDED AS IS, WITHOUT REPRESENTATION FROM 
THE UNIVERSITY OF MICHIGAN AS TO ITS FITNESS FOR ANY PURPOSE, 
AND WITHOUT WARRANTY BY THE UNIVERSITY OF MICHIGAN OF ANY KIND, 
EITHER EXPRESS OR IMPLIED, INCLUDING WITHOUT LIMITATION THE 
IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A 
PARTICULAR PURPOSE. THE REGENTS OF THE UNIVERSITY OF MICHIGAN 
SHALL NOT BE LIABLE FOR ANY DAMAGES, INCLUDING SPECIAL, INDIRECT, 
INCIDENTAL, OR CONSEQUENTIAL DAMAGES, WITH RESPECT TO ANY CLAIM 
ARISING OUT OF OR IN CONNECTION WITH THE USE OF THE SOFTWARE, 
EVEN IF IT HAS BEEN OR IS HEREAFTER ADVISED OF THE POSSIBILITY 
OF SUCH DAMAGES.
*/


#include "tree.h"

/**
 * Default construction
 */
Tree::Tree(void)
{
}

/*
 * Constructor
 *
 * Construct a tree, given nodeids in a compacted list and the nodes
 * in a sparse list. 
 *@param id The id of the tree.
 *@param root The node id of the root node.
 *@param nodeNum The number of nodes in the tree.
 *@param nodeids The list of node ids -- the id of the nodes in the tree.
 *@param nodes The list of nodes, each node is stored in a slot based on its id. 
 */
Tree::Tree(TreeIDType id, 
		   NodeIDType root, 
		   int nodeNum,
		   NodeIDType* nodeids,
		   Node** nodes)
{
	this->treeID = id;
	this->root = root;
	
	this->nodeNumber = nodeNum;
	this->nodes = new Node*[nodeNum];
	for (int i=0; i<nodeNum; i++)
	{
		this->nodes[i] = nodes[nodeids[i]];
	}
}

/*
 * Constructor
 *
 * Construct a tree, given a compacted list of nodes.
 *@param id The id of the tree.
 *@param root The node id of the root node.
 *@param nodeNum The number of nodes in the tree.
 *@param nodes The list of nodes, in a compact list. 
 */
Tree::Tree(TreeIDType id,
		   NodeIDType root, 
		   int nodeNum, 
		   Node** nodes)
{
	this->treeID = id;
	this->root = root;

	this->nodeNumber = nodeNum;
	this->nodes = new Node*[nodeNum];
	for (int i=0; i<nodeNum; i++)
	{
		this->nodes[i] = nodes[i];
	}
}

/**
 * Destruction should be taken care of by the sub-classes.
 */
Tree::~Tree()
{
	if (this->nodes != NULL)
	{
		for (int i=0; i<this->nodeNumber; i++)
			delete this->nodes[i];
		delete [] this->nodes;
	}
}

/**
 * Access Method
 *
 * Get the tree id. 
 */

TreeIDType Tree::getTreeID()
{
	return this->treeID;
}

/**
 * Access Method
 *
 * Get the root node id. 
 */
NodeIDType Tree::getRootID()
{
	return this->root;
}

/**
 * Access Method
 *
 * Get the number of nodes in the tree. 
 */
int Tree::getNodeNumber()
{
	return this->nodeNumber;
}

/**
 * Access Method
 *
 * Get the the node with the given id. 
 */
Node* Tree::getNodeWithID(NodeIDType id)
{
	for (int i=0; i<this->nodeNumber; i++)
	{
		if (this->nodes[i]->getNodeID() == id)
			return this->nodes[i];
	}
	return NULL;
}

/**
 * Access Method
 *
 * Get the the node at the given position in the node list
 */
Node* Tree::getNodeAtIndex(int i)
{
	if ((i<0) || (i>=nodeNumber))
		return NULL;
	else return this->nodes[i];
}

/**
 * Access Method
 *
 * Get the position of the node in the node list, given a node id. 
 */
int Tree::getIndexOfNodeWithID(NodeIDType id)
{
	for (int i=0; i<this->nodeNumber; i++)
		if (this->nodes[i]->getNodeID() == id)
			return i;
	return -1;
}

/**
 * Access Method
 *
 * Check whether the tree contains a node with the given id. 
 */
bool Tree::nodeIsInTree(NodeIDType id)
{
	int index = this->getIndexOfNodeWithID(id);
	return (index >= 0);
}

/**
 * Access Method
 *
 * reset a node. 
 * This method is not responsible to release the space assigned to the
 * old node. whoever replace the node with a new one is in responsible 
 * for this. 
 */
void Tree::setNodeWithID(NodeIDType id,
						 Node* node)
{
	int index = this->getIndexOfNodeWithID(id);
	if (index >= 0)
		this->nodes[index] = node;
}

/**
 * Debug Method
 *
 * Print the information about the tree, including: 
 * the tree id, the root node id, the number of nodes. 
 * For each node, print the node id and the parent node id. 
 */
void Tree::printTree()
{
	cout << "Tree: id=" << this->treeID 
		<< ", root=" << this->root 
		<< ", nodenum=" << this->nodeNumber 
		<< endl;
	for (int i=0; i<this->nodeNumber; i++)
	{
		cout << "	nodeid = " << this->nodes[i]->getNodeID()
			 << ", parentid = " << this->nodes[i]->getParentID() << endl;
	}
}
