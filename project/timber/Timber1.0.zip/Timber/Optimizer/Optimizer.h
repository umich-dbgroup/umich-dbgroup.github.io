/**
COPYRIGHT  � 2000-2004
THE REGENTS OF THE UNIVERSITY OF MICHIGAN ALL RIGHTS RESERVED

PERMISSION IS GRANTED TO USE, COPY, CREATE DERIVATIVE WORKS A
ND REDISTRIBUTE THIS SOFTWARE AND SUCH DERIVATIVE WORKS FOR 
NONCOMMERCIAL EDUCATION AND RESEARCH PURPOSES, SO LONG AS NO 
FEE IS CHARGED, AND SO LONG AS THE COPYRIGHT NOTICE ABOVE, 
THIS GRANT OF PERMISSION, AND THE DISCLAIMER BELOW APPEAR IN 
ALL COPIES MADE; AND SO LONG AS THE NAME OF THE UNIVERSITY OF 
MICHIGAN IS NOT USED IN ANY ADVERTISING OR PUBLICITY PERTAINING 
TO THE USE OR DISTRIBUTION OF THIS SOFTWARE WITHOUT SPECIFIC, 
WRITTEN PRIOR AUTHORIZATION.

THIS SOFTWARE IS PROVIDED AS IS, WITHOUT REPRESENTATION FROM 
THE UNIVERSITY OF MICHIGAN AS TO ITS FITNESS FOR ANY PURPOSE, 
AND WITHOUT WARRANTY BY THE UNIVERSITY OF MICHIGAN OF ANY KIND, 
EITHER EXPRESS OR IMPLIED, INCLUDING WITHOUT LIMITATION THE 
IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A 
PARTICULAR PURPOSE. THE REGENTS OF THE UNIVERSITY OF MICHIGAN 
SHALL NOT BE LIABLE FOR ANY DAMAGES, INCLUDING SPECIAL, INDIRECT, 
INCIDENTAL, OR CONSEQUENTIAL DAMAGES, WITH RESPECT TO ANY CLAIM 
ARISING OUT OF OR IN CONNECTION WITH THE USE OF THE SOFTWARE, 
EVEN IF IT HAS BEEN OR IS HEREAFTER ADVISED OF THE POSSIBILITY 
OF SUCH DAMAGES.
*/

#ifndef __Optimizer_H
#define __Optimizer_H

#include "ProcessTree/ParserOptimizerInterface/LogicalPlanParser.h"
#include "IndexSelection/IndexSelection.h"
#include "EvaluationPlanGenerator/SimplePlanGenerator/SimplePlanGenerator.h"


/**
 * The Optimizer class provides interface of the cost based optimizor.
 * It accept logical plan in the format of a file or a string and returns 
 * physical plan in the format of a string or a tree. 
 *
 * What is currently implemented is a simple physical plan generater. 
 * Availability based index selection is in place. 
 *
 *@author Yuqing Melanie Wu 
 */


class Optimizer
{
public:
	Optimizer(IndexMng* indexmng);
	~Optimizer(void);

	bool optimize(char* psTreeString,
		int source,
		int indexOptimizationOption,
		int planGenerationOption,
		char** evStr);

private: 
	/** 
	 * The index manager
	 */
	IndexMng* indexMng;
	
	/** 
	 * A parser that parses the input logical plan (string) and
	 * builds the logical plan tree.
	 */
	LogicalPlanParser* planParser;
	
	/**
	 * The index selector, which performs index selection.
	 */
	IndexSelection* indexSelector;

	/** 
	 * The simple plan generator.
	 */
	SimplePlanGenerator* simpleGen;

	/**
	 * The logical plan (process tree), based on which the physical
	 * plan is to be built. 
	 */
	ProcessTree* PsTree;

	/**
	 * for construct the error message
	 */
	char errMsg[1000];

	/**
	 * Internal methods
	 */

	/**
	 * Given the name of the file contains the logical plan,
	 * parse it and generate the internal tree representation 
	 * of the logical plan. 
	 */
	void getPsTreeFromFile(char* psTreeFileName);

	/**
	 * Generate simple physical plan, based on the internal
	 * tree representation of the logical plan. 
	 */ 
	void generateSimplePlan();
};

#endif