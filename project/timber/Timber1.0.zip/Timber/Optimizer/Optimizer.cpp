/**
COPYRIGHT  � 2000-2004
THE REGENTS OF THE UNIVERSITY OF MICHIGAN ALL RIGHTS RESERVED

PERMISSION IS GRANTED TO USE, COPY, CREATE DERIVATIVE WORKS A
ND REDISTRIBUTE THIS SOFTWARE AND SUCH DERIVATIVE WORKS FOR 
NONCOMMERCIAL EDUCATION AND RESEARCH PURPOSES, SO LONG AS NO 
FEE IS CHARGED, AND SO LONG AS THE COPYRIGHT NOTICE ABOVE, 
THIS GRANT OF PERMISSION, AND THE DISCLAIMER BELOW APPEAR IN 
ALL COPIES MADE; AND SO LONG AS THE NAME OF THE UNIVERSITY OF 
MICHIGAN IS NOT USED IN ANY ADVERTISING OR PUBLICITY PERTAINING 
TO THE USE OR DISTRIBUTION OF THIS SOFTWARE WITHOUT SPECIFIC, 
WRITTEN PRIOR AUTHORIZATION.

THIS SOFTWARE IS PROVIDED AS IS, WITHOUT REPRESENTATION FROM 
THE UNIVERSITY OF MICHIGAN AS TO ITS FITNESS FOR ANY PURPOSE, 
AND WITHOUT WARRANTY BY THE UNIVERSITY OF MICHIGAN OF ANY KIND, 
EITHER EXPRESS OR IMPLIED, INCLUDING WITHOUT LIMITATION THE 
IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A 
PARTICULAR PURPOSE. THE REGENTS OF THE UNIVERSITY OF MICHIGAN 
SHALL NOT BE LIABLE FOR ANY DAMAGES, INCLUDING SPECIAL, INDIRECT, 
INCIDENTAL, OR CONSEQUENTIAL DAMAGES, WITH RESPECT TO ANY CLAIM 
ARISING OUT OF OR IN CONNECTION WITH THE USE OF THE SOFTWARE, 
EVEN IF IT HAS BEEN OR IS HEREAFTER ADVISED OF THE POSSIBILITY 
OF SUCH DAMAGES.
*/


#include "optimizer.h"

/*
 * Constructor
 *
 * Initialize variables. 
 */
Optimizer::Optimizer(IndexMng* indexmng)
{
	this->indexMng = indexmng;
	this->planParser = new LogicalPlanParser();
	this->indexSelector = new IndexSelection(this->indexMng);
}

/* 
 * Destructor
 * 
 * Delete all the structures that are in use. 
 */
Optimizer::~Optimizer(void)
{
	delete this->planParser;
	delete this->indexSelector;
}

/*
 * methodL optimize
 *
 * This method takes a logical plan and generates a physical plan.
 * 
 * In the current implementation (generate simple plan), the physical
 * plan is generated in two steps: index selection and plan generation.
 * 
 *@param psTreeString A string, whether to interpret the string as a
 *			file name or as process tree in string format depends on 
 *			the value of 'source' (next parameter). 
 *@param source A value which indicates how to interpret the psTreeString.
 *			possible values can be: 
 *				INPUT_FROM_FILE	This means the psTreeString is the file name.
 *				INPUT_STRING This means the psTreeString is the logical plan
 *						in string format. 
 *@param indexOpt A value that specifies how the index selection is to be done. 
 *			possible values can be: 
 *				INDEX_SELECTION_OPTION_NOINDEX	Assuming there is no index available		
 *				INDEX_SELECTION_OPTION_TAGINDEX	 Assuming there are only tag indices
 *				INDEX_SELECTION_OPTION_AVAILABILITY_BASED availability-based index selection
 *						select the index that matches the most predicates. 
 *				INDEX_SELECTION_OPTION_COST_BASED (not supported in this version). 
 *@param planGenOpt A value that sepcifies to what degree the optimization
 *			is to be done. 
 *			possible values can be: 
 *				GENERATE_SIMPLE_PLAN	Generate only simple plan.
 *				PATTERN_TREE_OPTIMIZATION  perform pattern tree optimization. (not included in this version). 
 *@param planFormatOpt A Value that specifies the format of the physical plan to 
 *			be generated
 *			possible values can be: 
 *			GENERATE_PLAN_IN_TREE	Generate physical plan in tree format.
 *			GENERATE_PLAN_IN_STRING	Generate physical plan in string.
 *			GENERATE_PLAN_IN_BOTH   Generate physical plan in both format. 
 *@param evTree (output) The evaluation plan in tree format, if the planFormatOpt
 *			is GENERATE_PLAN_IN_TREE or GENERATE_PLAN_IN_BOTH.
 *@param evStr (output) The evaluation plan in string format, if the planFormatOpt
 *			is GENERATE_PLAN_IN_STRING or GENERATE_PLAN_IN_BOTH.
 *@returns A boolean value which indicate whether the operation is 
 *			done successfully. 
 */
bool Optimizer::optimize(char* psTreeString,
						 int source, 
						 int indexOpt,
						 int planGenOpt,
						 char** evStr)
{
	bool success = false;

	switch (source)
	{
	case INPUT_STRING:
		{
			// read the string and create process tree
			std::strstream pTreeStream;
			pTreeStream << psTreeString;
			this->PsTree = this->planParser->getProcessTreeFromString(&pTreeStream);
		}
		break;

	case INPUT_FROM_FILE:
		// read the process tree from the file. 
		this->PsTree = this->planParser->getProcessTreeFromFile(psTreeString);
		break;

	default:
		sprintf(errMsg,"%d is not a valid choice for input source for process tree.",source);
		globalErrorInfo.insertProblem(ERR_TYPE_ERROR, __LINE__, 
			"Optimizer::optimize", __FILE__, 
			errMsg);
		goto exit;
	}

	if (globalErrorInfo.doWeHaveAProblem())
	{
		globalErrorInfo.insertProblem(ERR_TYPE_ERROR, __LINE__, 
			"Optimizer::optimize", __FILE__, 
			"Error happens while reading the process tree from file.");
		goto exit;
	}

#if _DEBUG
	this->PsTree->printPsTree();
#endif

	// index selection

	this->PsTree = this->indexSelector->selectIndex(this->PsTree, indexOpt);
	if (globalErrorInfo.doWeHaveAProblem())
	{
		globalErrorInfo.insertProblem(ERR_TYPE_ERROR, __LINE__, 
			"Optimizer::optimize", __FILE__, 
			"Error happends while selecting indices for node access.");
		goto exit;
	}

#if _DEBUG
	this->PsTree->printPsTree();
#endif

	// generate simple physical evaluation plan

	SimplePlanGenerator* simpleGen = new SimplePlanGenerator(this->indexMng);
	success = simpleGen->generateSimplePlan(this->PsTree, 
											planGenOpt, 
											evStr);

	delete simpleGen;

exit:
	// exit the optimization
	// release the space

	if (this->PsTree != NULL) 
		delete this->PsTree;
	return success;
}

