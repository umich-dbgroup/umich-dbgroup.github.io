/**
COPYRIGHT  � 2000-2004
THE REGENTS OF THE UNIVERSITY OF MICHIGAN ALL RIGHTS RESERVED

PERMISSION IS GRANTED TO USE, COPY, CREATE DERIVATIVE WORKS A
ND REDISTRIBUTE THIS SOFTWARE AND SUCH DERIVATIVE WORKS FOR 
NONCOMMERCIAL EDUCATION AND RESEARCH PURPOSES, SO LONG AS NO 
FEE IS CHARGED, AND SO LONG AS THE COPYRIGHT NOTICE ABOVE, 
THIS GRANT OF PERMISSION, AND THE DISCLAIMER BELOW APPEAR IN 
ALL COPIES MADE; AND SO LONG AS THE NAME OF THE UNIVERSITY OF 
MICHIGAN IS NOT USED IN ANY ADVERTISING OR PUBLICITY PERTAINING 
TO THE USE OR DISTRIBUTION OF THIS SOFTWARE WITHOUT SPECIFIC, 
WRITTEN PRIOR AUTHORIZATION.

THIS SOFTWARE IS PROVIDED AS IS, WITHOUT REPRESENTATION FROM 
THE UNIVERSITY OF MICHIGAN AS TO ITS FITNESS FOR ANY PURPOSE, 
AND WITHOUT WARRANTY BY THE UNIVERSITY OF MICHIGAN OF ANY KIND, 
EITHER EXPRESS OR IMPLIED, INCLUDING WITHOUT LIMITATION THE 
IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A 
PARTICULAR PURPOSE. THE REGENTS OF THE UNIVERSITY OF MICHIGAN 
SHALL NOT BE LIABLE FOR ANY DAMAGES, INCLUDING SPECIAL, INDIRECT, 
INCIDENTAL, OR CONSEQUENTIAL DAMAGES, WITH RESPECT TO ANY CLAIM 
ARISING OUT OF OR IN CONNECTION WITH THE USE OF THE SOFTWARE, 
EVEN IF IT HAS BEEN OR IS HEREAFTER ADVISED OF THE POSSIBILITY 
OF SUCH DAMAGES.
*/

#ifndef __IndexSelection_H
#define __IndexSelection_H

#include "../ProcessTree/ProcessTreeInterface.h"


#define INDEX_SELECTION_OPTION_NOINDEX				0
#define INDEX_SELECTION_OPTION_TAGINDEX				1
#define INDEX_SELECTION_OPTION_AVAILABILITY_BASED	2
#define INDEX_SELECTION_OPTION_COST_BASED			3

/**
 * Class IndexSelection
 * This class takes care of index selection for individual pattern
 * tree selection node. Pattern tree marked selection node will be
 * generated, with contains the index(es) to use, and the selection
 * condition left, which can not be evaluated by index scan. 
 * 
 * What is currently implemented are 
 * 1. assuming there is no index at all. No index selection is done
 *		the leftover condition is the selection condition itself. 
 * 2. assuming that element tag index is available, and it is the
 *		only index available. chose to use this index when it is 
 *		possible. 
 * 3. availability based index selection, choose whatever index
 *		combination that has the least leftover condition. 
 * 
 *@see IndexMng
 *@author: Yuqing Melanie Wu
 */
class IndexSelection
{
public:
	IndexSelection(IndexMng* indexmng);		

	~IndexSelection(void);

	ProcessTree* selectIndex(ProcessTree* psTree, 
		int option); 

private: 
	/*
	 * A pointer to the index manager. 
	 */
	IndexMng* indexMng;

	/*
	 * For index matching
	 */
	IndexMatching* indexMatching;

	/*
	 * The process tree to be built after index selection
	 */
	ProcessTree* PsTree;

	MarkedPatternTreeSelectionNode* nodeMarkingWithNoIndexAssumption(PatternTreeSelectionNode* ptNode);
	MarkedPatternTreeSelectionNode* nodeMarkingWithTagIndexAssumption(PatternTreeSelectionNode* ptNode);
	MarkedPatternTreeSelectionNode* hackedNodeMarking(PatternTreeSelectionNode* ptNode);
	MarkedPatternTreeSelectionNode* availabilityBasedNodeMarking(PatternTreeSelectionNode* ptNode);

	void availabilityBasedIndexSelection(int option);
};

#endif