/**
COPYRIGHT  � 2000-2004
THE REGENTS OF THE UNIVERSITY OF MICHIGAN ALL RIGHTS RESERVED

PERMISSION IS GRANTED TO USE, COPY, CREATE DERIVATIVE WORKS A
ND REDISTRIBUTE THIS SOFTWARE AND SUCH DERIVATIVE WORKS FOR 
NONCOMMERCIAL EDUCATION AND RESEARCH PURPOSES, SO LONG AS NO 
FEE IS CHARGED, AND SO LONG AS THE COPYRIGHT NOTICE ABOVE, 
THIS GRANT OF PERMISSION, AND THE DISCLAIMER BELOW APPEAR IN 
ALL COPIES MADE; AND SO LONG AS THE NAME OF THE UNIVERSITY OF 
MICHIGAN IS NOT USED IN ANY ADVERTISING OR PUBLICITY PERTAINING 
TO THE USE OR DISTRIBUTION OF THIS SOFTWARE WITHOUT SPECIFIC, 
WRITTEN PRIOR AUTHORIZATION.

THIS SOFTWARE IS PROVIDED AS IS, WITHOUT REPRESENTATION FROM 
THE UNIVERSITY OF MICHIGAN AS TO ITS FITNESS FOR ANY PURPOSE, 
AND WITHOUT WARRANTY BY THE UNIVERSITY OF MICHIGAN OF ANY KIND, 
EITHER EXPRESS OR IMPLIED, INCLUDING WITHOUT LIMITATION THE 
IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A 
PARTICULAR PURPOSE. THE REGENTS OF THE UNIVERSITY OF MICHIGAN 
SHALL NOT BE LIABLE FOR ANY DAMAGES, INCLUDING SPECIAL, INDIRECT, 
INCIDENTAL, OR CONSEQUENTIAL DAMAGES, WITH RESPECT TO ANY CLAIM 
ARISING OUT OF OR IN CONNECTION WITH THE USE OF THE SOFTWARE, 
EVEN IF IT HAS BEEN OR IS HEREAFTER ADVISED OF THE POSSIBILITY 
OF SUCH DAMAGES.
*/

#pragma warning(disable: 4312)

#include "indexselection.h"

/**
 * Constructor
 */
IndexSelection::IndexSelection(IndexMng* indexmng)

{
	this->indexMng = indexmng;
	this->indexMatching = new IndexMatching(this->indexMng);
}

/**
 * Destructor
 */
IndexSelection::~IndexSelection(void)
{
	delete this->indexMatching; 
}

/**
 * Index Selection
 * Given a process tree, go over all the pattern tree selection nodes,
 * select index to use, and change them to pattern tree marked
 * selection node. 
 *
 *@param psTree The process tree which need index selection . 
 *@param option This variable specifies what assumption to make on index selection. 
 *@returns A process tree, it is the same as the input, except
 *	that all the pattern tree selection nodes are replaced by 
 *	pattern tree marked selection node. 
 */

ProcessTree* IndexSelection::selectIndex(ProcessTree* psTree, 
										 int option)
{
	this->PsTree = psTree;

	int i, j;

	int psTreeNodeNum = this->PsTree->getNodeNumber();

	/*
	 * go over each process tree node in the process tree. 
	 */
	for (i=0; i<psTreeNodeNum; i++)
	{
		ProcessTreeNode* psTreeNode = this->PsTree->getPsNodeAtIndex(i);
		PatternTree* ptTree = NULL;
			
		// only process tree select node, join node and MLCA node can 
		// have pattern tree that contains pattern tree selection node.
		int psTreeNodeType = psTreeNode->getPsNodeType();
		if ((psTreeNodeType == PROCESS_TREE_SELECT_NODE) ||
			(psTreeNodeType == PROCESS_TREE_JOIN_NODE) ||
			(psTreeNodeType == PROCESS_TREE_MLCA_NODE))
		{
			// get the pattern tree associated with the process tree node
			ptTree = ((ProcessTreeSelectNode*) psTreeNode)->getPatternTree();

			if (ptTree == NULL) continue;

			int ptTreeNodeNum = ptTree->getNodeNumber();

			// go over each pattern tree node in the pattern tree
			for (j=0; j<ptTreeNodeNum; j++)
			{
				PatternTreeNode* ptTreeNode = ptTree->getPtNodeAtIndex(j);

				// only pattern tree selection node need index selection 
				if (ptTreeNode->getPtTreeNodeType() == PATTERN_TREE_SELECTION_NODE)
				{
					PatternTreeSelectionNode* selectionNode = (PatternTreeSelectionNode*) ptTreeNode;

					// create a marked selection pattern tree node based on the index availablility and the option

					MarkedPatternTreeSelectionNode* markedPtNode = NULL;

					switch (option)
					{
					case INDEX_SELECTION_OPTION_NOINDEX:
						markedPtNode = this->nodeMarkingWithNoIndexAssumption(selectionNode);
						break;

					case INDEX_SELECTION_OPTION_TAGINDEX:
						markedPtNode = this->nodeMarkingWithTagIndexAssumption(selectionNode);
						break;

					case INDEX_SELECTION_OPTION_AVAILABILITY_BASED:
						markedPtNode = this->availabilityBasedNodeMarking(selectionNode);
						break;
					}

					// replace the pattern tree selection node with the new markedPtNode

					ptTree->setNodeWithID(markedPtNode->getNodeID(), (Node*) markedPtNode);
					delete selectionNode;

				}
			}
		}
	}
	return this->PsTree;
}

/**
 * Index selection, with the assumption that there is no index available.
 */
MarkedPatternTreeSelectionNode* IndexSelection
::nodeMarkingWithNoIndexAssumption(PatternTreeSelectionNode* ptNode)
{
	MarkedPatternTreeSelectionNode*	markedPtNode 
		= new MarkedPatternTreeSelectionNode(ptNode,
											 NO_INDEX, 0, NULL, NULL);
	return markedPtNode;
}

/**
 * Index selection, with the assumption that indices on element tag
 * and attribute name are available (these are the indices built 
 * with default loading option), and they are the only indices available. 
 * We also assume that these indices are STRING indices on GIST
 */
MarkedPatternTreeSelectionNode* IndexSelection
::nodeMarkingWithTagIndexAssumption(PatternTreeSelectionNode* selectionNode)
{
	MarkedPatternTreeSelectionNode* markedPtNode = NULL;

	char* fileName = selectionNode->getFileName();
	SelectionCondition* cond = selectionNode->getSelectionCondition();
	IndexMatchingInfo** imInfo = NULL;

	// different kind of selection nodes are handled differently.
	switch (cond->getNodeType())
	{
	case DOCUMENT_NODE:
		{
			// on document node, there is predicate on the document name, 
			// get it by file scan
			markedPtNode = new MarkedPatternTreeSelectionNode(selectionNode,
				NO_INDEX, 0, imInfo, NULL);

		}
		break;

	case ELEMENT_NODE:
		{
			/*
			 * for element node, at least one predicate is on element tag, 
			 * assume there is index on that predicate use this predicate, 
			 * and leave the other predicate in the condition
			 */

			/* 
			 * currently, assume that there are at most one more predicate 
			 *(besides the element tag) on a pattern tree node with type "element"
			 */
			
			// check whether there is any predicate on element tag.
			ConjunctiveCondition* conj = cond->getCondition()->getCondAt(0);
			bool hasPredOnEleTag = false;
			for (int i=0; i<conj->getNumber(); i++)
			{
				if (conj->getCondAt(i)->getLeftValue() == SCAN_LEFTVALUE_NODETAG)
				{
					hasPredOnEleTag = true;
					break;
				}
			}

			if (hasPredOnEleTag)
			{
				// if there is index on element tag, use the index, 
				// use the same name convention as in index manager to compose
				// the index name.  
				char indexname[MAX_INDEX_NAME_LENGTH];
				sprintf(indexname, "index_%s", fileName);
				indexname[strlen(indexname)-4] = '\0';
				strcat(indexname, "_elementtag");

				SelectionCondition* condLeft = NULL;

				if (conj->getNumber() == 1)
				{
					// There is only on predicate in the selection condition, 
					// construct the index key, by taking the right value from the predicate

					imInfo = new IndexMatchingInfo*[1];
					imInfo[0] = new IndexMatchingInfo(indexname, 
						STRING_INDEX,
						GIST_INDEX,
						conj->getCondAt(i)->getRightValue(), 
						conj->getCondAt(i)->getRightValue(),
						false);

					markedPtNode = new MarkedPatternTreeSelectionNode(selectionNode,
																	  FULLY_INDEXED, 
																	  1,
																	  imInfo,
																	  condLeft);
				}
				else
				{
					// There is more than one predicate in the selection condition.
					// so, there is leftover predicate. 
					ConjunctiveCondition* newconj = new ConjunctiveCondition(conj->getNumber()-1);
					for (int j=0; j<conj->getNumber(); j++)
						if (j!=i)
							newconj->insertCond(new PredicateCondition(conj->getCondAt(j)));
					DisjunctiveCondition* newdisj = new DisjunctiveCondition(1);
					newdisj->insertCond(newconj);
					condLeft = new SelectionCondition(cond->getNodeType(), newdisj, cond->getReturnType());

					imInfo = new IndexMatchingInfo*[1];
					imInfo[0] = new IndexMatchingInfo(indexname, 
						STRING_INDEX,
						GIST_INDEX,
						conj->getCondAt(i)->getRightValue(), 
						conj->getCondAt(i)->getRightValue(),
						false);

					markedPtNode = new MarkedPatternTreeSelectionNode(selectionNode,
																	  PARTIALLY_INDEXED, 
																	  1,
																	  imInfo,
																	  condLeft);
				}
			}
			else
			{
				// The pattern tree selection node, with type "element"
				// does not have predicate on element tag
				// throw a warning. 
				markedPtNode = new MarkedPatternTreeSelectionNode(selectionNode, 
					NO_INDEX, 0, NULL, NULL);
			}
		}
		break;

	case ATTRIBUTE_NODE:
		{
			/*
			 * In queries we currently support, there should be only one 
			 * predicate on attribute node. It is either "HASATTRIBUTE" or 
			 * a predicate on value of an attribute with a given name.
			 * We assume that index on attribute name is available. 
			 * The index maps attribute name to the node id of attribute node.
			 */		
			ConjunctiveCondition* conj = cond->getCondition()->getCondAt(0);
			PredicateCondition* pred = conj->getCondAt(0);

			if (pred->getLeftValue() == SCAN_LEFTVALUE_HASATTRIBUTE)
			{
				/*
				 * The predicate is on attribute name. so, this node is
				 * fully-indexed
				 */

				char indexname[MAX_INDEX_NAME_LENGTH];
				sprintf(indexname, "index_%s", fileName);
				indexname[strlen(indexname)-4] = '\0';
				strcat(indexname, "_attrname");

				imInfo = new IndexMatchingInfo*[1];
				imInfo[0] = new IndexMatchingInfo(indexname, 
												  STRING_INDEX,
												  GIST_INDEX,
												  pred->getRightValue(), 
												  pred->getRightValue(),
												  false);

				markedPtNode = new MarkedPatternTreeSelectionNode(selectionNode,
																  FULLY_INDEXED, 
																  1,
																  imInfo, 
																  NULL);
			}
			else 
			{
				/* 
				 * The predicate is on attribute value. 
				 * Since we have index on attribute name, this node
				 * is partially-indexed. 
				 */
				char indexname[MAX_INDEX_NAME_LENGTH];
				sprintf(indexname, "index_%s", fileName);
				indexname[strlen(indexname)-4] = '\0';
				strcat(indexname, "_attrname");

				imInfo = new IndexMatchingInfo*[1];
				Value* val = new Value(STRING_VALUE, (char*) pred->getLeftValue());

				imInfo[0] = new IndexMatchingInfo(indexname, 
												  STRING_INDEX,
												  GIST_INDEX,
												  val, 
												  val,
												  false); 
				delete val;

				markedPtNode = new MarkedPatternTreeSelectionNode(selectionNode,
																  PARTIALLY_INDEXED, 
																  1,
																  imInfo, 
																  new SelectionCondition(cond));
			}
		}
		break;

	case TEXT_NODE:
		{
			/*
			 * In the queries we currently support, there is only one predicate 
			 * on the content of element. 
			 * Since 
			 * Since we assume there is only element tag index, there is no
			 * index to use for this node. 
			 */

			markedPtNode = new MarkedPatternTreeSelectionNode(selectionNode, 
				NO_INDEX, 0, NULL, NULL);
		}
		break;
	}

	return markedPtNode;
}


/**
 * Availability based index selection. 
 */
MarkedPatternTreeSelectionNode* IndexSelection
::availabilityBasedNodeMarking(PatternTreeSelectionNode* selectionNode)
{
	MarkedPatternTreeSelectionNode* markedPtNode = NULL;

	char* fileName = selectionNode->getFileName();
	SelectionCondition* cond = selectionNode->getSelectionCondition();

	IndexCombSet indexFullSet, indexPartialSet;
	SelectionCondition* condLeft = NULL;
	int imNum = 0;
	IndexMatchingInfo** imInfo = NULL;	

	int success = this->indexMatching->matchIndex(fileName, 
									selectionNode->getNodeType(),
									cond->getCondition()->getCondAt(0),
									indexFullSet, 
									indexPartialSet);

	if (success < 0)
	{
		globalErrorInfo.insertProblem(ERR_TYPE_ERROR, __LINE__, 
			"IndexSelection::availabilityBasedNodeMarking", __FILE__,
			"IndexMatching::matchIndex fails.");
		goto exit;
	}

	int indexStatus;
	IndexCombination* indexComb = NULL;

	if ((indexFullSet.size() == 0) && (indexPartialSet.size() == 0))
	{
		indexStatus = NO_INDEX;
		condLeft = NULL;
	}
	else
	{
		if (indexFullSet.size()> 0)
		{
			indexStatus = FULLY_INDEXED;
			list<IndexCombination*>::iterator it = indexFullSet.begin();
			indexComb = *it;
		}
		else 
		{
			indexStatus = PARTIALLY_INDEXED;
			list<IndexCombination*>::iterator it = indexPartialSet.begin();
			indexComb = *it;
		}

		// construct the condition left. 

		if (indexComb->filter != NULL)
		{
			ConjunctiveCondition* conjCond = new ConjunctiveCondition(indexComb->filter);
			DisjunctiveCondition* disjCond = new DisjunctiveCondition(1);
			disjCond->insertCond(conjCond);
			condLeft = new SelectionCondition(cond->getNodeType(), disjCond,
				cond->getReturnType());
		}

		// construct the index matching info for the marked pattern tree node

		imNum = (int) indexComb->ilist.size();
		if (imNum > 0)
		{
			imInfo = new IndexMatchingInfo*[imNum];
			int count = 0;

			list<IndexMatchingType*>::iterator it = indexComb->ilist.begin();
			IndexMatchingType* im = *it;
			while (it != indexComb->ilist.end())
			{
				imInfo[count] = new IndexMatchingInfo(im->indexName,
												  im->indexType,
												  im->indexSource,
												  im->minkey,
												  im->maxkey,
												  im->isValueIndex);	
				count++;
				it++;
			}
		}
	}

	// construct the marked pattern tree node
	markedPtNode = new MarkedPatternTreeSelectionNode(selectionNode,
													  indexStatus,
													  imNum, 
													  imInfo,
													  condLeft);

	// clean up
	for (IndexCombSet::iterator it = indexFullSet.begin(); it != indexFullSet.end(); ++it) {
		IndexCombination* ic = *it;
		delete ic;
	}
	for (IndexCombSet::iterator it = indexPartialSet.begin(); it != indexPartialSet.end(); ++it) {
		IndexCombination* ic = *it;
		delete ic;
	}
								
exit: 
	return markedPtNode;

}

