Timber Web Interface to the SOAP Server
Author: Andrew Nierman


REQUIREMENTS:
in order to set up the web interface for the timber soap server you
need the following installed on your machine:
	java/javac 1.3+ or 1.4+
	apache tomcat
	ant (for automated building)
	timber soap server (up and running on a web accessible machine
		or on your local machine)


BUILDING AND DEPLOYMENT:
once you have these installed, enter the main directory where build.xml
is found.  modify the following parameters in the build.xml file:
	catalina.home -> this is the location of your apache tomcat installation
	wsdl.url -> this is the location of the wsdl file describing the timber
		soap service
	xquery.wsdl.url -> this is the location of the wsdl file describing the
		xquery parser service (runs under IIS)

after this, you can simply type:
	ant

and all the source files will be compiled and the output files (the output of
the compilation, external libraries, static web pages, etc.) will be placed 
into the build directory.

typing
	ant deploy

will copy all of the appropriate files to the webapps directory (under timberweb)
of your apache installation (you can make this a one step process by just typing
"ant deploy" rather than "ant" followed by "ant deploy").


ACCESSING THE WEB INTERFACE:
the URL will be:
http://localhost:8080/timberweb/index.html
if you have set up the web interface on your local machine.  Simply replace the
localhost with the actual machine name if you want to access the web interface from
a different machine.


MODIFYING THE WEB INTERFACE:
The source code for the Java Servlet and Java Beans can be found in 
TimberWebInterface\src\edu\umich\eecs\timber\web
(the code in TimberWebInterface\src\edu\umich\eecs\timber\soapclient and
TimberWebInterface\src\edu\umich\eecs\timber\xquerysoapclient is automatically
generated from the WSDLs by the Apache Axis SOAP toolkit in the ant build script).

JSP (Java Server Pages) files can be found in TimberWebInterface\web
(html files and other resource files are found in this directory as well).

