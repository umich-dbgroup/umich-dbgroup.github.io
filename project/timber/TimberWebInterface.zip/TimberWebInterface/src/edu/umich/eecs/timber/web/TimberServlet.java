/*
COPYRIGHT  � 2000-2004 
THE REGENTS OF THE UNIVERSITY OF MICHIGAN
ALL RIGHTS RESERVED

PERMISSION IS GRANTED TO USE, COPY, CREATE DERIVATIVE WORKS AND REDISTRIBUTE
THIS SOFTWARE AND SUCH DERIVATIVE WORKS FOR NONCOMMERCIAL EDUCATION AND RESEARCH
PURPOSES, SO LONG AS NO FEE IS CHARGED, AND SO LONG AS THE COPYRIGHT NOTICE
ABOVE, THIS GRANT OF PERMISSION, AND THE DISCLAIMER BELOW APPEAR IN ALL COPIES
MADE; AND SO LONG AS THE NAME OF THE UNIVERSITY OF MICHIGAN IS NOT USED IN ANY
ADVERTISING OR PUBLICITY PERTAINING TO THE USE OR DISTRIBUTION OF THIS SOFTWARE
WITHOUT SPECIFIC, WRITTEN PRIOR AUTHORIZATION.

THIS SOFTWARE IS PROVIDED AS IS, WITHOUT REPRESENTATION FROM THE UNIVERSITY OF
MICHIGAN AS TO ITS FITNESS FOR ANY PURPOSE, AND WITHOUT WARRANTY BY THE
UNIVERSITY OF MICHIGAN OF ANY KIND, EITHER EXPRESS OR IMPLIED, INCLUDING WITHOUT
LIMITATION THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A
PARTICULAR PURPOSE. THE REGENTS OF THE UNIVERSITY OF MICHIGAN SHALL NOT BE
LIABLE FOR ANY DAMAGES, INCLUDING SPECIAL, INDIRECT, INCIDENTAL, OR
CONSEQUENTIAL DAMAGES, WITH RESPECT TO ANY CLAIM ARISING OUT OF OR IN CONNECTION
WITH THE USE OF THE SOFTWARE, EVEN IF IT HAS BEEN OR IS HEREAFTER ADVISED OF THE
POSSIBILITY OF SUCH DAMAGES.
*/

package edu.umich.eecs.timber.web;

import java.io.*;
import java.util.*;
import javax.servlet.*;
import javax.servlet.http.*;

// Import log4j classes.
import org.apache.log4j.Logger;
import org.apache.log4j.BasicConfigurator;
import org.apache.log4j.PropertyConfigurator;

import edu.umich.eecs.timber.soapclient.*;
//import edu.umich.eecs.timber.soapclient.holders.*;


public class TimberServlet extends HttpServlet implements SingleThreadModel {

	//static vars are shared across all servlet instances (different names for same servlet)
	static SoapTimber service;
	static SoapTimberPortType port;

	//static String storedFile;
	static String storedQueryText;
	static String storedQueryResult;

	static Logger logger;

	public void init() throws ServletException {
		service = new SoapTimberLocator();
		// Now use the service to get a stub which implements the SDI
		try {
			port = service.getSoapTimberPort();
		}
		catch (javax.xml.rpc.ServiceException e) {
			e.printStackTrace();
			//forward to a jsp page or something here....
		}

		// Define a static logger variable so that it references the
		// Logger instance named "TimberServlet".
		logger = Logger.getLogger(TimberServlet.class);
		// Set up a simple configuration that logs on the console.
		//BasicConfigurator.configure();
		//PropertyConfigurator.configure("log4j.properties");
		//logger.info("Entering application.");

		String prefix =  getServletContext().getRealPath("/");
		String file = getInitParameter("log4j-init-file");
		// if the log4j-init-file is not set, then no point in trying
		if(file != null) {
			PropertyConfigurator.configure(prefix + file);
		}
	}

	public void destroy() {

	}

/*
	public void doPost(HttpServletRequest req, HttpServletResponse res)
					throws ServletException, IOException {
		//RequestDispatcher rd = null;
		//rd = getServletContext().getRequestDispatcher("/xQueryForm.jsp");
		//rd.forward(req, res);
		System.out.println("<HTML><BODY>TEST OF POST</BODY></HTML>");
	}
*/

	//usually wouldn't want to synchronize this method, but since timber isn't
	//multi-threaded, we don't want multiple people accessing it at the same time...
	//probably better to implement the SingleThreadModel for now (until multi-threading
	//is working) and then have a managed connection pool instead
	//public synchronized void doGet(HttpServletRequest req, HttpServletResponse res)
	//				throws ServletException, IOException {
	public void doGet(HttpServletRequest req, HttpServletResponse res)
					throws ServletException, IOException {

		//bean forwarded by jsp:
		QueryBean queryBean = (QueryBean) req.getAttribute("queryBean");
//System.out.println("in Servlet: " + queryBean.getX());
/*
		QueryBean queryBean;
		try {
			queryBean = (XQueryBean) req.getAttribute("queryBean");
			logger.info("IN XQUERYBEAN\n");
		}
		catch (ClassCastException e) {
			queryBean = (QueryBean) req.getAttribute("queryBean");
		}
*/

		//String file = req.getParameter("file");
		//String queryText = req.getParameter("queryText");

	RequestDispatcher rd = null;


	if (queryBean.getDisplayXML()) {
		synchronized(this) {
			if (queryBean.getQueryText().equals(storedQueryText)) {
				//&& queryBean.getFile().equals(storedFile)) {

				//no need to set the bean's query result, we're not re-using it anywhere:
				//queryBean.setQueryResult(port.getOutput());
				//change from using queryResult.jsp to just outputting everything in the servlet...
				//rd = getServletContext().getRequestDispatcher("/queryResult.jsp");


				//IE ignores the text/plain if it's not a .txt file
				//netscape ignores the text/xml if it's not a .xml file
				//the way to do this eventually is to make it look like it's an xml file in 
				//the url by using <servlet-name> in the web.xml file
				//and return text/xml, non-xml enabled browsers will just download
				//the file to their file system...

				//for now I'll just transform to html for everything besides IE5 and IE6:

				String agent = req.getHeader("User-Agent");
				logger.info("AGENT: " + agent);

				String output = storedQueryResult;
				//String output = queryBean.getQueryResult();
				//String output = port.getOutput();
				//String output = "<test>stuff</test>";

				if (agent.indexOf("MSIE 6.0") >= 0 || agent.indexOf("MSIE 5.0") >= 0) {
					res.setContentType("text/xml");
				}
				else {
					res.setContentType("text/html");
					output = "<pre>" + getXMLString(output) + "</pre>";

					//res.setContentType("text/plain");
				}

				PrintWriter out = res.getWriter();
				//out.println("<?xml version=\"1.0\" encoding=\"ISO-8859-1\"?>");

				out.println(output);

				out.close();
			}
			else {
				queryBean.setQueryResultErrorMessage("The XML result has been overwritten by subsequent queries.");
				rd = getServletContext().getRequestDispatcher("/queryResultSummary.jsp");
				rd.forward(req, res);
			}
		} //synchronized
	}
	else {
		//String file = queryBean.getFile();
		String queryText = queryBean.getQueryText();

		//req -> public void setAttribute(java.lang.String name,
		//java.lang.Object o)

//System.out.println("FILE:\n" + file);
//System.out.println("QUERY:\n" + queryText);

		//if (file.trim().equals("") || queryText.trim().length() == 0) { 
		//	queryBean.setQueryFormErrorMessage("Please fill in all fields.");
		if (queryText.trim().length() == 0) {
			queryBean.setQueryFormErrorMessage("No query was entered.");
			rd = getServletContext().getRequestDispatcher("/queryForm.jsp");
		}
		else {
			rd = getServletContext().getRequestDispatcher("/queryResultSummary.jsp");
			//timber isn't multi-threaded, so synchronize the query execution:

			javax.xml.rpc.holders.IntHolder numElements = new javax.xml.rpc.holders.IntHolder();
			javax.xml.rpc.holders.DoubleHolder time = new javax.xml.rpc.holders.DoubleHolder();

			String fixedQueryText = "";

			//used for logging:
			String ip = req.getRemoteAddr(); // ip address
			String host = req.getRemoteHost(); // hostname

			synchronized(this) {
//System.out.println("FILE: " + file);
				//port.selectFileForQuery(file);

				//multi-line queryText strings are giving ansi 13,10 for newlines
				//whereas it should just be ansi 10
				//so use fixedQueryText in runQuery

				StringTokenizer t = new StringTokenizer(queryText, "\n\r\f");
				while(t.hasMoreTokens()) {
					String line = t.nextToken();
					fixedQueryText += (line+"\n");
				}
				fixedQueryText = fixedQueryText.trim();

				//runQuery should return an error if query is not formulated correctly
//System.out.println("QUERYTEXT:\n" + queryText);
//System.out.println("QUERYTEXTFIXED:\n" + fixedQueryText);


				//need to log before calling runQuery, in case timber soap dies on the query
				//if it dies on runQuery, we would "hang" indefinitely.

				//logger.info("IP:" + ip + "\tHOST:" + host + "\tFILE:" + file + "\tQUERY:" + fixedQueryText);
				logger.info("IP:" + ip + "\tHOST:" + host + "\tQUERY:\n" + fixedQueryText);

				javax.xml.rpc.holders.StringHolder queryResult = new javax.xml.rpc.holders.StringHolder();

				javax.xml.rpc.holders.BooleanHolder isWarning = new javax.xml.rpc.holders.BooleanHolder();
				javax.xml.rpc.holders.StringHolder warning = new javax.xml.rpc.holders.StringHolder();
				javax.xml.rpc.holders.BooleanHolder isError = new javax.xml.rpc.holders.BooleanHolder();
				javax.xml.rpc.holders.StringHolder error = new javax.xml.rpc.holders.StringHolder();

				port.runQuery(fixedQueryText, true, time, numElements, queryResult,
					isWarning, warning, isError, error);

				//logger.info("RESULT: " + queryResult.value);
				//queryBean.setQueryResult(queryResult.value);
				storedQueryResult = queryResult.value;

				//we just store one xml result for a query, so store queryText and file
				//(and device, if we allow the user to switch devices)
				//when the user chooses to display the xml, then we need to see if the current
				//result is still valid (make sure another query has not run in the interim)
				storedQueryText = queryBean.getQueryText();
				//storedFile = queryBean.getFile();
			} //synchronized


//System.out.println("numElements: " + numElements.value);
//System.out.println("time: " + time.value);
			queryBean.setNumElements(numElements.value);
			queryBean.setTime(time.value);
			if (numElements.value == -1 || time.value == -1) {
				queryBean.setQueryFormErrorMessage("The query evaluation plan was incorrect.");
				rd = getServletContext().getRequestDispatcher("/queryForm.jsp");
			}
		}

		rd.forward(req, res);
		
//		if (emptyParameter)
//			rd.include(req, res);

	}//else
	}


        // escape &, <, >, ', and "

        public static String getXMLString(String str)
        {
                StringBuffer buffer = new StringBuffer(str);

                char ch = ' ';
                for (int i = 0; i < buffer.length(); i++) {
                        ch = buffer.charAt(i);
                        if (ch == '&') {
                                buffer.insert(i+1, "amp;");
                                i+=3;
                        } else if (ch == '<') {
                                buffer.replace(i, i+1, "&lt;");
                                i+=2;
                        } else if (ch == '>') {
                                buffer.replace(i, i+1, "&gt;");
                                i+=2;
                        } else if (ch == '\'') {
				buffer.replace(i, i+1, "&apos;");
				i+=4;
			} else if (ch == '"') {
				buffer.replace(i, i+1, "&quot;");
				i+=4;
			}
                }

                return buffer.toString();
        }

}
