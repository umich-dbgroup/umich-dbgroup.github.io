/*
COPYRIGHT  � 2000-2004 
THE REGENTS OF THE UNIVERSITY OF MICHIGAN
ALL RIGHTS RESERVED

PERMISSION IS GRANTED TO USE, COPY, CREATE DERIVATIVE WORKS AND REDISTRIBUTE
THIS SOFTWARE AND SUCH DERIVATIVE WORKS FOR NONCOMMERCIAL EDUCATION AND RESEARCH
PURPOSES, SO LONG AS NO FEE IS CHARGED, AND SO LONG AS THE COPYRIGHT NOTICE
ABOVE, THIS GRANT OF PERMISSION, AND THE DISCLAIMER BELOW APPEAR IN ALL COPIES
MADE; AND SO LONG AS THE NAME OF THE UNIVERSITY OF MICHIGAN IS NOT USED IN ANY
ADVERTISING OR PUBLICITY PERTAINING TO THE USE OR DISTRIBUTION OF THIS SOFTWARE
WITHOUT SPECIFIC, WRITTEN PRIOR AUTHORIZATION.

THIS SOFTWARE IS PROVIDED AS IS, WITHOUT REPRESENTATION FROM THE UNIVERSITY OF
MICHIGAN AS TO ITS FITNESS FOR ANY PURPOSE, AND WITHOUT WARRANTY BY THE
UNIVERSITY OF MICHIGAN OF ANY KIND, EITHER EXPRESS OR IMPLIED, INCLUDING WITHOUT
LIMITATION THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A
PARTICULAR PURPOSE. THE REGENTS OF THE UNIVERSITY OF MICHIGAN SHALL NOT BE
LIABLE FOR ANY DAMAGES, INCLUDING SPECIAL, INDIRECT, INCIDENTAL, OR
CONSEQUENTIAL DAMAGES, WITH RESPECT TO ANY CLAIM ARISING OUT OF OR IN CONNECTION
WITH THE USE OF THE SOFTWARE, EVEN IF IT HAS BEEN OR IS HEREAFTER ADVISED OF THE
POSSIBILITY OF SUCH DAMAGES.
*/

package edu.umich.eecs.timber.web;

import edu.umich.eecs.timber.soapclient.*;
import edu.umich.eecs.timber.soapclient.holders.*;
import edu.umich.eecs.timber.xquerysoapclient.*;

public class QueryBean {

	//String sampleQuery = "";

	String x = "";

	String device = null;
	String queryText = "";
	String file = "";

	String queryFileErrorMessage = "";
	String queryFormErrorMessage = "";
	String queryResultErrorMessage = "";

	String xQueryText = "";

	int numElements = -2;
	double time = -2;

	String queryResult;

	boolean displayXML = false;

	public String escapeQuotes(String s) {
		String result = "";
		for (int i = 0; i < s.length(); i++) {
			char c = s.charAt(i);
			if (c == '"') {
				result += "\\\"";
			}
			else {
				result += c+"";
			}
		}
//System.out.println("S: " + s);
//System.out.println("RESULT: " + result);
		return result;
	}

/*
<jsp:getProperty name="queryBean" property="sampleQuery" />

	public String getSampleQuery() {
		return "I,index_books_elementtag,GIST,STR,author";
	}

	public void setSampleQuery(String s) {
		sampleQuery = s;
	}
*/

	public void setDisplayXML(boolean b) {
		displayXML = b;
	}
	public boolean getDisplayXML() {
		return displayXML;
	}

	public void setQueryResult(String s) {
		queryResult = s;
	}
	public String getQueryResult() {
		return queryResult;
	}

	public void setNumElements(int i) {
		numElements = i;
	}
	public int getNumElements() {
		return numElements;
	}

	public void setTime(double d) {
		time = d;
	}
	public double getTime() {
		return time;
	}

	public void setQueryResultErrorMessage(String s) {
		queryResultErrorMessage = s;
	}
	public String getQueryResultErrorMessage() {
		String htmlError = "<font color=\"red\"><b>" + TimberServlet.getXMLString(queryResultErrorMessage) + "</font></b>";
		return queryResultErrorMessage != null ? htmlError : "";
	}

	public void setQueryFormErrorMessage(String s) {
		queryFormErrorMessage = s;
	}
	public String getQueryFormErrorMessage() {
		String htmlError = "<font color=\"red\"><b>" + TimberServlet.getXMLString(queryFormErrorMessage) + "</font></b>";
		return queryFormErrorMessage != null ? htmlError : "";
	}

	public void setQueryFileErrorMessage(String s) {
		queryFileErrorMessage = s;
	}
	public String getQueryFileErrorMessage() {
		String htmlError = "<font color=\"red\"><b>" + TimberServlet.getXMLString(queryFileErrorMessage) + "</font></b>";
		return queryFileErrorMessage != null ? htmlError : "";
	}


	public void setDevice(String s) {
		device = s;
	}
	public String getDevice() {
		return device != null ? device : "";
	}

	public void setX(String s) {
//System.out.println("IN setX, s=" + s);
		x = s.trim();
/*
		if (!x.equals(s.trim())) {
			x = s.trim();

			//setFile("books1.xml");
			String evaluationPlan = evaluationPlan(x);
System.out.println("EVAL PLAN: " + evaluationPlan);
			setQueryText(evaluationPlan);
		}
*/
	}
	public String getX() {
		return x;
	}



/*
	public void setXQueryText(String s) {
System.out.println("IN setXQueryText, s=" + s);
		if (!xQueryText.equals(s.trim())) {
			xQueryText = s.trim();
			setFile("books1.xml");
			String evaluationPlan = evaluationPlan(xQueryText);
System.out.println("EVAL PLAN: " + evaluationPlan);
			setQueryText(evaluationPlan);
		}
	}
	public String getXQueryText() {
		return xQueryText;
	}
*/

	public String evaluationPlan(String xQuery) {
		String evaluationPlan = "";
		try {
			Xqueryservice xQueryService = new XqueryserviceLocator();
			// Now use the service to get a stub which implements the SDI
			XqueryserviceSoap client = xQueryService.getXqueryserviceSoap();
			String logicalPlan = client.xQueryToLogicalAlgebra(xQuery);
			//return the xquery parser error:
			if (logicalPlan.startsWith("ERROR:")) {
				setQueryFormErrorMessage(logicalPlan);
				return "";
			}
			SoapTimber service = new SoapTimberLocator();
			SoapTimberPortType port = service.getSoapTimberPort();

			//javax.xml.rpc.holders.IntHolder numFilesHolder = new javax.xml.rpc.holders.IntHolder();
			//ArrayOfstringHolder arrayHolder = new ArrayOfstringHolder();

			javax.xml.rpc.holders.StringHolder evaluationPlanHolder = new javax.xml.rpc.holders.StringHolder();
			javax.xml.rpc.holders.BooleanHolder isWarning = new javax.xml.rpc.holders.BooleanHolder();
			javax.xml.rpc.holders.StringHolder warning = new javax.xml.rpc.holders.StringHolder();
			javax.xml.rpc.holders.BooleanHolder isError = new javax.xml.rpc.holders.BooleanHolder();
			javax.xml.rpc.holders.StringHolder error = new javax.xml.rpc.holders.StringHolder();

			//(logicalPlan, 1, ...) = tag index
			//(logicalPlan, 2, ...) = availability based
			port.getQueryEvaluationPlan(logicalPlan, 2, 0, evaluationPlanHolder,
				isWarning, warning, isError, error);

			//if there was an error, return that to the user, rather than the evaluation plan:
			if (isError.value) {
				setQueryFormErrorMessage(error.value);
				return "";
			}

			evaluationPlan = evaluationPlanHolder.value;

			//OLD:
			//Service1 service = new Service1Locator();
			// Now use the service to get a stub which implements the SDI
			//Service1Soap client = service.getService1Soap();
			//evaluationPlan = client.getXQExecutionPlan(xQuery);
		} 
		catch (Exception e) {
			return "Exception Thrown. Error Creating Evaluation Plan.";
		}
		return evaluationPlan;
	}

	public void setQueryText(String s) {
		queryText = s.trim();
	}
	public String getQueryText() {
		return queryText;
	}

	public void setFile(String s) {
		file = s;
	}
	public String getFile() {
		return file;
	}

	public String[] fileNames() {
		String [] fileNames = null;
		try {

			SoapTimber service = new SoapTimberLocator();
			SoapTimberPortType port = service.getSoapTimberPort();

			//javax.xml.rpc.holders.IntHolder numFilesHolder = new javax.xml.rpc.holders.IntHolder();
			ArrayOfstringHolder arrayHolder = new ArrayOfstringHolder();

			javax.xml.rpc.holders.BooleanHolder isWarning = new javax.xml.rpc.holders.BooleanHolder();
			javax.xml.rpc.holders.StringHolder warning = new javax.xml.rpc.holders.StringHolder();
			javax.xml.rpc.holders.BooleanHolder isError = new javax.xml.rpc.holders.BooleanHolder();
			javax.xml.rpc.holders.StringHolder error = new javax.xml.rpc.holders.StringHolder();


			port.getFileNames(arrayHolder, //numFilesHolder,
				isWarning, warning, isError, error);

			if (isError.value) {
				fileNames = new String[1];
				fileNames[0] = error.value;
			}
			else {
				//fileNames = port.getFileNames();
				fileNames = arrayHolder.value;
			}
		}
		catch (Exception e) {
			return new String[]{};
		}
		return fileNames != null ? fileNames : new String[]{};
	}

	public String[] indexNamesForFile(String file) {

		//System.out.println("FILE:" + file);

		String[] indices = null;
		try {
			SoapTimber service = new SoapTimberLocator();
			SoapTimberPortType port = service.getSoapTimberPort();

			//javax.xml.rpc.holders.IntHolder numIndicesHolder = new javax.xml.rpc.holders.IntHolder();
			ArrayOfstringHolder arrayHolder = new ArrayOfstringHolder();

			javax.xml.rpc.holders.BooleanHolder isWarning = new javax.xml.rpc.holders.BooleanHolder();
			javax.xml.rpc.holders.StringHolder warning = new javax.xml.rpc.holders.StringHolder();
			javax.xml.rpc.holders.BooleanHolder isError = new javax.xml.rpc.holders.BooleanHolder();
			javax.xml.rpc.holders.StringHolder error = new javax.xml.rpc.holders.StringHolder();


			port.getIndexNamesForFile(file, arrayHolder, //numIndicesHolder);
				isWarning, warning, isError, error);

			if (isError.value) {
				indices = new String[1];
				indices[0] = error.value;
			}
			else {
				indices = arrayHolder.value;
			}
		} 
		catch (Exception e) {
			return new String[]{};
		}
		return indices != null ? indices : new String[]{};
	}

	/**
	* Return the string "checked" for use in the html, if the radio button is selected
	*/
	public String deviceSelectionAttr(String deviceName) {
		if (device != null) {
			return device.equals(deviceName) ? "checked" : "";
		}
		return "";
	}

	public String fileSelectionAttr(String fileName) {
		if (file.equals(fileName)) return "selected";
		return "";
	}
}
