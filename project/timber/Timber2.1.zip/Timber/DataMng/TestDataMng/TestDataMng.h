/*
COPYRIGHT  � 2000-2004 
THE REGENTS OF THE UNIVERSITY OF MICHIGAN
ALL RIGHTS RESERVED

PERMISSION IS GRANTED TO USE, COPY, CREATE DERIVATIVE WORKS AND
REDISTRIBUTE THIS SOFTWARE AND SUCH DERIVATIVE WORKS FOR NONCOMMERCIAL
EDUCATION AND RESEARCH PURPOSES, SO LONG AS NO FEE IS CHARGED, AND SO
LONG AS THE COPYRIGHT NOTICE ABOVE, THIS GRANT OF PERMISSION, AND THE
DISCLAIMER BELOW APPEAR IN ALL COPIES MADE; AND SO LONG AS THE NAME OF
THE UNIVERSITY OF MICHIGAN IS NOT USED IN ANY ADVERTISING OR PUBLICITY
PERTAINING TO THE USE OR DISTRIBUTION OF THIS SOFTWARE WITHOUT
SPECIFIC, WRITTEN PRIOR AUTHORIZATION.

THIS SOFTWARE IS PROVIDED AS IS, WITHOUT REPRESENTATION FROM THE
UNIVERSITY OF MICHIGAN AS TO ITS FITNESS FOR ANY PURPOSE, AND WITHOUT
WARRANTY BY THE UNIVERSITY OF MICHIGAN OF ANY KIND, EITHER EXPRESS OR
IMPLIED, INCLUDING WITHOUT LIMITATION THE IMPLIED WARRANTIES OF
MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE. THE REGENTS OF
THE UNIVERSITY OF MICHIGAN SHALL NOT BE LIABLE FOR ANY DAMAGES,
INCLUDING SPECIAL, INDIRECT, INCIDENTAL, OR CONSEQUENTIAL DAMAGES,
WITH RESPECT TO ANY CLAIM ARISING OUT OF OR IN CONNECTION WITH THE USE
OF THE SOFTWARE, EVEN IF IT HAS BEEN OR IS HEREAFTER ADVISED OF THE
POSSIBILITY OF SUCH DAMAGES.
*/

#ifndef __TestDataMng_H
#define __TestDataMng_H
#include <timber-compat.h>

#include "../DataMng.h"
#include "../../XMLParser/TestParser/TestClass.h"

// choices for testDataMng
#define TEST_DM_LOADING				0
#define TEST_DM_APPENDING			1
#define TEST_DM_SCANNING			2
#define TEST_DM_UPDATE				3	
#define TEST_DM_NODEIDMAP			4
#define TEST_DM_DATAINSTANTIATION	5

// choices  for test scan
#define TEST_DM_SCAN_ALL			11
#define TEST_DM_SCAN_SIMPLE_COND	12
#define TEST_DM_SCAN_COMPLEX_COND	13
#define TEST_DM_SCAN_SIMPLE_RANGE	14
#define TEST_DM_SCAN_COMPLEX_RANGE	15

// choices for print (count the nodes or to print each nodes)
#define TEST_DM_PRINT_NODE		21
#define TEST_DM_COUNT_NODE		22

class TestDataMng : public TestClass
{
public:
	TestDataMng(lvid_t vold_i, char* filename);
	~TestDataMng();

	void runTest();

private:
	DataMng* dataMng;
	
	// the following two variables controls how the scan results are printed. 
	int outputChoice;
	int countInterval;

	void initTestCode();
	void testLoading();
	void testAppending();
	void testScan();
	void testUpdate();
	void testNodeIDMap();
	void testDataInstantiation();

	SelectionCondition* constructScanCond(int targetNode, 
										  int leftvalue, int op);
	bool dataLoaded(char* filename);
	int loadXMLFile(char* filenamewithpath);

	void fullScanSubtree(FileIDType fileid,
		KeyType rootkey);
	
	void scanSubTreeForTag(FileIDType fileid,
		KeyType rootkey, char* tag);

	void scanAndPrint(FileIDType fileid,
		KeyType rootkey, SelectionCondition* cond, ScanRange* ranges);

	void fetchANode(FileIDType fileid, KeyType key);

	void printFile(char* filename);

};


#endif

