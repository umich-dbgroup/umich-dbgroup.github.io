/*
COPYRIGHT  � 2000-2004 
THE REGENTS OF THE UNIVERSITY OF MICHIGAN
ALL RIGHTS RESERVED

PERMISSION IS GRANTED TO USE, COPY, CREATE DERIVATIVE WORKS AND
REDISTRIBUTE THIS SOFTWARE AND SUCH DERIVATIVE WORKS FOR NONCOMMERCIAL
EDUCATION AND RESEARCH PURPOSES, SO LONG AS NO FEE IS CHARGED, AND SO
LONG AS THE COPYRIGHT NOTICE ABOVE, THIS GRANT OF PERMISSION, AND THE
DISCLAIMER BELOW APPEAR IN ALL COPIES MADE; AND SO LONG AS THE NAME OF
THE UNIVERSITY OF MICHIGAN IS NOT USED IN ANY ADVERTISING OR PUBLICITY
PERTAINING TO THE USE OR DISTRIBUTION OF THIS SOFTWARE WITHOUT
SPECIFIC, WRITTEN PRIOR AUTHORIZATION.

THIS SOFTWARE IS PROVIDED AS IS, WITHOUT REPRESENTATION FROM THE
UNIVERSITY OF MICHIGAN AS TO ITS FITNESS FOR ANY PURPOSE, AND WITHOUT
WARRANTY BY THE UNIVERSITY OF MICHIGAN OF ANY KIND, EITHER EXPRESS OR
IMPLIED, INCLUDING WITHOUT LIMITATION THE IMPLIED WARRANTIES OF
MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE. THE REGENTS OF
THE UNIVERSITY OF MICHIGAN SHALL NOT BE LIABLE FOR ANY DAMAGES,
INCLUDING SPECIAL, INDIRECT, INCIDENTAL, OR CONSEQUENTIAL DAMAGES,
WITH RESPECT TO ANY CLAIM ARISING OUT OF OR IN CONNECTION WITH THE USE
OF THE SOFTWARE, EVEN IF IT HAS BEEN OR IS HEREAFTER ADVISED OF THE
POSSIBILITY OF SUCH DAMAGES.
*/

#ifndef __ScanTable_H
#define __ScanTable_H
#include <timber-compat.h>

#include "ScanTableItem.h"

// the maximum number of scans allowed on one data file
#define MAXSCAN_NUMBER	100


/**
* class ScanTable
* This class keeps track of all scans opened on a single data file. 
* 
* @see ScanTableItem
* @see DynamicFileMap
* 
* @author Yuqing Melanie Wu
* @version 1.0
*/

class ScanTable
{
public:
	/**
	* Constructor
	* Initialize the variables with default value.
	*/
	ScanTable();
	
	/**
	* Destructor
	* Release space taken by the scanlist.
	*/
	virtual ~ScanTable();

	/**
	* Process Method
	* Get the ID of the first free (invalid) ScanTableItem in the scanlist
	* @returns The ID of the first free (invalid) ScanTableItem in the scanlist. -1 if all the scan table item in the list are occupied. 
	*/
	ScanIDType getNewScanID();

	/**
	* Set Method
	* Set the scan inforamtion to the ScanTableItem with a reserved id.
	* @param scanid The id of the ScanTableItem reserved for the scan. 
	* @param scaninfo The information about a scan on the physical data management level.
	* @param writetoNodeMap A boolean value which indicate whether the results of the scan are to be written to the buffer (NodeIDMap). 
	*/
	void  validate(ScanIDType scanid, 
		ScanInfo* scaninfo,
		bool writetoNodeMap);

	/**
	* Process Method
	* Invalidate a scan table item in the ScanTable.
	*
	* @param scanid The id of the scan table item to be invalidated. 
	*/
	void	invalidate(const ScanIDType scanid);

	/**
	* Access Method
	* 
	* Get the ScanTableItem with a given scanid.
	*
	* @param scanid The id of the scan table item 
	* @returns The ScanTableItem that contains information about the scan
	*/
	ScanTableItem* getScan(const ScanIDType scanid);
	
	/**
	* Assert Method
	* 
	* Check whether a scan talbe item in the ScanTable with a given scanid is valid.
	* 
	* @param scanid The id of the scan table item 
	* @returns a boolean value which indicate whether the scan table item is valid
	*/
	bool	checkValid(const ScanIDType scanid);


private:
	/**
	* The Number of active scans in the scan table. 
	*/
	int	activeScanNumber;

	/**
	* The list of active scans
	* 
	* This is a list of fixed length, which gives the maximum number of 
	* scans can be opened on a single data file
	*/ 
	ScanTableItem*	scanList[MAXSCAN_NUMBER];

friend class ScanTableItem;
};

#endif

