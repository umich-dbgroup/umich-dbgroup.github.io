/*
COPYRIGHT  � 2000-2004 
THE REGENTS OF THE UNIVERSITY OF MICHIGAN
ALL RIGHTS RESERVED

PERMISSION IS GRANTED TO USE, COPY, CREATE DERIVATIVE WORKS AND
REDISTRIBUTE THIS SOFTWARE AND SUCH DERIVATIVE WORKS FOR NONCOMMERCIAL
EDUCATION AND RESEARCH PURPOSES, SO LONG AS NO FEE IS CHARGED, AND SO
LONG AS THE COPYRIGHT NOTICE ABOVE, THIS GRANT OF PERMISSION, AND THE
DISCLAIMER BELOW APPEAR IN ALL COPIES MADE; AND SO LONG AS THE NAME OF
THE UNIVERSITY OF MICHIGAN IS NOT USED IN ANY ADVERTISING OR PUBLICITY
PERTAINING TO THE USE OR DISTRIBUTION OF THIS SOFTWARE WITHOUT
SPECIFIC, WRITTEN PRIOR AUTHORIZATION.

THIS SOFTWARE IS PROVIDED AS IS, WITHOUT REPRESENTATION FROM THE
UNIVERSITY OF MICHIGAN AS TO ITS FITNESS FOR ANY PURPOSE, AND WITHOUT
WARRANTY BY THE UNIVERSITY OF MICHIGAN OF ANY KIND, EITHER EXPRESS OR
IMPLIED, INCLUDING WITHOUT LIMITATION THE IMPLIED WARRANTIES OF
MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE. THE REGENTS OF
THE UNIVERSITY OF MICHIGAN SHALL NOT BE LIABLE FOR ANY DAMAGES,
INCLUDING SPECIAL, INDIRECT, INCIDENTAL, OR CONSEQUENTIAL DAMAGES,
WITH RESPECT TO ANY CLAIM ARISING OUT OF OR IN CONNECTION WITH THE USE
OF THE SOFTWARE, EVEN IF IT HAS BEEN OR IS HEREAFTER ADVISED OF THE
POSSIBILITY OF SUCH DAMAGES.
*/

#include "FileHandler.h"
#include "../../Utilities/ErrorInfoClass.h"


/**
* class FileHandler
* 
* A Filehandler handles the operations related to data file, including data loading, appending, 
* checking for file existence in database, opening/closeing file, etc. 
* 
* Some of the operations can be done by directly calling the function in PhysicalDataMng that provide the 
* service, such as loading file. Some of them requires extra book-keeping on this Logical Data Management 
* level, such as open file and close file. Some of them could not be done properly at physical data
* management level and require a lot of additional process in this level, such as data appending. 
* 
* @see DynamicFileTalbe
* @see DataMng
* @see PhysicalDataMng
*
* @author Yuqing Melanie Wu
* @version 1.0
*/

/**
* Constructor
* initialize the FileHandler with a pointer to the PhysicalDataMng
* @param pdatamng A pointer to the PhysicalDataMng
*/
FileHandler::FileHandler(PhysicalDataMng* pdatamng)
{
	this->physicalDataMng = pdatamng;
	this->dynamicFileTable = new DynamicFileTable();
}

FileHandler::~FileHandler(void)
{
  delete this->dynamicFileTable;
}

/**
* File Interface
* Find out whether a data file exist in the database
* @param filename The name of the file we are looking for
* @returns A boolean value which indicate whether a data file with the given name exists in the database.
* @see PhysicalDataMng::fileExist
*/
bool FileHandler::fileExist(char* filename)
{
	return this->physicalDataMng->fileExist(filename);
}

/**
* File Interface
* 
* Given the name of a data file, open the file and prepare for further operation.
*
* This is the first step for all the operations on the file. 
* Nothing can be done without open the file first.
*
* This Method does the following:
*		find the file in the database
*		prepare the buffer (NodeIDMap) for the file in memory 
*		insert an item into DynamicFileTable for this file
*
* @param filename The name of the file to be opened
* @param rootkey The key of the root node in the file (return value)
* @param capacityChoice/idmapCapacity/rpPolicy/LRURemovePercentage The parameters for NodeIDMap.
* @returns The dynamic file id assigned to the file. -1 if any error happens, or when no more file can be opened.
* @see NodeIDMap
*/
FileIDType FileHandler::openFile(char* filename,
								 KeyType* rootkey, 
								 int capacityChoice, 
								 int idmapCapacity, 
								 int rpPolicy, 
								 float LRURemovePercentage)
{
	// find whether a data file with the given name is in the database. 
	if (!this->physicalDataMng->fileExist(filename))
		return -1;

	// check whether the file has been opened, by this transaction or by others
	FileIDType dynamicid = this->dynamicFileTable->findDynamicIDByFileName(filename);
	if (dynamicid >= 0)
		return dynamicid;

	// reserve a dyanmic file id in the DyanmicFileTable. 
	// In our design, there is an upper-bound on how many files can be openned at the same time. 
	// if the number of files opened has reached that boundary, -1 will be returned.

	dynamicid = this->dynamicFileTable->newItem(filename);
	if (dynamicid == -1)
	{
          globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"FileHandler",__FILE__,"Cannot open any more files");
		return -1;
	}

	// get the information about the file in database. 
	FileInfoType* fileinfo = this->physicalDataMng->getFileInfo(filename);
	if (fileinfo == NULL)
	{
          globalErrorInfo.insertProblem(ERR_TYPE_WARNING,__LINE__,"FileHandler",__FILE__,"File does not exist in Timber. Looking for file on the harddrive");
          return -1;
	}
	else
	{
		// set the information to the dynamic file table. 
		this->dynamicFileTable->setFileInfo(dynamicid, fileinfo);
		*rootkey = fileinfo->rootKey;

		// when open a file, build an empty nodeidmap for the file. 

		NodeIDMap* crtNodeIDMap = new NodeIDMap(capacityChoice, 
												idmapCapacity, 
												rpPolicy, 
												LRURemovePercentage);
	
		// set the NodeIDMap to the item associate with the file in DynamicFileTable. 
		this->dynamicFileTable->setNodeMap(dynamicid, crtNodeIDMap);
	
		return dynamicid;
	}
}

/**
* File Interface
* 
* Close a data file. 
* 
* After all operation is done on a file, this file must be closed explicitly in TIMBER. 
* This is done by remove the item associated with the data file from the DynamicFileTable. No more
* operation can be applied on the data file (through the DataMng's interface) after the file is closed. 
* If the file has been changed during the time it is opened, the fileinfo is write out to database 
* at this time.
* 
* @param fileid The dynamic id of the file to be closed. 
* @param sizeRequirement/replacementTimes The statistical information related to the buffer (NodeIDMap) usage.
*		These are return values. These info will be provided when the input is not NULL.   
*/
void FileHandler::closeFile(FileIDType fileid,
							int* sizeRequirement,
							int* replacementTimes)
{
	// write the file info to database if it has been changed. 
	if (this->dynamicFileTable->fileInfoIsChanged(fileid))
		this->physicalDataMng->resetFileInfo(this->dynamicFileTable->getFileName(fileid),
											this->dynamicFileTable->getFileInfo(fileid));

	// get the statistical information about the buffer (NodeIDMap) usage, if the info is required
	NodeIDMap* idMap = this->getNodeIDMap(fileid);
	if (sizeRequirement != NULL)
		(*sizeRequirement) = idMap->getSizeRequirement();
	if (replacementTimes != NULL)
		*replacementTimes = idMap->getReplacementTimes();

	// invalidate the item in DynamicFileTable.
	this->dynamicFileTable->invalidate(fileid);
}

/**
* File Interface 
*
* Reorganize a file (most possiblly after updates), to make sure nodes are stored in key order.
*
* This is done by directly calling the reorganizeFile function in PhysicalDataMng. 
* 
* @param filename The name of the file to be reorganized.
* @returns Error code.
*/
int FileHandler::reorganizeFile(char* filename)
{
	return this->physicalDataMng->reorganizeFile(filename);
}
//int FileHandler::reorganizeFile(FileIDType fileID)
//{
//	return this->physicalDataMng->reorganizeFile(this->getFileInfo(fileID));
//}

/**
* Access Method
* Get the information about the data file in the database, given the dynamic file id.
* Get the information  from the DynamicFileTable.
* 
* @param fileid The dyanmic file id of the opened data file. 
* @returns the information about the file. 
*/

FileInfoType* FileHandler::getFileInfo(FileIDType fileid)
{
	return this->dynamicFileTable->getFileInfo(fileid);
}

/**
* Access Method
* Get the NodeIDMap associated with the data file in the database, given the dynamic file id.
* Get the NodeIDMap from the DynamicFileTable.
* 
* @param fileid The dyanmic file id of the opened data file. 
* @returns The NodeIDMap associated with the data file in the database
*/

NodeIDMap* FileHandler::getNodeIDMap(FileIDType fileid)
{
	return this->dynamicFileTable->getCurrentNodeIDMap(fileid);
}

/**
* Process Method
* Reserve a new ScanID for a file. 
* This is done by the functions provided by DyanmicFileTable. 
* 
* @param fileid The dyanmic file id of the opened data file. 
* @returns The scan id reserved for the new scan. 
*/
ScanIDType FileHandler::getNewScanID(FileIDType fileid)
{
	return this->dynamicFileTable->getNewScanID(fileid);
}

/**
* Access Method
* Get the scan table item about a scan, given the file id and scan id. 
* The scan table item, with the matching fileid and scanid, in the DynamicFileTable will be returned.
* 
* @param fileid The dynamic file id of the file. 
* @param scanid The id of the scan. 
* @param The scan table item, with the matching fileid and scanid. 
*/
ScanTableItem* FileHandler::getScanItem(FileIDType fileid, ScanIDType scanid)
{
	return this->dynamicFileTable->getScan(fileid, scanid);
}

/**
* Process Method
* Validate a scan in the DynamicFileTable, given the fileid and the scanid. 
* The information about the scan is provided here. They will be written to the scan item. 
* 
* @param fileid The dynamic file id of the file. 
* @param scanid The id of the scan. 
* @param scaninfo The information about the scan. 
* @param writetonodemap A boolean value which indicate whether the scan results are to be written to the NodeIDMap. 
*/
void FileHandler::validateScan(FileIDType fileid, 
							   ScanIDType scanid, 
							   ScanInfo* scaninfo, 
							   bool writetonodemap)
{
	this->dynamicFileTable->validateScan(fileid, scanid, scaninfo, writetonodemap);
}

/**
* Process Method
* Invalidate a scan item, with the given fileid and the scan id. 
* It remove the informaiton associated with the scan from the DynamicFileTable. 
* @param fileid The dynamic file id of the file. 
* @param scanid The id of the scan. 
*/
void FileHandler::invalidateScan(FileIDType fileid, 
							   ScanIDType scanid)
{
	this->dynamicFileTable->invalidateScan(fileid, scanid);
}

/**
* Set Method
* Set the information about the data file to the item in the DynamicFileTable
* that is associated with the file with the given id. 
* @param fileid The dynamic id of the data file.
* @param fileinfo The information about the data file. 
*/
void FileHandler::setFileInfo(FileIDType fileid, 
							  FileInfoType* fileinfo)
{
	this->dynamicFileTable->setFileInfo(fileid, fileinfo);
}

/**
* Debug Method
* Print the content of the buffer (NodeIDMap) associated with a data file. 
* @param fileid The dynamic id of the data file. 
*/
void FileHandler::printNodeIDMap(FileIDType fileid)
{
	NodeIDMap* idMap = this->getNodeIDMap(fileid);
	if (idMap == NULL)
          globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"FileHandler",__FILE__,"NodeIDMap is NULL");
	else
		idMap->printContent();
}

/**
* File Interface
* Get the names of all the data files in the database. 
* This is done by calling the correspondent function provided by PhyscialDataMng.
* @param num The total number of data files in the database (return value).
* @returns The list of names of the data file. 
*/
char** FileHandler::getFileNames(int* num)
{
	return this->physicalDataMng->getFileNames(num);
}

