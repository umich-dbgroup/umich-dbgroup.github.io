/*
  COPYRIGHT  � 2000-2004 
  THE REGENTS OF THE UNIVERSITY OF MICHIGAN
  ALL RIGHTS RESERVED

  PERMISSION IS GRANTED TO USE, COPY, CREATE DERIVATIVE WORKS AND
  REDISTRIBUTE THIS SOFTWARE AND SUCH DERIVATIVE WORKS FOR NONCOMMERCIAL
  EDUCATION AND RESEARCH PURPOSES, SO LONG AS NO FEE IS CHARGED, AND SO
  LONG AS THE COPYRIGHT NOTICE ABOVE, THIS GRANT OF PERMISSION, AND THE
  DISCLAIMER BELOW APPEAR IN ALL COPIES MADE; AND SO LONG AS THE NAME OF
  THE UNIVERSITY OF MICHIGAN IS NOT USED IN ANY ADVERTISING OR PUBLICITY
  PERTAINING TO THE USE OR DISTRIBUTION OF THIS SOFTWARE WITHOUT
  SPECIFIC, WRITTEN PRIOR AUTHORIZATION.

  THIS SOFTWARE IS PROVIDED AS IS, WITHOUT REPRESENTATION FROM THE
  UNIVERSITY OF MICHIGAN AS TO ITS FITNESS FOR ANY PURPOSE, AND WITHOUT
  WARRANTY BY THE UNIVERSITY OF MICHIGAN OF ANY KIND, EITHER EXPRESS OR
  IMPLIED, INCLUDING WITHOUT LIMITATION THE IMPLIED WARRANTIES OF
  MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE. THE REGENTS OF
  THE UNIVERSITY OF MICHIGAN SHALL NOT BE LIABLE FOR ANY DAMAGES,
  INCLUDING SPECIAL, INDIRECT, INCIDENTAL, OR CONSEQUENTIAL DAMAGES,
  WITH RESPECT TO ANY CLAIM ARISING OUT OF OR IN CONNECTION WITH THE USE
  OF THE SOFTWARE, EVEN IF IT HAS BEEN OR IS HEREAFTER ADVISED OF THE
  POSSIBILITY OF SUCH DAMAGES.
*/

#include "../StdAfx.h"
#include "UpdateHandler.h"
#include "../../Utilities/ErrorInfoClass.h"
#include "../../Evaluator/Iterators/Sort/SortIterator.h"
#include "../../IndexMng/IndexOperation/IndexIncrementalUpdate.h"

#include <sstream>
#include <vector>
#include <algorithm>
using std::stringstream;
using std::ios;
using std::fixed;
using std::setiosflags;
using std::setprecision;

UpdateHandler::UpdateHandler(PhysicalDataMng* pdatamng,
                             ScanHandler* shdl,
                             NavigationHandler* nhdl)

{
  this->physicalDataMng = pdatamng;
  this->scanHandler = shdl;
  this->navigationHandler = nhdl;
}

UpdateHandler::~UpdateHandler(void)
{
}

/**
* returns -1 if there was an error.
* returns the start key of the deleted node otherwise
*/
double UpdateHandler::deleteLeafNode(IndexIncrementalUpdate *indexUpdater, 
								  NodeIDMap *idMap,
								  FileInfoType* fileinfo, 
								  KeyType nodekey,
								  KeyType deleteNodeParentKey)
{
  
	// information about the node to be deleted
	serial_t rid;
	DM_DataNode* nodeToDelete;

	// the relative nodes that may need to change
	KeyType parentKey, prevSiblingKey, nextSiblingKey, attrKey;
	DM_DataNode* parentNode;
	DM_DataNode* prevSiblingNode;
	DM_DataNode* nextSiblingNode;

	serial_t parentRid;
	serial_t prevSiblingRid;
	serial_t nextSiblingRid;

	DM_DataNode* attrNode = NULL;
	serial_t attrRid;

	rc_t rc;

	// get the node to be deleted
	nodeToDelete = this->physicalDataMng->fetchDataNodeFromDBFile((const FileInfoType) *fileinfo, nodekey, &rid);

	if (nodeToDelete == NULL)
	{
		globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"UpdateHandler",__FILE__,"The node to be deleted does not exist.");
		return -1;
	}
	if (!nodeToDelete->isLeafNode()) {
		globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"UpdateHandler::deleteNode",__FILE__,"Deletion of a single interior node is not supported");
		return -1;
	}

	// get its relatives
	parentKey = nodeToDelete->getParent();

	prevSiblingKey = nodeToDelete->getPrevSibling();
	//Nuwee added: 06/30/2003 for Multicolor
	//If key is not valid , and it is char node, and attribute key is valid
	if ((!prevSiblingKey.isValid()) && 
		((nodeToDelete->getFlag() == TEXT_NODE) || (nodeToDelete->getFlag() == COMMENT_NODE)) &&
		(((DM_CharNode*)nodeToDelete)->getAttributes().isValid()))
	{
		parentKey = deleteNodeParentKey; //added 12/3/04 parent's key for multicolor cannot get from
		//the node to delete (if it is text node) directly, since it can have many parents
		//we need specific parent from the calling function

		// it is part of the children of Multicolor node
		//go to that attribute node to get next sibling of this char node
		DM_DataNode* attrnode;
		attrnode = this->physicalDataMng->fetchDataNodeFromDBFile((const FileInfoType) *fileinfo, ((DM_CharNode*)nodeToDelete)->getAttributes(), NULL);
		prevSiblingKey = ((DM_AttributeNode*)attrnode)->getMCTPrevSibling(parentKey,nodeToDelete->getKey());
		delete attrnode;
	}
	//end Multicolor

	nextSiblingKey = nodeToDelete->getNextSibling();
	//Nuwee added: 06/30/2003 for Multicolor
	//If mct is true, key is not valid , and it is char node, and attribute key is valid
	if ((!nextSiblingKey.isValid()) && 
		((nodeToDelete->getFlag() == TEXT_NODE) || (nodeToDelete->getFlag() == COMMENT_NODE)) &&
		(((DM_CharNode*)nodeToDelete)->getAttributes().isValid()))
	{
		//need to get parent key from the calling function, because it does not know which tree it is performing on.
		parentKey = deleteNodeParentKey;//added 12/3/04

		// it is part of the children of Multicolor node
		//go to that attribute node to get next sibling of this char node
		DM_DataNode* attrnode;
		attrnode = this->physicalDataMng->fetchDataNodeFromDBFile((const FileInfoType) *fileinfo, ((DM_CharNode*)nodeToDelete)->getAttributes(), NULL);
		nextSiblingKey = ((DM_AttributeNode*)attrnode)->getMCTNextSibling(parentKey,nodeToDelete->getKey());
		delete attrnode;
	}
	//end Multicolor

	if (parentKey != -1)
	{
		parentNode = this->physicalDataMng->fetchDataNodeFromDBFile((const FileInfoType) *fileinfo, parentKey, &parentRid);
		if (parentNode->getFlag() == DOCUMENT_NODE) {
			globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"UpdateHandler",__FILE__,"The parent of the node to be deleted cannot be the document node");
			return -1;
		}
		if (parentNode == NULL)
		{
			globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"UpdateHandler",__FILE__,"The parent of the node to be deleted can not be found.");
			return -1;
		}
	}
	else parentNode = NULL;

	if (prevSiblingKey != -1)
	{
		prevSiblingNode = this->physicalDataMng->fetchDataNodeFromDBFile((const FileInfoType) *fileinfo, prevSiblingKey, &prevSiblingRid);
		if (prevSiblingNode == NULL)
		{
			globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"UpdateHandler",__FILE__,"The previous sibling of the node to be deleted can not be found in the database.");
			return -1;
		}
	}
	else prevSiblingNode = NULL;

	if (nextSiblingKey != -1)
	{
		nextSiblingNode = this->physicalDataMng->fetchDataNodeFromDBFile((const FileInfoType) *fileinfo, nextSiblingKey, &nextSiblingRid);
		if (nextSiblingNode == NULL)
		{
			globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"UpdateHandler",__FILE__,"The next sibling of the node to be deleted can not be found in the database.");
			return -1;
		}
	}
	else nextSiblingNode = NULL;

	//should we consider an element node with an attribute to be a leaf node?  according to node->isLeafNode(), yes:
	if (nodeToDelete->getFlag() == ELEMENT_NODE)
	{
		attrKey = ((DM_ElementNode*) nodeToDelete)->getAttributes();
		if (attrKey != -1)
		{
			attrNode = this->physicalDataMng->fetchDataNodeFromDBFile((const FileInfoType) *fileinfo, attrKey, &attrRid);
			if (attrNode == NULL)
			{
				globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"UpdateHandler",__FILE__,"The attribute of the node to be deleted can not be found in the database.");
				return  -1;
			}
			
			//indexUpdater->attributeNodeDeletion(parentKey, static_cast<DM_AttributeNode*>(attrNode));
			bool indexRetVal = indexUpdater->nodeDeletion(fileinfo, static_cast<DM_ElementNode*>(nodeToDelete), attrNode);
			if (!indexRetVal) {
				//unfortunately, gist does not support write-ahead logging for indices
				//so aborting the transaction will not return us to a correct state:
				globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"DeleteLeafNode",__FILE__,
					"There was a problem with updating the indices.  The data was left unchanged by the update query, but indices must be rebuilt");
				physicalDataMng->abortTransaction();
				return -1;
			}
			this->physicalDataMng->deleteNodeFromDBFile(fileinfo, attrKey); //, rid);
			idMap->deleteNode(attrKey);
		}
	}

	// besides delete the node with key equal to nodekey. the info in its relatives need to be changed, too.

	if (nodeToDelete->getFlag() == ATTRIBUTE_NODE)
	{
		// in case it is an attribute node, need to modify the information of the element node 
		// it associates with
		((DM_ElementNode*) parentNode)->setAttrNumber(0);
		((DM_ElementNode*) parentNode)->setAttributes(-1);

		// modify the parent node.  is this a fixed size modification?
		//this->modifyNode(idMap, fileinfo, parentNode->getKey(), parentNode);
		this->fixedSizeModifyNode(idMap, parentNode->getKey(), parentNode, parentRid);
	}
	else
	{
		// otherwise, need to do the following
		// 1. modify the pointers in its siblings that point to this node
		// 2. modify the information in the parend node (child number, first/last 
		// child link, if applied)

		if (parentNode != NULL)
		{
			((DM_ElementNode*) parentNode)->deleteChild(nodekey, prevSiblingNode, nextSiblingNode);
			//this->modifyNode(idMap, fileinfo, parentKey, parentNode);
			this->fixedSizeModifyNode(idMap, parentKey, parentNode, parentRid);

			if (prevSiblingNode != NULL)
				this->fixedSizeModifyNode(idMap, prevSiblingKey, prevSiblingNode, prevSiblingRid);
				//this->modifyNode(idMap, fileinfo, prevSiblingKey, prevSiblingNode);
			if (nextSiblingNode != NULL)
				this->fixedSizeModifyNode(idMap, nextSiblingKey, nextSiblingNode, nextSiblingRid);
				//this->modifyNode(idMap, fileinfo, nextSiblingKey, nextSiblingNode);
		}
	}

	bool indexRetVal = indexUpdater->nodeDeletion(fileinfo, parentKey, nodeToDelete);
	if (!indexRetVal) {
		//unfortunately, gist does not support write-ahead logging for indices
		//so aborting the transaction will not return us to a correct state:
		globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"DeleteLeafNode",__FILE__,
			"There was a problem with updating the indices.  The data was left unchanged by the update query, but indices must be rebuilt");
		physicalDataMng->abortTransaction();
		return -1;
	}
	// finally, delete the node from  SHORE file
	this->physicalDataMng->deleteNodeFromDBFile(fileinfo, nodekey); //, rid);
	idMap->deleteNode(nodekey);

	//clean up memory:
	delete nodeToDelete;

	if (parentNode != NULL)
		delete parentNode;
	if (prevSiblingNode != NULL)
		delete prevSiblingNode;
	if (nextSiblingNode != NULL)
		delete nextSiblingNode;

	return nodekey.toDouble();
}

/**
* returns the number of nodes that were deleted from the subtree
* (each text node counts as one node)
* if there was an error that requires an abortTransaction, returns -1
*/
int UpdateHandler::deleteSubTree(IndexIncrementalUpdate* indexUpdater,
								 NodeIDMap *idMap,
								 FileInfoType* fileinfo,
                                 KeyType nodekey)
{
	// variables

	// information about the node to be deleted
	serial_t rid;
	DM_DataNode* nodeToDelete;

	// the relative nodes that may need to change
	KeyType parentKey, prevSiblingKey, nextSiblingKey;
	DM_DataNode* parentNode;
	DM_DataNode* prevSiblingNode;
	DM_DataNode* nextSiblingNode;

	serial_t parentRid;
	serial_t prevSiblingRid;
	serial_t nextSiblingRid;

	rc_t rc;


	nodeToDelete = this->physicalDataMng->fetchDataNodeFromDBFile((const FileInfoType) *fileinfo, nodekey, &rid);

	if (nodeToDelete == NULL)
	{
		globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"UpdateHandler",__FILE__,"The node to be deleted does not exist.");
		return -1;
	}

	// get its relatives
	parentKey = nodeToDelete->getParent();
	prevSiblingKey = nodeToDelete->getPrevSibling();
	//Nuwee added: 06/30/2003 for Multicolor
	//If key is not valid , and it is char node, and attribute key is valid
	if ((!prevSiblingKey.isValid()) && 
		((nodeToDelete->getFlag() == TEXT_NODE) || (nodeToDelete->getFlag() == COMMENT_NODE)) &&
		(((DM_CharNode*)nodeToDelete)->getAttributes().isValid()))
	{
		// it is part of the children of Multicolor node
		//go to that attribute node to get next sibling of this char node
		DM_DataNode* attrnode;
		attrnode = this->physicalDataMng->fetchDataNodeFromDBFile((const FileInfoType) *fileinfo, ((DM_CharNode*)nodeToDelete)->getAttributes(), NULL);
		prevSiblingKey = ((DM_AttributeNode*)attrnode)->getMCTPrevSibling(parentKey,nodeToDelete->getKey());
		delete attrnode;
	}
	//end Multicolor

	nextSiblingKey = nodeToDelete->getNextSibling();
	//Nuwee added: 06/30/2003 for Multicolor
	//If key is not valid , and it is char node, and attribute key is valid
	if ((!nextSiblingKey.isValid()) && 
		((nodeToDelete->getFlag() == TEXT_NODE) || (nodeToDelete->getFlag() == COMMENT_NODE)) &&
		(((DM_CharNode*)nodeToDelete)->getAttributes().isValid()))
	{
		// it is part of the children of Multicolor node
		//go to that attribute node to get next sibling of this char node
		DM_DataNode* attrnode;
		attrnode = this->physicalDataMng->fetchDataNodeFromDBFile((const FileInfoType) *fileinfo, ((DM_CharNode*)nodeToDelete)->getAttributes(), NULL);
		nextSiblingKey = ((DM_AttributeNode*)attrnode)->getMCTNextSibling(parentKey,nodeToDelete->getKey());
		delete attrnode;
	}
	//end Multicolor

	if (parentKey != -1)
	{
		parentNode = this->physicalDataMng->fetchDataNodeFromDBFile((const FileInfoType) *fileinfo, parentKey, &parentRid);
		if (parentNode->getFlag() == DOCUMENT_NODE) {
			globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"UpdateHandler",__FILE__,"The parent of the node to be deleted cannot be the document node");
			return -1;
		}
		if (parentNode == NULL)
		{
			globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"UpdateHandler",__FILE__,"The parent of the node to be deleted does not exist");
			return -1;
		}
	}
	else parentNode = NULL;

	if (prevSiblingKey != -1)
	{
		prevSiblingNode = this->physicalDataMng->fetchDataNodeFromDBFile((const FileInfoType) *fileinfo, prevSiblingKey, &prevSiblingRid);
		if (prevSiblingNode == NULL)
		{
			globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"UpdateHandler",__FILE__,"The previous sibling of the node to be deleted does not exist.");
			return -1;
		}
	}
	else prevSiblingNode = NULL;

	if (nextSiblingKey != -1)
	{
		nextSiblingNode = this->physicalDataMng->fetchDataNodeFromDBFile((const FileInfoType) *fileinfo, nextSiblingKey, &nextSiblingRid);
		if (nextSiblingNode == NULL)
		{
			globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"UpdateHandler",__FILE__,"The next sibling of the node to be deleted does not exist.");
			return -1;
		}
	}
	else nextSiblingNode = NULL;

	// we delete a subtree in the following steps
	// 1. delete all nodes in the subtree rooted at the given node
	// 2. modify the sibling pointers in the sibling node of the root of the subtree
	// 3. modify the children number and the first/last child pointer in the parent node of the root of the subtree

	// delete subtree nodes


	//AN: since we have the overflow, nodes may not be returned in key order from a scan.
	//but, the index updater needs to have the parent info when deleting text or attributes of an element.
	//to do this (somewhat) efficiently we need to sort the (hopefully small) overflow area, to have
	//access to nodes in key order

	//using a vector here is a temporary fix, need to switch to a "shore sort" to avoid memory overhead problems,
	//in case overflow is large
	//(although a file reorganization should be done if the overflow is large, and the nodes that go into the
	//vector are only those that are in the subtree of nodekey):

	vector<KeyType> overflowKeys;

	if (fileinfo->overflow) {
		SelectionCondition* overflowScanCondition = new SelectionCondition(SCAN_ALLNODES,
			NULL,
			SCAN_RETURN_THISNODE);

		//2=just scan overflow:
		ScanInfo* scanInfo = scanHandler->startScan(fileinfo, nodekey, 0, -1, NULL, overflowScanCondition, 2);

		DM_DataNode* currentOverflowNode = NULL;

		if (scanInfo != NULL)
		{
			//true=write to nodeIDMap:
			currentOverflowNode = this->scanHandler->scanFetchNext(scanInfo, true, idMap);
			while (currentOverflowNode != NULL)
			{
				overflowKeys.push_back(currentOverflowNode->getKey());
				
				//only delete this here if we don't write it to the nodeIDMap:
				//delete currentOverflowNode;
				
				//true=write to nodeIDMap:
				currentOverflowNode = this->scanHandler->scanFetchNext(scanInfo, true, idMap);
			}
			this->physicalDataMng->clearScan(scanInfo);
		} 
		else {
			globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"UpdateHandler::deleteSubTree",__FILE__,"Error reported while starting overflow scan."); 
		}

		//sort the overflow nodes (that are in the the subtree with root key=nodekey)
		sort(overflowKeys.begin(), overflowKeys.end());

	} //if overflow



//cout << "overflowKeys.size()=" << overflowKeys.size() << endl;
//vector<KeyType>::iterator it;
//for( it = overflowKeys.begin(); it != overflowKeys.end(); it++ )
//	cout << it->toDouble() << endl;
//return NO_ERROR;

	SelectionCondition* scanCondition = new SelectionCondition(SCAN_ALLNODES,
		NULL,
		SCAN_RETURN_THISNODE);

	DM_DataNode* currentNode = NULL;
	KeyType currentNodeKey;
	int numberOfNodesDeleted = 0;

	//DM_DataNode* nextScanNode = NULL;

	//we store a stack of element nodes along the path from the root element node of the subtree
	//(rooted at nodekey), to the current node being deleted.
	//(we use this to pass parent element node info into the index update methods)
	vector<DM_ElementNode*> elementNodesStack;

	//1=only scan sorted portion of the file:
	ScanInfo* scanInfo = scanHandler->startScan(fileinfo, nodekey, 0, -1, NULL, scanCondition, 1);
	//if all the nodes are in the overflow, then scanInfo==NULL, but we should still go through the
	//overflow nodes (note that scanFetchNext will return NULL if scanInfo==NULL)
	if (scanInfo != NULL || overflowKeys.size() > 0)
	{
		//if the root (key==nodekey) is in the overflow, grab it from there
		if (overflowKeys.size() > 0 && overflowKeys.front() == nodekey) {
			currentNode = this->navigationHandler->getDataNode(idMap, fileinfo, nodekey, true);
			overflowKeys.erase(overflowKeys.begin());
		}
		//otherwise it will be in the sorted file area and we will get it with scanFetchNext:
		else {
			//true -> write to nodeIDMap:
			currentNode = this->scanHandler->scanFetchNext(scanInfo, true, idMap);
		}

		//keep track of where we grabbed the last node from (the first time through we'll grab from both):
		bool usedOverflowNode = true;
		bool usedScanNode = true;
		DM_DataNode* nextOverflowNode = NULL;
		DM_DataNode* nextScanNode = NULL;


		while (currentNode != NULL)
		{
			currentNodeKey = currentNode->getKey();

			//delete the node, and related info from the indices:
			//if the node to delete is the first (root) node, then pass in the parent key to the index updater:
			if (currentNodeKey == nodekey) {
				bool indexRetVal = indexUpdater->nodeDeletion(fileinfo, currentNode->getParent(), currentNode);
				if (!indexRetVal) {
					//unfortunately, gist does not support write-ahead logging for indices
					//so aborting the transaction will not return us to a correct state:
					globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"DeleteSubTree",__FILE__,
						"There was a problem with updating the indices.  The data was left unchanged by the update query, but indices must be rebuilt");
					physicalDataMng->abortTransaction();
					return -1;
				}
			}
			else {
				//since we are scanning nodes in order (due to the sort and merge of the overflow)
				//we can remove element nodes off the top of the stack that aren't the parent of the current node
				//we won't need these again...
				DM_ElementNode* parentNode = elementNodesStack.back();
				while(!parentNode->isParentOf(currentNode)) {
					elementNodesStack.pop_back();
					delete parentNode;
					parentNode = elementNodesStack.back();
				}
				bool indexRetVal = indexUpdater->nodeDeletion(fileinfo, parentNode, currentNode);
				if (!indexRetVal) {
					//unfortunately, gist does not support write-ahead logging for indices
					//so aborting the transaction will not return us to a correct state:
					globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"DeleteSubTree",__FILE__,
						"There was a problem with updating the indices.  The data was left unchanged by the update query, but indices must be rebuilt");
					physicalDataMng->abortTransaction();
					return -1;
				}
				//delete parentNode;
			}

			if (currentNode->getFlag() == ELEMENT_NODE) {
				//push a COPY of the current element node onto the stack:
				elementNodesStack.push_back(new DM_ElementNode(static_cast<DM_ElementNode*>(currentNode)));
			}

			// delete the node from DB
			this->physicalDataMng->deleteNodeFromDBFile(fileinfo, currentNodeKey);
			//fileinfo->recNum--; //AN: should just put this inside deleteNodeFromDBFile
			idMap->deleteNode(currentNodeKey);

			numberOfNodesDeleted++;

			//only delete if not using nodeIDMap in scanFetchNext
			//delete currentNode;


			//grab a new node from whatever location was used last time
			//(the first time through, we'll grab from both)

			if (usedScanNode) {
				nextScanNode = this->scanHandler->scanFetchNext(scanInfo, true, idMap);
			}

			if (usedOverflowNode) {
				if (overflowKeys.size() > 0) {
					nextOverflowNode = this->navigationHandler->getDataNode(idMap, fileinfo, overflowKeys.front(), true);
					overflowKeys.erase(overflowKeys.begin());
				}
				else
					nextOverflowNode = NULL;
			}

			//assign the current node to be either the nextOverflowNode of the nextScanNode:

			//if both nodes are NULL, we have deleted all nodes, and we exit the while loop:
			if (nextScanNode == NULL && nextOverflowNode == NULL)
				currentNode = NULL;
			else if (nextScanNode != NULL && nextOverflowNode != NULL) {
				if (nextScanNode->getKey() < nextOverflowNode->getKey()) {
					currentNode = nextScanNode;
					usedScanNode = true;
					usedOverflowNode = false;
				}
				else {
					currentNode = nextOverflowNode;
					usedScanNode = false;
					usedOverflowNode = true;
				}
			}
			//one of the nodes was NULL:
			else {
				if (nextScanNode != NULL) {
					currentNode = nextScanNode;
					usedScanNode = true;
					usedOverflowNode = false;
				}
				else {
					currentNode = nextOverflowNode;
					usedScanNode = false;
					usedOverflowNode = true;
				}
			}
		} //while currentNode != NULL
		this->physicalDataMng->clearScan(scanInfo);

	} 
	else {
		globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"UpdateHandler::deleteSubTree",__FILE__,"Error reported while starting scan of sorted file portion"); 
	}


	//OLD SCAN, not necessarily in key order (if overflow section)
	//this causes problems for the index updating (content indices and parent index):
	// prepare a scan
/*
	ScanInfo* scaninfo;
	DM_DataNode* cntNode;
	KeyType cntNodeKey;
	serial_t cntNodeRid;

	SelectionCondition* scancond;
	scancond = new SelectionCondition(SCAN_ALLNODES,
		NULL,
		SCAN_RETURN_THISNODE);

	ScanRange* scanRanges;
	ScanRangeType* scanRange;
	scanRanges = new ScanRange(1);
	scanRange = new ScanRangeType();
	scanRange->startPos = nodeToDelete->getKey();
	scanRange->endPos = nodeToDelete->getEndKey();
	scanRanges->setScanRangeAt(0, scanRange);

	// scan the whole subtree rooted at the node to delete

	scaninfo = this->scanHandler->startScan(fileinfo, nodekey, 0, -1, 
		scanRanges, scancond);

	//SortIterator* sortIterator = new SortIterator(scanIDType, fileIDType, -1, dataMng);

	if (scaninfo != NULL)
	{
		//false -> don't write to nodeIDMap:
		cntNode = this->scanHandler->scanFetchNext(scaninfo, false, NULL);
		while (cntNode!= NULL)
		{
			cntNodeKey = cntNode->getKey();
#ifdef DEBUG
			ostringstream oss;
			oss << "currentNodeKey=";
			oss << cntNodeKey;

			globalErrorInfo.insertProblem(ERR_TYPE_NOTE,__LINE__,"UpdateHandler",__FILE__,oss.str().c_str()); 
#endif
			//delete the node, and related info from the indices
			bool indexRetVal = indexUpdater->nodeDeletion(fileinfo, cntNode->getParent(), cntNode);
			if (!indexRetVal) {
				//unfortunately, gist does not support write-ahead logging for indices
				//so aborting the transaction will not return us to a correct state:
				globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"DeleteSubTree",__FILE__,
					"There was a problem with updating the indices.  The data was left unchanged by the update query, but indices must be rebuilt");
				node = NULL;
				physicalDataMng->abortTransaction();
				return;
			}

			// delete the node from DB
			this->physicalDataMng->deleteNodeFromDBFile(fileinfo, cntNodeKey);
			//fileinfo->recNum--; //AN: should just put this inside deleteNodeFromDBFile
			idMap->deleteNode(cntNodeKey);

			delete cntNode;
			cntNode = this->scanHandler->scanFetchNext(scaninfo, false, NULL);
		}
		this->physicalDataMng->clearScan(scaninfo);
	} 
	else {
		globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"UpdateHandler",__FILE__,"Error reported while starting scan."); 
	}
*/


	// modify the previous sibling of the root of the subtree to delete 
	if (prevSiblingNode != NULL)
	{
		prevSiblingNode->setNextSibling(nextSiblingKey);
		//this->modifyNode(idMap, fileinfo, prevSiblingKey, prevSiblingNode);
		this->fixedSizeModifyNode(idMap, prevSiblingKey, prevSiblingNode, prevSiblingRid);
	}
	else
	{
		// if the root of the subtree to delete is the first child of its parend, 
		// now, the first child is its next sibling
		((DM_ElementNode*) parentNode)->setFirstChild(nextSiblingKey);
	}

	// modify the next sibling of the root of the subtree to delete
	if (nextSiblingNode != NULL)
	{
		nextSiblingNode->setPrevSibling(prevSiblingKey);
		//this->modifyNode(idMap, fileinfo, nextSiblingKey, nextSiblingNode);
		this->fixedSizeModifyNode(idMap, nextSiblingKey, nextSiblingNode, nextSiblingRid);
	}
	else
	{
		// if the root of the subtree to delete is the last child of its parend, 
		// now, the first child is its previsou sibling
		((DM_ElementNode*) parentNode)->setLastChild(prevSiblingKey);
	}

	// modify the child count in the parent node (item 1)
	int newChildNumber = parentNode->getChildNumber() - 1 ;
	((DM_ElementNode*) parentNode)->setChildNumber(newChildNumber);
	//this->modifyNode(idMap, fileinfo, parentKey, parentNode);		
	this->fixedSizeModifyNode(idMap, parentKey, parentNode, parentRid);

	//clean up memory:
	delete nodeToDelete;

	if (parentNode != NULL)
		delete parentNode;
	if (prevSiblingNode != NULL)
		delete prevSiblingNode;
	if (nextSiblingNode != NULL)
		delete nextSiblingNode;

	//elementNodesStack.clear();
	vector<DM_ElementNode*>::iterator it;
	for (it = elementNodesStack.begin(); it != elementNodesStack.end(); it++) {
		delete *it;
	}

	//return NO_ERROR;
	return numberOfNodesDeleted;
}

//currently, modifyNode doesn't change the indices, so this must be done in the calling functions
//should change this now that we have fixedSizeModifyNode for all the internal node modifications

int UpdateHandler::modifyNode(NodeIDMap *idMap,
							  FileInfoType* fileinfo, 
                              KeyType nodekey,
                              DM_DataNode* newnode)
{
	this->physicalDataMng->modifyNodeInDBFile(fileinfo, nodekey, newnode);
	//AN: should we insert the new node into the node ID map, or just delete it from the nodeIDMap:
	idMap->deleteNode(nodekey);
	//idMap->insertNode(newnode);
	return NO_ERROR;
}


int UpdateHandler::fixedSizeModifyNode(NodeIDMap *idMap,
									   KeyType oldNodeKey,
									   DM_DataNode* newNode,
									   serial_t newNodeRid)
{
	int retval = this->physicalDataMng->fixedSizeModifyNodeInDBFile(newNode, newNodeRid);
	
	idMap->deleteNode(oldNodeKey);
	return retval;
}

//we pass in the IndexIncrementalUpdate* because we may have to change the parent's end key,
//as well as assigning the new node's key, may need to update indices in response to this
double UpdateHandler::insertLeafNode(IndexIncrementalUpdate *indexUpdater,
									  NodeIDMap *idMap,
									  FileInfoType* fileinfo, 
                                      KeyType nodekey, 	
                                      int childIndex,
                                      DM_DataNode* newnode)
{
	// variables
	KeyType parentKey, prevSiblingKey, nextSiblingKey;
	KeyType startRange, endRange;	// the range that the new key can fall in.
	DM_DataNode* parentNode;
	DM_DataNode* prevSiblingNode;
	DM_DataNode* nextSiblingNode;

	serial_t parentRid;
	serial_t prevSiblingRid;
	serial_t nextSiblingRid;

	prevSiblingNode = NULL;
	nextSiblingNode = NULL;

	serial_t noderid;

	// prepare the range for the new key
	startRange = -1;
	endRange = -1;

	// get the node which will be the parent of the node to insert

	parentNode = this->physicalDataMng->fetchDataNodeFromDBFile((const FileInfoType) *fileinfo, nodekey, &parentRid);
	//store the parentKey for use later when modifying the parent node (and needing to remove it from the nodeIDMap):
	parentKey = nodekey;
	
	// find out whether the parent node is an element node. otherwise, the insertion is not legal

	if (parentNode->getFlag() != ELEMENT_NODE)
	{
		globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"UpdateHandler",__FILE__,"The node specified is not an element node and cannot have the new node inserted as a child."); 
		return -1;
	}

	// get the information needed for the insertaion

	if (newnode->getFlag() == ATTRIBUTE_NODE)
	{
		// in case the node to insert is an attribute node, need to get the key range for it
		startRange = parentKey;
		endRange = parentNode->getFirstChild();
		if (endRange == -1)
			endRange = parentNode->getEndKey();
	}
	else
	{
		// other wise, the new node will be a child of the parent node, 
		// need to fetch the nearest siblings, which should be changed
		// also need to find the key range for the new node
		int childNum = parentNode->getChildNumber();

		//if ((childIndex < 0) | (childNum < childIndex))
		if ((childIndex < 0) || (childNum < childIndex))
		{
			globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"UpdateHandler",__FILE__,"The parent node does not have enough children, and the new node cannot be inserted at desired location."); 
			return  -1;
		}
		// get the future sibling nodes of the node to insert

		if (childIndex == 0)
		{
			prevSiblingKey = -1;

			nextSiblingKey = parentNode->getFirstChild();
			if (nextSiblingKey.isValid()) 
				nextSiblingNode = this->physicalDataMng->fetchDataNodeFromDBFile((const FileInfoType) *fileinfo, nextSiblingKey, &nextSiblingRid);

			if ((childIndex!= parentNode->getChildNumber()) && (nextSiblingNode == NULL))
			{
				globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"UpdateHandler",__FILE__,"The first child of the parent node does not exist"); 
				return -1;
			}
		}
		else if (childIndex == childNum)
		{
			prevSiblingKey = parentNode->getLastChild();
			if (prevSiblingKey.isValid())
				prevSiblingNode = this->physicalDataMng->fetchDataNodeFromDBFile((const FileInfoType) *fileinfo, prevSiblingKey, &prevSiblingRid);

			if ((childIndex != 0) && (prevSiblingNode == NULL))
			{
				globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"UpdateHandler",__FILE__,"The last child of the parent node does not exist"); 
				return -1;
			}

			nextSiblingKey = -1;
		}
		else
		{
			/*
			prevSiblingNode = this->navigationHandler->getChild(NULL, fileinfo, parentKey, childIndex-1, false);
			if ((childIndex != 0) && (prevSiblingNode == NULL))
			{
				globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"UpdateHandler",__FILE__,"The child at the specified index of the parent node does not exist."); 
				return -1;
			}
			else prevSiblingKey = prevSiblingNode->getKey();

			nextSiblingNode = this->navigationHandler->getChild(NULL, fileinfo, parentKey, childIndex, false);
			if ((childIndex!= parentNode->getChildNumber()) && (nextSiblingNode == NULL))
			{
				globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"UpdateHandler",__FILE__,"The child at the specified index of the parent node does not exist."); 
				return -1;
			}
			else nextSiblingKey = nextSiblingNode->getKey();
			*/

			globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"UpdateHandler",__FILE__,"Node insertions are only permitted at either the first or last child position"); 
			return  -1;
		}


		if (prevSiblingNode != NULL)
			startRange = prevSiblingNode->getEndKey();
		else if (((DM_ElementNode*) parentNode)->getAttributes() != -1)
			startRange = ((DM_ElementNode*) parentNode)->getAttributes();
		else startRange = parentKey;

		if (nextSiblingKey != -1)
			endRange = nextSiblingKey;
		else endRange = parentNode->getEndKey();
	}


	// deal with the mergin case for the key range. 
	if (startRange == endRange)
	{
		// in this case, the parent node used to be a leaf node
		// need to change the end key of the parent

		KeyType parentKeyEndRange;

		parentKeyEndRange = parentNode->getNextSibling();
		//Nuwee added: 06/30/2003 for Multicolor
		//If key is not valid , and it is char node, and attribute key is valid
		if ((!parentKeyEndRange.isValid()) && 
			((parentNode->getFlag() == TEXT_NODE) || (parentNode->getFlag() == COMMENT_NODE)) &&
			(((DM_CharNode*)parentNode)->getAttributes().isValid()))
		{
			// it is part of the children of Multicolor node
			//go to that attribute node to get next sibling of this char node
			DM_DataNode* attrnode;
			attrnode = this->physicalDataMng->fetchDataNodeFromDBFile((const FileInfoType) *fileinfo, ((DM_CharNode*)parentNode)->getAttributes(), NULL);
			parentKeyEndRange = ((DM_AttributeNode*)attrnode)->getMCTNextSibling(parentNode->getParent(),parentNode->getKey()); 
			//Not wrong, because parentNode is always element node when coming to this condition, therefore, the parent always valid without getting multicolor information
			delete attrnode;
		}
		//end Multicolor


		if (parentKeyEndRange == -1)
		{
			//false means don't put this node in the idMap
			DM_DataNode* grandparentNode = this->navigationHandler->getParent(idMap, fileinfo, parentKey, false); 
			//Nuwee Multicolor: Not wrong because parent specifying by parentKey is always element node when coming to this condition
			if (grandparentNode == NULL)
			{
				globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"UpdateHandler",__FILE__,"Error reported while fetching node."); 
				return -1;
			}
			parentKeyEndRange = grandparentNode->getEndKey();
			//delete grandparentNode;
		}

		KeyType newParentEndKey = this->getNewKey(parentKey, parentKeyEndRange);
		if (newParentEndKey == -1)
			return -1;

		//indexUpdater->keyModification(parentNode, parentNode->getKey(), newParentEndKey);
		bool indexRetVal = indexUpdater->keyModification(fileinfo, parentNode, parentNode->getKey(), newParentEndKey, parentNode->getLevel());
		if (!indexRetVal) {
			//unfortunately, gist does not support write-ahead logging for indices
			//so aborting the transaction will not return us to a correct state:
			globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"insertLeafNode",__FILE__,
				"There was a problem with updating the indices.  The data was left unchanged by the update query, but indices must be rebuilt");
			physicalDataMng->abortTransaction();
			return -1;
		}

		parentNode->setEndKey(newParentEndKey);

		endRange = newParentEndKey;
		//delete grandparentNode;
	}


	//globalErrorInfo.insertProblem(ERR_TYPE_NOTE,__LINE__,"UpdateHandler",__FILE__,"Start Range."); 
	//globalErrorInfo.insertProblem(ERR_TYPE_NOTE,__LINE__,"UpdateHandler",__FILE__,startRange.toString()); 
	//globalErrorInfo.insertProblem(ERR_TYPE_NOTE,__LINE__,"UpdateHandler",__FILE__,"End Range."); 
	//globalErrorInfo.insertProblem(ERR_TYPE_NOTE,__LINE__,"UpdateHandler",__FILE__,endRange.toString()); 

	// set the key, endkey, and level for the new node

	KeyType newKey = this->getNewKey(startRange, endRange);
	if (newKey == -1)
		return -1;
	newnode->setKey(newKey);
	newnode->setEndKey(newKey);
	newnode->setLevel(parentNode->getLevel() + 1);

	// modify relative nodes of the new node

	if (newnode->getFlag() == ATTRIBUTE_NODE)
	{
		// in case the new node is an attribute node, only need to change the attribute link of its parent;
		((DM_ElementNode*) parentNode)->setAttributes(newKey);
		static_cast<DM_ElementNode*>(parentNode)->setAttrNumber(newnode->getAttributeNumber());
	}
	else
	{
		// otherwise, need to change the parent node, and sibling nodes

		((DM_ElementNode*) parentNode)->insertChild(childIndex, newnode, prevSiblingNode, nextSiblingNode);

		// modify the nodes in DB

		if(prevSiblingNode != NULL)
			//this->modifyNode(idMap, fileinfo, prevSiblingKey, prevSiblingNode);
			this->fixedSizeModifyNode(idMap, prevSiblingKey, prevSiblingNode, prevSiblingRid);

		if(nextSiblingNode != NULL)
			//this->modifyNode(idMap, fileinfo, nextSiblingKey, nextSiblingNode);
			this->fixedSizeModifyNode(idMap, nextSiblingKey, nextSiblingNode, nextSiblingRid);
	}


	// modify the parent node in DB, which is common, not matter what kind of node the new node is.
	//this->modifyNode(idMap, fileinfo, parentKey, parentNode);
	this->fixedSizeModifyNode(idMap, parentKey, parentNode, parentRid);

	// insert the new node to DB
	// since newnode is new, it will not be in the NodeIDMap, and we do not have to modify idMap
	this->physicalDataMng->storeNodeToDBFile(fileinfo, newnode);
	bool indexRetVal = indexUpdater->nodeInsertion(fileinfo, parentKey, newnode);
	if (!indexRetVal) {
		//unfortunately, gist does not support write-ahead logging for indices
		//so aborting the transaction will not return us to a correct state:
		globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"insertLeafNode",__FILE__,
			"There was a problem with updating the indices.  The data was left unchanged by the update query, but indices must be rebuilt");
		physicalDataMng->abortTransaction();
		return -1;
	}

	if (parentNode != NULL)
		delete parentNode;
	if (prevSiblingNode != NULL)
		delete prevSiblingNode;
	if (nextSiblingNode != NULL)
		delete nextSiblingNode;

	return newKey.toDouble();
}



KeyType UpdateHandler::getNewKey(KeyType prev, KeyType next)
{
	KeyType newkey;
	newkey = KeyType::mid(prev, next);

	if ((newkey == prev) || (newkey == next)) {
		stringstream ss;
		ss << setiosflags(ios::fixed);
		ss << setprecision(DBL_DIG);
		ss << "Could not generate a new key in the range: " << "[" << prev.toDouble() << "," << next.toDouble() << "].";
		ss << " The range is too small.";
		ss << " The update was aborted";
	
		globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"UpdateHandler::getNewKey",__FILE__,ss.str().c_str());
		this->physicalDataMng->abortTransaction();
		return -1;
	}
	else 
		return newkey;
}


///  NOT CURRENTLY USED  ///

/*
int UpdateHandler::insertSubTree()
{
  return NO_ERROR;
}
*/

/*
int UpdateHandler::deleteNode(NodeIDMap *idMap, 
							  FileInfoType* fileinfo, 
                              KeyType nodekey)
{
  // variables

  // information about the node to be deleted
  serial_t rid;
  DM_DataNode* nodeToDelete;

  // the relative nodes that may need to change
  KeyType parentKey, prevSiblingKey, nextSiblingKey, attrKey;
  DM_DataNode* parentNode;
  DM_DataNode* prevSiblingNode;
  DM_DataNode* nextSiblingNode;
  DM_DataNode* attrNode = NULL;
  serial_t attrRid;

  rc_t rc;

  // get the node to be deleted
  nodeToDelete = this->physicalDataMng->fetchDataNodeFromDBFile((const FileInfoType) *fileinfo, nodekey, &rid);

  if (nodeToDelete == NULL)
    {
      globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"UpdateHandler",__FILE__,"The node to be deleted does not exist.");
      return -1;
    }

  // get its relatives
  parentKey = nodeToDelete->getParent();

  prevSiblingKey = nodeToDelete->getPrevSibling();
  //Nuwee added: 06/30/2003 for Multicolor
  //If key is not valid , and it is char node, and attribute key is valid
  if ((!prevSiblingKey.isValid()) && 
      ((nodeToDelete->getFlag() == TEXT_NODE) || (nodeToDelete->getFlag() == COMMENT_NODE)) &&
      (((DM_CharNode*)nodeToDelete)->getAttributes().isValid())) {
    // it is part of the children of Multicolor node
    //go to that attribute node to get next sibling of this char node
    DM_DataNode* attrnode;
    attrnode = this->physicalDataMng->fetchDataNodeFromDBFile((const FileInfoType) *fileinfo, ((DM_CharNode*)nodeToDelete)->getAttributes(), NULL);
    prevSiblingKey = ((DM_AttributeNode*)attrnode)->getMCTPrevSibling(parentKey,nodeToDelete->getKey());
    delete attrnode;
  }
  //end Multicolor

	nextSiblingKey = nodeToDelete->getNextSibling();
	//Nuwee added: 06/30/2003 for Multicolor
	//If key is not valid , and it is char node, and attribute key is valid
	if ((!nextSiblingKey.isValid()) && 
		((nodeToDelete->getFlag() == TEXT_NODE) || (nodeToDelete->getFlag() == COMMENT_NODE)) &&
		(((DM_CharNode*)nodeToDelete)->getAttributes().isValid())) {
		// it is part of the children of Multicolor node
		//go to that attribute node to get next sibling of this char node
		DM_DataNode* attrnode;
		attrnode = this->physicalDataMng->fetchDataNodeFromDBFile((const FileInfoType) *fileinfo, ((DM_CharNode*)nodeToDelete)->getAttributes(), NULL);
		nextSiblingKey = ((DM_AttributeNode*)attrnode)->getMCTNextSibling(parentKey,nodeToDelete->getKey());
		delete attrnode;
	}
	//end Multicolor

	  if (parentKey != -1)
	  {
		  parentNode = this->physicalDataMng->fetchDataNodeFromDBFile((const FileInfoType) *fileinfo, parentKey);
		  if (parentNode == NULL)
		  {
			  globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"UpdateHandler",__FILE__,"The parent of the node to be deleted can not be found.");
			  return -1;
		  }
	  }
	  else parentNode = NULL;

	  if (prevSiblingKey != -1)
	  {
		  prevSiblingNode = this->physicalDataMng->fetchDataNodeFromDBFile((const FileInfoType) *fileinfo, prevSiblingKey);
		  if (prevSiblingNode == NULL)
		  {
			  globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"UpdateHandler",__FILE__,"The previous sibling of the node to be deleted can not be found in the database.");
			  return -1;
		  }
	  }
	  else prevSiblingNode = NULL;

	  if (nextSiblingKey != -1)
	  {
		  nextSiblingNode = this->physicalDataMng->fetchDataNodeFromDBFile((const FileInfoType) *fileinfo, nextSiblingKey);
		  if (nextSiblingNode == NULL)
		  {
			  globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"UpdateHandler",__FILE__,"The next sibling of the node to be deleted can not be found in the database.");
			  return -1;
		  }
	  }
	  else nextSiblingNode = NULL;

	  if (nodeToDelete->getFlag() == ELEMENT_NODE)
	  {
		  attrKey = ((DM_ElementNode*) nodeToDelete)->getAttributes();
		  if (attrKey != -1)
		  {
			  attrNode = this->physicalDataMng->fetchDataNodeFromDBFile((const FileInfoType) *fileinfo, attrKey, &attrRid);
			  if (attrNode == NULL)
			  {
				  globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"UpdateHandler",__FILE__,"The attribute of the node to be deleted can not be found in the database.");
				  return  -1;
			  }
		  }
	  }

	  // besides delete the node with key equal to nodekey. the info in its relatives need to be changed, too.
	  // what are affected depends on whether the node to delete is a leaf node or not, and what kind of node it is. 
	  if (nodeToDelete->isLeafNode())
	  {
		  // in case the node is a leaf node

		  if (nodeToDelete->getFlag() == ATTRIBUTE_NODE)
		  {
			  // in case it is an attribute node, need to modify the information of the element node 
			  // it associates with
			  ((DM_ElementNode*) parentNode)->setAttrNumber(0);
			  ((DM_ElementNode*) parentNode)->setAttributes(-1);

			  // modify the parent node
			  this->modifyNode(idMap, fileinfo, parentNode->getKey(), parentNode);
		  }
		  else
		  {
			  // otherwise, need to do the following
			  // 1. modify the pointers in its siblings that point to this node
			  // 2. modify the information in the parend node (child number, first/last 
			  // child link, if applied)

			  if (parentNode != NULL)
			  {
				  ((DM_ElementNode*) parentNode)->deleteChild(nodekey, prevSiblingNode, nextSiblingNode);
				  this->modifyNode(idMap, fileinfo, parentKey, parentNode);
				  if (prevSiblingNode != NULL)
					  this->modifyNode(idMap, fileinfo, prevSiblingKey, prevSiblingNode);
				  if (nextSiblingNode != NULL)
					  this->modifyNode(idMap, fileinfo, nextSiblingKey, nextSiblingNode);
			  }
		  }

		  // finally, delete the node from  SHORE file
		  this->physicalDataMng->deleteNodeFromDBFile(fileinfo, nodekey);//, rid);
		  idMap->deleteNode(nodekey);

		  //vec_t indexkey(&nodekey, sizeof(KeyType));
		  //rc = ss_m::destroy_assoc(this->physicalDataMng->volumeID, fileinfo->keyIndex, 
		  //vec_t(&nodekey, sizeof(KeyType)), 
		  //vec_t(&rid, sizeof(serial_t)));
		  //if (rc) 
		  //{
		  //cerr << "Warning: error reported when destroy shore index item in UpdateHandler::deleteNode" << endl;
		  //cerr << rc << endl;
		  //return -1;
		  //}

		  //rc = ss_m::destroy_rec(this->physicalDataMng->volumeID, rid);
		  //if (rc)
		  //{
		  //cerr << "Warning: error reported when destroy record in UpdateHandler::deleteNode" << endl;
		  //cerr << rc << endl;
		  //return -1;
		  //}

	  }

	  else
    {
      // in case it is not a leaf node, all its children becomes the children of its parent
      // the nodes need to change are as following: 
      // 1. the child number, first child, last child field of the parent node
      // 2. the sibling point of the previous sibling and next sibling of the node to delete
      // 3. the sibling pointer of the first child and last child of the node to delete
      // 4. the parent fields of all children of the node to delete
      // 5. the level field of all descendant of the node to delete

      // change the level field of all descendant. (item 5)
      // also check for direct children and change their parent link (item 4)
      // if the node is the first/last child of the node to delete, change its sibling link (item 3)

      KeyType firstChildKey = nodeToDelete->getFirstChild();
      KeyType lastChildKey = nodeToDelete->getLastChild();

      // prepare a scan

      ScanInfo* scaninfo;
      DM_DataNode* cntNode;
      int nodeToDeleteLevel = nodeToDelete->getLevel();

      SelectionCondition* scancond;
      scancond = new SelectionCondition(SCAN_ALLNODES,
                                        NULL,
                                        SCAN_RETURN_THISNODE);

      ScanRange* scanRanges;
      ScanRangeType* scanRange;
      scanRanges = new ScanRange(1);
      scanRange = new ScanRangeType();
      scanRange->startPos = nodeToDelete->getKey();
      scanRange->endPos = nodeToDelete->getEndKey();
      scanRanges->setScanRangeAt(0, scanRange);

      // scan the whole subtree rooted at the node to delete

      scaninfo = this->scanHandler->startScan(fileinfo, nodekey, 0, -1, 
                                              scanRanges, scancond);

      if (scaninfo != NULL)
        {
          cntNode = this->scanHandler->scanFetchNext(scaninfo, false, NULL);
          while (cntNode!= NULL)
            {
              short cntNodeLevel = cntNode->getLevel();
              cntNode->setLevel(cntNodeLevel - 1);

              if (cntNodeLevel == nodeToDeleteLevel + 1)
                cntNode->setParent(parentKey);

              if (cntNode->getKey() == firstChildKey)
                cntNode->setPrevSibling(prevSiblingKey);

              if (cntNode->getKey() == lastChildKey)
                cntNode->setNextSibling(nextSiblingKey);

              this->modifyNode(idMap, fileinfo, cntNode->getKey(), cntNode);
              delete cntNode;

              cntNode = this->scanHandler->scanFetchNext(scaninfo, false, NULL);
            }
          this->physicalDataMng->clearScan(scaninfo);
        }
      else 
        globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"UpdateHandler",__FILE__,"Start of scan failed.");
 

      // modify the previsous sibling of the node to delete (item 2)
      if (prevSiblingNode != NULL)
        {
          prevSiblingNode->setNextSibling(firstChildKey);
          this->modifyNode(idMap, fileinfo, prevSiblingKey, prevSiblingNode);
        }
      else
        {
          // if the node to delete is the first child of its parend, now, its first child is.
          ((DM_ElementNode*) parentNode)->setFirstChild(firstChildKey);
        }

      // modify the next sibling of the node to delete
      if (nextSiblingNode != NULL)
        {
          nextSiblingNode->setNextSibling(lastChildKey);
          this->modifyNode(idMap, fileinfo, nextSiblingKey, nextSiblingNode);
        }
      else
        {
          // if the node to delete is the last child of its parend, now, its last child is.
          ((DM_ElementNode*) parentNode)->setLastChild(lastChildKey);
        }

      // modify the child count in the parent node (item 1)
      int newChildNumber = parentNode->getChildNumber() - 1 + nodeToDelete->getChildNumber();
      ((DM_ElementNode*) parentNode)->setChildNumber(newChildNumber);
      this->modifyNode(idMap, fileinfo, parentKey, parentNode);		

      // if the node to delete has attribute node, delete it as well
	  if (attrNode != NULL) {
		  this->physicalDataMng->deleteNodeFromDBFile(fileinfo, attrKey);//, attrRid);
			idMap->deleteNode(attrKey);
	  }
        //{
        //rc = ss_m::destroy_assoc(this->physicalDataMng->volumeID, fileinfo->keyIndex, 
        //vec_t(&attrKey, sizeof(KeyType)), 
        //vec_t(&attrRid, sizeof(serial_t)));
        //if (rc)
        //{
        //cerr << "Warning: error reported when destroy shore index item in UpdateHandler::deleteNode" << endl;
        //cerr << rc << endl;
        //return -1;
        //}

        //rc = ss_m::destroy_rec(this->physicalDataMng->volumeID, attrRid);
        //if (rc)
        //{
        //cerr << "Warning: error reported when destroy record in UpdateHandler::deleteNode" << endl;
        //cerr << rc << endl;
        //return -1;
        //}
        //}

      // finally, delete the node to delete from DB

      this->physicalDataMng->deleteNodeFromDBFile(fileinfo, nodekey); //, rid);
		idMap->deleteNode(nodekey);

 //       rc = ss_m::destroy_assoc(this->physicalDataMng->volumeID, fileinfo->keyIndex, 
 //       vec_t(&nodekey, sizeof(KeyType)), 
 //       vec_t(&rid, sizeof(serial_t)));
 //       if (rc)
 //       {
 //       cerr << "Warning: error reported when destroy shore index item in UpdateHandler::deleteNode" << endl;
 //       cerr << rc << endl;
 //       return -1;
 //       }
	//
 //       rc = ss_m::destroy_rec(this->physicalDataMng->volumeID, rid);
 //       if (rc)
 //       {
 //       cerr << "Warning: error reported when destroy record in UpdateHandler::deleteNode" << endl;
 //       cerr << rc << endl;
 //       return -1;
 //       }

	}

	return NO_ERROR;
}
*/


/*
// insert a node on an edge, the parent node on the edge becomes the parent of the new node
// the child on the edge becomes the only child of the new node.

KeyType UpdateHandler::insertNonLeafNode(NodeIDMap *idMap,
										 FileInfoType* fileinfo, 
                                         KeyType nodekey, 
                                         int childIndex,
                                         DM_DataNode* newnode)
{
  // variables
  KeyType parentKey, childKey, prevSiblingKey, nextSiblingKey;
  KeyType startRange, endRange;	// the range that the new key can fall in.
  KeyType newKey, newEndKey;      // the key, end key for the new node
  DM_DataNode* parentNode;
  DM_DataNode* childNode; 
  DM_DataNode* prevSiblingNode;
  DM_DataNode* nextSiblingNode;

  prevSiblingNode = NULL;
  nextSiblingNode = NULL;

  serial_t noderid;

  // find the relative nodes that may be modified, they are:
  // 1. the parent node (specified by nodekey), which will becomes the parent of the new node
  // 2. the child node (specified by childIndex), which will becomes the child of the new node
  // 3. the previous sibling of the child node, which will later becomes the previous sibling of the new node
  // 4. the next sibling of the child node, which will later becomes the next sibling of the new node

  parentNode = this->physicalDataMng->fetchDataNodeFromDBFile((const FileInfoType) *fileinfo, nodekey);
  parentKey = nodekey;
	
  // find out whether the parent node is an element node. otherwise, the insertion is not legal
	
  if (parentNode->getFlag() != ELEMENT_NODE)
    {
      globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"UpdateHandler",__FILE__,"The node specified is not an element node and cannot be insert a new node as its child."); 
      return -1;
    }

  // check whether the childIndex is legal for insertion 
  int childNum = parentNode->getChildNumber();
  //if ((childIndex < 0) | (childNum < childIndex))
  if ((childIndex < 0) || (childNum < childIndex))
    {
      globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"UpdateHandler",__FILE__,"The parent node does not have enough children to insert a child at the specified index."); 
      return  -1;
    }

  // get the child node
  childNode = this->navigationHandler->getChild(NULL, fileinfo, parentKey, childIndex, false);
  if (childNode == NULL)
    {
      globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"UpdateHandler",__FILE__,"Error reported while looking for the specified child."); 
      return -1;
    }
  childKey = childNode->getKey();

  prevSiblingKey = childNode->getPrevSibling();
  //Nuwee added: 06/30/2003 for Multicolor
  //If key is not valid , and it is char node, and attribute key is valid
  if ((!prevSiblingKey.isValid()) && 
      ((childNode->getFlag() == TEXT_NODE) || (childNode->getFlag() == COMMENT_NODE)) &&
      (((DM_CharNode*)childNode)->getAttributes().isValid())) {
    // it is part of the children of Multicolor node
    //go to that attribute node to get next sibling of this char node
    DM_DataNode* attrnode;
    attrnode = this->physicalDataMng->fetchDataNodeFromDBFile((const FileInfoType) *fileinfo, ((DM_CharNode*)childNode)->getAttributes(), NULL);
    prevSiblingKey = ((DM_AttributeNode*)attrnode)->getMCTPrevSibling(parentKey,childNode->getKey());
    delete attrnode;
  }
  //end Multicolor

  if (prevSiblingKey != -1)
    {
      prevSiblingNode = this->physicalDataMng->fetchDataNodeFromDBFile((const FileInfoType) *fileinfo, prevSiblingKey);
      if (prevSiblingNode == NULL)
        {
          globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"UpdateHandler",__FILE__,"Error reported while fetching node."); 
          return -1;
        }
    }

  nextSiblingKey = childNode->getNextSibling();
  //Nuwee added: 06/30/2003 for Multicolor
  //If key is not valid , and it is char node, and attribute key is valid
  if ((!nextSiblingKey.isValid()) && 
      ((childNode->getFlag() == TEXT_NODE) || (childNode->getFlag() == COMMENT_NODE)) &&
      (((DM_CharNode*)childNode)->getAttributes().isValid())) {
    // it is part of the children of Multicolor node
    //go to that attribute node to get next sibling of this char node
    DM_DataNode* attrnode;
    attrnode = this->physicalDataMng->fetchDataNodeFromDBFile((const FileInfoType) *fileinfo, ((DM_CharNode*)childNode)->getAttributes(), NULL);
    nextSiblingKey = ((DM_AttributeNode*)attrnode)->getMCTNextSibling(parentKey,childNode->getKey());
    delete attrnode;
  }
  //end Multicolor

  if (nextSiblingKey != -1)
    {
      nextSiblingNode = this->physicalDataMng->fetchDataNodeFromDBFile((const FileInfoType) *fileinfo, nextSiblingKey);
      if (nextSiblingNode == NULL)
        {
          globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"UpdateHandler",__FILE__,"Error reported while fetching node."); 
          return -1;
        }
    }

  // set the key range for the key of the new node
	
  if (prevSiblingKey >= 0)
    startRange = prevSiblingKey;
  else if (((DM_ElementNode*) parentNode)->getAttributes() >= 0)
    startRange = ((DM_ElementNode*) parentNode)->getAttributes();
  else startRange = parentKey;

  endRange = childKey;

  // get the start key for the new node
  newKey = this->getNewKey(startRange, endRange);

  // set the key range for the endkey of the new node
	
  startRange = childNode->getEndKey();

  if (nextSiblingKey >= 0)
    endRange = nextSiblingKey;
  else endRange = parentNode->getEndKey();

  // get the end key for the new node
  newEndKey = this->getNewKey(startRange, endRange);

  // set the info in the new node
  newnode->setParent(parentKey);
  newnode->setKey(newKey);
  newnode->setEndKey(newEndKey);
  newnode->setLevel(childNode->getLevel());

  // for each node in the subtree rooted at the childNode, need to increase the value of field "Level" by one

  // prepare a scan
  ScanInfo* scaninfo;
  DM_DataNode* cntNode;

  SelectionCondition* scancond;
  scancond = new SelectionCondition(SCAN_ALLNODES,
                                    NULL,
                                    SCAN_RETURN_THISNODE);

  ScanRange* scanRanges;
  ScanRangeType* scanRange;
  scanRanges = new ScanRange(1);
  scanRange = new ScanRangeType();
  scanRange->startPos = childNode->getKey();
  scanRange->endPos = childNode->getEndKey();
  scanRanges->setScanRangeAt(0, scanRange);

  // scan the whole subtree rooted at the child node, increase the level value in each node

  scaninfo = this->scanHandler->startScan(fileinfo, childKey, 0, -1, 
                                          scanRanges, scancond);

  if (scaninfo != NULL)
    {
      cntNode = this->scanHandler->scanFetchNext(scaninfo, false, NULL);
      while (cntNode!= NULL)
        {
          short cntNodeLevel = cntNode->getLevel();
          cntNode->setLevel(cntNodeLevel + 1);
          this->modifyNode(idMap, fileinfo, cntNode->getKey(), cntNode);
          delete cntNode;
          cntNode = this->scanHandler->scanFetchNext(scaninfo, false, NULL);
        }
      this->physicalDataMng->clearScan(scaninfo);
    }
  else 
    globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"UpdateHandler",__FILE__,"Error reported while starting scan."); 
 

  // modify child node
  childNode->setParent(newKey);
  childNode->setLevel(childNode->getLevel() + 1);
  childNode->setPrevSibling(-1);
  childNode->setNextSibling(-1);
  this->modifyNode(idMap, fileinfo, childKey, childNode);

  // modify sibling nodes and parent node

  if (prevSiblingKey >= 0)
    {
      prevSiblingNode->setNextSibling(childNode->getKey());
      this->modifyNode(idMap, fileinfo, prevSiblingKey, prevSiblingNode);
    }
  else ((DM_ElementNode*) parentNode)->setFirstChild(newKey);

  if (nextSiblingKey >= 0)
    {
      nextSiblingNode->setPrevSibling(childNode->getKey());
      this->modifyNode(idMap, fileinfo, nextSiblingKey, nextSiblingNode);
    }
  else ((DM_ElementNode*) parentNode)->setLastChild(newKey);

  this->modifyNode(idMap, fileinfo, parentKey, parentNode);

  // insert the new node into DB
  // since newnode is new, it will not be in the NodeIDMap, and we do not have to modify idMap
  this->physicalDataMng->storeNodeToDBFile(fileinfo, newnode);

  return NO_ERROR;
}
*/
