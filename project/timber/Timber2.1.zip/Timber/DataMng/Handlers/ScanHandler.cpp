/*
  COPYRIGHT  � 2000-2004 
  THE REGENTS OF THE UNIVERSITY OF MICHIGAN
  ALL RIGHTS RESERVED

  PERMISSION IS GRANTED TO USE, COPY, CREATE DERIVATIVE WORKS AND
  REDISTRIBUTE THIS SOFTWARE AND SUCH DERIVATIVE WORKS FOR NONCOMMERCIAL
  EDUCATION AND RESEARCH PURPOSES, SO LONG AS NO FEE IS CHARGED, AND SO
  LONG AS THE COPYRIGHT NOTICE ABOVE, THIS GRANT OF PERMISSION, AND THE
  DISCLAIMER BELOW APPEAR IN ALL COPIES MADE; AND SO LONG AS THE NAME OF
  THE UNIVERSITY OF MICHIGAN IS NOT USED IN ANY ADVERTISING OR PUBLICITY
  PERTAINING TO THE USE OR DISTRIBUTION OF THIS SOFTWARE WITHOUT
  SPECIFIC, WRITTEN PRIOR AUTHORIZATION.

  THIS SOFTWARE IS PROVIDED AS IS, WITHOUT REPRESENTATION FROM THE
  UNIVERSITY OF MICHIGAN AS TO ITS FITNESS FOR ANY PURPOSE, AND WITHOUT
  WARRANTY BY THE UNIVERSITY OF MICHIGAN OF ANY KIND, EITHER EXPRESS OR
  IMPLIED, INCLUDING WITHOUT LIMITATION THE IMPLIED WARRANTIES OF
  MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE. THE REGENTS OF
  THE UNIVERSITY OF MICHIGAN SHALL NOT BE LIABLE FOR ANY DAMAGES,
  INCLUDING SPECIAL, INDIRECT, INCIDENTAL, OR CONSEQUENTIAL DAMAGES,
  WITH RESPECT TO ANY CLAIM ARISING OUT OF OR IN CONNECTION WITH THE USE
  OF THE SOFTWARE, EVEN IF IT HAS BEEN OR IS HEREAFTER ADVISED OF THE
  POSSIBILITY OF SUCH DAMAGES.
*/

#include "ScanHandler.h"
#include "../../Utilities/ErrorInfoClass.h"

/**
 * class ScanHandler
 * 
 * This class support functionality of file scan and those related to scan access. The scan interface can 
 * be supported directly through the PhysicalDataMng, except scanFetchNext(), since buffer management is 
 * involved here at DataMng level. The functions related to scan access are those supporting data instantiation. 
 *
 * @see PhysicalDataMng
 * @see DataMng
 * 
 * @author Yuqing Melanie Wu
 * @version 1.0
 */


/**
 * Constructor
 * Initialize the ScanHandler with the PhysicalDataMng which provide support at physical level.
 */
ScanHandler::ScanHandler(PhysicalDataMng* pdatamng)
{
  this->physicalDataMng = pdatamng;
}

ScanHandler::~ScanHandler(void)
{
}

/**
 * Scan Interface
 * Start A scan. This is done by calling the startScan method in PhysicalDataMng.
 *
 * @param fileinfo The Information of the file in which scan is to be done.
 * @param nodekey The key of the node which is the root of the subtree to be scanned
 * @param scanmethod The scan method (reserved for later use)
 * @param depth The depth to get into the subtree. Only nodes within "depth" to the subtree root can be result of the scan.					 
 * @param scanrange A list of ranges. Only nodes fall in to  the scan range can be result of the scan. 
 * @param condition The scan condition in CNF format.
 * @param overflowSetting 0=scan both sorted and overflow sections, 1=just sorted, 2=just overflow
 * @returns The scaninfo which contains the inforamtion about the scan, and is to be used later for data fetching. 
 *		returns NULL is the scan is illegal, so, something is wrong in the process. 
 */
ScanInfo* ScanHandler::startScan(FileInfoType* fileinfo,
                                 KeyType nodekey,
                                 int scanmethod,
                                 int depth,
                                 ScanRange* scanranges,
                                 SelectionCondition* condition,
								 int overflowSetting)
{
	if (overflowSetting == 0) {
		return this->physicalDataMng->startScan(fileinfo, nodekey, scanmethod, depth, scanranges, condition, true);
	}
	else if (overflowSetting == 1) {
		return this->physicalDataMng->startScan(fileinfo, nodekey, scanmethod, depth, scanranges, condition, false);
	}
	else if (overflowSetting == 2) {
		if (scanranges != NULL)
			globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"ScanHandler",__FILE__,"scanranges should be NULL when overflowSetting == 2");

		return this->physicalDataMng->startOverflowScan(fileinfo, nodekey, scanmethod, depth, condition);
	}
	else {
		globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"ScanHandler",__FILE__,"overflowSetting is not one of: {0, 1, 2}");
		return NULL;
	}
	//return this->physicalDataMng->startScan(fileinfo, nodekey, scanmethod, depth, scanranges, condition);
}


/**
 * Scan Interface
 * Finish a scan. This is done by calling the cleartScan method in PhysicalDataMng.
 *
 * @param scaninfo The information about the scan to be finished
 * @returns Error code
 */
void ScanHandler::clearScan(ScanInfo* scaninfo)
{
  this->physicalDataMng->clearScan(scaninfo);
}

/**
 * Scan Interface
 * 
 * Fetch the next result of the scan. 
 * The node, which is the next scan result, is fetched through the scan interface of PhysicalDataMng.
 * In addition, this method maintains the memory buffer, if it is required. 
 *
 * @param scaninfo The information of the scan.
 * @writetonodemap A boolean value which indicate whether the result node is to be written to the NodeIDMap.
 * @param idMap The NodeIDMap associated with the data file. 
 * @returns The next result node in the scan. NULL if all nodes have been fetched already. 
 */
DM_DataNode* ScanHandler::scanFetchNext(ScanInfo* scaninfo,
                                        bool writetonodemap, 
                                        NodeIDMap* idMap)
{
  DM_DataNode* nodepnt;
  DM_DataNode* nodeFromIDMap;

  // get the scan result throught the PhysicalDataMng. 
  nodepnt = this->physicalDataMng->scanFetchNext(scaninfo);
	
  if (nodepnt == NULL)
    return NULL;

  if (writetonodemap)
    {
      // if writetonodemap is requested, write the node to NodeIDMap.

      nodeFromIDMap = idMap->getNode(nodepnt->getKey());
      if (nodeFromIDMap != NULL)
        {
          // if the node is already in NodeIDMap, delete the node here. 
          delete nodepnt;
          nodepnt = nodeFromIDMap;
        }
      else
        // otherwise, write to NodeIDMap. 
        idMap->insertNode(nodepnt);
    }

  return nodepnt;
}

/**
 * Process Method
 * Instantiate node(s) by bringing the nodes from database to the memory buffer (NodeIDMap). 
 * 
 * @param fileinfo The information of the data file.
 * @param nodekey The key of the node to be instantiated. 
 * @param diSpec The data instantiation specification. 
 * @param idMap The NodeIDMap associated with the data file. 
 * @returns A pointer to the node. 
 *
 * Note: cutting is not currently supported.
 */
DM_DataNode* ScanHandler::dataInstantiation(FileInfoType* fileinfo,
                                            KeyType nodekey, 
                                            DataInstantiationSpecification* diSpec,
                                            NodeIDMap* idMap)
{
  // construct a scan condition that scan for all nodes. 
  SelectionCondition* scancond = new SelectionCondition(SCAN_ALLNODES, NULL, SCAN_RETURN_THISNODE);

  // start a file scan, in the subtree rooted at the nodes with the given key. 
  ScanInfo* scaninfo = this->physicalDataMng->startScan(fileinfo, nodekey, -1, 100, NULL, scancond);

  // get the next result from the scan. 
  bool finish = false;
  DM_DataNode* datanode = this->physicalDataMng->scanFetchNext(scaninfo);
  DM_DataNode* rootnode = datanode;

  if (datanode == NULL)
    finish = true;

  // loop through all the nodes returned from the scan. 
  while (!finish)
    {
      // if the scope for instantiation is limited to the node, then, whenever the scan is out of range, stop
      bool inScope = false;
      int nodetype = datanode->getFlag();

      if (diSpec->scope == DI_SPEC_THENODE)
        {
          // the scope of the DI is only at the node with the given key. 
          if (datanode->getKey() == nodekey)
            // so, if the node returned from scan is the node with the given key, it is in scope
            inScope = true;
          else if (datanode->getParent() == nodekey)
            // otherwise, if the node is the content or attribute of the node with the given key, it is in scope. 
            if ((nodetype == TEXT_NODE) || (nodetype == ATTRIBUTE_NODE))
              inScope = true;
        }
      // result node from the scan is always in scope if the scope specified is subtree. 
      else inScope = true;

      if (!inScope)
        {
          // jump out of the loop is the node is no longer in scope. 
          delete datanode;
          finish = true;
          continue;
        }

      // now, see whether the node is what we want. 
      bool toInsert = false;

      if ((diSpec->element) && (nodetype == ELEMENT_NODE)) toInsert = true;
      if ((diSpec->attribute) && (nodetype == ATTRIBUTE_NODE)) toInsert = true;
      if ((diSpec->content) && (nodetype == TEXT_NODE)) toInsert = true;
	
      // in case the node is what specified in the data instantiation specification
      // insert it to NodeIDMap
      // in case that the node is already in NodeIDMap, delete the node just fetched. 
      if (toInsert)
        {
          DM_DataNode* nodefromIDmap = idMap->getNode(datanode->getKey());
          if (nodefromIDmap == NULL)
            idMap->insertNode(datanode);
          else
            {
              delete datanode;
              datanode = nodefromIDmap;
            }
        }

      // move on to the next node in scan
      datanode = this->physicalDataMng->scanFetchNext(scaninfo);
      if (datanode == NULL)
        finish = true;
    }

  this->physicalDataMng->clearScan(scaninfo);

  return rootnode;
}

/**
 * Process Method
 * Discard nodes from buffer (NodeIDMap). 
 * 
 * @param fileinfo The information of the data file.
 * @param nodekey The key of the node to be discarded from the buffer. 
 * @param diSpec The data instantiation specification which specify what nodes are to be discarded. 
 * @param idMap The NodeIDMap associated with the data file. 
 *
 * Note: cutting is not currently supported.
 */

void ScanHandler::dataDiscard( KeyType nodekey, 
                               DataInstantiationSpecification* diSpec,
                               NodeIDMap* idMap)
{
  // get the node with the given key. 
  DM_DataNode* rootnode = idMap->getNode(nodekey);
  if (rootnode == NULL)
    return;

  // the discarding process is different, depending on the scope specified. 
  switch (diSpec->scope)
    {
    case DI_SPEC_THENODE:
      {
        // the scope is only the nodes. 

        if (diSpec->attribute)
          {
            if (rootnode->getFlag() == ELEMENT_NODE)
              {
                // discard the attribute node associated with the element node, if specified so. 
                KeyType attrkey = ((DM_ElementNode*) rootnode)->getAttributes();
                if (attrkey.isValid())
                  idMap->deleteNode(attrkey);
              }
          }
        if (diSpec->content)
          if (rootnode->getFlag() == ELEMENT_NODE)
            {
              // if the content is specified to be discarded, go over all children of the node
              // and discard all the text nodes among them. 
              KeyType childkey = rootnode->getFirstChild();
              while (childkey.isValid())
                {
                  DM_DataNode* node = idMap->getNode(childkey);
                  KeyType nextchildkey;

                  if (node == NULL)
                    break;
                  else
                    {
                      nextchildkey = rootnode->getNextSibling(); //Nuwee: wrong??? could be node->getNextSibling instead?
							
                      //Nuwee added: 06/30/2003 for Multicolor
                      //If key is not valid , and it is char node, and attribute key is valid
                      if ((!nextchildkey.isValid()) && 
                          ((node->getFlag() == TEXT_NODE) || (node->getFlag() == COMMENT_NODE)) &&
                          (((DM_CharNode*)node)->getAttributes().isValid())) {
                        // it is part of the children of Multicolor node
                        //go to that attribute node to get next sibling of this char node
                        DM_DataNode* attrnode;
                        attrnode = idMap->getNode(((DM_CharNode*)node)->getAttributes());
                        nextchildkey = ((DM_AttributeNode*)attrnode)->getMCTNextSibling(rootnode->getKey(),node->getKey());
                        //delete attrnode;
                      }
                      //end Multicolor
							
                      if (node->getFlag() == TEXT_NODE)
                        idMap->deleteNode(childkey);
                      childkey = nextchildkey;
                    }
                }
            }
        if (diSpec->element)				
          // discard the node itself. 
          idMap->deleteNode(nodekey);
      }
      break;

    case DI_SPEC_SUBTREE:
      {
        // the whole subtree is to be discarded. 

        // find the key range of the rootnode. 
        KeyType start = rootnode->getKey();
        KeyType end = rootnode->getEndKey();

        DM_DataNode* nodelist[10];
        bool finish = false;

        while (!finish)
          {
            // get nodes in the range from  the NodeIDMap, one set at a time, and discard them, 
            // according to the node type specified in the DISpec. 
            int listLength = idMap->getNodesInRange(start, end, nodelist, 10);

            if (listLength == 0)
              {
                finish = true;
                continue;
              }
			
            start = nodelist[listLength-1]->getKey();

            // the last node in the list is not deleted, since it will be used for locating position
            // when next set of nodes are to be found, except the case when the list is the last  list. 
            int numToDelete;
            if (listLength < 10)
              numToDelete = listLength;
            else numToDelete = 9;

            // discard the nodes in the list from NodeIDMap
            for (int i=0; i<numToDelete; i++)
              {
                bool toDelete = false;
                int nodetype = nodelist[i]->getFlag();

                if ((diSpec->element) && (nodetype == ELEMENT_NODE)) toDelete = true;
                if ((diSpec->attribute) && (nodetype == ATTRIBUTE_NODE)) toDelete = true;
                if ((diSpec->content) && (nodetype == TEXT_NODE)) toDelete = true;
				
                if (toDelete)
                  idMap->deleteNode(nodelist[i]->getKey());
              }
          }
      }
      break;

    default:
      globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"ScanHandler",__FILE__,"Illegal data instatiation specification on scope.");
    }

  return;
}

