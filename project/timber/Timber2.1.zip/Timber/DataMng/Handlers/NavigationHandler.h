/*
COPYRIGHT  � 2000-2004 
THE REGENTS OF THE UNIVERSITY OF MICHIGAN
ALL RIGHTS RESERVED

PERMISSION IS GRANTED TO USE, COPY, CREATE DERIVATIVE WORKS AND
REDISTRIBUTE THIS SOFTWARE AND SUCH DERIVATIVE WORKS FOR NONCOMMERCIAL
EDUCATION AND RESEARCH PURPOSES, SO LONG AS NO FEE IS CHARGED, AND SO
LONG AS THE COPYRIGHT NOTICE ABOVE, THIS GRANT OF PERMISSION, AND THE
DISCLAIMER BELOW APPEAR IN ALL COPIES MADE; AND SO LONG AS THE NAME OF
THE UNIVERSITY OF MICHIGAN IS NOT USED IN ANY ADVERTISING OR PUBLICITY
PERTAINING TO THE USE OR DISTRIBUTION OF THIS SOFTWARE WITHOUT
SPECIFIC, WRITTEN PRIOR AUTHORIZATION.

THIS SOFTWARE IS PROVIDED AS IS, WITHOUT REPRESENTATION FROM THE
UNIVERSITY OF MICHIGAN AS TO ITS FITNESS FOR ANY PURPOSE, AND WITHOUT
WARRANTY BY THE UNIVERSITY OF MICHIGAN OF ANY KIND, EITHER EXPRESS OR
IMPLIED, INCLUDING WITHOUT LIMITATION THE IMPLIED WARRANTIES OF
MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE. THE REGENTS OF
THE UNIVERSITY OF MICHIGAN SHALL NOT BE LIABLE FOR ANY DAMAGES,
INCLUDING SPECIAL, INDIRECT, INCIDENTAL, OR CONSEQUENTIAL DAMAGES,
WITH RESPECT TO ANY CLAIM ARISING OUT OF OR IN CONNECTION WITH THE USE
OF THE SOFTWARE, EVEN IF IT HAS BEEN OR IS HEREAFTER ADVISED OF THE
POSSIBILITY OF SUCH DAMAGES.
*/

#ifndef __NavigationHandler_H
#define __NavigationHandler_H
#include <timber-compat.h>

#include "../StdAfx.h"
#include "../NodeIDMap/NodeIDMap.h"
 
/**
* class NavigationHandler
* This handler provide support for the nagivation interface at the DataMng level. 
* 
* The major different between the navigation at the PhysicalDataMng level and at the DataMng level is that
* at PhysicalDataMng level, nodes are access by given fileinfo and node key, and at DataMng level, nodes
* are accessed by given filename, node key, and the relationship of the node you want to find with the node  
* with the given key. This Interface provide the ability to navigate in the XML tree structure, from one node
* to its parent, child, sibling, attribute, etc. 
* 
* Another difference is that the PhysicalDataMng always fetch node from database, on each such request, while
* the DataMng has the support from a memory buffer (NodeIDMap) which keeps some nodes in memory, and can 
* access them quick on the requests that refer to nodes that are currently in the NodeIDMap. The buffer 
* (NodeIDMap) is not visible to the user of the Navigation Interface of DataMng. 
* 
* @see PhysicalDataMng
* @see DataMng
* @see NodeIDMap
* 
* @author Yuqing Melanie Wu
* @version 1.0
*/

class NavigationHandler
{
public:
	/**
	* Constructor
	* Initialize the NavigationHandler with the PhysicalDataMng which provide support to it. 
	*/
	NavigationHandler(PhysicalDataMng* pdatamng);
	~NavigationHandler(void);

	/**
	* Navigation Interface
	* 
	* Get the data node, given the dynamic file id of a file and the key of a node.
	* 
	* @param idmap The NodeIDMap associated with the data file. 
	* @param fileinfo The information about the datafile 
	* @param nodekey The key of the node which data we are looking for. 
	* @param writetoNodeMap A boolean value which inidcate whether the node is to be written to the NodeIDMap.
	* @returns A pointer to the data node, or NULL is no such node exists in the database. 
	*/

	DM_DataNode* getDataNode(NodeIDMap* idmap,
		FileInfoType* fileinfo,
		KeyType nodekey,
		bool writetoNodeMap = true);

	/**
	* Navigation Interface
	* 
	* Given the dynamic file id of a file and the key of a node, 
	* get all the data node in the sub-tree rooted at the node given.
	* 
	* Cutting is possible, which specify the kind(s) of node to fetch, as well as the height of the result subtree. 
	* 
	* @param idmap The NodeIDMap associated with the data file. 
	* @param fileinfo The information about the datafile. 
	* @param nodekey The key of the node, the subtree at that node is we are looking for. 
	* @param cutting The cutting sepcification (type of nodes, depth).
	* @param writetoNodeMap A boolean value which inidcate whether the nodes in the subtree are to be written to the NodeIDMap.
	* @returns A pointer to a data node, which is the root of the subtree, or NULL is the root node does not exist.
	*/
	DM_DataNode* getSubTree(NodeIDMap* idmap,
		FileInfoType* fileinfo,
		KeyType nodekey,
		CuttingType* cutting,
		bool writetoNodeMap );

	/**
	* Navigation Interface
	* 
	* Given the dynamic file id of a file and the key of a node, 
	* get the data node which is the parent of the node with the given key. 
	* 
	* @param idmap The NodeIDMap associated with the data file. 
	* @param fileinfo The information about the datafile 
	* @param nodekey The key of the node whose parent is we are looking for. 
	* @param writetoNodeMap A boolean value which inidcate whether the node is to be written to the NodeIDMap.
	* @returns A pointer to the parent node of the node with the given key. NULL if no node has the given key, 
	*	or the node does not have a parent.
	*/
	DM_DataNode* getParent(NodeIDMap* idmap,
		FileInfoType* fileinfo,
		KeyType nodekey,
		bool writetoNodeMap = true);

	/**
	* Navigation Interface
	* 
	* Given the dynamic file id of a file and the key of a node, and a number (n)
	* get the data node which is the n'th child of the node with the given key. 
	* 
	* @param idmap The NodeIDMap associated with the data file. 
	* @param fileinfo The information about the datafile 
	* @param nodekey The key of the node whose child is we are looking for. 
	* @param index The index of the child starting from 0. Index = -1 mean that the last child is what we are looking for. 
	* @param writetoNodeMap A boolean value which inidcate whether the node is to be written to the NodeIDMap.
	* @returns A pointer to a data node, which is the (index'th) child of the node with the given key.
	*		returns NULL if node with the given key does not exist in the database, or the node does not have 
	*		as many children as needed for fetching the (index'th).
	*/
	DM_DataNode* getChild(NodeIDMap* idmap,
		FileInfoType* fileinfo,
		KeyType nodekey,
		int index,
		bool writetoNodeMap =true);

	/**
	* Navigation Interface
	* 
	* Given the dynamic file id of a file and the key of a node, get the data node which is a sibling 
	* to the node with the given key, and its position is right in front of that node. 
	* 
	* @param idmap The NodeIDMap associated with the data file. 
	* @param fileinfo The information about the datafile 
	* @param nodekey The key of the node whose previous sibling is we are looking for. 
	* @param parentkey The key of the parent of the node whose sibling is to be get, use for Multicolor (Nuwee added 07/01/03)
	* @param writetoNodeMap A boolean value which inidcate whether the result node is to be written to the NodeIDMap.
	* @returns A pointer to a data node, which is the sibling node in front of the node with the given key. 
	*	returns NULL if node with the given key does not exist in the database, or the node is the first child of
	*	its parent.
	*/
	DM_DataNode* getPrevSibling(NodeIDMap* idmap,
		FileInfoType* fileinfo,
		KeyType nodekey,
		KeyType parentkey,
		bool writetoNodeMap = true);

	/**
	* Navigation Interface
	* 
	* Given the dynamic file id of a file and the key of a node, get the data node which is a sibling 
	* to the node given, and its position is right after that node. 
	* 
	* @param idmap The NodeIDMap associated with the data file. 
	* @param fileinfo The information about the datafile 
	* @param nodekey The key of the node whose next sibling is we are looking for. 
	* @param parentkey The key of the parent of the node whose sibling is to be get, use for Multicolor (Nuwee added 07/01/03)
	* @param writetoNodeMap A boolean value which inidcate whether the result node is to be written to the NodeIDMap.
	* @returns A pointer to the data node, which is the sibling node after the node given. 
	*	returns NULL if node with the given key does not exist in the database, or the node is the last child of
	*	its parent.
	*/
	DM_DataNode* getNextSibling(NodeIDMap* idmap,
		FileInfoType* fileinfo,
		KeyType nodekey,
		KeyType parentkey,
		bool writetoNodeMap = true );

	/**
	* Navigation Interface
	* 
	* Given the dynamic file id of a file and the key of a node, find out the number of children the node has. 
	* 
	* @param idmap The NodeIDMap associated with the data file. 
	* @param fileinfo The information about the datafile.
	* @param nodekey The key of the node.
	* @param writetoNodeMap A boolean value which inidcate whether the node is to be written to the NodeIDMap.
	* @returns The number of children of the  node with the given key. -1 if no such node exists in the database. 
	*/
	int getNumChildren(NodeIDMap* idmap,
		FileInfoType* fileid, 
		KeyType nodekey, 
		bool writetoNodeMap = true );

	/**
	* Navigation Interface
	* 
	* Given the dynamic file id of a file and the key of a node, find out the height of the subtree rooted at the node.  
	* 
	* @param idmap The NodeIDMap associated with the data file. 
	* @param fileinfo The information about the datafile.
	* @param nodekey The key of the node.
	* @param writetoNodeMap A boolean value which inidcate whether the node is to be written to the NodeIDMap.
	* @returns The height of the subtree rooted at the node with the given key. -1 if no such node exists in the database. 
	*/
	int getSubtreeDepth(NodeIDMap* idmap, 
		FileInfoType* fileid, 
		KeyType nodekey, 
		bool writetoNodeMap = true );

	/**
	* Navigation Interface
	* 
	* Given the dynamic file id of a file and the key of an element node, get the data node which contains 
	* the attributes belongs to the element node. 
	*
	* @param idmap The NodeIDMap associated with the data file. 
	* @param fileinfo The information about the datafile.
	* @param nodekey The key of the element node.
	* @param writetoNodeMap A boolean value which inidcate whether the node is to be written to the NodeIDMap.
	* @returns A pointer to the attribute node which contains all the attributes belonging to the element node. 
	*	returns -1 if no element node with the given key exists, or the element does not have attribute. 
	*/
	DM_DataNode* getAttributes(NodeIDMap* idmap,
		FileInfoType* fileinfo,
		KeyType nodekey,
		bool writetoNodeMap = true);

	
	/**
	* Navigation Interface
	* 
	* Given the dynamic file id of a file and the key of a node and a number (n)
	* get the name and value of the attribute which is the n'th attribute of the node given. 
	* The node with the given key can be an element node or an attribute node. 
	*
	* @param idmap The NodeIDMap associated with the data file. 
	* @param fileinfo The information about the datafile.
	* @param nodekey The key of the node (it can be an element node or an attribute node).
	* @param index The index of the attribute we are looking for. 
	* @param writetoNodeMap A boolean value which inidcate whether the node is to be written to the NodeIDMap.
	* @param attrname The name of the attribute (return value)
	* @param value The value of the attribute (return value). 
	* @returns Error Code
	*/
	int getAttribute(
		// input
		NodeIDMap* idmap,
		FileInfoType* fileinfo,
		KeyType nodekey,
		short index,
		bool writetoNodeMap,
		// output
		char* attrname,
		Value* value);

	/**
	* Navigation Interface
	* 
	* Given the dynamic file id of a file and the key of a node and the attribute name
	* get the value of the attribute which is an attribute of the node given, and
	* whose name is the same as the name given.
	*
	* @param idmap The NodeIDMap associated with the data file. 
	* @param fileinfo The information about the datafile.
	* @param nodekey The key of the node (it can be an element node or an attribute node).
	* @param attrname The name of the attribute whose value is what we are looking for.
	* @param writetoNodeMap A boolean value which inidcate whether the node is to be written to the NodeIDMap.
	* @returns The value of the attribute. returns NULL if the node with the given key does not exist,
	* or it is not an element node or attribute, or the element node does not have attribute, or there
	* is no attribute has the name given. 
	*/
	Value* getAttribute(NodeIDMap* idmap,
		FileInfoType* fileinfo,
		KeyType nodekey,
		char* attrname,
		bool writetoNodeMap);



private:
	/**
	* The PhysicalDataMng which provide support for data access at physical level
	*/
	PhysicalDataMng* physicalDataMng;




};


#endif

