/*
COPYRIGHT  (c) 2000-2004 
THE REGENTS OF THE UNIVERSITY OF MICHIGAN
ALL RIGHTS RESERVED

PERMISSION IS GRANTED TO USE, COPY, CREATE DERIVATIVE WORKS AND
REDISTRIBUTE THIS SOFTWARE AND SUCH DERIVATIVE WORKS FOR NONCOMMERCIAL
EDUCATION AND RESEARCH PURPOSES, SO LONG AS NO FEE IS CHARGED, AND SO LONG
AS THE COPYRIGHT NOTICE ABOVE, THIS GRANT OF PERMISSION, AND THE
DISCLAIMER BELOW APPEAR IN ALL COPIES MADE; AND SO LONG AS THE NAME OF THE
UNIVERSITY OF MICHIGAN IS NOT USED IN ANY ADVERTISING OR PUBLICITY
PERTAINING TO THE USE OR DISTRIBUTION OF THIS SOFTWARE WITHOUT SPECIFIC,
WRITTEN PRIOR AUTHORIZATION.

THIS SOFTWARE IS PROVIDED AS IS, WITHOUT REPRESENTATION FROM THE
UNIVERSITY OF MICHIGAN AS TO ITS FITNESS FOR ANY PURPOSE, AND WITHOUT
WARRANTY BY THE UNIVERSITY OF MICHIGAN OF ANY KIND, EITHER EXPRESS OR
IMPLIED, INCLUDING WITHOUT LIMITATION THE IMPLIED WARRANTIES OF
MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE. THE REGENTS OF THE
UNIVERSITY OF MICHIGAN SHALL NOT BE LIABLE FOR ANY DAMAGES, INCLUDING
SPECIAL, INDIRECT, INCIDENTAL, OR CONSEQUENTIAL DAMAGES, WITH RESPECT TO
ANY CLAIM ARISING OUT OF OR IN CONNECTION WITH THE USE OF THE SOFTWARE,
EVEN IF IT HAS BEEN OR IS HEREAFTER ADVISED OF THE POSSIBILITY OF SUCH
DAMAGES.
*/

#include "IndexNameTable.h"

/**
* IndexNameTable
* 
* This class is an index catalog given an index name
* return the index info of that index file
* 
* @version 1.0
*/

/**
* Constructor
*
* @param volumeID The device volume id
*/
IndexNameTable::IndexNameTable(lvid_t volumeID)
{
	this->volumeID = volumeID;
	serial_t root_iid;
	this->scanindex = NULL;

	// find the root index of SHORE

	rc_t rc = ss_m::vol_root_index(this->volumeID, root_iid);
	if (rc)
	{
		globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"IndexNameTable::IndexNameTable",__FILE__,"After looking for root index");
		return;
	}
	
	// look for the IndexNameTable file in SHORE
	char* name = "IndexNameTable";
	int namesize = strlen(name);
	smsize_t size = sizeof(serial_t);
	bool found = false;
	rc = ss_m::find_assoc(this->volumeID, root_iid,
				vec_t(name, namesize),
 				&(this->IndexNameTable_IndexID), 
				size,
				found);
	if (rc)
	{
		globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"IndexNameTable::IndexNameTable",__FILE__,"After finding association in root index");
		return;
	}

	this->scanindex = NULL;
	if (!found)
	{
		// if the IndexNameTable can not be found, this means, it is
		// the first run of the database

		// create a IndexNameTable Index
		
		char index_t[10] = "b*";
		char size[10];
		itoa(MAX_XMLFILE_NAME_LENGTH, size, 10);
		strcpy(index_t+2, size);

		rc = ss_m::create_index(this->volumeID, 
								ss_m::t_btree, 
								ss_m::t_regular,
								index_t, 0, 
								this->IndexNameTable_IndexID);
		if (rc)
		{
			globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"IndexNameTable::IndexNameTable",__FILE__,"After creating a new index");
			return;
		}

		// Create association of the file and its name in root index of SHORE

		rc = ss_m::create_assoc(this->volumeID, root_iid,
					vec_t("IndexNameTable", strlen("IndexNameTable")),
 					vec_t(&(this->IndexNameTable_IndexID), sizeof(serial_t)));
		if (rc)
		{
			globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"IndexNameTable::IndexNameTable",__FILE__,"After creating an entry in root index");
			return;
		}
	}

	return;

}

/**
* Destructor
*/
IndexNameTable::~IndexNameTable()
{
	if (scanindex)
		delete scanindex;
}

/**
* Process method
* Insert an index name - indexinfo association
*
* @param indexname The name of the index
* @param indexinfo The index info the index being inserted
* @returns Error code
*/
int	IndexNameTable::insertIndex(char* indexname,
		IndexInfoType* indexinfo)
{
	IndexInfoType* fi = getIndexInfo(indexname);
	if (fi != NULL)
	{
		globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"IndexNameTable::insertIndex",__FILE__,"An index with same name exists.");
		delete fi;
		return -1;
	}
	
	rc_t rc = ss_m::create_assoc(this->volumeID, this->IndexNameTable_IndexID,
				vec_t(indexname, strlen(indexname)),
				vec_t(indexinfo, sizeof(IndexInfoType)));
	if (rc)
	{
		delete fi;
		globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"IndexNameTable::insertIndex",__FILE__,"After creating an entry in the index");
		return -1;
	}

	return 0;
}

/**
* Process method
* Delete an index name - indexinfo association
*
* @param indexname The name of the index
* @returns Error code
*/
int IndexNameTable::deleteIndex(char* indexname)
{
	rc_t rc;
	
	IndexInfoType* indexinfo = getIndexInfo(indexname);
	if (indexinfo == NULL)
	{
		globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"IndexNameTable::deleteIndex",__FILE__,"Index with this name do not exist.");
		delete indexinfo;
		return -1;
	}
	else
	{
		rc = ss_m::destroy_assoc(this->volumeID, 
			this->IndexNameTable_IndexID,
			vec_t(indexname, strlen(indexname)),
			vec_t(indexinfo, sizeof(IndexInfoType)));

		if (rc)
		{
			delete indexinfo;
			globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"IndexNameTable::deleteIndex",__FILE__,"After trying to destroy an entry in the index");
			return -1;
		}
		delete indexinfo;
		return 0;
	}
}

/**
* Process method
* Get an index info of the index name
*
* @param indexname The name of the index
* @returns The indexinfoType of the index
*/
IndexInfoType* IndexNameTable::getIndexInfo(char* indexname)
{
	IndexInfoType* indexinfo = new IndexInfoType;
	smsize_t indexinfo_len = sizeof(IndexInfoType);
	bool found = false;

	rc_t rc = ss_m::find_assoc(this->volumeID, this->IndexNameTable_IndexID,
				vec_t(indexname, strlen(indexname)),
 				indexinfo, indexinfo_len, found);
	if (rc)
	{
		globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"IndexNameTable::getIndexInfo",__FILE__,"After looking for an try in the index");
		delete indexinfo;
		return NULL;
	}
	if (found)
		return indexinfo;
	else 
	{
		delete indexinfo;
		return NULL;
	}
}

/**
* Scan method
* Start the scan of the whole catalog
*/
void IndexNameTable::startTableScan()
{
	if (scanindex)
		delete scanindex;
	scanindex = new scan_index_i(this->volumeID,
												this->IndexNameTable_IndexID,
											   scan_index_i::gt, 
											   cvec_t::neg_inf, 
											   scan_index_i::lt, 
											   cvec_t::pos_inf);
											   //t_cc_none);
	if (scanindex->error_code()){
		scanindex->finish();
		delete scanindex;
		globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"IndexNameTable::startTableScan",__FILE__,"After scan index initialization");
	}

}

/**
* Scan method
* Get the next matching index
*
* @returns The indexinfoType of the index
*/
IndexInfoType* IndexNameTable::getNextIndexInfo()
{
	if (!scanindex)
		startTableScan();

	char blah[200];
	IndexInfoType* ii = new IndexInfoType;
	vec_t key(blah,200), ele(ii,sizeof(IndexInfoType));
	smsize_t keysize;
	smsize_t elesize;
	bool eof = false;
	
	rc_t rc = scanindex->next(eof);
	if (rc)
	{
		globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"IndexNameTable::getNextIndexInfo",__FILE__,"After scan fetch next from the index");
		scanindex->finish();
		delete scanindex;
		scanindex = NULL;
		return NULL;
	}
	if (!eof)
	{
		rc = scanindex->curr(&key, keysize, &ele, elesize);
		if (rc)
		{
			globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"IndexNameTable::getNextIndexInfo",__FILE__,"After scan fetch next current function from the index");
			scanindex->finish();
			delete scanindex;
			scanindex = NULL;
			return NULL;
		}
	}
	else
	{
		scanindex->finish();
		delete scanindex;
		scanindex = NULL;
		return NULL;
	}
	return ii;
}

