/*
COPYRIGHT  (c) 2000-2004 
THE REGENTS OF THE UNIVERSITY OF MICHIGAN
ALL RIGHTS RESERVED

PERMISSION IS GRANTED TO USE, COPY, CREATE DERIVATIVE WORKS AND
REDISTRIBUTE THIS SOFTWARE AND SUCH DERIVATIVE WORKS FOR NONCOMMERCIAL
EDUCATION AND RESEARCH PURPOSES, SO LONG AS NO FEE IS CHARGED, AND SO LONG
AS THE COPYRIGHT NOTICE ABOVE, THIS GRANT OF PERMISSION, AND THE
DISCLAIMER BELOW APPEAR IN ALL COPIES MADE; AND SO LONG AS THE NAME OF THE
UNIVERSITY OF MICHIGAN IS NOT USED IN ANY ADVERTISING OR PUBLICITY
PERTAINING TO THE USE OR DISTRIBUTION OF THIS SOFTWARE WITHOUT SPECIFIC,
WRITTEN PRIOR AUTHORIZATION.

THIS SOFTWARE IS PROVIDED AS IS, WITHOUT REPRESENTATION FROM THE
UNIVERSITY OF MICHIGAN AS TO ITS FITNESS FOR ANY PURPOSE, AND WITHOUT
WARRANTY BY THE UNIVERSITY OF MICHIGAN OF ANY KIND, EITHER EXPRESS OR
IMPLIED, INCLUDING WITHOUT LIMITATION THE IMPLIED WARRANTIES OF
MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE. THE REGENTS OF THE
UNIVERSITY OF MICHIGAN SHALL NOT BE LIABLE FOR ANY DAMAGES, INCLUDING
SPECIAL, INDIRECT, INCIDENTAL, OR CONSEQUENTIAL DAMAGES, WITH RESPECT TO
ANY CLAIM ARISING OUT OF OR IN CONNECTION WITH THE USE OF THE SOFTWARE,
EVEN IF IT HAS BEEN OR IS HEREAFTER ADVISED OF THE POSSIBILITY OF SUCH
DAMAGES.
*/

#ifndef __FileIndexTable_H
#define __FileIndexTable_H
#include <timber-compat.h>

#include "../Common/IndexMng_definitions.h"

/**
* FileIndexTable
* 
* This class is an index catalog given an xml document name
* return the index info associated with
* 
* @version 1.0
*/

class FileIndexTable
{
public:


	/**
	* Constructor
	*
	* @param volumeID The device volume id (handler)
	*/
	FileIndexTable(lvid_t volumeID);

	/**
	* Destructor
	*/
	~FileIndexTable() {}

	/**
	* Process method
	* Insert new index association due to a creation
	*
	* @param filename The XML document file name
	* @param indexinfo The index description of IndexInfoType
	* @returns Error code
	*/
	int insertIndex(char* filename,
		IndexInfoType* indexinfo);

	/**
	* Process method
	* Delete new index associated with an XML file
	*
	* @param filename The XML document file name
	* @param indexname The name of index built on this file
	* @returns Error code
	*/
	int deleteIndex(char* filename, char* indexname);

	/**
	* Scan method
	* Start scan of all index of particular document
	*
	* @param filename The XML document file name
	*/
	void startScanIndex(char* filename);

	/**
	* Scan method
	* Get next matching index of the current scan
	*
	* @returns Index info of the matching index
	*/
	IndexInfoType* getNextIndexInfo();

	/**
	* Scan method
	* Close and finish the scan index iterator
	*/
	void closeScanIndex();


private:
	lvid_t volumeID;
	serial_t FileIndexTable_IndexID; //Index id

	scan_index_i *scanIndex; //scan index handler
	bool eof; //end of file flag
	vec_t* key;
	int keySize;
};	

#endif
