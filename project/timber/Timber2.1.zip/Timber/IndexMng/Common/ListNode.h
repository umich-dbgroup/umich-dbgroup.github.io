/*
COPYRIGHT  (c) 2000-2004 
THE REGENTS OF THE UNIVERSITY OF MICHIGAN
ALL RIGHTS RESERVED

PERMISSION IS GRANTED TO USE, COPY, CREATE DERIVATIVE WORKS AND
REDISTRIBUTE THIS SOFTWARE AND SUCH DERIVATIVE WORKS FOR NONCOMMERCIAL
EDUCATION AND RESEARCH PURPOSES, SO LONG AS NO FEE IS CHARGED, AND SO LONG
AS THE COPYRIGHT NOTICE ABOVE, THIS GRANT OF PERMISSION, AND THE
DISCLAIMER BELOW APPEAR IN ALL COPIES MADE; AND SO LONG AS THE NAME OF THE
UNIVERSITY OF MICHIGAN IS NOT USED IN ANY ADVERTISING OR PUBLICITY
PERTAINING TO THE USE OR DISTRIBUTION OF THIS SOFTWARE WITHOUT SPECIFIC,
WRITTEN PRIOR AUTHORIZATION.

THIS SOFTWARE IS PROVIDED AS IS, WITHOUT REPRESENTATION FROM THE
UNIVERSITY OF MICHIGAN AS TO ITS FITNESS FOR ANY PURPOSE, AND WITHOUT
WARRANTY BY THE UNIVERSITY OF MICHIGAN OF ANY KIND, EITHER EXPRESS OR
IMPLIED, INCLUDING WITHOUT LIMITATION THE IMPLIED WARRANTIES OF
MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE. THE REGENTS OF THE
UNIVERSITY OF MICHIGAN SHALL NOT BE LIABLE FOR ANY DAMAGES, INCLUDING
SPECIAL, INDIRECT, INCIDENTAL, OR CONSEQUENTIAL DAMAGES, WITH RESPECT TO
ANY CLAIM ARISING OUT OF OR IN CONNECTION WITH THE USE OF THE SOFTWARE,
EVEN IF IT HAS BEEN OR IS HEREAFTER ADVISED OF THE POSSIBILITY OF SUCH
DAMAGES.
*/

#ifndef __ListNode_h
#define __ListNode_h
#include <timber-compat.h>

#include "IndexMng_definitions.h"

/**
 * A simple tree node. Part of WitnessTree. represents basic information about a DB node.
 * @see ComplexListNode
 * @see WitnessTree
 * @author Shurug Al-Khalifa 
 * @version 1.0
 */

class ListNode   
{
public:
    /**
       Constructor.
       Initialization of data members.
    **/
    ListNode(); 

    /**
       Destructor.
    **/
    ~ListNode();

	/**
	   Copy Constructor
	**/
	ListNode(ListNode* lNode);

    /**
       Process Method.
       sets the startPos data member to the new value
       @param startPos is the new value to be assigned to startPos data member.
    **/
    void SetStartPos(KeyType startPos);

    /**
       Access Method.
       gets the value of startPos data member.
       @returns startPos data member.
    **/
    KeyType GetStartPos();

    /**
       Process Method.
       sets the endPos data member to the new value
       @param endPos is the new value to be assigned to endPos data member.
    **/
    void SetEndPos(KeyType endPos);

    /**
       Access Method.
       gets the value of endPos data member.
       @returns endPos data member.
    **/
    KeyType GetEndPos();

    /**
       Process Method.
       sets the level data member to the new value
       @param level is the new value to be assigned to level data member.
    **/
    void SetLevel(short level);

    /**
       Access Method.
       gets the value of level data member.
       @returns level data member.
    **/
    short GetLevel();

    /**
       Process Method.
       sets the offset data member to the new value
       @param offset is the new value to be assigned to level data member.
    **/
    void SetOffset(short offset);

    /**
       Access Method.
       gets the value of offset data member.
       @returns offset data member.
    **/
    short GetOffset();

    /**
	* Process Method
	* sets the index of the file in the open files array where this node came from.
	* @param fileIndex index of the file in the open files array where this node came from.
	**/
    void setFileIndex(char fileIndex);

    /**
	* Access Method
	* @returns index of the file in the open files array where this node came from.
	**/
    char getFileIndex();

    /**
       Process Method.
       initializes the data members.
    **/
    void initialize();

   /**
	* Access Method
	* returns true if this node is an ancestor of potentialDesc node.
	* @param potentialDesc is a node that we will be checking to see if it is a desc of this node.
	* @returns true if this node is an ancestor of potentialDesc node.
	**/
    bool isAncsOf(ListNode *potentialDesc);

	/**
	* Access Method
	* returns true if this node is a descendant of potentialAncs node.
	* @param potentialAncs is a node that we will be checking to see if it is an ancs of this node.
	* @returns true if this node is a descendant of potentialAncs node.
	**/
    bool isDescOf(ListNode *potentialAncs);

	/**
	* Access Method
	* returns true if this node's start-end interval is not contained in the interval of someNode.
	* @param someNode is a node that we will be checking to make sure that this node is not contained in.
	* @returns true if this node is not contained in someNode.
	**/
    bool isNotContainedIn(ListNode *someNode);

	/**
	* Access Method
	* returns true if this node is a parent of potentialChild node.
	* @param potentialChild is a node that we will be checking to see if it is a child of this node.
	* @returns true if this node is a parent of potentialChild node.
	**/
    bool isParentOf(ListNode *potentialChild);

	/**
	* Access Method
	* returns true if this node is a child of potentialParent node.
	* @param potentialParent is a node that we will be checking to see if it is a parent of this node.
	* @returns true if this node is a child of potentialParent node.
	**/
    bool isChildOf(ListNode *potentialParent);

	NREType getNRE();
	void setNRE(NREType nre);

private:
    /**
       the start key of a DB node.
    **/
    KeyType startPos;

    /**
       the end key of a DB node.
    **/
    KeyType endPos;

    /**
       the level of a DB node.
    **/
    //int level;
    short level;

    /**
       the offset of the word in the element
    **/
    short offset;

    /**
       which file does this node belong to
    **/
    char fileIndex;

	NREType nre;

};

#endif

