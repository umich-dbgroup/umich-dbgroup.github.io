/*
COPYRIGHT  (c) 2000-2004 
THE REGENTS OF THE UNIVERSITY OF MICHIGAN
ALL RIGHTS RESERVED

PERMISSION IS GRANTED TO USE, COPY, CREATE DERIVATIVE WORKS AND
REDISTRIBUTE THIS SOFTWARE AND SUCH DERIVATIVE WORKS FOR NONCOMMERCIAL
EDUCATION AND RESEARCH PURPOSES, SO LONG AS NO FEE IS CHARGED, AND SO LONG
AS THE COPYRIGHT NOTICE ABOVE, THIS GRANT OF PERMISSION, AND THE
DISCLAIMER BELOW APPEAR IN ALL COPIES MADE; AND SO LONG AS THE NAME OF THE
UNIVERSITY OF MICHIGAN IS NOT USED IN ANY ADVERTISING OR PUBLICITY
PERTAINING TO THE USE OR DISTRIBUTION OF THIS SOFTWARE WITHOUT SPECIFIC,
WRITTEN PRIOR AUTHORIZATION.

THIS SOFTWARE IS PROVIDED AS IS, WITHOUT REPRESENTATION FROM THE
UNIVERSITY OF MICHIGAN AS TO ITS FITNESS FOR ANY PURPOSE, AND WITHOUT
WARRANTY BY THE UNIVERSITY OF MICHIGAN OF ANY KIND, EITHER EXPRESS OR
IMPLIED, INCLUDING WITHOUT LIMITATION THE IMPLIED WARRANTIES OF
MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE. THE REGENTS OF THE
UNIVERSITY OF MICHIGAN SHALL NOT BE LIABLE FOR ANY DAMAGES, INCLUDING
SPECIAL, INDIRECT, INCIDENTAL, OR CONSEQUENTIAL DAMAGES, WITH RESPECT TO
ANY CLAIM ARISING OUT OF OR IN CONNECTION WITH THE USE OF THE SOFTWARE,
EVEN IF IT HAS BEEN OR IS HEREAFTER ADVISED OF THE POSSIBILITY OF SUCH
DAMAGES.
*/

#ifndef __ContainerClass_h
#define __ContainerClass_h
#include <timber-compat.h>

#include "IndexMng_definitions.h"

#include <iostream>
using std::istream ;
using std::ostream ;

#define SELF_CONTAINER 0
#define DESC_CONTAINER 1

#define CONTAINER_SIZE	8000
#define CONTAINER_SIZE_DEFAULT	8000

/**
* a memory buffer used in shore list.
* @see ShoreList
* @author Shurug Al-Khalifa 
* @version 1.0
*/
class ContainerClass
{
public:
	/**
	* Constructor
	* Initialize the variables.
	*@param size is the size of the container. default is CONTAINER_SIZE
	*/
	ContainerClass();

	/**
	* Destructor
	* nothing.
	*/
	~ContainerClass();

	friend ostream & operator << (ostream &output, const ContainerClass &c) 
	{
		output.write(reinterpret_cast<const char *>(&c.snext), sizeof(serial_t)) ;
		output.write(reinterpret_cast<const char *>(&c.ssize), sizeof(int)) ;
		output.write(c.container, sizeof(char) * 8000) ;
		return output ;
	} ;

	friend istream & operator >> (istream &input, ContainerClass &c)
	{
		input.read(reinterpret_cast<char *>(&c.snext), sizeof(serial_t)) ;
		input.read(reinterpret_cast<char *>(&c.ssize), sizeof(int)) ;
		c.size = c.ssize ;
		c.addCursor = c.size ;
		memset(c.container, 0, sizeof(char) * 8000) ;
		input.read(c.container, sizeof(char) * 8000) ;
		return input ;
	} ;

	/**
	* Access Method
	* Gets the value of the adding cursor.
	*@returns the value of the adding cursor.
	*/
	int GetAddCursor();

	/**
	* Access Method
	* Gets the value of the scanning cursor.
	*@returns the value of the scanning cursor.
	*/
	int GetScanCursor();

	/**
	* Access Method
	* Gets the previous value of the scanning cursor.
	*@returns the previous value of the scanning cursor.
	*/
	int GetOldScanCursor();

	/**
	* Access Method
	* decides whether or not the container is full.
	*@returns true if the container is full. otherwise, returns false.
	*/
	bool IsFull();

	/**
	* Access Method
	* decides whether or not the container is empty.
	*@returns true if the container is empty. otherwise, returns false.
	*/
	bool IsEmpty();

	/**
	* Access Method
	* decides whether or not the container has enough space to accomedate a given number of bytes.
	*@param size is the number of bytes we want to check if they can fit in the container.
	*@returns true if the container can accomedate size. otherwise, returns false.
	*/
	bool EnoughSpace(int size);

	/**
	* Access Method
	* decides whether or not you will be exceeding the adding cursor (you will be getting junk) 
	* if you decide to read from location start for size number of bytes. 
	*@param start is the location to start from in the container to check for exceeding boundry.
	*@param size is the number of bytes we are planning on reading.
	*@returns true if the adding cursor is exceeded. otherwise, returns false.
	*/
	bool ExceedBoundry(int start, int size); 
	
	/**
	* Access Method
	* decides whether or not you will be exceeding the adding cursor (you will be getting junk) 
	* if you decide to read from the scanning cursor for size number of bytes. 
	*@param size is the number of bytes we are planning on reading.
	*@returns true if the adding cursor is exceeded. otherwise, returns false.
	*/
	bool ExceedBoundry(int size);             

	/**
	* Access Method
	* reads data from location start for length number of bytes and puts the read section in data. 
	*@param start is the location in the container to start reading from.
	*@param length is the number of bytes we are planning on reading.
	*@param data is a buffer passed in to hold the data read from the container.
	*@returns SUCCESS if the data was read. If the container is empty or the adding cursor
	* is exceeded, FAILURE is returned.
	*/
	int GetData(int start,int length, char *data);

	/**
	* Access Method
	* reads data from scan cursor for length number of bytes and puts the read section in data. 
	* this operation advances the scan cursor by length.
	*@param length is the number of bytes we are planning on reading.
	*@param data is a buffer passed in to hold the data read from the container.
	*@returns SUCCESS if the data was read. If the container is empty or the adding cursor
	* is exceeded, FAILURE is returned.
	*/
	int GetNext(int length, char *data, bool updateUnitCursor = false, bool updateUnitCursorEnd = false);

	/**
	* Process Method
	* writes data in newData into the container at the add cursor location. 
	* this operation advances the add cursor by length.
	*@param newData is a buffer holding the data
	*@param length is the size of teh data to written.
	*@returns SUCCESS if the data was written. If the container is full or newData
	* is NULL, FAILURE is returned.
	*/
	int AddData(char *newData, int length);

	/**
	* Initialization
	* Initialize the variables. called by the constructor.
	*/
	void Initialize();

	/**
	* Process Method
	* assigns a new value to the scan cursor.
	*@param scanCursor is the new value of scanCursor.
	*/
	void SetScanCursor(int scanCursor);

	/**
	* Process Method
	* assigns a new value to the add cursor.
	*@param addCursor is the new value of addCursor.
	*/
	void SetAddCursor(int addCursor);

	/**
	* Access Method
	*@returns a pointer to the actual buffer.
	*/
	char *GetContainer();

	/**
	* Process Method
	* copies a container cont to this container.
	*@param cont is a container that we want to copy to this container.
	*/
	void CopyContainer(ContainerClass *cont);

	/**
	* Access Method
	*@returns teh maximum size of this container.
	*/
	int GetSize();

	/**
	* Access Method
	* reads data from scan cursor and returns a pointer to it. 
	* this operation advances the scan cursor by length.
	*@param length is the number of bytes we are planning on reading.
	*@returns a pointer to the data read. If the container is empty or the adding cursor
	* is exceeded, NULL is returned.
	*/
	char *GetNextPtr(int length, bool updateUnitCursor = false, bool updateUnitCursorEnd = false);

	bool reachedEndOfContainer();

	void decrementScanCursor();
	void advanceScanCursor();

	void nullifyContainer();

	void setSSize(int s) { ssize = s ; } ;
	void setSNext(serial_t n) { snext = n ; } ;

	int getSSize() { return ssize ; } ;
	serial_t getSNext() { return snext ; } ;

private:

	int ssize ;
	serial_t snext ;

	/**
	*actual buffer.
	*/
	//char *container;//[CONTAINER_SIZE];
	char container[CONTAINER_SIZE];
	
	/**
	*max size of buffer.
	*/
	int size;

	/**
	*cursor that indicates how much has been added to the container.
	*/
	int addCursor;

	/**
	*cursor that indicates how much has been scanned from the container.
	*/
	int scanCursor;

	/**
	*cursor that holds a previous value of scan cursor
	*/
	int oldScanCursor;

	int unitCursor;
	int unitCursorEnd;
};




#endif
