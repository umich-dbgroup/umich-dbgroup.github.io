/*
COPYRIGHT  (c) 2000-2004 
THE REGENTS OF THE UNIVERSITY OF MICHIGAN
ALL RIGHTS RESERVED

PERMISSION IS GRANTED TO USE, COPY, CREATE DERIVATIVE WORKS AND
REDISTRIBUTE THIS SOFTWARE AND SUCH DERIVATIVE WORKS FOR NONCOMMERCIAL
EDUCATION AND RESEARCH PURPOSES, SO LONG AS NO FEE IS CHARGED, AND SO LONG
AS THE COPYRIGHT NOTICE ABOVE, THIS GRANT OF PERMISSION, AND THE
DISCLAIMER BELOW APPEAR IN ALL COPIES MADE; AND SO LONG AS THE NAME OF THE
UNIVERSITY OF MICHIGAN IS NOT USED IN ANY ADVERTISING OR PUBLICITY
PERTAINING TO THE USE OR DISTRIBUTION OF THIS SOFTWARE WITHOUT SPECIFIC,
WRITTEN PRIOR AUTHORIZATION.

THIS SOFTWARE IS PROVIDED AS IS, WITHOUT REPRESENTATION FROM THE
UNIVERSITY OF MICHIGAN AS TO ITS FITNESS FOR ANY PURPOSE, AND WITHOUT
WARRANTY BY THE UNIVERSITY OF MICHIGAN OF ANY KIND, EITHER EXPRESS OR
IMPLIED, INCLUDING WITHOUT LIMITATION THE IMPLIED WARRANTIES OF
MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE. THE REGENTS OF THE
UNIVERSITY OF MICHIGAN SHALL NOT BE LIABLE FOR ANY DAMAGES, INCLUDING
SPECIAL, INDIRECT, INCIDENTAL, OR CONSEQUENTIAL DAMAGES, WITH RESPECT TO
ANY CLAIM ARISING OUT OF OR IN CONNECTION WITH THE USE OF THE SOFTWARE,
EVEN IF IT HAS BEEN OR IS HEREAFTER ADVISED OF THE POSSIBILITY OF SUCH
DAMAGES.
*/

#ifndef __IndexMngDefinition_H
#define __IndexMngDefinition_H
#include <timber-compat.h>

#include "../../PhysicalDataMng/PhysicalDataMng.h"

#include "../../Utilities/ErrorInfoClass.h"
extern ErrorInfoClass globalErrorInfo;
/**
* Index type and definition
*/

// general type
#define SHORE_INDEX	1
#define GIST_INDEX	2
#define HASH_INDEX	3

// value type
#define INT_INDEX		0
#define STRING_INDEX	1
#define FLOAT_INDEX		2
#define DOUBLE_INDEX	3

// index description:
#define VALUEINDEX_ELEMENTTAG					0
#define VALUEINDEX_ATTRIBUTENAME				1	
#define VALUEINDEX_ATTRIBUTEVALUE				2
#define VALUEINDEX_TEXTVALUE					3
#define VALUEINDEX_ELEMENTCONTENT				4
#define VALUEINDEX_ATTRIBUTECONTENT				5
#define VALUEINDEX_INVERTEDINDEX_ELEM_STEM		6
#define VALUEINDEX_INVERTEDINDEX_TEXT_STEM		7
#define VALUEINDEX_INVERTEDINDEX_ELEM_NOSTEM	8
#define VALUEINDEX_INVERTEDINDEX_TEXT_NOSTEM	9
#define VALUEINDEX_PARENT						10
#define VALUEINDEX_ELEMENTTAGSTR				11

// tag - stdTag index description
#define VALUEINDEX_NAME_STANDARDNAME_PAIR	    12
#define VALUEINDEX_STANDARDNAME_NAME_PAIR	    13

//text-tag index description
#define VALUEINDEX_INVERTEDINDEX_TEXT_NAME_STEM   14
#define VALUEINDEX_INVERTEDINDEX_TEXT_NAME_NOSTEM 15

//---------------------------------------------------------------------
// Yunyao: added on 04-25-2005 to support ancestor-descendant 
//         summarization index
// Possible problem: 
//         Currently Timber stores tag/attribute names of the entire 
//         volume in the same XMLNameTable. But the ancestor-descendant 
//         summarization index is created for EACH XML document.
//         To guarantee the correctness of the index, we need to create
//         it on a clean volume each time we create the index.
//name-pos index description
//         name: tag/attribute name
//         pos:  the position of the name in the bitset map
#define VALUEINDEX_NAME_POS                          16
//ancestor-descendant summarization index
//         ancestor: the tag name of the node
//         descendant: a bitset representing the type of descendant
//                     rooted at the current node
#define VALUEINDEX_ANCESTOR_DESCENDANT_SUMMARIZATION 17
//skey-pos index
//         skey: start key of the node
//         pos:  the position of the node in a bitset mapping
#define VALUEINDEX_SKEY_POS_SUMMARIZATION            18
//---------------------------------------------------------------------

// updatable index descriptions:
#define VALUEINDEX_TAGNAME_ID_PAIR				20
#define VALUEINDEX_ATTRIBUTENAME_ID_PAIR		21

#define JOININDEX								30
#define JOININDEX_ELEMENTCONTENT				31
#define JOININDEX_ATTRIBUTEVALUE				32
#define JOININDEX_ATTRIBUTECONTENT				33
#define COLORJOININDEX							40

// the structure that keeps information about a index.
#define MAX_INDEX_NAME_LENGTH		100
#define MAX_INDEX_VALUE_LENGTH		100
#define MAX_SELCONDITION_LENGTH		2000

// the max size of descendant map associated with each node
#define MAX_BITSET_LENGTH           128
#define MAX_DEPTH                   16

#define TITLEOFFSET 50  // offset to duplicate entries in title

/**
* IndexInfoType
* Describe information of the index of a document
*/
typedef struct {
    char		indexName[MAX_INDEX_NAME_LENGTH]; //index name
    char		fileName[MAX_XMLFILE_NAME_LENGTH]; // XML file name
    serial_t		indexID;
    int 		indexType; // string, int, float, etc.
	int			indexDescription; //type of index e.g. elementtag, attributecontent index
    int 		indexKeyLength; //length of the index key
    int 		recordNumber; //number of records
    int 		indexSource; //is it a GiST or Shore index?
	bool		isUpdatable; //is it an updatable index?
	char		selectionCondition[MAX_SELCONDITION_LENGTH]; //selection condition the index built on
	int			selectionConditionLength;
	SelectionCondition    *sc; //Avoid (un)wrapping binary
	//for join index condition
	int			leftSideType;
	char		leftSide[MAX_NODETAG_LENGTH];
	int			rightSideType;
	char		rightSide[MAX_NODETAG_LENGTH];
	bool		isCaseInsensitive;
}  IndexInfoType;

typedef struct
{
	/**
       the start key of a DB node.
    **/
    KeyType startPos;

    /**
       the end key of a DB node.
    **/
    KeyType endPos;

    /**
       the level of a DB node.
    **/
    short level;
} IndexNodeType;

#define SUCCESS 1
#define FAILURE -1

typedef int NREType;

#define SUPPLEMENTARY_NODES_NRE		0
#define DEFAULT_NODES_NRE			0
#define NULL_NRE					255

#endif

