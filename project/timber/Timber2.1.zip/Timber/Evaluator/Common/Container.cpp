
#include "Container.hpp"

#include <iostream>
#include <fstream>
using namespace std ;

namespace Timber {

Container::Container(int length) : size(length), amountUsed(0)
{
	if (size > 0)
	{
	//	data = new char[size] ;
	}
	size = 8000 ;
	memset(data, 0, 8000) ;
}

Container::Container(int length, char *d) : size(length), amountUsed(0)
{
	size = 8000 ;
	if (size > 0)
	{
		//data = new char[size] ;
		memset(data, 0, 8000) ;
		memcpy(data, d, length) ;
	}

	// else { Should throw an exception here.... }
}

Container::~Container()
{
	if (size > 0)
	{
		delete [] data ;
	}
}

char *
Container::getBytes()
{
	return data ;
}

char *
Container::getBytes(int offset)
{
	if (offset < 0 || offset >= size)
	{
		return NULL ;
	}

	return data+offset ;
}

bool 
Container::setBytes(int length, char *d)
{
	return setBytes(0, d, length) ;
}

bool
Container::setBytes(int offset, char *d, int length)
{
	if (offset >= size || offset < 0) {
		return false ;
	}

	if (length > size || length <= 0 || offset + length > size) {
		return false ;
	}

	//
	// If we are here then we are going to set the bytes.
	// If offset is zero, and length is less than size then
	// the existing data should be zero'd out.
	//
	if (offset == 0 && length < size)
	{
		memset(data, 0, size) ;
	}

	amountUsed = offset+length ;

	memcpy(data+offset, d, length) ;

	return true ;
}

int 
Container::getSize()
{
	return size ;
}

int
Container::getAmountUsed()
{
	return amountUsed ;
}

bool 
Container::setSize(int newsize)
{
	return true ;
}
/*
cout << "setSize = " << newsize ;
	if (newsize <= 0)
	{
		return false ;
	}

	int oldSize = size ;
	char *newData = new char[newsize] ;
	memset(newData, 0, newsize) ;

	if (oldSize > 0)
	{
		int sizeToCopy = size >= newsize ? size : newsize ;
		memcpy(newData, data, sizeToCopy) ;
	}

	if (size)
	{
		delete [] data ;
	}

	data = newData ;
	size = newsize ;

	if (amountUsed > size)
	{
		amountUsed = size ;
	}

	cout << "amountUsed = " << amountUsed << endl ;
	cout.flush() ;

	return true ;
	
}
*/

void 
Container::reset()
{
	if (size > 0)
	{
		memset(data, 0, size) ;
	}

	amountUsed = 0 ;
}

ostream & operator << (ostream &output, const Container &c)
{
	output.write(reinterpret_cast<const char *>(&c.size), sizeof(int)) ;
	//output << c.amountUsed ;
	output.write(c.data, sizeof(char) * c.amountUsed) ;
	return output ;
}

void Container::write(string name)
{
	fstream f ;
	f.open(name.c_str(), ios::binary | ios::out) ;
	int i = 4 ;
	f.write(reinterpret_cast<const char *>(&i), sizeof(int)) ;
	f.write(data+8, (sizeof(char) * amountUsed)-8) ;
	f.close() ;
}

istream & operator >> (istream &input, Container &c)
{
	int s ;
	input.read(reinterpret_cast<char *>(&s), sizeof(int)) ;
	cout << "Size read in container is " << s << endl ;
	cout.flush() ;
	//c.setSize(s) ;
	input.read(c.data, (sizeof(char) * c.size)) ;
	c.amountUsed = s ;
	return input ;
}

} // namespace Timber
