/*
COPYRIGHT  � 2000-2004 
THE REGENTS OF THE UNIVERSITY OF MICHIGAN
ALL RIGHTS RESERVED

PERMISSION IS GRANTED TO USE, COPY, CREATE DERIVATIVE WORKS AND REDISTRIBUTE THIS SOFTWARE AND SUCH DERIVATIVE WORKS FOR 
NONCOMMERCIAL EDUCATION AND RESEARCH PURPOSES, SO LONG AS NO FEE IS CHARGED, AND SO LONG AS THE COPYRIGHT NOTICE ABOVE, 
THIS GRANT OF PERMISSION, AND THE DISCLAIMER BELOW APPEAR IN ALL COPIES MADE; AND SO LONG AS THE NAME OF THE UNIVERSITY 
OF MICHIGAN IS NOT USED IN ANY ADVERTISING OR PUBLICITY PERTAINING TO THE USE OR DISTRIBUTION OF THIS SOFTWARE WITHOUT 
SPECIFIC, WRITTEN PRIOR AUTHORIZATION.

THIS SOFTWARE IS PROVIDED AS IS, WITHOUT REPRESENTATION FROM THE UNIVERSITY OF MICHIGAN AS TO ITS FITNESS FOR ANY PURPOSE, 
AND WITHOUT WARRANTY BY THE UNIVERSITY OF MICHIGAN OF ANY KIND, EITHER EXPRESS OR IMPLIED, INCLUDING WITHOUT LIMITATION THE 
IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE. THE REGENTS OF THE UNIVERSITY OF MICHIGAN SHALL 
NOT BE LIABLE FOR ANY DAMAGES, INCLUDING SPECIAL, INDIRECT, INCIDENTAL, OR CONSEQUENTIAL DAMAGES, WITH RESPECT TO ANY CLAIM 
ARISING OUT OF OR IN CONNECTION WITH THE USE OF THE SOFTWARE, EVEN IF IT HAS BEEN OR IS HEREAFTER ADVISED OF THE POSSIBILITY 
OF SUCH DAMAGES.
*/


#ifndef __ExecArrayType_h
#define __ExecArrayType_h
#include <timber-compat.h>

#include "../Common/IteratorClass.h"
#include "../QueryEvaluationTree/QueryEvaluationTree.h"
#define MAX_EXECUTION_NODES 50
/**
* This class is basically an execution node in the execution array.
* it may have the iterator itself (iterator) or info about it (queryEvalNode)
* @see ExecArrayType
* @see IteratorClass
* @author Shurug Al-Khalifa	
* @version 1.0
*/

class ExecArrayTupleType
{
public:
	/**
	Constructor
	**/
	ExecArrayTupleType();

	/**
	Destructor
	frees iterator if it existed.
	**/
	~ExecArrayTupleType();

	/**
	Process Method
	sets the data member type.
	@param type is the new value to be assigned to the data member type
	**/
	void SetType(int type);

	/**
	Access Method
	gets the type data member
	@returns type data member
	**/
	int GetType();

	/**
	Process Method
	sets the data member level.
	@param level is the new value to be assigned to the data member level
	**/
	void SetLevel(int level);

	/**
	Access Method
	gets the level data member
	@returns level data member
	**/
	int GetLevel();

	/**
	Process Method
	sets the data member iterator.
	@param iterator is the new value to be assigned to the data member iterator
	**/
	void SetIterator(IteratorClass *iterator);

	/**
	Access Method
	gets the iterator data member
	@returns iterator data member
	**/
	IteratorClass *GetIterator();


	/**
	Process Method
	sets the data member queryEvalNode.
	@param queryEvalNode is the new value to be assigned to the data member queryEvalNode.
	**/
	void SetQueryEvalNode(QueryEvaluationTreeNode *queryEvalNode);

	/**
	Access Method
	gets the queryEvalNode data member
	@returns queryEvalNode data member
	**/
	QueryEvaluationTreeNode *GetQueryEvalNode();

	int getIndex();
	void setIndex(int index);
private:
	/**
	type of the iterator... SELECT, CONSTRUCT...
	**/
	int type;

	/**
	level of the iterator... useful in representing trees.
	**/
	int level;

	int index;
	/**
	iterator.
	**/
	IteratorClass *iterator;

	/**
	query eval node.
	**/
	QueryEvaluationTreeNode *queryEvalNode;
};


/**
* This class basically represents an execution plan. It is a tree represented 
* as an array. It is a depth-first preorder traversal of the execution tree
* with a level attribute associated with each node to distinguish between children
* and siblings.
* @see ExecArrayTupleType
* @author Shurug Al-Khalifa	
* @version 1.0
*/
class ExecArrayType
{
public:
	/**
	Construct
	initialization
	**/
	ExecArrayType();

	/**
	Destruct
	**/
	~ExecArrayType();

	/**
	Access Method
	gets a node by index.
	@param index is the actual index of the node in the array.
	@returns a pointer to the node that has the iterator, its level and its type.
	**/
	ExecArrayTupleType *GetEntryByIndex(int index);

	/**
	Access Method
	gets the number of nodes in the execution tree/array.
	@returns the size of the execution tree/array
	**/
	int GetSize();

	/**
	Process Method
	inserts an iterator in the execution tree/array. Basically appends it.
	@param iter is the actual iterator.
	@param lev is the level of the iterator.
	@param typ is the type of the iterator
	@returns SUCCESS if everything is fine. FAILURE if the array limit is exceeded.
	**/
	int InsertIterInArray(IteratorClass *iter,int lev,int typ, int index = -1);

	/**
	Process Method
	inserts a queryEvalNode in the execution tree/array. Basically appends it.
	@param queryEvalNode is the actual query eval node.
	@param lev is the level of the node.
	@returns SUCCESS if everything is fine. FAILURE if the array limit is exceeded.
	**/
	int InsertNodeInArray(QueryEvaluationTreeNode *queryEvalNode,int lev);


	/**
	Process Method
	initializes data members. 
	**/
	void initialize();
	
	/**
	Access Method
	Given a node index, returns its parent index.
	@param index the index of the node you want to get its parent.
	@returns index of the parent in the array or -1 if it doesn't exist.
	**/
	int getParentIndex(int index);

	/**
	Access Method
	Given a node index, returns its first Child index.
	@param index the index of the node you want to get its child.
	@returns index of the first child in the array or -1 if it doesn't exist.
	**/
	int getChildIndex(int index);

	/**
	Access Method
	Given a node index, returns its following sibling index.
	@param index the index of the node you want to get its next sibling.
	@returns index of the sibling in the array or -1 if it doesn't exist.
	**/
	int getSiblingIndex(int index);

	/**
	Access Method
	Given a node index, returns its parent.
	@param index the index of the node you want to get its parent.
	@returns the parent in the array or NULL if it doesn't exist.
	**/
	ExecArrayTupleType *getParent(int index);

	/**
	Access Method
	Given a node index, returns its first child.
	@param index the index of the node you want to get its first child.
	@returns the first child in the array or NULL if it doesn't exist.
	**/
	ExecArrayTupleType *getChild(int index);

	/**
	Access Method
	Given a node index, returns itsnext sibling.
	@param index the index of the node you want to get its next sibling.
	@returns the next sibling in the array or NULL if it doesn't exist.
	**/
	ExecArrayTupleType *getSibling(int index);

private:
	/**
	Execution Array
	**/
	ExecArrayTupleType execArray[MAX_EXECUTION_NODES];

	/**
	its size.
	**/
	int size;
};


#endif

