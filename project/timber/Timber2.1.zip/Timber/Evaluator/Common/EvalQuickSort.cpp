/*
COPYRIGHT  � 2000-2004 
THE REGENTS OF THE UNIVERSITY OF MICHIGAN
ALL RIGHTS RESERVED

PERMISSION IS GRANTED TO USE, COPY, CREATE DERIVATIVE WORKS AND REDISTRIBUTE THIS SOFTWARE AND SUCH DERIVATIVE WORKS FOR 
NONCOMMERCIAL EDUCATION AND RESEARCH PURPOSES, SO LONG AS NO FEE IS CHARGED, AND SO LONG AS THE COPYRIGHT NOTICE ABOVE, 
THIS GRANT OF PERMISSION, AND THE DISCLAIMER BELOW APPEAR IN ALL COPIES MADE; AND SO LONG AS THE NAME OF THE UNIVERSITY 
OF MICHIGAN IS NOT USED IN ANY ADVERTISING OR PUBLICITY PERTAINING TO THE USE OR DISTRIBUTION OF THIS SOFTWARE WITHOUT 
SPECIFIC, WRITTEN PRIOR AUTHORIZATION.

THIS SOFTWARE IS PROVIDED AS IS, WITHOUT REPRESENTATION FROM THE UNIVERSITY OF MICHIGAN AS TO ITS FITNESS FOR ANY PURPOSE, 
AND WITHOUT WARRANTY BY THE UNIVERSITY OF MICHIGAN OF ANY KIND, EITHER EXPRESS OR IMPLIED, INCLUDING WITHOUT LIMITATION THE 
IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE. THE REGENTS OF THE UNIVERSITY OF MICHIGAN SHALL 
NOT BE LIABLE FOR ANY DAMAGES, INCLUDING SPECIAL, INDIRECT, INCIDENTAL, OR CONSEQUENTIAL DAMAGES, WITH RESPECT TO ANY CLAIM 
ARISING OUT OF OR IN CONNECTION WITH THE USE OF THE SOFTWARE, EVEN IF IT HAS BEEN OR IS HEREAFTER ADVISED OF THE POSSIBILITY 
OF SUCH DAMAGES.
*/

//@author James Gosling
//website http://www.cs.ubc.ca/spider/harrison/Java/QSortAlgorithm.java.html

#include "EvalQuickSort.h"

EvalQuickSort::EvalQuickSort()
{
}

EvalQuickSort::~EvalQuickSort()
{
}

void EvalQuickSort::swap(WitnessTree *a, int i, int j)
{
	WitnessTree temp;
	temp.copyTree(&a[i]); 
	a[i].copyTree(&a[j]);
	a[j].copyTree(&temp);
};

void EvalQuickSort::swap(WitnessTree **a, int i, int j)
{
	WitnessTree* temp;
	temp = a[i]; 
	a[i] = a[j];
	a[j] = temp;
};

int EvalQuickSort::quickSort(WitnessTree *a, int lo0, int hi0, int ( *compare )(const void *, const void *) )
{

	int lo = lo0;
	int hi = hi0;
	
	if (lo >= hi) 
		return SUCCESS;
	else if ( lo == hi - 1 ) 
	{
		if (compare((void *)&a[lo] ,(void *) &a[hi]) > 0) 
			swap(a,lo,hi);
		return SUCCESS;
	}


	/*
	*  Pick a pivot and move it out of the way
	*/
	WitnessTree pivot;
	pivot.copyTree(&a[(lo + hi) / 2]);
	a[(lo + hi) / 2].copyTree(&a[hi]);
	a[hi].copyTree(&pivot);

	while( lo < hi ) 
	{
#ifdef EVAL_TIME_OUT
	clock_t currTime = clock();
	double queryDuration = (double)(currTime - gQueryStartTime) / CLOCKS_PER_SEC;
	if (queryDuration >= gTimeOutAfter)
	{
		globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"Evaluator",__FILE__,"Query Timed Out.");
		return FAILURE;
	}
#endif
		/*
		*  Search forward from a[lo] until an element is found that
		*  is greater than the pivot or lo >= hi 
		*/
		while (compare((void *)&a[lo] , (void *)&pivot) <= 0 && lo < hi) 
			lo++;

		/*
		*  Search backward from a[hi] until element is found that
		*  is less than the pivot, or lo >= hi
		*/
		while (compare((void *)&pivot , (void *)&a[hi]) <= 0 && lo < hi ) 
			hi--;

		/*
		*  Swap elements a[lo] and a[hi]
		*/
		if( lo < hi ) 
			swap(a,lo,hi);

	}

	/*
	*  Put the median in the "center" of the list
	*/
	a[hi0].copyTree(&a[hi]);
	a[hi].copyTree(&pivot);

	/*
	*  Recursive calls, elements a[lo0] to a[lo-1] are less than or
	*  equal to pivot, elements a[hi+1] to a[hi0] are greater than
	*  pivot.
	*/
	if (quickSort(a, lo0, lo-1,compare) == FAILURE)
		return FAILURE;
	
	if (quickSort(a, hi+1, hi0,compare) == FAILURE)
		return FAILURE;

	return SUCCESS;
}

int EvalQuickSort::quickSort(WitnessTree **a, int lo0, int hi0, int ( *compare )(const void *, const void *) )
{

	int lo = lo0;
	int hi = hi0;
	
	if (lo >= hi) 
		return SUCCESS;
	else if ( lo == hi - 1 ) 
	{
		if (compare((void *)a[lo] ,(void *) a[hi]) > 0) 
			swap(a,lo,hi);
		return SUCCESS;
	}


	/*
	*  Pick a pivot and move it out of the way
	*/
	WitnessTree* pivot;
	pivot = a[(lo + hi) / 2];
	a[(lo + hi) / 2] = a[hi];
	a[hi] = pivot;

	while( lo < hi ) 
	{
#ifdef EVAL_TIME_OUT
	clock_t currTime = clock();
	double queryDuration = (double)(currTime - gQueryStartTime) / CLOCKS_PER_SEC;
	if (queryDuration >= gTimeOutAfter)
	{
		globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"Evaluator",__FILE__,"Query Timed Out.");
		return FAILURE;
	}
#endif
		/*
		*  Search forward from a[lo] until an element is found that
		*  is greater than the pivot or lo >= hi 
		*/
		while (compare((void *)a[lo] , (void *)pivot) <= 0 && lo < hi) 
			lo++;

		/*
		*  Search backward from a[hi] until element is found that
		*  is less than the pivot, or lo >= hi
		*/
		while (compare((void *)pivot , (void *)a[hi]) <= 0 && lo < hi ) 
			hi--;

		/*
		*  Swap elements a[lo] and a[hi]
		*/
		if( lo < hi ) 
			swap(a,lo,hi);

	}

	/*
	*  Put the median in the "center" of the list
	*/
	a[hi0] = a[hi];
	a[hi] = pivot;

	/*
	*  Recursive calls, elements a[lo0] to a[lo-1] are less than or
	*  equal to pivot, elements a[hi+1] to a[hi0] are greater than
	*  pivot.
	*/
	if (quickSort(a, lo0, lo-1,compare) == FAILURE)
		return FAILURE;
	
	if (quickSort(a, hi+1, hi0,compare) == FAILURE)
		return FAILURE;

	return SUCCESS;
}
