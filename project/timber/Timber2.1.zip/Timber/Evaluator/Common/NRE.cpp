
#ifdef COMPILE_ME

#include "NRE.hpp"

namespace Timber
{

	NRE::NRE(NREType n) : nre(n)
	{
	}

	NRE::~NRE()
	{
		//indexList.clear() ;
	}

	void 
	NRE::startScan()
	{
		//scanIterator = indexList.begin() ;
	}

	int 
	NRE::getNextIndex()
	{
		/*
		if (scanIterator == indexList.end())
		{
			return FAILURE ;
		}

		int value = (*scanIterator)->second ;
		scanIterator++ ;
		return value ;
		*/
		return 1 ;
	}

	NREType
	NRE::getNRE()
	{
		return nre ;
	}

	int 
	NRE::getSize()
	{
		return indexList.size() ;
	}

	int
	NRE::getNode(int index)
	{
		int node ;

		try
		{
			node = indexList.at(index) ;
		}
		catch(std::out_of_range outOfRange)
		{
			node = -1 ;
		}

		return node ;
	}
			

	void 
	NRE::copy(NRE &toCopy)
	{
		//
		// Check to see if toCopy contains any entries
		// to copy from.
		//
		if (toCopy.getSize())
		{
			// This is a destructive in the sense that
			// toCopy replaces what we currently have.

			// Clear out current list
			indexList.clear() ;

			// Copy new entries in
			for (int index = 0 ; index < toCopy.getSize() ; index++)
			{
				int node = toCopy.getNode(index) ;
				if (node != -1)
				{
					indexList.push_back(node) ;
				}
			}
		}
	}

	bool 
	NRE::isEmpty()
	{
		return indexList.empty() ;
	}

	void 
	NRE::addOffsetToRangeAny(int startValue, int endValue, int offset)
	{
		if (indexList.empty())
		{
			return ;
		}

		int startInd = -1 ;

		//
		// Search through list looking for the starting point
		//
		for (int i = 0 ; i < indexList.size() ; i++)
		{
			if (indexList[i] >= startValue)
			{
				startInd = i ;
				break ;
			}
		}

		if (startInd != -1)
		{
			//
			// We found nodes to modify, start at node index
			// identified above
			//
			for (int i = startInd ; i < indexList.size() ; i++)
			{
				if (indexList[i] == endValue)
				{
					// Reached stopping point
					indexList[i] += offset ;
					break ;
				}
				else if (indexList[i] > endValue)
				{
					break ;
				}
				else
				{
					indexList[i] += offset ;
				}
			}
		}

		return ;
	}

	void 
	NRE::appendIndex(int index)
	{
		indexList.push_back(index) ;
	}

	void 
	NRE::deleteIndex(int index)
	{
		//indexListIterator = indexList.
		//indexList.erase(std::remove(indexList.begin(), indexList.end(), index), 
		//		indexList.end());
	}

	void 
	NRE::insertIndex(int index)
	{
		// Insert implicitly sorts the items....
		for(indexListIterator = indexList.begin() ; indexListIterator != indexList.end() ;
			indexListIterator++)
		{
			if (index < *(indexListIterator) )
			{
				indexList.insert(indexListIterator, index) ;
				break ;
			}
		}
	}

	bool 
	NRE::moreThanOneMatch()
	{
		return indexList.size() > 1 ;
	}

} // namespace Timber

#endif

