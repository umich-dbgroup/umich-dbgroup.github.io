/*
COPYRIGHT  � 2000-2004 
THE REGENTS OF THE UNIVERSITY OF MICHIGAN
ALL RIGHTS RESERVED

PERMISSION IS GRANTED TO USE, COPY, CREATE DERIVATIVE WORKS AND REDISTRIBUTE THIS SOFTWARE AND SUCH DERIVATIVE WORKS FOR 
NONCOMMERCIAL EDUCATION AND RESEARCH PURPOSES, SO LONG AS NO FEE IS CHARGED, AND SO LONG AS THE COPYRIGHT NOTICE ABOVE, 
THIS GRANT OF PERMISSION, AND THE DISCLAIMER BELOW APPEAR IN ALL COPIES MADE; AND SO LONG AS THE NAME OF THE UNIVERSITY 
OF MICHIGAN IS NOT USED IN ANY ADVERTISING OR PUBLICITY PERTAINING TO THE USE OR DISTRIBUTION OF THIS SOFTWARE WITHOUT 
SPECIFIC, WRITTEN PRIOR AUTHORIZATION.

THIS SOFTWARE IS PROVIDED AS IS, WITHOUT REPRESENTATION FROM THE UNIVERSITY OF MICHIGAN AS TO ITS FITNESS FOR ANY PURPOSE, 
AND WITHOUT WARRANTY BY THE UNIVERSITY OF MICHIGAN OF ANY KIND, EITHER EXPRESS OR IMPLIED, INCLUDING WITHOUT LIMITATION THE 
IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE. THE REGENTS OF THE UNIVERSITY OF MICHIGAN SHALL 
NOT BE LIABLE FOR ANY DAMAGES, INCLUDING SPECIAL, INDIRECT, INCIDENTAL, OR CONSEQUENTIAL DAMAGES, WITH RESPECT TO ANY CLAIM 
ARISING OUT OF OR IN CONNECTION WITH THE USE OF THE SOFTWARE, EVEN IF IT HAS BEEN OR IS HEREAFTER ADVISED OF THE POSSIBILITY 
OF SUCH DAMAGES.
*/

#ifndef __constructspecification_h
#define __constructspecification_h
#include <timber-compat.h>

#include "../../IndexMng/Common/ListNode.h"
#include "ExecArrayType.h"
//type
#define CONSTRUCT_TYPE_ELEMENT				1
#define CONSTRUCT_TYPE_ATTRIBUTE			2
#define CONSTRUCT_TYPE_CONTENT				3
#define CONSTRUCT_TYPE_OPTIONAL_ATTR		4


//source
#define CONSTRUCT_SRC_CONST			1
#define CONSTRUCT_SRC_REFERENCE		2


//getWhat
#define CPM_GET_SUBTREE			1
#define CPM_GET_TEXT			2
#define CPM_GET_ATTR			3
#define CPM_GET_ITSELF			4
#define CPM_GET_LOCAL_SUBTREE	5
#define CPM_GET_VALUE			6

//node source
#define CPM_NODE_SRC_WITNESS	1
#define CPM_NODE_SRC_INDEX		2



class ExecArrayType;


/**
* a single construct specification. used to represent a node in the construct spec tree.
* @see ConstructIterator
* @see ConstructSpecification (underneath)
* @author Shurug Al-Khalifa 
* @version 1.0
*/
class SingleConstructSpec
{
public:
	/**
	* Constructor
	* Initialize the variables.
	*/
	SingleConstructSpec();

	/**
	* Constructor
	* Initialize the variables.
	*@param type is the type of the node in the construct tree. it is one of the following: 
	*			CONSTRUCT_TYPE_ELEMENT: representing an element in the construct tree.
	*			CONSTRUCT_TYPE_ATTRIBUTE: representing an attribute node in the construct tree.
	*			CONSTRUCT_TYPE_CONTENT: representing a text of a subtree of an element in the construct tree.
	*@param source is the source of data to be used in an  element, attribute or content nodes. one of the following:
	*			CONSTRUCT_SRC_CONST: for type element, the element name is const and is stored in str1. for
	*							type attribute, the attribute name and value are consts and provided in str1
	*							and str2. for type content, the text content is const and is providef in str1.
	*			CONSTRUCT_SRC_REFERENCE: this means that the source of data is actually something in the database.
	*							for type element, the element name is gotten from the database. this depends on the 
	*							getWhat parameter. for type attribute, the attribute name is provided as const in str1
	*							while the value is gotten from the database using the getWhat parameter. for type
	*							content, getWhat is used to decide what to get from the database. If you are using
	*							this source (reference) you need to provide a pattern tree with the root in the input
	*							witness tree to the construct.
	*@param str1 is either element name or attribute name or content depending on the previous parameters. read above.
	*@param str2 is attribute value in case of const attribute.
	*@param patternRootIndex the index of the root of the pattern tree in the witness tree that is input to the 
	*			construct.
	*@param pattern is the pattern that you wish to construct. its root should belong in the input witness tree.
	*@param relation is an array of relationships between nodes in the pattern tree. relation[0] is the relationship
	*				between nodes 0 and 1 on the pattern. relation array is 1 entry smaller than pattern tree. each
	*				entry is either ANCS_DESC or PARENT_CHILD.
	*@param getWhat for each node in the pattern tree, what do you need? is ignored except for leaf nodes. each entry
	*				is one of the following:
	*				CPM_GET_SUBTREE: gets the subtree of the corresponding node in the pattern tree(i.e. all the desc)
	*				CPM_GET_TEXT: gets only the text children of teh corresponding node in the pattern tree.
	*				CPM_GET_ATTR: gets the attribute node of the corresponding node in the pattern tree.
	*				CPM_GET_ITSELF: gets the data of the node itself only without any desc.
	*@param attrNames if the corresponding pattern tree node asks for attribute in the getWhat field, then attrNames
	*				will have the name of the attribute.
	*@param level since ConstructSpecification is a tree that is traversed depth-first pre-order, level is used to
	*		distinguish children from siblings.
	*/
	SingleConstructSpec(int type, int source, char *str1, char *str2, NREType patternRootNRE, ExecArrayType *pattern,
		int *relation, int *getWhat, char **attrNames, int level, NREType assignedNRE);

	/**
	* Destructor
	* deletes different members.
	*/
	~SingleConstructSpec();

	int getType();
	void setType(int type);

	int getSource();
	void setSource(int source);
	 
	char *getStr1();
	void setStr1(char *str1, bool deleteOld = true);

	char *getStr2();
	void setStr2(char *str2, bool deleteOld = true);

	ExecArrayType *getPattern();
	void setPattern(ExecArrayType *pattern, bool deleteOld = true);

	NREType getPatternRootNRE();
	void setPatternRootNRE(NREType patternRootNRE);

	int getLevel();
	void setLevel(int level);

	int *getRelation();
	void setRelation(int *relation, bool deleteOld = true);

	int *getGetWhat();
	void setGetWhat(int *getWhat, bool deleteOld = true);

	char **getAttrNames();
	void setAttrNames(char **attrNames, bool deleteOld = true);

	int getRootGetWhat();
	void setRootGetWhat(int rootGetWhat);

	char *getRootAttrName();
	void setRootAttrName(char *rootAttrName, bool deleteOld = true);

	int getNodeSource();
	void setNodeSource(int nodeSource);

	int *getTagNames();
	void setTagNames(int *tagNames, bool deleteOld = true);

	NREType getAssignedNRE();
	void setAssignedNRE(NREType assignedNRE);
private:
	int type;
	int source;
	char *str1;
	char *str2;
	NREType patternRootNRE;
	ExecArrayType *pattern;
	int *relation;
	int *getWhat;
	char **attrNames;
	NREType assignedNRE;

	// tagNames are used when the nodeSource is CPM_NODE_SRC_WITNESS
	int *tagNames;

	int level;

	//this is for special case where pattern size =0 then it is for the root only and is treated like getWhat
	// parameter above.
	int rootGetWhat;

	//this is for special case where pattern size =0 then it is for the root only and is applicable if rootGetWhat
	// asks for an attribute.
	char *rootAttrName;

	// specifies the source of the nodes in teh pattern tree. you can either scan an index or scan the witness
	// tree. it is one of the following:
	//		CPM_NODE_SRC_WITNESS: if all the data you want is in the witness tree, then you you have to provide tag
	//					names to look for. tagNames should not be null.
	//		CPM_NODE_SRC_INDEX: if the data you want is scanned  from indices.
	int nodeSource;
};


/**
* a group of singleConstructSpec. is basically a tree that specifes how the output of the construct iterator should
* look like. it is an array of singleConstructSpec. the level field in the single construct spec defines the tree.
* the array is a depth-first pre-order traversal of the construct tree.
* @see ConstructIterator
* @see SingleConstructSpec (above)
* @author Shurug Al-Khalifa 
* @version 1.0
*/
class ConstructSpecification
{
public:
	/**
	* Constructor
	* Initialize the variables.
	*/
	ConstructSpecification(int maxSize);

	/**
	* Destructor
	* nothing.
	*/
	~ConstructSpecification();

	/**
	* Access Method
	* gets a specific spec by its index in the tree.
	* @param index the index of the spec in the tree.
	* @returns the node in the construct tree with index index.
	*/
	SingleConstructSpec *getSpecByIndex(int index);

	/**
	* Process Method
	* appends a spec to the construct tree. remember, it is an array, therefore, setting the level parameter
	* will decide where the spec belongs in the tree.
	* @param spec is the spec to be appended.
	* @returns FAILURE if there is no space to add this spec, returns SUCCESS otherwise.
	*/
	int appendSpec(SingleConstructSpec *spec);

	/**
	* Process Method
	* inserts a spec into the construct tree. remember, it is an array, therefore, setting the level parameter
	* will decide where the spec belongs in the tree.
	* @param spec is the spec to be inserted.
	* @param index is the index in the array where you want tthe spec to be inserted.
	* @returns FAILURE if there is no space to add this spec, returns SUCCESS otherwise.
	*/
	int insertSpec(SingleConstructSpec *spec, int index);

	/**
	* Access Method
	* gets the index of an ancs of a given spec.
	* @param index the index of the spec in the tree that you want to get its ancestor.
	* @param levelsUp is how many levels upwards the ancestor is. 1--> parent
	* @returns the index of the ancestor spec of spec with index index.
	*/
	int getAncsIndex(int index, int levelsUp = 1);

	/**
	* Access Method
	* gets the index of a child of a given spec.
	* @param index the index of the spec in the tree that you want to get its child.
	* @param childNum is the number of the child you want to get. 1--> first child
	* @returns the index of the child spec of spec with index index.
	*/
	int getChildIndex(int index, int childNum = 1);

	/**
	* Access Method
	* gets the index of the next sibling of a given spec.
	* @param index the index of the spec in the tree that you want to get its next sibling.
	* @returns the index of the sibling spec of spec with index index.
	*/
	int getSiblingIndex(int index);

	/**
	* Access Method
	* gets the ancs of a given spec.
	* @param index the index of the spec in the tree that you want to get its ancestor.
	* @param levelsUp is how many levels upwards the ancestor is. 1--> parent
	* @returns the ancestor spec of spec with index index.
	*/
	SingleConstructSpec *getAncs(int index, int levelsUp = 1);

	/**
	* Access Method
	* gets the child of a given spec.
	* @param index the index of the spec in the tree that you want to get its child.
	* @param childNum is the number of the child you want to get. 1--> first child
	* @returns the child spec of spec with index index.
	*/
	SingleConstructSpec *getChild(int index, int childNum = 1);

	/**
	* Access Method
	* gets the next sibling of a given spec.
	* @param index the index of the spec in the tree that you want to get its next sibling.
	* @returns the sibling spec of spec with index index.
	*/
	SingleConstructSpec *getSibling(int index);

	/**
	* Access Method
	* gets the root of the construct tree.
	* @returns the root of the construct tree.
	*/
	SingleConstructSpec *getRoot();

	/**
	* Access Method
	* gets the size of the construct tree.
	* @returns the size of the construct tree. i.e. the number of specs in it.
	*/
	int getSize();

private:
	int size;
	int maxSize;
	SingleConstructSpec *specArray;
};

#endif
