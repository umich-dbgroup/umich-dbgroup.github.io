/*
COPYRIGHT  � 2000-2004 
THE REGENTS OF THE UNIVERSITY OF MICHIGAN
ALL RIGHTS RESERVED

PERMISSION IS GRANTED TO USE, COPY, CREATE DERIVATIVE WORKS AND REDISTRIBUTE THIS SOFTWARE AND SUCH DERIVATIVE WORKS FOR 
NONCOMMERCIAL EDUCATION AND RESEARCH PURPOSES, SO LONG AS NO FEE IS CHARGED, AND SO LONG AS THE COPYRIGHT NOTICE ABOVE, 
THIS GRANT OF PERMISSION, AND THE DISCLAIMER BELOW APPEAR IN ALL COPIES MADE; AND SO LONG AS THE NAME OF THE UNIVERSITY 
OF MICHIGAN IS NOT USED IN ANY ADVERTISING OR PUBLICITY PERTAINING TO THE USE OR DISTRIBUTION OF THIS SOFTWARE WITHOUT 
SPECIFIC, WRITTEN PRIOR AUTHORIZATION.

THIS SOFTWARE IS PROVIDED AS IS, WITHOUT REPRESENTATION FROM THE UNIVERSITY OF MICHIGAN AS TO ITS FITNESS FOR ANY PURPOSE, 
AND WITHOUT WARRANTY BY THE UNIVERSITY OF MICHIGAN OF ANY KIND, EITHER EXPRESS OR IMPLIED, INCLUDING WITHOUT LIMITATION THE 
IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE. THE REGENTS OF THE UNIVERSITY OF MICHIGAN SHALL 
NOT BE LIABLE FOR ANY DAMAGES, INCLUDING SPECIAL, INDIRECT, INCIDENTAL, OR CONSEQUENTIAL DAMAGES, WITH RESPECT TO ANY CLAIM 
ARISING OUT OF OR IN CONNECTION WITH THE USE OF THE SOFTWARE, EVEN IF IT HAS BEEN OR IS HEREAFTER ADVISED OF THE POSSIBILITY 
OF SUCH DAMAGES.
*/

#include "ShoreList.h"

char *ShoreList::tempBuf;//[CONTAINER_SIZE + sizeof(serial_t) + 5];

#include "OnDiskList.hpp"

ShoreList::ShoreList()
{
	this->Initialize();
	this->bufSize = gSettings->getIntegerValue("CONTAINER_SIZE",CONTAINER_SIZE_DEFAULT) + sizeof(serial_t) + 5;
}

ShoreList::ShoreList(serial_t fileID, lvid_t volumeID)
{
	this->fileID = fileID;
	this->volumeID = volumeID;

	size = 0;
	scanCursor = 0;
	this->bufSize = gSettings->getIntegerValue("CONTAINER_SIZE",CONTAINER_SIZE_DEFAULT) + sizeof(serial_t) + 5;
}

ShoreList::~ShoreList()
{
}

void ShoreList::Initialize()
{
	size = 0;
	scanCursor = 0;
	recordsRead = 0;
}

bool ShoreList::IsEmpty()
{
	return (size==0?true:false);
}

serial_t ShoreList::GetHead()
{
	return head;
}

serial_t ShoreList::GetTail()
{
	return tail;
}

void ShoreList::SetHead(serial_t head)
{
	this->head = head;
}

void ShoreList::SetTail(serial_t tail)
{
	this->tail = tail;
}

void ShoreList::setSize(int size)
{
	this->size = size;
}

void ShoreList::SetFileID(serial_t fileID)
{
	this->fileID = fileID;
}

void ShoreList::SetVolumeID(lvid_t volumeID)
{
	this->volumeID = volumeID;
}

void ShoreList::SetCurrRecID(serial_t currRecID)
{
	this->currRecID = currRecID;
}


serial_t ShoreList::GetCurrRecID()
{
	return currRecID;
}

int ShoreList::AddToList(ContainerClass *cont, serial_t nextRecID)
{
	bool status ;

	if (IsEmpty())
	{
		head = currRecID;
		scanCursor = head;
	}
	else
		scanCursor = currRecID;

	tail = currRecID;

	// copying the next record in the list
	cont->setSNext(nextRecID) ;


	//copying the size of the container
	int cursor = cont->GetAddCursor();
	cont->setSSize(cursor);

	status = Timber::OnDiskList::createRecord(currRecID.getRID(), cont) ;

	if (! status)
	{
		stringstream msg;
		msg<<status<<'\0';
		globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"Evaluator",
				__FILE__,msg.rdbuf()->str().c_str());
		return FAILURE;				
	}	

	SetCurrRecID(nextRecID);
	size++;

	//added to update the tail of shorelist
	//tail = currRecID;

	return SUCCESS;
}

int ShoreList::AppendToList(ShoreList *appendedList)
{
	cout << "AppendToList" << endl ;

	if (appendedList->IsEmpty())
		return SUCCESS;

	if (IsEmpty())
	{
		copyList(appendedList);
		return SUCCESS;
	}

	char str[sizeof(serial_t)];
	serial_t h = appendedList->GetHead();
	memcpy(str,&h,sizeof(serial_t));
	vec_t newRid(str,sizeof(serial_t));
		
	rc = ss_m::update_rec(volumeID,tail,0,newRid);
	if (rc)
	{
		stringstream msg;
		msg<<rc<<'\0';
		globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"Evaluator",__FILE__,msg.rdbuf()->str().c_str());
		return FAILURE;				
	}

	size += appendedList->Size();
	tail = appendedList->GetTail();
	currRecID = appendedList->GetCurrRecID();
	return SUCCESS;
}


int ShoreList::complexPrependToList(ShoreList *prependedList,ContainerClass *newElement, 
									 serial_t nextRecID)
{
	cout << "complexPrependToList" << endl ;

	this->head = prependedList->GetHead();

	char str[sizeof(serial_t)];
	memcpy(str,&(nextRecID),sizeof(serial_t));
	vec_t newRid(str,sizeof(serial_t));

	//Timber::Container c(sizeof(serial_t)) ;
	//c.setBytes(sizeof(serial_t), str) ;
		
	//rc = ss_m::update_rec(volumeID,prependedList->GetTail(),0,newRid);
	//if (rc)

	bool status = true ;
	//status = Timber::OnDiskList::updateRecord(prependedList->GetTail().getRID(), 0, c) ;

	if (! status)
	{
		stringstream msg;
		msg<<rc<<'\0';
		globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"Evaluator",__FILE__,msg.rdbuf()->str().c_str());
		return FAILURE;				
	}


	if (oldScanCursor == tail)
	{
		serial_t tmpCurrRecID = currRecID;
		currRecID = nextRecID;
		size = prependedList->Size();
		this->AddToList(newElement,tmpCurrRecID);
		this->tail = nextRecID;
	}
	else
	{
		size = prependedList->Size() + this->Size() - this->recordsRead;
	//	this->AddToList(newElement,scanCursor);
		int recSize = 0;
		// copying the next record in the list
		memcpy(ShoreList::tempBuf,&scanCursor,sizeof(scanCursor));
		recSize += sizeof(scanCursor);

		//copying the size of the container
		int cursor = newElement->GetAddCursor();
		memcpy(ShoreList::tempBuf+recSize,&cursor,sizeof(int));
		recSize += sizeof(int);

		// copying the container itself
		newElement->GetData(0,newElement->GetAddCursor(),ShoreList::tempBuf+recSize);
		recSize += newElement->GetAddCursor();

		vec_t data(ShoreList::tempBuf, recSize); 
		//rc = ss_m::create_rec_id(volumeID,fileID,vec_t(), recSize,data,nextRecID);
		//if (rc) 

		//Timber::Container c2(recSize) ;
		//c.setBytes(recSize, ShoreList::tempBuf) ;

		//status = Timber::OnDiskList::createRecord(currRecID.getRID(), c2) ;

		if (! status)
		{
			stringstream msg;
			msg<<rc<<'\0';
			globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"Evaluator",__FILE__,msg.rdbuf()->str().c_str());
			return FAILURE;					
		}	
//		globalTemp++;
//			fprintf(shoreIDsFile,"%d\n",currRecID);

	}
	this->StartScan();	
	return SUCCESS;
}

int ShoreList::simplePrependToList(ShoreList *prependedList, serial_t nextRecID)
{
	cout << "simplePrependToList" << endl ;

	head = prependedList->GetHead();
	char str[sizeof(serial_t)];
	if (oldScanCursor == tail)
	{
		memcpy(str,&(nextRecID),sizeof(serial_t));
		vec_t newRid(str,sizeof(serial_t));
			
		rc = ss_m::update_rec(volumeID,prependedList->GetTail(),0,newRid);
		if (rc)
		{
			stringstream msg;
			msg<<rc<<'\0';
			globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"Evaluator",__FILE__,msg.rdbuf()->str().c_str());
			return FAILURE;				
		}
		currRecID = nextRecID;

		tail = prependedList->GetTail();
		size = prependedList->Size();
	}
	else
	{
		memcpy(str,&(scanCursor),sizeof(serial_t));
		vec_t newRid(str,sizeof(serial_t));
			
		rc = ss_m::update_rec(volumeID,prependedList->GetTail(),0,newRid);
		if (rc)
		{
			stringstream msg;
			msg<<rc<<'\0';
			globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"Evaluator",__FILE__,msg.rdbuf()->str().c_str());
			return FAILURE;				
		}
		size += prependedList->Size();
	}
	return SUCCESS;
}


void ShoreList::copyList(ShoreList *newList)
{
	cout << "copyList" << endl ;
	head = newList->GetHead();
	tail = newList->GetTail();

	size = newList->Size();
	currRecID = newList->GetCurrRecID();
	this->StartScan();

	cout << "copyList2 head = " << head << endl ;
}



int ShoreList::copyList(ShoreList *newList, serial_t nextRecID)
{
	cout << "copyList" << endl ;

	head = newList->GetHead();
	tail = newList->GetTail();

	size = newList->Size();
	char str[sizeof(serial_t)];
	memcpy(str,&(nextRecID),sizeof(serial_t));
	vec_t newRid(str,sizeof(serial_t));
			
	rc = ss_m::update_rec(volumeID,newList->GetTail(),0,newRid);
	if (rc)
	{
		stringstream msg;
		msg<<rc<<'\0';
		globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"Evaluator",__FILE__,msg.rdbuf()->str().c_str());
		return FAILURE;				
	}

	currRecID = nextRecID;
	this->StartScan();
	cout << "copyList1 head = " << head << endl ;
	return SUCCESS;
}


void ShoreList::StartScan()
{
	scanCursor = head;
	oldScanCursor = 0;
	recordsRead = 0;
}

serial_t ShoreList::GetScanCursor()
{
	return scanCursor;
}

int ShoreList::GetNext(ContainerClass *cont)
{
	if (IsEmpty())
		return FAILURE;

	if (oldScanCursor == tail && scanCursor != tail)
		return FAILURE;

	oldScanCursor = scanCursor;

	cont->Initialize();

	bool status = Timber::OnDiskList::getRecord(scanCursor.getRID(), cont) ;

	if (! status)
	{
		stringstream msg;
		msg<<status<<'\0';
		globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"Evaluator",__FILE__,msg.rdbuf()->str().c_str());
		return FAILURE;							
	} 


	scanCursor = cont->getSNext() ;

	recordsRead++;

	return SUCCESS;
}


int ShoreList::Size()
{
	return size;
}

int ShoreList::prependBuffer(ContainerClass *cont, serial_t recID)
{
	cout << "prependBuffer" << endl ;

	serial_t nextRecID;
	if (IsEmpty())
	{
		tail = recID;
		nextRecID = 0;
	}
	else
		nextRecID = head;
		
		
	head = recID;
	int recSize = 0;
	// copying the next record in the list
	memcpy(ShoreList::tempBuf,&nextRecID,sizeof(nextRecID));
	recSize += sizeof(nextRecID);

	//copying the size of the container
	int cursor = cont->GetAddCursor();
	memcpy(ShoreList::tempBuf+recSize,&cursor,sizeof(int));
	recSize += sizeof(int);

	// copying the container itself
	cont->GetData(0,cont->GetAddCursor(),ShoreList::tempBuf+recSize);
	recSize += cont->GetAddCursor();

	vec_t data(ShoreList::tempBuf, recSize); 
	rc = ss_m::create_rec_id(volumeID,fileID,vec_t(), recSize,data,recID);
	if (rc) 
	{
		stringstream msg;
		msg<<rc<<'\0';
		globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"Evaluator",__FILE__,msg.rdbuf()->str().c_str());
		return FAILURE;				
	}	 
	//globalTemp++;
	//	fprintf(shoreIDsFile,"%d\n",currRecID);

	scanCursor = head;
	size++;
	return SUCCESS;
}

/*Yunyao - Added 12-15-03, updated 01-04-2005*/
void ShoreList::SetScanCursor(serial_t newScanCursor)
{
	cout << "SetScanCursor newScanCursor = " << newScanCursor << endl ;
	this->scanCursor = newScanCursor;
	this->oldScanCursor = newScanCursor;
}

