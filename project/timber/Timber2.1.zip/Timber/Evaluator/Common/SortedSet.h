/*
COPYRIGHT  � 2000-2004 
THE REGENTS OF THE UNIVERSITY OF MICHIGAN
ALL RIGHTS RESERVED

PERMISSION IS GRANTED TO USE, COPY, CREATE DERIVATIVE WORKS AND REDISTRIBUTE THIS SOFTWARE AND SUCH DERIVATIVE WORKS FOR 
NONCOMMERCIAL EDUCATION AND RESEARCH PURPOSES, SO LONG AS NO FEE IS CHARGED, AND SO LONG AS THE COPYRIGHT NOTICE ABOVE, 
THIS GRANT OF PERMISSION, AND THE DISCLAIMER BELOW APPEAR IN ALL COPIES MADE; AND SO LONG AS THE NAME OF THE UNIVERSITY 
OF MICHIGAN IS NOT USED IN ANY ADVERTISING OR PUBLICITY PERTAINING TO THE USE OR DISTRIBUTION OF THIS SOFTWARE WITHOUT 
SPECIFIC, WRITTEN PRIOR AUTHORIZATION.

THIS SOFTWARE IS PROVIDED AS IS, WITHOUT REPRESENTATION FROM THE UNIVERSITY OF MICHIGAN AS TO ITS FITNESS FOR ANY PURPOSE, 
AND WITHOUT WARRANTY BY THE UNIVERSITY OF MICHIGAN OF ANY KIND, EITHER EXPRESS OR IMPLIED, INCLUDING WITHOUT LIMITATION THE 
IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE. THE REGENTS OF THE UNIVERSITY OF MICHIGAN SHALL 
NOT BE LIABLE FOR ANY DAMAGES, INCLUDING SPECIAL, INDIRECT, INCIDENTAL, OR CONSEQUENTIAL DAMAGES, WITH RESPECT TO ANY CLAIM 
ARISING OUT OF OR IN CONNECTION WITH THE USE OF THE SOFTWARE, EVEN IF IT HAS BEEN OR IS HEREAFTER ADVISED OF THE POSSIBILITY 
OF SUCH DAMAGES.
*/

#ifndef __sortedset_h
#define __sortedset_h
#include <timber-compat.h>

#define INITIAL_SET_SIZE	1000

template <class Temp> class SortedSet
{
public:
	SortedSet(int initialSize = INITIAL_SET_SIZE)
	{
		maxSize = initialSize;
		theSet = new Temp[maxSize];
		initialize();
	};
	void initialize()
	{
		actualSize = 0;
		scanCursor = 0;
		maxLevel = -1;
		numMaxLevel = 0;
	};

	~SortedSet()
	{
		delete [] theSet;
	};

	void append(ComplexListNode *node)
	{
		if (actualSize == maxSize)
			doubleSetSize();
		theSet[actualSize].SetActualAncsComplex(node);
		actualSize++;
		if (node->GetLevel() > maxLevel)
		{
			maxLevel = node->GetLevel();
			numMaxLevel = 1;
		}
		else if (node->GetLevel() == maxLevel)
			numMaxLevel++;
	};

	void append(ListNode *node)
	{
		if (actualSize == maxSize)
			doubleSetSize();
		theSet[actualSize].SetActualAncs(node);
		actualSize++;
		if (node->GetLevel() > maxLevel)
		{
			maxLevel = node->GetLevel();
			numMaxLevel = 1;
		}
		else if (node->GetLevel() == maxLevel)
			numMaxLevel++;
	};

	void append(Temp *node)
	{
		if (actualSize == maxSize)
			doubleSetSize();
		theSet[actualSize] = *node;
		actualSize++;
		if (node->GetActualAncs()->GetLevel() > maxLevel)
		{
			maxLevel = node->GetActualAncs()->GetLevel();
			numMaxLevel = 1;
		}
		else if (node->GetActualAncs()->GetLevel() == maxLevel)
			numMaxLevel++;
	};

	void appendWitness(WitnessTree *node)
	{
		if (actualSize == maxSize)
			doubleSetSizeWitness();
		theSet[actualSize].appendList((ListNode *)node->getBuffer(),node->length());
		theSet[actualSize].setScore(node->getScore());
		actualSize++;
	};
	void doubleSetSizeWitness()
	{
		Temp *tmp = theSet;
		maxSize *= 2;
		theSet = new Temp[maxSize];
		//memcpy(theSet,tmp,sizeof(Temp)*actualSize);
		for (int i=0; i<actualSize; i++)
		{
			theSet[i].appendList((ListNode *)tmp[i].getBuffer(),tmp[i].length());
			theSet[i].setScore(tmp[i].getScore());
		}
		delete [] tmp;
	};
	void doubleSetSize()
	{
		Temp *tmp = theSet;
		maxSize *= 2;
		theSet = new Temp[maxSize];
		memcpy(theSet,tmp,sizeof(Temp)*actualSize);
		delete [] tmp;
	};

	void removeDuplicates()
	{
		if (isEmpty())
			return;

		//we can assume safely that they are sorted by start key
		KeyType lastSK = -1;
		int curr = 0;
		while (curr < actualSize)
		{
			KeyType currSK = theSet[curr].GetActualAncs()->GetStartPos();
			if (currSK == lastSK)
				remove(curr);
			else
			{
				if (lastSK == -1)
					curr++;
				else
					remove(curr-1);
				lastSK = currSK;
			}
		}
	};


	Temp *getNodeAt(int index)
	{
		if (isEmpty())
			return NULL;
		if (index >= actualSize)
			return NULL;
		return &theSet[index];
	};
	int getActualSize()
	{
		return actualSize;
	};

	bool isEmpty()
	{
		return (actualSize == 0);
	};

	void startScan()
	{
		scanCursor = 0;
	};

	Temp *getNext()
	{
		if (isEmpty())
			return NULL;
		if (scanCursor == actualSize)
			return NULL;
		scanCursor++;
		return &theSet[scanCursor-1];
	};

	int getScanCursor()
	{
		return scanCursor;
	};

	void remove(int index)
	{
		if (index >= actualSize)
			return;
		int lev = theSet[index].GetActualAncs()->GetLevel();
		theSet[index].setCounters(NULL);
		for (int i=index+1; i<actualSize; i++)
			theSet[i-1] = theSet[i];
		actualSize--;
		theSet[actualSize].setCounters(NULL,false);
		if (lev == maxLevel)
		{
			numMaxLevel--;
			if (numMaxLevel == 0)
				findMaxLevel();
		}
	};

	int getMaxLevel()
	{
		return maxLevel;
	};

	void findMaxLevel()
	{
		maxLevel = -1;
		for (int i=0; i<actualSize; i++)
		{
			if (theSet[i].GetActualAncs()->GetLevel() > maxLevel)
			{
				maxLevel = theSet[i].GetActualAncs()->GetLevel();
				numMaxLevel = 1;
			}
			else if (theSet[i].GetActualAncs()->GetLevel() == maxLevel)
				numMaxLevel++;
		}
	};

	Temp *getCurr()
	{
		if (isEmpty())
			return NULL;
		if (scanCursor == actualSize)
			return NULL;
		return &theSet[scanCursor];
	};
private:
	Temp *theSet;
	int maxSize;
	int actualSize;
	int scanCursor;
	int maxLevel;
	int numMaxLevel;
};

#endif
