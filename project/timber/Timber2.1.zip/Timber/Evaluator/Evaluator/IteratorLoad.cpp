#ifdef WIN32

#include "EvaluatorClass.h"

#include "Iterators/ChildChooser/parse.hpp"
#include "Iterators/Construct/parse.hpp"
#include "Iterators/Cube/parse.hpp"
#include "Iterators/DataDiscard/parse.hpp"
#include "Iterators/DataInstantiation/parse.hpp"
#include "Iterators/DuplicateEliminator/parse.hpp"
#include "Iterators/FileReader/parse.hpp"
#include "Iterators/FileWriter/parse.hpp"
#include "Iterators/Function/parse.hpp"
#include "Iterators/GroupBy/parse.hpp"
#include "Iterators/IndexAccess/parse.hpp"
#include "Iterators/IndexHashValueJoin/parse.hpp"
#include "Iterators/MCCAS/parse.hpp"
#include "Iterators/MergeTrees/parse.hpp"
#include "Iterators/NavigationalGetRelative/parse.hpp"
#include "Iterators/OneSidedValueJoin/parse.hpp"
#include "Iterators/PhraseFinder/parse.hpp"
#include "Iterators/Pick/parse.hpp"
#include "Iterators/Projection/parse.hpp"
#include "Iterators/Provenance/parse.hpp"
#include "Iterators/SBTermJoin/parse.hpp"
#include "Iterators/ScanAccess/parse.hpp"
#include "Iterators/Selection/parse.hpp"
#include "Iterators/SetOperations/parse.hpp"
#include "Iterators/Sort/parse.hpp"
#include "Iterators/SortStopK/parse.hpp"
#include "Iterators/StructuralJoin/parse.hpp"
#include "Iterators/UnivQuant/parse.hpp"
#include "Iterators/Updates/parse.hpp"
#include "Iterators/ValueJoin/parse.hpp"
#include "Iterators/ValueSort/parse.hpp"

void
EvaluatorClass::iteratorLoad()
{
	iterator_parsers[ ChildChooserPlanParser::getIteratorIdentifier()] = ChildChooserPlanParser::getQueryEvalNode ;
	iterator_parsers[ ConstructPlanParser::getIteratorIdentifier()] = ConstructPlanParser::getQueryEvalNode ;
	iterator_parsers[ CubePlanParser::getIteratorIdentifier()] = CubePlanParser::getQueryEvalNode ;
	iterator_parsers[ DataDiscardPlanParser::getIteratorIdentifier()] = DataDiscardPlanParser::getQueryEvalNode ;
	iterator_parsers[ DataInstantiationPlanParser::getIteratorIdentifier()] = DataInstantiationPlanParser::getQueryEvalNode ;
	iterator_parsers[ DuplicateEliminatorPlanParser::getIteratorIdentifier()] = DuplicateEliminatorPlanParser::getQueryEvalNode ;
	iterator_parsers[ FileReaderPlanParser::getIteratorIdentifier()] = FileReaderPlanParser::getQueryEvalNode ;
	iterator_parsers[ FileWriterPlanParser::getIteratorIdentifier()] = FileWriterPlanParser::getQueryEvalNode ;
	iterator_parsers[ FunctionPlanParser::getIteratorIdentifier()] = FunctionPlanParser::getQueryEvalNode ;
	iterator_parsers[ GroupByPlanParser::getIteratorIdentifier()] = GroupByPlanParser::getQueryEvalNode ;
	iterator_parsers[ IndexAccessPlanParser::getIteratorIdentifier()] = IndexAccessPlanParser::getQueryEvalNode ;
	iterator_parsers[ IndexHashValueJoinPlanParser::getIteratorIdentifier()] = IndexHashValueJoinPlanParser::getQueryEvalNode ;
	iterator_parsers[ MCCASPlanParser::getIteratorIdentifier()] = MCCASPlanParser::getQueryEvalNode ;
	iterator_parsers[ MergeTreesPlanParser::getIteratorIdentifier()] = MergeTreesPlanParser::getQueryEvalNode ;
	iterator_parsers[ NavigationalGetRelativePlanParser::getIteratorIdentifier()] = NavigationalGetRelativePlanParser::getQueryEvalNode ;
	iterator_parsers[ OneSidedValueJoinPlanParser::getIteratorIdentifier()] = OneSidedValueJoinPlanParser::getQueryEvalNode ;
	iterator_parsers[ PhraseFinderPlanParser::getIteratorIdentifier()] = PhraseFinderPlanParser::getQueryEvalNode ;
	iterator_parsers[ PickPlanParser::getIteratorIdentifier()] = PickPlanParser::getQueryEvalNode ;
	iterator_parsers[ ProjectionPlanParser::getIteratorIdentifier()] = ProjectionPlanParser::getQueryEvalNode ;
	iterator_parsers[ ProvenancePlanParser::getIteratorIdentifier()] = ProvenancePlanParser::getQueryEvalNode ;
	iterator_parsers[ SBTermJoinPlanParser::getIteratorIdentifier()] = SBTermJoinPlanParser::getQueryEvalNode ;
	iterator_parsers[ ScanAccessPlanParser::getIteratorIdentifier()] = ScanAccessPlanParser::getQueryEvalNode ;
	iterator_parsers[ SelectionPlanParser::getIteratorIdentifier()] = SelectionPlanParser::getQueryEvalNode ;
	iterator_parsers[ SetOperationsPlanParser::getIteratorIdentifier()] = SetOperationsPlanParser::getQueryEvalNode ;
	iterator_parsers[ SortPlanParser::getIteratorIdentifier()] = SortPlanParser::getQueryEvalNode ;
	iterator_parsers[ SortStopKPlanParser::getIteratorIdentifier()] = SortStopKPlanParser::getQueryEvalNode ;
	iterator_parsers[ StructuralJoinPlanParser::getIteratorIdentifier()] = StructuralJoinPlanParser::getQueryEvalNode ;
	iterator_parsers[ UnivQuantPlanParser::getIteratorIdentifier()] = UnivQuantPlanParser::getQueryEvalNode ;
	iterator_parsers[ UpdatesPlanParser::getIteratorIdentifier()] = UpdatesPlanParser::getQueryEvalNode ;
	iterator_parsers[ ValueJoinPlanParser::getIteratorIdentifier()] = ValueJoinPlanParser::getQueryEvalNode ;
	iterator_parsers[ ValueSortPlanParser::getIteratorIdentifier()] = ValueSortPlanParser::getQueryEvalNode ;
}

#endif
