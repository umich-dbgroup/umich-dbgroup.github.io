#!perl

use IO::File;
use strict;

my $lookForParseCase = 0;
my $lookForProcessCase = 0;
my $saveLines = 0;
my @switchBuf = ();
my $evalTreeNodeClass = "";
my $evalTreeChar = "";
my $queryNodeType = "";
my @evalMembers = qw(maxNRE getQueryEvalNode processQueryEvalNode TransformString getExecTree fileIDsArray getIndexMng getDataManager updatesCursor);
my @includes = ();

my @iteratorClasses =  qw(ChildChooserIterator ConstructIterator ConstructPartialMatcher CubeBottomUpIterator CubeCounterBasedIterator CubeTopDown2Iterator CubeTopDownIterator DataDiscardIterator DataInstantiationIterator DifferenceIterator DuplicateEliminatorIterator ExternalSortIterator ExternalValueSortIterator FileReaderIterator FileWriterIterator FilterIterator FunctionIterator GroupByIterator IndexHashValueJoinIterator IntersectionIterator MeetIterator MergeTreesIterator NavigationalGetRelative OneSidedValueJoinIterator PhraseFinderIterator PickIterator ProjectionIterator ProvenanceIterator ScanIterator SortIterator SortStopKIterator TempProject TreeLevelFunctionIterator UnionIterator UniversalQuantification UpdatesIterator ValueJoinIterator ValueSortIterator StackBasedAncs StackBasedAncsOuter StackBasedAncsProjAncs StackBasedDesc StackBasedNegativeAncs StackBasedTermJoin GistIndexAccess HashIndexAccess HashIndexUpdate);
 
my $iteratorRE = join("|",@iteratorClasses);

while(my $line = <>) {
    chomp $line;
    chop $line if substr($line,-1) eq "\015";

    # START LOOKING FOR CASES
    #
    if($line =~ /\QQueryEvaluationTreeNode *EvaluatorClass::getQueryEvalNode(char *line, void *queryInput)\E/) {
	$lookForParseCase = 1;
    }
    elsif($line =~ /\QIteratorClass *EvaluatorClass::processQueryEvalNode(QueryEvaluationTreeNode *node)\E/) {
	$lookForProcessCase = 1;
    }

    # PROCESS LINES INSIDE CASE STATEMENTS
    if($lookForParseCase && ($line =~ /^\s*case '(\w)':/)) {
	my $newEvalChar = $1;
	
	warn("Parsing iterator $newEvalChar\n");
	if($saveLines) {
	    dumpParseTreeNode();
	}
	$evalTreeChar = $newEvalChar;
	$evalTreeNodeClass = "";
	$saveLines = 1;
	@switchBuf = ();
	@includes = ();
    }
    elsif ($lookForProcessCase && ($line =~ /^\s*case (EVALUATION_OP\w*):/)) {
	my $newQueryNodeType = $1;

	warn("Parsing iterator $newQueryNodeType\n");
	if($saveLines) {
	    dumpQueryTreeNode();
	}
	$queryNodeType = $newQueryNodeType;
	$evalTreeNodeClass = "";
	$saveLines = 1;
	@switchBuf = ();
	@includes = ();
    }

    # END OF CASE STATEMENT: ALL DONE
    elsif ($line =~ /\/\/END_PARSE/) {
	if($saveLines && $lookForParseCase) {
	    dumpParseTreeNode();
	} elsif ($saveLines && $lookForProcessCase) {
	    dumpQueryTreeNode();
	}
	@switchBuf = ();
	@includes = ();
	$saveLines = 0;
	$lookForParseCase = 0;
	$lookForProcessCase = 0;
    }
    elsif($saveLines) {
	# $line =~ s/globalErrorInfo.insertProblem\(ERR_TYPE_ERROR,__LINE__,"Evaluator",__FILE__,(.*)\);/EVALUATOR_ERROR($1)/;
	# Also need to transform refs to EvaluatorClass from this-> to evaluator-> AND add that to any
	# unmarked references to EvaluatorClass.
	if($line =~ /QueryEvaluationTree(\w+)Node/) {
	    if($evalTreeNodeClass ne '' && $evalTreeNodeClass ne $1) {
		warn("More than one QueryEvaluationTree class: old: $evalTreeNodeClass; new $1\n");
	    }
	    $evalTreeNodeClass = $1 ;
	}

	$line =~ s/return NULL;/curr=NULL; return;/g;
	$line =~ s/dataMng/getDataManager()/g;
	$line =~ s/this(\W)/evaluator$1/g;
	foreach my $token (@evalMembers) {
	    $line =~ s/([^>])$token/$1evaluator->$token/g;
	}
	if ($line =~ /($iteratorRE)/) {
	    push(@includes,$1);
	}

	push(@switchBuf,$line);
    }


}

sub dumpQueryTreeNode {
    my $evalFile = new IO::File;
    #$evalFile->open("< ../QueryEvaluationTree/$evalTreeNodeClass.cpp") or die("Can't open $evalTreeNodeClass.cpp: $!");

    while($switchBuf[-1] =~ /^\s*$/ || $switchBuf[-1] =~ /^\s*break;\s*$/) {
	pop(@switchBuf);
    }

    if(!$evalTreeNodeClass) {
	warn("No tree node class found for iterator '$queryNodeType'\n");
	@switchBuf = ();
	return;
    } else {
	print "Iterator class is $evalTreeNodeClass\n";
    }
    my $evalFileOut = new IO::File;
    system("mkdir -p ../NewIterators/$evalTreeNodeClass");
    $evalFileOut->open("> ../NewIterators/$evalTreeNodeClass/process.cpp") or die("Can't open process.cpp: $!");

    
    print $evalFileOut qq(#include "../EvaluatorClass.h"\n\n);
    print $evalFileOut qq(#include "QueryEvaluationTree${evalTreeNodeClass}Node.h"\n\n);
    #print("cp ../QueryEvaluationTree/QueryEvaluationTree${evalTreeNodeClass}Node.h ../../NewIterators/$evalTreeNodeClass\n");
    #system("cp ../QueryEvaluationTree/QueryEvaluationTree${evalTreeNodeClass}Node.h ../../NewIterators/$evalTreeNodeClass");
    #system("cp ../QueryEvaluationTree/QueryEvaluationTree${evalTreeNodeClass}Node.cpp ../../NewIterators/$evalTreeNodeClass");
    foreach my $include (@includes) {
	print $evalFileOut qq(#include "$include.h"\n);
	#my $filepath = `find .. -name $include.h`;
	#chomp($filepath);
	#print("cp $filepath ../../NewIterators/$evalTreeNodeClass\n");
	#system("cp $filepath ../../NewIterators/$evalTreeNodeClass");
	#$filepath = `find .. -name $include.cpp`;
	#chomp($filepath);
	#print("cp $filepath ../../NewIterators/$evalTreeNodeClass\n");
	#system("cp $filepath ../../NewIterators/$evalTreeNodeClass");
    }
    print $evalFileOut qq(#include "extra.h"\n\n);

    print $evalFileOut "void processQueryEvalNode(EvaluatorClass* evaluator, QueryEvaluationTreeNode* node, IteratorClass*& curr)\n";
    print $evalFileOut join("\n",@switchBuf);
    print $evalFileOut "\n\n";
    $evalFileOut->close();
    #$evalFile->close();
}

sub dumpParseTreeNode {
    my $evalFile = new IO::File;
    #$evalFile->open("< ../QueryEvaluationTree/$evalTreeNodeClass.cpp") or die("Can't open $evalTreeNodeClass.cpp: $!");

    while($switchBuf[-1] =~ /^\s*$/ || $switchBuf[-1] =~ /^\s*break;\s*$/) {
	pop(@switchBuf);
    }

    if(!$evalTreeNodeClass) {
	warn("No tree node class found for iterator '$evalTreeChar'\n");
	@switchBuf = ();
	return;
    } else {
	print "Iterator class is $evalTreeNodeClass\n";
    }
    my $evalFileOut = new IO::File;
    system("mkdir -p ../NewIterators/$evalTreeNodeClass");
    $evalFileOut->open("> ../NewIterators/$evalTreeNodeClass/parse.cpp") or die("Can't open parse.cpp: $!");

    print $evalFileOut qq(#include "../EvaluatorClass.h"\n\n);
    print $evalFileOut qq(#include "extra.h"\n\n);
    print $evalFileOut "char getIteratorIdentifier(void) { return '$evalTreeChar'; }\n\n";

    print $evalFileOut "void getQueryEvalNode(EvaluatorClass* evaluator, char* line, void* queryInput, QueryEvaluationTreeNode*& curr)\n";
    print $evalFileOut join("\n",@switchBuf);
    print $evalFileOut "\n\n";
    
    $evalFileOut->close();
    #$evalFile->close();
}
