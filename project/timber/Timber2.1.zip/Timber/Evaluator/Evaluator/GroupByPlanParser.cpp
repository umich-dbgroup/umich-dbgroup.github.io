#ifdef COMPILE_ME
#include "GroupByPlanParser.hpp"
#include "QueryEvaluationTreeGroupByNode.h"
#include "IndexMng_definitions.h"
#include "EvaluatorClass.h"


namespace Timber
{

GroupByPlanParser::GroupByPlanParser()
{
	initState() ;
}

GroupByPlanParser::~GroupByPlanParser()
{
	cleanupState() ;
}

void
GroupByPlanParser::initState()
{
	cleanupState() ;
	groupbyAttrName = NULL ;
	operation = NULL ;
	onWhat = NULL ;
	attrName = NULL ;
	nre = NULL ;
	operationNRE = NULL ;
}

void
GroupByPlanParser::error(int line, char *msg)
{
	globalErrorInfo.insertProblem(ERR_TYPE_ERROR,line,"Evaluator",__FILE__,msg);
	cleanupState() ;
}

void
GroupByPlanParser::cleanupState()
{
	if (groupbyAttrName) delete [] groupbyAttrName;
	if (operation) delete [] operation;
	if (onWhat) delete [] onWhat;
	if (attrName)
	{
		for (int j=0; j<i; j++)
			if (attrName) delete [] attrName;
		delete [] attrName;
	}
	if (nre) delete [] nre;
	if (operationNRE) delete [] operationNRE; 
}

#define DO_ERROR(msg) {error(__LINE__, msg) ; return NULL ; }

QueryEvaluationTreeNode *
GroupByPlanParser::parseline(char *line)
{
	QueryEvaluationTreeNode *curr ;
	char *token = strtok(line+2,",");                    
	if (token == NULL)
	{
		DO_ERROR("Error input from file... expecting estimated Size... group by line...");
	}
	int size = atoi(token);
	token = strtok(NULL,",");
	if (token == NULL)
	{
		DO_ERROR("Error input from file... expecting groupby what... group by line...");
	}
	int groupByWhat;
	if (strcmp(token,"AN") == 0)
		groupByWhat = GROUPBY_ATTRIBUTE_NUM;
	else if (strcmp(token,"AS") == 0)
		groupByWhat = GROUPBY_ATTRIBUTE_STR;
	else if (strcmp(token,"TN") == 0)
		groupByWhat = GROUPBY_TEXT_NUM;
	else if (strcmp(token,"TS") == 0)
		groupByWhat = GROUPBY_TEXT_STR;
	else if (strcmp(token,"SK") == 0)
		groupByWhat = GROUPBY_STARTKEY;
	else if (strcmp(token,"VN") == 0)
		groupByWhat = GROUPBY_VALUE_NUM;
	else if (strcmp(token,"VS") == 0)
		groupByWhat = GROUPBY_VALUE_STR;
	else
	{
		DO_ERROR("Error input from file... unrecognized groupby what... group by line...");
	}

	token = strtok(NULL,",");
	if (token == NULL)
	{
		DO_ERROR("Error input from file... expecting group by nre... group by line...");
	}
	NREType groupbyNRE = (NREType)atoi(token);
	if (groupbyNRE < 1)
	{
		DO_ERROR("NRE should be positive.");
	}
	if (groupbyNRE > EvaluatorClass::getMaxNRE())
		EvaluatorClass::setMaxNRE(groupbyNRE);

	token = strtok(NULL,",");
	if (token == NULL)
	{
		DO_ERROR("Error input from file... expecting group by attr name... group by line...");
	}
	groupbyAttrName = new char[strlen(token)+1];
	strcpy(groupbyAttrName,token);

	token = strtok(NULL,",");
	if (token == NULL)
	{
		DO_ERROR("Error input from file... expecting boolean keepTrees value... group by line...");
	}

	if (atoi(token) != 0 && atoi(token) != 1)
	{
		DO_ERROR("Error input from file... keep trees should be 0 or 1... group by line...");
	}
	bool keepTrees = (bool)atoi(token);

	token = strtok(NULL,",");
	if (token == NULL)
	{
		DO_ERROR("Error input from file... expecting num of operations... group by line...");
	}
	int num = atoi(token);

	if (num > 0)
	{
		operation = new int[num];
		onWhat = new int[num];
		attrName = new char *[num];
		nre = new NREType[num];
		operationNRE = new NREType[num];
	}
	else
	{
		operation = NULL;
		onWhat = NULL;
		attrName = NULL;
		nre = NULL;
		operationNRE = NULL;
	}

	for (int i=0; i<num; i++)
	{
		token = strtok(NULL,",");
		if (token == NULL)
		{
			DO_ERROR("Error input from file... expecting operation... group by line...");
		}

		if (strcmp(token,"C") == 0)
			operation[i] = OP_COUNT;
		else if (strcmp(token,"A") == 0)
			operation[i] = OP_AVG;
		else if (strcmp(token,"S") == 0)
			operation[i] = OP_SUM;
		else if (strcmp(token,"M") == 0)
			operation[i] = OP_MAX;
		else if (strcmp(token,"m") == 0)
			operation[i] = OP_MIN;
		else 
		{
			DO_ERROR("Error input from file... unrecognized operation... group by line...");
		}

		token = strtok(NULL,",");
		if (token == NULL)
		{
			DO_ERROR("Error input from file... expecting oper on what... group by line...");
		}

		if (strcmp(token,"A") == 0)
			onWhat[i] = ON_ATTRIBUTE_NUM;
		else if (strcmp(token,"LA") == 0) onWhat[i] = ON_ATTR_LOCAL_NUM;
		else if (strcmp(token,"T") == 0)
			onWhat[i] = ON_TEXT_NUM;
		else if (strcmp(token,"LT") == 0)
			onWhat[i] = ON_TEXT_LOCAL_NUM;
		else if (strcmp(token,"LF") == 0)
			onWhat[i] = ON_FANOUT_LOCAL;
		else if (strcmp(token,"AF") == 0)
			onWhat[i] = ON_FANOUT_ACTUAL;
		else if (strcmp(token,"LD") == 0)
			onWhat[i] = ON_DEPTH_LOCAL;
		else if (strcmp(token,"AD") == 0)
			onWhat[i] = ON_DEPTH_ACTUAL;
		else if (strcmp(token,"V") == 0)
			onWhat[i] = ON_VALUE_NUM;
		else
		{
			DO_ERROR("Error input from file... unrecognized operation on what... group by line...");
		}
		token = strtok(NULL,",");
		if (token == NULL)
		{
			DO_ERROR("Error input from file... expecting attrName... group by line...");
		}
		attrName[i] = new char[strlen(token)+1];
		strcpy(attrName[i],token);
		token = strtok(NULL,",");
		if (token == NULL)
		{
			DO_ERROR("Error input from file... expecting nre... group by line...");
		}
		nre[i] = atoi(token);
		if (nre[i] < 1)
		{
			DO_ERROR("NRE should be positive.");
		}
		if (nre[i] > EvaluatorClass::getMaxNRE())
			EvaluatorClass::setMaxNRE(nre[i]);
		token = strtok(NULL,",");
		if (token == NULL)
		{
			DO_ERROR("Error input from file... expecting operation nre... group by line...");
		}

		operationNRE[i] = atoi(token);
		if (operationNRE[i] < 1)
		{
			DO_ERROR("NRE should be positive.");
		}
		if (operationNRE[i] > EvaluatorClass::getMaxNRE())
			EvaluatorClass::setMaxNRE(operationNRE[i]);
	}
	token = strtok(NULL,",");
	if (token == NULL)
	{
		DO_ERROR("Error input from file... expecting root nre... group by line...");
	}
	NREType rootNRE = (NREType)atoi(token);

	if (rootNRE < 1)
	{
		DO_ERROR("NRE should be positive.");
	}
	if (rootNRE > EvaluatorClass::getMaxNRE())
		EvaluatorClass::setMaxNRE(rootNRE);
	token = strtok(NULL,",");
	if (token == NULL)
	{
		DO_ERROR("Error input from file... expecting value nre... group by line...");
	}
	NREType valueNRE = (NREType)atoi(token);
	if (valueNRE < 1)
	{
		DO_ERROR("NRE should be positive.");
	}
	if (valueNRE > EvaluatorClass::getMaxNRE())
		EvaluatorClass::setMaxNRE(valueNRE);

	token = strtok(NULL,",");
	if (token == NULL)
	{
		DO_ERROR("Error input from file... expecting sort bool... group by line...");
	}
	if (atoi(token) != 0 && atoi(token) != 1)
	{
		DO_ERROR("Error input from file... sort should be 0 or 1... group by line...");
	}
	bool sort = (bool) atoi(token);
	char newLine[MAX_FILE_INTERFACE_LINE_SIZE];
	if (((std::iostream *)queryInput)->eof() == 0)
		((std::iostream *)queryInput)->getline(newLine,MAX_FILE_INTERFACE_LINE_SIZE);
	else
	{
		DO_ERROR("Unexpected end of file... group by line...");
	}
	QueryEvaluationTreeNode *oper = getQueryEvalNode(newLine,queryInput);
	if (oper == NULL)
	{
		DO_ERROR("Unexpected operand1 returned... group by line...");
	}
	curr = new QueryEvaluationTreeGroupByNode(oper,size,groupByWhat,groupbyNRE,groupbyAttrName,num,operation,onWhat,attrName,nre,rootNRE,valueNRE,operationNRE,sort,keepTrees);
	return curr ;
}

} // namespace Timber
#endif

