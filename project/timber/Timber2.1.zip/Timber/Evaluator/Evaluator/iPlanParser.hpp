
#ifndef __iPlanParser_include_
#define __iPlanParser_include_

#include "QueryEvaluationTreeNode.h"

namespace Timber
{

class iPlanParser
{
public:
	iPlanParser() {} ;
	virtual ~iPlanParser() {} ;

	virtual QueryEvaluationTreeNode *parseline(char *line) = 0 ;
	
} ; // class iPlanParser

} ; // namespace Timber

#endif // __iPlanParser_include_
