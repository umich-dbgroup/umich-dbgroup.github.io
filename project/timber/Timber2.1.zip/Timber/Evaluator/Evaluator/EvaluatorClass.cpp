/*
   COPYRIGHT  ?2000-2004 
   THE REGENTS OF THE UNIVERSITY OF MICHIGAN
   ALL RIGHTS RESERVED

   PERMISSION IS GRANTED TO USE, COPY, CREATE DERIVATIVE WORKS AND REDISTRIBUTE THIS SOFTWARE AND SUCH DERIVATIVE WORKS FOR 
   NONCOMMERCIAL EDUCATION AND RESEARCH PURPOSES, SO LONG AS NO FEE IS CHARGED, AND SO LONG AS THE COPYRIGHT NOTICE ABOVE, 
   THIS GRANT OF PERMISSION, AND THE DISCLAIMER BELOW APPEAR IN ALL COPIES MADE; AND SO LONG AS THE NAME OF THE UNIVERSITY 
   OF MICHIGAN IS NOT USED IN ANY ADVERTISING OR PUBLICITY PERTAINING TO THE USE OR DISTRIBUTION OF THIS SOFTWARE WITHOUT 
   SPECIFIC, WRITTEN PRIOR AUTHORIZATION.

   THIS SOFTWARE IS PROVIDED AS IS, WITHOUT REPRESENTATION FROM THE UNIVERSITY OF MICHIGAN AS TO ITS FITNESS FOR ANY PURPOSE, 
   AND WITHOUT WARRANTY BY THE UNIVERSITY OF MICHIGAN OF ANY KIND, EITHER EXPRESS OR IMPLIED, INCLUDING WITHOUT LIMITATION THE 
   IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE. THE REGENTS OF THE UNIVERSITY OF MICHIGAN SHALL 
   NOT BE LIABLE FOR ANY DAMAGES, INCLUDING SPECIAL, INDIRECT, INCIDENTAL, OR CONSEQUENTIAL DAMAGES, WITH RESPECT TO ANY CLAIM 
   ARISING OUT OF OR IN CONNECTION WITH THE USE OF THE SOFTWARE, EVEN IF IT HAS BEEN OR IS HEREAFTER ADVISED OF THE POSSIBILITY 
   OF SUCH DAMAGES.
   */


/**
 * This class is the Timber's query evaluator. Currently, this class reads its query plan tree from 
 * a text file. 
 * @author Shurug Al-Khalifa    
 * @version 1.0
 */

#include "EvaluatorClass.h"
#include "../Common/ShoreList.h"

int globalNRETableCapacity;
int globalTemp;
//#include "../IndexAccesses/HashIndexAccess.h"
//ErrorInfoClass globalErrorInfo;
#include <fstream>
#include <sstream>
#include <string>
#include <vector>

using namespace std;

EvaluatorClass *gEvaluator;
FileIDType gFileID;
vector< pair<int, string> > gUpdatesArray;

//bool gUseTagIdIndex = false;
#ifdef EVAL_TIME_OUT
clock_t gQueryStartTime;
int gTimeOutAfter;
#endif


//FILE *shoreIDsFile;
// evaluator's static members
int EvaluatorClass::openFilesCount;
FileIDType EvaluatorClass::openFiles[MAX_FILENUMER];
char EvaluatorClass::openFilesNames[MAX_XMLFILE_NAME_LENGTH][MAX_FILENUMER];
bool EvaluatorClass::plugins_loaded = false;
fcn_map_t EvaluatorClass::iterator_parsers;


#ifdef LINUX
int EvaluatorClass::loadPlugin(const char* filename, lt_ptr data) {
    idfuncptr_t getIteratorIdentifier = NULL;
    parsefuncptr_t parsefunc = NULL;
    lt_dlhandle handle;
    const char* error;
    handle = lt_dlopenext(filename);

    if (!handle) {
	fprintf (stderr, "%s\n", lt_dlerror());
	exit(1);
    }

    lt_dlerror();    /* Clear any existing error */
    getIteratorIdentifier = (idfuncptr_t) lt_dlsym(handle, "getIteratorIdentifier");
    if ((error = lt_dlerror()) != NULL)  {
	fprintf (stderr, "%s\n", error);
	exit(1);
    }

    parsefunc = (parsefuncptr_t) lt_dlsym(handle, "getQueryEvalNode");
    if ((error = lt_dlerror()) != NULL)  {
	fprintf (stderr, "%s\n", error);
	exit(1);
    }
    iterator_parsers[(*getIteratorIdentifier)()] =parsefunc;

    printf ("Loaded plugin '%s': type '%c'\n", filename, (*getIteratorIdentifier)());
    return 0;
}

void EvaluatorClass::loadPlugins() {

    const char* plugin_dir = gSettings->getStringValue("PLUGIN_DIRECTORY","../iterators").c_str();
    const char* error;

    lt_dlinit();
    if ((error = lt_dlerror()) != NULL)  {
	fprintf (stderr, "%s\n", error);
	exit(1);
    }
    lt_dlforeachfile(plugin_dir,loadPlugin,NULL);

}
#endif


/*********************
 * Constructs & Misc *
 *********************/
EvaluatorClass::EvaluatorClass(DataMng *dataMng, IndexMng *indexMng)
{
    this->dataMng = dataMng;

    this->indexMng = indexMng;
    if(!EvaluatorClass::plugins_loaded) {

#ifdef WIN32

	iteratorLoad() ;

#else
	loadPlugins();

#endif
	plugins_loaded = true;
    }

    xmlOutput = NULL;
    openFilesCount = 0;
    constructOutput = true;

    // added by Melanie
    this->capacityChoice = -1;
    this->capacity = -1;
    this->replacementChoice = -1;
    this->replacementPercentage = -1;
    globalNRETableCapacity = NRE_TABLE_DEFAULT_CAPACITY;

    updatesCursor = 0;

#ifdef EVAL_TIME_OUT
    gTimeOutAfter = gSettings->getIntegerValue("EVAL_TIME_OUT_AFTER",DEFAULT_TIME_OUT);
#endif
    ShoreList::tempBuf = new char[gSettings->getIntegerValue("CONTAINER_SIZE",CONTAINER_SIZE_DEFAULT) + sizeof(serial_t) + 5];
    fileIDsArray = NULL;
    fileIDsArraySize = 0;

    //globalTemp = 0;
    //shoreIDsFile = fopen("shoreIDs.txt","w");
}

EvaluatorClass::~EvaluatorClass()
{
    if (xmlOutput)
	delete [] xmlOutput;

    delete [] ShoreList::tempBuf;
    if (this->fileIDsArray)
	delete [] fileIDsArray;
    gUpdatesArray.clear();

    //	cout<<"num shore writes:"<<globalTemp<<endl;
    //	fclose(shoreIDsFile);
}

IndexMng *EvaluatorClass::getIndexMng()
{
    return this->indexMng;
}



//todo: Yunyao: add hack to query input here
/*****************************
 * Query Tree Methods        *
 *****************************/
QueryEvaluationTree *EvaluatorClass::getQueryEvalTree(void *queryInput)
{
    char line[MAX_FILE_INTERFACE_LINE_SIZE];
    QueryEvaluationTree *tree = NULL;
    this->maxNRE = 1;
    this->fileIDsArraySize = 0;
    //	gNumUpdates = 0;

    if (((std::iostream *)queryInput)->eof() == 0)
    {

	((std::iostream *)queryInput)->getline(line,MAX_FILE_INTERFACE_LINE_SIZE);
	tree = NULL;

	gUpdatesArray.clear();
	tree = new QueryEvaluationTree(getQueryEvalNode(line,queryInput));
	globalNRETableCapacity = maxNRE + 1;

    }
    return tree;

}

QueryEvaluationTree *EvaluatorClass::getTreeFromFile(char *fullPathFileName)
{
    std::fstream queryFile;
    queryFile.open(fullPathFileName, std::ios::in);
    // FILE *queryFile = fopen(fullPathFileName,"r");
    if (queryFile.is_open() == 0)
    {
	ostringstream oss;
	oss << "File " << fullPathFileName << " could not be opened";
	globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"Evaluator",__FILE__,oss.str().c_str());
	this->closeFiles(dataMng);
	return NULL;              
    }
    QueryEvaluationTree *qtree = getQueryEvalTree(&queryFile);
    queryFile.close();
    return qtree;
}


    void
EvaluatorClass::TransformString(char *str)
{
    static bool gotSettings = false ;
    static bool case_insensitive = false ;

    if (! gotSettings)
    {
	case_insensitive = gSettings->getBooleanValue("INDEX_CASE_INSENSITIVE",false) ;
	gotSettings = true ;
    }

    if (! str)
    {
	return ;
    }

    if (case_insensitive)
    {
	str = _strlwr(str) ;
    }
}

QueryEvaluationTreeNode *EvaluatorClass::getQueryEvalNode(char *line, void *queryInput)
{
    QueryEvaluationTreeNode *curr = NULL;
    while (line[0] == '*')
    {
	if (((std::iostream *)queryInput)->eof() == 0)
	    ((std::iostream *)queryInput)->getline(line,MAX_FILE_INTERFACE_LINE_SIZE);
	else
	    return NULL;
    }

    // call parse from appropriate plugin using line[0]
    (*iterator_parsers[line[0]])(this,line,queryInput,curr);

    return curr;
}


IteratorClass *EvaluatorClass::getExecTree(QueryEvaluationTree *evalTree)
{
    updatesCursor = 0;
    if (!evalTree)
    {
	globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"Evaluator",__FILE__,"Evaluation Tree is NULL.");
	return NULL;
    }
    QueryEvaluationTreeNode *root = evalTree->getRoot();
    if (root == NULL)
	return NULL;

    if (createShoreFiles() == FAILURE)
    {
	cout << "createShoreFiles() == FAILURE" << endl;
	return NULL;
    }

    return processQueryEvalNode(root);
}

IteratorClass *EvaluatorClass::processQueryEvalNode(QueryEvaluationTreeNode *node) {
    IteratorClass* curr = NULL;
    node->processQueryEvalNode(this,curr);
    return curr;
}

/*****************************
 * Query Evaluation Method   *
 *****************************/
double EvaluatorClass::runQuery(char *query, int *count)
{
    *count = -1;
    dataMng->beginTransaction();
    clock_t starttime, finishtime;   
    double  duration;
    fileid = gFileID;
    globalErrorInfo.reset();
    std::stringstream queryStream(string(query,strlen(query)));

    QueryEvaluationTree *qtree = this->getQueryEvalTree(&queryStream);
    if (qtree == NULL || qtree->getRoot() == NULL)
    {
	this->closeFiles(dataMng);
	dataMng->abortTransaction();
	if (this->xmlOutput)
	{
	    delete [] xmlOutput; 
	    xmlOutput = NULL;
	}
	return -1;
    }
#ifdef EVAL_TIME_OUT
    gQueryStartTime = clock();
#endif
    starttime = clock();
    IteratorClass *iter = this->getExecTree(qtree);
    if (iter == NULL)
    {
	qtree->getRoot()->deleteStructures();
	delete qtree;
	this->closeFiles(dataMng);
	dataMng->abortTransaction();
	if (this->xmlOutput)
	{
	    delete [] xmlOutput; 
	    xmlOutput = NULL;
	}
	return -1;
    }

    WitnessTree *res;
    int c = 0;
    if (!this->xmlOutput)
    {
	xmlOutput = new char[gSettings->getIntegerValue("INITIAL_OUTPUT_SIZE_WHOLE",10000)];
	xmlOutputBufferSz = gSettings->getIntegerValue("INITIAL_OUTPUT_SIZE_WHOLE",10000);
    }

    //xmlOutputPtr = xmlOutput;
    curXmlSize = 0;
    //xmlOutputPtr[0] = '\0';
    xmlOutput[0] = '\0';

    //	strcpy(ltStr,"&lt;");
    //	strcpy(gtStr,"&gt;");
    strcpy(ltStr,"<");
    strcpy(gtStr,">");
    int lastAdded = 0;
    bool updatesPerformed = false;
    /*	if (qtree->getRoot()->getQueryEvaluationTreeNodeType() == EVALUATION_OP_UPDATES ||
	(qtree->getRoot()->getQueryEvaluationTreeNodeType() == EVALUATION_OP_CONSTRUCT
	&& ((QueryEvaluationTreeConstructNode *)qtree->getRoot())->getOperand()->getQueryEvaluationTreeNodeType() == EVALUATION_OP_UPDATES))
	updatesPerformed = true;*/
    if (gUpdatesArray.size() > 0)
	updatesPerformed = true;
    if (this->constructOutput && !updatesPerformed)
    {
	copyToXMLOutput(ltStr);
	copyToXMLOutput("results");
	copyToXMLOutput(gtStr);
	copyToXMLOutput("\n");
	lastAdded = LAST_ADDED_FIRST_START_TAG;
    }

    iter->next(res);
    while (res)
    {
	if (this->constructOutput && !updatesPerformed)
	{
	    res->switchToComplex(dataMng);
	    int len;
	    int r;
	    r = appendTreeToResult(res,0,1,len,lastAdded);
	    while (r != FAILURE && len < res->length())
		r = appendTreeToResult(res,len,1,len,lastAdded);
	}
	c++;
	iter->next(res);
    }

    finishtime = clock();
    if (globalErrorInfo.doWeHaveAProblem())
    {
	delete qtree;
	delete iter;

	this->closeFiles(dataMng);
	dataMng->abortTransaction();
	if (this->xmlOutput)
	{
	    delete [] xmlOutput; 
	    xmlOutput = NULL;
	}
	return -1;
    }
    if (this->constructOutput && !updatesPerformed)
    {
	copyToXMLOutput(ltStr);
	copyToXMLOutput("/results");
	copyToXMLOutput(gtStr);
	copyToXMLOutput("\n");
    }

    for (unsigned int i = 0; i < gUpdatesArray.size(); i++) {
	int updatesOfThisType = gUpdatesArray.at(i).first;
	string updateType = gUpdatesArray.at(i).second;
	string s = (updatesOfThisType!=1)?"s":""; //make the phrase plural for 0 and >= 1 updates :)

	ostringstream oss;
	oss << "Update " << i+1 << ": " << updatesOfThisType << " " << updateType << s << "." << endl;
	//cout << "Update " << i+1 << ": " << updatesOfThisType << " " << updateType << s << "." << endl;
	copyToXMLOutput(oss.str().c_str());
    }
    duration = (double)(finishtime - starttime) / CLOCKS_PER_SEC;
    delete qtree;
    delete iter;

    this->closeFiles(dataMng);
    dataMng->endTransaction();
    *count = c;
    return duration;
}

void EvaluatorClass::runQueryNL(char * fileName, char actualTerm[][100], int &numMatchedTerm, bool printOutput)
{
    bool oldFashioned = false;
    clock_t starttime, finishtime;   
    int count = 0;

    this->capacity = -1;
    this->replacementChoice = REPLACEMENT_POLICY_LRU;
    this->replacementPercentage = (float)0.3;

    QueryEvaluationTree *qtree = NULL;
    dataMng->beginTransaction();

    qtree = this->getTreeFromFile(fileName);

    if (qtree == NULL || qtree->getRoot() == NULL)
    {
	this->closeFiles(dataMng);
	dataMng->abortTransaction();
	if (this->xmlOutput)
	{
	    delete [] xmlOutput; 
	    xmlOutput = NULL;
	}
	return;
    }

#ifdef EVAL_TIME_OUT
    gQueryStartTime = clock();
#endif
    starttime = clock();
    IteratorClass *iter = this->getExecTree(qtree);
    if (!iter)
    {
	qtree->getRoot()->deleteStructures();
	if (qtree) delete qtree;
	globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"Evaluator",__FILE__,"Execution tree is NULL.");
	this->closeFiles(dataMng);
	dataMng->abortTransaction();
	if (globalErrorInfo.doWeHaveAProblem() == true) globalErrorInfo.displayError();
	if (globalErrorInfo.doWeHaveAWarn() == true) globalErrorInfo.displayWarn();
	return;
    }

    if (!this->xmlOutput)
    {
	xmlOutput = new char[gSettings->getIntegerValue("INITIAL_OUTPUT_SIZE_WHOLE",10000)];
	xmlOutputBufferSz = gSettings->getIntegerValue("INITIAL_OUTPUT_SIZE_WHOLE",10000);
    }

    iter->next(resultBuffer);

    while (resultBuffer)
    {
	count++;

	if (oldFashioned && printOutput)
	    resultBuffer->dumpBuffer(stdout, true);
	else
	{
	    this->xmlOutput[0] = '\0';
	    curXmlSize = 0;

	    resultBuffer->switchToComplex(dataMng);
	    int r, len, lastAdded = 0;
	    r = this->appendTreeToResult(resultBuffer,0,0,len,lastAdded);
	    while (r != FAILURE && len < resultBuffer->length())
		r = this->appendTreeToResult(resultBuffer,len,0,len,lastAdded);

	    if (printOutput)
	    {
		printf("%s",this->xmlOutput);
	    }
	}

	char *token = strtok(this->xmlOutput,"\n");

	// get only the tag names
	while(token && numMatchedTerm < MAX_SENSE_NUMBER)
	{
	    strcpy(actualTerm[numMatchedTerm++], token);
	    token = strtok(NULL,"\n");
	}

	if (this->xmlOutput)
	    strcpy(this->xmlOutput,"");

	iter->next(resultBuffer);
    }

    if (iter) delete iter;
    finishtime = clock();
    if (qtree) delete qtree;
    this->closeFiles(dataMng);
    dataMng->endTransaction();
}

void EvaluatorClass::runQueryPR(char * filename, int &precision, int &recall)
{
    int count = 0;
    clock_t starttime, finishtime;   

    this->capacity = -1;
    this->replacementChoice = REPLACEMENT_POLICY_LRU;
    this->replacementPercentage = (float)0.3;

    QueryEvaluationTree *qtree = NULL;
    dataMng->beginTransaction();

    qtree = this->getTreeFromFile(filename);

    if (qtree == NULL || qtree->getRoot() == NULL)
    {
	this->closeFiles(dataMng);
	dataMng->abortTransaction();
	if (this->xmlOutput)
	{
	    delete [] xmlOutput; 
	    xmlOutput = NULL;
	}
	return;
    }

#ifdef EVAL_TIME_OUT
    gQueryStartTime = clock();
#endif
    starttime = clock();
    IteratorClass *iter = this->getExecTree(qtree);
    if (!iter)
    {
	qtree->getRoot()->deleteStructures();
	if (qtree) delete qtree;
	globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"Evaluator",__FILE__,"Execution tree is NULL.");
	this->closeFiles(dataMng);
	dataMng->abortTransaction();
	if (globalErrorInfo.doWeHaveAProblem() == true) globalErrorInfo.displayError();
	if (globalErrorInfo.doWeHaveAWarn() == true) globalErrorInfo.displayWarn();
	return;
    }

    if (!this->xmlOutput)
    {
	xmlOutput = new char[gSettings->getIntegerValue("INITIAL_OUTPUT_SIZE_WHOLE",10000)];
	xmlOutputBufferSz = gSettings->getIntegerValue("INITIAL_OUTPUT_SIZE_WHOLE",10000);
    }

    iter->next(resultBuffer);

    while (resultBuffer)
    {
	count++;

	this->xmlOutput[0] = '\0';
	curXmlSize = 0;

	resultBuffer->switchToComplex(dataMng);
	int r, len, lastAdded = 0;
	r = this->appendTreeToResult(resultBuffer,0,0,len,lastAdded);
	while (r != FAILURE && len < resultBuffer->length())
	    r = this->appendTreeToResult(resultBuffer,len,0,len,lastAdded);

	char *token = strtok(this->xmlOutput,"\n");

	// get precision and recall
	if (count == 1)
	{		
	    precision = atoi(token);
	}
	else if (count == 2)
	{
	    recall = atoi(token);
	}

	if (this->xmlOutput)
	    strcpy(this->xmlOutput,"");

	iter->next(resultBuffer);
    }

    if (iter) delete iter;
    finishtime = clock();
    if (qtree) delete qtree;
    this->closeFiles(dataMng);
    dataMng->endTransaction();
}

/*****************************
 * XML Output Methods        *
 *****************************/

int EvaluatorClass::appendTreeToResult(WitnessTree *in, int index, int numTabs, int &length, int &lastAdded)
{
    if (in->length() == 0)
	return FAILURE;
    short i;
    length = index + 1;
    ComplexListNode *n = (ComplexListNode *)in->getNodeByIndex(index);

    if (n->GetStartPos()  == -1 && !(n->IsDummy()))
	return 0;

    if (!n)
	return FAILURE;

    char temp[500];

    if (n->IsDummy())
    {
	if (n->GetDummyName()[0] == '@')
	{	
	    //if (strlen(xmlOutput) >= 2)
	    if (curXmlSize >= 2)
	    {
		removeLastChars(strlen(gtStr)+1);
		copyToXMLOutput(" ");
		copyToXMLOutput(n->GetDummyName()+1);
		copyToXMLOutput(gtStr);
		copyToXMLOutput("\n");
		lastAdded = LAST_ADDED_ATTR;
		return 0;
	    }
	    else
	    {
		copyToXMLOutput(n->GetDummyName()+1);
		copyToXMLOutput("\n");
		lastAdded = LAST_ADDED_ATTR;
		return 0;
	    }
	}
	else 
	{	
	    if (n->GetDummyName()[0]== '<')
	    { //element
		memset(temp,'\t',numTabs);
		temp[numTabs] = '\0';
		copyToXMLOutput(temp);
		copyToXMLOutput(ltStr);
		copyToXMLOutput(n->GetDummyName()+1,strlen(n->GetDummyName()) - 2);
		copyToXMLOutput(gtStr);
		copyToXMLOutput("\n");
		if (index == 0 && in->getScore() > -1)
		{
		    sprintf(temp," score=\"%0.3lf\"%s\n",in->getScore(),gtStr);
		    copyToXMLOutput(temp);
		    removeLastChars(strlen(gtStr)+1);
		    copyToXMLOutput(temp);
		}
		lastAdded = LAST_ADDED_START_TAG;
	    }
	    else //text
	    {
		if (curXmlSize == 0)
		    //if (strlen(xmlOutput) == 0)
		{
		    memset(temp,'\t',numTabs);
		    temp[numTabs] = '\0';
		    copyToXMLOutput(temp);
		}
		else
		{
		    if (lastAdded == LAST_ADDED_START_TAG ||
			    lastAdded == LAST_ADDED_ATTR)
			removeLastChars(1);
		    else
		    {
			memset(temp,'\t',numTabs);
			temp[numTabs] = '\0';
			copyToXMLOutput(temp);
		    }
		}
		copyToXMLOutput(n->GetDummyName());

		copyToXMLOutput("\n");
		lastAdded = LAST_ADDED_TEXT;
		return 0;
	    }
	}
    }
    else
    {
	if (n->GetData() == NULL)
	    return FAILURE;

	int flag = n->GetData()->getFlag();
	switch (flag)
	{
	    case ELEMENT_NODE:

		memset(temp,'\t',numTabs);
		temp[numTabs] = '\0';
		copyToXMLOutput(temp);
		sprintf(temp,"%s%s%s\n",ltStr,dataMng->getPhysicalDataMng()->getXMLNameTable()->getNameByCode(n->GetData()->getTag()),gtStr);
		copyToXMLOutput(temp);

		if (index == 0 && in->getScore() > -1)
		{
		    sprintf(temp," score=\"%0.3lf\"%s\n",in->getScore(),gtStr);
		    copyToXMLOutput(temp);
		    removeLastChars(strlen(gtStr)+1);
		    copyToXMLOutput(temp);
		}
		lastAdded = LAST_ADDED_START_TAG;
		break;

	    case ATTRIBUTE_NODE:
		{
		    short attNum = ((DM_AttributeNode *)n->GetData())->getAttributeNumber();
		    if (curXmlSize >= 2) 
			//if (strlen(xmlOutput) >= 2)
		    {
			removeLastChars(strlen(gtStr)+1);
			for (int i=0;i<attNum;i++)
			{
			    //char attrName[MAX_ATTRIBUTE_NAME_LENGTH];
			    char* attrName = NULL;

			    Value *val = ((DM_AttributeNode *)n->GetData())->getAttr(i,attrName);
			    if (val)
			    {
				sprintf(temp," %s=\"%s\"",attrName,val->getStrValue());
				copyToXMLOutput(temp);
			    }
			    else
				return FAILURE;
			}
			copyToXMLOutput(gtStr);
			copyToXMLOutput("\n");
			lastAdded = LAST_ADDED_ATTR;
		    }
		    else
		    {
			for (int i=0;i<attNum;i++)
			{
			    //char attrName[MAX_ATTRIBUTE_NAME_LENGTH];
			    char* attrName = NULL;

			    Value *val = ((DM_AttributeNode *)n->GetData())->getAttr(i,attrName);
			    if (val)
			    {
				sprintf(temp," %s=\"%s\"",attrName,val->getStrValue());
				copyToXMLOutput(temp);
			    }
			    else
				return FAILURE;
			}
			copyToXMLOutput("\n");
			lastAdded = LAST_ADDED_ATTR;
		    }
		}
		return 0;

	    case TEXT_NODE:
	    case DOCUMENT_NODE:
		{
		    if (curXmlSize == 0) 
			//if (strlen(xmlOutput) == 0)
		    {
			memset(temp,'\t',numTabs);
			temp[numTabs] = '\0';
			copyToXMLOutput(temp);
		    }
		    else
		    {
			if (lastAdded == LAST_ADDED_START_TAG ||
				lastAdded == LAST_ADDED_ATTR)
			    removeLastChars(1);
			else
			{
			    memset(temp,'\t',numTabs);
			    temp[numTabs] = '\0';
			    copyToXMLOutput(temp);
			}
		    }
		    if (flag == TEXT_NODE)
			copyToXMLOutput(((DM_CharNode *)n->GetData())->getCharValue());
		    else
			copyToXMLOutput(((DM_DocumentNode *)n->GetData())->getXMLFileName());

		    copyToXMLOutput("\n");
		    lastAdded = LAST_ADDED_TEXT;
		}
		return 0;
	}
    }

    int childNum = 1; 
    int child = in->GetLocalChild(index,childNum,true);
    int returnedSkip = 0;
    while (child != -1)
    {
	returnedSkip++;
	int skip = appendTreeToResult(in,child,numTabs+1,length,lastAdded);
	if (skip == FAILURE)
	    return FAILURE;
	childNum++;
	childNum += skip;
	returnedSkip += skip;
	// child  = in->GetNextLocalSibling(child,true);
	child = in->GetLocalChild(index,childNum,true);
    }

    //if (xmlOutput[strlen(xmlOutput)-1] == '\n')
    if (xmlOutput[curXmlSize-1] == '\n')
    {
	if (lastAdded == LAST_ADDED_END_TAG) 
	{
	    memset(temp,'\t',numTabs);
	    temp[numTabs] = '\0';
	    copyToXMLOutput(temp);
	}
	else
	    removeLastChars(1);
    }


    if (n->IsDummy())
    {
	sprintf(temp,"%s/%s",ltStr,n->GetDummyName()+1);
	copyToXMLOutput(temp, strlen(temp)-1);
	copyToXMLOutput(gtStr);
	copyToXMLOutput("\n");
	lastAdded = LAST_ADDED_END_TAG;
    }
    else
    {
	sprintf(temp,"%s/%s%s\n",ltStr,dataMng->getPhysicalDataMng()->getXMLNameTable()->getNameByCode(n->GetData()->getTag()),gtStr);
	copyToXMLOutput(temp);
	lastAdded = LAST_ADDED_END_TAG;
    }

    return returnedSkip;
}

void EvaluatorClass::copyToXMLOutput(const char *str, int howMany)
{
    if (howMany == -1)
    {
	accomodate(strlen(str));
	strcpy(xmlOutput+curXmlSize,str);
	curXmlSize += strlen(str);
    }
    else
    {
	accomodate(howMany);
	strncpy(xmlOutput+curXmlSize,str,howMany);
	curXmlSize += howMany;
	xmlOutput[curXmlSize] = '\0';
    }
}

void EvaluatorClass::removeLastChars(int howMany)
{
    curXmlSize -= howMany;
    xmlOutput[curXmlSize] = '\0';
}

char *EvaluatorClass::getXMLoutput()
{
    return this->xmlOutput;
}
void EvaluatorClass::accomodate(int howMany)
{
    int size = howMany + curXmlSize;
    size++;
    while (size >= xmlOutputBufferSz)
	this->doubleXMLoutputBuffer();
}
void EvaluatorClass::doubleXMLoutputBuffer()
{
    char *tmp = xmlOutput;
    xmlOutputBufferSz *= 2;
    xmlOutput = new char[xmlOutputBufferSz];
    //memcpy(xmlOutput,tmp,strlen(tmp)+1);
    memcpy(xmlOutput, tmp, curXmlSize+1);
    //xmlOutputPtr = xmlOutput + strlen(xmlOutput);
    delete [] tmp;
}
void EvaluatorClass::increaseSizeOfXMLoutputBuffer(int by)
{
    char *tmp = xmlOutput;
    xmlOutputBufferSz += by;
    xmlOutput = new char[xmlOutputBufferSz];
    //memcpy(xmlOutput,tmp,strlen(tmp)+1);
    memcpy(xmlOutput, tmp, curXmlSize+1);
    //xmlOutputPtr = xmlOutput + strlen(xmlOutput);
    delete [] tmp;
}
void EvaluatorClass::setConstructOutput(bool constructOutput)
{
    this->constructOutput = constructOutput;
}

bool EvaluatorClass::getConstructOutput()
{
    return this->constructOutput;
}


/*****************************
 * File Related Methods      *
 *****************************/

int EvaluatorClass::openFile(char *fileName, DataMng *dataMng, int cpChoice,
	int cp, int rpChoice, float rpRate)
{
    for (int i=0; i<openFilesCount; i++)
	if (strcmp(openFilesNames[i],fileName) == 0)
	    return i;
    if (openFilesCount >= MAX_FILENUMER)
	return -1;
    KeyType rootIndex;

    // medified by Melanie 
    openFiles[openFilesCount] = dataMng->openFile(fileName,&rootIndex,
	    cpChoice, cp, rpChoice, rpRate);

    if (openFiles[openFilesCount] == -1)
	return -1;
    strcpy(openFilesNames[openFilesCount],fileName);
    openFilesCount++;
    return openFilesCount-1;
}

char *EvaluatorClass::getOpenFileName(int openFileIndex)
{
    if (openFileIndex >= openFilesCount || openFileIndex < 0)
	return NULL;
    return openFilesNames[openFileIndex];
}
void EvaluatorClass::closeFiles(DataMng *dataMng, int* size, int* rpTimes)
{
    for (int i=0; i<openFilesCount; i++)
	dataMng->closeFile(openFiles[i], size, rpTimes);
    openFilesCount = 0;
}                        
void EvaluatorClass::setFileID(FileIDType fid)
{
    this->fileid = fid;
}
FileIDType EvaluatorClass::getFileID(int fileIndex)
{
    if (fileIndex >= openFilesCount || fileIndex < 0)
	return -1;
    return openFiles[fileIndex];
}


/*****************************
 * Data Access Method        *
 *****************************/
int EvaluatorClass::findNode(WitnessTree *in, int tag, DataMng *dataMng)
{
    in->switchToComplex(dataMng);
    for (int i=0; i<in->length(); i++)
    {
	FileIDType fileid;
	fileid = getFileID(((ComplexListNode *)in->getNodeByIndex(i))->getFileIndex());
	if (fileid == -1)
	    return FAILURE;
	if (((ComplexListNode *)(in->getNodeByIndex(i)))->GetData() == NULL)
	    return FAILURE;
	if (((ComplexListNode *)in->getNodeByIndex(i))->GetData()->getFlag() != ELEMENT_NODE)
	    continue;

	if (((ComplexListNode *)in->getNodeByIndex(i))->GetData()->getTag() == tag)
	    return i;
    }
    return FAILURE;
}




char *EvaluatorClass::findText(WitnessTree *in, int index, int &newInd)
{
    int s=1;
    int i;
    while ((i=in->GetChild(index, s)) > -1)
    {
	if (!(((ComplexListNode *)(in->getNodeByIndex(i)))->GetData()))
	    return NULL;
	if (((ComplexListNode *)(in->getNodeByIndex(i)))->GetData()->getFlag() == TEXT_NODE)
	{
	    newInd = i;
	    return ((DM_CharNode *)((ComplexListNode *)(in->getNodeByIndex(i)))->GetData())->getCharValue();
	}
	s++;
    }
    return NULL;
}


char *EvaluatorClass::returnText(WitnessTree *in, int index, DataMng *dataMng, FileIDType fid, bool desc)
{

    in->switchToComplex(dataMng);
    ComplexListNode *n1 = (ComplexListNode *)in->getNodeByIndex(index);
    if (n1->IsDummy())
    {
	char *txt = new char[strlen(n1->GetDummyName())+1];
	strcpy(txt,n1->GetDummyName());
	return txt;
    }
    int res;

    char *txt = NULL;
    if (!desc)
    {
	if (findText(in,index,res) == NULL)
	{
	    res= GetText(in,index,dataMng,fid);
	    if (res == 0)
	    {
		txt = new char[1];
		strcpy(txt,"");
		return txt;
	    }
	    else if (res == FAILURE)
		return NULL;

	}

	//getting text
	ComplexListNode *n=(ComplexListNode *)in->getNodeByIndex(res);

	if (n->GetData() == NULL)
	    return NULL;
	txt = new char[strlen(((DM_CharNode *)n->GetData())->getCharValue()) + 1];
	strcpy(txt,((DM_CharNode *)n->GetData())->getCharValue());

	res = in->GetNextSibling(res);
	DM_DataNode *dn;
	while (res != -1)
	{
	    n = (ComplexListNode *)in->getNodeByIndex(res);
	    dn = n->GetData();
	    if (dn == NULL)
	    {
		delete [] txt;
		return NULL;
	    }
	    if (dn->getFlag() == TEXT_NODE)
	    {
		char *tmp = txt;
		txt = new char [strlen(tmp) + strlen(((DM_CharNode *)dn)->getCharValue()) + 1];
		strcpy(txt,tmp);
		strcat(txt,((DM_CharNode *)dn)->getCharValue());
		delete [] tmp;
	    }
	    res = in->GetNextSibling(res);
	}
    }
    else
    {	
	//getting text
	ComplexListNode *n=(ComplexListNode *)in->getNodeByIndex(index);

	if (n->GetData() == NULL)
	    return NULL;
	KeyType sk = n->GetStartPos();
	DM_DataNode *dataNode = dataMng->getChild(fid,sk,0);

	while (dataNode)
	{
	    if (dataNode->getFlag() == ELEMENT_NODE)
	    {
		ComplexListNode child;
		child.SetStartPos(dataNode->getKey());
		WitnessTree tmpTree(LIST_NODE_WITH_DATA);
		tmpTree.appendList(&child,dataMng,1);
		char *retText = returnText(&tmpTree,0,dataMng,fid,desc);
		if (retText)
		{
		    if (txt)
		    {
			char *tmp = txt;
			txt = new char [strlen(tmp) + strlen(retText) + 1];
			strcpy(txt,tmp);
			strcat(txt,retText);
			delete [] tmp;
			delete [] retText;
		    }
		    else
			txt = retText;

		}
	    }
	    else if (dataNode->getFlag() == TEXT_NODE)
	    {
		if (txt)
		{
		    char *tmp = txt;
		    txt = new char [strlen(tmp) + strlen(((DM_CharNode *)dataNode)->getCharValue()) + 1];
		    strcpy(txt,tmp);
		    strcat(txt,((DM_CharNode *)dataNode)->getCharValue());
		    delete [] tmp;
		}
		else
		{
		    txt = new char [strlen(((DM_CharNode *)dataNode)->getCharValue()) + 1];
		    strcpy(txt,((DM_CharNode *)dataNode)->getCharValue());
		}
	    }
	    sk = dataNode->getKey();
	    dataNode = dataMng->getNextSibling(fid,sk);
	}
    }
    return txt;

}


int EvaluatorClass::GetChildren(WitnessTree *in, int index, DataMng *dataMng, FileIDType fid, NREType nre)
{
    DM_DataNode *data_node = dataMng->getChild(fid,((ComplexListNode *)in->getNodeByIndex(index))->GetStartPos(),0,true);
    KeyType parentkey = ((ComplexListNode *)in->getNodeByIndex(index))->GetStartPos(); //Nuwee added 07/28/03
    int firstChild = 0;
    char fileIndex = ((ComplexListNode *)in->getNodeByIndex(index))->getFileIndex();
    bool childrenFound = false;
    while (data_node)
    {
	ComplexListNode node;
	node.SetStartPos(data_node->getKey());
	node.SetEndPos(data_node->getEndKey());
	node.SetLevel(data_node->getLevel());
	node.setNRE(nre);
	//        node.setSkipNode(skipChildren);
	node.setFileIndex(fileIndex);
	//        addDMNode(data_node,&node);
	int i = in->sortedInsertNode((ComplexListNode *)&node,dataMng,index+1);
	if (!childrenFound)
	    firstChild = i;
	index++;
	childrenFound = true;
	//Nuwee changed interface 07/01/03, need parent key for Multicolor
	data_node = dataMng->getNextSibling(fid,data_node->getKey(),parentkey,true);
    }
    return (childrenFound? firstChild : FAILURE);
}

int EvaluatorClass::GetProvChildren(WitnessTree *in, int index, DataMng *dataMng, FileIDType fid, NREType nre)
{
    DM_DataNode *data_node = dataMng->getChild(fid,((ComplexListNode *)in->getNodeByIndex(index))->GetStartPos(),0,true);
    KeyType parentkey = ((ComplexListNode *)in->getNodeByIndex(index))->GetStartPos(); //Nuwee added 07/28/03
    int firstChild = 0;
    char fileIndex = ((ComplexListNode *)in->getNodeByIndex(index))->getFileIndex();
    bool childrenFound = false;
    int returnindex = -1;
    while (data_node)
    {

	char* tagname = data_node->getTag(dataMng->getPhysicalDataMng()->getXMLNameTable());

	if (tagname != NULL && strcmp(tagname, PROV_TAGNAME) == 0) {

	    ComplexListNode node;
	    node.SetStartPos(data_node->getKey());
	    node.SetEndPos(data_node->getEndKey());
	    node.SetLevel(data_node->getLevel());
	    node.setNRE(nre);
	    //        node.setSkipNode(skipChildren);
	    node.setFileIndex(fileIndex);
	    //        addDMNode(data_node,&node);
	    int i = in->sortedInsertNode((ComplexListNode *)&node,dataMng,index+1);
	    returnindex = i;
	    if (!childrenFound)
		firstChild = i;
	    index++;
	    childrenFound = true;
	    break;
	}
	data_node = dataMng->getNextSibling(fid,data_node->getKey(),parentkey,true);
    }
    return returnindex;
}

int EvaluatorClass::GetChildrenText(WitnessTree *in, int index, DataMng *dataMng, FileIDType fid, NREType nre)
{
    DM_DataNode *data_node = dataMng->getChild(fid,((ComplexListNode *)in->getNodeByIndex(index))->GetStartPos(),0,true);
    //Nuwee added 07/28/03
    KeyType parentkey = ((ComplexListNode *)in->getNodeByIndex(index))->GetStartPos();

    int firstChild = 0;
    char fileIndex = ((ComplexListNode *)in->getNodeByIndex(index))->getFileIndex();
    bool childrenFound = false;
    while (data_node)
    {
	if (data_node->getFlag() == TEXT_NODE)
	{
	    ComplexListNode node;
	    node.SetStartPos(data_node->getKey());
	    node.SetEndPos(data_node->getEndKey());
	    node.SetLevel(data_node->getLevel());
	    node.setNRE(nre);
	    //            node.setSkipNode(skipChildren);
	    node.setFileIndex(fileIndex);
	    int i = in->sortedInsertNode((ComplexListNode *)&node,dataMng,index+1);
	    if (!childrenFound)
		firstChild = i;
	    index++;
	    childrenFound = true;
	}
	//Nuwee changed interface 07/01/03, need parent key for Multicolor
	data_node = dataMng->getNextSibling(fid,data_node->getKey(),parentkey,true);
    }
    return (childrenFound? firstChild : FAILURE);
}

int EvaluatorClass::GetNumChildren(WitnessTree *in, int index, DataMng *dataMng, FileIDType fid)
{
    if (in->isSimple())
	return dataMng->getNumChildren(fid,((ListNode *)in->getNodeByIndex(index))->GetStartPos(),true);
    return dataMng->getNumChildren(fid,((ComplexListNode *)in->getNodeByIndex(index))->GetStartPos(),true);
}

int EvaluatorClass::GetSubtreeDepth(WitnessTree *in, int index, DataMng *dataMng, FileIDType fid)
{
    if (in->isSimple())
	return dataMng->getSubtreeDepth(fid,((ListNode *)in->getNodeByIndex(index))->GetStartPos(),true);
    return dataMng->getSubtreeDepth(fid,((ComplexListNode *)in->getNodeByIndex(index))->GetStartPos(),true);
}


int EvaluatorClass::GetChild(WitnessTree *in, int index, int childIndex, DataMng *dataMng, FileIDType fid, NREType nre)
{
    DM_DataNode *data_node = dataMng->getChild(fid,((ComplexListNode *)in->getNodeByIndex(index))->GetStartPos(),childIndex,true);
    char fileIndex = ((ComplexListNode *)in->getNodeByIndex(index))->getFileIndex();
    if (data_node)
    {
	ComplexListNode node;
	node.SetStartPos(data_node->getKey());
	node.SetEndPos(data_node->getEndKey());
	node.SetLevel(data_node->getLevel());
	node.setFileIndex(fileIndex);
	//        node.setSkipNode(true);
	node.setNRE(nre);
	return in->sortedInsertNode((ComplexListNode *)&node, dataMng,index+1);
    }    
    return FAILURE;

}


int EvaluatorClass::getAncs(WitnessTree *in, int index, int levelsUp, DataMng *dataMng, FileIDType fid, NREType nre)
{
    DM_DataNode *data_node;

    if (levelsUp <= 0)
	return FAILURE;
    int levels = 1;
    // CONG YU: May 27, 2003, NodeIDMap has problems?
    // data_node = dataMng->getParent(fid,((ComplexListNode *)in->getNodeByIndex(index))->GetStartPos(),true);
    data_node = dataMng->getParent(fid,((ComplexListNode *)in->getNodeByIndex(index))->GetStartPos(),true);
    char fileIndex = ((ComplexListNode *)in->getNodeByIndex(index))->getFileIndex();
    while (data_node && levels < levelsUp)
    {
	// dataMng->getNodeMap(fid)->deleteNode(data_node->getKey());
	data_node = dataMng->getParent(fid,data_node->getKey(),true);
	levels++;
    }

    if (data_node)
    {
	ComplexListNode node;
	node.SetStartPos(data_node->getKey());
	node.SetEndPos(data_node->getEndKey());
	node.SetLevel(data_node->getLevel());
	//        node.setSkipNode(true);
	node.setFileIndex(fileIndex);
	node.setNRE(nre);
	return in->sortedInsertNode(&node,dataMng,index+1);
    }
    return FAILURE;
}

void EvaluatorClass::GetAllDesc(WitnessTree *in, int &index, DataMng *dataMng, 
	FileIDType fid, short localLevel, NREType nre)
{
    short l = (short)(localLevel == -1 ? localLevel : localLevel+1);
    GetAttributes(in,index,dataMng,fid,l,nre);
    DM_DataNode *data_node = dataMng->getChild(fid,((ComplexListNode *)in->getNodeByIndex(index))->GetStartPos(),0,true);

    KeyType parentkey = ((ComplexListNode *)in->getNodeByIndex(index))->GetStartPos();//Nuwee added 07/28/03 multicolor

    char fileIndex = ((ComplexListNode *)in->getNodeByIndex(index))->getFileIndex();
    while (data_node)
    {
	ComplexListNode node;
	node.SetStartPos(data_node->getKey());
	node.SetEndPos(data_node->getEndKey());
	node.SetLevel(data_node->getLevel());
	node.setNRE(nre);
	node.SetLocalLevel(l);
	node.setFileIndex(fileIndex);
	int ind = in->sortedInsertNode(&node,dataMng, index+1);

	short lev = l;//(l == -1 ? l : l+1);
	if (data_node->getFlag() == ELEMENT_NODE || data_node->getFlag() == DOCUMENT_NODE)
	    GetAllDesc(in,ind,dataMng,fid,lev,nre);

	//Nuwee changed interface 07/01/03, need parent key for Multicolor
	data_node = dataMng->getNextSibling(fid,data_node->getKey(),parentkey,true);
	if (data_node)
	    index++;
    }
}

void EvaluatorClass::GetAllDescText(WitnessTree *in, int &index, DataMng *dataMng, FileIDType fid, 
	short localLevel, NREType nre)
{
    short l = (short)(localLevel == -1 ? localLevel : localLevel+1);
    DM_DataNode *data_node = dataMng->getChild(fid,((ComplexListNode *)in->getNodeByIndex(index))->GetStartPos(),0,true);

    //Nuwee added 07/28/03
    KeyType parentkey = ((ComplexListNode *)in->getNodeByIndex(index))->GetStartPos();
    char fileIndex = ((ComplexListNode *)in->getNodeByIndex(index))->getFileIndex();
    while (data_node)
    {
	int ind;
	short lev;
	ComplexListNode node;
	node.SetStartPos(data_node->getKey());
	node.SetEndPos(data_node->getEndKey());
	node.SetLevel(data_node->getLevel());
	node.setNRE(nre);
	node.SetLocalLevel(l);
	//        node.setSkipNode(skipDesc);
	node.setFileIndex(fileIndex);
	ind = in->sortedInsertNode(&node, dataMng,index+1);
	int oldInd = ind;
	lev = (short)(l == -1 ? l : l+1);
	if (data_node->getFlag() != TEXT_NODE)
	{
	    GetAllDescText(in,ind,dataMng,fid,lev,nre);
	    in->deleteNode(oldInd);
	}
	//Nuwee changed interface 07/01/03, need parent key for Multicolor
	data_node = dataMng->getNextSibling(fid,data_node->getKey(),parentkey,true);
	if (data_node)
	    index++;
    }
}





int EvaluatorClass::GetAttributes(WitnessTree *in, int index, DataMng *dataMng, FileIDType fid, 
	short localLevel, NREType nre)
{
    in->switchToComplex(dataMng);
    int actualIndex = index;//in->getActualIndex(index);
    if (actualIndex == -1)
	return FAILURE;
    if (in->getNodeByIndex(actualIndex+1))
    {
	if (((ComplexListNode *)in->getNodeByIndex(actualIndex+1))->GetData())
	{
	    if (((ComplexListNode *)in->getNodeByIndex(actualIndex+1))->GetData()->getFlag() == ATTRIBUTE_NODE)
		return SUCCESS;
	}
    }

    // Modified by Cong: to avoid warning message of "getting attributes of a non-element node"
    // it may be less efficient due to the fetching of the data??
    DM_DataNode *data_node = NULL;
    if ( ((ComplexListNode *)in->getNodeByIndex(index))->GetData()->getFlag() == ELEMENT_NODE )
    {
	data_node = dataMng->getAttributes(fid,((ComplexListNode *)in->getNodeByIndex(index))->GetStartPos(),true);
    }
    //data_node = dataMng->getAttributes(fid,((ComplexListNode *)in->getNodeByIndex(index))->GetStartPos(),true);
    char fileIndex = ((ComplexListNode *)in->getNodeByIndex(index))->getFileIndex();
    if (data_node)
    {
	actualIndex = index;//in->getActualIndex(index);
	if (actualIndex == -1)
	    return FAILURE;
	if (in->getNodeByIndex(actualIndex+1) && 
		data_node->getKey() == ((ComplexListNode *)in->getNodeByIndex(actualIndex+1))->GetStartPos())
	{
	    // addDMNode(data_node,(ComplexListNode *)in->getNodeByIndex(actualIndex+1));
	    return SUCCESS;
	}
	ComplexListNode node;
	node.SetStartPos(data_node->getKey());
	node.SetEndPos(data_node->getEndKey());
	node.SetLevel(data_node->getLevel());
	node.SetLocalLevel(localLevel);
	//        node.setSkipNode(skipAttr);
	node.setFileIndex(fileIndex);
	node.setNRE(nre);
	in->insertNode(index+1,&node,dataMng);
	return SUCCESS;
    }
    return FAILURE;

}

int EvaluatorClass::GetText(WitnessTree *in, int index, DataMng *dataMng, FileIDType fid, short localLevel, NREType nre)
{
    int newInd;

    if (findText(in,index,newInd) != NULL)
	return newInd;
    bool textFound = false;
    bool emptyText = true;
    int firstFound = 0;
    DM_DataNode *data_node = dataMng->getChild(fid,((ComplexListNode *)in->getNodeByIndex(index))->GetStartPos(),0,true);

    //Nuwee added 07/28/03
    KeyType parentkey = ((ComplexListNode *)in->getNodeByIndex(index))->GetStartPos();

    char fileIndex = ((ComplexListNode *)in->getNodeByIndex(index))->getFileIndex();
    while (data_node)
    {
	emptyText = false;
	KeyType sk = data_node->getKey();
	if (data_node->getFlag() == TEXT_NODE)
	{
	    ComplexListNode node;
	    node.SetStartPos(data_node->getKey());
	    node.SetEndPos(data_node->getEndKey());
	    node.SetLevel(data_node->getLevel());
	    node.SetLocalLevel(localLevel);
	    //            node.setSkipNode(true);
	    node.setFileIndex(fileIndex);
	    node.setNRE(nre);
	    int i = in->sortedInsertNode(&node, dataMng,index+1);
	    if (!textFound)
		firstFound = i;
	    index++;
	    textFound = true;
	}

	//Nuwee changed interface 07/01/03, need parent key for Multicolor
	data_node = dataMng->getNextSibling(fid,sk,parentkey,true);
    }
    if (emptyText) return 0;
    return (textFound? firstFound : FAILURE);
}


void EvaluatorClass::setBufPara(int cpChoice, int cp, int rpChoice, float rpRate)
{
    this->capacityChoice = cpChoice;
    this->capacity = cp;
    this->replacementChoice = rpChoice;
    this->replacementPercentage = rpRate;
}

int EvaluatorClass::createRecID(serial_t &recID)
{
    /*	rc_t rc = ss_m::create_file(dataMng->getVolumeID(), fileID,ss_m::t_regular);
	if (rc) 
	{
	stringstream msg;
	msg<<rc<<'\0';
	globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"Evaluator",__FILE__,msg.rdbuf()->str().c_str());
	return FAILURE;				
	}*/
    //	cout<<"create file ID: "<<fileID<<endl;
    int maxIDs = gSettings->getIntegerValue("MAX_ID_PER_FILE_EXTERNAL_SORT",1000000);
    rc_t rc = ss_m::create_id(dataMng->getVolumeID(),maxIDs,recID);

    if (rc) 
    {
	stringstream msg;
	msg<<rc<<'\0';
	globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"Evaluator",__FILE__,msg.rdbuf()->str().c_str());	
	return FAILURE;				
    }
    return maxIDs;
}

int EvaluatorClass::createShoreFiles()
{
    this->fileIDsArrayPtr = 0;
    if (this->fileIDsArray)
	delete [] this->fileIDsArray;

    if (this->fileIDsArraySize == 0)
    {
	this->fileIDsArray = NULL;
	return SUCCESS;
    }


    this->fileIDsArray = new serial_t[this->fileIDsArraySize];

    for (int i=0; i<this->fileIDsArraySize; i++)
    {
	rc_t rc = ss_m::create_file(dataMng->getVolumeID(), fileIDsArray[i],ss_m::t_regular);
	if (rc) 
	{
	    stringstream msg;
	    msg<<rc<<'\0';
	    globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"Evaluator",__FILE__,msg.rdbuf()->str().c_str());
	    return FAILURE;				
	}
    }

    return SUCCESS;
}

void EvaluatorClass::getNamesByValue(char * fileToBeLoaded, char * value, char names[][100], int * num, bool stem)
{
    int numMatchedTerm = 0; 
    int size;
    char idxName[100] = "index_";
    char fileName[100] = "temp.qry";
    *num = -1;
    FILE * pFile;

    register char *s = value;

    while(*s != '\0') {
	if(*s >= 'A' && *s <= 'Z')
	    *s += 32;
	s++;
    }

    strcpy(ltStr,"<");
    strcpy(gtStr,">");

    globalErrorInfo.reset();

    dataMng->beginTransaction();

    // choice on stem or not; currect using stemming by default
    strcpy(idxName+6, fileToBeLoaded);
    if (stem)
	strcpy(idxName+6+strlen(fileToBeLoaded)-4, "_invelem_s");
    else
	strcpy(idxName+6+strlen(fileToBeLoaded)-4, "_invelem_n");

    pFile = fopen(fileName, "w+");
    fprintf(pFile, "n,1,%s,%s,%s\n",idxName, fileToBeLoaded, value);
    fflush(pFile);
    fclose(pFile);

    int count = 0;

    QueryEvaluationTree *qtree = NULL;
    qtree = this->getTreeFromFile(fileName);
    if (qtree == NULL)
    {
	globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"Evaluator",__FILE__,"Query tree is NULL.");
	dataMng->abortTransaction();
	if (globalErrorInfo.doWeHaveAProblem() == true) globalErrorInfo.displayError();
	if (globalErrorInfo.doWeHaveAWarn() == true) globalErrorInfo.displayWarn();
	if (this->xmlOutput)
	{	
	    delete [] this->xmlOutput;
	    this->xmlOutput = NULL;
	}
	return;
    }
    if (qtree->getRoot() == NULL)
    {
	delete qtree;
	globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"Evaluator",__FILE__,"Query tree root is NULL.");
	dataMng->abortTransaction();
	if (globalErrorInfo.doWeHaveAProblem() == true) globalErrorInfo.displayError();
	if (globalErrorInfo.doWeHaveAWarn() == true) globalErrorInfo.displayWarn();
	if (this->xmlOutput)
	{	
	    delete [] this->xmlOutput;
	    this->xmlOutput = NULL;
	}
	return;
    }

    IteratorClass *iter = this->getExecTree(qtree);

    if (!iter)
    {
	qtree->getRoot()->deleteStructures();
	delete qtree;
	globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"Evaluator",__FILE__,"Execution tree is NULL.");
	dataMng->abortTransaction();
	if (globalErrorInfo.doWeHaveAProblem() == true) globalErrorInfo.displayError();
	if (globalErrorInfo.doWeHaveAWarn() == true) globalErrorInfo.displayWarn();
	if (this->xmlOutput)
	{	
	    delete [] this->xmlOutput;
	    this->xmlOutput = NULL;
	}
	return;
    }

    WitnessTree *res;

    if (!this->xmlOutput)
    {
	xmlOutput = new char[gSettings->getIntegerValue("INITIAL_OUTPUT_SIZE_WHOLE",10000)];
	xmlOutputBufferSz = gSettings->getIntegerValue("INITIAL_OUTPUT_SIZE_WHOLE",10000);
    }

    iter->next(res);

    while (res)
    {
	count++;
	this->xmlOutput[0] = '\0';
	curXmlSize = 0;

	res->switchToComplex(dataMng);
	int r, len, lastAdded = 0;
	r = this->appendTreeToResult(res,0,0,len,lastAdded);
	while (r != FAILURE && len < res->length())
	    r = this->appendTreeToResult(res,len,0,len,lastAdded);

	char *token = strtok(this->xmlOutput,">");

	// get only the tag names
	if(token)
	{
	    bool skip = false;

	    for (int k = 0; k < numMatchedTerm; k++)
	    {
		if (strcmp(names[k], token + 1) == 0)
		{
		    skip = true;
		    break;
		}
	    }

	    if (!skip)
	    {
		size = strlen(token + 1);
		strcpy(names[numMatchedTerm++], token + 1);
	    }
	}

	if (this->xmlOutput)
	    strcpy(this->xmlOutput,"");

	iter->next(res);
    }  

    *num = numMatchedTerm;

    delete qtree;
    //delete iter;
    this->closeFiles(dataMng);

    dataMng->endTransaction(); 

    if (numMatchedTerm == 0)
    {
	*num = 0;
	cout << endl << "Sorry, there is no *" << value << "* in the chosen database" << endl;
	return;
    }

    return;
}

