
#include "parse.hpp"

char QueryEvaluationTreeMergeTreesNode::getIdentifier(void) { return 'M'; }

char MergeTreesPlanParser::getIteratorIdentifier(void) { return 'M'; }

void 
MergeTreesPlanParser::getQueryEvalNode(EvaluatorClass* evaluator, char* line, void* queryInput, QueryEvaluationTreeNode*& curr)
	    {
		char *token = strtok(line+2,",");
		if (token == NULL)
		{
		    globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"Evaluator",__FILE__,"Error input from file... expecting number of inputs... MergeTrees line...");
		    curr=NULL; return;
		}
		int num = atoi(token);

		QueryEvaluationTreeNode **operands;

		if (num == 0)
		    operands = NULL;
		else
		    operands = new QueryEvaluationTreeNode *[num];

		char newLine[MAX_FILE_INTERFACE_LINE_SIZE];
		for (int i=0; i<num; i++)
		{
		    if (((std::iostream *)queryInput)->eof() == 0)
			((std::iostream *)queryInput)->getline(newLine,MAX_FILE_INTERFACE_LINE_SIZE);
		    else
		    {
			globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"Evaluator",__FILE__,"Unexpected end of file... mergeTrees line...");
			curr=NULL; return;
		    }
		    operands[i] = evaluator->getQueryEvalNode(newLine,queryInput);
		    if (operands[i] == NULL)
		    {
			globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"Evaluator",__FILE__,"Unexpected operand returned... mergeTRees line...");
			curr=NULL; return;
		    }
		}
		curr = new QueryEvaluationTreeMergeTreesNode(operands,num);
	    }

