
#include "parse.hpp"

char QueryEvaluationTreeProvenanceNode::getIdentifier(void) { return 'p'; }

char ProvenancePlanParser::getIteratorIdentifier(void) { return 'p'; }

void 
ProvenancePlanParser::getQueryEvalNode(EvaluatorClass* evaluator, char* line, void* queryInput, QueryEvaluationTreeNode*& curr)
	    {
		char *token = strtok(line+2,",");

		if (token == NULL)
		{
		    globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"Evaluator",__FILE__,"Error input from file... expecting number of inputs... Provenance line...");
		    curr=NULL; return;
		}

		NREType nre = (NREType)atoi(token);
		if (nre < 1)
		{
		    globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"Evaluator",__FILE__,"NRE should be positive.");
		    curr=NULL; return;
		}		

		token = strtok(NULL,",");
		if (token == NULL)
		{
		    globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"Evaluator",__FILE__,"Error input from file... expecting depth of stack... Provenance line...");
		    curr=NULL; return;
		}
		NREType actonnre = (NREType)atoi(token);

		char newLine[MAX_FILE_INTERFACE_LINE_SIZE];
		if (((std::iostream *)queryInput)->eof() == 0)
		    ((std::iostream *)queryInput)->getline(newLine,MAX_FILE_INTERFACE_LINE_SIZE);
		else
		{
		    globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"Evaluator",__FILE__,"Unexpected end of file... provenance  line...");
		    curr=NULL; return;
		}

		QueryEvaluationTreeNode *oper = evaluator->getQueryEvalNode(newLine,queryInput);
		if (oper == NULL)
		{
		    globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"Evaluator",__FILE__,"Unexpected operand returned... provenance line...");
		    curr=NULL; return;
		}
		curr = new QueryEvaluationTreeProvenanceNode(oper,nre,actonnre);
		evaluator->fileIDsArraySize++;
	    }

