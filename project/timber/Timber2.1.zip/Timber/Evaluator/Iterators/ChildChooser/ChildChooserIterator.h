/*
COPYRIGHT  � 2000-2004 
THE REGENTS OF THE UNIVERSITY OF MICHIGAN
ALL RIGHTS RESERVED

PERMISSION IS GRANTED TO USE, COPY, CREATE DERIVATIVE WORKS AND REDISTRIBUTE THIS SOFTWARE AND SUCH DERIVATIVE WORKS FOR 
NONCOMMERCIAL EDUCATION AND RESEARCH PURPOSES, SO LONG AS NO FEE IS CHARGED, AND SO LONG AS THE COPYRIGHT NOTICE ABOVE, 
THIS GRANT OF PERMISSION, AND THE DISCLAIMER BELOW APPEAR IN ALL COPIES MADE; AND SO LONG AS THE NAME OF THE UNIVERSITY 
OF MICHIGAN IS NOT USED IN ANY ADVERTISING OR PUBLICITY PERTAINING TO THE USE OR DISTRIBUTION OF THIS SOFTWARE WITHOUT 
SPECIFIC, WRITTEN PRIOR AUTHORIZATION.

THIS SOFTWARE IS PROVIDED AS IS, WITHOUT REPRESENTATION FROM THE UNIVERSITY OF MICHIGAN AS TO ITS FITNESS FOR ANY PURPOSE, 
AND WITHOUT WARRANTY BY THE UNIVERSITY OF MICHIGAN OF ANY KIND, EITHER EXPRESS OR IMPLIED, INCLUDING WITHOUT LIMITATION THE 
IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE. THE REGENTS OF THE UNIVERSITY OF MICHIGAN SHALL 
NOT BE LIABLE FOR ANY DAMAGES, INCLUDING SPECIAL, INDIRECT, INCIDENTAL, OR CONSEQUENTIAL DAMAGES, WITH RESPECT TO ANY CLAIM 
ARISING OUT OF OR IN CONNECTION WITH THE USE OF THE SOFTWARE, EVEN IF IT HAS BEEN OR IS HEREAFTER ADVISED OF THE POSSIBILITY 
OF SUCH DAMAGES.
*/

#ifndef __ChildChooserIterator_h
#define __ChildChooserIterator_h
#include <timber-compat.h>

#include "../../Common/IteratorClass.h"
/**
* An iterator that passes the nth occurance of a given ancestor (equal to passing a certain child)
* assumes input is sorted by the start key of a certain node in the input tree.
* @see IteratorClass
* @see WitnessTree 
* @see EvaluatorClass
* @author Shurug Al-Khalifa 
* @version 1.0
*/
class ChildChooserIterator : public IteratorClass
{
public:
	/**
	Constructor
	initializes variables.
	@param input is another iterator that produces the input trees to this iterator.
	@param whichChild is the index of the occurance to be passed 2--> the 2nd occurance
	-1--> the last occurance.
	@param nreOfParent the nre of the node that will be checked.
	@param dataMng is an instance of the data manager
	**/
	ChildChooserIterator(IteratorClass *input,int whichChild, int num, NREType *nreOfParent, DataMng *dataMng);

	/**
	Destructor
	frees the output buffer.
	**/
	~ChildChooserIterator();
	
	/**
	Access Method
	gets the next output from this iterator.
	@param node is a pointer that well be set to the output buffer or NULL (indicating that
	there are no more results).
	**/
	void next(WitnessTree *&node);
private:

	/**
	Process Method
	gets the next new set of trees.
	@param startKey the key of the nodes we want to skip to get a new set of nodes.
	**/
	void getNextNewChild(KeyType *startKey);

	/**
	Blah Method
	checks to see whether the input tree key and a given key are the same.
	@param in is the input tree.
	@param key is the key to be compared with the input tree.
	**/
	bool sameNode(WitnessTree *in, KeyType *key);

	KeyType getParentKey(WitnessTree *tree, NREType nre);

	void setPrevStartKey(WitnessTree *tree);

	/**
	an IteratorClass that produces input for this iterator.
	**/
	IteratorClass *input;

	/**
	an instance of the data Manager
	**/
	DataMng *dataMng;

	/**
	index of the node in the tree to pass the nth occurance of
	**/
	NREType *nreOfParent;
	int num;

	/**
	n. The number of the occurance you want to pass.
	**/
	int whichChild;  

	/**
	The input tree read from input
	**/
	WitnessTree *inTuple;

	/**
	A buffer that holds the output tree.
	**/
	WitnessTree *resultBuffer;

	/**
	A previous value of inTuple. used for comparison.
	**/
	WitnessTree *prevTuple;

	/**
	a counter used in finding the right occurance to pass.
	**/
	int count;

	/**
	a previous value of the start key. used for comparison.
	**/
	KeyType *prevStartKey;
};

#endif
