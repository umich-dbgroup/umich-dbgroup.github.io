#include "../../Evaluator/EvaluatorClass.h"

#include "QueryEvaluationTreeDataInstantiationNode.h"

#include "DataInstantiationIterator.h"
#include "extra.h"

void QueryEvaluationTreeDataInstantiationNode::processQueryEvalNode(EvaluatorClass* evaluator, IteratorClass*& curr)
	    {
		IteratorClass *opr = evaluator->processQueryEvalNode(getOperand());
		if (opr == NULL)
		    curr=NULL; return;
		curr = new DataInstantiationIterator(opr,getNodeIndexInWitnessTree(),getDISpecification(),evaluator->getDataManager());
	    }

