
#include "parse.hpp"

char QueryEvaluationTreeIndexHashValueJoinNode::getIdentifier(void) { return 'H'; }

char IndexHashValueJoinPlanParser::getIteratorIdentifier(void) { return 'H'; }

void 
IndexHashValueJoinPlanParser::getQueryEvalNode(EvaluatorClass* evaluator, char* line, void* queryInput, QueryEvaluationTreeNode*& curr)
	    {
		char *token = strtok(line+2,",");

		if (token == NULL)
		{
		    globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"Evaluator",__FILE__,"Error input from file... expecting expected size... inex hash join line...");
		    curr=NULL; return;
		}
		int size = atoi(token);

		char *indexName;
		token = strtok(NULL,",");
		if (token == NULL)
		{
		    globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"Evaluator",__FILE__,"Error input from file... expecting join index name... index hash join line...");
		    curr=NULL; return;
		}
		indexName = new char[strlen(token)+1];
		strcpy(indexName,token);

		token = strtok(NULL,",");
		char *fileName;
		if (token == NULL)
		{
		    globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"Evaluator",__FILE__,"Error input from file... expecting file name... index hash join line...");
		    delete [] indexName;
		    curr=NULL; return;
		}
		fileName = new char[strlen(token)+1];
		strcpy(fileName,token);

		token = strtok(NULL,",");
		if (token == NULL)
		{
		    globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"Evaluator",__FILE__,"Error input from file... expecting left nre... index hash join line...");
		    delete [] indexName;
		    delete [] fileName;
		    curr=NULL; return;
		}
		NREType  leftNRE;
		if (atoi(token) < 1)
		{
		    globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"Evaluator",__FILE__,"left NRE should be positive.");
		    delete [] indexName;
		    delete [] fileName;
		    curr=NULL; return;
		}
		else
		{
		    leftNRE = (NREType)atoi(token);
		    if (leftNRE > evaluator->maxNRE)
			evaluator->maxNRE = leftNRE;
		}

		token = strtok(NULL,",");
		if (token == NULL)
		{
		    globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"Evaluator",__FILE__,"Error input from file... expecting right nre... index hash join line...");
		    delete [] indexName;
		    delete [] fileName;
		    curr=NULL; return;
		}
		NREType  rightNRE;
		if (atoi(token) < 1)
		{
		    globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"Evaluator",__FILE__,"right NRE should be positive.");
		    delete [] indexName;
		    delete [] fileName;
		    curr=NULL; return;
		}
		else
		{
		    rightNRE = (NREType)atoi(token);
		    if (rightNRE > evaluator->maxNRE)
			evaluator->maxNRE = rightNRE;
		}

		token = strtok(NULL,",");
		if (token == NULL)
		{
		    globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"Evaluator",__FILE__,"Error input from file... expecting root NRE... index hash join line...");
		    delete [] indexName;
		    delete [] fileName;
		    curr=NULL; return;
		}
		NREType rootNRE = (NREType)atoi(token);
		if (rootNRE < 1)
		{
		    globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"Evaluator",__FILE__,"NRE should be positive.");
		    delete [] indexName;
		    delete [] fileName;
		    curr=NULL; return;
		}
		if (rootNRE > evaluator->maxNRE)
		    evaluator->maxNRE = rootNRE;


		bool outer = false;
		bool atLeastOne = false;

		token = strtok(NULL,",");
		if (token != NULL)
		{
		    if (strcmp(token,"O") == 0)
		    {
			outer = true;
			token = strtok(NULL,",");
			if (token != NULL)
			{
			    if (strcmp(token,"A") == 0)
				atLeastOne = true;
			    else
			    {
				globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"Evaluator",__FILE__,"Error input from file... unrecognized optional parameter... index hash join line...");

				if (indexName) delete [] indexName;
				if (fileName) delete [] fileName;
				curr=NULL; return;	
			    }
			}
		    }
		    else
		    {
			if (strcmp(token,"A") == 0)
			    atLeastOne = true;
			else
			{
			    globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"Evaluator",__FILE__,"Error input from file... unrecognized optional parameter... index hash join line...");

			    if (indexName) delete [] indexName;
			    if (fileName) delete [] fileName;
			    curr=NULL; return;	
			}
		    }
		}


		char newLine[MAX_FILE_INTERFACE_LINE_SIZE];
		if (((std::iostream *)queryInput)->eof() == 0)
		    ((std::iostream *)queryInput)->getline(newLine,MAX_FILE_INTERFACE_LINE_SIZE);
		else
		{
		    globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"Evaluator",__FILE__,"Unexpected end of file... index hash join line...");
		    if (indexName) delete [] indexName;
		    if (fileName) delete [] fileName;           
		    curr=NULL; return;
		}
		QueryEvaluationTreeNode *oper1 = evaluator->getQueryEvalNode(newLine,queryInput);
		if (oper1 == NULL)
		{
		    globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"Evaluator",__FILE__,"Unexpected operand 1 returned... index hash join line...");
		    if (indexName) delete [] indexName;
		    if (fileName) delete [] fileName;
		    curr=NULL; return;
		}

		if (((std::iostream *)queryInput)->eof() == 0)
		    ((std::iostream *)queryInput)->getline(newLine,MAX_FILE_INTERFACE_LINE_SIZE);
		else
		{
		    globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"Evaluator",__FILE__,"Unexpected end of file... index hash join line...");
		    if (indexName) delete [] indexName;
		    if (fileName) delete [] fileName; 
		    delete oper1;
		    curr=NULL; return;
		}
		QueryEvaluationTreeNode *oper2 = evaluator->getQueryEvalNode(newLine,queryInput);
		if (oper2 == NULL)
		{
		    globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"Evaluator",__FILE__,"Unexpected operand 2 returned... index hash join line...");
		    if (indexName) delete [] indexName;
		    if (fileName) delete [] fileName;
		    delete oper1;
		    curr=NULL; return;
		}

		curr  = new QueryEvaluationTreeIndexHashValueJoinNode(oper1,oper2,size,indexName,fileName,leftNRE,rightNRE,rootNRE,outer,atLeastOne);
	    }

