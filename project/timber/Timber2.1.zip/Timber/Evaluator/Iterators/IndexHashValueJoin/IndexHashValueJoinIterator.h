/*
COPYRIGHT  � 2000-2004 
THE REGENTS OF THE UNIVERSITY OF MICHIGAN
ALL RIGHTS RESERVED

PERMISSION IS GRANTED TO USE, COPY, CREATE DERIVATIVE WORKS AND REDISTRIBUTE THIS SOFTWARE AND SUCH DERIVATIVE WORKS FOR 
NONCOMMERCIAL EDUCATION AND RESEARCH PURPOSES, SO LONG AS NO FEE IS CHARGED, AND SO LONG AS THE COPYRIGHT NOTICE ABOVE, 
THIS GRANT OF PERMISSION, AND THE DISCLAIMER BELOW APPEAR IN ALL COPIES MADE; AND SO LONG AS THE NAME OF THE UNIVERSITY 
OF MICHIGAN IS NOT USED IN ANY ADVERTISING OR PUBLICITY PERTAINING TO THE USE OR DISTRIBUTION OF THIS SOFTWARE WITHOUT 
SPECIFIC, WRITTEN PRIOR AUTHORIZATION.

THIS SOFTWARE IS PROVIDED AS IS, WITHOUT REPRESENTATION FROM THE UNIVERSITY OF MICHIGAN AS TO ITS FITNESS FOR ANY PURPOSE, 
AND WITHOUT WARRANTY BY THE UNIVERSITY OF MICHIGAN OF ANY KIND, EITHER EXPRESS OR IMPLIED, INCLUDING WITHOUT LIMITATION THE 
IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE. THE REGENTS OF THE UNIVERSITY OF MICHIGAN SHALL 
NOT BE LIABLE FOR ANY DAMAGES, INCLUDING SPECIAL, INDIRECT, INCIDENTAL, OR CONSEQUENTIAL DAMAGES, WITH RESPECT TO ANY CLAIM 
ARISING OUT OF OR IN CONNECTION WITH THE USE OF THE SOFTWARE, EVEN IF IT HAS BEEN OR IS HEREAFTER ADVISED OF THE POSSIBILITY 
OF SUCH DAMAGES.
*/

#ifndef __IndexHashValueJoinIterator_h
#define __IndexHashValueJoinIterator_h
#include <timber-compat.h>

#include <hash_map-compat.h>
#include "../../Evaluator/EvaluatorClass.h"
#include "../IndexAccess/GistIndexAccess.h"

/**
* An access method that performs value join. It performs a nested loop join or a sort-merge join.
* @see IteratorClass
* @see EvaluatorClass
* @see WitnessTree
* @author Shurug Al-Khalifa 
* @version 1.0
*/
class IndexHashValueJoinIterator : public IteratorClass
{
public:
	/**
	Constructor.
	@param left is the left input (outer loop).
	@param right is the right input (inner loop). ValueJoin blocks on right input.
	@param leftIndex index of node in the left tree that we need to join. if the 
			joinByWhat is:
				JOINBY_ATTRIBUTE_NUM the value of attribute attrNameLeft of the node leftIndex
						will be used in the join. It will be compared as a number.
				JOINBY_ATTRIBUTE_STR the value of attribute attrNameLeft of the node leftIndex
						will be used in the join. It will be compared as a string.
				JOINBY_TEXT_NUM the text value of node leftIndex will be used in the join.
						It will be compared as a number.
				JOINBY_TEXT_STR the text value of node leftIndex will be used in the join.
						It will be compared as a string.
				JOINBY_NOTHING leftIndex is ignored.
				JOINBY_STARTKEY leftIndex is the index of the node in the left input tree 
						to be joined by start key
				JOINBY_LEVEL leftIndex is the index of the node in the left input tree
						to be joined by level
	@param rightIndex index of node in the right tree that we need to join. if the 
			joinByWhat is:
				JOINBY_ATTRIBUTE_NUM the value of attribute attrNameRight of the node rightIndex
						will be used in the join. It will be compared as a number.
				JOINBY_ATTRIBUTE_STR the value of attribute attrNameRight of the node rightIndex
						will be used in the join. It will be compared as a string.
				JOINBY_TEXT_NUM the text value of node rightIndex will be used in the join.
						It will be compared as a number.
				JOINBY_TEXT_STR the text value of node rightIndex will be used in the join.
						It will be compared as a string.
				JOINBY_NOTHING rightIndex is ignored.
				JOINBY_STARTKEY rightIndex is the index of the node in the right input tree 
						to be joined by start key
				JOINBY_LEVEL rightIndex is the index of the node in the right input tree
						to be joined by level
	@param leftTag is the tag in the left input tree of the element to use in the join. this 
			parameter is ignored unless leftIndex == -1. then, it replaces leftIndex in terms
			of meaning. for example, if you are joining by attribute, then node with leftTag 
			is located in the left input tree and its attribute attrNameLeft is used in the join.
	@param rightTag is the tag in the right input tree of the element to use in the join. this 
			parameter is ignored unless rightIndex == -1. then, it replaces rightIndex in terms
			of meaning. for example, if you are joining by attribute, then node with rightTag 
			is located in the right input tree and its attribute attrNameRight is used in the join.
	@param estimatedSizeOfRight since we block on right input in the case of nested loop join, 
			we new an array in memory of this size. it is not necessary to give an exact size, 
			but giving a close on would enhance performance.
	@param attrNameLeft holds the attribute name of the left input if the value join is to be 
			performed on attribute (joinByWhat = JOINBY_ATTRIBUTE_*). Otherwise, it is ignored.
	@param attrNameRight holds the attribute name of the right input if the value join is to be 
			performed on attribute (joinByWhat = JOINBY_ATTRIBUTE_*). Otherwise, it is ignored.
	@param data_mng an instance of the data manager.
	@param operation is the join condition operation it is one of the following:
			JOINOP_EQ: left input join value is equal to right input join value. only this operation
						is supported for sort-merge join.
			JOINOP_NE: left input join value is not equal to right input join value.
			JOINOP_LT: left input join value is less than right input join value.
			JOINOP_GT: left input join value is greater than right input join value.
			JOINOP_LE: left input join value is less than or equal to right input join value.
			JOINOP_GE: left input join value is greater than or equal to right input join value.
	@param joinByWhatLeft specifies the value used in the join. If it is
				JOINBY_ATTRIBUTE_* the value of attribute attrName of the nodes specified by left and right
						indices will be used in the join.
				JOINBY_TEXT_* the text value of nodes specified by left and right indices 
				        will be used in the join.
				JOINBY_NOTHING is cartesian product of left and right input trees.
	@param sortedInput if true, sort-merge join is performed, else, nested-loop join is performed.
	**/ 
	IndexHashValueJoinIterator(IteratorClass *left, IteratorClass *right, NREType leftNRE, NREType rightNRE, 
		int estimatedSizeOfRight, 
		  DataMng *dataMng, bool outerJoin, NREType rootNRE,
		char *indexName, int openFileIndex,bool atLeastOne);

	/**
	Destructor.
	releases memory used by array and result buffer.
	**/
	~IndexHashValueJoinIterator();

	/**
	Access Method
	gets the next output from this iterator.
	@param node is a pointer that well be set to the output buffer or NULL (indicating that
	there are no more results).
	**/
	void next(WitnessTree *&node);
private:

	int joinNested();

	/**
	Access Method.
	checks whether or not the two input trees are to be joined.
	@param in1 is the left input tree.
	@param in2 is the right input tree.
	@returns true is in1 and in2 statisy the join condition. returns false otherwise.
	**/
	int joinable(WitnessTree *in1, WitnessTree *in2, int &result);
	int useIndexToMatch(WitnessTree *in1, WitnessTree *in2, int &result);
	bool useIndexAndHashToMatch(WitnessTree *in1, int &result);
	int compareStartKeys(WitnessTree *in1, WitnessTree *in2,int index1, int index2);
	GistIndexAccess *getIndexAccess(KeyType leftSK);
	bool leftJoins(KeyType sk, bool addToBuf);
	void addToBuffer(int index);

	int setIndex(WitnessTree *leftTree,WitnessTree *rightTree, bool checkMultiple);
	IteratorClass *left;
	IteratorClass *right;
	WitnessTree *rightArray;

	void writeToResult(WitnessTree *leftTree,WitnessTree *rightTree);
	void addToArray(WitnessTree *&treeArray, WitnessTree *inTree, int &arraySize, int &maxSize, int index);
	 
	void sortIndexBuffer();
	void writeIndexBufferToResult();
	DataMng *dataMng;

	WitnessTree *leftTuple;
	WitnessTree *rightTuple;
	WitnessTree *resultBuffer;

	NREType leftNRE;
	NREType rightNRE;
	int estimatedSizeOfRight;
	int actualSizeRight;

	int rightCursor;

	int initSize;
	int operation;

	bool outerJoin;
	bool readFromArray;
	NREType rootNRE;

	int leftIndex;
	int rightIndex;

	bool leftJoined;
	int maxSizeRight;
	char *indexName;
	int openFileIndex;
	GistIndexAccess *indAccess;
	WitnessTree *indAccessTuple;
	bool atLeastOne;

	int *ib;
	int ibSz;
	int ibMax;

	hash_multimap<double,int> hashTable;
	hash_map <double, int> :: const_iterator hashTabIter;
};




#endif
