#include "../../Evaluator/EvaluatorClass.h"

#include "QueryEvaluationTreeGroupByNode.h"

#include "GroupByIterator.h"
#include "extra.h"

void QueryEvaluationTreeGroupByNode::processQueryEvalNode(EvaluatorClass* evaluator, IteratorClass*& curr)
	    {
		IteratorClass *opr = evaluator->processQueryEvalNode(getOperand());
		if (opr == NULL)
		{
		    globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"Evaluator",__FILE__, "operand returned is NULL. group by process eval node..." );
		    curr=NULL; return;
		}
		curr = new GroupByIterator(opr,getEstimatedSize(),getGroupByWhat(),
			getGroupByNRE(),getGroupByAttrName(),getKeepTrees(),
			getNum(),getOperation(),getOpOnWhat(),
			getAttrNames(),getNRE(),getRootNRE(),
			getValueNRE(),getOperationNRE(),evaluator->getDataManager(),getSort());

		setOperationNRE(NULL);
		setNRE(NULL);
		setOperation(NULL);
		setOpOnWhat(NULL);
		setAttrNames(NULL);
		setGroupByAttrName(NULL);
	    }

