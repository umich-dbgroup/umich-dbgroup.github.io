/*
COPYRIGHT  � 2000-2004 
THE REGENTS OF THE UNIVERSITY OF MICHIGAN
ALL RIGHTS RESERVED

PERMISSION IS GRANTED TO USE, COPY, CREATE DERIVATIVE WORKS AND REDISTRIBUTE THIS SOFTWARE AND SUCH DERIVATIVE WORKS FOR 
NONCOMMERCIAL EDUCATION AND RESEARCH PURPOSES, SO LONG AS NO FEE IS CHARGED, AND SO LONG AS THE COPYRIGHT NOTICE ABOVE, 
THIS GRANT OF PERMISSION, AND THE DISCLAIMER BELOW APPEAR IN ALL COPIES MADE; AND SO LONG AS THE NAME OF THE UNIVERSITY 
OF MICHIGAN IS NOT USED IN ANY ADVERTISING OR PUBLICITY PERTAINING TO THE USE OR DISTRIBUTION OF THIS SOFTWARE WITHOUT 
SPECIFIC, WRITTEN PRIOR AUTHORIZATION.

THIS SOFTWARE IS PROVIDED AS IS, WITHOUT REPRESENTATION FROM THE UNIVERSITY OF MICHIGAN AS TO ITS FITNESS FOR ANY PURPOSE, 
AND WITHOUT WARRANTY BY THE UNIVERSITY OF MICHIGAN OF ANY KIND, EITHER EXPRESS OR IMPLIED, INCLUDING WITHOUT LIMITATION THE 
IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE. THE REGENTS OF THE UNIVERSITY OF MICHIGAN SHALL 
NOT BE LIABLE FOR ANY DAMAGES, INCLUDING SPECIAL, INDIRECT, INCIDENTAL, OR CONSEQUENTIAL DAMAGES, WITH RESPECT TO ANY CLAIM 
ARISING OUT OF OR IN CONNECTION WITH THE USE OF THE SOFTWARE, EVEN IF IT HAS BEEN OR IS HEREAFTER ADVISED OF THE POSSIBILITY 
OF SUCH DAMAGES.
*/

#include "QueryEvaluationTreeGroupByNode.h"



QueryEvaluationTreeGroupByNode::QueryEvaluationTreeGroupByNode(QueryEvaluationTreeNode* operand,
		int estimatedSize,int groupByWhat, NREType groupbyNRE, char *groupbyAttrName, int num, int *operation, int *opOnWhat,
		char **attrNames, NREType *nre,NREType rootNRE, NREType valueNRE,NREType *operationNRE, bool sort, bool keepTrees)
: QueryEvaluationTreeNode()
{
	this->operand = operand;
	this->estimatedSize = estimatedSize;
	this->groupByWhat = groupByWhat;
	this->num = num;
	this->groupbyNRE = groupbyNRE;
	this->groupbyAttrName = groupbyAttrName;
	this->operation = operation;
	this->opOnWhat = opOnWhat;
	this->attrNames = attrNames;
	this->nre = nre;
	this->rootNRE = rootNRE;
	this->valueNRE = valueNRE;
	this->operationNRE = operationNRE;
	this->sort = sort;
	this->keepTrees  = keepTrees;
}


QueryEvaluationTreeGroupByNode::~QueryEvaluationTreeGroupByNode()
{
	delete operand;
}

int QueryEvaluationTreeGroupByNode::getEstimatedSize()
{
	return this->estimatedSize;
}

void QueryEvaluationTreeGroupByNode::setEstimatedSize(int estimatedSize)
{
	this->estimatedSize  = estimatedSize;
}

int QueryEvaluationTreeGroupByNode::getGroupByWhat()
{
	return this->groupByWhat;
}

void QueryEvaluationTreeGroupByNode::setGroupByWhat(int groupByWhat)
{
	this->groupByWhat = groupByWhat;
}


int *QueryEvaluationTreeGroupByNode::getOperation()
{
	return this->operation;
}

void QueryEvaluationTreeGroupByNode::setOperation(int *operation)
{
	this->operation = operation;
}

int *QueryEvaluationTreeGroupByNode::getOpOnWhat()
{
	return this->opOnWhat;
}

void QueryEvaluationTreeGroupByNode::setOpOnWhat(int *opOnWhat)
{
	this->opOnWhat = opOnWhat;
}

NREType *QueryEvaluationTreeGroupByNode::getNRE()
{
	return this->nre;
}

void QueryEvaluationTreeGroupByNode::setNRE(NREType *nre)
{
	this->nre = nre;
}

NREType *QueryEvaluationTreeGroupByNode::getOperationNRE()
{
	return this->operationNRE;
}

void QueryEvaluationTreeGroupByNode::setOperationNRE(NREType *operationNRE)
{
	this->operationNRE = operationNRE;
}


NREType QueryEvaluationTreeGroupByNode::getRootNRE()
{
	return this->rootNRE;
}

void QueryEvaluationTreeGroupByNode::setRootNRE(NREType rootNRE)
{
	this->rootNRE = rootNRE;
}

NREType QueryEvaluationTreeGroupByNode::getValueNRE()
{
	return this->valueNRE;
}

void QueryEvaluationTreeGroupByNode::setValueNRE(NREType valueNRE)
{
	this->valueNRE = valueNRE;
}

NREType QueryEvaluationTreeGroupByNode::getGroupByNRE()
{
	return this->groupbyNRE;
}

void QueryEvaluationTreeGroupByNode::setGroupByNRE(NREType groupbyNRE)
{
	this->groupbyNRE = groupbyNRE;
}

int QueryEvaluationTreeGroupByNode::getNum()
{
	return this->num;
}

void QueryEvaluationTreeGroupByNode::setNum(int num)
{
	this->num = num;
}

bool QueryEvaluationTreeGroupByNode::getSort()
{
	return this->sort;
}

void QueryEvaluationTreeGroupByNode::setSort(bool sort)
{
	this->sort = sort;
}

bool QueryEvaluationTreeGroupByNode::getKeepTrees()
{
	return this->keepTrees;
}

void QueryEvaluationTreeGroupByNode::setKeepTrees(bool keepTrees)
{
	this->keepTrees = keepTrees;
}


char *QueryEvaluationTreeGroupByNode::getGroupByAttrName()
{
	return this->groupbyAttrName;
}

void QueryEvaluationTreeGroupByNode::setGroupByAttrName(char *groupbyAttrName)
{
	this->groupbyAttrName = groupbyAttrName;
}


char **QueryEvaluationTreeGroupByNode::getAttrNames()
{
	return this->attrNames;
}

void QueryEvaluationTreeGroupByNode::setAttrNames(char **attrNames)
{
	this->attrNames = attrNames;
}

QueryEvaluationTreeNode *QueryEvaluationTreeGroupByNode::getOperand()
{
	return this->operand;
}

void QueryEvaluationTreeGroupByNode::setOperand(QueryEvaluationTreeNode* operand)
{
	this->operand = operand;
}

void QueryEvaluationTreeGroupByNode::deleteStructures()
{
	if (operationNRE) delete [] operationNRE;
	if (nre) delete [] nre;
	if (operation) delete [] operation;
	if (opOnWhat) delete [] opOnWhat;
	if (attrNames)
	{
		for (int i=0; i< num; i++)
			if (attrNames[i]) delete [] attrNames[i];
		delete [] attrNames;
	}
	if (groupbyAttrName) delete [] groupbyAttrName;
	operand->deleteStructures();
}
