
#include "parse.hpp"

char QueryEvaluationTreeIndexAccessNode::getIdentifier(void) { return 'I'; }

char IndexAccessPlanParser::getIteratorIdentifier(void) { return 'I'; }

void 
IndexAccessPlanParser::getQueryEvalNode(EvaluatorClass* evaluator, char* line, void* queryInput, QueryEvaluationTreeNode*& curr)
	    {
		// the index name
		char *token = strtok(line+2,",");

		if (token == NULL)
		{
		    globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"Evaluator",__FILE__,"Expecting NRE in Index Access Line.");
		    curr=NULL; return;
		}
		NREType nre = (NREType)atoi(token);
		if (nre < 1)
		{
		    globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"Evaluator",__FILE__,"NRE should be positive.");
		    curr=NULL; return;
		}
		if (nre > evaluator->maxNRE)
		    evaluator->maxNRE = nre;

		token = strtok(NULL,",");
		if (token == NULL)
		{
		    globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"Evaluator",__FILE__,"Expecting Index Name in Index Access Line.");
		    curr=NULL; return;
		}
		char *indexName = new char[strlen(token)+1];
		strcpy(indexName,token);

		// the index file name
		token = strtok(NULL,",");
		char *fileName;
		if (token == NULL)
		{
		    globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"Evaluator",__FILE__,"Expecting XML File Name in Index Access Line.");
		    delete [] indexName;           
		    curr=NULL; return;
		}
		fileName = new char[strlen(token)+1];
		strcpy(fileName,token);

		//Hash or GIST index
		token = strtok(NULL,",");
		if (token == NULL)
		{
		    globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"Evaluator",__FILE__,"Expecting HASH or GIST in Index Access Line.");
		    delete [] indexName;
		    delete [] fileName;
		    curr=NULL; return;
		}
		int shoreOrGist;
		if (strcmp(token,"GIST") == 0)
		    shoreOrGist = GIST_INDEX;
		else if (strcmp(token,"HASH") == 0)
		    shoreOrGist = HASH_INDEX;
		else if (strcmp(token,"SHORE") == 0)
		{
		    globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"Evaluator",__FILE__,"Shore indices are not supported.");
		    delete [] indexName;
		    delete [] fileName;
		    curr=NULL; return;
		}
		else
		{
		    globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"Evaluator",__FILE__,"Unrecognizable index source.");
		    delete [] indexName;
		    delete [] fileName; 
		    curr=NULL; return;
		}

		// Index Type: INT, STR, FLT
		token = strtok(NULL,",");
		if (token == NULL)
		{
		    globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"Evaluator",__FILE__,"Expecting Index Type in Index Access Line.");
		    delete [] indexName;
		    delete [] fileName; 
		    curr=NULL; return;
		}
		int indexType;
		if (strcmp(token,"INT") == 0)
		    indexType = INT_INDEX;
		else if (strcmp(token,"FLT") == 0)
		    indexType = FLOAT_INDEX;
		else if (strcmp(token,"STR") == 0)
		    indexType = STRING_INDEX;
		else if (strcmp(token,"DBL") == 0)
		    indexType = DOUBLE_INDEX;
		else
		{
		    globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"Evaluator",__FILE__,"Unrecognizable index type.");
		    delete [] indexName;
		    delete [] fileName; 
		    curr=NULL; return;
		}

		if (strstr(indexName,"elementtag"))
		    indexType = INT_INDEX;

		bool useTagIdIndex = false;
		//make sure indexName has tagid in it if using indices with concatenated <string,id> keys... for updates.
		if (strstr(indexName, "tagid")) {
		    useTagIdIndex = true;
		}
		// value
		token = strtok(NULL,",");
		if (token == NULL)
		{
		    globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"Evaluator",__FILE__,"Expecting string, float, double or integer value in Index Access Line.");
		    delete [] indexName;
		    delete [] fileName;  
		    curr=NULL; return;
		}
		char *strVal;
		if (strstr(indexName,"elementtag"))
		{
		    int tagCode = evaluator->getDataManager()->getPhysicalDataMng()->getXMLNameTable()->getCodeByName(token);
		    /*	if (tagCode == -1)
			{
			globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"Evaluator",__FILE__,"Tag name does not exist in Timber. in Index Access Line.");
			delete [] indexName;
			delete [] fileName;  
			curr=NULL; return;
			}*/
		    strVal = new char[6];
		    sprintf(strVal,"%d",tagCode);
		}
		else
		{
		    strVal = new char[strlen(token)+1];
		    strcpy(strVal , token);
		}

		// create the new QueryEvaluationTreeNode
		token = strtok(NULL,",");
		evaluator->TransformString(strVal) ;
		if (token == NULL)
		{
		    curr = new QueryEvaluationTreeIndexAccessNode(indexName,nre,fileName,strVal,NULL);
		    ((QueryEvaluationTreeIndexAccessNode *)curr)->setIndexType(indexType);
		    ((QueryEvaluationTreeIndexAccessNode *)curr)->setShoreOrGist(shoreOrGist);
		}
		else
		{
		    // the second optional value 
		    char *strVal2  = NULL;
		    if (strcmp(token,"-1") != 0)
		    {
			if (strstr(indexName,"elementtag"))
			{
			    int tagCode = evaluator->getDataManager()->getPhysicalDataMng()->getXMLNameTable()->getCodeByName(token);
			    /*	if (tagCode == -1)
				{
				globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"Evaluator",__FILE__,"Tag name does not exist in Timber. in Index Access Line.");
				delete [] indexName;
				delete [] fileName;  
				curr=NULL; return;
				}*/
			    strVal2 = new char[6];
			    sprintf(strVal2,"%d",tagCode);
			}
			else
			{
			    strVal2 = new char[strlen(token)+1];
			    strcpy(strVal2,token);
			}
		    }

		    curr = new QueryEvaluationTreeIndexAccessNode(indexName,nre,fileName,strVal,strVal2);
		    ((QueryEvaluationTreeIndexAccessNode *)curr)->setIndexType(indexType);
		    ((QueryEvaluationTreeIndexAccessNode *)curr)->setShoreOrGist(shoreOrGist);     
		}

		((QueryEvaluationTreeIndexAccessNode *)curr)->tagIdIndex = useTagIdIndex;
	    }
	    //((QueryEvaluationTreeIndexAccessNode *)curr)->tagIdIndex = gUseTagIdIndex;
	    //gUseTagIdIndex = false;

