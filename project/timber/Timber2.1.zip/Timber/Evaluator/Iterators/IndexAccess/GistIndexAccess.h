/*
COPYRIGHT  � 2000-2004 
THE REGENTS OF THE UNIVERSITY OF MICHIGAN
ALL RIGHTS RESERVED

PERMISSION IS GRANTED TO USE, COPY, CREATE DERIVATIVE WORKS AND REDISTRIBUTE THIS SOFTWARE AND SUCH DERIVATIVE WORKS FOR 
NONCOMMERCIAL EDUCATION AND RESEARCH PURPOSES, SO LONG AS NO FEE IS CHARGED, AND SO LONG AS THE COPYRIGHT NOTICE ABOVE, 
THIS GRANT OF PERMISSION, AND THE DISCLAIMER BELOW APPEAR IN ALL COPIES MADE; AND SO LONG AS THE NAME OF THE UNIVERSITY 
OF MICHIGAN IS NOT USED IN ANY ADVERTISING OR PUBLICITY PERTAINING TO THE USE OR DISTRIBUTION OF THIS SOFTWARE WITHOUT 
SPECIFIC, WRITTEN PRIOR AUTHORIZATION.

THIS SOFTWARE IS PROVIDED AS IS, WITHOUT REPRESENTATION FROM THE UNIVERSITY OF MICHIGAN AS TO ITS FITNESS FOR ANY PURPOSE, 
AND WITHOUT WARRANTY BY THE UNIVERSITY OF MICHIGAN OF ANY KIND, EITHER EXPRESS OR IMPLIED, INCLUDING WITHOUT LIMITATION THE 
IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE. THE REGENTS OF THE UNIVERSITY OF MICHIGAN SHALL 
NOT BE LIABLE FOR ANY DAMAGES, INCLUDING SPECIAL, INDIRECT, INCIDENTAL, OR CONSEQUENTIAL DAMAGES, WITH RESPECT TO ANY CLAIM 
ARISING OUT OF OR IN CONNECTION WITH THE USE OF THE SOFTWARE, EVEN IF IT HAS BEEN OR IS HEREAFTER ADVISED OF THE POSSIBILITY 
OF SUCH DAMAGES.
*/

#ifndef __GistIndexAccess_h
#define __GistIndexAccess_h
#include <timber-compat.h>

#include "IndexMng/IndexOperation/GistIndexUpdate.h"
#include "TextMng/TermExpansion/TermExpansion.h"
#include "Common/IteratorClass.h"

// tag name for dummy nodes constructed for term expansion result
#define STDTAGNAME "string"
// maximum number of sense for each word
#define MaxNumSense 16 

class WitnessTree;
class IteratorClass;
class gist;

/**
* GistIndexAccess
* 
* This class is a gist index retrieval iterator
* It is inherited from IteratorClass
* 
* @version 1.0
*/
class GistIndexAccess : public IteratorClass
{
public:

	/**
	* Constructor
	*
	* @param indexName The index name (actually the physical filename)
	* @param q The query accessing type of gist
	* @param indexType The index type (string, integer...)
	* @param openFileIndex The index in the open file table
	* @param assignedNRE NRE assigned to this index access
	*/
	GistIndexAccess(char *indexName,bt_query_t *q,int indexType,char openFileIndex, NREType assignedNRE, DataMng *dataMng) ;

	GistIndexAccess(char *indexName,bt_query_t *q,int indexType,char openFileIndex, NREType assignedNRE) ;

	/**
	* Destructor
	*
	* Close the index and clear buffer
	*/
	~GistIndexAccess() ;

	/**
	* Iterator Method
	*
	* Reset the iterator to the beginning of the result
	*/
	void Reset() ;

	/**
	* Iterator Method
	*
	* Get next key/data entry from the index
	* @param node A witness tree node that will be filled in by the data
	*/
	void next(WitnessTree *&node) ;

	/**
	 * Yunyao: added to support term expansion
	 *
	 * @
	 **/
	 bool alreadyOutput(char *term) ;

private:
    gist_cursor_t cursor;
	gist index;
	bool eof;
	char *fetchedString;
	int fetchedInt;
	float fetchedFloat;
	double fetchedDouble;
	unsigned long keysz;  
	unsigned long datasz;
	bt_query_t *query;
	int indexType;
	WitnessTree *resultBuffer;
	char *indexName;
	char *indexNameWithPath;
	int numRead;
	char openFileIndex;
	NREType assignedNRE;
	bool errorFound;
	rc_tGist rc;

	// Yunyao Li: 10-21-2004, added to support term expansion
	bool isStdTagTagIndex;
	int dummyNodeCounter;
	DataMng *dataMng;
	char stdTerm[MaxNumSense][MaxStrLen];
	char output[MaxNumSense][MaxStrLen];
	int num;
	int counter;
	int outputCounter;
};

#endif

