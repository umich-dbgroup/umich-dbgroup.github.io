/*
COPYRIGHT  ?2000-2004 
THE REGENTS OF THE UNIVERSITY OF MICHIGAN
ALL RIGHTS RESERVED

PERMISSION IS GRANTED TO USE, COPY, CREATE DERIVATIVE WORKS AND REDISTRIBUTE THIS SOFTWARE AND SUCH DERIVATIVE WORKS FOR 
NONCOMMERCIAL EDUCATION AND RESEARCH PURPOSES, SO LONG AS NO FEE IS CHARGED, AND SO LONG AS THE COPYRIGHT NOTICE ABOVE, 
THIS GRANT OF PERMISSION, AND THE DISCLAIMER BELOW APPEAR IN ALL COPIES MADE; AND SO LONG AS THE NAME OF THE UNIVERSITY 
OF MICHIGAN IS NOT USED IN ANY ADVERTISING OR PUBLICITY PERTAINING TO THE USE OR DISTRIBUTION OF THIS SOFTWARE WITHOUT 
SPECIFIC, WRITTEN PRIOR AUTHORIZATION.

THIS SOFTWARE IS PROVIDED AS IS, WITHOUT REPRESENTATION FROM THE UNIVERSITY OF MICHIGAN AS TO ITS FITNESS FOR ANY PURPOSE, 
AND WITHOUT WARRANTY BY THE UNIVERSITY OF MICHIGAN OF ANY KIND, EITHER EXPRESS OR IMPLIED, INCLUDING WITHOUT LIMITATION THE 
IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE. THE REGENTS OF THE UNIVERSITY OF MICHIGAN SHALL 
NOT BE LIABLE FOR ANY DAMAGES, INCLUDING SPECIAL, INDIRECT, INCIDENTAL, OR CONSEQUENTIAL DAMAGES, WITH RESPECT TO ANY CLAIM 
ARISING OUT OF OR IN CONNECTION WITH THE USE OF THE SOFTWARE, EVEN IF IT HAS BEEN OR IS HEREAFTER ADVISED OF THE POSSIBILITY 
OF SUCH DAMAGES.
*/

#include "CubeCounterBasedIterator.h"
#include "CubeBottomUpIterator.h"
#include <float.h>
#include <assert.h>

int gCurrentDim;
int gDimNum;
NREType* gNREDim;
int* gWhereEmptyGoesDim;
int* gOrderDim;
char** gAttrNameDim;
int* gSortByDim;
OutputTreeRec* outputRecCounter;

double sizec,sizew;
DataMng *gdataMngCube;

int compareCubeNodesValSort(const void *elem1,const void *elem2)
{
	for (int i=gCurrentDim; i<gDimNum; i++)
	{
		int index1 = ((WitnessTree *)elem1)->getIndexOfNRE(gNREDim[i]);
		int index2 = ((WitnessTree *)elem2)->getIndexOfNRE(gNREDim[i]);
		if (index1 == FAILURE && index2 == FAILURE)
			continue;
		if (index1 == FAILURE)
			return (-1*gWhereEmptyGoesDim[i]);
		if (index2 == FAILURE)
			return (gWhereEmptyGoesDim[i]);

		FileIDType fileid1 = EvaluatorClass::getFileID(((ComplexListNode *)((WitnessTree *)elem1)->getNodeByIndex(index1))->getFileIndex());
		if (fileid1 == -1)
			return -1;
		FileIDType fileid2 = EvaluatorClass::getFileID(((ComplexListNode *)((WitnessTree *)elem2)->getNodeByIndex(index2))->getFileIndex());
		if (fileid2 == -1)
			return -1;

		switch (gSortByDim[i])
		{
		case SORTBY_TEXT_NUM:
		case SORTBY_TEXT_STR:
			{
				int res1 = EvaluatorClass::GetText((WitnessTree *)elem1,index1,gdataMngCube,fileid1);
				int res2 = EvaluatorClass::GetText((WitnessTree *)elem2,index2,gdataMngCube,fileid2);
				if ((res1 == FAILURE  || res1 == 0) && (res2 == FAILURE  || res2 == 0))
					continue;
				if (res1 == FAILURE  || res1 == 0)
					return (-1*gWhereEmptyGoesDim[i]);

				if (res2 == FAILURE  || res2 == 0)
					return (gWhereEmptyGoesDim[i]);
				char *txt1 = ((DM_CharNode *)((ComplexListNode *)((WitnessTree *)elem1)->getNodeByIndex(res1))->GetData())->getCharValue();
				char *txt2 = ((DM_CharNode *)((ComplexListNode *)((WitnessTree *)elem2)->getNodeByIndex(res2))->GetData())->getCharValue();

				if (gSortByDim[i] == SORTBY_TEXT_NUM)
				{
					double num1 = atof(txt1);
					double num2 = atof(txt2);
					if (num1 == num2)
						continue;
					else
						return (int)(gOrderDim[i]* ceil(num1 - num2));
				}
				else
				{
					int r = strcmp(txt1,txt2);
					if (r == 0)
						continue;
					else
						return gOrderDim[i]*r;
				}
			}
			break;
		case SORTBY_ATTRIBUTE_NUM:
		case SORTBY_ATTRIBUTE_STR:
			{
				int res1 = EvaluatorClass::GetAttributes((WitnessTree *)elem1,index1,gdataMngCube,fileid1);
				int res2 = EvaluatorClass::GetAttributes((WitnessTree *)elem2,index2,gdataMngCube,fileid2);
				if (res1 == FAILURE && res2 == FAILURE)
					continue;
				if (res1 == FAILURE)
					return (-1*gWhereEmptyGoesDim[i]);

				if (res2 == FAILURE)
					return (gWhereEmptyGoesDim[i]);

				Value *val1 = ((DM_AttributeNode *)((ComplexListNode *)((WitnessTree *)elem1)->getNodeByIndex(index1+1))->GetData())->getAttr(gAttrNameDim[i]);
				Value *val2 = ((DM_AttributeNode *)((ComplexListNode *)((WitnessTree *)elem2)->getNodeByIndex(index2+1))->GetData())->getAttr(gAttrNameDim[i]);

				if (!val1 && !val2) 
					continue;

				if (!val1)
					return (-1*gWhereEmptyGoesDim[i]);
				if (!val2)
					return (gWhereEmptyGoesDim[i]);

				char *txt1 = val1->getStrValue();
				char *txt2 = val2->getStrValue();
				if (gSortByDim[i] == SORTBY_ATTRIBUTE_NUM)
				{
					double num1 = atof(txt1);
					double num2 = atof(txt2);
					if (num1 == num2)
						continue;
					else
						return (int)(gOrderDim[i]* ceil(num1 - num2));
				}
				else
				{
					int r = strcmp(txt1,txt2);
					if (r == 0)
						continue;
					else
						return gOrderDim[i]*r;
				}
			}
			break;
		case SORTBY_TAGNAME:
			{
				ComplexListNode *n1 = (ComplexListNode *)((WitnessTree *)elem1)->getNodeByIndex(index1);
				ComplexListNode *n2 = (ComplexListNode *)((WitnessTree *)elem2)->getNodeByIndex(index2);
				DM_DataNode *dn1 = n1->GetData();
				DM_DataNode *dn2 = n2->GetData();
				if (dn1 == NULL && dn2 == NULL)
					continue;
				if (dn1 == NULL)
					return -1*gWhereEmptyGoesDim[i];

				if (dn2 == NULL)
					return gWhereEmptyGoesDim[i];

				if (dn1->getFlag() != ELEMENT_NODE && dn2->getFlag() != ELEMENT_NODE)
					continue;

				if (dn1->getFlag() != ELEMENT_NODE)
					return (-1*gWhereEmptyGoesDim[i]);

				if (dn2->getFlag() != ELEMENT_NODE)
					return (gWhereEmptyGoesDim[i]);
				if (((DM_ElementNode *)dn1)->getTag() == ((DM_ElementNode *)dn2)->getTag())
					continue;

				char *tag1 = gdataMngCube->getPhysicalDataMng()->getXMLNameTable()->getNameByCode(((DM_ElementNode *)dn1)->getTag());
				char *tag2 = gdataMngCube->getPhysicalDataMng()->getXMLNameTable()->getNameByCode(((DM_ElementNode *)dn2)->getTag());
				int r = strcmp(tag1, tag2);
				if (r == 0)
					continue;
				else
					return gOrderDim[i] * r;
			}
			break;
		case SORTBY_VALUE_NUM:
		case SORTBY_VALUE_STR:
			{
				DM_DataNode *dn1 = ((ComplexListNode *)((WitnessTree *)elem1)->getNodeByIndex(index1))->GetData();
				DM_DataNode *dn2 = ((ComplexListNode *)((WitnessTree *)elem2)->getNodeByIndex(index2))->GetData();
				if (dn1 == NULL && dn2 == NULL)
					continue;
				if (dn1 == NULL)
					return -1*gWhereEmptyGoesDim[i];

				if (dn2 == NULL)
					return gWhereEmptyGoesDim[i];

				char *txt1;
				char *txt2;
				Value *val1;
				Value *val2;
				if (dn1->getFlag() == ELEMENT_NODE)
					txt1 = gdataMngCube->getPhysicalDataMng()->getXMLNameTable()->getNameByCode(((DM_ElementNode *)dn1)->getTag());

				else if (dn1->getFlag() == DOCUMENT_NODE)
				{
					if (((DM_DocumentNode *)dn1)->getXMLFileName())
						txt1 = ((DM_DocumentNode *)dn1)->getXMLFileName();
					else
						txt1 = NULL;
				}
				else if (dn1->getFlag() == ATTRIBUTE_NODE)
				{
					//if attribute node, return the value of attribute "attrName"

					val1 = ((DM_AttributeNode *)dn1)->getAttr(gAttrNameDim[i]);
					if (val1 != NULL)
					{
						if (val1->getStrValue() != NULL && strlen(val1->getStrValue()) != 0)
							txt1 = val1->getStrValue();
						else
							txt1 = NULL;
					}
					else
						txt1 = NULL;
				} 
				else
				{
					//if text node, return the text value
					if (((DM_CharNode *)dn1)->getCharValue())
						txt1 = ((DM_CharNode *)dn1)->getCharValue();
					else
						txt1 = NULL;
				}

				//getting second vLUES
				if (dn2->getFlag() == ELEMENT_NODE)
					txt2 = gdataMngCube->getPhysicalDataMng()->getXMLNameTable()->getNameByCode(((DM_ElementNode *)dn2)->getTag());

				else if (dn2->getFlag() == DOCUMENT_NODE)
				{
					if (((DM_DocumentNode *)dn2)->getXMLFileName())
						txt2 = ((DM_DocumentNode *)dn2)->getXMLFileName();
					else
						txt2 = NULL;
				}
				else if (dn2->getFlag() == ATTRIBUTE_NODE)
				{
					//if attribute node, return the value of attribute "attrName"

					val2 = ((DM_AttributeNode *)dn2)->getAttr(gAttrNameDim[i]);
					if (val2 != NULL)
					{
						if (val2->getStrValue() != NULL && strlen(val2->getStrValue()) != 0)
							txt2 = val2->getStrValue();
						else
							txt2 = NULL;
					}
					else
						txt2 = NULL;
				} 
				else
				{
					//if text node, return the text value
					if (((DM_CharNode *)dn2)->getCharValue())
						txt2 = ((DM_CharNode *)dn2)->getCharValue();
					else
						txt2 = NULL;
				}
				if (!txt1 && !txt2) 
					continue;

				if (!txt1)
					return (-1*gWhereEmptyGoesDim[i]);
				if (!txt2)
					return (gWhereEmptyGoesDim[i]);

				if (gSortByDim[i] == SORTBY_VALUE_NUM)
				{
					double num1 = atof(txt1);
					double num2 = atof(txt2);
					if (num1 == num2)
						continue;
					else
						return (int)(gOrderDim[i]* ceil(num1 - num2));
				}
				else
				{
					int r = strcmp(txt1,txt2);
					if (r == 0)
						continue;
					else
						return gOrderDim[i]*r;
				}

			}
			break;
		case SORT_BY_START_KEY:
			{
				KeyType sk1 = ((ComplexListNode *)((WitnessTree *)elem1)->getNodeByIndex(index1))->GetStartPos();
				KeyType sk2 = ((ComplexListNode *)((WitnessTree *)elem2)->getNodeByIndex(index2))->GetStartPos();
				if (sk1 == sk2)
					continue;
				else
				{
					if (sk1 < sk2)
						return (-1*gOrderDim[i]);
					else
						return (gOrderDim[i]);
				}
			}
			break;
		}
	}
	int n = ((WitnessTree *)elem1)->length() < ((WitnessTree *)elem2)->length()?
		((WitnessTree *)elem1)->length() : ((WitnessTree *)elem2)->length();
	for (int i=0; i<n; i++)
	{
		if (((ComplexListNode *)((WitnessTree *)elem1)->findNode(i))->GetStartPos() ==
			((ComplexListNode *)((WitnessTree *)elem2)->findNode(i))->GetStartPos())
			continue;
		else
		{
			if (((ComplexListNode *)((WitnessTree *)elem1)->findNode(i))->GetStartPos() <
				((ComplexListNode *)((WitnessTree *)elem2)->findNode(i))->GetStartPos())
				return -1;
			else
				return 1;
		}
	}
	if (((WitnessTree *)elem1)->length() < ((WitnessTree *)elem2)->length())
		return -1;
	else if (((WitnessTree *)elem1)->length() > ((WitnessTree *)elem2)->length())
		return 1;
	return 0;
}



CubeCounterBasedIterator::CubeCounterBasedIterator(IteratorClass *input, int sizeExpected, int cubeBy, int dimnum, NREType factNRE,
												   int factByWhat, char* factByAttrName, int factByOperation,
												   NREType factOpNRE, int factOpOnWhat, char* factOpOnWhatAttrName,
												   NREType *nre, bool** groupByRelaxType, NREType* subtreeParent,
												   int* groupByWhat, char** groupByAttrName, bool isAlreadySorted,												
												   DataMng *dataMng, char* fileName, EvaluatorClass* evalClass)
{
	this->cubeBy = cubeBy;
	this->dataMng = dataMng;
	this->fileName = fileName;
	gdataMngCube = dataMng;
	this->dimnum = dimnum;
	this->groupByWhat = groupByWhat;
	this->groupByRelaxType = groupByRelaxType;
	this->subtreeParent = subtreeParent;
	this->factNRE = factNRE;
	this->factByOperation = factByOperation;
	this->factOpNRE = factOpNRE;
	this->factOpOnWhat = factOpOnWhat;
	this->factOpOnWhatAttrName = factOpOnWhatAttrName;

	outputRecCounter = new OutputTreeRec[this->dimnum];
	//set initial output tree
	for (int i = 0; i < this->dimnum ; i++){
		outputRecCounter[i].anc = -1;
		outputRecCounter[i].rel = -1;
		outputRecCounter[i].value = NULL;
	}

	allCuboidValue = new CuboidValue;
	//profiling
	sizec = sizew = 0;
	this->input = input;

	size = 0;
	if (sizeExpected <= 0)
		sizeExpected = gSettings->getIntegerValue("INITIAL_DEFAULT_SORT_ARRAY_SIZE",INITIAL_SORT_ARRAY_SIZE_DEFAULT);
	sizeExpected++;
	sortArray = new WitnessTree[sizeExpected];

	this->input->next(inTuple);
	while (inTuple)
	{
		inTuple->switchToComplex(dataMng);
		sizew += sizeof(inTuple);
		sizew += 5*sizeof(ComplexListNode);
		sizew += 16*sizeof(char);
		if (size >= sizeExpected)
		{
			//if sortArray size is not enough-->double it
			WitnessTree *tmp = sortArray;
			sizeExpected *= 2;
			sortArray = new WitnessTree[sizeExpected];
			//memcpy(sortArray, tmp, size * sizeof(WitnessTree));
			//change to Glenn suggestion
			//
			// Copy old witness trees into new array, and allow
			// old tree's to be deleted. This fixes a memory leak.
			//
			for (int j = 0 ; j < size ; j++)
			{
				sortArray[j].copyTree(&tmp[j]) ;
				tmp[j].setDeleteBuffers(true) ;
			}
			//
			// Allow the old WitnessTrees to be deleted
			//
			delete [] tmp;
		}
		sortArray[size].copyTree(inTuple);
		sortArray[size].setDeleteBuffers(true);
		size++;


		//?? help decrease mem, crash here
		//delete inTuple;
		inTuple->deleteAllNodes();

		this->input->next(inTuple);
	}
	delete this->input;	


	//1.Sort data by factID, dimID...., if not already sorted
	int hereByWhat;
	//if (!isAlreadySorted) {

		gDimNum = dimnum+1;
		gCurrentDim = 0;
		gSortByDim = new int[dimnum+1];


		for (int i=0 ; i < dimnum + 1 ; i++)
		{
			if (i == 0) hereByWhat = factByWhat;
			else hereByWhat = groupByWhat[i-1];

			if (hereByWhat == GROUPBY_ATTRIBUTE_NUM) gSortByDim[i] = SORTBY_ATTRIBUTE_NUM;
			else if (hereByWhat == GROUPBY_ATTRIBUTE_STR) gSortByDim[i] = SORTBY_ATTRIBUTE_STR;
			else if (hereByWhat == GROUPBY_TEXT_NUM) gSortByDim[i] = SORTBY_TEXT_NUM;
			else if (hereByWhat == GROUPBY_TEXT_STR) gSortByDim[i] = SORTBY_TEXT_STR;
			else if (hereByWhat == GROUPBY_STARTKEY) gSortByDim[i] = SORT_BY_START_KEY;
			else if (hereByWhat == GROUPBY_VALUE_NUM) gSortByDim[i] = SORTBY_VALUE_NUM;
			else if (hereByWhat == GROUPBY_VALUE_STR) gSortByDim[i] = SORTBY_VALUE_STR;
		}

		//have to combine nre array and group by information to sort
		// maybe faster if we push this up by doing it before we call iterator, so all algorithms have the same cost
		gNREDim = new NREType[dimnum +1];
		gNREDim[0] = factNRE;
		for (int i=1 ; i < dimnum + 1 ; i++)
		{
			gNREDim[i] = nre[i-1];
		}

		gAttrNameDim = new char*[dimnum+1];
		gAttrNameDim[0] = new char[strlen(factByAttrName)+1];
		strcpy(gAttrNameDim[0],factByAttrName);
		for (int i=1 ; i < dimnum + 1 ; i++)
		{
			gAttrNameDim[i] = new char[strlen(groupByAttrName[i-1])+1];
			strcpy(gAttrNameDim[i],groupByAttrName[i-1]);
		}

		gOrderDim = new int[dimnum+1];

		for (int i=0 ; i < dimnum + 1 ; i++)
		{
			gOrderDim[i] = ASCENDING;
		}


		gWhereEmptyGoesDim = new int[dimnum+1];

		for (int i=0 ; i < dimnum + 1 ; i++)
		{
			gWhereEmptyGoesDim[i] = EMPTY_AT_END;
		}

		clock_t starttime, finishtime; 
		double duration;
		starttime = clock();



		EvalQuickSort s;
		//cout << endl << "--Sort on dimension--" << d << " up" << endl << endl;
		if (s.quickSort(sortArray,0,size-1,compareCubeNodesValSort) == FAILURE) {
			size = 0;
			return;
		}
		finishtime = clock();
		duration = (double)(finishtime - starttime) / CLOCKS_PER_SEC;
		cout << duration << " seconds to sort " << endl;

		delete [] gNREDim;
		delete [] gAttrNameDim;
		delete [] gOrderDim;
		delete [] gWhereEmptyGoesDim;
		delete [] gSortByDim;
	//}

	//2. Set global sort information for later sorting
	gDimNum = dimnum;
	gNREDim = nre;	
	gAttrNameDim = groupByAttrName;


	gSortByDim = new int[dimnum];
	//for global sort by, for later operation
	for (int i=0 ; i < dimnum ; i++)
	{
		hereByWhat = groupByWhat[i];

		if (hereByWhat == GROUPBY_ATTRIBUTE_NUM) gSortByDim[i] = SORTBY_ATTRIBUTE_NUM;
		else if (hereByWhat == GROUPBY_ATTRIBUTE_STR) gSortByDim[i] = SORTBY_ATTRIBUTE_STR;
		else if (hereByWhat == GROUPBY_TEXT_NUM) gSortByDim[i] = SORTBY_TEXT_NUM;
		else if (hereByWhat == GROUPBY_TEXT_STR) gSortByDim[i] = SORTBY_TEXT_STR;
		else if (hereByWhat == GROUPBY_STARTKEY) gSortByDim[i] = SORT_BY_START_KEY;
		else if (hereByWhat == GROUPBY_VALUE_NUM) gSortByDim[i] = SORTBY_VALUE_NUM;
		else if (hereByWhat == GROUPBY_VALUE_STR) gSortByDim[i] = SORTBY_VALUE_STR;
	}

	gOrderDim = new int[dimnum];
	for (int i=0 ; i < dimnum ; i++)
	{
		gOrderDim[i] = ASCENDING;
	}

	gWhereEmptyGoesDim = new int[dimnum];
	for (int i=0 ; i < dimnum ; i++)
	{
		gWhereEmptyGoesDim[i] = EMPTY_AT_END;
	}

	char* oldPartitionValue = NULL;
	char* thisPartitionValue = NULL;
	int partitionStartIndex = 0; //real index 


//	clock_t starttime, finishtime; 
//	double duration;
	starttime = clock();
	int k = 0;
	for (k = 0 ; k < size ; k++) { //go through each tuple

		//get the value of the current fact id
		//if it start a new partition, stop and do the recursive function

		int success = this->getNodeValue(&sortArray[k],factNRE,factByAttrName,factByWhat,thisPartitionValue);
		if (success == FAILURE){
			//???? is this always true? what if fact attribute is missing, possible?
			//size = 0;
			//in DBLP, fact id is possibly missing, so just by pass
			//thisPartitionValue = NULL;
			//globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"Evaluator",__FILE__,"Can't get the required node value - Cube Iterator");
			//return;
			if (strcmp(thisPartitionValue,"NULL") != 0){
				thisPartitionValue = new char[5];
				strcpy(thisPartitionValue,"NULL");
			}
		}

		if ((oldPartitionValue != NULL) && (thisPartitionValue != NULL) && (strcmp(oldPartitionValue,thisPartitionValue) !=0))
		{
			//process old partition
			//cout << oldPartitionValue << "from size" << partitionStartIndex << "to size" << size-2 << endl;
			//compute ALL cuboid
			this->computeAllCuboid(&sortArray[partitionStartIndex]);
			this->CubePartition(sortArray,partitionStartIndex, k-1, 0, -1);
			//start new partition
			partitionStartIndex = k;
			if (factByWhat == GROUPBY_STARTKEY){
				delete [] oldPartitionValue;
			}
			oldPartitionValue = thisPartitionValue;

		}
		oldPartitionValue = thisPartitionValue;
	}
	//process the last partition
	//compute ALL cuboid
	this->computeAllCuboid(&sortArray[partitionStartIndex]);
	if (thisPartitionValue != NULL) {
		this->CubePartition(sortArray,partitionStartIndex, k-1, 0, -1);
		if (factByWhat == GROUPBY_STARTKEY){
			delete [] thisPartitionValue;
			thisPartitionValue = NULL;
		}
		//cout << oldPartitionValue << "from size" << partitionStartIndex-1 << "to size" << size-1 << endl;
	}

	if ((thisPartitionValue != NULL) && (strcmp(thisPartitionValue,"NULL") == 0))
		delete [] thisPartitionValue;

	finishtime = clock();
	duration = (double)(finishtime - starttime) / CLOCKS_PER_SEC;
	cout << duration << " seconds to compute Cube" << endl;
	if (nre) delete [] nre;
	if (groupByWhat) delete  [] groupByWhat;
	if (factByAttrName) delete [] factByAttrName;
	if (groupByAttrName)
	{
		for (int i=0; i< dimnum; i++)
			if (groupByAttrName[i])
				delete [] groupByAttrName[i];
		delete [] groupByAttrName;
	} 
	if (groupByRelaxType) {
		for (int i=0; i< dimnum; i++)
			delete [] groupByRelaxType[i];
		delete [] groupByRelaxType;
	}
	if (subtreeParent) delete [] subtreeParent;
	if (factOpOnWhatAttrName) delete [] factOpOnWhatAttrName;
}//end constructor


CubeCounterBasedIterator::~CubeCounterBasedIterator()
{
	delete [] sortArray;
	//delete resultBuffer;
	delete [] gSortByDim;
	delete [] gWhereEmptyGoesDim;
	delete [] gOrderDim;
	if (fileName) delete [] fileName;
	if (outputRecCounter)
	{
		delete [] outputRecCounter;
	} 
}

void CubeCounterBasedIterator::next(WitnessTree *&node)
{	
#ifdef EVAL_TIME_OUT
	clock_t currTime = clock();
	double queryDuration = (double)(currTime - gQueryStartTime) / CLOCKS_PER_SEC;
	if (queryDuration >= gTimeOutAfter)
	{
		globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"Evaluator",__FILE__,"Query Timed Out. Cube");
		node = NULL;
		return;		
	}
#endif

	this->writeOutput();
	node = NULL;
	return;
}

/**
start is the index (real index start from 0) of the partition
end is the index
current_dim is the index of dimension (real index start from 0)
**/
void CubeCounterBasedIterator::CubePartition(WitnessTree* input, int start, int end, int current_dim, int old_dim)
{
#ifdef EVAL_TIME_OUT
	clock_t currTime = clock();
	double queryDuration = (double)(currTime - gQueryStartTime) / CLOCKS_PER_SEC;
	if (queryDuration >= gTimeOutAfter)
	{
		globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"Evaluator",__FILE__,"Query Timed Out. Cube");
		node = NULL;
		return;		
	}
#endif
	for (int i = current_dim ; i < this->dimnum ; i++){

		//memory optimization
		//do 0 x x, ... only
		if ((old_dim == -1) && (i > gSettings->getIntegerValue("DIM_LIMIT"))) return;

		//do from 0.2, and do only starting 0
		//if ((old_dim ==0) && (i < 2)) continue;		
		//if ((old_dim == -1) && (i != 0)) return;
		
		//do only 0.2
		//if ((old_dim ==0) && (i < 2)) continue;	
		//if ((old_dim ==0) && (i > 2)) return;
		//if ((old_dim == -1) && (i != 0)) return;

		//do only 0, 0.1,0.1.2, not doing 0.2,0.3 and else
		//if ((old_dim ==0) && (i > 1)) return;
		//if ((old_dim == -1) && (i != 0)) return;

		gCurrentDim = i;
		if ((i != old_dim+1) && (start != end)) { 
			//if it's not the consecutive level, which is already sorted by what we want
			//and not having only 1 tuple tree (it's 1 tree why do we have to sort :-)
			//sort partition according to current_dim to dimnum
			EvalQuickSort s;
			//cout << endl << "--Sort on dimension--" << i << " up" << endl << endl;
			if (s.quickSort(input,start,end,compareCubeNodesValSort) == FAILURE) {
				size = 0;
				return;
			}
		}
		//for each partition of current_dim's value
		int i1 = start;
		char* oldPartitionValue = NULL;
		char* thisPartitionValue = NULL;
		int partitionStartIndex = start;
		int partitionEndIndex = end;
		while (i1 <= end) {
			int success = this->getNodeValue(&input[i1], gNREDim[i], gAttrNameDim[i], this->groupByWhat[i],thisPartitionValue);
			if (success == FAILURE) { //this maybe the missing dimension, so just ignore and cont
				//???? is this always true, what if the missing is not the last partition????
				//should not be, b/c we always sort, and let ALL as the last value
				//size = 0;
				i1 = end+1;
				oldPartitionValue = NULL;
				continue;
			}

			if ((oldPartitionValue != NULL) && (strcmp(oldPartitionValue,thisPartitionValue) !=0))
			{
				//process old partition
				//cout << oldPartitionValue << " from size " << partitionStartIndex << " to size " << i1-1 << endl;					
				partitionEndIndex = i1-1;
				for (int g = 0 ; g < 4 ; g++)
				{
					if (this->groupByRelaxType[i][g] == true) //if relaxable
					{
						if (g == 0) //LND-AD 
						{
							//if d's value != EMPTY, which is always the case
							outputRecCounter[i].value = oldPartitionValue;
							outputRecCounter[i].rel = ANCS_DESC;
							outputRecCounter[i].anc = -1;
						
								this->constructAndInsertCuboid(&input[i1-1]);
							if (i < gDimNum -1) //only if not last dimension
								this->CubePartition(input,partitionStartIndex, i1-1, i+1, i);
						}
						else if (g == 1) //LND-PC, PC-AD
						{
							//resort by PC of this axis, next axis up by value
							partitionEndIndex = this->moveRelevantToFront(partitionStartIndex, partitionEndIndex, i, PARENT_CHILD, this->factNRE);
							if (partitionEndIndex != -1) //if it's -1, means no trees satisfy this condition
							{
								outputRecCounter[i].value = oldPartitionValue;
								outputRecCounter[i].rel = PARENT_CHILD;
								outputRecCounter[i].anc = -1;
								
								this->constructAndInsertCuboid(&input[partitionEndIndex]);
								if (i < gDimNum -1) //only if not last dimension
									this->CubePartition(input,partitionStartIndex, partitionEndIndex, i+1, i);
							}
						}
						else if (g == 2) //SP-AD
						{		
							//resort by PC of this axis, next axis up by value
							partitionEndIndex = this->moveRelevantToFront(partitionStartIndex, partitionEndIndex, i, ANCS_DESC, this->subtreeParent[i]);
							if (partitionEndIndex != -1) //if it's -1, means no trees satisfy this condition
							{
								outputRecCounter[i].value = oldPartitionValue;
								outputRecCounter[i].rel = ANCS_DESC;
								outputRecCounter[i].anc = this->subtreeParent[i];
								
								this->constructAndInsertCuboid(&input[partitionEndIndex]);
								if (i < gDimNum -1) //only if not last dimension
									this->CubePartition(input,partitionStartIndex, partitionEndIndex, i+1, i);
							}
						}
						else if (g == 3) //SP-PC
						{
							partitionEndIndex = this->moveRelevantToFront(partitionStartIndex, partitionEndIndex, i, PARENT_CHILD, this->subtreeParent[i]);
							if (partitionEndIndex != -1) //if it's -1, means no trees satisfy this condition
							{
								outputRecCounter[i].value = oldPartitionValue;
								outputRecCounter[i].rel = PARENT_CHILD;
								outputRecCounter[i].anc = this->subtreeParent[i];
							
								this->constructAndInsertCuboid(&input[partitionEndIndex]);
								if (i < gDimNum -1) //only if not last dimension
									this->CubePartition(input,partitionStartIndex, partitionEndIndex, i+1, i);
							}
						}
					}

				}//for each relaxation
				//start new partition
				partitionStartIndex = i1;

			}
			oldPartitionValue = thisPartitionValue;

			i1++;
		}//while
		//do the last partition
		if(oldPartitionValue != NULL){
			//process old partition
			//cout << oldPartitionValue << " from size " << partitionStartIndex << " to size " << i1-1 << endl;
			partitionEndIndex = i1-1;
			for (int g = 0 ; g < 4 ; g++)
			{
				if (this->groupByRelaxType[i][g] == true) //if relaxable
				{
					if (g == 0) //LND-AD 
					{
						//if d's value != EMPTY, which is always the case
						outputRecCounter[i].value = oldPartitionValue;
						outputRecCounter[i].rel = ANCS_DESC;
						outputRecCounter[i].anc = -1;
		
						this->constructAndInsertCuboid(&input[i1-1]);
						if (i < gDimNum -1) //only if not last dimension
							this->CubePartition(input,partitionStartIndex, i1-1, i+1, i);
					}
					else if (g == 1) //LND-PC, PC-AD
					{
						//resort by PC of this axis, next axis up by value
						partitionEndIndex = this->moveRelevantToFront(partitionStartIndex, partitionEndIndex, i, PARENT_CHILD, this->factNRE);
						if (partitionEndIndex != -1) //if it's -1, means no trees satisfy this condition
						{
							outputRecCounter[i].value = oldPartitionValue;
							outputRecCounter[i].rel = PARENT_CHILD;
							outputRecCounter[i].anc = -1;
							
							this->constructAndInsertCuboid(&input[partitionEndIndex]);
							if (i < gDimNum -1) //only if not last dimension
								this->CubePartition(input,partitionStartIndex, partitionEndIndex, i+1, i);
						}
					}
					else if (g == 2) //SP-AD
					{		
						//resort by PC of this axis, next axis up by value
						partitionEndIndex = this->moveRelevantToFront(partitionStartIndex, partitionEndIndex, i, ANCS_DESC, this->subtreeParent[i]);
						if (partitionEndIndex != -1) //if it's -1, means no trees satisfy this condition
						{
							outputRecCounter[i].value = oldPartitionValue;
							outputRecCounter[i].rel = ANCS_DESC;
							outputRecCounter[i].anc = this->subtreeParent[i];
							
							this->constructAndInsertCuboid(&input[partitionEndIndex]);
							if (i < gDimNum -1) //only if not last dimension
								this->CubePartition(input,partitionStartIndex, partitionEndIndex, i+1, i);
						}
					}
					else if (g == 3) //SP-PC
					{
						partitionEndIndex = this->moveRelevantToFront(partitionStartIndex, partitionEndIndex, i, PARENT_CHILD, this->subtreeParent[i]);
						if (partitionEndIndex != -1) //if it's -1, means no trees satisfy this condition
						{
							outputRecCounter[i].value = oldPartitionValue;
							outputRecCounter[i].rel = PARENT_CHILD;
							outputRecCounter[i].anc = this->subtreeParent[i];
							
							this->constructAndInsertCuboid(&input[partitionEndIndex]);
							if (i < gDimNum -1) //only if not last dimension
								this->CubePartition(input,partitionStartIndex, partitionEndIndex, i+1, i);
						}
					}
				}

			}//for each relaxation

		}//end do last partition
		outputRecCounter[i].rel = -1; //clear

	}
}

int CubeCounterBasedIterator::getNodeValue(WitnessTree* elem1, NREType nre, char* attrName, int nodeGroupByType, char*& charValue)
{
	int index1 = ((WitnessTree *)elem1)->getIndexOfNRE(nre);
	if (index1 == FAILURE)
		return FAILURE;

	FileIDType fileid1 = EvaluatorClass::getFileID(((ComplexListNode *)((WitnessTree *)elem1)->getNodeByIndex(index1))->getFileIndex());
	if (fileid1 == -1)
		return -1;

	switch (nodeGroupByType)
	{
	case GROUPBY_TEXT_NUM:
	case GROUPBY_TEXT_STR:
		{
			int res1 = EvaluatorClass::GetText((WitnessTree *)elem1,index1,this->dataMng,fileid1);
			if (res1 == FAILURE) return FAILURE;
			charValue = ((DM_CharNode *)((ComplexListNode *)((WitnessTree *)elem1)->getNodeByIndex(res1))->GetData())->getCharValue();


		}
		break;
	case GROUPBY_ATTRIBUTE_NUM:
	case GROUPBY_ATTRIBUTE_STR:
		{
			int res1 = EvaluatorClass::GetAttributes((WitnessTree *)elem1,index1,this->dataMng,fileid1);
			if (res1 == FAILURE) return FAILURE;

			Value *val1 = ((DM_AttributeNode *)((ComplexListNode *)((WitnessTree *)elem1)->getNodeByIndex(index1+1))->GetData())->getAttr(attrName);
			if (!val1) return FAILURE;

			charValue = val1->getStrValue();

		}
		break;
	case GROUPBY_VALUE_NUM:
	case GROUPBY_VALUE_STR:
		{
			DM_DataNode *dn1 = ((ComplexListNode *)((WitnessTree *)elem1)->getNodeByIndex(index1))->GetData();
			if (dn1 == NULL)
				return FAILURE;

			if (dn1->getFlag() == ELEMENT_NODE)
				charValue = this->dataMng->getPhysicalDataMng()->getXMLNameTable()->getNameByCode(((DM_ElementNode *)dn1)->getTag());

			else if (dn1->getFlag() == DOCUMENT_NODE)
			{
				if (((DM_DocumentNode *)dn1)->getXMLFileName())
					charValue = ((DM_DocumentNode *)dn1)->getXMLFileName();
				else {
					charValue = NULL;
					return FAILURE;
				}
			}
			else if (dn1->getFlag() == ATTRIBUTE_NODE)
			{
				//if attribute node, return the value of attribute "attrName"

				Value* val1 = ((DM_AttributeNode *)dn1)->getAttr(attrName);
				if (!val1) return FAILURE;

				charValue = val1->getStrValue();

			} 
			else
			{
				//if text node, return the text value
				charValue = ((DM_CharNode *)dn1)->getCharValue();
			}

		}
		break;
	case GROUPBY_STARTKEY:
		{
			charValue = ((ComplexListNode *)((WitnessTree *)elem1)->getNodeByIndex(index1))->GetStartPos().toString();
		}
		break;
	}//switch
	return SUCCESS;

}

int CubeCounterBasedIterator::getNodeValue(WitnessTree* elem1, NREType factOpNRE, int factOpOnWhat, char* factOpAttrName, double* retValue)
{
	int index1 = ((WitnessTree *)elem1)->getIndexOfNRE(factOpNRE);
	if (index1 == FAILURE)
		return FAILURE;

	FileIDType fileid1 = EvaluatorClass::getFileID(((ComplexListNode *)((WitnessTree *)elem1)->getNodeByIndex(index1))->getFileIndex());
	if (fileid1 == -1)
		return FAILURE;

	switch (factOpOnWhat)
	{
	case ON_ATTRIBUTE_NUM:
		{
			int res1 = EvaluatorClass::GetAttributes((WitnessTree *)elem1,index1,this->dataMng,fileid1);
			if (res1 == FAILURE) return FAILURE;

			Value *val1 = ((DM_AttributeNode *)((ComplexListNode *)((WitnessTree *)elem1)->getNodeByIndex(index1+1))->GetData())->getAttr(factOpAttrName);
			if (!val1) return FAILURE;

			*retValue = val1->getRealValue();
		}
		break;
	case ON_TEXT_NUM:
		{
			int res1 = EvaluatorClass::GetText((WitnessTree *)elem1,index1,this->dataMng,fileid1);
			if (res1 == FAILURE) return FAILURE;
			*retValue = atof(((DM_CharNode *)((ComplexListNode *)((WitnessTree *)elem1)->getNodeByIndex(res1))->GetData())->getCharValue());
		}
		break;
	case ON_VALUE_NUM:
		{
			DM_DataNode *dn1 = ((ComplexListNode *)((WitnessTree *)elem1)->getNodeByIndex(index1))->GetData();
			if (dn1 == NULL)
				return FAILURE;

			if (dn1->getFlag() == ELEMENT_NODE)
				*retValue = (double)(((DM_ElementNode *)dn1)->getTag());

			else if (dn1->getFlag() == ATTRIBUTE_NODE)
			{
				//if attribute node, return the value of attribute "attrName"

				Value* val1 = ((DM_AttributeNode *)dn1)->getAttr(factOpAttrName);
				if (!val1) return FAILURE;

				*retValue = val1->getRealValue();

			} 
			else
			{
				//if text node, return the text value
				*retValue = atof(((DM_CharNode *)dn1)->getCharValue());
			}
		}
		break;
	}
	return SUCCESS;
}

void CubeCounterBasedIterator::constructAndInsertCuboid(WitnessTree* treeInput)
{
	Cuboid* thisCuboid = new Cuboid;
	double sizeb = 0;

	for (int i =0 ; i < this->dimnum ;i++){
		if (outputRecCounter[i].rel != -1){ //if it's not cleared (leaf deleted)
			char* newDimNameCurrent;
			if(outputRecCounter[i].value != NULL) {
				newDimNameCurrent = new char[strlen(outputRecCounter[i].value)+1];
				strcpy(newDimNameCurrent,outputRecCounter[i].value);
			}
			else {
				newDimNameCurrent = new char[5];
				strcpy(newDimNameCurrent,"NULL");
			}
			thisCuboid->push_back(newDimNameCurrent);
			char* newDimRel1 = new char[2];
			itoa(outputRecCounter[i].rel,newDimRel1,10);
			thisCuboid->push_back(newDimRel1);
			char* newDimAnc1 = new char[3];
			itoa(outputRecCounter[i].anc,newDimAnc1,10);
			thisCuboid->push_back(newDimAnc1);
			sizeb = sizeb + 3*sizeof(newDimNameCurrent) + (strlen(newDimNameCurrent)+5)*sizeof(char);//p
		}
		else {
			char* newDimNull = new char[4];
			strcpy(newDimNull,"ALL");
			thisCuboid->push_back(newDimNull);
			char* newDimRel = new char[2];
			strcpy(newDimRel,"0");
			thisCuboid->push_back(newDimRel);
			char* newDimAnc = new char[2];
			strcpy(newDimAnc,"0");
			thisCuboid->push_back(newDimAnc);
			sizeb = sizeb + 3*sizeof(char*) + 8*sizeof(char);//p
		}
	}


	sizeb = sizeb + sizeof(thisCuboid);//p

	CuboidValue* thisCuboidValue;

	double aggrValue;
	cubeIter = cubeResult.find(thisCuboid);
	if (cubeIter != cubeResult.end()) { //already found in cube
		thisCuboidValue = (*cubeIter).second;
		switch (this->factByOperation)
		{
		case OP_COUNT:
			{
				thisCuboidValue->at(0) = thisCuboidValue->at(0)+1;
			}
			break;
		case OP_SUM:
			{
				int ret = this->getNodeValue(treeInput,this->factOpNRE,this->factOpOnWhat,this->factOpOnWhatAttrName,&aggrValue);
				if (ret == FAILURE) return;
				thisCuboidValue->at(0) = thisCuboidValue->at(0)+ aggrValue;
			}
			break;
		case OP_AVG:
			{
				int ret = this->getNodeValue(treeInput,this->factOpNRE,this->factOpOnWhat,this->factOpOnWhatAttrName,&aggrValue);
				if (ret == FAILURE) return;
				thisCuboidValue->at(0) = thisCuboidValue->at(0)+ aggrValue;
				thisCuboidValue->at(1) = thisCuboidValue->at(1)+ 1;
			}
			break;
		case OP_MIN:
			{
				int ret = this->getNodeValue(treeInput,this->factOpNRE,this->factOpOnWhat,this->factOpOnWhatAttrName,&aggrValue);
				if (ret == FAILURE) return;
				if (aggrValue < thisCuboidValue->at(0))
					thisCuboidValue->at(0) = aggrValue;
			}
			break;
		case OP_MAX:
			{
				int ret = this->getNodeValue(treeInput,this->factOpNRE,this->factOpOnWhat,this->factOpOnWhatAttrName,&aggrValue);
				if (ret == FAILURE) return;
				if (thisCuboidValue->at(0) < aggrValue)
					thisCuboidValue->at(0) = aggrValue;
			}
			break;
		default:
			globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"Evaluator",__FILE__,"Undefined aggregate operation passed to cube iterator.");
			return;
		}
		for (unsigned int j = 0 ; j < thisCuboid->size() ; j++) {
			delete [] thisCuboid->at(j);
		}
		delete thisCuboid;
	}
	else {
		thisCuboidValue = new CuboidValue;
		sizec = sizec + sizeof(thisCuboidValue);//p
		sizec = sizec + sizeb;
		switch (this->factByOperation)
		{
		case OP_COUNT:
			{
				thisCuboidValue->push_back(1);
				sizec = sizec + sizeof(double);//p
			}
			break;
		case OP_SUM:
		case OP_MIN:
		case OP_MAX:
			{
				int ret = this->getNodeValue(treeInput,this->factOpNRE,this->factOpOnWhat,this->factOpOnWhatAttrName,&aggrValue);
				if (ret == FAILURE) return;
				thisCuboidValue->push_back(aggrValue);
				sizec = sizec + sizeof(double);//p
			}
			break;
		case OP_AVG:
			{
				int ret = this->getNodeValue(treeInput,this->factOpNRE,this->factOpOnWhat,this->factOpOnWhatAttrName,&aggrValue);
				if (ret == FAILURE) return;
				thisCuboidValue->push_back(aggrValue); //sum
				thisCuboidValue->push_back(1); //count
				sizec = sizec + sizeof(double);//p
				sizec = sizec + sizeof(double);//p
			}
			break;
		default:
			globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"Evaluator",__FILE__,"Undefined aggregate operation passed to cube iterator.");
			return;
		}

		cubeResult.insert(Map_Cuboid_To_Value::value_type(thisCuboid,thisCuboidValue));
	}

	return;
}

void CubeCounterBasedIterator::computeAllCuboid(WitnessTree* treeInput)
{
	double aggrValue;
	if (this->allCuboidValue->size() > 0) { //not the first fact item

		switch (this->factByOperation)
		{
		case OP_COUNT:
			{
				allCuboidValue->at(0) = allCuboidValue->at(0)+1;
			}
			break;
		case OP_SUM:
			{
				int ret = this->getNodeValue(treeInput,this->factOpNRE,this->factOpOnWhat,this->factOpOnWhatAttrName,&aggrValue);
				if (ret == FAILURE) return;
				allCuboidValue->at(0) = allCuboidValue->at(0)+ aggrValue;
			}
			break;
		case OP_AVG:
			{
				int ret = this->getNodeValue(treeInput,this->factOpNRE,this->factOpOnWhat,this->factOpOnWhatAttrName,&aggrValue);
				if (ret == FAILURE) return;
				allCuboidValue->at(0) = allCuboidValue->at(0)+ aggrValue;
				allCuboidValue->at(1) = allCuboidValue->at(1)+ 1;
			}
			break;
		case OP_MIN:
			{
				int ret = this->getNodeValue(treeInput,this->factOpNRE,this->factOpOnWhat,this->factOpOnWhatAttrName,&aggrValue);
				if (ret == FAILURE) return;
				if (aggrValue < allCuboidValue->at(0))
					allCuboidValue->at(0) = aggrValue;
			}
			break;
		case OP_MAX:
			{
				int ret = this->getNodeValue(treeInput,this->factOpNRE,this->factOpOnWhat,this->factOpOnWhatAttrName,&aggrValue);
				if (ret == FAILURE) return;
				if (allCuboidValue->at(0) < aggrValue)
					allCuboidValue->at(0) = aggrValue;
			}
			break;
		default:
			globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"Evaluator",__FILE__,"Undefined aggregate operation passed to cube iterator.");
			return;
		}

	}
	else {

		switch (this->factByOperation)
		{
		case OP_COUNT:
			{
				allCuboidValue->push_back(1);
			}
			break;
		case OP_SUM:
		case OP_MIN:
		case OP_MAX:
			{
				int ret = this->getNodeValue(treeInput,this->factOpNRE,this->factOpOnWhat,this->factOpOnWhatAttrName,&aggrValue);
				if (ret == FAILURE) return;
				allCuboidValue->push_back(aggrValue);
			}
			break;
		case OP_AVG:
			{
				int ret = this->getNodeValue(treeInput,this->factOpNRE,this->factOpOnWhat,this->factOpOnWhatAttrName,&aggrValue);
				if (ret == FAILURE) return;
				allCuboidValue->push_back(aggrValue); //sum
				allCuboidValue->push_back(1); //count
			}
			break;
		default:
			globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"Evaluator",__FILE__,"Undefined aggregate operation passed to cube iterator.");
			return;
		}
	}
}

void CubeCounterBasedIterator::writeOutput()
{
	//go through cuboid
	output = fopen(this->fileName,"w");

	Map_Cuboid_To_Value::const_iterator cur  = cubeResult.begin();
	while (cur != cubeResult.end()){
		Cuboid* thisCuboid = (*cur).first;
		for (unsigned int i =0 ; i < thisCuboid->size();i = i+3){
			//cout << thisCuboid->at(i) << "\t";
			char* cubeDimVal = thisCuboid->at(i);
			char* cubeDimRel = thisCuboid->at(i+1);
			char* cubeDimAncNRE = thisCuboid->at(i+2);
			if (strcmp("ALL",cubeDimVal) == 0)
				fprintf(output,"%s      \t",cubeDimVal);
			else
				fprintf(output,"%s %s %s\t",cubeDimVal, cubeDimRel, cubeDimAncNRE);
			//delete [] thisCuboid->at(i);
		}
		CuboidValue* thisCuboidValue = (*cur).second;
		switch (this->factByOperation)
		{
		case OP_COUNT:
			{
				//cout << " = " << thisCuboidValue->at(0) << endl;
				int cubeAggr = (int)thisCuboidValue->at(0);
				fprintf(output,"%d\n",cubeAggr);
			}
			break;
		case OP_SUM:
		case OP_MIN:
		case OP_MAX:
			{
				//cout << " = " << thisCuboidValue->at(0) << endl;
				double cubeAggr = thisCuboidValue->at(0);
				fprintf(output,"%lf\n",cubeAggr);
			}
			break;
		case OP_AVG:
			{
				//cout << " = " << thisCuboidValue->at(0) << " / " << thisCuboidValue->at(1) << endl;
				double cubeAggr1 = thisCuboidValue->at(0);
				int cubeAggr2 = (int)thisCuboidValue->at(1);
				fprintf(output,"%lf / %d\n",cubeAggr1,cubeAggr2);
			}
			break;
		default:
			globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"Evaluator",__FILE__,"Undefined aggregate operation passed to cube iterator.");
			return;

		}
		//clear memory
		for (unsigned int j = 0 ; j < thisCuboid->size() ; j++) {
			delete [] thisCuboid->at(j);
		}
		delete thisCuboid;
		delete thisCuboidValue;
		++cur;
	}

	//print all cuboid
	fprintf(output,"ALL\t");
	switch (this->factByOperation)
	{
	case OP_COUNT:
		{
			int cubeAggr = (int)allCuboidValue->at(0);
			fprintf(output,"%d\n",cubeAggr);
		}
		break;
	case OP_SUM:
	case OP_MIN:
	case OP_MAX:
		{
			double cubeAggr = allCuboidValue->at(0);
			fprintf(output,"%lf\n",cubeAggr);
		}
		break;
	case OP_AVG:
		{
			double cubeAggr1 = allCuboidValue->at(0);
			int cubeAggr2 = (int)allCuboidValue->at(1);
			fprintf(output,"%lf / %d\n",cubeAggr1,cubeAggr2);
		}
		break;
	default:
		globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"Evaluator",__FILE__,"Undefined aggregate operation passed to cube iterator.");
		return;

	}
	delete allCuboidValue;
	fclose(output);
	cout << "Number of counters(cube) = " << cubeResult.size() << endl;
	cout << "Size of counters = " << sizec << endl;
	cout << "Size of witness trees = " << sizew << endl;
}

//return the index of the last one that is relevant
int CubeCounterBasedIterator::moveRelevantToFront(int start, int end, int dim, int relationship, NREType ancNRE)
{
	int first = -1; // is the first non-Inplace for the current order
	int lastRelevant = -1;
	WitnessTree temp;

	for (int i= start ; i<= end ; i++)
	{
		int index1 = ((WitnessTree *)&sortArray[i])->getIndexOfNRE(gNREDim[dim]);
		int indexp1 = ((WitnessTree *)&sortArray[i])->getIndexOfNRE(ancNRE);
		int levp1 = ((ComplexListNode *)((WitnessTree *)&sortArray[i])->getNodeByIndex(indexp1))->GetLevel();
		int lev1 = ((ComplexListNode *)((WitnessTree *)&sortArray[i])->getNodeByIndex(index1))->GetLevel();
		KeyType sp1 = ((ComplexListNode *)((WitnessTree *)&sortArray[i])->getNodeByIndex(indexp1))->GetStartPos();
		KeyType ep1 = ((ComplexListNode *)((WitnessTree *)&sortArray[i])->getNodeByIndex(indexp1))->GetEndPos();
		KeyType s1 = ((ComplexListNode *)((WitnessTree *)&sortArray[i])->getNodeByIndex(index1))->GetStartPos();
		KeyType e1 = ((ComplexListNode *)((WitnessTree *)&sortArray[i])->getNodeByIndex(index1))->GetEndPos();
		if (relationship == PARENT_CHILD){

			if (lev1 == levp1+1 && sp1 < s1 && ep1 > e1 && (first == -1 || first > i)) 
				lastRelevant = i;
			else if ((lev1 != levp1+1 || sp1 >= s1 || ep1 <= e1) && first == -1)
				first = i;
			else if (lev1 == levp1+1 && sp1 < s1 && ep1 > e1 && first != -1  && first < i){
				//swap
				temp.copyTree(&sortArray[i]); 
				sortArray[i].copyTree(&sortArray[first]);
				sortArray[first].copyTree(&temp);
				i= first;
				lastRelevant = first;
				first = -1;
			}
		}
		else if (relationship == ANCS_DESC){

			if (sp1 < s1 && ep1 > e1 && (first == -1 || first > i)) 
				lastRelevant = i;
			else if ((sp1 >= s1 || ep1 <= e1) && first == -1)
				first = i;
			else if (sp1 < s1 && ep1 > e1 && first != -1  && first < i){
				//swap
				temp.copyTree(&sortArray[i]); 
				sortArray[i].copyTree(&sortArray[first]);
				sortArray[first].copyTree(&temp);
				i= first;
				lastRelevant = first;
				first = -1;
			}
		}
	}
	return lastRelevant;
}
