#include "../../Evaluator/EvaluatorClass.h"

#include "QueryEvaluationTreeCubeNode.h"

#include "CubeCounterBasedIterator.h"
#include "CubeBottomUpIterator.h"
#include "CubeTopDown2Iterator.h"
#include "CubeTopDownIterator.h"
#include "extra.h"

void QueryEvaluationTreeCubeNode::processQueryEvalNode(EvaluatorClass* evaluator, IteratorClass*& curr)
	    {
		IteratorClass *opr = evaluator->processQueryEvalNode(getOperand());
		if (opr == NULL)
		{
		    globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"Evaluator",__FILE__, "operand returned is NULL. cube eval node..." );
		    curr=NULL; return;
		}
		switch (getCubeBy())
		{
		    case CUBE_ALGORITHM_1: 
			curr = new CubeCounterBasedIterator(opr, getSizeExpected(), getCubeBy(), 
				getDimNum(), getFactNRE(), getFactByWhat(),
				getFactByAttrName(), getFactOperation(), getFactOpNRE(),
				getFactOpOnWhat(), getFactOpOnWhatAttrName(), getNRE(), 
				getGroupByRelaxType(), getSubtreeParent(), 
				getGroupByWhat(), getGroupByAttrName(), getUseExternalSort(),
				evaluator->getDataManager(), getFileName(),evaluator);
			break;
		    case CUBE_ALGORITHM_2: 
			curr = new CubeBottomUpIterator(opr, getSizeExpected(), getCubeBy(), 
				getDimNum(), getFactNRE(), getFactByWhat(),
				getFactByAttrName(), getFactOperation(), getFactOpNRE(),
				getFactOpOnWhat(), getFactOpOnWhatAttrName(), getNRE(), 
				getGroupByRelaxType(), getSubtreeParent(),
				getGroupByWhat(), getGroupByAttrName(), getUseExternalSort(),
				evaluator->getDataManager(), getFileName(),evaluator);
			break;
		    case CUBE_ALGORITHM_3:
			{
			    if(gSettings->getBooleanValue("CUBEREUSE",false) == true) 
				curr = new CubeTopDown2Iterator(opr, getSizeExpected(), getCubeBy(), 
					getDimNum(), getFactNRE(), getFactByWhat(),
					getFactByAttrName(), getFactOperation(), getFactOpNRE(),
					getFactOpOnWhat(), getFactOpOnWhatAttrName(), getNRE(), 
					getGroupByRelaxType() , getSubtreeParent(),
					getGroupByWhat(), getGroupByAttrName(), getUseExternalSort(),
					evaluator->getDataManager(), getFileName(), getSortOrderFileName(),
					getAssignedDummyNRE1(),getAssignedDummyNRE2(),evaluator); 
			    else 
				curr = new CubeTopDownIterator(opr, getSizeExpected(), getCubeBy(), 
					getDimNum(), getFactNRE(), getFactByWhat(),
					getFactByAttrName(), getFactOperation(), getFactOpNRE(),
					getFactOpOnWhat(), getFactOpOnWhatAttrName(), getNRE(), 
					getGroupByRelaxType() , getSubtreeParent(),
					getGroupByWhat(), getGroupByAttrName(), getUseExternalSort(),
					evaluator->getDataManager(), getFileName(), getSortOrderFileName(),evaluator); 
			}
			break;
		    default:
			globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"Evaluator",__FILE__, "unrecognized cube algorithm. set operations process eval node..." );
			curr=NULL; return;
		}

		setFileName(NULL);
		setNRE(NULL);
		setFactByAttrName(NULL);
		setFactOpOnWhatAttrName(NULL);
	    }

