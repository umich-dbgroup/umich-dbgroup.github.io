/*
COPYRIGHT  ?2000-2004 
THE REGENTS OF THE UNIVERSITY OF MICHIGAN
ALL RIGHTS RESERVED

PERMISSION IS GRANTED TO USE, COPY, CREATE DERIVATIVE WORKS AND REDISTRIBUTE THIS SOFTWARE AND SUCH DERIVATIVE WORKS FOR 
NONCOMMERCIAL EDUCATION AND RESEARCH PURPOSES, SO LONG AS NO FEE IS CHARGED, AND SO LONG AS THE COPYRIGHT NOTICE ABOVE, 
THIS GRANT OF PERMISSION, AND THE DISCLAIMER BELOW APPEAR IN ALL COPIES MADE; AND SO LONG AS THE NAME OF THE UNIVERSITY 
OF MICHIGAN IS NOT USED IN ANY ADVERTISING OR PUBLICITY PERTAINING TO THE USE OR DISTRIBUTION OF THIS SOFTWARE WITHOUT 
SPECIFIC, WRITTEN PRIOR AUTHORIZATION.

THIS SOFTWARE IS PROVIDED AS IS, WITHOUT REPRESENTATION FROM THE UNIVERSITY OF MICHIGAN AS TO ITS FITNESS FOR ANY PURPOSE, 
AND WITHOUT WARRANTY BY THE UNIVERSITY OF MICHIGAN OF ANY KIND, EITHER EXPRESS OR IMPLIED, INCLUDING WITHOUT LIMITATION THE 
IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE. THE REGENTS OF THE UNIVERSITY OF MICHIGAN SHALL 
NOT BE LIABLE FOR ANY DAMAGES, INCLUDING SPECIAL, INDIRECT, INCIDENTAL, OR CONSEQUENTIAL DAMAGES, WITH RESPECT TO ANY CLAIM 
ARISING OUT OF OR IN CONNECTION WITH THE USE OF THE SOFTWARE, EVEN IF IT HAS BEEN OR IS HEREAFTER ADVISED OF THE POSSIBILITY 
OF SUCH DAMAGES.
*/

#include "QueryEvaluationTreeCubeNode.h"


QueryEvaluationTreeCubeNode::QueryEvaluationTreeCubeNode( 
		int sizeExpected, int cubeBy, 
		NREType factNRE, int factByWhat, char* factByAttrName, int factOperation,
		NREType factOpNRE, int factOpOnWhat,char* factOpOnWhatAttrName,
		int dimnum, NREType *nre, bool** groupByRelaxType, NREType* subtreeParent,
		int* groupByWhat, char** groupByAttrName, bool useExternalSort,
		char* fileName,	char* sortorderfileName, NREType assignedDummyNRE1, NREType assignedDummyNRE2,
		QueryEvaluationTreeNode* operand)
: QueryEvaluationTreeNode()
{

	this->sizeExpected = sizeExpected;
	this->dimnum = dimnum;
	this->cubeBy = cubeBy;
	this->factNRE = factNRE;
	this->factByWhat = factByWhat;
	this->factByAttrName = factByAttrName;
	this->factOperation = factOperation;
	this->factOpNRE = factOpNRE;
	this->factOpOnWhat = factOpOnWhat;
	this->factOpOnWhatAttrName = factOpOnWhatAttrName;

	this->nre = nre;
	this->groupByRelaxType = groupByRelaxType;
	this->subtreeParent = subtreeParent;
	this->groupByWhat = groupByWhat;
	this->groupByAttrName = groupByAttrName;
	this->operand = operand;
	this->useExternalSort = useExternalSort;
	this->fileName = fileName;
	this->sortorderfileName = sortorderfileName;
	this->assignedDummyNRE1 = assignedDummyNRE1;
	this->assignedDummyNRE2 = assignedDummyNRE2;
}

QueryEvaluationTreeCubeNode::~QueryEvaluationTreeCubeNode()
{
	if (operand)
		delete operand;
}


int QueryEvaluationTreeCubeNode::getCubeBy()
{
	return this->cubeBy;
}

int QueryEvaluationTreeCubeNode::getSizeExpected()
{
	return this->sizeExpected;
}

int QueryEvaluationTreeCubeNode::getDimNum()
{
	return this->dimnum;
}

NREType QueryEvaluationTreeCubeNode::getFactNRE()
{
	return this->factNRE;
}

void QueryEvaluationTreeCubeNode::setCubeBy(int cubeBy)
{
	this->cubeBy = cubeBy;
}


void QueryEvaluationTreeCubeNode::setDimNum(int dimnum)
{
	this->dimnum = dimnum;
}

void QueryEvaluationTreeCubeNode::setFactNRE(NREType factNRE)
{
	this->factNRE = factNRE;
}

int QueryEvaluationTreeCubeNode::getFactByWhat()
{
	return this->factByWhat;
}
void QueryEvaluationTreeCubeNode::setFactByWhat(int factByWhat)
{
	this->factByWhat = factByWhat;
}

char *QueryEvaluationTreeCubeNode::getFactByAttrName()
{
	return this->factByAttrName;
}
void QueryEvaluationTreeCubeNode::setFactByAttrName(char *factByAttrName)
{
	this->factByAttrName = factByAttrName;
}

int QueryEvaluationTreeCubeNode::getFactOperation()
{
	return this->factOperation;
}
void QueryEvaluationTreeCubeNode::setFactOperation(int factOperation)
{
	this->factOperation = factOperation;
}

NREType QueryEvaluationTreeCubeNode::getFactOpNRE()
{
	return this->factOpNRE;
}
void QueryEvaluationTreeCubeNode::setFactOpNRE(NREType factOpNRE)
{
	this->factOpNRE = factOpNRE;
}

int QueryEvaluationTreeCubeNode::getFactOpOnWhat()
{
	return this->factOpOnWhat;
}
void QueryEvaluationTreeCubeNode::setFactOpOnWhat(int factOpOnWhat)
{
	this->factOpOnWhat = factOpOnWhat;
}

char* QueryEvaluationTreeCubeNode::getFactOpOnWhatAttrName()
{
	return this->factOpOnWhatAttrName;
}

void QueryEvaluationTreeCubeNode::setFactOpOnWhatAttrName(char* factOpOnWhatAttrName)
{
	this->factOpOnWhatAttrName = factOpOnWhatAttrName;
}


NREType* QueryEvaluationTreeCubeNode::getNRE()
{
	return this->nre;
}

void QueryEvaluationTreeCubeNode::setNRE(NREType *nre)
{
	this->nre = nre;
}

bool** QueryEvaluationTreeCubeNode::getGroupByRelaxType()
{
	return this->groupByRelaxType;
}

void QueryEvaluationTreeCubeNode::setGroupByRelaxType(bool** groupByRelaxType)
{
	this->groupByRelaxType = groupByRelaxType;
}

NREType *QueryEvaluationTreeCubeNode::getSubtreeParent()
{
	return this->subtreeParent;
}

void QueryEvaluationTreeCubeNode::setSubtreeParent(NREType *parent)
{
	this->subtreeParent = parent;
}

int* QueryEvaluationTreeCubeNode::getGroupByWhat()
{
	return this->groupByWhat;
}
void QueryEvaluationTreeCubeNode::setGroupByWhat(int* groupByWhat)
{
	this->groupByWhat = groupByWhat;
}

char **QueryEvaluationTreeCubeNode::getGroupByAttrName()
{
	return this->groupByAttrName;
}

void QueryEvaluationTreeCubeNode::setGroupByAttrName(char **groupByAttrName)
{
	this->groupByAttrName = groupByAttrName;
}

QueryEvaluationTreeNode* QueryEvaluationTreeCubeNode::getOperand()
{
	return operand;
}

void QueryEvaluationTreeCubeNode::setOperand(QueryEvaluationTreeNode *operand)
{
	this->operand = operand;
}

bool QueryEvaluationTreeCubeNode::getUseExternalSort()
{
	return this->useExternalSort;
}

void QueryEvaluationTreeCubeNode::setUseExternalSort(bool useExternalSort)
{
	this->useExternalSort = useExternalSort;
}	

void QueryEvaluationTreeCubeNode::setFileName(char* fileName)
{
	this->fileName = fileName;
}

char* QueryEvaluationTreeCubeNode::getFileName()
{
	return this->fileName;
}

char* QueryEvaluationTreeCubeNode::getSortOrderFileName()
{
	return this->sortorderfileName;
}

void QueryEvaluationTreeCubeNode::setSortOrderFileName(char *sortOrderFileName)
{
	this->sortorderfileName = sortOrderFileName;
}


NREType QueryEvaluationTreeCubeNode::getAssignedDummyNRE1()
{
	return this->assignedDummyNRE1;
}
void QueryEvaluationTreeCubeNode::setAssignedDummyNRE1(NREType assignedDummyNRE1)
{
	this->assignedDummyNRE1 = assignedDummyNRE1;
}

NREType QueryEvaluationTreeCubeNode::getAssignedDummyNRE2()
{
	return this->assignedDummyNRE2;
}
void QueryEvaluationTreeCubeNode::setAssignedDummyNRE2(NREType assignedDummyNRE2)
{
	this->assignedDummyNRE2 = assignedDummyNRE2;
}

void QueryEvaluationTreeCubeNode::deleteStructures()
{
	if (nre) delete [] nre;
	if (fileName) delete [] fileName;
	operand->deleteStructures();
}
