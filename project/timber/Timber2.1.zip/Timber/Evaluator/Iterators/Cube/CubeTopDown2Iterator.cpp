/*
COPYRIGHT  ?2000-2004 
THE REGENTS OF THE UNIVERSITY OF MICHIGAN
ALL RIGHTS RESERVED

PERMISSION IS GRANTED TO USE, COPY, CREATE DERIVATIVE WORKS AND REDISTRIBUTE THIS SOFTWARE AND SUCH DERIVATIVE WORKS FOR 
NONCOMMERCIAL EDUCATION AND RESEARCH PURPOSES, SO LONG AS NO FEE IS CHARGED, AND SO LONG AS THE COPYRIGHT NOTICE ABOVE, 
THIS GRANT OF PERMISSION, AND THE DISCLAIMER BELOW APPEAR IN ALL COPIES MADE; AND SO LONG AS THE NAME OF THE UNIVERSITY 
OF MICHIGAN IS NOT USED IN ANY ADVERTISING OR PUBLICITY PERTAINING TO THE USE OR DISTRIBUTION OF THIS SOFTWARE WITHOUT 
SPECIFIC, WRITTEN PRIOR AUTHORIZATION.

THIS SOFTWARE IS PROVIDED AS IS, WITHOUT REPRESENTATION FROM THE UNIVERSITY OF MICHIGAN AS TO ITS FITNESS FOR ANY PURPOSE, 
AND WITHOUT WARRANTY BY THE UNIVERSITY OF MICHIGAN OF ANY KIND, EITHER EXPRESS OR IMPLIED, INCLUDING WITHOUT LIMITATION THE 
IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE. THE REGENTS OF THE UNIVERSITY OF MICHIGAN SHALL 
NOT BE LIABLE FOR ANY DAMAGES, INCLUDING SPECIAL, INDIRECT, INCIDENTAL, OR CONSEQUENTIAL DAMAGES, WITH RESPECT TO ANY CLAIM 
ARISING OUT OF OR IN CONNECTION WITH THE USE OF THE SOFTWARE, EVEN IF IT HAS BEEN OR IS HEREAFTER ADVISED OF THE POSSIBILITY 
OF SUCH DAMAGES.
*/

#include "CubeTopDown2Iterator.h"
#include <float.h>
#include <assert.h>
using std::pair;

int gDimNum3;
NREType* gNREDim3;
int* gWhereEmptyGoesDim3;
int* gOrderDim3;
char** gAttrNameDim3;
int* gSortByDim3;

DataMng *gdataMngCube3;
int numCubeTD2;

int compareCubeNodesValSort3(const void *elem1,const void *elem2)
{
	for (int i=0; i<gDimNum3; i++)
	{
		int index1 = ((WitnessTree *)elem1)->getIndexOfNRE(gNREDim3[i]);
		int index2 = ((WitnessTree *)elem2)->getIndexOfNRE(gNREDim3[i]);
		if (index1 == FAILURE && index2 == FAILURE)
			continue;
		if (index1 == FAILURE)
			return (-1*gWhereEmptyGoesDim3[i]);
		if (index2 == FAILURE)
			return (gWhereEmptyGoesDim3[i]);

		FileIDType fileid1 = EvaluatorClass::getFileID(((ComplexListNode *)((WitnessTree *)elem1)->getNodeByIndex(index1))->getFileIndex());
		if (fileid1 == -1)
			return -1;
		FileIDType fileid2 = EvaluatorClass::getFileID(((ComplexListNode *)((WitnessTree *)elem2)->getNodeByIndex(index2))->getFileIndex());
		if (fileid2 == -1)
			return -1;

		switch (gSortByDim3[i])
		{
		case SORTBY_TEXT_NUM:
		case SORTBY_TEXT_STR:
			{
				int res1 = EvaluatorClass::GetText((WitnessTree *)elem1,index1,gdataMngCube3,fileid1);
				int res2 = EvaluatorClass::GetText((WitnessTree *)elem2,index2,gdataMngCube3,fileid2);
				if ((res1 == FAILURE  || res1 == 0) && (res2 == FAILURE  || res2 == 0))
					continue;
				if (res1 == FAILURE  || res1 == 0)
					return (-1*gWhereEmptyGoesDim3[i]);

				if (res2 == FAILURE  || res2 == 0)
					return (gWhereEmptyGoesDim3[i]);
				char *txt1 = ((DM_CharNode *)((ComplexListNode *)((WitnessTree *)elem1)->getNodeByIndex(res1))->GetData())->getCharValue();
				char *txt2 = ((DM_CharNode *)((ComplexListNode *)((WitnessTree *)elem2)->getNodeByIndex(res2))->GetData())->getCharValue();

				if (gSortByDim3[i] == SORTBY_TEXT_NUM)
				{
					double num1 = atof(txt1);
					double num2 = atof(txt2);
					if (num1 == num2)
						continue;
					else
						return (int)(gOrderDim3[i]* ceil(num1 - num2));
				}
				else
				{
					int r = strcmp(txt1,txt2);
					if (r == 0)
						continue;
					else
						return gOrderDim3[i]*r;
				}
			}
			break;
		case SORTBY_ATTRIBUTE_NUM:
		case SORTBY_ATTRIBUTE_STR:
			{
				int res1 = EvaluatorClass::GetAttributes((WitnessTree *)elem1,index1,gdataMngCube3,fileid1);
				int res2 = EvaluatorClass::GetAttributes((WitnessTree *)elem2,index2,gdataMngCube3,fileid2);
				if (res1 == FAILURE && res2 == FAILURE)
					continue;
				if (res1 == FAILURE)
					return (-1*gWhereEmptyGoesDim3[i]);

				if (res2 == FAILURE)
					return (gWhereEmptyGoesDim3[i]);

				Value *val1 = ((DM_AttributeNode *)((ComplexListNode *)((WitnessTree *)elem1)->getNodeByIndex(index1+1))->GetData())->getAttr(gAttrNameDim3[i]);
				Value *val2 = ((DM_AttributeNode *)((ComplexListNode *)((WitnessTree *)elem2)->getNodeByIndex(index2+1))->GetData())->getAttr(gAttrNameDim3[i]);

				if (!val1 && !val2) 
					continue;

				if (!val1)
					return (-1*gWhereEmptyGoesDim3[i]);
				if (!val2)
					return (gWhereEmptyGoesDim3[i]);

				char *txt1 = val1->getStrValue();
				char *txt2 = val2->getStrValue();
				if (gSortByDim3[i] == SORTBY_ATTRIBUTE_NUM)
				{
					double num1 = atof(txt1);
					double num2 = atof(txt2);
					if (num1 == num2)
						continue;
					else
						return (int)(gOrderDim3[i]* ceil(num1 - num2));
				}
				else
				{
					int r = strcmp(txt1,txt2);
					if (r == 0)
						continue;
					else
						return gOrderDim3[i]*r;
				}
			}
			break;
		case SORTBY_TAGNAME:
			{
				ComplexListNode *n1 = (ComplexListNode *)((WitnessTree *)elem1)->getNodeByIndex(index1);
				ComplexListNode *n2 = (ComplexListNode *)((WitnessTree *)elem2)->getNodeByIndex(index2);
				DM_DataNode *dn1 = n1->GetData();
				DM_DataNode *dn2 = n2->GetData();
				if (dn1 == NULL && dn2 == NULL)
					continue;
				if (dn1 == NULL)
					return -1*gWhereEmptyGoesDim3[i];

				if (dn2 == NULL)
					return gWhereEmptyGoesDim3[i];

				if (dn1->getFlag() != ELEMENT_NODE && dn2->getFlag() != ELEMENT_NODE)
					continue;

				if (dn1->getFlag() != ELEMENT_NODE)
					return (-1*gWhereEmptyGoesDim3[i]);

				if (dn2->getFlag() != ELEMENT_NODE)
					return (gWhereEmptyGoesDim3[i]);
				if (((DM_ElementNode *)dn1)->getTag() == ((DM_ElementNode *)dn2)->getTag())
					continue;

				char *tag1 = gdataMngCube3->getPhysicalDataMng()->getXMLNameTable()->getNameByCode(((DM_ElementNode *)dn1)->getTag());
				char *tag2 = gdataMngCube3->getPhysicalDataMng()->getXMLNameTable()->getNameByCode(((DM_ElementNode *)dn2)->getTag());
				int r = strcmp(tag1, tag2);
				if (r == 0)
					continue;
				else
					return gOrderDim3[i] * r;
			}
			break;
		case SORTBY_VALUE_NUM:
		case SORTBY_VALUE_STR:
			{
				DM_DataNode *dn1 = ((ComplexListNode *)((WitnessTree *)elem1)->getNodeByIndex(index1))->GetData();
				DM_DataNode *dn2 = ((ComplexListNode *)((WitnessTree *)elem2)->getNodeByIndex(index2))->GetData();
				if (dn1 == NULL && dn2 == NULL)
					continue;
				if (dn1 == NULL)
					return -1*gWhereEmptyGoesDim3[i];

				if (dn2 == NULL)
					return gWhereEmptyGoesDim3[i];

				char *txt1;
				char *txt2;
				Value *val1;
				Value *val2;
				if (dn1->getFlag() == ELEMENT_NODE)
					txt1 = gdataMngCube3->getPhysicalDataMng()->getXMLNameTable()->getNameByCode(((DM_ElementNode *)dn1)->getTag());

				else if (dn1->getFlag() == DOCUMENT_NODE)
				{
					if (((DM_DocumentNode *)dn1)->getXMLFileName())
						txt1 = ((DM_DocumentNode *)dn1)->getXMLFileName();
					else
						txt1 = NULL;
				}
				else if (dn1->getFlag() == ATTRIBUTE_NODE)
				{
					//if attribute node, return the value of attribute "attrName"

					val1 = ((DM_AttributeNode *)dn1)->getAttr(gAttrNameDim3[i]);
					if (val1 != NULL)
					{
						if (val1->getStrValue() != NULL && strlen(val1->getStrValue()) != 0)
							txt1 = val1->getStrValue();
						else
							txt1 = NULL;
					}
					else
						txt1 = NULL;
				} 
				else
				{
					//if text node, return the text value
					if (((DM_CharNode *)dn1)->getCharValue())
						txt1 = ((DM_CharNode *)dn1)->getCharValue();
					else
						txt1 = NULL;
				}

				//getting second vLUES
				if (dn2->getFlag() == ELEMENT_NODE)
					txt2 = gdataMngCube3->getPhysicalDataMng()->getXMLNameTable()->getNameByCode(((DM_ElementNode *)dn2)->getTag());

				else if (dn2->getFlag() == DOCUMENT_NODE)
				{
					if (((DM_DocumentNode *)dn2)->getXMLFileName())
						txt2 = ((DM_DocumentNode *)dn2)->getXMLFileName();
					else
						txt2 = NULL;
				}
				else if (dn2->getFlag() == ATTRIBUTE_NODE)
				{
					//if attribute node, return the value of attribute "attrName"

					val2 = ((DM_AttributeNode *)dn2)->getAttr(gAttrNameDim3[i]);
					if (val2 != NULL)
					{
						if (val2->getStrValue() != NULL && strlen(val2->getStrValue()) != 0)
							txt2 = val2->getStrValue();
						else
							txt2 = NULL;
					}
					else
						txt2 = NULL;
				} 
				else
				{
					//if text node, return the text value
					if (((DM_CharNode *)dn2)->getCharValue())
						txt2 = ((DM_CharNode *)dn2)->getCharValue();
					else
						txt2 = NULL;
				}
				if (!txt1 && !txt2) 
					continue;

				if (!txt1)
					return (-1*gWhereEmptyGoesDim3[i]);
				if (!txt2)
					return (gWhereEmptyGoesDim3[i]);

				if (gSortByDim3[i] == SORTBY_VALUE_NUM)
				{
					double num1 = atof(txt1);
					double num2 = atof(txt2);
					if (num1 == num2)
						continue;
					else
						return (int)(gOrderDim3[i]* ceil(num1 - num2));
				}
				else
				{
					int r = strcmp(txt1,txt2);
					if (r == 0)
						continue;
					else
						return gOrderDim3[i]*r;
				}

			}
			break;
		case SORT_BY_START_KEY:
			{
				KeyType sk1 = ((ComplexListNode *)((WitnessTree *)elem1)->getNodeByIndex(index1))->GetStartPos();
				KeyType sk2 = ((ComplexListNode *)((WitnessTree *)elem2)->getNodeByIndex(index2))->GetStartPos();
				if (sk1 == sk2)
					continue;
				else
				{
					if (sk1 < sk2)
						return (-1*gOrderDim3[i]);
					else
						return (gOrderDim3[i]);
				}
			}
			break;
		}
	}
	int n = ((WitnessTree *)elem1)->length() < ((WitnessTree *)elem2)->length()?
		((WitnessTree *)elem1)->length() : ((WitnessTree *)elem2)->length();
	for (int i=0; i<n; i++)
	{
		if (((ComplexListNode *)((WitnessTree *)elem1)->findNode(i))->GetStartPos() ==
			((ComplexListNode *)((WitnessTree *)elem2)->findNode(i))->GetStartPos())
			continue;
		else
		{
			if (((ComplexListNode *)((WitnessTree *)elem1)->findNode(i))->GetStartPos() <
				((ComplexListNode *)((WitnessTree *)elem2)->findNode(i))->GetStartPos())
				return -1;
			else
				return 1;
		}
	}
	if (((WitnessTree *)elem1)->length() < ((WitnessTree *)elem2)->length())
		return -1;
	else if (((WitnessTree *)elem1)->length() > ((WitnessTree *)elem2)->length())
		return 1;
	return 0;
}



CubeTopDown2Iterator::CubeTopDown2Iterator(IteratorClass *input, int sizeExpected, int cubeBy, int dimnum, NREType factNRE,
										   int factByWhat, char* factByAttrName, int factByOperation,
										   NREType factOpNRE, int factOpOnWhat, char* factOpOnWhatAttrName,
										   NREType *nre, bool** groupByRelaxType,NREType* subtreeParent,
										   int* groupByWhat, char** groupByAttrName, bool useExternalSort,
										   DataMng *dataMng, char* fileName, char* sortOrderFileName,
										   NREType assignedDummyNRE1,NREType assignedDummyNRE2,EvaluatorClass* evalClass)
{
	at = 0;
	this->cubeBy = cubeBy;
	this->dataMng = dataMng;
	this->fileName = fileName;
	this->sortOrderFileName = sortOrderFileName;
	gdataMngCube3 = dataMng;
	this->dimnum = dimnum;
	this->groupByNRE = nre;
	this->groupByAttrName = groupByAttrName;
	this->groupByWhat = groupByWhat;
	this->groupByRelaxType = groupByRelaxType;
	this->subtreeParent = subtreeParent;
	this->factNRE = factNRE;
	this->factByWhat = factByWhat;
	this->factByAttrName = factByAttrName;
	this->factByOperation = factByOperation;
	this->factOpNRE = factOpNRE;
	this->factOpOnWhat = factOpOnWhat;
	this->factOpOnWhatAttrName = factOpOnWhatAttrName;
	this->useExternalSort = useExternalSort;
	this->lastUseExternalSort = false;
	this->lastUseExternalSortOrder = -1;
	this->assignedDummyNRE1 = assignedDummyNRE1;
	this->assignedDummyNRE2 = assignedDummyNRE2;

	this->no_overlap = gSettings->getBooleanValue("NO_OVERLAP",false);
	gNREDim3 = NULL;
	gWhereEmptyGoesDim3 = NULL;
	gOrderDim3 = NULL;
	gAttrNameDim3 = NULL;
	gSortByDim3 = NULL;

	NREType* nreDimExSort = NULL;
	char** attrNameDimExSort = NULL;
	int* sortByDimExSort = NULL;
	int* orderDimExSort = NULL;
	int* whereEmptyGoesDimExSort = NULL;

	this->input = input;

	numCubeTD2 = 0;
	//map nre to index from the input
	for (int i = 0 ; i < dimnum ; i++) {
		pair<NREType,int> p1(this->groupByNRE[i],i);
		NREToIndex.insert(p1);	
	}

	//file for cuboid results
	output = fopen(this->fileName,"w");

	size = 0;
	if (sizeExpected <= 0)
		sizeExpected = gSettings->getIntegerValue("INITIAL_DEFAULT_SORT_ARRAY_SIZE",INITIAL_SORT_ARRAY_SIZE_DEFAULT);
	sizeExpected++;
	treeArray = new WitnessTree*[sizeExpected];
	for (int i = 0 ; i < sizeExpected; i++) {
		treeArray[i] = NULL;
	}

	this->getSortOrder();

	clock_t starttime, finishtime; 
	double sortDuration;
	starttime = clock();

	int firstSortDimNum = ((this->sortOrder[0]).at(0))->numNRE;
	if (!useExternalSort){
		this->input->next(inTuple);
		while (inTuple)
		{
			inTuple->switchToComplex(dataMng);

			if (size >= sizeExpected)
			{
				//if sortArray size is not enough-->double it
				WitnessTree **tmp = treeArray;
				sizeExpected *= 2;
				treeArray = new WitnessTree*[sizeExpected];
				//memcpy(treeArray, tmp, size * sizeof(WitnessTree));
				//
				// Copy old witness trees into new array, and allow
				// old tree's to be deleted. This fixes a memory leak.
				//
				for (int j = 0 ; j < size ; j++)
				{
					treeArray[j] = tmp[j];
					tmp[j]->setDeleteBuffers(true) ;
				}
				//
				// Allow the old WitnessTrees to be deleted
				//
				delete [] tmp;
			}
			treeArray[size] = new WitnessTree;
			treeArray[size]->copyTree(inTuple);
			treeArray[size]->setDeleteBuffers(true);
			size++;


			inTuple->deleteAllNodes();

			this->input->next(inTuple);
		}
		delete this->input;


		gDimNum3 = firstSortDimNum;
		//1. sort by the first sort order
		gSortByDim3 = new int[firstSortDimNum];
		gAttrNameDim3 = new char*[firstSortDimNum];
		//for global sort by, for later operation
		int hereByWhat;
		for (int i=0 ; i < firstSortDimNum ; i++)
		{
			NREType thisNRE = ((this->sortOrder[0]).at(0))->nreList[i];
			int thisInd = NREToIndex[thisNRE];

			hereByWhat = this->groupByWhat[thisInd];
			if (hereByWhat == GROUPBY_ATTRIBUTE_NUM) gSortByDim3[i] = SORTBY_ATTRIBUTE_NUM;
			else if (hereByWhat == GROUPBY_ATTRIBUTE_STR) gSortByDim3[i] = SORTBY_ATTRIBUTE_STR;
			else if (hereByWhat == GROUPBY_TEXT_NUM) gSortByDim3[i] = SORTBY_TEXT_NUM;
			else if (hereByWhat == GROUPBY_TEXT_STR) gSortByDim3[i] = SORTBY_TEXT_STR;
			else if (hereByWhat == GROUPBY_STARTKEY) gSortByDim3[i] = SORT_BY_START_KEY;
			else if (hereByWhat == GROUPBY_VALUE_NUM) gSortByDim3[i] = SORTBY_VALUE_NUM;
			else if (hereByWhat == GROUPBY_VALUE_STR) gSortByDim3[i] = SORTBY_VALUE_STR;
			gAttrNameDim3[i] = this->groupByAttrName[thisInd];
		}

		gOrderDim3 = new int[firstSortDimNum];
		for (int i=0 ; i < firstSortDimNum ; i++)
		{
			gOrderDim3[i] = ASCENDING;
		}
		gNREDim3 = ((this->sortOrder[0]).at(0))->nreList;

		gWhereEmptyGoesDim3 = new int[firstSortDimNum];
		for (int i=0 ; i < firstSortDimNum ; i++)
		{
			gWhereEmptyGoesDim3[i] = EMPTY_AT_END;
		}

		EvalQuickSort s;
		//cout << endl << "--Sort on dimension--" << d << " up" << endl << endl;
		if (s.quickSort(treeArray,0,size-1,compareCubeNodesValSort3) == FAILURE) {
			size = 0;
			return;
		}
	}
	else { //if external sort
		serial_t fileID = 0;
		serial_t recID = 0;
		int numWrites = 0;
		fileID = evalClass->fileIDsArray[evalClass->fileIDsArrayPtr];
		evalClass->fileIDsArrayPtr++;
		numWrites = evalClass->createRecID(recID);
		if (numWrites == FAILURE)
		{
			globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"Evaluator",__FILE__, "operand returned is NULL. sort process eval node..." );
		}

		//construct info for external sorting, these will be destroyed by externalsort iterator

		nreDimExSort = new NREType[firstSortDimNum];
		for (int i=0 ; i < firstSortDimNum ; i++)
		{
			nreDimExSort[i] = ((this->sortOrder[0]).at(0))->nreList[i];
		}

		sortByDimExSort = new int[firstSortDimNum];
		attrNameDimExSort = new char*[firstSortDimNum];
		//for global sort by, for later operation
		int hereByWhat;
		for (int i=0 ; i < firstSortDimNum ; i++)
		{
			NREType thisNRE = ((this->sortOrder[0]).at(0))->nreList[i];
			int thisInd = NREToIndex[thisNRE];

			hereByWhat = this->groupByWhat[thisInd];
			if (hereByWhat == GROUPBY_ATTRIBUTE_NUM) sortByDimExSort[i] = SORTBY_ATTRIBUTE_NUM;
			else if (hereByWhat == GROUPBY_ATTRIBUTE_STR) sortByDimExSort[i] = SORTBY_ATTRIBUTE_STR;
			else if (hereByWhat == GROUPBY_TEXT_NUM) sortByDimExSort[i] = SORTBY_TEXT_NUM;
			else if (hereByWhat == GROUPBY_TEXT_STR) sortByDimExSort[i] = SORTBY_TEXT_STR;
			else if (hereByWhat == GROUPBY_STARTKEY) sortByDimExSort[i] = SORT_BY_START_KEY;
			else if (hereByWhat == GROUPBY_VALUE_NUM) sortByDimExSort[i] = SORTBY_VALUE_NUM;
			else if (hereByWhat == GROUPBY_VALUE_STR) sortByDimExSort[i] = SORTBY_VALUE_STR;
			attrNameDimExSort[i] = new char[strlen(this->groupByAttrName[thisInd])+1];
			strcpy(attrNameDimExSort[i],this->groupByAttrName[thisInd]);
		}

		orderDimExSort = new int[firstSortDimNum];
		for (int i=0 ; i < firstSortDimNum ; i++)
		{
			orderDimExSort[i] = ASCENDING;
		}

		whereEmptyGoesDimExSort = new int[firstSortDimNum];
		for (int i=0 ; i < firstSortDimNum ; i++)
		{
			whereEmptyGoesDimExSort[i] = EMPTY_AT_END;
		}

		this->input = new ExternalValueSortIterator(this->input,firstSortDimNum,sortByDimExSort,nreDimExSort,attrNameDimExSort,
			orderDimExSort,dataMng,whereEmptyGoesDimExSort,fileID,recID,numWrites);

		this->lastUseExternalSort = true;
		this->lastUseExternalSortOrder = 0;
	}
	finishtime = clock();
	sortDuration = (double)(finishtime - starttime) / CLOCKS_PER_SEC;
	cout << sortDuration << " seconds to sort" << endl;

	//2. for each sort order
	for (int sOrder = 0 ; sOrder < numSortOrder; sOrder++) {
#ifdef EVAL_TIME_OUT
		clock_t currTime = clock();
		double queryDuration = (double)(currTime - gQueryStartTime) / CLOCKS_PER_SEC;
		if (queryDuration >= gTimeOutAfter)
		{
			globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"Evaluator",__FILE__,"Query Timed Out. Cube");
			node = NULL;
			return;		
		}
#endif
		//initialize accumulator for storing dimension char value
		//and also store first tuple

		starttime = clock();

		if(sortOrderWriteCube[sOrder]) {
			char buffer[10];
			writeCubeFile = fopen(itoa(sOrder,buffer,10),"w");
		}

		if (sortOrderReadCube[sOrder] > -1)
		{
			char buffer[10];
			this->input = new FileReaderIterator(itoa(sortOrderReadCube[sOrder],buffer,10),this->dataMng);
			if (this->useExternalSort){
				serial_t fileID = 0;
				serial_t recID = 0;
				int numWrites = 0;
				fileID = evalClass->fileIDsArray[evalClass->fileIDsArrayPtr];
				evalClass->fileIDsArrayPtr++;
				numWrites = evalClass->createRecID(recID);
				if (numWrites == FAILURE)
				{
					globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"Evaluator",__FILE__, "operand returned is NULL. sort process eval node..." );
				}

				//construct info for external sorting, these will be destroyed by externalsort iterator

				int curSortDimNum = ((this->sortOrder[sOrder]).at(0))->numNRE;

				nreDimExSort = new NREType[curSortDimNum];
				for (int i=0 ; i < curSortDimNum ; i++)
				{
					nreDimExSort[i] = ((this->sortOrder[sOrder]).at(0))->nreList[i];
				}

				sortByDimExSort = new int[curSortDimNum];
				attrNameDimExSort = new char*[curSortDimNum];
				//for global sort by, for later operation
				int hereByWhat;
				for (int i=0 ; i < curSortDimNum ; i++)
				{
					NREType thisNRE = ((this->sortOrder[sOrder]).at(0))->nreList[i];
					int thisInd = NREToIndex[thisNRE];

					hereByWhat = this->groupByWhat[thisInd];
					if (hereByWhat == GROUPBY_ATTRIBUTE_NUM) sortByDimExSort[i] = SORTBY_ATTRIBUTE_NUM;
					else if (hereByWhat == GROUPBY_ATTRIBUTE_STR) sortByDimExSort[i] = SORTBY_ATTRIBUTE_STR;
					else if (hereByWhat == GROUPBY_TEXT_NUM) sortByDimExSort[i] = SORTBY_TEXT_NUM;
					else if (hereByWhat == GROUPBY_TEXT_STR) sortByDimExSort[i] = SORTBY_TEXT_STR;
					else if (hereByWhat == GROUPBY_STARTKEY) sortByDimExSort[i] = SORT_BY_START_KEY;
					else if (hereByWhat == GROUPBY_VALUE_NUM) sortByDimExSort[i] = SORTBY_VALUE_NUM;
					else if (hereByWhat == GROUPBY_VALUE_STR) sortByDimExSort[i] = SORTBY_VALUE_STR;
					attrNameDimExSort[i] = new char[strlen(this->groupByAttrName[thisInd])+1];
					strcpy(attrNameDimExSort[i],this->groupByAttrName[thisInd]);
				}

				orderDimExSort = new int[curSortDimNum];
				for (int i=0 ; i < curSortDimNum ; i++)
				{
					orderDimExSort[i] = ASCENDING;
				}

				whereEmptyGoesDimExSort = new int[curSortDimNum];
				for (int i=0 ; i < curSortDimNum ; i++)
				{
					whereEmptyGoesDimExSort[i] = EMPTY_AT_END;
				}

				this->input = new ExternalValueSortIterator(this->input,curSortDimNum,sortByDimExSort,nreDimExSort,attrNameDimExSort,
					orderDimExSort,dataMng,whereEmptyGoesDimExSort,fileID,recID,numWrites);
				this->lastUseExternalSort = true;
			}
			else {
				size = 0;
				this->input->next(inTuple);
				while (inTuple)
				{
					inTuple->switchToComplex(dataMng);
					treeArray[size]->copyTree(inTuple);
					treeArray[size]->setDeleteBuffers(true);
					size++;
					inTuple->deleteAllNodes();

					this->input->next(inTuple);
				}
				delete this->input;

				EvalQuickSort s;
				//cout << endl << "--Sort on dimension--" << d << " up" << endl << endl;
				if (s.quickSort(treeArray,0,size-1,compareCubeNodesValSort3) == FAILURE) {
					size = 0;
					return;
				}
			}//else quicksort
		}
		if (this->useExternalSort && (this->lastUseExternalSort)) {
			//for ext sort, get first tree
			size = 0;
			this->input->next(inTuple);
			inTuple->switchToComplex(dataMng);
			if (!treeArray[size]) treeArray[size] = new WitnessTree; //TODO: or if (sortOrder==0) bypass checking, since maybe sizeExpected is lower than real, then it's not initialized as null
			treeArray[size]->copyTree(inTuple);
			treeArray[size]->setDeleteBuffers(true);
			size++;
		}

		for (int ii = 0 ; ii < this->sortOrder[sOrder].size() ; ii++) {
			int nNRE = ((this->sortOrder[sOrder]).at(ii))->numNRE;
			//if it is zero, it is the ALL cuboid
			if (nNRE > 0) ((this->sortOrder[sOrder]).at(ii))->dimValue = new char*[nNRE];
			for (int jj = 0 ; jj < ((this->sortOrder[sOrder]).at(ii))->numNRE; jj++)
			{
				char* thisDimVal;
				NREType thisNRE = ((this->sortOrder[sOrder]).at(ii))->nreList[jj];
				int thisInd = NREToIndex[thisNRE];
				int success = this->getNodeValue(treeArray[0],thisNRE,
					this->groupByAttrName[thisInd],this->groupByWhat[thisInd],thisDimVal);
				if (success == FAILURE) { //possible missing
					((this->sortOrder[sOrder]).at(ii))->dimValue[jj] = NULL;
				}
				else {
					((this->sortOrder[sOrder]).at(ii))->dimValue[jj] = thisDimVal;
				}

			}


			if(this->no_overlap == false) {
				//Before aggregate anything, check whether it complies to AD,PC,SP
				if (this->checkRelevant(0,(this->sortOrder[sOrder]).at(ii))){
					char* factVal;
					int r = this->getNodeValue(treeArray[0],this->factNRE,this->factByAttrName,this->factByWhat,factVal);
					if (r == FAILURE) //missing fact value? e.g. in DBLP
					{
						factVal = new char[5];
						strcpy(factVal,"NULL");
					}
					(((this->sortOrder[sOrder]).at(ii))->fact).insert(pair<char*,WitnessTree*>(factVal,treeArray[0]));

				}
			}
			else{
				//optimization
				//just aggregate according to operation type
				((this->sortOrder[sOrder]).at(ii))->aggrValue2 = 0;
				switch (this->factByOperation)
				{
				case OP_MIN:
					((this->sortOrder[sOrder]).at(ii))->aggrValue1 = DBL_MAX;
					break;
				case OP_MAX:
					((this->sortOrder[sOrder]).at(ii))->aggrValue1 = DBL_MIN;
					break;
				default:
					((this->sortOrder[sOrder]).at(ii))->aggrValue1 = 0;
					break;
				}
				//go to aggregate function
				//Before aggregate anything, check whether it complies to AD,PC,SP
				if (this->checkRelevant(0,(this->sortOrder[sOrder]).at(ii))){
					this->Aggregate(((this->sortOrder[sOrder]).at(ii)),treeArray[0],this->sortOrderReadCube[sOrder]);
				}//check relevant
			}

		}//for

		//set info for later sort, do not forget to delete old sort info, but not to delete thing inside if it come from the caller (gAttrNameDim3)
		if (sOrder+1 < numSortOrder) {
			int nextSortDimNum = ((this->sortOrder[sOrder+1]).at(0))->numNRE;
			gDimNum3 = nextSortDimNum;
			if (gSortByDim3) delete [] gSortByDim3;
			gSortByDim3 = new int[nextSortDimNum];
			if (gAttrNameDim3) delete [] gAttrNameDim3;
			gAttrNameDim3 = new char*[nextSortDimNum];
			for (int i=0 ; i < nextSortDimNum ; i++)
			{
				NREType thisNRE = ((this->sortOrder[sOrder+1]).at(0))->nreList[i];
				int thisInd = NREToIndex[thisNRE];

				int hereByWhat = this->groupByWhat[thisInd];
				if (hereByWhat == GROUPBY_ATTRIBUTE_NUM) gSortByDim3[i] = SORTBY_ATTRIBUTE_NUM;
				else if (hereByWhat == GROUPBY_ATTRIBUTE_STR) gSortByDim3[i] = SORTBY_ATTRIBUTE_STR;
				else if (hereByWhat == GROUPBY_TEXT_NUM) gSortByDim3[i] = SORTBY_TEXT_NUM;
				else if (hereByWhat == GROUPBY_TEXT_STR) gSortByDim3[i] = SORTBY_TEXT_STR;
				else if (hereByWhat == GROUPBY_STARTKEY) gSortByDim3[i] = SORT_BY_START_KEY;
				else if (hereByWhat == GROUPBY_VALUE_NUM) gSortByDim3[i] = SORTBY_VALUE_NUM;
				else if (hereByWhat == GROUPBY_VALUE_STR) gSortByDim3[i] = SORTBY_VALUE_STR;
				gAttrNameDim3[i] = this->groupByAttrName[thisInd];
			}

			if (gOrderDim3) delete [] gOrderDim3;
			gOrderDim3 = new int[nextSortDimNum];
			for (int i=0 ; i < nextSortDimNum ; i++)
			{
				gOrderDim3[i] = ASCENDING;
			}
			gNREDim3 = ((this->sortOrder[sOrder+1]).at(0))->nreList;

			if (gWhereEmptyGoesDim3) delete [] gWhereEmptyGoesDim3;
			gWhereEmptyGoesDim3 = new int[nextSortDimNum];
			for (int i=0 ; i < nextSortDimNum ; i++)
			{
				gWhereEmptyGoesDim3[i] = EMPTY_AT_END;
			}
		}

		//find common attribute number with the next sort order, for use in 2.3.1
		int common = 0;

		if (sOrder+1 < numSortOrder) {
			common = (((this->sortOrder[sOrder]).at(0))->numNRE > ((this->sortOrder[sOrder+1]).at(0))->numNRE ?  ((this->sortOrder[sOrder+1]).at(0))->numNRE:((this->sortOrder[sOrder]).at(0))->numNRE);
			for (int i = 0 ; 
				i < (((this->sortOrder[sOrder]).at(0))->numNRE > ((this->sortOrder[sOrder+1]).at(0))->numNRE ?  ((this->sortOrder[sOrder+1]).at(0))->numNRE:((this->sortOrder[sOrder]).at(0))->numNRE);
				i++){
					if (this->sortOrder[sOrder].at(0)->nreList[i] != this->sortOrder[sOrder+1].at(0)->nreList[i])
					{	
						common = i;
						break;
					}
				}
		}
		int partitionPresort = 0;

		//2.3 for each subsequent tree tuple do
		//get next tuple, when using external sort

		if (this->useExternalSort && (this->lastUseExternalSort)) {
			//for ext sort, get first tree
			this->input->next(inTuple);
			if (inTuple){
				inTuple->switchToComplex(dataMng);
				if (!treeArray[size]) treeArray[size] = new WitnessTree;
				treeArray[size]->copyTree(inTuple);
				treeArray[size]->setDeleteBuffers(true);
				size++;
			}
		}

		int tt = 0;
		for (tt = 1; tt < size; tt++){
			//2.3.1 compare treeArray[tt], treeArray[tt-1], if proper, should presort
			if ((sOrder+1 < numSortOrder) && (this->sortOrderReadCube[sOrder+1] < 0)) {
				int diffat = this->differenceAt(sOrder,treeArray[tt],treeArray[tt-1]);
				if (common > diffat)
				{
					EvalQuickSort s2;
					//cout << endl << "--Presort--" << partitionPresort << " to" << tt-1 << endl << endl;
					if (s2.quickSort(treeArray,partitionPresort,tt-1,compareCubeNodesValSort3) == FAILURE) {
						size = 0;
						return;
					}
					partitionPresort = tt;
				}
			}
			//2.3.3 check grouping of tt and the accumulators
			//for each accumulator of this sort order
			for (int i = 0 ; i < this->sortOrder[sOrder].size() ; i++){
				//compare treeArray[tt] and accumulator.dimvalue
				int whichMissing;
				Accumulator* curAccu = (this->sortOrder[sOrder]).at(i);
				bool isDiffer = isDifference(curAccu,treeArray[tt], &whichMissing);
				if (isDiffer){ //differs
					if (whichMissing != 1) //if current accu contains missing, nothing output
					{
						if(sortOrderWriteCube[sOrder] && i == 0) //only first prefix order to write
							this->AggregateAndWriteOutput(curAccu,true,this->sortOrderReadCube[sOrder]);
						else 
							this->AggregateAndWriteOutput(curAccu,false,this->sortOrderReadCube[sOrder]);
					}

					//change value of accu to current tree value
					for (int j = 0 ; j < curAccu->numNRE; j++)
					{
						char* thisDimVal;
						NREType thisNRE = curAccu->nreList[j];
						int thisInd = NREToIndex[thisNRE];
						int success = this->getNodeValue(treeArray[tt],thisNRE,
							this->groupByAttrName[thisInd],this->groupByWhat[thisInd],thisDimVal);
						if (success == FAILURE) { //possible missing
							curAccu->dimValue[j] = NULL;
						}
						else {
							curAccu->dimValue[j] = thisDimVal;
						}

					}


					if(this->no_overlap == false) {
						//Before aggregate anything, check whether it complies to AD,PC,SP
						if (this->checkRelevant(tt,curAccu)){
							char* factVal;
							int r = this->getNodeValue(treeArray[tt],this->factNRE,this->factByAttrName,this->factByWhat,factVal);
							if (r == FAILURE) //missing fact value? e.g. in DBLP
							{
								factVal = new char[5];
								strcpy(factVal,"NULL");
							}

							if (this->factByWhat == GROUPBY_STARTKEY){
								map<char*, WitnessTree*, ltstr>::const_iterator cur;
								cur = (curAccu->fact).begin();
								while (cur != (curAccu->fact).end()){
									delete [] (*cur).first;
									++cur;
								}
							}
							curAccu->fact.clear();
							(curAccu->fact).insert(pair<char*,WitnessTree*>(factVal,treeArray[tt]));
						}
						else curAccu->fact.clear();
					}
					else //optimization , just aggregate, clear bf
					{
						curAccu->aggrValue2 = 0;
						switch (this->factByOperation)
						{
						case OP_MIN:
							curAccu->aggrValue1 = DBL_MAX;
							break;
						case OP_MAX:
							curAccu->aggrValue1 = DBL_MIN;
							break;
						default:
							curAccu->aggrValue1 = 0;
							break;
						}
						//go to aggregrate function
						//Before aggregate anything, check whether it complies to AD,PC,SP
						if (this->checkRelevant(tt,curAccu)){
							this->Aggregate(curAccu,treeArray[tt],this->sortOrderReadCube[sOrder]);
						}
					}

				}
				else{ //not differ
					//Before aggregate anything, check whether it complies to AD,PC,SP
					if (this->checkRelevant(tt,curAccu)){
						if(this->no_overlap == false) {
							char* factVal;
							int r = this->getNodeValue(treeArray[tt],this->factNRE,this->factByAttrName,this->factByWhat,factVal);
							if (r == FAILURE) //missing fact value? e.g. in DBLP
							{
								factVal = new char[5];
								strcpy(factVal,"NULL");
							}
							(curAccu->fact).insert(pair<char*,WitnessTree*>(factVal,treeArray[tt]));
						}
						else { //optimization , just aggregate
							this->Aggregate(curAccu,treeArray[tt],this->sortOrderReadCube[sOrder]);
						}
					}
				}


			}//for each accumulator

			if (this->useExternalSort && (this->lastUseExternalSort)) {
				//for ext sort, get next
				this->input->next(inTuple);
				if (inTuple) {
					inTuple->switchToComplex(dataMng);
					if (!treeArray[size]) treeArray[size] = new WitnessTree;
					treeArray[size]->copyTree(inTuple);
					treeArray[size]->setDeleteBuffers(true);
					size++;
				}
			}
		}//for each subsequent tuple

		//last tuple left in accumulators, write output only if it's not missing
		for (int i = 0 ; i < this->sortOrder[sOrder].size() ; i++){

			int whichMissing;
			Accumulator* curAccu = (this->sortOrder[sOrder]).at(i);
			(void)this->isDifference(curAccu,NULL, &whichMissing);
			if (whichMissing != 1)

				if(sortOrderWriteCube[sOrder] && i == 0)
					this->AggregateAndWriteOutput(curAccu,true,this->sortOrderReadCube[sOrder]);
				else
					this->AggregateAndWriteOutput(curAccu,false,this->sortOrderReadCube[sOrder]);
		}

		finishtime = clock();
		double cubeDuration = (double)(finishtime - starttime) / CLOCKS_PER_SEC;
		cout << cubeDuration << " seconds to Compute Cube" << endl;

		if (this->useExternalSort && (this->lastUseExternalSort)) {
			delete this->input;
		}

		at = 0;
		//sort last partition of presort
		if ((sOrder+1 < numSortOrder) && (this->sortOrderReadCube[sOrder+1] < 0)) {
			starttime = clock();
			if ((partitionPresort == 0)&&(this->useExternalSort)){
				//big chunks, to use external sort

				//cout << endl << "--Bigsort--" << partitionPresort << " to" << tt-1 << endl << endl;

				serial_t fileID = 0;
				serial_t recID = 0;
				int numWrites = 0;
				fileID = evalClass->fileIDsArray[evalClass->fileIDsArrayPtr];
				evalClass->fileIDsArrayPtr++;
				numWrites = evalClass->createRecID(recID);
				if (numWrites == FAILURE)
				{
					globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"Evaluator",__FILE__, "operand returned is NULL. sort process eval node..." );
				}
				int nextSortDimNum = ((this->sortOrder[sOrder+1]).at(0))->numNRE;

				nreDimExSort = new NREType[nextSortDimNum];
				for (int i=0 ; i < nextSortDimNum ; i++)
				{
					nreDimExSort[i] = ((this->sortOrder[sOrder+1]).at(0))->nreList[i];
				}

				attrNameDimExSort = new char*[nextSortDimNum];

				sortByDimExSort = new int[nextSortDimNum];
				for (int i=0 ; i < nextSortDimNum ; i++)
				{
					NREType thisNRE = ((this->sortOrder[sOrder+1]).at(0))->nreList[i];
					int thisInd = NREToIndex[thisNRE];

					int hereByWhat = this->groupByWhat[thisInd];
					if (hereByWhat == GROUPBY_ATTRIBUTE_NUM) sortByDimExSort[i] = SORTBY_ATTRIBUTE_NUM;
					else if (hereByWhat == GROUPBY_ATTRIBUTE_STR) sortByDimExSort[i] = SORTBY_ATTRIBUTE_STR;
					else if (hereByWhat == GROUPBY_TEXT_NUM) sortByDimExSort[i] = SORTBY_TEXT_NUM;
					else if (hereByWhat == GROUPBY_TEXT_STR) sortByDimExSort[i] = SORTBY_TEXT_STR;
					else if (hereByWhat == GROUPBY_STARTKEY) sortByDimExSort[i] = SORT_BY_START_KEY;
					else if (hereByWhat == GROUPBY_VALUE_NUM) sortByDimExSort[i] = SORTBY_VALUE_NUM;
					else if (hereByWhat == GROUPBY_VALUE_STR) sortByDimExSort[i] = SORTBY_VALUE_STR;
					attrNameDimExSort[i] = new char[strlen(this->groupByAttrName[thisInd])+1];
					strcpy(attrNameDimExSort[i],this->groupByAttrName[thisInd]);
				}


				orderDimExSort = new int[nextSortDimNum];
				for (int i=0 ; i < nextSortDimNum ; i++)
				{
					orderDimExSort[i] = ASCENDING;
				}


				whereEmptyGoesDimExSort = new int[nextSortDimNum];
				for (int i=0 ; i < nextSortDimNum ; i++)
				{
					whereEmptyGoesDimExSort[i] = EMPTY_AT_END;
				}

				this->input = new ExternalValueSortIterator(this,nextSortDimNum,sortByDimExSort,nreDimExSort,attrNameDimExSort,
					orderDimExSort,dataMng,whereEmptyGoesDimExSort,fileID,recID,numWrites,true);

				this->lastUseExternalSort = true;
				this->lastUseExternalSortOrder = sOrder+1;
			}

			else {
				EvalQuickSort s1;
				//cout << endl << "--Presort--" << partitionPresort << " to" << tt-1 << endl << endl;
				if (s1.quickSort(treeArray,partitionPresort,tt-1,compareCubeNodesValSort3) == FAILURE) {
					size = 0;
					return;
				}
				this->lastUseExternalSort = false;
			}
			finishtime = clock();
			sortDuration = (double)(finishtime - starttime) / CLOCKS_PER_SEC;
			cout << sortDuration << " seconds to sort" << endl;
		}//if sortorder+1 < numSortorder

		if(sortOrderWriteCube[sOrder]) {
			fclose(writeCubeFile);
		}
	}//for each sort order

}//end constructor


CubeTopDown2Iterator::~CubeTopDown2Iterator()
{
	fclose(output);

	cout << "TD2++++Total Cube = " << numCubeTD2 << endl;
	for (int sOrder = 0 ; sOrder < numSortOrder; sOrder++) {
		for (int ii = 0 ; ii < this->sortOrder[sOrder].size() ; ii++) {

			Accumulator* thisAccu = this->sortOrder[sOrder].at(ii);
			if (thisAccu->numNRE  > 0){
				delete [] thisAccu->nreList;
				delete [] thisAccu->dimAnc;
				delete [] thisAccu->dimRel;
				delete [] thisAccu->dimValue;
			}
			delete thisAccu;
		}
		this->sortOrder[sOrder].clear();
	}
	delete [] this->sortOrder;
	delete [] sortOrderWriteCube;
	delete [] sortOrderReadCube;

	if (groupByNRE) delete [] groupByNRE;
	if (groupByWhat) delete  [] groupByWhat;
	if (factByAttrName) delete [] factByAttrName;
	if (factOpOnWhatAttrName) delete [] factOpOnWhatAttrName;
	if (groupByAttrName)
	{
		for (int i=0; i< dimnum; i++)
			if (groupByAttrName[i])
				delete [] groupByAttrName[i];
		delete [] groupByAttrName;
	} 

	for (int i = 0 ; i < size ; i++){
		if (treeArray[i]) delete treeArray[i];
	}
	delete [] treeArray;
	delete [] gSortByDim3;
	delete [] gWhereEmptyGoesDim3;
	delete [] gOrderDim3;
	if (groupByRelaxType) {
		for (int i=0; i< dimnum; i++)
			delete [] groupByRelaxType[i];
		delete [] groupByRelaxType;
	}
	if (subtreeParent) delete [] subtreeParent;
	if (fileName) delete [] fileName;
	if (sortOrderFileName) delete [] sortOrderFileName;
}

void CubeTopDown2Iterator::next(WitnessTree *&node)
{	

	if (at < size)
		node = treeArray[at];
	else
		node = NULL;
	at++;
	return;
}


bool CubeTopDown2Iterator::isDifference(Accumulator* thisAccu, WitnessTree* thisInput,int* whichMissing)
{
	bool diff = false;
	*whichMissing = 0;
	if  (thisAccu->numNRE == 0) return false;
	for (int i = 0 ; i< thisAccu->numNRE ; i++){
		bool accuMissing = false;
		bool treeMissing = false;
		//???possible optimization for NO_MISSING
		if (thisAccu->dimValue[i] == NULL)
		{
			accuMissing = true;
			*whichMissing = 1; //means accu is missing
			//if previous accu contains missing it must be difference
		}
		int ind = NREToIndex[thisAccu->nreList[i]];
		char* dimVal;
		if (thisInput != NULL) {//for checking missing of last tuple
			int r = this->getNodeValue(thisInput,thisAccu->nreList[i],this->groupByAttrName[ind],this->groupByWhat[ind],dimVal);
			if (r == FAILURE) { //if missing
				//means current tuple is missing
				treeMissing = true;
			}
		}
		if (!accuMissing && !treeMissing && thisInput!=NULL)
			if (strcmp(thisAccu->dimValue[i],dimVal) != 0)
				diff = true;
			else ;
		else
			diff = true;
	}
	return diff;
}

int CubeTopDown2Iterator::differenceAt(int sortorder, WitnessTree* thisInput1, WitnessTree* thisInput2)
{

	Accumulator* accu = this->sortOrder[sortorder].at(0);
	for (int i = 0 ; i < accu->numNRE ; i++){
		char *dimVal1, *dimVal2;
		int ind = NREToIndex[accu->nreList[i]];
		int r1 = this->getNodeValue(thisInput1,accu->nreList[i],this->groupByAttrName[ind],this->groupByWhat[ind],dimVal1);

		int r2 = this->getNodeValue(thisInput2,accu->nreList[i],this->groupByAttrName[ind],this->groupByWhat[ind],dimVal2);

		//???possible optimization for NO_MISSING
		if (r1 != FAILURE && r2 == FAILURE) return i;
		else if (r1 == FAILURE && r2 != FAILURE) return i;
		else if (r1 != FAILURE && r2 != FAILURE && (strcmp(dimVal1,dimVal2) != 0)) return i;
	}
	return accu->numNRE+1;
}

bool CubeTopDown2Iterator::checkRelevant(int i, Accumulator* accu)
{
	for (int j =0 ; j < accu->numNRE ; j++) {

		NREType ancNRE;
		int index1 = ((WitnessTree *)treeArray[i])->getIndexOfNRE(accu->nreList[j]);
		if (accu->dimAnc[j] == -1) ancNRE = this->factNRE;
		else ancNRE = accu->dimAnc[j];
		int indexp1 = ((WitnessTree *)treeArray[i])->getIndexOfNRE(ancNRE);
		if (index1 == -1 || indexp1 == -1) return false;
		int levp1 = ((ComplexListNode *)((WitnessTree *)treeArray[i])->getNodeByIndex(indexp1))->GetLevel();
		int lev1 = ((ComplexListNode *)((WitnessTree *)treeArray[i])->getNodeByIndex(index1))->GetLevel();
		KeyType sp1 = ((ComplexListNode *)((WitnessTree *)treeArray[i])->getNodeByIndex(indexp1))->GetStartPos();
		KeyType ep1 = ((ComplexListNode *)((WitnessTree *)treeArray[i])->getNodeByIndex(indexp1))->GetEndPos();
		KeyType s1 = ((ComplexListNode *)((WitnessTree *)treeArray[i])->getNodeByIndex(index1))->GetStartPos();
		KeyType e1 = ((ComplexListNode *)((WitnessTree *)treeArray[i])->getNodeByIndex(index1))->GetEndPos();
		if (accu->dimRel[j] == PARENT_CHILD){
			if (sp1 < s1 && ep1 > e1 && lev1 == levp1 +1)
			{}
			else return false;
		}
		else if (accu->dimRel[j] == ANCS_DESC){
			if (sp1 < s1 && ep1 > e1)
			{}
			else return false;
		}
	}
	return true;
}

void CubeTopDown2Iterator::AggregateAndWriteOutput(Accumulator* curAccu, bool writeCube, int readCube)
{
	bool first = true; //if the first iteration, to set value for OP_MIN,OP_MAX
	double aggrValue;
	double aggregatedValue1 = 0;
	int aggregatedValue2 = 0; //for OP_AVG, store COUNT
	if(this->no_overlap == false) {
		//output old accu
		//change accu to this tuple dim value


		if (this->factByOperation != OP_COUNT) {
			map<char*, WitnessTree*, ltstr>::const_iterator cur = curAccu->fact.begin();
			while (cur != curAccu->fact.end()){
				//go through the map and perform aggregation
				switch (this->factByOperation)
				{
				case OP_SUM:
					{
						if (readCube > -1){
							ComplexListNode* dummy = (ComplexListNode*)((WitnessTree*)((*cur).second)->findNodeNRE(this->assignedDummyNRE1));
							aggregatedValue1 = aggregatedValue1 + atof(dummy->GetDummyName());
						}
						else {
							int ret = this->getNodeValue((*cur).second,this->factOpNRE,this->factOpOnWhat,this->factOpOnWhatAttrName,&aggrValue);
							if (ret == FAILURE) return;
							aggregatedValue1 = aggregatedValue1 + aggrValue;
						}
					}
					break;
				case OP_AVG:
					{
						if (readCube > -1){
							ComplexListNode* dummy = (ComplexListNode*)((WitnessTree*)((*cur).second)->findNodeNRE(this->assignedDummyNRE1));
							aggregatedValue1 = aggregatedValue1 + atof(dummy->GetDummyName());
							dummy = (ComplexListNode*)((WitnessTree*)((*cur).second)->findNodeNRE(this->assignedDummyNRE2));
							aggregatedValue2 = aggregatedValue2 + atoi(dummy->GetDummyName());
						}
						else {
							int ret = this->getNodeValue((*cur).second,this->factOpNRE,this->factOpOnWhat,this->factOpOnWhatAttrName,&aggrValue);
							if (ret == FAILURE) return;
							aggregatedValue1 = aggregatedValue1 + aggrValue;
							aggregatedValue2++;
						}
					}
					break;
				case OP_MIN:
					{
						if (readCube > -1){
							ComplexListNode* dummy = (ComplexListNode*)((WitnessTree*)((*cur).second)->findNodeNRE(this->assignedDummyNRE1));
							if (first) aggregatedValue1 = atof(dummy->GetDummyName());
							else {
								if (aggregatedValue1 >  atof(dummy->GetDummyName()))
									aggregatedValue1 =  atof(dummy->GetDummyName());
							}
						}
						else {
							int ret = this->getNodeValue((*cur).second,this->factOpNRE,this->factOpOnWhat,this->factOpOnWhatAttrName,&aggrValue);
							if (ret == FAILURE) return;
							if (first) aggregatedValue1 = aggrValue;
							else {
								if (aggregatedValue1 > aggrValue)
									aggregatedValue1 = aggrValue;
							}
						}
					}
					break;
				case OP_MAX:
					{
						if (readCube > -1){
							ComplexListNode* dummy = (ComplexListNode*)((WitnessTree*)((*cur).second)->findNodeNRE(this->assignedDummyNRE1));
							if (first) aggregatedValue1 = atof(dummy->GetDummyName());
							else {
								if (aggregatedValue1 <  atof(dummy->GetDummyName()))
									aggregatedValue1 =  atof(dummy->GetDummyName());
							}
						}
						else {
							int ret = this->getNodeValue((*cur).second,this->factOpNRE,this->factOpOnWhat,this->factOpOnWhatAttrName,&aggrValue);
							if (ret == FAILURE) return;
							if (first) aggregatedValue1 = aggrValue;
							else {
								if (aggregatedValue1 < aggrValue)
									aggregatedValue1 = aggrValue;
							}
						}
					}
					break;
				default:
					globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"Evaluator",__FILE__,"Undefined aggregate operation passed to cube iterator.");
					return;
				}
				++cur;
				first = false;
			}
		}
		else{
			if (readCube > -1)
			{
				map<char*, WitnessTree*, ltstr>::const_iterator cur = curAccu->fact.begin();
				while (cur != curAccu->fact.end()){
					ComplexListNode* dummy = (ComplexListNode*)((WitnessTree*)((*cur).second)->findNodeNRE(this->assignedDummyNRE1));
					aggregatedValue1 = aggregatedValue1 + atof(dummy->GetDummyName());
					first = false;
					++cur;
				}
			}
			else {
				aggregatedValue1 = curAccu->fact.size();// for count, we don't even have to iterate
			}	
		}
		// write output

		if (curAccu->fact.size() > 0) {
			//if there's some aggregation of fact
			//size is zero when no tree is relevant to the current accumulator
			//for ex. all trees are AD, so no PC
			numCubeTD2++;
			for (int i =0 ; i < curAccu->numNRE ;i++){
				fprintf(output,"%s %d %d\t",curAccu->dimValue[i],curAccu->dimRel[i],curAccu->dimAnc[i]);
			}
			if (this->factByOperation == OP_AVG) {
				fprintf(output,"%lf/%d\n",aggregatedValue1,aggregatedValue2);
				if (writeCube){
					WitnessTree treeToWrite;
					ComplexListNode* dummy;


					map<char*, WitnessTree*, ltstr>::const_iterator cur = curAccu->fact.begin();
					treeToWrite.copyTree((*cur).second);

					dummy = (ComplexListNode*)treeToWrite.findNodeNRE(this->assignedDummyNRE1);

					if (dummy == NULL){
						dummy = new ComplexListNode;
						dummy->SetDummy(true);
						char tmp[50];
						sprintf(tmp,"%5.3lf",aggregatedValue1);
						dummy->SetDummyName(tmp);

						dummy->SetLocalLevel(0);
						dummy->setNRE(this->assignedDummyNRE1);

						treeToWrite.appendList(dummy,dataMng,1);


					}
					else{ //if already had, itself is an immediate cube,change value
						char tmp[50];
						sprintf(tmp,"%5.3lf",aggregatedValue1);
						dummy->SetDummyName(tmp);
					}

					dummy = (ComplexListNode*)treeToWrite.findNodeNRE(this->assignedDummyNRE2);
					if (dummy == NULL){
						dummy = new ComplexListNode;
						dummy->SetDummy(true);
						char tmp[50];
						sprintf(tmp,"%d",aggregatedValue2);
						dummy->SetDummyName(tmp);
						dummy->SetLocalLevel(0);
						dummy->setNRE(this->assignedDummyNRE2);
						treeToWrite.appendList(dummy,dataMng,1);
					}
					else {
						char tmp[50];
						sprintf(tmp,"%d",aggregatedValue2);
						dummy->SetDummyName(tmp);
					}
					writeTupleToFile(&treeToWrite,writeCubeFile);
				}
			}
			else {
				fprintf(output,"%lf\n",aggregatedValue1);
				if (writeCube){
					WitnessTree treeToWrite;
					ComplexListNode* dummy;
					map<char*, WitnessTree*, ltstr>::const_iterator cur = curAccu->fact.begin();
					treeToWrite.copyTree((*cur).second);


					dummy = (ComplexListNode*)treeToWrite.findNodeNRE(this->assignedDummyNRE1);

					if (dummy == NULL){
						dummy = new ComplexListNode;
						dummy->SetDummy(true);
						char tmp[50];
						sprintf(tmp,"%5.3lf",aggregatedValue1);
						dummy->SetDummyName(tmp);

						dummy->SetLocalLevel(0);
						dummy->setNRE(this->assignedDummyNRE1);
						treeToWrite.appendList(dummy,dataMng,1);
					}
					else{
						char tmp[50];
						sprintf(tmp,"%5.3lf",aggregatedValue1);
						dummy->SetDummyName(tmp);
					}
					writeTupleToFile(&treeToWrite,writeCubeFile);
				}
			}


		}
	}
	else { //optimization, just output from accumulator

		if (!((this->factByOperation == OP_COUNT && curAccu->aggrValue1 == 0) || 
			(this->factByOperation == OP_AVG && curAccu->aggrValue2 == 0) ||
			(this->factByOperation == OP_SUM && curAccu->aggrValue1 == 0) ||
			(this->factByOperation == OP_MIN && curAccu->aggrValue1 == DBL_MAX) ||
			(this->factByOperation == OP_MAX && curAccu->aggrValue1 == DBL_MIN)))
			//check for at least 1 tree that complies with
		{
			numCubeTD2++;
			for (int i =0 ; i < curAccu->numNRE ;i++){
				fprintf(output,"%s %d %d\t",curAccu->dimValue[i],curAccu->dimRel[i],curAccu->dimAnc[i]);
			}
			if (this->factByOperation == OP_AVG) {
				fprintf(output,"%lf/%d\n",curAccu->aggrValue1,curAccu->aggrValue2);
				if (writeCube){
					WitnessTree treeToWrite;
					ComplexListNode* dummy;

					treeToWrite.copyTree(curAccu->aTreeInTheGroup);

					dummy = (ComplexListNode*)treeToWrite.findNodeNRE(this->assignedDummyNRE1);

					if (dummy == NULL){
						dummy = new ComplexListNode;
						dummy->SetDummy(true);
						char tmp[50];
						sprintf(tmp,"%5.3lf",curAccu->aggrValue1);
						dummy->SetDummyName(tmp);

						dummy->SetLocalLevel(0);
						dummy->setNRE(this->assignedDummyNRE1);

						treeToWrite.appendList(dummy,dataMng,1);

					}
					else{ //if already had, itself is an immediate cube,change value
						char tmp[50];
						sprintf(tmp,"%5.3lf",curAccu->aggrValue1);
						dummy->SetDummyName(tmp);
					}

					dummy = (ComplexListNode*)treeToWrite.findNodeNRE(this->assignedDummyNRE2);
					if (dummy == NULL){
						dummy = new ComplexListNode;
						dummy->SetDummy(true);
						char tmp[50];
						sprintf(tmp,"%d",curAccu->aggrValue2);
						dummy->SetDummyName(tmp);
						dummy->SetLocalLevel(0);
						dummy->setNRE(this->assignedDummyNRE2);
						treeToWrite.appendList(dummy,dataMng,1);
					}
					else {
						char tmp[50];
						sprintf(tmp,"%d",curAccu->aggrValue2);
						dummy->SetDummyName(tmp);
					}
					writeTupleToFile(&treeToWrite,writeCubeFile);
				}

			}
			else {
				fprintf(output,"%lf\n",curAccu->aggrValue1);
				if (writeCube){
					WitnessTree treeToWrite;
					ComplexListNode* dummy;
					treeToWrite.copyTree(curAccu->aTreeInTheGroup);

					dummy = (ComplexListNode*)treeToWrite.findNodeNRE(this->assignedDummyNRE1);

					if (dummy == NULL){
						dummy = new ComplexListNode;
						dummy->SetDummy(true);
						char tmp[50];
						sprintf(tmp,"%5.3lf",curAccu->aggrValue1);
						dummy->SetDummyName(tmp);

						dummy->SetLocalLevel(0);
						dummy->setNRE(this->assignedDummyNRE1);
						treeToWrite.appendList(dummy,dataMng,1);
					}
					else{
						char tmp[50];
						sprintf(tmp,"%5.3lf",curAccu->aggrValue1);
						dummy->SetDummyName(tmp);
					}
					writeTupleToFile(&treeToWrite,writeCubeFile);
				}
			}
		}
	}

}

void CubeTopDown2Iterator::Aggregate(Accumulator* thisAccu, WitnessTree* Input, int readCube)
{
	double aggrValue;
	thisAccu->aTreeInTheGroup = Input;
	switch (this->factByOperation)
	{
	case OP_COUNT:
		{
			if (readCube > -1){
				ComplexListNode* dummy = (ComplexListNode*)Input->findNodeNRE(this->assignedDummyNRE1);
				thisAccu->aggrValue1 = thisAccu->aggrValue1 + atof(dummy->GetDummyName());
			}
			else thisAccu->aggrValue1 = thisAccu->aggrValue1 + 1;
		}
		break;
	case OP_SUM:
		{
			if (readCube > -1){
				ComplexListNode* dummy = (ComplexListNode*)Input->findNodeNRE(this->assignedDummyNRE1);
				thisAccu->aggrValue1 = thisAccu->aggrValue1 +  atof(dummy->GetDummyName());
			}
			else {
				int ret = this->getNodeValue(Input,this->factOpNRE,this->factOpOnWhat,this->factOpOnWhatAttrName,&aggrValue);
				if (ret == FAILURE) return;
				thisAccu->aggrValue1 = thisAccu->aggrValue1 + aggrValue;
			}
		}
		break;
	case OP_AVG:
		{
			if (readCube > -1){
				Input->dumpBuffer(stdout,true);
				ComplexListNode* dummy = (ComplexListNode*)Input->findNodeNRE(this->assignedDummyNRE1);
				thisAccu->aggrValue1 = thisAccu->aggrValue1 +  atof(dummy->GetDummyName());
				dummy = (ComplexListNode*)Input->findNodeNRE(this->assignedDummyNRE2);
				thisAccu->aggrValue2 = thisAccu->aggrValue2 +  atoi(dummy->GetDummyName());
			}
			else {
				int ret = this->getNodeValue(Input,this->factOpNRE,this->factOpOnWhat,this->factOpOnWhatAttrName,&aggrValue);
				if (ret == FAILURE) return;
				thisAccu->aggrValue1 = thisAccu->aggrValue1 + aggrValue;
				thisAccu->aggrValue2++;
			}
		}
		break;
	case OP_MIN:
		{
			if (readCube > -1){
				ComplexListNode* dummy = (ComplexListNode*)Input->findNodeNRE(this->assignedDummyNRE1);
				if (thisAccu->aggrValue1 > atof(dummy->GetDummyName()))
					thisAccu->aggrValue1 = atof(dummy->GetDummyName());
			}
			else {
				int ret = this->getNodeValue(Input,this->factOpNRE,this->factOpOnWhat,this->factOpOnWhatAttrName,&aggrValue);
				if (ret == FAILURE) return;
				if (thisAccu->aggrValue1 > aggrValue)
					thisAccu->aggrValue1 = aggrValue;
			}
		}
		break;
	case OP_MAX:
		{
			if (readCube > -1){
				ComplexListNode* dummy = (ComplexListNode*)Input->findNodeNRE(this->assignedDummyNRE1);
				if (thisAccu->aggrValue1 < atof(dummy->GetDummyName()))
					thisAccu->aggrValue1 = atof(dummy->GetDummyName());
			}
			else {
				int ret = this->getNodeValue(Input,this->factOpNRE,this->factOpOnWhat,this->factOpOnWhatAttrName,&aggrValue);
				if (ret == FAILURE) return;
				if (thisAccu->aggrValue1 < aggrValue)
					thisAccu->aggrValue1 = aggrValue;
			}
		}
		break;
	default:
		globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"Evaluator",__FILE__,"Undefined aggregate operation passed to cube iterator.");
		return;
	}
}

int CubeTopDown2Iterator::getNodeValue(WitnessTree* elem1, NREType nre, char* attrName, int nodeGroupByType, char*& charValue)
{
	int index1 = ((WitnessTree *)elem1)->getIndexOfNRE(nre);
	if (index1 == FAILURE)
		return FAILURE;

	FileIDType fileid1 = EvaluatorClass::getFileID(((ComplexListNode *)((WitnessTree *)elem1)->getNodeByIndex(index1))->getFileIndex());
	if (fileid1 == -1)
		return -1;

	switch (nodeGroupByType)
	{
	case GROUPBY_TEXT_NUM:
	case GROUPBY_TEXT_STR:
		{
			int res1 = EvaluatorClass::GetText((WitnessTree *)elem1,index1,this->dataMng,fileid1);
			if (res1 == FAILURE) return FAILURE;
			charValue = ((DM_CharNode *)((ComplexListNode *)((WitnessTree *)elem1)->getNodeByIndex(res1))->GetData())->getCharValue();


		}
		break;
	case GROUPBY_ATTRIBUTE_NUM:
	case GROUPBY_ATTRIBUTE_STR:
		{
			int res1 = EvaluatorClass::GetAttributes((WitnessTree *)elem1,index1,this->dataMng,fileid1);
			if (res1 == FAILURE) return FAILURE;

			Value *val1 = ((DM_AttributeNode *)((ComplexListNode *)((WitnessTree *)elem1)->getNodeByIndex(index1+1))->GetData())->getAttr(attrName);
			if (!val1) return FAILURE;

			charValue = val1->getStrValue();

		}
		break;
	case GROUPBY_VALUE_NUM:
	case GROUPBY_VALUE_STR:
		{
			DM_DataNode *dn1 = ((ComplexListNode *)((WitnessTree *)elem1)->getNodeByIndex(index1))->GetData();
			if (dn1 == NULL)
				return FAILURE;

			if (dn1->getFlag() == ELEMENT_NODE)
				charValue = this->dataMng->getPhysicalDataMng()->getXMLNameTable()->getNameByCode(((DM_ElementNode *)dn1)->getTag());

			else if (dn1->getFlag() == DOCUMENT_NODE)
			{
				if (((DM_DocumentNode *)dn1)->getXMLFileName())
					charValue = ((DM_DocumentNode *)dn1)->getXMLFileName();
				else {
					charValue = NULL;
					return FAILURE;
				}
			}
			else if (dn1->getFlag() == ATTRIBUTE_NODE)
			{
				//if attribute node, return the value of attribute "attrName"

				Value* val1 = ((DM_AttributeNode *)dn1)->getAttr(attrName);
				if (!val1) return FAILURE;

				charValue = val1->getStrValue();

			} 
			else
			{
				//if text node, return the text value
				charValue = ((DM_CharNode *)dn1)->getCharValue();
			}

		}
		break;
	case GROUPBY_STARTKEY:
		{
			charValue = ((ComplexListNode *)((WitnessTree *)elem1)->getNodeByIndex(index1))->GetStartPos().toString();
		}
		break;
	}//switch
	return SUCCESS;

}

int CubeTopDown2Iterator::getNodeValue(WitnessTree* elem1, NREType factOpNRE, int factOpOnWhat, char* factOpAttrName, double* retValue)
{
	int index1 = ((WitnessTree *)elem1)->getIndexOfNRE(factOpNRE);
	if (index1 == FAILURE)
		return FAILURE;

	FileIDType fileid1 = EvaluatorClass::getFileID(((ComplexListNode *)((WitnessTree *)elem1)->getNodeByIndex(index1))->getFileIndex());
	if (fileid1 == -1)
		return FAILURE;

	switch (factOpOnWhat)
	{
	case ON_ATTRIBUTE_NUM:
		{
			int res1 = EvaluatorClass::GetAttributes((WitnessTree *)elem1,index1,this->dataMng,fileid1);
			if (res1 == FAILURE) return FAILURE;

			Value *val1 = ((DM_AttributeNode *)((ComplexListNode *)((WitnessTree *)elem1)->getNodeByIndex(index1+1))->GetData())->getAttr(factOpAttrName);
			if (!val1) return FAILURE;

			*retValue = val1->getRealValue();
		}
		break;
	case ON_TEXT_NUM:
		{
			int res1 = EvaluatorClass::GetText((WitnessTree *)elem1,index1,this->dataMng,fileid1);
			if (res1 == FAILURE) return FAILURE;
			*retValue = atof(((DM_CharNode *)((ComplexListNode *)((WitnessTree *)elem1)->getNodeByIndex(res1))->GetData())->getCharValue());
		}
		break;
	case ON_VALUE_NUM:
		{
			DM_DataNode *dn1 = ((ComplexListNode *)((WitnessTree *)elem1)->getNodeByIndex(index1))->GetData();
			if (dn1 == NULL)
				return FAILURE;

			if (dn1->getFlag() == ELEMENT_NODE)
				*retValue = (double)(((DM_ElementNode *)dn1)->getTag());

			else if (dn1->getFlag() == ATTRIBUTE_NODE)
			{
				//if attribute node, return the value of attribute "attrName"

				Value* val1 = ((DM_AttributeNode *)dn1)->getAttr(factOpAttrName);
				if (!val1) return FAILURE;

				*retValue = val1->getRealValue();

			} 
			else
			{
				//if text node, return the text value
				*retValue = atof(((DM_CharNode *)dn1)->getCharValue());
			}
		}
		break;
	}
	return SUCCESS;
}

void CubeTopDown2Iterator::getSortOrder()
{
	//file for sort order of input
	sortorderInput = fopen(this->sortOrderFileName,"r");
	if (sortorderInput == NULL) cout << "Sort order file open error" << endl;
	char line[100];

	while( fgets( line, 100,  sortorderInput))
	{
		if (strncmp(line,"*",1) == 0) continue; //comment line
		numSortOrder = atoi(line);
		sortOrder = new CubeSortOrder[numSortOrder];
		sortOrderWriteCube = new bool[numSortOrder];
		sortOrderReadCube= new int[numSortOrder];
		for (int i = 0 ; i < numSortOrder; i++){
			fgets( line, 100,  sortorderInput);
			if (strncmp(line,"*",1) == 0) {
				i--;
				continue; //comment line
			}

			char* token = strtok(line,",");
			int numPrefixOrder = 0;
			int readCubeSortOrder, writeCubeSortOrder;
			if (token != NULL) {
				numPrefixOrder = atoi(line);
				token = strtok(NULL,",");
				readCubeSortOrder = atoi(token);
				//cout << "readCubeSortOrder = " << readCubeSortOrder-1 << endl;
				sortOrderReadCube[i] = readCubeSortOrder-1;
				token = strtok(NULL,",");
				writeCubeSortOrder = atoi(token);
				//cout << "writeCubeSortOrder = " << writeCubeSortOrder << endl;
				if (writeCubeSortOrder == 1) sortOrderWriteCube[i] = true;
				else sortOrderWriteCube[i] = false;
			}
			for (int j = 0; j < numPrefixOrder; j++){
				fgets( line, 100,  sortorderInput);
				if (strncmp(line,"*",1) == 0) {
					j--;
					continue; //comment line
				}

				NREType* nreList = NULL;
				char* token = strtok(line,",");
				if (token != NULL) {
					int numDimen = atoi(token); //first item in line is no. of cuboid dimension
					if (numDimen > 0) {
						cur.nreList = new NREType[numDimen];
						cur.dimRel = new int[numDimen];
						cur.dimAnc = new NREType[numDimen];
						nreList = new NREType[numDimen];

						for (int k = 0 ; k < numDimen ; k++){
							token = strtok(NULL,",");
							nreList[k] = atoi(token);
						}
						this->sortOrderRelaxRecursive(i,0, numDimen, nreList);
					}
					else { //for 0, it is ALL cuboid
						Accumulator* thisAccu = new Accumulator;
						thisAccu->numNRE = 0;
						sortOrder[i].push_back(thisAccu);
					}

					if (numDimen > 0){
						delete [] cur.nreList;
						delete [] cur.dimRel;
						delete [] cur.dimAnc;
						if (nreList) delete [] nreList;
					}
				}

			}

		}
		//cout << line << endl;
	}
	fclose(sortorderInput);
}

/*
numDimen = number of dimension for this accumulator
n = starting dimension for this recurse
nreList = the list of nre from text file 6, 7, 8, so that we can insert in Accumulator correctly
*/
void CubeTopDown2Iterator::sortOrderRelaxRecursive(int at, int n, int numDimen, NREType* nreList)
{

	int i = n;
	for (int j = 0 ; j < 4 ; j++){
		if (this->groupByRelaxType[this->NREToIndex[nreList[i]]][j] == true){
			if (j == 0)
			{
				cur.nreList[i] = nreList[i];
				cur.dimRel[i] = ANCS_DESC;
				cur.dimAnc[i] = -1;

			}
			else if (j == 1)
			{
				cur.nreList[i] = nreList[i];
				cur.dimRel[i] = PARENT_CHILD;
				cur.dimAnc[i] = -1;
			}
			else if (j == 2)
			{
				cur.nreList[i] = nreList[i];
				cur.dimRel[i] = ANCS_DESC;
				cur.dimAnc[i] = this->subtreeParent[this->NREToIndex[nreList[i]]];

			}
			else if (j == 3)
			{
				cur.nreList[i] = nreList[i];
				cur.dimRel[i] = PARENT_CHILD;
				cur.dimAnc[i] = this->subtreeParent[this->NREToIndex[nreList[i]]];

			}

			if ( i + 1 < numDimen) {
				sortOrderRelaxRecursive(at,i+1,numDimen,nreList);
			}
			else { //end of recurse, copy accumulator info to the sortorder struct
				Accumulator* newAccu = new Accumulator;
				newAccu->numNRE = numDimen;
				newAccu->nreList = new NREType[numDimen];
				newAccu->dimAnc = new NREType[numDimen];
				newAccu->dimRel = new int[numDimen];
				for (int k = 0 ; k < numDimen ; k++){
					newAccu->nreList[k] = cur.nreList[k];
					newAccu->dimAnc[k] = cur.dimAnc[k];
					newAccu->dimRel[k] = cur.dimRel[k];
				}
				sortOrder[at].push_back(newAccu);
			}
		} //if allowable
	} //for relaxation

}

void CubeTopDown2Iterator::writeTupleToFile(WitnessTree* treeToWrite, FILE* cubeImmediateFile){

	if (!(treeToWrite->isSimple()))
	{

		//writing to the file, number of nodes in witness tree and score of witness tree
		fprintf(cubeImmediateFile,"%d %lf\n",treeToWrite->length(),treeToWrite->getScore());

		//for each node in the witness tree, write its info
		for (int i = 0; i<treeToWrite->length(); i++)
		{
			ComplexListNode *n = (ComplexListNode *)(treeToWrite->findNode(i));

			char emptyStr[8];
			strcpy(emptyStr,"[EMPTY]");
			//write the file name along with start key, end key , level, offset, and nre to the file
			if (n->IsDummy()) {
				//fprintf(output,"d %lf %d %d %s\n",
				fprintf(cubeImmediateFile,"d %.*g %d %d %s\n",
					DBL_DIG+2,n->GetStartPos().toDouble(),(int)n->getNRE(),n->GetLocalLevel(),strcmp(n->GetDummyName(),"") == 0?emptyStr:n->GetDummyName());
			}
			else
			{
				//get the file name that this node came from
				char *fileName = EvaluatorClass::getOpenFileName((int)n->getFileIndex());
				if (fileName == NULL)
				{
					globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"Evaluator",__FILE__,"File is not loaded in Timber.");
					return;
				}
				//fprintf(output,"c %s %lf %lf %d %d %d %d\n",fileName,
				fprintf(cubeImmediateFile,"c %s %.*g %.*g %d %d %d %d\n",fileName,
					DBL_DIG+2,n->GetStartPos().toDouble(),DBL_DIG+2,n->GetEndPos().toDouble(),n->GetLevel(),n->GetOffset(),(int)n->getNRE(),n->GetLocalLevel());
			}
		}
	}
	else
	{

		//writing to the file, number of nodes in witness tree and score of witness tree
		fprintf(cubeImmediateFile,"%d %lf\n",treeToWrite->length(),treeToWrite->getScore());

		//for each node in the witness tree, write its info
		for (int i = 0; i<treeToWrite->length(); i++)
		{
			ListNode *n = (ListNode *)(treeToWrite->findNode(i));

			//get the file name that this node came from
			char *fileName = EvaluatorClass::getOpenFileName((int)n->getFileIndex());
			if (fileName == NULL)
			{
				globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"Evaluator",__FILE__,"File is not loaded in Timber.");
				return;
			}

			//write the file name along with start key, end key , level, offset, and nre to the file
			//fprintf(output,"s %s %lf %lf %d %d %d\n",fileName,
			fprintf(cubeImmediateFile,"s %s %.*g %.*g %d %d %d\n",fileName,
				DBL_DIG+2,n->GetStartPos().toDouble(),DBL_DIG+2,n->GetEndPos().toDouble(),n->GetLevel(),n->GetOffset(),(int)n->getNRE());
		}
	}
}
