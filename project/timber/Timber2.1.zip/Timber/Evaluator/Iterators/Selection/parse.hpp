#include "../../Evaluator/EvaluatorClass.h"

#include "extra.h"

class SelectionPlanParser
{
public:

	static char getIteratorIdentifier(void) ;

	static void getQueryEvalNode(EvaluatorClass* evaluator, char* line, void* queryInput, QueryEvaluationTreeNode*& curr) ;

} ; 

#ifndef WIN32

extern "C" char getIteratorIdentifier(void)
{
	return SelectionPlanParser::getIteratorIdentifier() ;
} ;

extern "C" void getQueryEvalNode(EvaluatorClass* evaluator, char* line, void* queryInput, QueryEvaluationTreeNode*& curr)
{
	return SelectionPlanParser::getQueryEvalNode(evaluator, line, queryInput, curr) ;
} ;

#endif
