
#include "parse.hpp"

char QueryEvaluationTreeSelectionNode::getIdentifier(void) { return 'f'; }

char SelectionPlanParser::getIteratorIdentifier(void) { return 'f'; }

void 
SelectionPlanParser::getQueryEvalNode(EvaluatorClass* evaluator, char* line, void* queryInput, QueryEvaluationTreeNode*& curr)
	    {
		char newLine[MAX_FILE_INTERFACE_LINE_SIZE];
		char origline[MAX_FILE_INTERFACE_LINE_SIZE];
		strcpy(origline,line+2);
		int readNum = 0;
		char *token = strtok(line+2,",");
		if (token == NULL)
		{
		    globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"Evaluator",__FILE__,"Error input from file... expecting number of disjunctive conditions... Filter line...");
		    curr=NULL; return;
		}

		int num1 = atoi(token);

		readNum += strlen(token)+1;
		FilterCondition *filtCond;
		if (num1 >0)
		    filtCond = new FilterCondition[num1]; 
		else 
		{
		    filtCond = NULL;
		    globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"Evaluator",__FILE__,"Error input from file... number of disjunctive conditions should be at least 1... Filter line...");
		    curr=NULL; return;
		}
		bool startOver = false;
		for (int i=0; i<num1; i++)
		{
		    if (startOver)
		    {
			token = strtok(line,",");
			startOver = false;
		    }
		    else
			token = strtok(NULL,",");
		    if (token == NULL)
		    {
			globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"Evaluator",__FILE__,"Error input from file... expecting number of conjunctive conditions in disjunctive... Filter line...");
			curr=NULL; return;
		    }
		    int num2 = atoi(token);
		    readNum += strlen(token)+1;
		    if (num2 <= 0) 
		    {
			delete [] filtCond;
			globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"Evaluator",__FILE__,"Error input from file... number of conjunctive conditions should be at least 1... Filter line...");
			curr=NULL; return;
		    }
		    filtCond[i].setMaxSize(num2);
		    for (int j=0; j<num2; j++)
		    {
			int leftType, rightType,  opr, application;
			NREType nreLeft, nreRight;
			float numLeft, numRight;
			char *strLeft = NULL;
			char *strRight = NULL;
			if (startOver)
			{
			    token = strtok(line,",");
			    startOver = false;
			}
			else
			    token = strtok(NULL,",");
			if (token == NULL)
			{
			    delete [] filtCond;
			    globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"Evaluator",__FILE__,"Error input from file... expecting application in predicate... Filter line...");
			    curr=NULL; return;
			}
			readNum += strlen(token)+1;
			if (strcmp(token,"E") == 0)
			    application = FILTER_APP_EVERY;
			else if (strcmp(token,"AO") == 0)
			    application = FILTER_APP_AT_LEAST_ONE;
			else if (strcmp(token,"EO") == 0)
			    application = FILTER_APP_EXACTLY_ONE;
			else if (strcmp(token,"EX") == 0)
			    application = FILTER_APP_EXACTLY_ONE_EXISTS;
			else
			{
			    delete [] filtCond;
			    globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"Evaluator",__FILE__,"Error input from file... unrecognized application... Filter line...");
			    curr=NULL; return;
			}

			token = strtok(NULL,",");
			if (token == NULL)
			{
			    delete [] filtCond;
			    globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"Evaluator",__FILE__,"Error input from file... expecting leftType in predicate... Filter line...");
			    curr=NULL; return;
			}

			readNum += strlen(token)+1;

			if (strcmp(token,"V") == 0)
			    leftType = FILTER_VALUE;
			else if (strcmp(token,"A") == 0)
			    leftType = FILTER_ATTR_VALUE;
			else if (strcmp(token,"T") == 0)
			    leftType = FILTER_TEXT;
			else if (strcmp(token,"DT") == 0)
			    leftType = FILTER_DESC_TEXT;
			else if (strcmp(token,"L") == 0)
			    leftType = FILTER_LENGTH;
			else if (strcmp(token,"LCV") == 0)
			    leftType = FILTER_LOCALCHILD_VALUE;
			else if (strcmp(token,"LCA") == 0)
			    leftType = FILTER_LOCALCHILD_ATTR_VAL;
			else if (strcmp(token,"LCT") == 0)
			    leftType = FILTER_LOCALCHILD_TEXT;
			else if (strcmp(token,"LCDT") == 0)
			    leftType = FILTER_LOCALCHILD_DESC_TEXT;
			else if (strcmp(token,"LCL") == 0)
			    leftType = FILTER_LOCALCHILD_LENGTH;
			else if (strcmp(token,"ACV") == 0)
			    leftType = FILTER_ACTUALCHILD_VALUE;
			else if (strcmp(token,"ACA") == 0)
			    leftType = FILTER_ACTUALCHILD_ATTR_VAL;
			else if (strcmp(token,"ACT") == 0)
			    leftType = FILTER_ACTUALCHILD_TEXT;
			else if (strcmp(token,"ACDT") == 0)
			    leftType = FILTER_ACTUALCHILD_DESC_TEXT;
			else if (strcmp(token,"ACL") == 0)
			    leftType = FILTER_ACTUALCHILD_LENGTH;
			else if (strcmp(token,"LAV") == 0)
			    leftType = FILTER_LOCALANCS_VALUE;
			else if (strcmp(token,"LAA") == 0)
			    leftType = FILTER_LOCALANCS_ATTR_VAL;
			else if (strcmp(token,"LAT") == 0)
			    leftType = FILTER_LOCALANCS_TEXT;
			else if (strcmp(token,"LADT") == 0)
			    leftType = FILTER_LOCALANCS_DESC_TEXT;
			else if (strcmp(token,"LAL") == 0)
			    leftType = FILTER_LOCALANCS_LENGTH;
			else if (strcmp(token,"AAV") == 0)
			    leftType = FILTER_ACTUALANCS_VALUE;
			else if (strcmp(token,"AAA") == 0)
			    leftType = FILTER_ACTUALANCS_ATTR_VAL;
			else if (strcmp(token,"AAT") == 0)
			    leftType = FILTER_ACTUALANCS_TEXT;
			else if (strcmp(token,"AADT") == 0)
			    leftType = FILTER_ACTUALANCS_DESC_TEXT;
			else if (strcmp(token,"AAL") == 0)
			    leftType = FILTER_ACTUALANCS_LENGTH;
			else if (strcmp(token,"C") == 0)
			    leftType = FILTER_CONST;
			else if (strcmp(token,"CI") == 0)
			    leftType = FILTER_CONST_FROM_ITER;
			else if (strcmp(token,"LF") == 0)
			    leftType = FILTER_LOCAL_FANOUT;
			else if (strcmp(token,"AF") == 0)
			    leftType = FILTER_ACTUAL_FANOUT;
			else if (strcmp(token,"LD") == 0)
			    leftType = FILTER_LOCALSUBTREE_DEPTH;
			else if (strcmp(token,"AD") == 0)
			    leftType = FILTER_ACTUALSUBTREE_DEPTH;    
			else if (strcmp(token,"SK") == 0)
			    leftType = FILTER_STARTKEY;
			else if (strcmp(token,"EK") == 0)
			    leftType = FILTER_ENDKEY;
			else if (strcmp(token,"LEV") == 0)
			    leftType = FILTER_LEVEL;
			else
			{
			    delete [] filtCond;
			    globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"Evaluator",__FILE__,"Error input from file... unrecognized left type... Filter line...");
			    curr=NULL; return;
			}

			token = strtok(NULL,",");
			if (token == NULL)
			{
			    delete [] filtCond;
			    globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"Evaluator",__FILE__,"Error input from file... expecting leftnre in predicate... Filter line...");
			    curr=NULL; return;
			}

			nreLeft = (NREType)atoi(token);
			if (nreLeft > evaluator->maxNRE)
			    evaluator->maxNRE = nreLeft;
			readNum += strlen(token)+1;

			token = strtok(NULL,",");
			if (token == NULL)
			{
			    delete [] filtCond;
			    globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"Evaluator",__FILE__,"Error input from file... expecting left num in predicate... Filter line...");
			    curr=NULL; return;
			}
			readNum += strlen(token) +1;

			numLeft = (float) atof(token);

			token = strtok(NULL,",");
			if (token == NULL)
			{
			    delete [] filtCond;
			    globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"Evaluator",__FILE__,"Error input from file... expecting left str in predicate... Filter line...");
			    curr=NULL; return;
			}
			readNum += strlen(token) +1;

			if (strcmp(token,"<EMPTY>") == 0)
			{
			    strLeft = new char[1];
			    strcpy(strLeft,"");
			}
			else
			{
			    strLeft = new char[strlen(token)+1];
			    strcpy(strLeft,token);
			}
			QueryEvaluationTreeNode *leftOper;
			IteratorClass *leftIter= NULL;
			if (leftType == FILTER_CONST_FROM_ITER)
			{
			    char l[MAX_FILE_INTERFACE_LINE_SIZE];
			    if ((int)strlen(origline) < readNum)
				l[0] = '\0';
			    else
				strcpy(l,origline+readNum);
			    ((std::iostream *)queryInput)->getline(newLine,MAX_FILE_INTERFACE_LINE_SIZE);
			    if (((std::iostream *)queryInput)->eof() != 0)
			    {
				delete [] filtCond;
				delete [] strLeft;
				globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"Evaluator",__FILE__,"Unexpected end of file... filter line...");
				curr=NULL; return;
			    }
			    leftOper = evaluator->getQueryEvalNode(newLine,queryInput);
			    leftIter = evaluator->processQueryEvalNode(leftOper);
			    delete leftOper;
			    strcpy(line,l);
			    readNum = 0;
			    token = strtok(line,",");

			}
			else
			{
			    leftIter = NULL;
			    token = strtok(NULL,",");
			}

			//        token = strtok(NULL,",");
			if (token == NULL)
			{
			    delete [] strLeft;
			    delete [] filtCond;
			    globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"Evaluator",__FILE__,"Expecting operation in Filter Line.");
			    curr=NULL; return;
			}

			readNum += strlen(token) +1;

			if (strcmp(token,"EQN") == 0)
			    opr = FILTER_EQ_NUM;
			else if (strcmp(token,"NEN") == 0)
			    opr = FILTER_NE_NUM;
			else if (strcmp(token,"LTN") == 0)
			    opr = FILTER_LT_NUM;
			else if (strcmp(token,"LEN") == 0)
			    opr = FILTER_LE_NUM;
			else if (strcmp(token,"GTN") == 0)
			    opr = FILTER_GT_NUM;
			else if (strcmp(token,"GEN") == 0)
			    opr = FILTER_GE_NUM;
			else if (strcmp(token,"EQS") == 0)
			    opr = FILTER_EQ_STR;
			else if (strcmp(token,"NES") == 0)
			    opr = FILTER_NE_STR;
			else if (strcmp(token,"LTS") == 0)
			    opr = FILTER_LT_STR;
			else if (strcmp(token,"LES") == 0)
			    opr = FILTER_LE_STR;
			else if (strcmp(token,"GTS") == 0)
			    opr = FILTER_GT_STR;
			else if (strcmp(token,"GES") == 0)
			    opr = FILTER_GE_STR; 
			else if (strcmp(token,"S") == 0)
			    opr = FILTER_STARTS_WITH;
			else if (strcmp(token,"B") == 0)
			    opr = FILTER_IN_BEGINING;
			else if (strcmp(token,"C") == 0)
			    opr = FILTER_CONTAINS;
			else if (strcmp(token,"D") == 0)
			    opr = FILTER_CONTAINED; 
			else if (strcmp(token,"NS") == 0)
			    opr = FILTER_NOT_START_WITH;
			else if (strcmp(token,"NC") == 0)
			    opr = FILTER_NOT_CONTAIN;
			else if (strcmp(token,"CO") == 0)
			    opr = FILTER_CONTAINS_WITH_OFFSET;
			else
			{
			    delete [] filtCond;
			    delete [] strLeft;
			    globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"Evaluator",__FILE__,"Error input from file... unrecognized operation... Filter line...");
			    curr=NULL; return;
			}        

			token = strtok(NULL,",");
			if (token == NULL)
			{
			    delete [] filtCond;
			    delete [] strLeft;
			    globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"Evaluator",__FILE__,"Expecting right type in filter Line.");
			    curr=NULL; return;
			}
			readNum += strlen(token) +1;


			if (strcmp(token,"V") == 0)
			    rightType = FILTER_VALUE;
			else if (strcmp(token,"A") == 0)
			    rightType = FILTER_ATTR_VALUE;
			else if (strcmp(token,"T") == 0)
			    rightType = FILTER_TEXT;
			else if (strcmp(token,"DT") == 0)
			    rightType = FILTER_DESC_TEXT;
			else if (strcmp(token,"L") == 0)
			    rightType = FILTER_LENGTH;
			else if (strcmp(token,"LCV") == 0)
			    rightType = FILTER_LOCALCHILD_VALUE;
			else if (strcmp(token,"LCA") == 0)
			    rightType = FILTER_LOCALCHILD_ATTR_VAL;
			else if (strcmp(token,"LCT") == 0)
			    rightType = FILTER_LOCALCHILD_TEXT;
			else if (strcmp(token,"LCDT") == 0)
			    rightType = FILTER_LOCALCHILD_DESC_TEXT;
			else if (strcmp(token,"LCL") == 0)
			    rightType = FILTER_LOCALCHILD_LENGTH;
			else if (strcmp(token,"ACV") == 0)
			    rightType = FILTER_ACTUALCHILD_VALUE;
			else if (strcmp(token,"ACA") == 0)
			    rightType = FILTER_ACTUALCHILD_ATTR_VAL;
			else if (strcmp(token,"ACT") == 0)
			    rightType = FILTER_ACTUALCHILD_TEXT;
			else if (strcmp(token,"ACDT") == 0)
			    rightType = FILTER_ACTUALCHILD_DESC_TEXT;
			else if (strcmp(token,"ACL") == 0)
			    rightType = FILTER_ACTUALCHILD_LENGTH;
			else if (strcmp(token,"LAV") == 0)
			    rightType = FILTER_LOCALANCS_VALUE;
			else if (strcmp(token,"LAA") == 0)
			    rightType = FILTER_LOCALANCS_ATTR_VAL;
			else if (strcmp(token,"LAT") == 0)
			    rightType = FILTER_LOCALANCS_TEXT;
			else if (strcmp(token,"LADT") == 0)
			    rightType = FILTER_LOCALANCS_DESC_TEXT;
			else if (strcmp(token,"LAL") == 0)
			    rightType = FILTER_LOCALANCS_LENGTH;
			else if (strcmp(token,"AAV") == 0)
			    rightType = FILTER_ACTUALANCS_VALUE;
			else if (strcmp(token,"AAA") == 0)
			    rightType = FILTER_ACTUALANCS_ATTR_VAL;
			else if (strcmp(token,"AAT") == 0)
			    rightType = FILTER_ACTUALANCS_TEXT;
			else if (strcmp(token,"AADT") == 0)
			    rightType = FILTER_ACTUALANCS_DESC_TEXT;
			else if (strcmp(token,"AAL") == 0)
			    rightType = FILTER_ACTUALANCS_LENGTH;
			else if (strcmp(token,"C") == 0)
			    rightType = FILTER_CONST;
			else if (strcmp(token,"CI") == 0)
			    rightType = FILTER_CONST_FROM_ITER;
			else if (strcmp(token,"LF") == 0)
			    rightType = FILTER_LOCAL_FANOUT;
			else if (strcmp(token,"AF") == 0)
			    rightType = FILTER_ACTUAL_FANOUT;
			else if (strcmp(token,"LD") == 0)
			    rightType = FILTER_LOCALSUBTREE_DEPTH;
			else if (strcmp(token,"AD") == 0)
			    rightType = FILTER_ACTUALSUBTREE_DEPTH;    
			else if (strcmp(token,"SK") == 0)
			    rightType = FILTER_STARTKEY;
			else if (strcmp(token,"EK") == 0)
			    rightType = FILTER_ENDKEY;
			else if (strcmp(token,"LEV") == 0)
			    rightType = FILTER_LEVEL;
			else
			{
			    delete [] filtCond;
			    delete [] strLeft;
			    globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"Evaluator",__FILE__,"Error input from file... unrecognized right type... Filter line...");
			    curr=NULL; return;
			}        

			token = strtok(NULL,",");
			if (token == NULL)
			{
			    delete [] filtCond;
			    delete [] strLeft;
			    globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"Evaluator",__FILE__,"Expecting right NRE in filter Line.");
			    curr=NULL; return;
			}

			nreRight = (NREType)atoi(token);
			if (nreRight > evaluator->maxNRE)
			    evaluator->maxNRE = nreRight;
			readNum += strlen(token) +1;

			token = strtok(NULL,",");
			if (token == NULL)
			{
			    delete [] filtCond;
			    delete [] strLeft;
			    globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"Evaluator",__FILE__,"Expecting right num in filter Line.");
			    curr=NULL; return;
			}
			readNum += strlen(token) +1;

			numRight = (float) atof(token);

			token = strtok(NULL,",");
			if (token == NULL)
			{
			    delete [] filtCond;
			    delete [] strLeft;
			    globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"Evaluator",__FILE__,"Expecting right str in filter Line.");
			    curr=NULL; return;
			}
			readNum += strlen(token) +1;

			if (strcmp(token,"<EMPTY>") == 0)
			{
			    strRight = new char[1];
			    strcpy(strRight,"");
			}
			else
			{
			    strRight = new char[strlen(token)+1];
			    strcpy(strRight,token);
			}

			token = strtok(NULL,",");
			char *indexName = NULL;
			char *fileName = NULL;
			if (token == NULL)
			{
			    delete [] filtCond;
			    delete [] strLeft;
			    delete [] strRight;
			    globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"Evaluator",__FILE__,"Expecting join index name or NULL in filter Line.");
			    curr=NULL; return;
			}
			if (strcmp(token,"NULL") != 0)
			{
			    indexName = new char[strlen(token)+1];
			    strcpy(indexName,token);
			}

			token = strtok(NULL,",");
			if (token == NULL)
			{
			    delete [] filtCond;
			    delete [] strLeft;
			    delete [] strRight;
			    if (indexName) delete [] indexName;
			    globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"Evaluator",__FILE__,"Expecting xml file name or NULL in filter Line.");
			    curr=NULL; return;
			}
			if (strcmp(token,"NULL") != 0)
			{
			    fileName = new char[strlen(token)+1];
			    strcpy(fileName,token);
			}
			else if (indexName != NULL)
			{
			    delete [] filtCond;
			    delete [] strLeft;
			    delete [] strRight;
			    globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"Evaluator",__FILE__,"Expecting xml file name or NULL in filter Line. you specified index name, then you have to specify file name. both NULL or both there.");
			    curr=NULL; return;
			}

			QueryEvaluationTreeNode *rightOper;
			IteratorClass *rightIter;
			if (rightType == FILTER_CONST_FROM_ITER)
			{
			    char l[MAX_FILE_INTERFACE_LINE_SIZE];
			    if ((int)strlen(origline) < readNum)
				l[0] = '\0';
			    else
				strcpy(l,origline+readNum);
			    ((std::iostream *)queryInput)->getline(newLine,MAX_FILE_INTERFACE_LINE_SIZE);
			    if (((std::iostream *)queryInput)->eof() != 0)
			    {
				delete [] filtCond;
				delete [] strLeft;
				delete [] strRight;
				if (indexName) delete [] indexName;
				if (fileName) delete [] fileName;
				globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"Evaluator",__FILE__,"Unexpected end of file... filter line...");
				curr=NULL; return;
			    }
			    rightOper = evaluator->getQueryEvalNode(newLine,queryInput);
			    rightIter = evaluator->processQueryEvalNode(rightOper);
			    delete rightOper;
			    strcpy(line,l);
			    readNum = 0;
			    startOver = true;
			}
			else
			    rightIter = NULL;

			evaluator->TransformString(strRight) ;
			evaluator->TransformString(strLeft) ;

			if (leftType != FILTER_CONST_FROM_ITER)
			    leftIter = NULL;
			filtCond[i].InsertCondition(application,leftType,nreLeft,numLeft,strLeft,leftIter,opr,rightType,nreRight,numRight,strRight,rightIter,indexName,fileName,-1);
		    }

		}

		if (((std::iostream *)queryInput)->eof() == 0)
		    ((std::iostream *)queryInput)->getline(newLine,MAX_FILE_INTERFACE_LINE_SIZE);
		else
		{
		    delete [] filtCond;
		    globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"Evaluator",__FILE__,"Unexpected end of file... filter line...");
		    curr=NULL; return;
		}
		QueryEvaluationTreeNode *oper = evaluator->getQueryEvalNode(newLine,queryInput);
		if (oper == NULL)
		{
		    delete [] filtCond;
		    globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"Evaluator",__FILE__,"Unexpected operand returned... Filter line...");
		    curr=NULL; return;
		}
		curr = new QueryEvaluationTreeSelectionNode(filtCond,num1,oper);
	    }

