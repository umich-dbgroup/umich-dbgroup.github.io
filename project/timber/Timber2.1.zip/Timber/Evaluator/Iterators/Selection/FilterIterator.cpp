/*
COPYRIGHT  � 2000-2004 
THE REGENTS OF THE UNIVERSITY OF MICHIGAN
ALL RIGHTS RESERVED

PERMISSION IS GRANTED TO USE, COPY, CREATE DERIVATIVE WORKS AND REDISTRIBUTE THIS SOFTWARE AND SUCH DERIVATIVE WORKS FOR 
NONCOMMERCIAL EDUCATION AND RESEARCH PURPOSES, SO LONG AS NO FEE IS CHARGED, AND SO LONG AS THE COPYRIGHT NOTICE ABOVE, 
THIS GRANT OF PERMISSION, AND THE DISCLAIMER BELOW APPEAR IN ALL COPIES MADE; AND SO LONG AS THE NAME OF THE UNIVERSITY 
OF MICHIGAN IS NOT USED IN ANY ADVERTISING OR PUBLICITY PERTAINING TO THE USE OR DISTRIBUTION OF THIS SOFTWARE WITHOUT 
SPECIFIC, WRITTEN PRIOR AUTHORIZATION.

THIS SOFTWARE IS PROVIDED AS IS, WITHOUT REPRESENTATION FROM THE UNIVERSITY OF MICHIGAN AS TO ITS FITNESS FOR ANY PURPOSE, 
AND WITHOUT WARRANTY BY THE UNIVERSITY OF MICHIGAN OF ANY KIND, EITHER EXPRESS OR IMPLIED, INCLUDING WITHOUT LIMITATION THE 
IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE. THE REGENTS OF THE UNIVERSITY OF MICHIGAN SHALL 
NOT BE LIABLE FOR ANY DAMAGES, INCLUDING SPECIAL, INDIRECT, INCIDENTAL, OR CONSEQUENTIAL DAMAGES, WITH RESPECT TO ANY CLAIM 
ARISING OUT OF OR IN CONNECTION WITH THE USE OF THE SOFTWARE, EVEN IF IT HAS BEEN OR IS HEREAFTER ADVISED OF THE POSSIBILITY 
OF SUCH DAMAGES.
*/

#include "FilterIterator.h"
#include "../../Evaluator/EvaluatorClass.h"

FilterIterator::FilterIterator(IteratorClass *input, int num, FilterCondition *condition,  
									   DataMng *dataMng)
{
	this->input = input;
	this->num = num;
	this->condition = condition;
	
	
	this->dataMng = dataMng;

	offset = 0;
	lastSK = -1;
	input->next(inTuple);
	resultBuffer = new WitnessTree(LIST_NODE_WITH_DATA,dataMng);
}

FilterIterator::~FilterIterator()
{
	delete resultBuffer;
	if (condition)
		delete [] condition;
	
	delete input;
}


void FilterIterator::next(WitnessTree *&node)
{
#ifdef EVAL_TIME_OUT
	clock_t currTime = clock();
	double queryDuration = (double)(currTime - gQueryStartTime) / CLOCKS_PER_SEC;
	if (queryDuration >= gTimeOutAfter)
	{
		globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"Evaluator",__FILE__,"Query Timed Out.");
		node = NULL;
		return;
	}
#endif
	//if we don't have any more input, we are done.
	if (!inTuple)
	{
		node  = NULL;
		return;
	}

	//this is used in one of the filter cases.. the one with the offset. we are keeping the 
	//start key of the current inTuple
	currSK = (inTuple->isSimple()? ((ListNode *)inTuple->findNode(0))->GetStartPos() :
	((ComplexListNode *)inTuple->findNode(0))->GetStartPos());

	//as long as inTuple doesn't satisfy the filter condition, get next
	while (!satisfiesCondition(inTuple))
	{
		input->next(inTuple);
#ifdef EVAL_TIME_OUT
	clock_t currTime = clock();
	double queryDuration = (double)(currTime - gQueryStartTime) / CLOCKS_PER_SEC;
	if (queryDuration >= gTimeOutAfter)
	{
		globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"Evaluator",__FILE__,"Query Timed Out.");
		node = NULL;
		return;
	}
#endif
		if (!inTuple)
		{
			node  = NULL;
			return;
		}
		currSK = (inTuple->isSimple()? ((ListNode *)inTuple->findNode(0))->GetStartPos() :
			((ComplexListNode *)inTuple->findNode(0))->GetStartPos());
	}

	//at this point, inTuple has satisfied the filter condition, copy it to resultBuffer
	resultBuffer->copyTree(inTuple);
	if (resultBuffer->length() > 0)
	{
		node = resultBuffer;
		input->next(inTuple);
	}
	else
		node = NULL;
}


bool FilterIterator::satisfiesCondition(WitnessTree *in)
{

	//this method is used to check if witness tree "in"  satisfies at least one
	// of the disjunctive conditions in the filter condition array
	for (int i=0; i<num; i++)
	{
		//if at least one condition is satisfied, we are done.
		if (satisfiesOneOr(in, &condition[i]))
			return true;
	}
	return false;
}

bool FilterIterator::satisfiesOneOr(WitnessTree *in, FilterCondition *cond)
{

	//this method is used to check if witness tree "in"  satisfies all
	// of the conjunctive conditions in cond
	for (int i=0; i<cond->getNum(); i++)
	{
		//if at least one condition is not satisfied, we are done
		if (!satisfiesOneAnd(in,cond->getCondAt(i)))
			return false;
	}
	return true;
}


bool FilterIterator::satisfiesOneAnd(WitnessTree *in, FilterPredicate *cond)
{
	//this method checks if witness tree "in" satisfies one predicate "cond"
	double leftNum = -1;
	char *leftStr = NULL;
	double rightNum = -1;
	char *rightStr = NULL;
	int leftIndex;
	int rightIndex;
	bool gotRightValue = false;
	bool exactlyOneFound = false;

	int res;
	bool ret= false;

	
	in->startFindNodesNRE(cond->getNRELeft());
	leftIndex = in->getNextIndexNRE();
	if (leftIndex == -1 && cond->getApplication() == FILTER_APP_EVERY)
		return true;

	if (leftIndex == -1)
		return false;

	//first, what operation is being checked. if it is a numerical operation, we get the number from
	// the left and right sides of the predicate. if it is a string operation, we get the strings from
	// the left and right sides of the predicate.
	bool cont = true;
	while (cont)
	{
		if (cond->getIndexName())
		{
			rightIndex = in->getIndexOfNRE(cond->getNRERight());
			if (rightIndex == -1)
				return false;
			ret = getMatchesFromIndex(leftIndex,rightIndex,cond->getIndexName(),(char)cond->getOpenFileIndex());
			goto decision;
		}
		switch (cond->getOperation())
		{
			case FILTER_EQ_NUM:
			case FILTER_NE_NUM:
			case FILTER_LE_NUM:
			case FILTER_LT_NUM:
			case FILTER_GE_NUM:
			case FILTER_GT_NUM:
				// if operation is numerical

				//get leftNum
				res = getNum(in,cond->getLeftType(),cond->getNumLeft(),leftIndex,cond->getStrLeft(), leftNum);
				if (res == FAILURE)
				{
					ret = false;
					goto decision;
				}

				//get rightNum
				if (!gotRightValue)
				{
					rightIndex = in->getIndexOfNRE(cond->getNRERight());
					res = getNum(in,cond->getRightType(),cond->getNumRight(),rightIndex,cond->getStrRight(), rightNum);
					if (res == FAILURE)
						return false;
					gotRightValue = true;
				}
				break;

			case FILTER_EQ_STR:
			case FILTER_NE_STR:
			case FILTER_LE_STR:
			case FILTER_LT_STR:
			case FILTER_GE_STR:
			case FILTER_GT_STR:
			case FILTER_STARTS_WITH:
			case FILTER_IN_BEGINING:
			case FILTER_CONTAINS:
			case FILTER_CONTAINED:
			case FILTER_NOT_CONTAIN:
			case FILTER_NOT_START_WITH:
			case FILTER_CONTAINS_WITH_OFFSET:
				//if operation is a string one

				//get leftStr
				res = getStr(in,cond->getLeftType(),cond->getNumLeft(),leftIndex,cond->getStrLeft(), leftStr);
				if (res == FAILURE)
				{
					ret = false;
					goto decision;
				}

				//get rightStr
				if (!gotRightValue)
				{
					rightIndex = in->getIndexOfNRE(cond->getNRERight());
					res = getStr(in,cond->getRightType(),cond->getNumRight(),rightIndex,cond->getStrRight(), rightStr);
					if (res == FAILURE)
					{
						deleteLeftStr(leftStr,cond);
						return false;
					}
					gotRightValue = true;
				}
				if (leftStr == NULL && rightStr == NULL)
					return true;
				else if (leftStr == NULL || rightStr == NULL)
				{
					deleteLeftStr(leftStr,cond);
					deleteRightStr(rightStr,cond);
					return false;
				}
				break;
		}

		//at this point, we have either leftNum and rightNum or leftStr and rightStr depending on the operation,
		// now compare the left and right sides
		
		switch (cond->getOperation())
		{
		case FILTER_EQ_NUM:	ret = (leftNum==rightNum);break;
		case FILTER_NE_NUM: ret = (leftNum!=rightNum);break;
		case FILTER_LE_NUM: ret = (leftNum<=rightNum);break;
		case FILTER_LT_NUM: ret = (leftNum<rightNum);break;
		case FILTER_GE_NUM: ret = (leftNum>=rightNum);break;
		case FILTER_GT_NUM:	ret = (leftNum>rightNum);break;
		case FILTER_EQ_STR:	ret = (stricmp(leftStr,rightStr) == 0);break;
		case FILTER_NE_STR:	ret = (stricmp(leftStr,rightStr) != 0);break;
		case FILTER_LE_STR:	ret = (stricmp(leftStr,rightStr) <= 0);break;
		case FILTER_LT_STR:	ret = (stricmp(leftStr,rightStr) < 0);break;
		case FILTER_GE_STR:	ret = (stricmp(leftStr,rightStr) >= 0);break;
		case FILTER_GT_STR:	ret = (stricmp(leftStr,rightStr) > 0);break;
		case FILTER_STARTS_WITH: ret = (strncmp(leftStr,rightStr,strlen(rightStr)) == 0);break;
		case FILTER_NOT_START_WITH: ret = (strncmp(leftStr,rightStr,strlen(rightStr)) != 0);break;
		case FILTER_IN_BEGINING: ret = (strncmp(rightStr,leftStr,strlen(leftStr)) == 0);break;
		case FILTER_CONTAINS: ret = (strstr(leftStr,rightStr) != NULL);break;
		case FILTER_NOT_CONTAIN: ret = (strstr(leftStr,rightStr) == NULL);break;
		case FILTER_CONTAINED: ret = (strstr(rightStr,leftStr) != NULL);break;
		case FILTER_CONTAINS_WITH_OFFSET:
			//this case, checks for containment of a string in another starting from the last occurrence of
			// the substring 
			{
			if (lastSK != currSK) 
			{
				offset = 0;
				lastSK = currSK;
			}
			else
			{
				if (offset == 0)
				{
					ret = false;
					break;
				}
			}
			char *loc = strstr(leftStr+offset,rightStr);
			if (loc == NULL)
				ret = false;
			else
			{
				ret = true;
				offset = loc + strlen(rightStr) -leftStr;
			}
										// strstr from offset if not null,advance offset. ret=true
										// else ret = false 
			}					
			break;
		}

		//just freeing up memory used by leftStr and rightStr
		deleteLeftStr(leftStr,cond);
		if (leftIndex == FAILURE)
			break;
decision:
		if (cond->getApplication() == FILTER_APP_EVERY)
		{
			if (ret == false)
				break;
			leftIndex = in->getNextIndexNRE();
			if (leftIndex == FAILURE)
				break;
		}
		else if (cond->getApplication() == FILTER_APP_AT_LEAST_ONE)
		{
			if (ret == true)
				break;
			leftIndex  = in->getNextIndexNRE();
			if (leftIndex == FAILURE)
				break;
		}
		else if (cond->getApplication() == FILTER_APP_EXACTLY_ONE)
		{
			if (ret == true)
			{
				if (exactlyOneFound == false)
					exactlyOneFound = true;
				else
				{
					ret = false;
					break;
				}
			}
			leftIndex  = in->getNextIndexNRE();
			if (leftIndex == FAILURE)
			{
				ret = exactlyOneFound;
				break;
			}
		}
		else
		{
			if (ret == false)
				break;
			leftIndex  = in->getNextIndexNRE();
			if (leftIndex != FAILURE)
			{
				ret = false;
				break;
			}
			else
			{
				ret = true;
				break;
			}
		}
	}
	deleteRightStr(rightStr,cond);
	return ret;
}


int FilterIterator::getNum(WitnessTree *in,int type,double num,int index, char *str, double &valReturned)
{
	//this method gets a number depending on the different parameters of the predicate
	ComplexListNode *n;
	char *val;
	//int index = in->getIndexOfNRE(nre);//in->getActualIndex(index);

	//first, we want to get the node concerned from the DB or the witness tree
	switch (type)
	{
		case FILTER_LOCALCHILD_VALUE:
		case FILTER_LOCALCHILD_LENGTH:	
		case FILTER_LOCALCHILD_ATTR_VAL:
		case FILTER_LOCALCHILD_TEXT:
		case FILTER_LOCALCHILD_DESC_TEXT:
			//find the child node in the witness tree
			index = in->GetChild(index,(int) num);
			if (index == -1)
				return FAILURE;
			break;

		case FILTER_ACTUALCHILD_VALUE:
		case FILTER_ACTUALCHILD_LENGTH:
		case FILTER_ACTUALCHILD_ATTR_VAL:
		case FILTER_ACTUALCHILD_TEXT:
			case FILTER_ACTUALCHILD_DESC_TEXT:
			{
				//get the child node from DB
			FileIDType fileid;
			if (in->isSimple())
				fileid = EvaluatorClass::getFileID(((ListNode *)in->getNodeByIndex(index))->getFileIndex());
			else
				fileid = EvaluatorClass::getFileID(((ComplexListNode *)in->getNodeByIndex(index))->getFileIndex());
			if (fileid == -1)
				return FAILURE;
			index = EvaluatorClass::GetChild(in,index,(int) num,dataMng,fileid);
			if (index == FAILURE)
				return FAILURE;
			}
			break;

		case FILTER_LOCALANCS_VALUE:
		case FILTER_LOCALANCS_LENGTH:
		case FILTER_LOCALANCS_ATTR_VAL:
		case FILTER_LOCALANCS_TEXT:
			case FILTER_LOCALANCS_DESC_TEXT:
			//get ancs node from witness tree
			index = in->GetAncs(index,(int) num);
			if (index == -1)
				return FAILURE;
			break;

		case FILTER_ACTUALANCS_VALUE:
		case FILTER_ACTUALANCS_LENGTH:
		case FILTER_ACTUALANCS_ATTR_VAL:
		case FILTER_ACTUALANCS_TEXT:
			case FILTER_ACTUALANCS_DESC_TEXT:
			{
				//get ancs node from th DB
			FileIDType fileid;
			if (in->isSimple())
				fileid = EvaluatorClass::getFileID(((ListNode *)in->getNodeByIndex(index))->getFileIndex());
			else
				fileid = EvaluatorClass::getFileID(((ComplexListNode *)in->getNodeByIndex(index))->getFileIndex());
			if (fileid == -1)
				return FAILURE;
			index = EvaluatorClass::getAncs(in,index,(int) num,dataMng,fileid);
			if (index == FAILURE)
				return FAILURE;
			}
			break;
		
	}

	//now, index points to the location of the node we need to apply the condition to
	char *txt;
	
	// get the actual number that will be returned
	switch (type)
	{
		case FILTER_STARTKEY:
			//if number is start key
			valReturned = in->isSimple()? ((ListNode *)in->getNodeByIndex(index))->GetStartPos().toDouble() : 
											((ComplexListNode *)in->getNodeByIndex(index))->GetStartPos().toDouble();
			break;
		case FILTER_ENDKEY:
			//end key
			valReturned = in->isSimple()? ((ListNode *)in->getNodeByIndex(index))->GetEndPos().toDouble() : 
											((ComplexListNode *)in->getNodeByIndex(index))->GetEndPos().toDouble();
			break;
		case FILTER_LEVEL:
			//level
			valReturned = (double)(in->isSimple()? ((ListNode *)in->getNodeByIndex(index))->GetLevel() : 
											((ComplexListNode *)in->getNodeByIndex(index))->GetLevel());
			break;
		case FILTER_LENGTH:
		case FILTER_LOCALCHILD_LENGTH:
		case FILTER_ACTUALCHILD_LENGTH:
		case FILTER_LOCALANCS_LENGTH:
		case FILTER_ACTUALANCS_LENGTH:
			//if we are getting the length
			in->switchToComplex(dataMng);
			n = ((ComplexListNode *)in->getNodeByIndex(index));
			if (n->GetData() == NULL)
			{
			/*	FileIDType fileid = EvaluatorClass::getFileID(n->getFileIndex());
				if (fileid == -1)
					return FAILURE;
				res = EvaluatorClass::GetData(n,dataMng,fileid);
				if (res == FAILURE)
					return FAILURE;*/
				return FAILURE;
			}
			//now we want to get the value in node "index". the value depends on the type of the node
			if (getVal(n->GetData(),str,val) == FAILURE)
				return FAILURE;
			//return the length of the value.
			valReturned = (double) strlen(val);
			break;

		case FILTER_VALUE:
		case FILTER_LOCALCHILD_VALUE:
		case FILTER_ACTUALCHILD_VALUE:
		case FILTER_LOCALANCS_VALUE:
		case FILTER_ACTUALANCS_VALUE:
			//if we are gedtting the value itself
			in->switchToComplex(dataMng);
			n = ((ComplexListNode *)in->getNodeByIndex(index));
			if (!n->IsDummy())
			{
				if (n->GetData() == NULL)
				{
				/*	FileIDType fileid = EvaluatorClass::getFileID(n->getFileIndex());
					if (fileid == -1)
						return FAILURE;
					res = EvaluatorClass::GetData(n,dataMng,fileid);
					if (res == FAILURE)
						return FAILURE;*/
					return FAILURE;
				}
				if (getVal(n->GetData(),str,val) == FAILURE)
					return FAILURE;
			}
			else
			{
				if (n->GetDummyName()[0] == '\0')
					return FAILURE;
				//val = n->GetDummyName();
				
			}
			// return the value itself
			valReturned = (double) atof(n->GetDummyName());
			break;

		case FILTER_LOCALCHILD_ATTR_VAL:
		case FILTER_ACTUALCHILD_ATTR_VAL:
		case FILTER_LOCALANCS_ATTR_VAL:
		case FILTER_ACTUALANCS_ATTR_VAL:
		case FILTER_ATTR_VALUE:
			{
				//if the attribute value is what we care about
			in->switchToComplex(dataMng);
			FileIDType fileid = EvaluatorClass::getFileID(((ComplexListNode *)in->getNodeByIndex(index))->getFileIndex());
			if (fileid == -1)
				return FAILURE;
			//get attributes
			if (EvaluatorClass::GetAttributes(in,index,dataMng,fileid) == FAILURE)
				return FAILURE;
			//get the value in teh attributes that we care about
			if (getVal(((ComplexListNode *)in->getNodeByIndex(index+1))->GetData(),str,val) == FAILURE)
				return FAILURE;
			//return the attr value
			valReturned = (double) atof(val);
			}
			break;

		case FILTER_LOCALCHILD_TEXT:
		case FILTER_ACTUALCHILD_TEXT:
		case FILTER_LOCALANCS_TEXT:
		case FILTER_ACTUALANCS_TEXT:
		case FILTER_TEXT:
			{
				//if we want text value
			in->switchToComplex(dataMng);
	
			FileIDType fileid = EvaluatorClass::getFileID(((ComplexListNode *)in->getNodeByIndex(index))->getFileIndex());
			if (fileid == -1)
				return FAILURE;

			//get teh text under node "index"
			txt = EvaluatorClass::returnText(in,index,dataMng,fileid);
			if (txt == NULL)
				return FAILURE;
		
			//return the number we care about
			valReturned = (double) atof(txt);
			delete [] txt;
			}
			break;
		case FILTER_LOCALCHILD_DESC_TEXT:
		case FILTER_ACTUALCHILD_DESC_TEXT:
		case FILTER_LOCALANCS_DESC_TEXT:
		case FILTER_ACTUALANCS_DESC_TEXT:
		case FILTER_DESC_TEXT:
			{
				//if we want text value
			in->switchToComplex(dataMng);
	
			FileIDType fileid = EvaluatorClass::getFileID(((ComplexListNode *)in->getNodeByIndex(index))->getFileIndex());
			if (fileid == -1)
				return FAILURE;

			//get teh text under node "index"
			txt = EvaluatorClass::returnText(in,index,dataMng,fileid,true);
			if (txt == NULL)
				return FAILURE;
		
			//return the number we care about
			valReturned = (double) atof(txt);
			delete [] txt;
			}
			break;
		case FILTER_CONST:
			//if this side is just a const, return the number
			valReturned = num;
			break;

		case FILTER_CONST_FROM_ITER:
			//if this side is a number that an iterator has calculated
			valReturned = (float)atof(str);
			break;

		case FILTER_LOCAL_FANOUT:
			//if this side is the fan out, return the number of children in teh witness tree
			valReturned = (double)in->getNumChildren(index);
			if (valReturned == -1)
				return FAILURE;
			break;

		case FILTER_ACTUAL_FANOUT:
			{
				//if this side is the actual fanout, return the number of children in the DB
			FileIDType fileid;
			if (in->isSimple())
				fileid = EvaluatorClass::getFileID(((ListNode *)in->getNodeByIndex(index))->getFileIndex());
			else
				fileid = EvaluatorClass::getFileID(((ComplexListNode *)in->getNodeByIndex(index))->getFileIndex());
			if (fileid == -1)
				return FAILURE;
			valReturned = (double) EvaluatorClass::GetNumChildren(in,index,dataMng,fileid);
			if (valReturned == -1)
				return FAILURE;
			}
			break;

		case FILTER_LOCALSUBTREE_DEPTH:
			//if the number we care about is the local depth, return the depth in the witness tree of 
			// node "index"
			valReturned = (double)in->getSubTreeDepth(index);
			if (valReturned == -1)
				return FAILURE;
			break;

		case FILTER_ACTUALSUBTREE_DEPTH:
			{
				//if the number we care about is the actual depth, return the depth in the DB of 
			// node "index"
				FileIDType fileid;
			if (in->isSimple())
				fileid = EvaluatorClass::getFileID(((ListNode *)in->getNodeByIndex(index))->getFileIndex());
			else
				fileid = EvaluatorClass::getFileID(((ComplexListNode *)in->getNodeByIndex(index))->getFileIndex());
			if (fileid == -1)
				return FAILURE;
			valReturned = (double) EvaluatorClass::GetSubtreeDepth(in,index,dataMng,fileid);
			if (valReturned == -1)
				return FAILURE;
			}
			break;
	}
	return SUCCESS;

}
	

int FilterIterator::getStr(WitnessTree *in,int type,double num,int index, char *str, char *&valReturned)
{
	//this method gets a string depending on the different parameters of the predicate
	ComplexListNode *n;
//	int index = in->getIndexOfNRE(nre);//in->getActualIndex(index);

	//first, we want to get the node concerned from the DB or the witness tree
	switch (type)
	{
		case FILTER_LOCALCHILD_VALUE:	
		case FILTER_LOCALCHILD_ATTR_VAL:
		case FILTER_LOCALCHILD_TEXT:
		case FILTER_LOCALCHILD_DESC_TEXT:
			//get the index of the child in the witness tree
			index = in->GetChild(index,(int) num);
			if (index == -1)
				return FAILURE;
			
			break;

		case FILTER_ACTUALCHILD_VALUE:
		case FILTER_ACTUALCHILD_ATTR_VAL:
		case FILTER_ACTUALCHILD_TEXT:
			case FILTER_ACTUALCHILD_DESC_TEXT:
			{
				// get the index of the child in teh DB
			FileIDType fileid;
			if (in->isSimple())
				fileid = EvaluatorClass::getFileID(((ListNode *)in->getNodeByIndex(index))->getFileIndex());
			else
				fileid = EvaluatorClass::getFileID(((ComplexListNode *)in->getNodeByIndex(index))->getFileIndex());
			if (fileid == -1)
				return FAILURE;
			index = EvaluatorClass::GetChild(in,index,(int) num,dataMng,fileid);
			if (index == FAILURE)
				return FAILURE;
			}
			break;

		case FILTER_LOCALANCS_VALUE:
		case FILTER_LOCALANCS_ATTR_VAL:
		case FILTER_LOCALANCS_TEXT:
		case FILTER_LOCALANCS_DESC_TEXT:
			//get the index of teh ancs node in the witness tree
			index = in->GetAncs(index,(int) num);
			if (index == -1)
				return FAILURE;
			break;

		case FILTER_ACTUALANCS_VALUE:
		case FILTER_ACTUALANCS_ATTR_VAL:
		case FILTER_ACTUALANCS_TEXT:
			case FILTER_ACTUALANCS_DESC_TEXT:
			{
				//get the the ancs node from the DB
				FileIDType fileid;
			if (in->isSimple())
				fileid = EvaluatorClass::getFileID(((ListNode *)in->getNodeByIndex(index))->getFileIndex());
			else
				fileid = EvaluatorClass::getFileID(((ComplexListNode *)in->getNodeByIndex(index))->getFileIndex());
			if (fileid == -1)
				return FAILURE;
			index = EvaluatorClass::getAncs(in,index,(int) num,dataMng,fileid);
			if (index == FAILURE)
				return FAILURE;
			
			}
			break;
		
	}


	//now, we have the index of the node we care about in the var "index". we need to get the string itself.
	switch (type)
	{
		case FILTER_VALUE:
		case FILTER_LOCALCHILD_VALUE:
		case FILTER_ACTUALCHILD_VALUE:
		case FILTER_LOCALANCS_VALUE:
		case FILTER_ACTUALANCS_VALUE:
			//if we care about the actual value, get teh data and extract teh value
			in->switchToComplex(dataMng);
			n = ((ComplexListNode *)in->getNodeByIndex(index));
			if (!n->IsDummy())
			{
				if (n->GetData() == NULL)
				{
				/*	FileIDType fileid = EvaluatorClass::getFileID(n->getFileIndex());
					if (fileid == -1)
						return FAILURE;
					res = EvaluatorClass::GetData(n,dataMng,fileid);
					if (res == FAILURE)
						return FAILURE;
					*/
					return FAILURE;
				}
				// get teh value itself from the node
				if (getVal(n->GetData(),str,valReturned) == FAILURE)
					return FAILURE;
			}
			else
			{
				valReturned = new char [strlen(n->GetDummyName())+1];
				strcpy(valReturned, n->GetDummyName()) ;
			}
			break;

		case FILTER_LOCALCHILD_ATTR_VAL:
		case FILTER_ACTUALCHILD_ATTR_VAL:
		case FILTER_LOCALANCS_ATTR_VAL:
		case FILTER_ACTUALANCS_ATTR_VAL:
		case FILTER_ATTR_VALUE:
			{
				//if we care about attr value of node in index
			in->switchToComplex(dataMng);
			FileIDType fileid = EvaluatorClass::getFileID(((ComplexListNode *)in->getNodeByIndex(index))->getFileIndex());
			if (fileid == -1)
				return FAILURE;

			//get attribute node
			if (EvaluatorClass::GetAttributes(in,index,dataMng,fileid) == FAILURE)
				return FAILURE;
		
			//get val of attribute we care about
			if (getVal(((ComplexListNode *)in->getNodeByIndex(index+1))->GetData(),str,valReturned) == FAILURE)
				return FAILURE;
			}
			break;

		case FILTER_LOCALCHILD_TEXT:
		case FILTER_ACTUALCHILD_TEXT:
		case FILTER_LOCALANCS_TEXT:
		case FILTER_ACTUALANCS_TEXT:
		case FILTER_TEXT:
			{
				//if we care about the text of node in index "index"
			in->switchToComplex(dataMng);
			FileIDType fileid = EvaluatorClass::getFileID(((ComplexListNode *)in->getNodeByIndex(index))->getFileIndex());
			if (fileid == -1)
				return FAILURE;
			//get text itself
			valReturned = EvaluatorClass::returnText(in,index,dataMng,fileid);
			if (valReturned == NULL)
				return FAILURE;
			}
			break;

		case FILTER_LOCALCHILD_DESC_TEXT:
		case FILTER_ACTUALCHILD_DESC_TEXT:
		case FILTER_LOCALANCS_DESC_TEXT:
		case FILTER_ACTUALANCS_DESC_TEXT:
		case FILTER_DESC_TEXT:
			{
			//if we care about the text of node in index "index"
			in->switchToComplex(dataMng);
			FileIDType fileid = EvaluatorClass::getFileID(((ComplexListNode *)in->getNodeByIndex(index))->getFileIndex());
			if (fileid == -1)
				return FAILURE;
			//get text itself
			valReturned = EvaluatorClass::returnText(in,index,dataMng,fileid,true);
			if (valReturned == NULL)
				return FAILURE;
			}
			break;
		case FILTER_CONST:
		case FILTER_CONST_FROM_ITER:
			//if we are comparing with a const or an iterator calculated value, then return str
			valReturned = str;
			break;
	}
	return SUCCESS;

}


int FilterIterator::getVal(DM_DataNode *n, char *str, char *&value)
{
	//this method returns in the string "value" the value of a node depending on its type.
	Value *val;
	switch (n->getFlag())
	{
	case ELEMENT_NODE:
		//if it is an element node, return its tag
		value = dataMng->getPhysicalDataMng()->getXMLNameTable()->getNameByCode(n->getTag());
		break;
	case DOCUMENT_NODE:
		//if document node, return the xml file name
		value = ((DM_DocumentNode *)n)->getXMLFileName();
		break;
	case ATTRIBUTE_NODE:
		//if attribute node, return the value of attribute "str"
		val = ((DM_AttributeNode *)n)->getAttr(str);
		if (val == NULL)
			return FAILURE;
		if (val->getStrValue() == NULL || strlen(val->getStrValue()) == 0)
			return FAILURE;
		value = val->getStrValue();
		break;
	case TEXT_NODE:
		//if text node, return the text value
		value = ((DM_CharNode *)n)->getCharValue();
		break;
	default:
		cout<<"ERROR: Unrecognized node type or comment node. Node id "<<n->getKey().toDouble()<<". FilterIterator."<<endl;
		return FAILURE;	
	}
	return SUCCESS;
}

void FilterIterator::deleteLeftStr(char *&leftStr, FilterPredicate *cond)
{
	int conditionType  ;

	if (cond->getOperation() == FILTER_EQ_STR ||
			cond->getOperation() == FILTER_NE_STR ||
			cond->getOperation() == FILTER_LE_STR ||
			cond->getOperation() == FILTER_LT_STR ||
			cond->getOperation() == FILTER_GE_STR ||
			cond->getOperation() == FILTER_GT_STR ||
			cond->getOperation() == FILTER_STARTS_WITH ||
			cond->getOperation() == FILTER_IN_BEGINING ||
			cond->getOperation() == FILTER_CONTAINS ||
			cond->getOperation() == FILTER_CONTAINED ||
			cond->getOperation() == FILTER_NOT_CONTAIN ||
			cond->getOperation() == FILTER_NOT_START_WITH)
		{
			conditionType = cond->getLeftType() ;

			if (leftStr && (conditionType == FILTER_LOCALCHILD_TEXT ||
				conditionType == FILTER_LOCALCHILD_DESC_TEXT ||
				conditionType == FILTER_ACTUALCHILD_TEXT ||
				conditionType == FILTER_ACTUALCHILD_DESC_TEXT ||
				conditionType == FILTER_LOCALANCS_TEXT ||
				conditionType == FILTER_LOCALANCS_DESC_TEXT ||
				conditionType == FILTER_ACTUALANCS_TEXT ||
				conditionType == FILTER_LOCALANCS_DESC_TEXT ||
				conditionType == FILTER_TEXT ||
				conditionType == FILTER_DESC_TEXT ||
				conditionType == FILTER_VALUE ||
				conditionType == FILTER_LOCALCHILD_VALUE ||
				conditionType == FILTER_ACTUALCHILD_VALUE ||
				conditionType == FILTER_LOCALANCS_VALUE ||
				conditionType == FILTER_ACTUALANCS_VALUE))
			{
				delete [] leftStr;
				leftStr = NULL;
			}
		}
}

void FilterIterator::deleteRightStr(char *&rightStr, FilterPredicate *cond)
{
	int conditionType ;

	if (cond->getOperation() == FILTER_EQ_STR ||
			cond->getOperation() == FILTER_NE_STR ||
			cond->getOperation() == FILTER_LE_STR ||
			cond->getOperation() == FILTER_LT_STR ||
			cond->getOperation() == FILTER_GE_STR ||
			cond->getOperation() == FILTER_GT_STR ||
			cond->getOperation() == FILTER_STARTS_WITH ||
			cond->getOperation() == FILTER_IN_BEGINING ||
			cond->getOperation() == FILTER_CONTAINS ||
			cond->getOperation() == FILTER_CONTAINED ||
			cond->getOperation() == FILTER_NOT_CONTAIN ||
			cond->getOperation() == FILTER_NOT_START_WITH)
	{
			conditionType = cond->getRightType() ;

			if (rightStr && (conditionType == FILTER_LOCALCHILD_TEXT ||
				conditionType == FILTER_LOCALCHILD_DESC_TEXT ||
				conditionType == FILTER_ACTUALCHILD_TEXT ||
				conditionType == FILTER_ACTUALCHILD_DESC_TEXT ||
				conditionType == FILTER_LOCALANCS_TEXT ||
				conditionType == FILTER_LOCALANCS_DESC_TEXT ||
				conditionType == FILTER_ACTUALANCS_TEXT ||
				conditionType == FILTER_LOCALANCS_DESC_TEXT ||
				conditionType == FILTER_TEXT ||
				conditionType == FILTER_DESC_TEXT ||
				conditionType == FILTER_VALUE ||
				conditionType == FILTER_LOCALCHILD_VALUE ||
				conditionType == FILTER_ACTUALCHILD_VALUE ||
				conditionType == FILTER_LOCALANCS_VALUE ||
				conditionType == FILTER_ACTUALANCS_VALUE))
		{
			delete [] rightStr;
			rightStr = NULL;
		}
	}
}

bool FilterIterator::getMatchesFromIndex(int leftIndex, int rightIndex, char *indexName, char openFileIndex)
{
	KeyType leftSK = inTuple->isSimple()? ((ListNode *)inTuple->getNodeByIndex(leftIndex))->GetStartPos():
						((ComplexListNode *)inTuple->getNodeByIndex(leftIndex))->GetStartPos();
	KeyType rightSK = inTuple->isSimple()? ((ListNode *)inTuple->getNodeByIndex(rightIndex))->GetStartPos():
						((ComplexListNode *)inTuple->getNodeByIndex(rightIndex))->GetStartPos();

	bt_query_t *pred;
	pred = new bt_query_t(bt_query_t::bt_eq, new double(leftSK.toDouble()), NULL);
	char *newIndexName = new char[strlen(indexName)+1];
	strcpy(newIndexName,indexName);
	GistIndexAccess *right = new GistIndexAccess(newIndexName,pred,DOUBLE_INDEX,openFileIndex,SUPPLEMENTARY_NODES_NRE);
	WitnessTree *rightTuple;

	right->next(rightTuple);
	while (rightTuple)
	{
		KeyType indexSK = ((ListNode *)rightTuple->getNodeByIndex(0))->GetStartPos();
		if (indexSK == rightSK)
		{
			delete right;
			return true;
		}
		right->next(rightTuple);
	}

	delete right;
	return false;
}
