#include "../../Evaluator/EvaluatorClass.h"

#include "QueryEvaluationTreeOneSidedValueJoinNode.h"

#include "OneSidedValueJoinIterator.h"
#include "extra.h"

void QueryEvaluationTreeOneSidedValueJoinNode::processQueryEvalNode(EvaluatorClass* evaluator, IteratorClass*& curr)
	    {
		int openFileIndex= evaluator->openFile(getFileName(),evaluator->getDataManager());
		if (openFileIndex == -1)
		{
		    globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"Evaluator",__FILE__,"File is unloaded in Timber.");
		    curr=NULL; return;
		}
		IteratorClass *opr = evaluator->processQueryEvalNode(getOper());

		if (opr == NULL)
		{
		    globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"Evaluator",__FILE__, "operand returned is NULL. one sided value join process eval node..." );
		    curr=NULL; return;
		}

		curr = new OneSidedValueJoinIterator(opr,getIndexName(),(char)openFileIndex,getLeftNRE(),getRightNRE(),
			getNest(),getOuter(),getRootNRE(),evaluator->getDataManager());
		setIndexName(NULL);
	    }

