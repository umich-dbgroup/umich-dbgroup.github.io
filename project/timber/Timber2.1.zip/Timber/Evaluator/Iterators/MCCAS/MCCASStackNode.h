/*
COPYRIGHT  (c) 2000-2004 
THE REGENTS OF THE UNIVERSITY OF MICHIGAN
ALL RIGHTS RESERVED

PERMISSION IS GRANTED TO USE, COPY, CREATE DERIVATIVE WORKS AND
REDISTRIBUTE THIS SOFTWARE AND SUCH DERIVATIVE WORKS FOR NONCOMMERCIAL
EDUCATION AND RESEARCH PURPOSES, SO LONG AS NO FEE IS CHARGED, AND SO LONG
AS THE COPYRIGHT NOTICE ABOVE, THIS GRANT OF PERMISSION, AND THE
DISCLAIMER BELOW APPEAR IN ALL COPIES MADE; AND SO LONG AS THE NAME OF THE
UNIVERSITY OF MICHIGAN IS NOT USED IN ANY ADVERTISING OR PUBLICITY
PERTAINING TO THE USE OR DISTRIBUTION OF THIS SOFTWARE WITHOUT SPECIFIC,
WRITTEN PRIOR AUTHORIZATION.

THIS SOFTWARE IS PROVIDED AS IS, WITHOUT REPRESENTATION FROM THE
UNIVERSITY OF MICHIGAN AS TO ITS FITNESS FOR ANY PURPOSE, AND WITHOUT
WARRANTY BY THE UNIVERSITY OF MICHIGAN OF ANY KIND, EITHER EXPRESS OR
IMPLIED, INCLUDING WITHOUT LIMITATION THE IMPLIED WARRANTIES OF
MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE. THE REGENTS OF THE
UNIVERSITY OF MICHIGAN SHALL NOT BE LIABLE FOR ANY DAMAGES, INCLUDING
SPECIAL, INDIRECT, INCIDENTAL, OR CONSEQUENTIAL DAMAGES, WITH RESPECT TO
ANY CLAIM ARISING OUT OF OR IN CONNECTION WITH THE USE OF THE SOFTWARE,
EVEN IF IT HAS BEEN OR IS HEREAFTER ADVISED OF THE POSSIBILITY OF SUCH
DAMAGES.
*/

#ifndef __MCCASStackNode_h
#define __MCCASStackNode_h
#include <timber-compat.h>

#include <bitset>
using std::bitset;
#include "../StructuralJoin/SBJoinDescStackNode.h"
#include "../../Common/WitnessTree.h"

/**
* Define data structure MCCASStackNode and operations allowed on the data structure used by MLCAS(MCCAS)
* MeaningfulClosestCommonAncestorStructure
* @see SBJoinDescStackNode
* @see WitnessTree
* @author Yunyao Li
*/

/**
* the maximum number of nodes allowed in a MCCAS
**/
#define MAX_NUM_VARIABLE 16

/**
* the MLCAS sub-structures of current stack node consums the MLCAS sub-structures of another stack node
**/
#define CONSUMED_BY 1

/**
* the MLCAS sub-structures of current stack node is subsumed by the MLCAS sub-structures of another stack node
**/
#define SUBSUMED_BY 2

/**
* the MLCAS sub-structures of current stack node equals to the MLCAS sub-structures of another stack node
**/
#define EQUAL 3

/**
* the MLCAS sub-structures of current stack node have no overlap with the MLCAS sub-structures of another stack node
**/
#define NO_OVERLAP 4

/**
* the MLCAS sub-structures of current stack node have overlap with the MLCAS sub-structures of another stack node
* but they have no consumption relationship or equality relationship with each other
**/
#define HAVE_OVERLAP 5

/**
* A stack node used in MeaninfulClosestCommonAncestorStructure Class. Derived from SBJoinDescStackNode class.
* Each stack node is associated with a bitset named signature that represents which tagnames in the queries has been included in the link list of this stack node
* @see SimpleStackNode
* @see stack
* @see MeaninfulClosestCommonAncestorStructureIterator
* @author Yunyao Li
* @version 1.0
* @note Meaningful Closest Common Ancestor Structure (MCCAS) = Meaningful Lowest Common Ancestor Structure (MLCAS)
*/
class MCCASStackNode : public SBJoinDescStackNode
{
public:
	/**
	Constructor.
	Initializes data members.
	**/
	MCCASStackNode();
	
	/**
	Destructor.
	**/
	virtual ~MCCASStackNode();

	/**
	Process Method.
	initializes the data members.
	**/
	void initialize();

	/**
	Access Method.
	@returns the signautre of the MCCAS stack node
	this number works as signature of the node, similar to the signature of a signature file.
	**/
	bitset<MAX_NUM_VARIABLE> GetSignature();

	/**
	Process Method.
	set the value of the signature
	@param sign is the new signautre
	**/
    void SetSignature(bitset<MAX_NUM_VARIABLE> sign);

   	/**
    whether current node is the root of a mccas
	@param num is the number of keywords (tag names) contained in the MCCAS
	@return TRUE, if current 
	**/
	bool IsMCCAS(int num, bool *isOptional);

	/**
	whether current node belongs to a tagname in query itself
	**/
	bool  IsKey();

	/**
	mark current node to be a node belonging to a tagname in query
	**/
	void  SetKey();

	/**
	mark current node to be a node not belonging to a tagname in query
	**/
	void  ResetKey();

	/**
	print out the content of node
	1. all == true: print out nodes along with other info
	2. all == false, print out other info only without the lists
	**/
	void  PrintNode(bool all);

	/**
	copy MCCAS stack node
	**/
	void CopyStackNode(MCCASStackNode * stacknode);

	/**---- start new -------**/
    /**
	Access Method.
	@returns a pointer to buffer given index number
	**/
	ContainerClass * GetBufferByIndex(int index);

	/**
	Access Method.
	@returns a pointer to list given index number
	**/
	ShoreList * GetListByIndex(int index);

	/**
	Access Method.
	@returns a signature of the list with given index number
	**/
	bitset<MAX_NUM_VARIABLE> GetSignByIndex(int index);

	/**
	Process Method.
	@sets a signature of the list with given index number
	**/
	void SetSignByIndex(int index, bitset<MAX_NUM_VARIABLE> newSign);

	/**
	Process Method.
	Sets the buffer by given index
	**/
	void SetBufferByIndex(int index);

	/**
	Process Method.
	Sets the list by given index
	**/
	void SetListByIndex(int index);

	/**
	Process Method.
	Sets the value of the volume id and the file id used in shore lists.
	@param volumeID is the volume id.
	@param fileID is the current file id.
	**/
	void SetListsVolumeAndFileIDsByIndex(lvid_t volumeID,serial_t fileID, int index);

	/**
	Process Method.
	Sets the value of the volume id and the file id used in shore lists.
	@param volumeID is the volume id.
	@param fileID is the current file id.
	**/
	void SetListsVolumeAndFileIDs(lvid_t volumeID,serial_t fileID, int numOfLists);

	/**
	Process Method.
	Sets the number of non-empty link lists associated with the node 
	**/
	void SetNumOfStructure(int numOfLists);

	/**
	Acess Method.
	Returns the number of non-empty link lists associated with the node 
	**/
	int GetNumOfStructure();

	/**
    Process Method.
	**/
	void SetMaxByIndex(int index, int id);

	/**
	TODO: detele this
    Acess Method.
	**/
	int GetMaxByIndex(int index);

	/**
	TODO: detele this
    Process Method.
	**/
	void SetMinByIndex(int index, int id);

	/**
    Acess Method.
	**/
	int GetMinByIndex(int index);

	/**
    Process Method.
	**/
	void SetGlobalMax(int maxID);

	/**
    Acess Method.
	**/
	int GetGlobalMax();

	/**
    Process Method.
	**/
	void SetGlobalMin(int minID);

	/**
    Acess Method.
	**/
	int GetGlobalMin();

	/**
	Access Method:
	return 1: type of relationship between a given signature with the structures contained by the stack node
	**/
	int TypeOfRelationship(bitset<MAX_NUM_VARIABLE> signature, bool *isOptional, bool &isMaterial, int &index, bool optionalCount);

	/**
	Access Method
	**/
	bool IsEmpty();

	/**
	Process Method
	**/
	void SetEmpty();

	/**
	Process Method
	**/
	void ResetEmpty();

	/**
	Access Method
	**/
	int GetKeyValue();

	/**
	Process Method
	**/
	void SetKeyValue(int keyValue);

	/**
	Process Method
	**/
	bool DeleteSignByIndex(int index);

	/**
	Access Method
	**/
	WitnessTree * GetActualAncsWithSubtree();

    /**
	Process Method
	**/
	void SetActualAncsWithSubtree(WitnessTree * tree);
	/**----  end new  -------**/

	/* added by Shurug to prepare to delete this node when
	increasing the stack size*/
	void prepareToCopyDelete();
private:
	bitset<MAX_NUM_VARIABLE> signature;
	bool key;
	bool empty;
	int keyValue;
	
	/**---- start new -------**/
   	/**
	a memory buffer 
	**/
	ContainerClass listBuffers[MAX_NUM_VARIABLE];

	/**
	a disk list
	**/
	ShoreList lists[MAX_NUM_VARIABLE];

	/**
	a witness tree
	**/
	WitnessTree * actualAncsWithSubtree;

	// signature of lists that are associated with each other via nodes other than current stacknode
	// nodes from such lists form CCA structures.
	bitset<MAX_NUM_VARIABLE> signOfLists[MAX_NUM_VARIABLE];

	/**
	number of non-all-zero signatures contained by signOfLists
	**/
	int numOfStructure;

	/**
	max id of nodes within the corresponding link list
	**/
	int maxID[MAX_NUM_VARIABLE];

	/**
	min of nodes within the corresponding link list
	**/
	int minID[MAX_NUM_VARIABLE];

	/**
	**/
	int globalMinID;

	/**
	max id of all the nodes in the link lists
	**/
	int globalMaxID;

	/**---- end new ---------**/
};

#endif
