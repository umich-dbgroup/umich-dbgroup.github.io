#include "../../QueryEvaluationTree/QueryEvaluationTreeNode.h"

#ifndef __QueryEvaluationMCCASNode_H
#define __QueryEvaluationMCCASNode_H
#include <timber-compat.h>
class QueryEvaluationTreeMCCASNode: public QueryEvaluationTreeNode
{
public: 
	void processQueryEvalNode(EvaluatorClass* evaluator, IteratorClass*& curr);
	char getIdentifier();
	QueryEvaluationTreeMCCASNode(
		QueryEvaluationTreeNode** operands,
		int numInputs, 
		NREType *nre,
		//bool *isOptional,
		char *aSpec,
		NREType assignedNre,
		int expectedInputSize, 
		int expectedDepthint);
	~QueryEvaluationTreeMCCASNode();

	int getInputs();
	void setInputs(IteratorClass **inputs);

	int getNumInputs();
	void setNumInputs(int numInputs);

	int getExpectedInputSize();
	void setExpectedInputSize(int expectedInputSize);

	int getExpectedDepth();
	void setExpectedDepth(int expectedDepth);

	/* may be useful for optimization?
	char* getParentIndexName();
	void setParentIndexName(char* parentIndexname);
	*/

	QueryEvaluationTreeNode **getOperands();
	void setOperands(QueryEvaluationTreeNode** operands);

	NREType *getNRE();
	void setNRE(NREType *nre);

	NREType getAssignedNRE();
	void setAssignedNRE(NREType nre);

	//bool *getIsOptional();
	//void setIsOptional(bool * isOptional);

	char *getASpec();
	void setASpec(char * aSpec);

	//NREType *getOptionalNRE();
	//void setOptionalNRE(NREType *nre);

	void deleteStructures();

private:
	QueryEvaluationTreeNode** operands;
	int numInputs; 
	NREType *nre;
	//bool *isOptional;
	//Yunyao: added 11-20-04 to support annotated MLCAS
	char *aSpec;
	NREType assignedNre;
	int expectedInputSize; 
	int expectedDepth;
	//char *parentIndexName; // may be useful for optimization?
};
#endif

