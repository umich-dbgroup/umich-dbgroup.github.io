
#include "parse.hpp"

char QueryEvaluationTreeMCCASNode::getIdentifier(void) { return 'm'; }

char MCCASPlanParser::getIteratorIdentifier(void) { return 'm'; }

void 
MCCASPlanParser::getQueryEvalNode(EvaluatorClass* evaluator, char* line, void* queryInput, QueryEvaluationTreeNode*& curr)
	    {
		char *token = strtok(line+2,",");
		char *aSpec;
		NREType *nre;

		if (token == NULL)
		{
		    globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"Evaluator",__FILE__,"Error input from file... expecting number of inputs... MeaningfulClosestCommonAncestorStructure line...");
		    curr=NULL; return;
		}
		int num = atoi(token);

		if (num <= 0)
		{
		    aSpec = NULL;
		    nre = NULL;
		    globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"Evaluator",__FILE__,"Error input from file... number of inputs should be larger than 0... MeaningfulClosestCommonAncestorStructure line...");
		    curr=NULL; return;
		}


		nre = new NREType[num];

		for (int i=0; i<num; i++)
		{
		    token = strtok(NULL,",");
		    if (token == NULL)
		    {
			globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"Evaluator",__FILE__,"Error input from file... expecting NRE... MeaningfulClosestCommonAncestorStructure line...");
			if (nre) delete [] nre;
			curr=NULL; return;
		    }

		    nre[i] = (NREType)atoi(token);
		}

		// Yunyao: 09-06-04: added for supporting optional MLCAS
		//Yunyao: 11-20-04: updated for supporting annotated MLCAS
		//bool *isOptional;

		//if (num > 0)
		//	isOptional = new bool[num];
		//else
		//	isOptional = NULL;

		//Yunyao: added temporarily for Nalix, as XQuery and optimizer haven't been updated to support annotated MLCAS yet
		//TODO: get rid of the following code
		bool isAnnotated = true;

		aSpec = new char[num + 1];

		for (int i = 0; i < num; i++)
		{
		    token = strtok(NULL, ",");
		    if (token == NULL)
		    {
			globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"Evaluator",__FILE__,"Error input from file... expecting Annotation Specification... MeaningfulClosestCommonAncestorStructure line...");
			if (nre) delete [] nre;
			//if (isOptional) delete [] isOptional;
			if (aSpec) delete [] aSpec;
			curr=NULL; return;
		    }

		    //isOptional[i] = (bool)atoi(token);

		    //Yunyao: added temporarily for Nalix, as XQuery and optimizer haven't been updated to support annotated MLCAS yet
		    //TODO: get rid of the following code
		    //------------------------------------
		    if (!strcmp(token, "-") || !strcmp(token, "?")|| !strcmp(token, "+") || !strcmp(token, "*"))
		    {
			strcpy(&aSpec[i],token);
		    }
		    else
		    {
			//------------------------------------
			for (int j = 0; j < num; j++)
			    strcpy(&aSpec[j],"-");

			isAnnotated = false;

			break;
		    }
		}

		if (isAnnotated)
		    token = strtok(NULL,",");

		if (token == NULL)
		{
		    globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"Evaluator",__FILE__,"Error input from file... expecting assignedNre... MeaningfulClosestCommonAncestorStructure line...");
		    //if (isOptional) delete [] isOptional;
		    if (nre) delete [] nre;
		    if (aSpec) delete [] aSpec;
		    curr=NULL; return;
		}

		NREType assignedNre = atoi(token);

		token = strtok(NULL,",");
		if (token == NULL)
		{
		    globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"Evaluator",__FILE__,"Error input from file... expecting size of inputs... MeaningfulClosestCommonAncestorStructure line...");
		    if (nre) delete [] nre;
		    if (aSpec) delete [] aSpec;
		    curr=NULL; return;
		}

		int size = atoi(token);

		token = strtok(NULL,",");
		if (token == NULL)
		{
		    globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"Evaluator",__FILE__,"Error input from file... expecting depth of stack... MeaningfulClosestCommonAncestorStructure line...");
		    if (nre) delete [] nre;
		    if (aSpec) delete [] aSpec;
		    curr=NULL; return;
		}
		int depth = atoi(token);

		QueryEvaluationTreeNode **operands;

		operands = new QueryEvaluationTreeNode *[num];

		char newLine[MAX_FILE_INTERFACE_LINE_SIZE];
		for (int i=0; i<num; i++)
		{
		    if (((std::iostream *)queryInput)->eof() == 0)
			((std::iostream *)queryInput)->getline(newLine,MAX_FILE_INTERFACE_LINE_SIZE);
		    else
		    {
			globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"Evaluator",__FILE__,"Unexpected end of file... MeaningfulClosestCommonAncestorStructure line...");
			if (nre) delete [] nre;
			if (aSpec) delete [] aSpec;
			for (int j =0; j<i; j++)
			    if (operands[j]) delete operands[j];
			delete [] operands;
			curr=NULL; return;
		    }

		    operands[i] = evaluator->getQueryEvalNode(newLine,queryInput);

		    if (operands[i] == NULL)
		    {
			globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"Evaluator",__FILE__,"Unexpected operand returned... MeaningfulClosestCommonAncestorStructure line...");
			if (nre) delete [] nre;
			if (aSpec) delete [] aSpec;
			for (int j =0; j<i; j++)
			    if (operands[j]) delete operands[j];
			delete [] operands;
			curr=NULL; return;
		    }
		}
		curr = new QueryEvaluationTreeMCCASNode(operands, num, nre, aSpec, assignedNre, size, depth);
		evaluator->fileIDsArraySize++;
	    }

