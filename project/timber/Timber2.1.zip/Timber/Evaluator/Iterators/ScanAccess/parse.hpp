#include "../../Evaluator/EvaluatorClass.h"

#include "extra.h"

class ScanAccessPlanParser
{
public:

	static char getIteratorIdentifier(void) ;

	static void getQueryEvalNode(EvaluatorClass* evaluator, char* line, void* queryInput, QueryEvaluationTreeNode*& curr) ;

} ; 

#ifndef WIN32

extern "C" char getIteratorIdentifier(void)
{
	return ScanAccessPlanParser::getIteratorIdentifier() ;
} ;

extern "C" void getQueryEvalNode(EvaluatorClass* evaluator, char* line, void* queryInput, QueryEvaluationTreeNode*& curr)
{
	return ScanAccessPlanParser::getQueryEvalNode(evaluator, line, queryInput, curr) ;
} ;

#endif
