#include "../../Evaluator/EvaluatorClass.h"

#include "QueryEvaluationTreeScanAccessNode.h"

#include "ScanIterator.h"
#include "extra.h"

void QueryEvaluationTreeScanAccessNode::processQueryEvalNode(EvaluatorClass* evaluator, IteratorClass*& curr)
	    {
		int openFileIndex = evaluator->openFile(getFileName(),evaluator->getDataManager());
		if (openFileIndex == -1)
		{
		    globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"Evaluator",__FILE__,"File is unloaded in Timber.");
		    curr=NULL; return;
		}
		FileIDType fid = evaluator->getFileID(openFileIndex);
		curr = new ScanIterator(getScanRoot(),getScanRange(),getScanCondition(),
			(char)openFileIndex,getNRE(),evaluator->getDataManager(),fid);
		setScanCondition(NULL);
		setScanRange(NULL);

	    }

