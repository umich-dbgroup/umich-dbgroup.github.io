
#include "parse.hpp"

char QueryEvaluationTreeScanAccessNode::getIdentifier(void) { return 'S'; }

char ScanAccessPlanParser::getIteratorIdentifier(void) { return 'S'; }

void 
ScanAccessPlanParser::getQueryEvalNode(EvaluatorClass* evaluator, char* line, void* queryInput, QueryEvaluationTreeNode*& curr)
	    {
		// data file name
		char *token = strtok(line+2,",");
		if (token == NULL)
		{
		    globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"Evaluator",__FILE__,"Error input from file... expecting NRE... Scan Access line...");
		    curr=NULL; return;
		}
		NREType nre = (NREType)atoi(token);

		if (nre < 1)
		{
		    globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"Evaluator",__FILE__,"NRE should be positive.");
		    curr=NULL; return;
		}
		if (nre > evaluator->maxNRE)
		    evaluator->maxNRE = nre;
		token = strtok(NULL,",");
		char fileName[MAX_XMLFILE_NAME_LENGTH];
		if (token == NULL)
		{
		    globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"Evaluator",__FILE__,"Error input from file... expecting file name... Scan Access line...");
		    curr=NULL; return;
		}
		strcpy(fileName,token);

		// rootKey of the scan
		token = strtok(NULL,",");
		if (token == NULL)
		{
		    globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"Evaluator",__FILE__,"Error input from file... expecting scan root key... Scan Access line...");
		    curr=NULL; return;
		}
		KeyType rootKey = (KeyType)(atoi(token));

		// prepare the selection condition
		SelectionCondition *selCond = new SelectionCondition;

		// scan type: ALL_NODES, ELEMENT_NODE, etc.
		token = strtok(NULL,",");
		if (token == NULL)
		{
		    globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"Evaluator",__FILE__,"Error input from file... expecting node Type... Scan Access line...");
		    delete selCond;
		    curr=NULL; return;
		}
		if (strcmp(token,"ALL_NODES") == 0)
		    selCond->setNodeType(SCAN_ALLNODES);
		else if (strcmp(token,"DOCUMENT_NODE") == 0)
		    selCond->setNodeType(DOCUMENT_NODE);
		else if (strcmp(token,"ELEMENT_NODE") == 0)
		    selCond->setNodeType(ELEMENT_NODE);
		else if (strcmp(token,"ATTRIBUTE_NODE") == 0)
		    selCond->setNodeType(ATTRIBUTE_NODE);
		else if (strcmp(token,"TEXT_NODE") == 0)
		    selCond->setNodeType(TEXT_NODE);
		else if (strcmp(token,"COMMENT_NODE") == 0)
		    selCond->setNodeType(COMMENT_NODE);
		else
		{
		    globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"Evaluator",__FILE__,"Unrecognized node Type... Scan Access line...");
		    delete selCond;
		    curr=NULL; return;
		}

		// return type: THISNODE, PARENTNODE, etc.
		token = strtok(NULL,",");
		if (token == NULL)
		{
		    globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"Evaluator",__FILE__,"Error input from file... expecting return Type... Scan Access line...");
		    delete selCond;
		    curr=NULL; return;
		}
		if (strcmp(token,"THISNODE") == 0)
		    selCond->setReturnType(SCAN_RETURN_THISNODE);
		else if (strcmp(token,"PARENTNODE") == 0)
		    selCond->setReturnType(SCAN_RETURN_PARENTNODE);
		else if (strcmp(token,"ELEMENTNODE") == 0)
		    selCond->setReturnType(SCAN_RETURN_ELEMENTNODE);
		else if (strcmp(token,"ATTRIBUTENODE") == 0)
		    selCond->setReturnType(SCAN_RETURN_ATTRIBUTENODE);
		else if (strcmp(token,"SUBTREE") == 0)
		    selCond->setReturnType(SCAN_RETURN_SUBTREE);
		else
		{
		    globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"Evaluator",__FILE__,"Unrecognized return Type... Scan Access line...");
		    delete selCond;
		    curr=NULL; return;
		}

		// number of disjunction conditions
		token = strtok(NULL,",");
		if (token == NULL)
		{
		    globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"Evaluator",__FILE__,"Error input from file... expecting number of disjunctive conds... Scan Access line...");
		    delete selCond;
		    curr=NULL; return;
		}
		int numDis = atoi(token);

		if (numDis < 0)
		{
		    globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"Evaluator",__FILE__,"Error input from file... number of disjunctive conds should be positive or 0... Scan Access line...");
		    delete selCond;
		    curr=NULL; return;
		}
		DisjunctiveCondition *disCond = new DisjunctiveCondition(numDis);

		// number of conjunctive conditions in each disjunctive condition
		int numCon;
		ConjunctiveCondition *conCond;
		PredicateCondition *pred;

		// grab the conditions
		for (int i=0; i<numDis; i++)
		{
		    token = strtok(NULL,",");
		    if (token == NULL)
		    {
			globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"Evaluator",__FILE__,"Error input from file... expecting number of conjunctive conds... Scan Access line...");
			delete selCond;
			delete disCond;
			curr=NULL; return;
		    }
		    numCon = atoi(token);
		    if (numCon < 0)
		    {
			globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"Evaluator",__FILE__,"Error input from file... number of conjunctive conds should be positive or 0... Scan Access line...");
			delete selCond;
			delete disCond;
			curr=NULL; return;
		    }
		    conCond = new ConjunctiveCondition(numCon);
		    for (int j=0; j<numCon; j++)
		    {
			token = strtok(NULL,",");
			if (token == NULL)
			{
			    globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"Evaluator",__FILE__,"Error input from file... expecting Left predicate value... Scan Access line...");
			    delete selCond;
			    delete disCond;
			    delete conCond;
			    curr=NULL; return;
			}
			pred = new PredicateCondition;
			if (strcmp(token,"VALUE") == 0)
			    pred->setLeftValue(SCAN_LEFTVALUE_VALUE);
			else if (strcmp(token,"LENGTH") == 0)
			    pred->setLeftValue(SCAN_LEFTVALUE_LENGTH);
			else if (strcmp(token,"XMLFILENAME") == 0)
			    pred->setLeftValue(SCAN_LEFTVALUE_XMLFILENAME);
			else if (strcmp(token,"NODETAG") == 0)
			    pred->setLeftValue(SCAN_LEFTVALUE_NODETAG);
			else if (strcmp(token,"CHILDNUMBER") == 0)
			    pred->setLeftValue(SCAN_LEFTVALUE_CHILDNUMBER);
			else if (strcmp(token,"ATTRIBUTENUMBER") == 0)
			    pred->setLeftValue(SCAN_LEFTVALUE_ATTRIBUTENUMBER);
			else if (strcmp(token,"HAS_CHILD") == 0)
			    pred->setLeftValue(SCAN_LEFTVALUE_HASCHILD);
			else if (strcmp(token,"HAS_ATTRIBUTE") == 0)
			    pred->setLeftValue(SCAN_LEFTVALUE_HASATTRIBUTE);
			else if (strcmp(token,"ELEMENTCONTENT") == 0)
			    pred->setLeftValue(SCAN_LEFTVALUE_ELEMENTCONTENT);
			else if (strcmp(token,"ATTRIBUTE_VALUE") == 0)
			{
			    token = strtok(NULL,",");
			    if (token == NULL)
			    {
				globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"Evaluator",__FILE__,"Error input from file... expecting attribute name... Scan Access line...");
				delete selCond;
				delete disCond;
				delete conCond;
				delete pred;
				curr=NULL; return;
			    }
			    char *tmp = new char[strlen(token) + 1];
			    strcpy(tmp,token);
			    pred->setLeftValue((int) tmp);
			}
			else
			{
			    globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"Evaluator",__FILE__,"Error input from file... unrecognized left predicate type... Scan Access line...");
			    delete selCond;
			    delete disCond;
			    delete conCond;
			    delete pred;
			    curr=NULL; return;
			}

			token = strtok(NULL,",");
			if (token == NULL)
			{
			    globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"Evaluator",__FILE__,"Error input from file... expecting predicate operator... Scan Access line...");
			    delete selCond;
			    delete disCond;
			    delete conCond;
			    delete pred;
			    curr=NULL; return;
			}
			if (strcmp(token,"GT") == 0)
			    pred->setOperator(SCAN_OP_GT);
			else if (strcmp(token,"GE") == 0)
			    pred->setOperator(SCAN_OP_GE);
			else if (strcmp(token,"LT") == 0)
			    pred->setOperator(SCAN_OP_LT);
			else if (strcmp(token,"LE") == 0)
			    pred->setOperator(SCAN_OP_LE);
			else if (strcmp(token,"EQ") == 0)
			    pred->setOperator(SCAN_OP_EQ);
			else if (strcmp(token,"NE") == 0)
			    pred->setOperator(SCAN_OP_NE);
			else if (strcmp(token,"CONTAIN") == 0)
			    pred->setOperator(SCAN_OP_CONTAINS);
			else if (strcmp(token,"CONTAINEDBY") == 0)
			    pred->setOperator(SCAN_OP_CONTAINEDBY);
			else if (strcmp(token,"STARTWITH") == 0)
			    pred->setOperator(SCAN_OP_STARTWITH);
			else
			{
			    globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"Evaluator",__FILE__,"Error input from file... unrecognized operation... Scan Access line...");
			    delete selCond;
			    delete disCond;
			    delete conCond;
			    delete pred;
			    curr=NULL; return;
			}

			if (pred->getLeftValue() == SCAN_LEFTVALUE_NODETAG && pred->getOperator() != SCAN_OP_EQ
				&& pred->getOperator() != SCAN_OP_NE)
			{
			    globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"Evaluator",__FILE__,"Error input from file... Equality and inequality are the only operations allowed with node tag... Scan Access line...");
			    delete selCond;
			    delete disCond;
			    delete conCond;
			    delete pred;
			    curr=NULL; return;
			}

			token = strtok(NULL,",");
			if (token == NULL)
			{
			    globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"Evaluator",__FILE__,"Error input from file... expecting right predicate type... Scan Access line...");
			    delete selCond;
			    delete disCond;
			    delete conCond;
			    delete pred;
			    curr=NULL; return;
			}

			Value *val = new Value;
			if (strcmp(token,"INT") == 0)
			    val->setValueType(INT_VALUE);
			else if (strcmp(token,"STR") == 0)
			    val->setValueType(STRING_VALUE);
			else if (strcmp(token,"FLT") == 0)
			    val->setValueType(REAL_VALUE);
			else
			{
			    globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"Evaluator",__FILE__,"Error input from file... unrecognized right value type... Scan Access line...");
			    delete selCond;
			    delete disCond;
			    delete conCond;
			    delete pred;
			    delete val;
			    curr=NULL; return;
			}

			if (pred->getLeftValue() == SCAN_LEFTVALUE_NODETAG)
			    val->setValueType(INT_VALUE);

			token = strtok(NULL,",");
			if (token == NULL)
			{
			    globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"Evaluator",__FILE__,"Error input from file... expecting right predicate value... Scan Access line...");
			    delete selCond;
			    delete disCond;
			    delete conCond;
			    delete pred;
			    delete val;
			    curr=NULL; return;
			}

			if (val->getValueType() == INT_VALUE)
			{
			    if (pred->getLeftValue() == SCAN_LEFTVALUE_NODETAG)
				val->setIntValue(evaluator->getDataManager()->getPhysicalDataMng()->getXMLNameTable()->getCodeByName(token));
			    else
				val->setIntValue(atoi(token));
			}
			else if (val->getValueType() == STRING_VALUE)
			{
			    if (strcmp(token,"<EMPTY>") == 0)
				val->setStrValue("");
			    else
				val->setStrValue(token);
			}
			else
			    val->setRealValue(atof(token));

			pred->setRightValue(val);

			conCond->insertCond(pred);
		    }
		    disCond->insertCond(conCond);
		}
		selCond->setCondition(disCond);

		// scan ranges
		token = strtok(NULL,",");
		if (token == NULL)
		{
		    globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"Evaluator",__FILE__,"Error input from file... expecting number of scan ranges... Scan Access line...");
		    delete selCond;
		    curr=NULL; return;
		}
		int numScanRanges = atoi(token);
		ScanRange *scanRange = NULL;
		if (numScanRanges < 0)
		{
		    globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"Evaluator",__FILE__,"Error input from file... number of scan ranges should be positive or 0... Scan Access line...");
		    delete selCond;
		    curr=NULL; return;
		} 
		else if (numScanRanges > 0)
		    scanRange = new ScanRange(numScanRanges);

		for (int i=0; i<numScanRanges; i++)
		{
		    token = strtok(NULL,",");
		    if (token == NULL)
		    {
			globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"Evaluator",__FILE__,"Error input from file... expecting start pos... Scan Access line...");
			delete selCond;
			delete scanRange;
			curr=NULL; return;
		    }

		    ScanRangeType s;
		    s.startPos = (KeyType) atof(token);

		    token = strtok(NULL,",");
		    if (token == NULL)
		    {
			globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"Evaluator",__FILE__,"Error input from file... expecting end pos... Scan Access line...");
			delete selCond;
			delete scanRange;
			curr=NULL; return;
		    }
		    s.endPos = (KeyType) atof(token);
		    scanRange->setScanRangeAt(i, &s);
		}


		curr = new QueryEvaluationTreeScanAccessNode(fileName,nre,rootKey, selCond, scanRange);
	    }

