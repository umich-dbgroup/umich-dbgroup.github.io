
#include "parse.hpp"


char QueryEvaluationTreeDataDiscardNode::getIdentifier(void) { return 'b'; }

char DataDiscardPlanParser::getIteratorIdentifier(void) { return 'b'; }

void 
DataDiscardPlanParser::getQueryEvalNode(EvaluatorClass* evaluator, char* line, void* queryInput, QueryEvaluationTreeNode*& curr)
	    {
		char *token = strtok(line+2,",");
		if (token == NULL)
		{
		    globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"Evaluator",__FILE__,"Error input from file... expecting index... data discard line...");
		    curr=NULL; return;
		}
		int index = atoi(token);

		token = strtok(NULL,",");
		if (token == NULL)
		{
		    globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"Evaluator",__FILE__,"Error input from file... expecting scope... data discard line...");
		    curr=NULL; return;
		}
		int scope;
		if (strcmp(token,"I") == 0)
		    scope = DI_SPEC_THENODE;
		else if (strcmp(token,"S") == 0)
		    scope = DI_SPEC_SUBTREE;
		else
		    scope = DI_SPEC_SUBTREEWITHCUT;

		token = strtok(NULL,",");
		if (token == NULL)
		{
		    globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"Evaluator",__FILE__,"Error input from file... expecting cutting depth... data discard line...");
		    curr=NULL; return;
		}
		int cuttingDepth = atoi(token);

		token = strtok(NULL,",");
		if (token == NULL)
		{
		    globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"Evaluator",__FILE__,"Error input from file... expecting get Element... data discard line...");
		    curr=NULL; return;
		}
		bool getElement = (strcmp(token,"1") == 0);

		token = strtok(NULL,",");
		if (token == NULL)
		{
		    globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"Evaluator",__FILE__,"Error input from file... expecting get Attr... data discard line...");
		    curr=NULL; return;
		}
		bool getAttr = (strcmp(token,"1") == 0);

		token = strtok(NULL,",");
		if (token == NULL)
		{
		    globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"Evaluator",__FILE__,"Error input from file... expecting get Content... data discard line...");
		    curr=NULL; return;
		}
		bool getContent = (strcmp(token,"1") == 0);
		DataInstantiationSpecification *diSpec= new DataInstantiationSpecification;
		diSpec->scope = scope;
		diSpec->cutDepth = cuttingDepth;
		diSpec->element = getElement;
		diSpec->attribute = getAttr;
		diSpec->content = getContent;

		char newLine[MAX_FILE_INTERFACE_LINE_SIZE];
		if (((std::iostream *)queryInput)->eof() == 0)
		    ((std::iostream *)queryInput)->getline(newLine,MAX_FILE_INTERFACE_LINE_SIZE);
		else
		{
		    globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"Evaluator",__FILE__,"Unexpected end of file... data discard line...");
		    curr=NULL; return;
		}
		QueryEvaluationTreeNode *oper = evaluator->getQueryEvalNode(newLine,queryInput);
		if (oper == NULL)
		{
		    globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"Evaluator",__FILE__,"Unexpected operand returned... data discard line...");
		    curr=NULL; return;
		}
		curr  = new QueryEvaluationTreeDataDiscardNode(oper,index,diSpec);
	    }

