#ifndef __QueryEvaluationTreeDataDiscardNode_H
#define __QueryEvaluationTreeDataDiscardNode_H
#include <timber-compat.h>


#include "../../QueryEvaluationTree/QueryEvaluationTreeNode.h"
#include "../../DataMng/DataMng.h"


class QueryEvaluationTreeDataDiscardNode :
	public QueryEvaluationTreeNode
{
public: 
	void processQueryEvalNode(EvaluatorClass* evaluator, IteratorClass*& curr);
	char getIdentifier();
	QueryEvaluationTreeDataDiscardNode(QueryEvaluationTreeNode* operand,
		int nodeindex,
		DataInstantiationSpecification* diSpecification);
	
	~QueryEvaluationTreeDataDiscardNode(void);
	
	QueryEvaluationTreeNode* getOperand();
	int getNodeIndexInWitnessTree();
	DataInstantiationSpecification* getDISpecification();
	void deleteStructures();

private:
	QueryEvaluationTreeNode* operand;
	int nodeIndexInWitnessTree;
	DataInstantiationSpecification* diSpecification;
};

#endif
