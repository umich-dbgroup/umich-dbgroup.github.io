#include "../../Evaluator/EvaluatorClass.h"

#include "QueryEvaluationTreeSortStopKNode.h"

#include "SortStopKIterator.h"
#include "extra.h"

void QueryEvaluationTreeSortStopKNode::processQueryEvalNode(EvaluatorClass* evaluator, IteratorClass*& curr)
	    {
		IteratorClass *opr = evaluator->processQueryEvalNode(getOperand());
		if (opr == NULL)
		    curr=NULL; return;
		curr = new SortStopKIterator(opr,getK(),getInSize(),evaluator->getDataManager());
	    }

