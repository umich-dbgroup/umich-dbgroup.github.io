/*
COPYRIGHT  � 2000-2004 
THE REGENTS OF THE UNIVERSITY OF MICHIGAN
ALL RIGHTS RESERVED

PERMISSION IS GRANTED TO USE, COPY, CREATE DERIVATIVE WORKS AND REDISTRIBUTE THIS SOFTWARE AND SUCH DERIVATIVE WORKS FOR 
NONCOMMERCIAL EDUCATION AND RESEARCH PURPOSES, SO LONG AS NO FEE IS CHARGED, AND SO LONG AS THE COPYRIGHT NOTICE ABOVE, 
THIS GRANT OF PERMISSION, AND THE DISCLAIMER BELOW APPEAR IN ALL COPIES MADE; AND SO LONG AS THE NAME OF THE UNIVERSITY 
OF MICHIGAN IS NOT USED IN ANY ADVERTISING OR PUBLICITY PERTAINING TO THE USE OR DISTRIBUTION OF THIS SOFTWARE WITHOUT 
SPECIFIC, WRITTEN PRIOR AUTHORIZATION.

THIS SOFTWARE IS PROVIDED AS IS, WITHOUT REPRESENTATION FROM THE UNIVERSITY OF MICHIGAN AS TO ITS FITNESS FOR ANY PURPOSE, 
AND WITHOUT WARRANTY BY THE UNIVERSITY OF MICHIGAN OF ANY KIND, EITHER EXPRESS OR IMPLIED, INCLUDING WITHOUT LIMITATION THE 
IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE. THE REGENTS OF THE UNIVERSITY OF MICHIGAN SHALL 
NOT BE LIABLE FOR ANY DAMAGES, INCLUDING SPECIAL, INDIRECT, INCIDENTAL, OR CONSEQUENTIAL DAMAGES, WITH RESPECT TO ANY CLAIM 
ARISING OUT OF OR IN CONNECTION WITH THE USE OF THE SOFTWARE, EVEN IF IT HAS BEEN OR IS HEREAFTER ADVISED OF THE POSSIBILITY 
OF SUCH DAMAGES.
*/

#include "SortStopKIterator.h"

SortStopKIterator::SortStopKIterator(IteratorClass *input,int k, int inSize,DataMng *dataMng)
{
	this->input = input;
	this->k = k;
	this->dataMng = dataMng;
	if (inSize < 0)
		this->inSize = INT_MAX;
	else
		this->inSize = inSize;

	cursor = 0;
	sortArrayCursor = 0;

	sortArray = new WitnessTree[k];
	this->lowestScore = DBL_MIN;
	resultBuffer = new WitnessTree;
	input->next(inTuple);
	while (cursor < this->inSize && inTuple)
	{
		//we are writing input trees to the sort array if they have a 
		//score that is higher than the lowest score or we still have space.
		if (sortArrayCursor < k || inTuple->getScore() > this->lowestScore)
		{
			insertInArray(inTuple);
			this->lowestScore = sortArray[0].getScore();
		}
		cursor++;
		input->next(inTuple);
	}
	delete input;
	cursor = sortArrayCursor -1;
}


SortStopKIterator::~SortStopKIterator()
{
	delete [] sortArray;
	delete resultBuffer;
}


void SortStopKIterator::next(WitnessTree *&node)
{
	//as long as we have input trees in the array, output them
	if (cursor >= 0)
	{
		resultBuffer->copyTree(&sortArray[cursor]);
		cursor--;
		node = resultBuffer;
		return;
	}

	node = NULL;
	return;
}


void SortStopKIterator::insertInArray(WitnessTree *inTuple)
{
	//in this method, we insert an input tree into the correct position in the array
	// i.e. sorted.
	if (sortArrayCursor == 0)
	{
		//first time insertion
		sortArray[sortArrayCursor].copyTree(inTuple);
		sortArrayCursor++;
		return;
	}

	//this is a special case to handle if all entries in the array have the same score
	if (sortArray[0].getScore() == inTuple->getScore() 
		&& sortArray[sortArrayCursor-1].getScore() == inTuple->getScore())
	{
		if (sortArrayCursor == k)
			return;
		else
		{
			for (int i=sortArrayCursor; i > 0; i--)
				sortArray[i].copyTree(&sortArray[i-1]);
			sortArray[0].copyTree(inTuple);
			sortArrayCursor++;
			return;
		}
	}

	//perform a binary search to figure out where in the array inTuple should go
	int index = binSearch(inTuple->getScore());

	//now, we need to deal with two cases: we already have k inputs and we need to get
	// rid of the one with the smallest score. the other case is if we still have space 
	// in the array (we don't have k inputs yet.
	if (sortArrayCursor == k)
	{ //buffer is full: case1
		if (index == 0)
			return;
		for (int i=index-1; i > 0; i--)
			sortArray[i-1].copyTree(&sortArray[i]);
		sortArray[index-1].copyTree(inTuple);
	}
	else
	{
		//we have space: case2
		for (int i=sortArrayCursor; i > index; i--)
			sortArray[i].copyTree(&sortArray[i-1]);
		sortArray[index].copyTree(inTuple);
		sortArrayCursor++;
	}
}

int SortStopKIterator::binSearch(double key)
{
	//this method performs a simple binary search to find the correct place in
	// an array for key to go.
	int low = 0;
	int high = sortArrayCursor - 1;
	
	while (low <= high) 
	{
		int mid = (int) ((low + high) / 2);
		if (mid == 0)
		{
			if (key < sortArray[mid].getScore())
				return mid;
			else if (key > sortArray[mid].getScore() && key < sortArray[mid+1].getScore())
				return mid+1;
			else if (key == sortArray[mid].getScore())
				return mid-1;
		}
		if (mid == sortArrayCursor -1 )
		{
			if (key < sortArray[mid].getScore())
				return mid; 
			else
				return mid+1;
		}
		if (key > sortArray[mid].getScore() && key < sortArray[mid+1].getScore())
			return mid+1;
		if (key < sortArray[mid].getScore()) 
			high = mid - 1;
		else if (key > sortArray[mid].getScore()) 
			low = mid + 1;
		else if (key == sortArray[mid].getScore())
			return mid-1;
	}
    return 0; // never reached
}

