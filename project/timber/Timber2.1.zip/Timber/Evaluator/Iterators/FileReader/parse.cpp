
#include "parse.hpp"

char QueryEvaluationTreeFileReaderNode::getIdentifier(void) { return 'd'; }

char FileReaderPlanParser::getIteratorIdentifier(void) { return 'd'; }

void 
FileReaderPlanParser::getQueryEvalNode(EvaluatorClass* evaluator, char* line, void* queryInput, QueryEvaluationTreeNode*& curr)
	    {
		char *token = strtok(line+2,",");
		char *fileName;
		if (token == NULL)
		{
		    globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"Evaluator",__FILE__,"Error input from file... expecting fileName... file reader line...");
		    curr=NULL; return;
		}
		fileName = new char[strlen(token)+1];
		strcpy(fileName,token);
		curr = new QueryEvaluationTreeFileReaderNode(fileName);
	    }

