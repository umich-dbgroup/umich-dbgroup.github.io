/*
COPYRIGHT  � 2000-2004 
THE REGENTS OF THE UNIVERSITY OF MICHIGAN
ALL RIGHTS RESERVED

PERMISSION IS GRANTED TO USE, COPY, CREATE DERIVATIVE WORKS AND REDISTRIBUTE THIS SOFTWARE AND SUCH DERIVATIVE WORKS FOR 
NONCOMMERCIAL EDUCATION AND RESEARCH PURPOSES, SO LONG AS NO FEE IS CHARGED, AND SO LONG AS THE COPYRIGHT NOTICE ABOVE, 
THIS GRANT OF PERMISSION, AND THE DISCLAIMER BELOW APPEAR IN ALL COPIES MADE; AND SO LONG AS THE NAME OF THE UNIVERSITY 
OF MICHIGAN IS NOT USED IN ANY ADVERTISING OR PUBLICITY PERTAINING TO THE USE OR DISTRIBUTION OF THIS SOFTWARE WITHOUT 
SPECIFIC, WRITTEN PRIOR AUTHORIZATION.

THIS SOFTWARE IS PROVIDED AS IS, WITHOUT REPRESENTATION FROM THE UNIVERSITY OF MICHIGAN AS TO ITS FITNESS FOR ANY PURPOSE, 
AND WITHOUT WARRANTY BY THE UNIVERSITY OF MICHIGAN OF ANY KIND, EITHER EXPRESS OR IMPLIED, INCLUDING WITHOUT LIMITATION THE 
IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE. THE REGENTS OF THE UNIVERSITY OF MICHIGAN SHALL 
NOT BE LIABLE FOR ANY DAMAGES, INCLUDING SPECIAL, INDIRECT, INCIDENTAL, OR CONSEQUENTIAL DAMAGES, WITH RESPECT TO ANY CLAIM 
ARISING OUT OF OR IN CONNECTION WITH THE USE OF THE SOFTWARE, EVEN IF IT HAS BEEN OR IS HEREAFTER ADVISED OF THE POSSIBILITY 
OF SUCH DAMAGES.
*/

#include "FileReaderIterator.h"

FileReaderIterator::FileReaderIterator(const char *fileName,DataMng *dataMng)
{
	input = fopen(fileName,"r");
	count = 0;
	resultBuffer = new WitnessTree;
	this->dataMng = dataMng;
	
	//this->fileName = new char[strlen(fileName)+1];
	//strcpy(this->fileName, fileName);
}


FileReaderIterator::~FileReaderIterator()
{
	delete resultBuffer;
	if (input) fclose(input);
	//delete [] fileName;
}

void FileReaderIterator::next(WitnessTree *&node)
{
#ifdef EVAL_TIME_OUT
	clock_t currTime = clock();
	double queryDuration = (double)(currTime - gQueryStartTime) / CLOCKS_PER_SEC;
	if (queryDuration >= gTimeOutAfter)
	{
		globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"Evaluator",__FILE__,"Query Timed Out.");
		node = NULL;
		return;
	}
#endif
	//if the input file wouldn't open, then we are done
	if (!input)
	{
		globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"Evaluator",__FILE__,"Could not open file.");
		node = NULL;
		return;
	}
	count++;
	int num;

	//scan the input file for the number of nodes in the witness tree
	if (fscanf(input,"%d",&num) == EOF)
	{
		node = NULL;
		return;
	}

	double score;
	//scan the input file for score of witness tree
	if (fscanf(input,"%lf",&score) == EOF)
	{
		globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"Evaluator",__FILE__,"Expectiong score in input file.");
		node = NULL;
		return;
	}
	resultBuffer->initialize();
	resultBuffer->setScore(score);

	//scan the file for nodes in the witness tree
	for (int i=0; i<num; i++)
	{
		char fileName[MAX_XMLFILE_NAME_LENGTH];
		char dummyName[MAX_DUMMY_NAME];
		KeyType sk,ek;
		short level,offset,localLevel;
		NREType nre;
		char nodeType[2];
		
		//scan for the type of the node
		if (fscanf(input,"%s",nodeType) == EOF)
		{
			globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"Evaluator",__FILE__,"Expectiong node type in input file.");
			node = NULL;
			return;
		}

		if (strcmp(nodeType,"s") == 0 || strcmp(nodeType,"c") == 0)
		{ //if node is not a dummy node
			//scan for the filename that this node came from
			if (fscanf(input,"%s",fileName) == EOF)
			{
				globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"Evaluator",__FILE__,"Expectiong file name in input file.");
				node = NULL;
				return;
			}

			//try to open this file
			int openFileIndex = EvaluatorClass::openFile(fileName,dataMng);
			if (openFileIndex == -1)
			{
				globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"Evaluator",__FILE__,"File is not loaded in Timber.");
				node = NULL;
				return;
			}

			//scan for start key of this node
			if (fscanf(input,"%lf",&sk) == EOF)
			{
				globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"Evaluator",__FILE__,"Expectiong start key in input file.");
				node = NULL;
				return;
			}

			//scan for end key of this node
			if (fscanf(input,"%lf",&ek) == EOF)
			{
				globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"Evaluator",__FILE__,"Expectiong end key in input file.");
				node = NULL;
				return;
			}

			//scan for level of this node
			if (fscanf(input,"%d",&level) == EOF)
			{
				globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"Evaluator",__FILE__,"Expectiong level in input file.");
				node = NULL;
				return;
			}

			//scan for offset of this node
			if (fscanf(input,"%d",&offset) == EOF)
			{
				globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"Evaluator",__FILE__,"Expectiong offset in input file.");
				node = NULL;
				return;
			}

			//scan for nre of this node
			if (fscanf(input,"%d",&nre) == EOF)
			{
				globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"Evaluator",__FILE__,"Expectiong NRE in input file.");
				node = NULL;
				return;
			}

			if (strcmp(nodeType,"c") == 0)
			{
				//scan for level of this node
				if (fscanf(input,"%d",&localLevel) == EOF)
				{
					globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"Evaluator",__FILE__,"Expectiong local level in input file.");
					node = NULL;
					return;
				}
				ComplexListNode n;
				n.setFileIndex((char)openFileIndex);
				n.SetStartPos(sk);
				n.SetEndPos(ek);
				n.SetLevel(level);
				n.SetOffset(offset);
				n.setNRE(nre);
				n.SetLocalLevel(localLevel);
				n.SetDummy(false);

				//add node to resultBuffer
				resultBuffer->appendList(&n,dataMng,1);
			}
			else
			{
				ListNode n;
				n.setFileIndex((char)openFileIndex);
				n.SetStartPos(sk);
				n.SetEndPos(ek);
				n.SetLevel(level);
				n.SetOffset(offset);
				n.setNRE(nre);

				//add node to resultBuffer
				resultBuffer->appendList(&n,1);
			}
		}
		else if (strcmp(nodeType,"d") == 0)
		{
			//scan for start key of this node
			if (fscanf(input,"%lf",&sk) == EOF)
			{
				globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"Evaluator",__FILE__,"Expectiong start key in input file.");
				node = NULL;
				return;
			}

			//scan for nre of this node
			if (fscanf(input,"%d",&nre) == EOF)
			{
				globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"Evaluator",__FILE__,"Expectiong NRE in input file.");
				node = NULL;
				return;
			}

			//scan for level of this node
			if (fscanf(input,"%d",&localLevel) == EOF)
			{
				globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"Evaluator",__FILE__,"Expectiong local level in input file.");
				node = NULL;
				return;
			}

			//scan for the dummyname that this node came from
			if (fscanf(input,"%s",dummyName) == EOF)
			{
				globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"Evaluator",__FILE__,"Expectiong dummy name in input file.");
				node = NULL;
				return;
			}
			ComplexListNode n;
			n.SetStartPos(sk);
			n.setNRE(nre);
			n.SetLocalLevel(localLevel);
			n.SetDummy(true);
			if (strcmp(dummyName,"[EMPTY]") == 0)
				n.SetDummyName("");
			else
				n.SetDummyName(dummyName);

			//add node to resultBuffer
			resultBuffer->appendList(&n,dataMng,1);

		}
		else
		{
			globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"Evaluator",__FILE__,"Unrecognized node type in input file.");
			node = NULL;
			return;
		}
	}
	node = resultBuffer;
	return;
}
