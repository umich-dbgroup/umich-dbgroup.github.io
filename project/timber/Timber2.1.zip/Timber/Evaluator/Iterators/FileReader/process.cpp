#include "../../Evaluator/EvaluatorClass.h"

#include "QueryEvaluationTreeFileReaderNode.h"

#include "FileReaderIterator.h"
#include "extra.h"

void QueryEvaluationTreeFileReaderNode::processQueryEvalNode(EvaluatorClass* evaluator, IteratorClass*& curr)
	    {
		curr = new FileReaderIterator(getFileName(),evaluator->getDataManager());
		setFileName(NULL);
	    }

