#include "../../Evaluator/EvaluatorClass.h"

#include "QueryEvaluationTreeConstructNode.h"

#include "ConstructIterator.h"
#include "extra.h"

void QueryEvaluationTreeConstructNode::processQueryEvalNode(EvaluatorClass* evaluator, IteratorClass*& curr)
	    {
		IteratorClass *opr = evaluator->processQueryEvalNode(getOperand());
		if (opr == NULL)
		{
		    globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"Evaluator",__FILE__, "operand returned is NULL. construct process eval node..." );
		    curr=NULL; return;
		}
		curr = new ConstructIterator(opr,getSpec(),evaluator->getDataManager());
		setSpec(NULL);
	    }

