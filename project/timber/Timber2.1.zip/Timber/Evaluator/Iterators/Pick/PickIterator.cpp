/*
COPYRIGHT  � 2000-2004 
THE REGENTS OF THE UNIVERSITY OF MICHIGAN
ALL RIGHTS RESERVED

PERMISSION IS GRANTED TO USE, COPY, CREATE DERIVATIVE WORKS AND REDISTRIBUTE THIS SOFTWARE AND SUCH DERIVATIVE WORKS FOR 
NONCOMMERCIAL EDUCATION AND RESEARCH PURPOSES, SO LONG AS NO FEE IS CHARGED, AND SO LONG AS THE COPYRIGHT NOTICE ABOVE, 
THIS GRANT OF PERMISSION, AND THE DISCLAIMER BELOW APPEAR IN ALL COPIES MADE; AND SO LONG AS THE NAME OF THE UNIVERSITY 
OF MICHIGAN IS NOT USED IN ANY ADVERTISING OR PUBLICITY PERTAINING TO THE USE OR DISTRIBUTION OF THIS SOFTWARE WITHOUT 
SPECIFIC, WRITTEN PRIOR AUTHORIZATION.

THIS SOFTWARE IS PROVIDED AS IS, WITHOUT REPRESENTATION FROM THE UNIVERSITY OF MICHIGAN AS TO ITS FITNESS FOR ANY PURPOSE, 
AND WITHOUT WARRANTY BY THE UNIVERSITY OF MICHIGAN OF ANY KIND, EITHER EXPRESS OR IMPLIED, INCLUDING WITHOUT LIMITATION THE 
IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE. THE REGENTS OF THE UNIVERSITY OF MICHIGAN SHALL 
NOT BE LIABLE FOR ANY DAMAGES, INCLUDING SPECIAL, INDIRECT, INCIDENTAL, OR CONSEQUENTIAL DAMAGES, WITH RESPECT TO ANY CLAIM 
ARISING OUT OF OR IN CONNECTION WITH THE USE OF THE SOFTWARE, EVEN IF IT HAS BEEN OR IS HEREAFTER ADVISED OF THE POSSIBILITY 
OF SUCH DAMAGES.
*/

#include "PickIterator.h"
#include <float.h>

#define PICK_INIT_STACKSIZE 4096 /* StackNodeSize*PICK_INIT_STACKSIZE < PAGE SIZE? */
#define PICK_ANS_STACKSIZE 64 /* MAX_DEPTH of the datafile */

#define SAME 0
#define PARENT 1
#define CHILD 2
#define ANCESTOR_N 3
#define DESCENDENT 4
#define NONE 5

#define HAVE_MERCY_ON_SORT 1
#define MAX_RESULT 500

extern int GetTotalChild(KeyType sk, char *tag);

/* Utility Functions */
/*
 * [j]ournal -> [a]rticle -> [s]ec -> [p]/[i]
 */
int GetRelation(KeyType sk1, KeyType ek1, short level1, char *tag1, 
                KeyType sk2, KeyType ek2, short level2, char *tag2)
{
    if (level2 > level1)
    { // parent or ancestor
        if (sk1 < sk2 && ek1 > ek2)
        {
            if (tag1[0] == 'j')
                return (tag2[0] == 'a') ? PARENT : ANCESTOR_N;
            if (tag1[0] == 'a')
                return (tag2[0] == 's') ? PARENT : ANCESTOR_N;
            if (tag1[0] == 's')
                return (tag2[0] == 'i' || tag2[0] == 'p') ? PARENT : ANCESTOR_N;
            return NONE; // never reached

            //if (level2 > level1+1)
            //    return ANCESTOR_N;
            //else
            //    return PARENT;
        }
        else
            return NONE;
    }

    else if (level2 < level1)
    { // child or descendent
        if (sk1 > sk2 && ek1 < ek2)
        {
            if (tag1[0] == 'i' || tag1[0] == 'p')
                return (tag2[0] == 's') ? CHILD : DESCENDENT;
            if (tag1[0] == 's')
                return (tag2[0] == 'a') ? CHILD : DESCENDENT;
            if (tag1[0] == 'a')
                return (tag2[0] == 'j') ? CHILD : DESCENDENT;
            return NONE; // never reached

            //if (level2 < level1-1)
            //    return DESCENDENT;
            //else
            //    return CHILD;
        }
        else
            return NONE;
    }

    else
    { // same level
        if (sk1 - sk2 < 0.01 && sk1 - sk2 > -0.01)
            return SAME;
    }

    return NONE; // never reached
}

void GetInfo(stack<PickStackNode> *s, bool isSimple, 
             KeyType &sk, KeyType &ek, short &level, char *tag)
{
    ListNode *node = NULL;
    ComplexListNode *complexNode = NULL;

    if (!s->IsEmpty())
    {
        if (s->GetTop()->getTree()->length() != 0)
        {
            if (isSimple)
                node = (ListNode *)s->GetTop()->getTree()->findNode(0);
            else
                complexNode = (ComplexListNode *)s->GetTop()->getTree()->findNode(0);
            sk = isSimple ? node->GetStartPos() : complexNode->GetStartPos();
            ek = isSimple ? node->GetEndPos() : complexNode->GetEndPos();
            level = isSimple ? node->GetLevel() : complexNode->GetLevel();
        }
        else
        { // when I will hit this??
            sk = s->GetTop()->GetActualAncs()->GetStartPos();
            ek = s->GetTop()->GetActualAncs()->GetEndPos();
            level = s->GetTop()->GetActualAncs()->GetLevel();
            // tag
        }

        // the tagname is stored inside MiscInformation
        if (s->GetTop()->getMiscInformation() != NULL)
            strcpy(tag, (char *)(s->GetTop()->getMiscInformation()));
        else
            tag[0] = '\0';
    }
    else
    {
        sk = -1.0;
        ek = -1.0;
        level = -1;
        tag[0] = '\0';
    }
}

void GetInfo(WitnessTree *t, bool isSimple, DataMng *dataMng, FileIDType fid,
             KeyType &sk, KeyType &ek, short &level, char *tag)
{
    ListNode *node = NULL;
    ComplexListNode *complexNode = NULL;
    DM_DataNode *datanode;

    if (t)
    {
        if (isSimple)
            node = (ListNode *)t->findNode(0);
        else
            complexNode = (ComplexListNode *)t->findNode(0);
        sk = isSimple ? node->GetStartPos() : complexNode->GetStartPos();
        ek = isSimple ? node->GetEndPos() : complexNode->GetEndPos();
        level = isSimple ? node->GetLevel() : complexNode->GetLevel();
        // grab the tagname
        datanode = dataMng->getDataNode(fid, sk, true);
        strcpy(tag, datanode->getTag(dataMng->getPhysicalDataMng()->getXMLNameTable()));
    }
    else
    {
        sk = -1.0;
        ek = -1.0;
        level = -1;
        tag[0] = '\0';
    }
}

void GetVirtualParent(DataMng *dataMng, FileIDType fid, KeyType sk,
                      ListNode &listnode, char *ptag)
{
    // navigate up the tree until hit "journal", "article", or "sec"
    DM_DataNode *datanode;
    char *temptag;
    KeyType tempsk;
    datanode = dataMng->getParent(fid, sk, true);
    tempsk = datanode->getKey();
    temptag = datanode->getTag(dataMng->getPhysicalDataMng()->getXMLNameTable());
    while (strcmp(temptag, "sec") != 0 && 
           strcmp(temptag, "article") != 0 &&
           strcmp(temptag, "journal") != 0)
    {
        datanode = dataMng->getParent(fid, tempsk, true);
        if (datanode == NULL)
        {
            tempsk = -1.0;
            temptag[0] = '\0';
            break;
        }
        tempsk = datanode->getKey();
        temptag = datanode->getTag(dataMng->getPhysicalDataMng()->getXMLNameTable());
    }
    listnode.SetStartPos(tempsk);
    if (datanode != NULL)
    {
        listnode.SetEndPos(datanode->getEndKey());
        listnode.SetLevel(datanode->getLevel());
    }
    strcpy(ptag, temptag);
}

PickIterator::PickIterator(IteratorClass *input,bool ( *selectFunction1)(PickStackNode *node, ListNode *standard, char *lastTag), 
                           bool ( *qualifyFunction1)(WitnessTree *tree, char *tag), DataMng *dataMng, bool sort)
{
    this->input = input;
    if (input)
        input->next(inTuple);
    else 
        inTuple = NULL;

    if (inTuple)
    {
        if (inTuple->isSimple())
        {
            resultBuffer = new WitnessTree;
            nodeSize = sizeof(ListNode);
            nodeType = LIST_NODE;
            this->fid = EvaluatorClass::getFileID( (int) ((ListNode *)inTuple->findNode(0))->getFileIndex() );
            this->isSimple = true;
        }
        else
        {
            resultBuffer = new WitnessTree(LIST_NODE_WITH_DATA,dataMng);
            nodeSize = sizeof(ComplexListNode);
            nodeType = LIST_NODE_WITH_DATA;
            this->fid = EvaluatorClass::getFileID( (int) ((ComplexListNode *)inTuple->findNode(0))->getFileIndex() );
            this->isSimple = false;
        }

        listLength = inTuple->length();
        mainStack = new stack<PickStackNode>(PICK_INIT_STACKSIZE);
        ansStack = new stack<PickStackNode>(PICK_ANS_STACKSIZE);
    }
    else
    { // inTuple is NULL, no input from the input stream
        resultBuffer = NULL;
        mainStack = NULL;
        ansStack = NULL;
        nodeSize = sizeof(LIST_NODE);
        nodeType = LIST_NODE;
        listLength = 0;
        fid = -1;
        isSimple = true;
    }

    // select functions
    this->selectFunction1 = selectFunction1;
    this->qualifyFunction1 = qualifyFunction1;

    // database information
    this->dataMng = dataMng;

    // auxillary
    this->sort = sort;

    // lastAncestor does not need to be initialized

    //volumeID = dataMng->getVolumeID();
    //rc = ss_m::create_file(volumeID, fileID, ss_m::t_regular);
    //if (rc) 
    //{
    //    printf("after create file\n");
    //    cerr << rc << endl;
    //    return;            
    //}
    //rc = ss_m::create_id(volumeID,M AX_ID_PER_VOLUME, startID);
    //if (rc) 
    //{
    //    printf("after create id\n");
    //    cerr << rc << endl;
    //    return;            
    //}   

}

PickIterator::~PickIterator()
{
    if (resultBuffer) delete resultBuffer;
    if (mainStack) delete mainStack;
    if (ansStack) delete ansStack;
	delete input;
}


bool PickIterator::stillInput()
{
    return inTuple != NULL;
}

WitnessTree *PickIterator::currentTree()
{
    return inTuple;
}

void PickIterator::getNext()
{
    if (input)
        input->next(inTuple);
}

void PickIterator::next(WitnessTree *&node)
{
#ifdef EVAL_TIME_OUT
	clock_t currTime = clock();
	double queryDuration = (double)(currTime - gQueryStartTime) / CLOCKS_PER_SEC;
	if (queryDuration >= gTimeOutAfter)
	{
		globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"Evaluator",__FILE__,"Query Timed Out.");
		node = NULL;
		return;
	}
#endif
   /*
    * Algorithm: needs to be revised
    *   Input: a list of leaf node, however, non-leaf nodes are also included and are identified
    *          through identical (sk,ek,level) triples
    *   Note: to be pushed into `mainStack', a node hs to be qualified via worthOut function
    *
    *   1) if still within the current outputing event (i.e., one ancestor has been 
    * determined not worthy outputing or it is the root element), we pop
    * the top of `mainStack' (output it and return if it meets the criteria)
    *   1.1) if the stack is empty after pop, we reset `lastAncestor' and return
    *   1.2) if the top of the stack is no longer a decendent of the `lastAncestor',
    * we reset `lastAncestor' and return
    *
    *   2) we are no longer within an outputing event
    *
    *   2.0) break if `inTuple' is NULL
    *
    *   2.1) while `ansStack' is non-empty AND `inTuple' is not a child or descendent of top of `ansStack', 
    * we pop the `ansStack' and push the popped node onto the `mainStack'
    *
    *   2.2) if `inTuple' is a child of top of `ansStack', we pop the top of `ansStack' into `parent' 
    * (update the new top of `ansStack' for its qualified children number), update `parent' qualified
    * children number
    *
    *   2.3) else `inTuple' is a descendent of top of `ansStack' OR if `ansStack' is empty:
    *   2.3.1) if `mainStack' is empty, we push `inTuple' onto `mainStack', get next `inTuple', and 
    * we retrieve the parent of top of `mainStack' into `parent'
    *   2.3.2) else `mainStack' is non-empty, we retrieve the parent of top of `mainStack' into parent
    *
    *   2.4.1) while `inTuple' is still a child of `parent', update `parent' qualified children number,
    * push `inTuple' onto `mainStack', get next `inTuple'
    *   2.4.2) if `inTuple' is a descendent of `parent', we push `parent' onto `ansStack', push `inTuple'
    * onto `mainStack', retrieve the parent of top of `mainStack', set it to `parent', get next inTuple, 
    * GOTO (2.4.1)
    *   2.4.3) now `inTuple' is not in the subtree of `parent' (potentially the same node)
    *   2.4.3.1) if `parent' qualifies (both score and percentage), we push it onto `mainStack', GOTO (2)
    *   2.4.3.1) if the `parent' does not qualify, we set `lastAncestor' according to its information
    * and a new output event has been initiated, GOTO (1) to output tuples
    *
    *   3) input is exhaustied
    */

#if (HAVE_MERCY_ON_SORT)
    static int pickcnt = 0;
#endif

    //ListNode *slnMain = NULL, *slnCurrent = NULL, *slnAns = NULL;
    //ComplexListNode *clnMain = NULL, *clnCurrent = NULL, *clnAns = NULL;

    KeyType mainsk = -1.0, mainek = -1.0, cursk = -1.0, curek = -1.0, 
            anssk = -1.0, ansek = -1.0, popsk = -1.0, popek = -1.0, negkey = -1.0;
    short     mainlevel = -1, curlevel = -1, anslevel = -1;
	short poplevel = -1;
    char    maintag[20] = {'\0'}, curtag[20] = {'\0'}, anstag[20] = {'\0'}, poptag[20] = {'\0'};

    PickStackNode *popped = NULL;
    WitnessTree *tempParent = NULL;
    ListNode tempnode;
    int totalChild;

    if (mainStack == NULL)
    { // mainStack is not initialized if no input from below
        node = NULL;
        return;
    }

    while (this->stillInput())
    { // we still have inputs coming in

        /* still within the current output event, `mainStack' is guaranteed to be non-empty */
        GetInfo(this->mainStack, this->isSimple, mainsk, mainek, mainlevel, maintag);
        if (this->lastAncestor.GetStartPos() > 0)
        { // `lastAncestor' is valid
            if (mainsk > this->lastAncestor.GetStartPos() && mainek < this->lastAncestor.GetEndPos())
            { // top of `mainStack' is still a descendent of `lastAncestor'
                popped = mainStack->Pop();
                GetInfo(this->mainStack, this->isSimple, mainsk, mainek, mainlevel, maintag);
                while (popped != NULL)
                {
                    if (this->selectFunction1(popped, &(this->lastAncestor), this->lastAnsTag)) 
                        // bug: detemines if popped and lastAnd is the same class
                    { // it is worth outputing

                        // output it
                        resultBuffer->initialize();
                        if (this->isSimple)
                        {
                            resultBuffer->appendList((ListNode *)(popped->getTree()->getBuffer()), 
                                popped->getTree()->length());
                            resultBuffer->setScore(popped->getTree()->getScore());
                        }
                        else
                        {
                            resultBuffer->appendList((ComplexListNode *)(popped->getTree()->getBuffer()), 
                                this->dataMng, popped->getTree()->length());
                            resultBuffer->setScore(popped->getTree()->getScore());
                        }
                        node = resultBuffer;

                        // if empty, reset `lastAncestor'
                        if (this->mainStack->IsEmpty())
                            this->lastAncestor.SetStartPos(negkey);

                        // if top of stack is no longer a descendent, reset `lastAncestor'
                        else if (mainek < this->lastAncestor.GetStartPos() || mainsk > this->lastAncestor.GetEndPos())
                            this->lastAncestor.SetStartPos(negkey);

#if (HAVE_MERCY_ON_SORT)
                        pickcnt++;
                        if (pickcnt > MAX_RESULT)
                            node = NULL;
#endif

                        return;
                    }

                    else
                    { // it is not worth outputing
                        popped = mainStack->Pop();
                        GetInfo(this->mainStack, this->isSimple, mainsk, mainek, mainlevel, maintag);
                    }
                } // while (popped != NULL)

                this->lastAncestor.SetStartPos(negkey);

            } // if (topsk > this->lastAncestor.GetStartPos() && topek < this->lastAncestor.GetEndPos())

            else
            { // should never reached
                this->lastAncestor.SetStartPos(negkey);
            }
        } // if (this->lastAncestor.GetStartPos() > 0)


        /* no longer inside an output event */
        GetInfo(this->currentTree(), this->isSimple, this->dataMng, this->fid, cursk, curek, curlevel, curtag);
        GetInfo(this->ansStack, this->isSimple, anssk, ansek, anslevel, anstag);

        if ( !this->ansStack->IsEmpty() && 
            GetRelation(cursk, curek, curlevel, curtag, anssk, ansek, anslevel, anstag) == SAME )
        { // `inTuple' is the same as `ansTop'

            popped = this->ansStack->Pop();
            GetInfo(this->ansStack, this->isSimple, anssk, ansek, anslevel, anstag);

            if (this->selectFunction1(popped, NULL, NULL))
                // bug: true if more than 30% children are worthy
            { // ansTop worth return
                popped->setTree(inTuple);
                this->mainStack->Push(popped->getTree());
                this->mainStack->GetTop()->setNumberOfChildrenTotal(popped->getNumberOfChildrenTotal());
                this->mainStack->GetTop()->setNumberOfChildrenWorthy(popped->getNumberOfChildrenWorthy());
                this->mainStack->GetTop()->setMiscInformation(popped->getMiscInformation(), strlen((char *)popped->getMiscInformation()));
                GetInfo(this->mainStack, this->isSimple, mainsk, mainek, mainlevel, maintag);

                if ( !this->ansStack->IsEmpty() && 
                    GetRelation(anssk, ansek, anslevel, anstag, mainsk, mainek, mainlevel, maintag) == PARENT )
                { // parent on `ansStack'
                    this->ansStack->GetTop()->incrementNumberOfChildrenWorthy();
                }
                else
                { // retrieve parent from database
                    char temptag[20];
                    GetVirtualParent(this->dataMng, this->fid, mainsk, tempnode, temptag);
                    // deal with the situation where article contains p directly
                    if (temptag[0] != '\0' && strcmp(temptag, anstag) != 0)
                    {
                        totalChild = GetTotalChild(tempnode.GetStartPos(), temptag);
                        tempParent = new WitnessTree();
                        tempParent->appendList(&tempnode, 1);
                        this->ansStack->Push(tempParent);
                        this->ansStack->GetTop()->setNumberOfChildrenTotal(totalChild);
                        this->ansStack->GetTop()->setMiscInformation(temptag, strlen(temptag));
                        GetInfo(this->ansStack, this->isSimple, anssk, ansek, anslevel, anstag);
                        delete tempParent;
                        tempParent = NULL;
                        this->ansStack->GetTop()->incrementNumberOfChildrenWorthy();
                    }

                    //datanode = this->dataMng->getParent(this->fid, mainsk, false);
                    //totalChild = this->dataMng->getNumChildren(this->fid, datanode->getKey(), false);

                    //tempnode.SetStartPos(datanode->getKey());
                    //tempnode.SetEndPos(datanode->getEndKey());
                    //tempnode.SetLevel(datanode->getLevel());
                    //
                    //tempParent = new WitnessTree();
                    //tempParent->appendList(&tempnode, 1);

                    //this->ansStack->Push(tempParent);
                    //this->ansStack->GetTop()->setNumberOfChildrenTotal(totalChild);
                    //GetInfo(this->ansStack, this->isSimple, anssk, ansek, anslevel, anstag);

                    //delete tempParent;
                    //tempParent = NULL;

                    //this->ansStack->GetTop()->incrementNumberOfChildrenWorthy();
                }

            } // end of worth return ansTop

            else
            { // ansTop not worth return
                GetInfo(popped->getTree(), this->isSimple, this->dataMng, this->fid, popsk, popek, poplevel, poptag);
                this->lastAncestor.SetStartPos(popsk);
                this->lastAncestor.SetEndPos(popek);
                this->lastAncestor.SetLevel(poplevel);
                strcpy(this->lastAnsTag, (char *)popped->getMiscInformation());
            }

            this->getNext();
            continue;

        } // end of inTuple is the same as ansTop

        if ( this->ansStack->IsEmpty() || 
            GetRelation(cursk, curek, curlevel, curtag, anssk, ansek, anslevel, anstag) == DESCENDENT ||
            GetRelation(cursk, curek, curlevel, curtag, anssk, ansek, anslevel, anstag) == CHILD )
        { // `inTuple' is in the subtree of ansTop or ansStack is empty
            if ( this->qualifyFunction1(inTuple, curtag) )
            { // this incoming node is qualified, score > threshold

                this->mainStack->Push(inTuple);
                this->mainStack->GetTop()->setMiscInformation(curtag, strlen(curtag));
                GetInfo(this->mainStack, this->isSimple, mainsk, mainek, mainlevel, maintag);
                
                if ( GetRelation(anssk, ansek, anslevel, anstag, mainsk, mainek, mainlevel, maintag) == PARENT )
                { // ansTop is the new node's parent
                    this->ansStack->GetTop()->incrementNumberOfChildrenWorthy();
                }
                else
                { // ansTop is not yet the new node's parent
                    // retrieve parent from database
                    char temptag[20];
                    GetVirtualParent(this->dataMng, this->fid, mainsk, tempnode, temptag);
                    // deal with the situation where article contains p directly
                    if (temptag[0] != '\0' && strcmp(temptag, anstag) != 0)
                    {
                        totalChild = GetTotalChild(tempnode.GetStartPos(), temptag);
                        tempParent = new WitnessTree();
                        tempParent->appendList(&tempnode, 1);
                        this->ansStack->Push(tempParent);
                        this->ansStack->GetTop()->setNumberOfChildrenTotal(totalChild);
                        this->ansStack->GetTop()->setMiscInformation(temptag, strlen(temptag));
                        GetInfo(this->ansStack, this->isSimple, anssk, ansek, anslevel, anstag);
                        delete tempParent;
                        tempParent = NULL;
                        this->ansStack->GetTop()->incrementNumberOfChildrenWorthy();
                    }

                    //datanode = this->dataMng->getParent(this->fid, mainsk, false);
                    //totalChild = this->dataMng->getNumChildren(this->fid, datanode->getKey(), false);
                    //
                    //tempnode.SetStartPos(datanode->getKey());
                    //tempnode.SetEndPos(datanode->getEndKey());
                    //tempnode.SetLevel(datanode->getLevel());
                    //
                    //tempParent = new WitnessTree();
                    //tempParent->appendList(&tempnode, 1);

                    //this->ansStack->Push(tempParent);
                    //this->ansStack->GetTop()->setNumberOfChildrenTotal(totalChild);
                    //GetInfo(this->ansStack, this->isSimple, anssk, ansek, anslevel, anstag);

                    //delete tempParent;
                    //tempParent = NULL;

                    //this->ansStack->GetTop()->incrementNumberOfChildrenWorthy();
                }

                this->getNext();
                continue;
            }

            else
            { // this incoming node is not qualified
                this->getNext();
                continue;
            }

        } // end of `inTuple' in the subtree of ansTop or ansStack is empty

        //if ( !this->ansStack->IsEmpty() &&
        //    GetRelation(cursk, curek, curlevel, anssk, ansek, anslevel) == NONE );
        //  // never reached

    } // while (this->stillInput())

    // the input stream is done, we start outputing what's remaining on the stacks
    while ( ansStack->Size() > 0 || mainStack->Size() > 0 )
    { // ignore ansStack (wrong!?) and return nodes on mainStack, start with the top one
        if ( !this->ansStack->IsEmpty() )
            this->ansStack->Initialize();
        popped = this->mainStack->Pop();
        GetInfo(popped->getTree(), this->isSimple, this->dataMng, this->fid, 
                popsk, popek, poplevel, poptag);
        
        if (this->lastAncestor.GetStartPos() < 0)
        {
            if (!this->selectFunction1(popped, NULL, NULL))
            { // the top of mainStack is not worth return
                this->lastAncestor.SetStartPos(popsk);
                //this->lastAncestor.SetEndPos(popek);
                //this->lastAncestor.SetLevel(poplevel);
                strcpy(this->lastAnsTag, poptag);
                continue;
            }
            else
            { // the top of mainStack is worth return
                /* change lastAncestor to something that is discarded
                 * in real relationship: simulate it by modify the level
                 * in virtual relationship: simulate it by change the tagname
                 */
                this->lastAncestor.SetStartPos(popsk);
                //this->lastAncestor.SetEndPos(popek);
                //this->lastAncestor.SetLevel(poplevel);
                if (strcmp(poptag, "article") == 0)
                    strcpy(this->lastAnsTag, "journal");
                else if (strcmp(poptag, "sec") == 0)
                    strcpy(this->lastAnsTag, "article");
                else 
                    strcpy(this->lastAnsTag, "sec");

                resultBuffer->initialize();
                if (this->isSimple)
                {
                    resultBuffer->appendList((ListNode *)(popped->getTree()->getBuffer()), 
                        popped->getTree()->length());
                    resultBuffer->setScore(popped->getTree()->getScore());
                }
                else
                {
                    resultBuffer->appendList((ComplexListNode *)(popped->getTree()->getBuffer()), 
                        this->dataMng, popped->getTree()->length());
                    resultBuffer->setScore(popped->getTree()->getScore());
                }
                node = resultBuffer;

#if (HAVE_MERCY_ON_SORT)
                        pickcnt++;
                        if (pickcnt > MAX_RESULT)
                            node = NULL;
#endif

                return;
            }
        }
        else if ( this->selectFunction1(popped, &(this->lastAncestor), this->lastAnsTag) )
        {
            resultBuffer->initialize();
            if (this->isSimple)
            {
                resultBuffer->appendList((ListNode *)(popped->getTree()->getBuffer()), 
                    popped->getTree()->length());
                resultBuffer->setScore(popped->getTree()->getScore());
            }
            else
            {
                resultBuffer->appendList((ComplexListNode *)(popped->getTree()->getBuffer()), 
                    this->dataMng, popped->getTree()->length());
                resultBuffer->setScore(popped->getTree()->getScore());
            }
            node = resultBuffer;

#if (HAVE_MERCY_ON_SORT)
                        pickcnt++;
                        if (pickcnt > MAX_RESULT)
                            node = NULL;
#endif

            return;
        }

    } // while (ansStack->Size() > 0 || mainStack->Size() > 0)

    // both stacks are empty and input stream is done
    // we are done too!
    node = NULL;
    return;
}

