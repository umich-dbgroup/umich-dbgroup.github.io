
#include "parse.hpp"

char QueryEvaluationTreePickNode::getIdentifier(void) { return 'K'; }

char PickPlanParser::getIteratorIdentifier(void) { return 'K'; }

void 
PickPlanParser::getQueryEvalNode(EvaluatorClass* evaluator, char* line, void* queryInput, QueryEvaluationTreeNode*& curr)
	    {
		char *token = strtok(line+2,",");
		if (token == NULL)
		{
		    globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"Evaluator",__FILE__,"Error input from file... expecting function 1 number... pick line...");
		    curr=NULL; return;
		}
		int f1 = atoi(token);

		token = strtok(NULL,",");
		if (token == NULL)
		{
		    globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"Evaluator",__FILE__,"Error input from file... expecting function 2 number... pick line...");
		    curr=NULL; return;
		}
		int f2 = atoi(token);

		token = strtok(NULL,",");
		if (token == NULL)
		{
		    globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"Evaluator",__FILE__,"Error input from file... expecting sort or not (1/0)... pick line...");
		    curr=NULL; return;
		}
		if (atoi(token) != 0 && atoi(token) != 1)
		{
		    globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"Evaluator",__FILE__,"Error input from file... sort should be 0 or 1... pick line...");
		    curr=NULL; return;
		}
		bool sort = (bool)atoi(token);

		char newLine[MAX_FILE_INTERFACE_LINE_SIZE];
		if (((std::iostream *)queryInput)->eof() == 0)
		    ((std::iostream *)queryInput)->getline(newLine,MAX_FILE_INTERFACE_LINE_SIZE);
		else
		{
		    globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"Evaluator",__FILE__,"Unexpected end of file... pick line...");
		    curr=NULL; return;
		}
		QueryEvaluationTreeNode *oper = evaluator->getQueryEvalNode(newLine,queryInput);
		if (oper == NULL)
		{
		    globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"Evaluator",__FILE__,"Unexpected operand returned... pick line...");
		    curr=NULL; return;
		}
		curr  = new QueryEvaluationTreePickNode(oper,f1,f2,sort);
	    }

