#include "../../Evaluator/EvaluatorClass.h"

#include "QueryEvaluationTreePickNode.h"

#include "PickIterator.h"
#include "extra.h"

void QueryEvaluationTreePickNode::processQueryEvalNode(EvaluatorClass* evaluator, IteratorClass*& curr)
	    {
		IteratorClass *opr = evaluator->processQueryEvalNode(getOperand());
		if (opr == NULL)
		{
		    globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"Evaluator",__FILE__, "operand returned is NULL. pick process eval node..." );
		    curr=NULL; return;
		}
		bool ( *f1)(PickStackNode *node, ListNode *standard, char *lastTag); 
		bool ( *f2)(WitnessTree *tree, char *tag);
		switch (getFunctionNum1())
		{
		    case 1:
			f1 = Select;
			break;
		    default:
			globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"Evaluator",__FILE__, "unrecognized function1 number. pick process eval node..." );
			curr=NULL; return;
		}
		switch (getFunctionNum2())
		{
		    case 1:
			f2 = Qualify;
			break;
		    default:
			globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"Evaluator",__FILE__, "unrecognized function2 number. pick process eval node..." );
			curr=NULL; return;
		}

		curr = new PickIterator(opr,f1,f2,evaluator->getDataManager(),getSort());
	    }

