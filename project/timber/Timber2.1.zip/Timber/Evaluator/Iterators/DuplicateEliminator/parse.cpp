
#include "parse.hpp"

char QueryEvaluationTreeDuplicateEliminatorNode::getIdentifier(void) { return 'D'; }

char DuplicateEliminatorPlanParser::getIteratorIdentifier(void) { return 'D'; }

void 
DuplicateEliminatorPlanParser::getQueryEvalNode(EvaluatorClass* evaluator, char* line, void* queryInput, QueryEvaluationTreeNode*& curr)
	    {
		// elminate by what
		char *token = strtok(line+2,",");                    
		if (token == NULL)
		{
		    globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"Evaluator",__FILE__,"Error input from file... expecting eliminate by what... DuplicateEliminator line...");
		    curr=NULL; return;
		}
		int elimByWhat;
		if (strcmp(token,"SK") == 0)
		    elimByWhat = ELIMINATE_DUPLICATES_STARTKEY;
		else if (strcmp(token,"TS") == 0)
		    elimByWhat = ELIMINATE_DUPLICATES_TEXT_STR;
		else if (strcmp(token,"TN") == 0)
		    elimByWhat = ELIMINATE_DUPLICATES_TEXT_NUM;
		else if (strcmp(token,"AS") == 0)
		    elimByWhat = ELIMINATE_DUPLICATES_ATTR_STR;
		else if (strcmp(token,"AN") == 0)
		    elimByWhat = ELIMINATE_DUPLICATES_ATTR_NUM;
		else if (strcmp(token,"VS") == 0)
		    elimByWhat = ELIMINATE_DUPLICATES_VAL_STR;
		else if (strcmp(token,"VN") == 0)
		    elimByWhat = ELIMINATE_DUPLICATES_VAL_NUM;
		else if (strcmp(token,"TR") == 0)
		    elimByWhat = ELIMINATE_DUPLICATES_TREE;
		else
		{
		    globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"Evaluator",__FILE__,"Error input from file... unrecognized eliminate by what value... DuplicateEliminator line...");
		    curr=NULL; return;
		}

		token = strtok(NULL,",");
		if (token == NULL)
		{
		    globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"Evaluator",__FILE__,"Error input from file... expecting nre... DuplicateEliminator line...");
		    curr=NULL; return;
		}
		NREType nre = (NREType)atoi(token);
		if (nre < 1)
		{
		    globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"Evaluator",__FILE__,"NRE should be positive.");   
		    curr=NULL; return;
		}
		if (nre > evaluator->maxNRE)
		    evaluator->maxNRE = nre;

		// expected size
		token = strtok(NULL,",");
		if (token == NULL)
		{
		    globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"Evaluator",__FILE__,"Error input from file... expecting expected size... DuplicateEliminator line...");
		    curr=NULL; return;
		}
		int size = atoi(token);

		// attribute name
		token = strtok(NULL,",");
		if (token == NULL)
		{
		    globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"Evaluator",__FILE__,"Error input from file... expecting attribute name or NULL... DuplicateEliminator line...");
		    curr=NULL; return;
		}
		char *attrName;
		/*   if (strcmp(token,"NULL") == 0)
		     attrName = NULL;
		     else
		     {*/
		attrName = new char[strlen(token)+1];
		strcpy(attrName,token);
		//	}

		// sort or not
		token = strtok(NULL,",");
		if (token == NULL)
		{
		    globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"Evaluator",__FILE__,"Error input from file... expecting sort bool... DuplicateEliminator line...");
		    if (attrName) delete [] attrName;
		    curr=NULL; return;
		}
		if (atoi(token) != 0 && atoi(token) != 1)
		{
		    globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"Evaluator",__FILE__,"Error input from file... sort should be 0 or 1... DuplicateEliminator line...");
		    if (attrName) delete [] attrName;
		    curr=NULL; return;
		}
		bool sort = (bool)atoi(token);

		bool ext = false;
		token = strtok(NULL,",");
		if (token != NULL)
		{
		    if (strcmp(token,"X") == 0)
			ext = true;
		}
		// grab the operand
		char newLine[MAX_FILE_INTERFACE_LINE_SIZE];
		if (((std::iostream *)queryInput)->eof() == 0)
		    ((std::iostream *)queryInput)->getline(newLine,MAX_FILE_INTERFACE_LINE_SIZE);
		else
		{
		    globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"Evaluator",__FILE__,"Unexpected end of file... duplicate eliminator line...");
		    if (attrName) delete [] attrName;
		    curr=NULL; return;
		}
		QueryEvaluationTreeNode *oper = evaluator->getQueryEvalNode(newLine,queryInput);

		if (oper == NULL)
		{
		    globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"Evaluator",__FILE__,"Unexpected operand returned in DuplicateElimination.");
		    if (attrName) delete [] attrName;
		    curr=NULL; return;
		}
		curr  = new QueryEvaluationTreeDuplicateEliminatorNode(elimByWhat,nre,size,attrName,sort,ext,oper);
		if (ext)
		    evaluator->fileIDsArraySize++;
	    }

