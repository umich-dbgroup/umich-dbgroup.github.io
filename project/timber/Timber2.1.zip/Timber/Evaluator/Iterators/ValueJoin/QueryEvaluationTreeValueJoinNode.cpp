/*
COPYRIGHT  � 2000-2004 
THE REGENTS OF THE UNIVERSITY OF MICHIGAN
ALL RIGHTS RESERVED

PERMISSION IS GRANTED TO USE, COPY, CREATE DERIVATIVE WORKS AND REDISTRIBUTE THIS SOFTWARE AND SUCH DERIVATIVE WORKS FOR 
NONCOMMERCIAL EDUCATION AND RESEARCH PURPOSES, SO LONG AS NO FEE IS CHARGED, AND SO LONG AS THE COPYRIGHT NOTICE ABOVE, 
THIS GRANT OF PERMISSION, AND THE DISCLAIMER BELOW APPEAR IN ALL COPIES MADE; AND SO LONG AS THE NAME OF THE UNIVERSITY 
OF MICHIGAN IS NOT USED IN ANY ADVERTISING OR PUBLICITY PERTAINING TO THE USE OR DISTRIBUTION OF THIS SOFTWARE WITHOUT 
SPECIFIC, WRITTEN PRIOR AUTHORIZATION.

THIS SOFTWARE IS PROVIDED AS IS, WITHOUT REPRESENTATION FROM THE UNIVERSITY OF MICHIGAN AS TO ITS FITNESS FOR ANY PURPOSE, 
AND WITHOUT WARRANTY BY THE UNIVERSITY OF MICHIGAN OF ANY KIND, EITHER EXPRESS OR IMPLIED, INCLUDING WITHOUT LIMITATION THE 
IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE. THE REGENTS OF THE UNIVERSITY OF MICHIGAN SHALL 
NOT BE LIABLE FOR ANY DAMAGES, INCLUDING SPECIAL, INDIRECT, INCIDENTAL, OR CONSEQUENTIAL DAMAGES, WITH RESPECT TO ANY CLAIM 
ARISING OUT OF OR IN CONNECTION WITH THE USE OF THE SOFTWARE, EVEN IF IT HAS BEEN OR IS HEREAFTER ADVISED OF THE POSSIBILITY 
OF SUCH DAMAGES.
*/

#include "QueryEvaluationTreeValueJoinNode.h"
#include <string>

QueryEvaluationTreeValueJoinNode::QueryEvaluationTreeValueJoinNode(QueryEvaluationTreeNode* left,
		QueryEvaluationTreeNode* right, NREType rootNRE, NREType leftNRE, NREType rightNRE, int leftTag,
		int rightTag, int estimatedSize, char *attrNameLeft,char *attrNameRight,
		int operation, int joinByWhatLeft, int joinByWhatRight, bool sortedInput, bool nest, bool outer,
		char *indexName,char *fileName,
		bool atLeastOne)
: QueryEvaluationTreeNode()
{
	this->left = left;
	this->right = right;
	this->leftNRE = leftNRE;
	this->rightNRE = rightNRE;
	this->rootNRE = rootNRE;
	this->leftTag = leftTag;
	this->rightTag = rightTag;
	this->estimatedSize = estimatedSize;
	this->attrNameLeft = attrNameLeft;
	this->attrNameRight = attrNameRight;
	this->operation = operation;
	this->joinByWhatLeft = joinByWhatLeft;
	this->joinByWhatRight = joinByWhatRight;
	this->sortedInput = sortedInput;
	this->nest = nest;
	this->outer = outer;
	this->indexName = indexName;
	this->fileName = fileName;

	this->atLeastOne = atLeastOne;
}



QueryEvaluationTreeValueJoinNode::~QueryEvaluationTreeValueJoinNode()
{
	if (left)
		delete left;
	if (right)
		delete right;
	if (fileName) delete [] fileName;
}

void QueryEvaluationTreeValueJoinNode::setOperation(int operation)
{
	this->operation = operation;
}

int QueryEvaluationTreeValueJoinNode::getOperation()
{
	return operation;
}
	
void QueryEvaluationTreeValueJoinNode::setJoinByWhatLeft(int joinByWhatLeft)
{
	this->joinByWhatLeft = joinByWhatLeft;
}

int QueryEvaluationTreeValueJoinNode::getJoinByWhatLeft()
{
	return joinByWhatLeft;
}

void QueryEvaluationTreeValueJoinNode::setJoinByWhatRight(int joinByWhatRight)
{
	this->joinByWhatRight = joinByWhatRight;
}

int QueryEvaluationTreeValueJoinNode::getJoinByWhatRight()
{
	return joinByWhatRight;
}

void QueryEvaluationTreeValueJoinNode::setEstimatedSize(int estimatedSize)
{
	this->estimatedSize = estimatedSize;
}

int QueryEvaluationTreeValueJoinNode::getEstimatedSize()
{
	return this->estimatedSize;
}

void QueryEvaluationTreeValueJoinNode::setLeft(QueryEvaluationTreeNode *left)
{
	this->left = left;
}

QueryEvaluationTreeNode *QueryEvaluationTreeValueJoinNode::getLeft()
{
	return this->left;
}

void QueryEvaluationTreeValueJoinNode::setRight(QueryEvaluationTreeNode *right)
{
	this->right = right;
}

QueryEvaluationTreeNode *QueryEvaluationTreeValueJoinNode::getRight()
{
	return this->right;
}

void QueryEvaluationTreeValueJoinNode::setLeftNRE(NREType leftNRE)
{
	this->leftNRE = leftNRE;
}

NREType QueryEvaluationTreeValueJoinNode::getLeftNRE()
{
	return this->leftNRE;
}

void QueryEvaluationTreeValueJoinNode::setRightNRE(NREType rightNRE)
{
	this->rightNRE = rightNRE;
}

NREType QueryEvaluationTreeValueJoinNode::getRightNRE()
{
	return this->rightNRE;
}

void QueryEvaluationTreeValueJoinNode::setRootNRE(NREType rootNRE)
{
	this->rootNRE = rootNRE;
}

NREType QueryEvaluationTreeValueJoinNode::getRootNRE()
{
	return this->rootNRE;
}


void QueryEvaluationTreeValueJoinNode::setLeftTag(int leftTag)
{
	this->leftTag = leftTag;
}
void QueryEvaluationTreeValueJoinNode::setRightTag(int rightTag)
{
	this->rightTag = rightTag;
}

int QueryEvaluationTreeValueJoinNode::getLeftTag()
{
	return this->leftTag;
}

int QueryEvaluationTreeValueJoinNode::getRightTag()
{
	return this->rightTag;
}


void QueryEvaluationTreeValueJoinNode::setAttrNameLeft(char *attrNameLeft)
{
	this->attrNameLeft = attrNameLeft;
}

char *QueryEvaluationTreeValueJoinNode::getAttrNameLeft()
{
	return this->attrNameLeft;
}

void QueryEvaluationTreeValueJoinNode::setAttrNameRight(char *attrNameRight)
{
	this->attrNameRight = attrNameRight;
}

char *QueryEvaluationTreeValueJoinNode::getAttrNameRight()
{
	return this->attrNameRight;
}

void QueryEvaluationTreeValueJoinNode::setSortedInput(bool sortedInput)
{
	this->sortedInput = sortedInput;
}

bool QueryEvaluationTreeValueJoinNode::getSortedInput()
{
	return this->sortedInput;
}

void QueryEvaluationTreeValueJoinNode::setNest(bool nest)
{
	this->nest = nest;
}

bool QueryEvaluationTreeValueJoinNode::getNest()
{
	return this->nest;
}

void QueryEvaluationTreeValueJoinNode::setOuter(bool outer)
{
	this->outer = outer;
}

bool QueryEvaluationTreeValueJoinNode::getOuter()
{
	return this->outer;
}

void QueryEvaluationTreeValueJoinNode::setAtLeastOne(bool atLeastOne)
{
	this->atLeastOne = atLeastOne;
}

bool QueryEvaluationTreeValueJoinNode::getAtLeastOne()
{
	return this->atLeastOne;
}

void QueryEvaluationTreeValueJoinNode::setIndexName(char *indexName)
{
	this->indexName = indexName;
}

char *QueryEvaluationTreeValueJoinNode::getIndexName()
{
	return this->indexName;
}

void QueryEvaluationTreeValueJoinNode::setFileName(char *fileName)
{
	this->fileName = fileName;
}

char *QueryEvaluationTreeValueJoinNode::getFileName()
{
	return this->fileName;
}

void QueryEvaluationTreeValueJoinNode::deleteStructures()
{
	if (attrNameLeft) delete [] attrNameLeft;
	if (attrNameRight) delete [] attrNameRight;
	if (indexName) delete [] indexName;
	left->deleteStructures();
	right->deleteStructures();
}
