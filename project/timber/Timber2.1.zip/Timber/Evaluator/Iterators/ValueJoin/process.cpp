#include "../../Evaluator/EvaluatorClass.h"

#include "QueryEvaluationTreeValueJoinNode.h"

#include "ValueJoinIterator.h"
#include "extra.h"

void QueryEvaluationTreeValueJoinNode::processQueryEvalNode(EvaluatorClass* evaluator, IteratorClass*& curr)
	    {
		int openFileIndex = -1;
		if (getFileName() != NULL)
		{
		    openFileIndex= evaluator->openFile(getFileName(),evaluator->getDataManager());
		    if (openFileIndex == -1)
		    {
			globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"Evaluator",__FILE__,"File is unloaded in Timber.");
			curr=NULL; return;
		    }
		}
		IteratorClass *opr1 = evaluator->processQueryEvalNode(getLeft());

		if (opr1 == NULL)
		{
		    globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"Evaluator",__FILE__, "operand1 returned is NULL. value join process eval node..." );
		    curr=NULL; return;
		}
		IteratorClass *opr2 = evaluator->processQueryEvalNode(getRight());
		if (opr2 == NULL)
		{
		    globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"Evaluator",__FILE__, "operand2 returned is NULL. value join process eval node..." );
		    delete opr1;
		    curr=NULL; return;
		}
		curr = new ValueJoinIterator(opr1,opr2,getLeftNRE(),getRightNRE(),
			getLeftTag(),getRightTag(),
			getEstimatedSize(),getAttrNameLeft(),getAttrNameRight(),
			evaluator->getDataManager(), getOperation(),
			getJoinByWhatLeft(),
			getJoinByWhatRight(),getSortedInput()
			,getNest(),getOuter(),getRootNRE(), getIndexName(),
			openFileIndex,getAtLeastOne());
		setAttrNameLeft(NULL);
		setAttrNameRight(NULL);
		setIndexName(NULL);
	    }

