/*
COPYRIGHT  � 2000-2004 
THE REGENTS OF THE UNIVERSITY OF MICHIGAN
ALL RIGHTS RESERVED

PERMISSION IS GRANTED TO USE, COPY, CREATE DERIVATIVE WORKS AND REDISTRIBUTE THIS SOFTWARE AND SUCH DERIVATIVE WORKS FOR 
NONCOMMERCIAL EDUCATION AND RESEARCH PURPOSES, SO LONG AS NO FEE IS CHARGED, AND SO LONG AS THE COPYRIGHT NOTICE ABOVE, 
THIS GRANT OF PERMISSION, AND THE DISCLAIMER BELOW APPEAR IN ALL COPIES MADE; AND SO LONG AS THE NAME OF THE UNIVERSITY 
OF MICHIGAN IS NOT USED IN ANY ADVERTISING OR PUBLICITY PERTAINING TO THE USE OR DISTRIBUTION OF THIS SOFTWARE WITHOUT 
SPECIFIC, WRITTEN PRIOR AUTHORIZATION.

THIS SOFTWARE IS PROVIDED AS IS, WITHOUT REPRESENTATION FROM THE UNIVERSITY OF MICHIGAN AS TO ITS FITNESS FOR ANY PURPOSE, 
AND WITHOUT WARRANTY BY THE UNIVERSITY OF MICHIGAN OF ANY KIND, EITHER EXPRESS OR IMPLIED, INCLUDING WITHOUT LIMITATION THE 
IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE. THE REGENTS OF THE UNIVERSITY OF MICHIGAN SHALL 
NOT BE LIABLE FOR ANY DAMAGES, INCLUDING SPECIAL, INDIRECT, INCIDENTAL, OR CONSEQUENTIAL DAMAGES, WITH RESPECT TO ANY CLAIM 
ARISING OUT OF OR IN CONNECTION WITH THE USE OF THE SOFTWARE, EVEN IF IT HAS BEEN OR IS HEREAFTER ADVISED OF THE POSSIBILITY 
OF SUCH DAMAGES.
*/
#ifndef __functionIterator_h
#define __functionIterator_h
#include <timber-compat.h>


#include "../ValueSort/ValueSortIterator.h"





/**
* An access method that performs a function on all input and produces 1 tree.
* @see IteratorClass
* @see EvaluatorClass
* @see WitnessTree
* @author Shurug Al-Khalifa 
* @version 1.0
*/

class FunctionIterator : public IteratorClass
{
public:
	/**
	Constructor
	@param input where this iterator gets its input trees.
	@param length is length of operations array, onWhat array and attrName array (if it is not null).
	@param operations is an array of operations you would like to perform on input. Each entry
		can be one of the following: COUNT, SUM, AVG, MIN, or MAX.
	@param onWhat is an array that specifies on what the corresponding operation in operations array
		should be performed. It can be one of the following: 
			ON_ATTRIBUTE_*: in this case a corresponding attrName in attrName operation should be present
							and also an index of an element node that has the attribute in the index array.
							* can be NUM or STR. if NUM then attribute value compared as numbers else as strings.
							exp. you want maximum of attribute price of node 2 in tree ==> operation[i] = MAX
								onWhat[i] = ON_ATTRIBUTE, index[i] = 2, and attrName[i] = "price"
			ON_TEXT_* : in this case only an index of the element is needed.
							* can be NUM or STR. if NUM then text compared as numbers else as strings.
							exp. you want avg of content of element 2 in the tree ==> operation[i] = AVG
								onWhat[i] = ON_TEXT, index[i] = 2, and attrName[i] = NULL (we ignore it).
			ON_FANOUT_LOCAL: in this case only an index of the element that you want its local fanout is needed.	
						local fanout is the number of children of a given node in the tree (not necessarily in 
						the database).
						exp. you want minimum of local fan out of node 2 in the tree ==> operation[i] = MIN
							onWhat[i] = ON_FANOUT_LOCAL, index[i] = 2, and attrName[i] = NULL (we ignore it).	
			ON_FANOUT_ACTUAL: in this case only an index of the element that you want its actual fanout is needed.	
						actual fanout is the number of children of a given node in the database (orig XML doc).
			ON_DEPTH_LOCAL: in this case only an index of the element that you want its local depth is needed.	
						local fanout is the depth of the subtree of a given node in the tree (not necessarily in 
						the database).
						exp. you want minimum of local fan out of node 2 in the tree ==> operation[i] = MIN
							onWhat[i] = ON_FANOUT_LOCAL, index[i] = 2, and attrName[i] = NULL (we ignore it).	
			ON_DEPTH_ACTUAL: in this case only an index of the element that you want its actual depth is needed.	
						actual depth is the depth of a subtree of a given node in the database (orig XML doc).
	@param index is an array of indices of nodes in the input tree. Each cell in the array corresponds to an oper
			in the operations array. Each cell in the array should have a value if the corresponding operation is
			not COUNT. The value in index[i] corresponds to the element in input tree that we are performing the
			operation on its attribute, text, or fanout.
	@param attrName is an array of attribute names that matter only if corresponding onWhat entry is ON_ATTRIBUTE.
			The value in attrName[i] will be the name of the attribute to perform the operation on its value.
	@param dataMng an instance of the data manager.
	**/
	FunctionIterator(IteratorClass *input,int length, int *operations, int *onWhat, NREType *nre,char **attrName, NREType *assignedNRE,
		DataMng *dataMng);

	/**
	Destructor
	releases the space used by output buffer.
	**/
	~FunctionIterator();

	/**
	Access Method
	gets the next output from this iterator.
	@param node is a pointer that well be set to the output buffer or NULL (indicating that
	there are no more results).
	**/
	void next(WitnessTree *&node);

private:

	/**
	Access Method
	gets the text value of an element as a number.
	@param which is the index of values that we need to look at in all the arrays. So, the value
			that is got is the text of element with index index[which] in the input tree.
	@returns a float that is the content of element index[which] in the input tree.
	**/
	int getTextValueNum(int which, float &num);


	/**
	Access Method
	gets the text value of an element as a number.
	@param which is the index of values that we need to look at in all the arrays. So, the value
			that is got is the text of element with index index[which] in the input tree.
	@returns a float that is the content of element index[which] in the input tree.
	**/
	int getLocalTextValueNum(int which, float &num);

	int getLocalAttrValueNum(int which, float &num);

	/**
	Access Method
	gets the value of an attribute of an element as a number.
	@param which is the index of values that we need to look at in all the arrays. So, the value
			that is got is the content of element with index index[which] and attribute name is
			attrName[which].
	@returns a float that is the content of attribute attrName[which] of element index[which] 
			in the input tree.
	**/
	int getAttributeValueNum(int which, float &num);
	
	/**
	Access Method
	gets the actual fanout of an element.
	@param which is the index of values that we need to look at in all the arrays. So, the value
			that is got is the fanout of element with index index[which] in the input tree.
	@returns a float that is the actual fanout of element index[which] in the input tree.
	**/
	int getFanOutValue(int which, float &num);

	/**
	Access Method
	gets the local fanout of an element in the input tree.
	@param which is the index of values that we need to look at in all the arrays. So, the value
			that is got is the fanout of element with index index[which] in the input tree.
	@returns a float that is the local fanout of element index[which] in the input tree.
	**/
	int getLocalFanOutValue(int which, float &num);

	/**
	Access Method
	gets the actual depth of an element.
	@param which is the index of values that we need to look at in all the arrays. So, the value
			that is got is the depth of element with index index[which] in the input tree.
	@returns a float that is the actual depth of element index[which] in the input tree.
	**/
	int getDepthValue(int which, float &num);

	/**
	Access Method
	gets the local depth of an element in the input tree.
	@param which is the index of values that we need to look at in all the arrays. So, the value
			that is got is the depth of element with index index[which] in the input tree.
	@returns a float that is the local depth of element index[which] in the input tree.
	**/
	int getLocalDepthValue(int which, float &num);
	int getValueNum(int which, float &num);
	
	char *getStrOfNode(ComplexListNode *node, char *attrName);
	void formatFloat(double num, char *str);
	/**
	Buffer that holds the output tree. 
	**/
	WitnessTree *resultBuffer;

	/**
	Pointer to the input tree read from input.
	**/
	WitnessTree *inTuple;

	/**
	an iterator that produces the input trees.
	**/
	IteratorClass *input;

	/**
	Operations that need to be performed.
	**/
	int *operations;

	/**
	On what each of the operations are performed.
	**/
	int *onWhat;

	/**
	The index of an element node that we need to perform the operation
	on its text value, attribute, or fanout.
	**/
	NREType *nre;

	/**
	length of input arrays (number of operations)
	**/
	int length;

	/**
	if the operation is to be performed on an attribute, this holds its name.
	**/
	char **attrName;

	/**
	this holds the number values being computed. sum, avg, ...
	**/
	double *valueNum;

	/**
	number of input trees.
	**/
	int *counter;

	NREType *assignedNRE;
	/**
	an instance of the data manager
	**/
	DataMng *dataMng;
	bool *floatFound;
};

#endif
