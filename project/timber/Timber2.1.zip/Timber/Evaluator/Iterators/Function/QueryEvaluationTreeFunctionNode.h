/*
COPYRIGHT  � 2000-2004 
THE REGENTS OF THE UNIVERSITY OF MICHIGAN
ALL RIGHTS RESERVED

PERMISSION IS GRANTED TO USE, COPY, CREATE DERIVATIVE WORKS AND REDISTRIBUTE THIS SOFTWARE AND SUCH DERIVATIVE WORKS FOR 
NONCOMMERCIAL EDUCATION AND RESEARCH PURPOSES, SO LONG AS NO FEE IS CHARGED, AND SO LONG AS THE COPYRIGHT NOTICE ABOVE, 
THIS GRANT OF PERMISSION, AND THE DISCLAIMER BELOW APPEAR IN ALL COPIES MADE; AND SO LONG AS THE NAME OF THE UNIVERSITY 
OF MICHIGAN IS NOT USED IN ANY ADVERTISING OR PUBLICITY PERTAINING TO THE USE OR DISTRIBUTION OF THIS SOFTWARE WITHOUT 
SPECIFIC, WRITTEN PRIOR AUTHORIZATION.

THIS SOFTWARE IS PROVIDED AS IS, WITHOUT REPRESENTATION FROM THE UNIVERSITY OF MICHIGAN AS TO ITS FITNESS FOR ANY PURPOSE, 
AND WITHOUT WARRANTY BY THE UNIVERSITY OF MICHIGAN OF ANY KIND, EITHER EXPRESS OR IMPLIED, INCLUDING WITHOUT LIMITATION THE 
IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE. THE REGENTS OF THE UNIVERSITY OF MICHIGAN SHALL 
NOT BE LIABLE FOR ANY DAMAGES, INCLUDING SPECIAL, INDIRECT, INCIDENTAL, OR CONSEQUENTIAL DAMAGES, WITH RESPECT TO ANY CLAIM 
ARISING OUT OF OR IN CONNECTION WITH THE USE OF THE SOFTWARE, EVEN IF IT HAS BEEN OR IS HEREAFTER ADVISED OF THE POSSIBILITY 
OF SUCH DAMAGES.
*/

#include "../../QueryEvaluationTree/QueryEvaluationTreeNode.h"

#ifndef __QueryEvaluationTreeFunctionNode_H
#define __QueryEvaluationTreeFunctionNode_H
#include <timber-compat.h>


class QueryEvaluationTreeFunctionNode: public QueryEvaluationTreeNode
{
public: 
	void processQueryEvalNode(EvaluatorClass* evaluator, IteratorClass*& curr);
	char getIdentifier();
	QueryEvaluationTreeFunctionNode(QueryEvaluationTreeNode* operand,NREType *assignedNRE,
		 int num, int *operation, int *onWhat, NREType *nre,
		char **attrName, bool treeLevel);
	~QueryEvaluationTreeFunctionNode();

	int *getOperation();
	void setOperation(int *operation);

	int *getOnWhat();
	void setOnWhat(int *onWhat);

	NREType *getNRE();
	void setNRE(NREType *nre);

	NREType *getAssignedNRE();
	void setAssignedNRE(NREType *assignedNRE);

	int getNum();
	void setNum(int num);

	bool getTreeLevel();
	void setTreeLevel(bool treeLevel);

	char **getAttrName();
	void setAttrName(char **attrName);

	QueryEvaluationTreeNode *getOperand();
	void setOperand(QueryEvaluationTreeNode* operand);
	void deleteStructures();

private:
	QueryEvaluationTreeNode* operand;

	NREType *nre;
	int *operation;
	int *onWhat;
	char **attrName;
	int num;
	NREType *assignedNRE;
	bool treeLevel;
};



#endif

