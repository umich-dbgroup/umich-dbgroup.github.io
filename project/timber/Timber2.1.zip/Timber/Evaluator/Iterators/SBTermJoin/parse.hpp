#include "../../Evaluator/EvaluatorClass.h"

#include "extra.h"

class SBTermJoinPlanParser
{
public:

	static char getIteratorIdentifier(void) ;

	static void getQueryEvalNode(EvaluatorClass* evaluator, char* line, void* queryInput, QueryEvaluationTreeNode*& curr) ;

} ;

#ifndef WIN32

extern "C" char getIteratorIdentifier(void)
{
	return SBTermJoinPlanParser::getIteratorIdentifier() ;
} ;

extern "C" void getQueryEvalNode(EvaluatorClass* evaluator, char* line, void* queryInput, QueryEvaluationTreeNode*& curr)
{
	return SBTermJoinPlanParser::getQueryEvalNode(evaluator, line, queryInput, curr) ;
} ;

#endif
