extern double scoreFunction1(char *xmlDoc, int keywordSet);
extern double scoreFunction2(char *xmlDoc, int keywordSet);
extern bool ancsQual1(double score, int keywordSet);
extern int ancsLevel1(KeyType sk, int level, int keywordSet); /* what for? */

#include "QueryEvaluationTreeSBTermJoinNode.h"
