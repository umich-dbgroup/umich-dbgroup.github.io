/*
COPYRIGHT  � 2000-2004 
THE REGENTS OF THE UNIVERSITY OF MICHIGAN
ALL RIGHTS RESERVED

PERMISSION IS GRANTED TO USE, COPY, CREATE DERIVATIVE WORKS AND REDISTRIBUTE THIS SOFTWARE AND SUCH DERIVATIVE WORKS FOR 
NONCOMMERCIAL EDUCATION AND RESEARCH PURPOSES, SO LONG AS NO FEE IS CHARGED, AND SO LONG AS THE COPYRIGHT NOTICE ABOVE, 
THIS GRANT OF PERMISSION, AND THE DISCLAIMER BELOW APPEAR IN ALL COPIES MADE; AND SO LONG AS THE NAME OF THE UNIVERSITY 
OF MICHIGAN IS NOT USED IN ANY ADVERTISING OR PUBLICITY PERTAINING TO THE USE OR DISTRIBUTION OF THIS SOFTWARE WITHOUT 
SPECIFIC, WRITTEN PRIOR AUTHORIZATION.

THIS SOFTWARE IS PROVIDED AS IS, WITHOUT REPRESENTATION FROM THE UNIVERSITY OF MICHIGAN AS TO ITS FITNESS FOR ANY PURPOSE, 
AND WITHOUT WARRANTY BY THE UNIVERSITY OF MICHIGAN OF ANY KIND, EITHER EXPRESS OR IMPLIED, INCLUDING WITHOUT LIMITATION THE 
IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE. THE REGENTS OF THE UNIVERSITY OF MICHIGAN SHALL 
NOT BE LIABLE FOR ANY DAMAGES, INCLUDING SPECIAL, INDIRECT, INCIDENTAL, OR CONSEQUENTIAL DAMAGES, WITH RESPECT TO ANY CLAIM 
ARISING OUT OF OR IN CONNECTION WITH THE USE OF THE SOFTWARE, EVEN IF IT HAS BEEN OR IS HEREAFTER ADVISED OF THE POSSIBILITY 
OF SUCH DAMAGES.
*/

#ifndef __stackbasedtermjoin_h
#define __stackbasedtermjoin_h
#include <timber-compat.h>


#include "SBTermJoinStackNode.h"
#include "SBTermJoinComplexStackNode.h"
#include "../StructuralJoin/StackBasedAncs.h"
#include "../PhraseFinder/PhraseFinderIterator.h"
#include "../../Evaluator/EvaluatorClass.h"
#include <float.h>

#define INITIAL_XML_BUFFER_SIZE				500
#define INITIAL_XML_BUFFER_SIZE_COMPLEX		1500

/**
* This class represents the term join algorithm. it takes in a phrase consisting of
* a bunch of words. this join returns ancestors of these nodes with scores assigned to 
* them.
* @see WitnessTree
* @see stack
* @see SBTermJoinStackNode
* @see SBTermJoinComplexStackNode
* @see DataMng
* @see IteratorClass
* @author Shurug Al-Khalifa 
* @version 1.0
*/
class StackBasedTermJoin : public IteratorClass
{
public:

	/**
	Constructor.
	initializes variables.
	@param phrase is the phrase consisting of several words. we want to find the ancestors of text nodes containing
			these words.
	@param indexName is the name of the inverted index from which we need to get text nodes containing the words in teh phrase.
	@param openFileIndex is the index in the open files array of the file we are using for querying.
	@param scoreFunction is a function pointer to a function that calculates score of an ancestor given the words that it 
			contains. the words are passed in a n XML format.
	@param ancsDepthThresholdFunction is a function pointer to a function that, given a node's start key and level, returns
			the number of levels upwards to reach and get ancs. for example, if it returns 1, then the parent of a node 
			containing a word is returned only. if it returns -1, then ancestors until the root of the document are returned.
	@param ancsQualifies is a function pointer to a function that, given an ancs score, returns true if teh ancs scored high
			enough. otherwise, retunrs false. this function will be used to filter ancs.
	@param expectedDepth the depth of the XML document.
	@param parentIndexName if there exists an index that links each node with its parent, then pass its name here, otherwise
			pass NULL. having a parent index speeds up the term join because it avoids accessing the database.
	@param bufPoolSize if parentIndex exists, then a buffer pool is used to access the index. 
	@param dataMng an instance of the data manager.
	@param simpleScore if true a simple scoring method is used, it just uses the frequencies of terms. if false, a  ore complex
			scoring method is used where other info of the locations of the terms is used.
	**/
	StackBasedTermJoin(char *phrase, char *indexName,  char openFileIndex, 
                      double (*scoreFunction)(char *elementsInXML, int keywordSet), 
                      int (*ancsDepthThresholdFunction)(KeyType sk, int level, int keywordSet),
                      bool (*ancsQualifies)(double score, int keywordSet),
                      int expectedDepth, char *parentIndexName, int bufPoolSize, NREType assignedNRE, 
                      DataMng *dataMng, bool simpleScore = true, int keywordSet = 0);

	/**
	Destructor.
	releases mem used by output buffer and other arrays and buffers.
	**/
	~StackBasedTermJoin();

	/**
	Access Method
	gets the next output from this iterator.
	@param node is a pointer that well be set to the output buffer or NULL (indicating that
	there are no more results).
	**/
	void next(WitnessTree *&node);


	/**
	Process Method
	converts information associated with a stack node (occurances of terms) into an XML format. for
	the simple scoring case.
	@param sn the stack node that we want to convert its info into XML.
	@param xmlBuffer a buffer where the converted to xml data will reside.
	@param xmlBufferSize is the size of the xml buffer.
	@param wordNum is the number or words in teh phrase used in teh term join.
	@param volumeID is the id of the volume that the system is running on.
	@param fileID is the id of the file that sn belongs to.
	**/
	static void convertToXML(SBTermJoinStackNode *sn, char *&xmlBuffer,
                            int &xmlBufferSize, int wordNum, lvid_t volumeID,serial_t fileID);


	/**
	Process Method
	converts information associated with a stack node (occurances of terms and where they were) into 
	an XML format. for the complex scoring case.
	@param sn the stack node that we want to convert its info into XML.
	@param xmlBuffer a buffer where the converted to xml data will reside.
	@param xmlBufferSize is the size of the xml buffer.
	@param wordNum is the number or words in teh phrase used in teh term join.
	@param volumeID is the id of the volume that the system is running on.
	@param fileID is the id of the file that sn belongs to.
	**/
	static void convertToXMLComplex(SBTermJoinComplexStackNode *sn, char *&xmlBuffer,
                                   int &xmlBufferSize, int wordNum, lvid_t volumeID,serial_t fileID);

private:
	/**
	phrase to find in XML document
	**/
	char *phrase;

	char openFileIndex;
	DataMng *dataMng;

	/**
	inverted index name
	**/
	char *indexName;
	
	/**
	buffer used to hold the output
	**/
	WitnessTree *resultBuffer;

	int expectedDepth;

	/**
	number of words in the phrase
	**/
	int wordNum;

	WitnessTree **inTuple;


	GistIndexAccess **indices;

	NREType assignedNRE;

	bool simpleScore;
	int keywordSet;

	double (*scoreFunction)(char *elementsInXML, int keywordSet);
	int (*ancsDepthThresholdFunction)(KeyType sk, int level, int keywordSet);
	bool (*ancsQualifies)(double score, int keywordSet);

	stack<SBTermJoinStackNode> *ancsStack;
	stack<SBTermJoinComplexStackNode> *complexAncsStack;

	bool pushed;
	ComplexListNode *tempArray;
	int tempSize;
	int tempActualSize;
	char *parentIndexName;

	void GetAndStackAncs(KeyType startKey, char fileIndex,int level);
	void PushNode(ComplexListNode *pushedNode);
	void actualPush();
	int getInputs(int which = -1);
	void doubleArray();
	static void doubleXMLBuffer(char *&xmlBuffer, int &xmlBufferSize);
	int getStackTopLevel();
	int getStackTopOffset();
	KeyType getStackTopSK();
	KeyType getStackTopEK();

	int WriteBufferToItsList(ContainerClass *cont, ShoreList *list);
	int copyDataToTop(SBTermJoinComplexStackNode *sn);
	bool stackIsEmpty();

	void incrementTopCounters(int which, int by = 1);
	int whoseFirst();

	static void readFromList(serial_t head, serial_t tail, char *&xmlBuffer,
	                         int &xmlBufferSize, lvid_t volumeID, serial_t fileID);

	static void readFromBuffer(ContainerClass *c, char *&xmlBuffer,
                              int &xmlBufferSize, lvid_t volumeID, serial_t fileID);

	static void accomodate(char *str, char *&xmlBuffer, int &xmlBufferSize);
	int addNodeToTop(int index);
	int popStackIfNeeded(KeyType sk = DBL_MAX);
	int first;
	bool outputtingStack;
	int res;
	char *xmlBuffer;
	int xmlBufferSize;
	serial_t startID;
	lvid_t volumeID;
	serial_t fileID;
	rc_t rc;
	ContainerClass *readBuffer;
	HashIndexAccess *parentIndex;
	KeyType lastSK;
	bool errorFound;
	bool fileCreated;
	int getAncs(KeyType sk, char fileIndex, ComplexListNode &ancs);
	int numWrites;
};

#endif

