
#include "parse.hpp"

char QueryEvaluationTreeValueSortNode::getIdentifier(void) { return 'r'; }

char ValueSortPlanParser::getIteratorIdentifier(void) { return 'r'; }

void 
ValueSortPlanParser::getQueryEvalNode(EvaluatorClass* evaluator, char* line, void* queryInput, QueryEvaluationTreeNode*& curr)
	    {
		char *token = strtok(line+2,",");                    
		if (token == NULL)
		{
		    globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"Evaluator",__FILE__,"Error input from file... expecting expected size... ValSort line...");
		    curr=NULL; return;
		}
		int exSize = atoi(token);

		token = strtok(NULL,",");
		if (token == NULL)
		{
		    globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"Evaluator",__FILE__,"Error input from file... expecting num... ValSort line...");
		    curr=NULL; return;
		}
		int num = atoi(token);
		int i = 0;


		int *sortBy;
		NREType *nre;
		char **attrName;
		int *orderBy;
		int *whereEmptyGoes;
		if (num > 0)
		{
		    sortBy = new int[num];
		    nre = new NREType[num];
		    attrName= new char *[num];
		    orderBy = new int[num];
		    whereEmptyGoes = new int[num];
		}
		else
		{
		    sortBy = NULL;
		    nre = NULL;
		    attrName= NULL;
		    orderBy = NULL;
		    whereEmptyGoes = NULL;
		    globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"Evaluator",__FILE__,"Error input from file... num needs to be at least 1... ValSort line...");
		    curr=NULL; return;
		}
		for (i=0; i<num; i++)
		{
		    token = strtok(NULL,",");
		    if (token == NULL)
		    {
			globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"Evaluator",__FILE__,"Error input from file... expecting sort by what... ValSort line...");
			curr=NULL; return;
		    }
		    if (strcmp(token,"AN") == 0)
			sortBy[i] = SORTBY_ATTRIBUTE_NUM;
		    else if (strcmp(token,"AS") == 0)
			sortBy[i] = SORTBY_ATTRIBUTE_STR;
		    else if (strcmp(token,"TN") == 0)
			sortBy[i] = SORTBY_TEXT_NUM;
		    else if (strcmp(token,"TS") == 0)
			sortBy[i] = SORTBY_TEXT_STR;
		    else if (strcmp(token,"TG") == 0)
			sortBy[i] = SORTBY_TAGNAME;
		    else if (strcmp(token,"VN") == 0)
			sortBy[i] = SORTBY_VALUE_NUM;
		    else if (strcmp(token,"SK") == 0)
			sortBy[i] = SORT_BY_START_KEY;
		    else if (strcmp(token,"VS") == 0)
			sortBy[i] = SORTBY_VALUE_STR;
		    else if (strcmp(token,"AK") == 0)
			sortBy[i] = SORTBY_ATTRIBUTE_KEY;
		    else
		    {
			globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"Evaluator",__FILE__,"Error input from file... unrecognized sort by what... ValSort line...");
			delete [] sortBy;
			delete [] nre;
			for (int j=0; j<i; j++)
			    if (attrName[j]) delete [] attrName[j];
			delete [] attrName;
			delete [] orderBy ;
			delete [] whereEmptyGoes;
			curr=NULL; return;
		    }

		    token = strtok(NULL,",");
		    if (token == NULL)
		    {
			globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"Evaluator",__FILE__,"Expecting NRE in ValSort line.");
			delete [] sortBy;
			delete [] nre;
			for (int j=0; j<i; j++)
			    if (attrName[j]) delete [] attrName[j];
			delete [] attrName;
			delete [] orderBy ;
			delete [] whereEmptyGoes;				
			curr=NULL; return;
		    }
		    nre[i] = (NREType)atoi(token);

		    if (nre[i] < 1)
		    {
			globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"Evaluator",__FILE__,"NRE should be positive.");
			delete [] sortBy;
			delete [] nre;
			for (int j=0; j<i; j++)
			    if (attrName[j]) delete [] attrName[j];
			delete [] attrName;
			delete [] orderBy ;
			delete [] whereEmptyGoes;		
			curr=NULL; return;
		    }
		    if (nre[i] > evaluator->maxNRE)
			evaluator->maxNRE = nre[i];
		    token = strtok(NULL,",");
		    if (token == NULL)
		    {
			globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"Evaluator",__FILE__,"Error input from file... expecting orderBy... ValSort line...");
			delete [] sortBy;
			delete [] nre;
			for (int j=0; j<i; j++)
			    if (attrName[j]) delete [] attrName[j];
			delete [] attrName;
			delete [] orderBy ;
			delete [] whereEmptyGoes;               
			curr=NULL; return;
		    }

		    if (strcmp(token,"A") == 0)
			orderBy[i] = ASCENDING;
		    else if (strcmp(token,"D") == 0)
			orderBy[i] = DESCENDING;
		    else
		    {
			globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"Evaluator",__FILE__,"Error input from file... unrecognized order... ValSort line...");
			delete [] sortBy;
			delete [] nre;
			for (int j=0; j<i; j++)
			    if (attrName[j]) delete [] attrName[j];
			delete [] attrName;
			delete [] orderBy ;
			delete [] whereEmptyGoes;
			curr=NULL; return;
		    }
		    token = strtok(NULL,",");
		    if (token == NULL)
		    {
			globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"Evaluator",__FILE__,"Error input from file... expecting attrName... ValSort line...");
			delete [] sortBy;
			delete [] nre;
			for (int j=0; j<i; j++)
			    if (attrName[j]) delete [] attrName[j];
			delete [] attrName;
			delete [] orderBy ;
			delete [] whereEmptyGoes;
			curr=NULL; return;
		    }

		    /*		if (strcmp(token,"NULL") == 0)
				attrName[i] = NULL;
				else
				{*/
		    attrName[i] = new char[strlen(token)+1];
		    strcpy(attrName[i],token);
		    //	}
		    token = strtok(NULL,",");
		    if (token == NULL)
		    {
			globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"Evaluator",__FILE__,"Error input from file... expecting whereEmptyGoes... ValSort line...");
			delete [] sortBy;
			delete [] nre;
			for (int j=0; j<=i; j++)
			    if (attrName[j]) delete [] attrName[j];
			delete [] attrName;
			delete [] orderBy ;
			delete [] whereEmptyGoes;				
			curr=NULL; return;
		    }
		    if (strcmp(token,"B") == 0)
			whereEmptyGoes[i] = EMPTY_AT_BEGINNING;
		    else if (strcmp(token,"E") == 0)
			whereEmptyGoes[i] = EMPTY_AT_END;
		    else
		    {
			//FIX THIS after talking to Melanie. she outputs L instead of E for end.
			//currently, we will accept it
			whereEmptyGoes[i] = EMPTY_AT_END;
			/*	globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"Evaluator",__FILE__,"Error input from file... unrecognized where empty goes... ValSort line...");
				delete [] sortBy;
				delete [] nre;
				for (int j=0; j<i; j++)
				if (attrName[j]) delete [] attrName[j];
				delete [] attrName;
				delete [] orderBy ;
				delete [] whereEmptyGoes;
				curr=NULL; return;*/
		    }
		}

		bool ext = false;
		token = strtok(NULL,",");
		if (token != NULL)
		{
		    if (strcmp(token,"X") == 0)
			ext = true;
		}
		char newLine[MAX_FILE_INTERFACE_LINE_SIZE];
		if (((std::iostream *)queryInput)->eof() == 0)
		    ((std::iostream *)queryInput)->getline(newLine,MAX_FILE_INTERFACE_LINE_SIZE);
		else
		{
		    globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"Evaluator",__FILE__,"Unexpected end of file... valSort line...");
		    delete [] sortBy;
		    delete [] nre;
		    for (int j=0; j<i; j++)
			if (attrName[j]) delete [] attrName[j];
		    delete [] attrName;
		    delete [] orderBy ;
		    delete [] whereEmptyGoes;
		    curr=NULL; return;
		}
		QueryEvaluationTreeNode *oper = evaluator->getQueryEvalNode(newLine,queryInput);
		if (oper == NULL)
		{
		    globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"Evaluator",__FILE__,"Unexpected operand returned... valSort line...");
		    delete [] sortBy;
		    delete [] nre;
		    for (int j=0; j<i; j++)
			if (attrName[j]) delete [] attrName[j];
		    delete [] attrName;
		    delete [] orderBy ;
		    delete [] whereEmptyGoes;
		    curr=NULL; return;
		}
		curr = new QueryEvaluationTreeValueSortNode(exSize,num,sortBy,nre,attrName,orderBy, oper, whereEmptyGoes,ext);
		if (ext)
		    evaluator->fileIDsArraySize++;
	    }

