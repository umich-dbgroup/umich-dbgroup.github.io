/*
COPYRIGHT  � 2000-2004 
THE REGENTS OF THE UNIVERSITY OF MICHIGAN
ALL RIGHTS RESERVED

PERMISSION IS GRANTED TO USE, COPY, CREATE DERIVATIVE WORKS AND REDISTRIBUTE THIS SOFTWARE AND SUCH DERIVATIVE WORKS FOR 
NONCOMMERCIAL EDUCATION AND RESEARCH PURPOSES, SO LONG AS NO FEE IS CHARGED, AND SO LONG AS THE COPYRIGHT NOTICE ABOVE, 
THIS GRANT OF PERMISSION, AND THE DISCLAIMER BELOW APPEAR IN ALL COPIES MADE; AND SO LONG AS THE NAME OF THE UNIVERSITY 
OF MICHIGAN IS NOT USED IN ANY ADVERTISING OR PUBLICITY PERTAINING TO THE USE OR DISTRIBUTION OF THIS SOFTWARE WITHOUT 
SPECIFIC, WRITTEN PRIOR AUTHORIZATION.

THIS SOFTWARE IS PROVIDED AS IS, WITHOUT REPRESENTATION FROM THE UNIVERSITY OF MICHIGAN AS TO ITS FITNESS FOR ANY PURPOSE, 
AND WITHOUT WARRANTY BY THE UNIVERSITY OF MICHIGAN OF ANY KIND, EITHER EXPRESS OR IMPLIED, INCLUDING WITHOUT LIMITATION THE 
IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE. THE REGENTS OF THE UNIVERSITY OF MICHIGAN SHALL 
NOT BE LIABLE FOR ANY DAMAGES, INCLUDING SPECIAL, INDIRECT, INCIDENTAL, OR CONSEQUENTIAL DAMAGES, WITH RESPECT TO ANY CLAIM 
ARISING OUT OF OR IN CONNECTION WITH THE USE OF THE SOFTWARE, EVEN IF IT HAS BEEN OR IS HEREAFTER ADVISED OF THE POSSIBILITY 
OF SUCH DAMAGES.
*/

#include "ExternalValueSortIterator.h"
#include "../StructuralJoin/SBJoinAncsStackNode.h"
#include "../../Evaluator/Evaluator_definitions.h"
#include <math.h>

//debugging
int numMergePass;
//debugging end
DataMng *gdataMngValX;

NREType *gNREValX;
char **gAttrNameValX;
int *gOrderValX;
int *gSortByValX;
int gNumValX;
int *gWhereEmptyGoesValX;

int compareNodesValSortX(const void *elem1,const void *elem2)
{
	for (int i=0; i<gNumValX; i++)
	{
		int index1 = ((WitnessTree *)elem1)->getIndexOfNRE(gNREValX[i]);
		int index2 = ((WitnessTree *)elem2)->getIndexOfNRE(gNREValX[i]);
		if (index1 == FAILURE && index2 == FAILURE)
			continue;
		if (index1 == FAILURE)
			return (-1*gWhereEmptyGoesValX[i]);
		if (index2 == FAILURE)
			return (gWhereEmptyGoesValX[i]);

		FileIDType fileid1 = EvaluatorClass::getFileID(((ComplexListNode *)((WitnessTree *)elem1)->getNodeByIndex(index1))->getFileIndex());
		if (fileid1 == -1)
			return -1;
		FileIDType fileid2 = EvaluatorClass::getFileID(((ComplexListNode *)((WitnessTree *)elem2)->getNodeByIndex(index2))->getFileIndex());
		if (fileid2 == -1)
			return -1;

		switch (gSortByValX[i])
		{
		case SORTBY_TEXT_NUM:
		case SORTBY_TEXT_STR:
			{
				int res1 = EvaluatorClass::GetText((WitnessTree *)elem1,index1,gdataMngValX,fileid1);
				int res2 = EvaluatorClass::GetText((WitnessTree *)elem2,index2,gdataMngValX,fileid2);
				if ((res1 == FAILURE || res1 == 0) && (res2 == FAILURE || res2 == 0))
					continue;
				if (res1 == FAILURE || res1 == 0)
				{
					//((WitnessTree *)elem2)->deleteNode(res2); //???delete for what?
					return (-1*gWhereEmptyGoesValX[i]);
				}

				if (res2 == FAILURE || res2 == 0)
				{
					//((WitnessTree *)elem1)->deleteNode(res1);
					return (gWhereEmptyGoesValX[i]);
				}
				char *txt1 = ((DM_CharNode *)((ComplexListNode *)((WitnessTree *)elem1)->getNodeByIndex(res1))->GetData())->getCharValue();
				char *txt2 = ((DM_CharNode *)((ComplexListNode *)((WitnessTree *)elem2)->getNodeByIndex(res2))->GetData())->getCharValue();

				//((WitnessTree *)elem1)->deleteNode(res1);
				//((WitnessTree *)elem2)->deleteNode(res2);
				if (gSortByValX[i] == SORTBY_TEXT_NUM)
				{
					double num1 = atof(txt1);
					double num2 = atof(txt2);
					if (num1 == num2)
						continue;
					else
						return (int)(gOrderValX[i]* ceil(num1 - num2));
				}
				else
				{
					int r = strcmp(txt1,txt2);
					if (r == 0)
						continue;
					else
						return gOrderValX[i]*r;
				}
			}
			break;
		case SORTBY_ATTRIBUTE_NUM:
		case SORTBY_ATTRIBUTE_STR:
			{
				int res1 = EvaluatorClass::GetAttributes((WitnessTree *)elem1,index1,gdataMngValX,fileid1);
				int res2 = EvaluatorClass::GetAttributes((WitnessTree *)elem2,index2,gdataMngValX,fileid2);
				if (res1 == FAILURE && res2 == FAILURE)
					continue;
				if (res1 == FAILURE)
				{
					//((WitnessTree *)elem2)->deleteNode(res2);
					return (-1*gWhereEmptyGoesValX[i]);
				}

				if (res2 == FAILURE)
				{
					//((WitnessTree *)elem1)->deleteNode(res1);
					return (gWhereEmptyGoesValX[i]);
				}
				
				Value *val1 = ((DM_AttributeNode *)((ComplexListNode *)((WitnessTree *)elem1)->getNodeByIndex(index1+1))->GetData())->getAttr(gAttrNameValX[i]);
				Value *val2 = ((DM_AttributeNode *)((ComplexListNode *)((WitnessTree *)elem2)->getNodeByIndex(index2+1))->GetData())->getAttr(gAttrNameValX[i]);
			
				//((WitnessTree *)elem1)->deleteNode(res1);
				//((WitnessTree *)elem2)->deleteNode(res2);

				if (!val1 && !val2) 
					continue;
				
				if (!val1)
					return (-1*gWhereEmptyGoesValX[i]);
				if (!val2)
					return (gWhereEmptyGoesValX[i]);

				char *txt1 = val1->getStrValue();
				char *txt2 = val2->getStrValue();
				if (gSortByValX[i] == SORTBY_ATTRIBUTE_NUM)
				{
					double num1 = atof(txt1);
					double num2 = atof(txt2);
					if (num1 == num2)
						continue;
					else
						return (int)(gOrderValX[i]* ceil(num1 - num2));
				}
				else
				{
					int r = strcmp(txt1,txt2);
					if (r == 0)
						continue;
					else
						return gOrderValX[i]*r;
				}
			}
			break;
		case SORTBY_TAGNAME:
			{
				ComplexListNode *n1 = (ComplexListNode *)((WitnessTree *)elem1)->getNodeByIndex(index1);
				ComplexListNode *n2 = (ComplexListNode *)((WitnessTree *)elem2)->getNodeByIndex(index2);
				DM_DataNode *dn1 = n1->GetData();
				DM_DataNode *dn2 = n2->GetData();
				if (dn1 == NULL && dn2 == NULL)
					continue;
				if (dn1 == NULL)
					return -1*gWhereEmptyGoesValX[i];
				
				if (dn2 == NULL)
					return gWhereEmptyGoesValX[i];
				
				if (dn1->getFlag() != ELEMENT_NODE && dn2->getFlag() != ELEMENT_NODE)
					continue;
				
				if (dn1->getFlag() != ELEMENT_NODE)
					return (-1*gWhereEmptyGoesValX[i]);

				if (dn2->getFlag() != ELEMENT_NODE)
					return (gWhereEmptyGoesValX[i]);
				if (((DM_ElementNode *)dn1)->getTag() == ((DM_ElementNode *)dn2)->getTag())
					continue;

				char *tag1 = gdataMngValX->getPhysicalDataMng()->getXMLNameTable()->getNameByCode(((DM_ElementNode *)dn1)->getTag());
				char *tag2 = gdataMngValX->getPhysicalDataMng()->getXMLNameTable()->getNameByCode(((DM_ElementNode *)dn2)->getTag());
				int r = strcmp(tag1, tag2);
				if (r == 0)
					continue;
				else
					return gOrderValX[i] * r;
			}
			break;
		case SORTBY_VALUE_NUM:
		case SORTBY_VALUE_STR:
			{
				DM_DataNode *dn1 = ((ComplexListNode *)((WitnessTree *)elem1)->getNodeByIndex(index1))->GetData();
				DM_DataNode *dn2 = ((ComplexListNode *)((WitnessTree *)elem2)->getNodeByIndex(index2))->GetData();
				if (dn1 == NULL && dn2 == NULL)
					continue;
				if (dn1 == NULL)
					return -1*gWhereEmptyGoesValX[i];
				
				if (dn2 == NULL)
					return gWhereEmptyGoesValX[i];

				char *txt1;
				char *txt2;
				Value *val1;
				Value *val2;
				if (dn1->getFlag() == ELEMENT_NODE)
					txt1 = gdataMngValX->getPhysicalDataMng()->getXMLNameTable()->getNameByCode(((DM_ElementNode *)dn1)->getTag());
				else if (dn1->getFlag() == DOCUMENT_NODE)
				{
					if (((DM_DocumentNode *)dn1)->getXMLFileName())
						txt1 = ((DM_DocumentNode *)dn1)->getXMLFileName();
					else
						txt1 = NULL;
				}
				else if (dn1->getFlag() == ATTRIBUTE_NODE)
				{
					//if attribute node, return the value of attribute "attrName"
					
					val1 = ((DM_AttributeNode *)dn1)->getAttr(gAttrNameValX[i]);
					if (val1 != NULL)
					{
						if (val1->getStrValue() != NULL && strlen(val1->getStrValue()) != 0)
							txt1 = val1->getStrValue();
						else
							txt1 = NULL;
					}
					else
						txt1 = NULL;
				} 
				else
				{
					//if text node, return the text value
					if (((DM_CharNode *)dn1)->getCharValue())
						txt1 = ((DM_CharNode *)dn1)->getCharValue();
					else
						txt1 = NULL;
				}

				//getting second vLUES
				if (dn2->getFlag() == ELEMENT_NODE)
					txt2 = gdataMngValX->getPhysicalDataMng()->getXMLNameTable()->getNameByCode(((DM_ElementNode *)dn2)->getTag());
				else if (dn2->getFlag() == DOCUMENT_NODE)
				{
					if (((DM_DocumentNode *)dn2)->getXMLFileName())
						txt2 = ((DM_DocumentNode *)dn2)->getXMLFileName();
					else
						txt2 = NULL;
				}
				else if (dn2->getFlag() == ATTRIBUTE_NODE)
				{
					//if attribute node, return the value of attribute "attrName"
					
					val2 = ((DM_AttributeNode *)dn2)->getAttr(gAttrNameValX[i]);
					if (val2 != NULL)
					{
						if (val2->getStrValue() != NULL && strlen(val2->getStrValue()) != 0)
							txt2 = val2->getStrValue();
						else
							txt2 = NULL;
					}
					else
						txt2 = NULL;
				} 
				else
				{
					//if text node, return the text value
					if (((DM_CharNode *)dn2)->getCharValue())
						txt2 = ((DM_CharNode *)dn2)->getCharValue();
					else
						txt2 = NULL;
				}
				if (!txt1 && !txt2) 
					continue;
				
				if (!txt1)
					return (-1*gWhereEmptyGoesValX[i]);
				if (!txt2)
					return (gWhereEmptyGoesValX[i]);

				if (gSortByValX[i] == SORTBY_VALUE_NUM)
				{
					double num1 = atof(txt1);
					double num2 = atof(txt2);
					if (num1 == num2)
						continue;
					else
						return (int)(gOrderValX[i]* ceil(num1 - num2));
				}
				else
				{
					int r = strcmp(txt1,txt2);
					if (r == 0)
						continue;
					else
						return gOrderValX[i]*r;
				}

			}
			break;
			case SORT_BY_START_KEY:
				{
					KeyType sk1 = ((ComplexListNode *)((WitnessTree *)elem1)->getNodeByIndex(index1))->GetStartPos();
					KeyType sk2 = ((ComplexListNode *)((WitnessTree *)elem2)->getNodeByIndex(index2))->GetStartPos();
					if (sk1 == sk2)
						continue;
					else
					{
						if (sk1 < sk2)
							return (-1*gOrderValX[i]);
						else
							return (gOrderValX[i]);
					}
				}
				break;
			case SORTBY_ATTRIBUTE_KEY:
			{
				ComplexListNode *n1 = (ComplexListNode *)((WitnessTree *)elem1)->getNodeByIndex(index1);
				ComplexListNode *n2 = (ComplexListNode *)((WitnessTree *)elem2)->getNodeByIndex(index2);
				DM_DataNode *dn1 = n1->GetData();
				DM_DataNode *dn2 = n2->GetData();
				
				if (dn1 == NULL && dn2 == NULL)
					continue;
				if (dn1 == NULL)
					return -1*gWhereEmptyGoesValX[i];
				
				if (dn2 == NULL)
					return gWhereEmptyGoesValX[i];
				
				if (dn1->getFlag() != ELEMENT_NODE && dn2->getFlag() != ELEMENT_NODE)
					continue;
				
				if (dn1->getFlag() != ELEMENT_NODE)
					return (-1*gWhereEmptyGoesValX[i]);

				if (dn2->getFlag() != ELEMENT_NODE)
					return (gWhereEmptyGoesValX[i]);

				KeyType ak1 = ((DM_ElementNode*)dn1)->getAttributes();
				KeyType ak2 = ((DM_ElementNode*)dn2)->getAttributes();
				if (ak1 == 0 && ak2 == 0)
					continue;
				if (ak1 == 0)
					return -1*gWhereEmptyGoesValX[i];
				
				if (ak2 == 0)
					return gWhereEmptyGoesValX[i];

				if (ak1 == ak2)
						continue;
				else
					{
						if (ak1 < ak2)
							return (-1*gOrderValX[i]);
						else
							return (gOrderValX[i]);
					}
			}
			break;
		}
	}
	int n = ((WitnessTree *)elem1)->length() < ((WitnessTree *)elem2)->length()?
		((WitnessTree *)elem1)->length() : ((WitnessTree *)elem2)->length();
	for (int i=0; i<n; i++)
	{
		if (((ComplexListNode *)((WitnessTree *)elem1)->findNode(i))->GetStartPos() ==
			((ComplexListNode *)((WitnessTree *)elem2)->findNode(i))->GetStartPos())
			continue;
		else
		{
			if (((ComplexListNode *)((WitnessTree *)elem1)->findNode(i))->GetStartPos() <
				((ComplexListNode *)((WitnessTree *)elem2)->findNode(i))->GetStartPos())
				return -1;
			else
				return 1;
		}
	}
	if (((WitnessTree *)elem1)->length() < ((WitnessTree *)elem2)->length())
		return -1;
	else if (((WitnessTree *)elem1)->length() > ((WitnessTree *)elem2)->length())
		return 1;
	return 0;
}
ExternalValueSortIterator::ExternalValueSortIterator(IteratorClass *input, int num, int *sortBy,  
									NREType *nre, char **attrName, int *order, DataMng *dataMng, int *whereEmptyGoes
									, serial_t fileID, serial_t startID,int numWrites,
									bool fromCube)
{	
	numMergePass = 0; //debugging
	inMemSort = false;
	numCont = 0;
	allNull = false;
	numContIn = gSettings->getIntegerValue("EX_SORT_NUM_OF_CONTAINERS",EX_SORT_DEFAULT_NUM_CONT);
	if (numContIn < EX_SORT_DEFAULT_NUM_CONT)
		numContIn = EX_SORT_DEFAULT_NUM_CONT;
	cont = new ContainerClass[numContIn];

	res = new int[numContIn];
	inTree = new WitnessTree[numContIn];
	sortListsNum = 0;
	currSortList = 0;
	nextEmptySortList = 0;
	fileCreated = true;
	this->sortListsCap = gSettings->getIntegerValue("INITIAL_SORT_LISTS_NUM",INITIAL_SORT_LISTS_NUM_DEFAULT);
	this->input = input;
	this->dataMng = dataMng;
	this->num = num;
	this->nre= nre;
	this->order = order;
	this->sortByWhat = sortBy;
	this->attrName = attrName;
	this->volumeID = dataMng->getVolumeID();
	this->whereEmptyGoes = whereEmptyGoes;
	this->fileID = fileID;
	this->startID = startID;
	this->numWrites = numWrites;
	this->fromCube = fromCube;
	this->totsize = 0;

	gdataMngValX = this->dataMng;

	gNREValX = this->nre;
	gAttrNameValX = this->attrName;
	gOrderValX = this->order;
	gSortByValX = this->sortByWhat;
	gNumValX = this->num;
	gWhereEmptyGoesValX = this->whereEmptyGoes;

//	numWrites = 0;
	this->sortArray = NULL;
	this->sortLists = NULL;

	resultBuffer = new WitnessTree;

	buildSortArray();

	if (readInputIntoLists() == FAILURE)
		allNull = true;
	else
	{
		if (inMemSort)
			allNull = !readTreesFromContainers();
		else
		{
			if (sortTheLists() == FAILURE)
				allNull = true;
			else
			{
				//we have sortListsNum lists left for a final merge
				allNull = true;
				for (int i = 0 ; i < sortListsNum; i++){
					sortLists[i].StartScan();
					res[i] = sortLists[i].GetNext(&cont[i]);
					if (res[i] == SUCCESS)
						res[i] = readWitnessTreeFromContainer(&inTree[i], &cont[i]);

					if (res[i] == SUCCESS)
						allNull = false;

				}
				numContIn = sortListsNum;
				
			}
		}
	}
	cout << "It takes " << numMergePass+1 << " passes." << endl;
}

ExternalValueSortIterator::~ExternalValueSortIterator()
{
	delete resultBuffer;

	if (sortArray) delete [] sortArray;
	if (input && (!fromCube)) delete input;

	delete [] cont;

	delete [] res;
	delete [] inTree;

	if (order) delete [] order;
	if (nre) delete [] nre;
	if (sortByWhat) delete [] sortByWhat;
	if (whereEmptyGoes) delete [] whereEmptyGoes;
	if (attrName)
	{
		for (int i=0; i< num; i++)
			if (attrName[i])
				delete [] attrName[i];
		delete [] attrName;
	}

//	if (sortArray) delete [] sortArray;

	if (sortLists)
		delete [] sortLists;
	if (fileCreated)
	{
		//	cout<<"destroy file ID: "<<fileID<<endl;
		rc = ss_m::destroy_file(volumeID, fileID,true, numWrites);
		if (rc) 
		{
			stringstream msg;
			msg<<rc<<'\0';
			globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"Evaluator",__FILE__,msg.rdbuf()->str().c_str());
			return;				
		}
	}
}


void ExternalValueSortIterator::next(WitnessTree *&node)
{
#ifdef EVAL_TIME_OUT
	clock_t currTime = clock();
	double queryDuration = (double)(currTime - gQueryStartTime) / CLOCKS_PER_SEC;
	if (queryDuration >= gTimeOutAfter)
	{
		globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"Evaluator",__FILE__,"Query Timed Out.");
		node = NULL;
		return;
	}
#endif
	if (mergeAndOutputContainers() == SUCCESS)
	{
		node = resultBuffer;
		return;
	}
	node = NULL;
}

int ExternalValueSortIterator::readInputIntoLists()
{
	clock_t starttime, finishtime; 
	double duration;
	starttime = clock();

	
	input->next(inTuple);

	treeNodeSz = sizeof(ComplexListNode);
	if (!inTuple)
		return FAILURE;

	int numEntries;
	WitnessTree temp;

	while (inTuple)
	{
		clock_t starttime1, finishtime1; 
		double duration1;
		starttime1 = clock();


		for (int i=0; i<numContIn; i++)
		{
			numEntries = 0;

			int potSize = 0;
			int contCap = cont[i].GetSize();
			//retrieve all nodes to be compared by
			getAllNodesToCompare(inTuple);
			while (inTuple && potSize + treeSize(inTuple) < contCap)
			{
				potSize += treeSize(inTuple);
				sortArray[numEntries].switchToComplex(dataMng);
				sortArray[numEntries].copyTree(inTuple);
				numEntries++;
				this->totsize++;
				input->next(inTuple);
				if (inTuple){
					getAllNodesToCompare(inTuple);
				}
			}

			if (!inTuple)
			{
				if (globalErrorInfo.doWeHaveAProblem())
					return FAILURE;
			}
			if (numEntries == 0 && inTuple)
			{
				stringstream msg;
				int maxSz = 0;
				while (inTuple)
				{
					int currSz = treeSize(inTuple);
					if (currSz > maxSz)
						maxSz = currSz;
					input->next(inTuple);
				}
				maxSz++;
				msg<<"A container cannot accomodate 1 witness tree... increase CONTAINER_SIZE parameter in settings file "<<
					"to at least "<<maxSz<<"..."<<'\0';
				globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"Evaluator",__FILE__,msg.rdbuf()->str().c_str());
				return FAILURE; 
			}

			if (sortTheArray(numEntries) == FAILURE)
				return FAILURE;
			if (writeArrayIntoContainer(&cont[i], numEntries) == FAILURE)
				return FAILURE;
			if (!inTuple)
				break;
#ifdef EVAL_TIME_OUT
			clock_t currTime = clock();
			double queryDuration = (double)(currTime - gQueryStartTime) / CLOCKS_PER_SEC;
			if (queryDuration >= gTimeOutAfter)
			{
				globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"Evaluator",__FILE__,"Query Timed Out.");
				return FAILURE;
			}
#endif
		}
		if (!inTuple && numCont <= numContIn)
			inMemSort = true;
		else
		{
			if (mergeContainers() == FAILURE)
				return FAILURE;
		}
		finishtime1 = clock();
	duration1 = (double)(finishtime1 - starttime1) / CLOCKS_PER_SEC;
	//cout << duration1 << " seconds to compute 1 round of writing to a list" << endl;
	}

	if (globalErrorInfo.doWeHaveAProblem())
		return FAILURE;

	if (!fromCube) {
		delete input;
		input = NULL;
	}
	delete [] sortArray;
	sortArray = NULL;
	finishtime = clock();
	duration = (double)(finishtime - starttime) / CLOCKS_PER_SEC;
	cout << duration << " seconds to readinputintoLists " << endl;
	return SUCCESS;
}

int ExternalValueSortIterator::sortTheLists()
{
	while (sortListsNum > numContIn) //change from 2 to numContIn, real fanout
	{
		while (currSortList < sortListsNum)
		{
			if (mergeLists(currSortList) == FAILURE)
				return FAILURE;
			currSortList += numContIn;
		}
		sortListsNum = nextEmptySortList;
		currSortList = 0;
		nextEmptySortList = 0;
#ifdef EVAL_TIME_OUT
	clock_t currTime = clock();
	double queryDuration = (double)(currTime - gQueryStartTime) / CLOCKS_PER_SEC;
	if (queryDuration >= gTimeOutAfter)
	{
		globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"Evaluator",__FILE__,"Query Timed Out.");
		return FAILURE;
	}
#endif
	}
	return SUCCESS;
}

int ExternalValueSortIterator::mergeLists(int which)
{
	if (which == sortListsNum-1)
		//we have odd number of lists
	{
		sortLists[nextEmptySortList] = sortLists[which];
		nextEmptySortList++;
		return SUCCESS;
	}
allNull = true;
	for (int i=which; i<which+numContIn; i++)
	{
		if (i >= sortListsNum)
		{
			res[i-which] = FAILURE;
			continue;
		}
		if (sortLists[i].IsEmpty())
		{
			res[i-which] = FAILURE;
			continue;
		}

		clock_t starttime, finishtime; 
		double duration;
		starttime = clock();
		sortLists[i].StartScan();

		res[i-which] = sortLists[i].GetNext(&cont[i-which]);
		finishtime = clock();
		duration = (double)(finishtime - starttime) / CLOCKS_PER_SEC;
		//cout << duration << " seconds to retrieve one contatiner from shore list" << endl;

		if (res[i-which] == SUCCESS)
		{
			res[i-which] = readWitnessTreeFromContainer(&inTree[i-which], &cont[i-which]);
			//inTree[i-which].dumpBuffer(stdout, true);
			allNull = false;
		}
	}
	
	ShoreList tmpList;
	tmpList.SetFileID(fileID);
	tmpList.SetVolumeID(volumeID);

	while (!allNull)
	{
		int first = whoseFirst();
		if (first == FAILURE)
			return FAILURE;
		
		//inTree[first].dumpBuffer(stdout, true);
		
		if (writeWitnessTreeIntoContainer(&inTree[first],&outCont) == FAILURE)
		{
			if (writeContainerToList(&outCont,&tmpList) == FAILURE)
				return FAILURE;
			writeWitnessTreeIntoContainer(&inTree[first],&outCont);
		}
		res[first] = readWitnessTreeFromContainer(&inTree[first], &cont[first]);
		if (res[first] == FAILURE)
		{
			res[first] = sortLists[which+first].GetNext(&cont[first]);
			if (res[first] == SUCCESS)
				res[first] = readWitnessTreeFromContainer(&inTree[first], &cont[first]);
		}

		allNull = !atLeastOneSuccess();
	}

	if (!outCont.IsEmpty())
	{
		if (writeContainerToList(&outCont,&tmpList) == FAILURE)
			return FAILURE;
	}
	sortLists[nextEmptySortList] = tmpList;
	nextEmptySortList++;
	numMergePass++; //debugging
	return SUCCESS;
}

int ExternalValueSortIterator::writeArrayIntoContainer(ContainerClass *cont, int numEntries)
{
	cont->Initialize();
if (numEntries > 0)
		numCont++;

	for (int i=0; i < numEntries; i++)
		if (writeWitnessTreeIntoContainer(&sortArray[i],cont) == FAILURE){
			cout << "FAIL at writing into container array allocated" << endl;
			return FAILURE;
		}

}

int ExternalValueSortIterator::sortTheArray(int numEntries)
{
	if (numEntries == 0)
		return SUCCESS;
	
	EvalQuickSort s;
	//qsort(sortArray,numEntries,sizeof(WitnessTree),compareNodesValSortX);
	if (s.quickSort(sortArray,0,numEntries-1,compareNodesValSortX) == FAILURE)
		return FAILURE;
	return SUCCESS;
}

bool ExternalValueSortIterator::readTreesFromContainers()
{
	bool atLeastOne = false;
	for (int i=0; i<numContIn; i++)
	{
		res[i] = readWitnessTreeFromContainer(&inTree[i], &cont[i]);
		if (res[i] == SUCCESS)
			atLeastOne = true;
	}
	return atLeastOne;
}

bool ExternalValueSortIterator::atLeastOneSuccess()
{
	for (int i=0; i<numContIn; i++)
		if (res[i] == SUCCESS)
			return true;
	return false;
}

int ExternalValueSortIterator::mergeContainers()
{
	if (sortListsNum == 0)
		sortLists = new ShoreList[sortListsCap];
	else if (sortListsNum == sortListsCap)
	{
		sortListsCap *= 2;
		ShoreList *tmp = sortLists;
		sortLists = new ShoreList[sortListsCap];
		memcpy(sortLists,tmp,sortListsNum*sizeof(ShoreList));
		delete [] tmp;
	}

	bool atLeastOne  = readTreesFromContainers();

	while (atLeastOne)
	{
		int first = whoseFirst();

		if (first == FAILURE)
			return FAILURE;

		//inTree[first].dumpBuffer(stdout, true);

		if (writeWitnessTreeIntoContainer(&inTree[first],&outCont) == FAILURE)
		{
			if (writeContainerToList(&outCont,&sortLists[sortListsNum]) == FAILURE)
				return FAILURE;
			writeWitnessTreeIntoContainer(&inTree[first],&outCont);
		}
		res[first] = readWitnessTreeFromContainer(&inTree[first],&cont[first]);
		//inTree[first].dumpBuffer(stdout, true);
		atLeastOne = atLeastOneSuccess();
#ifdef EVAL_TIME_OUT
	clock_t currTime = clock();
	double queryDuration = (double)(currTime - gQueryStartTime) / CLOCKS_PER_SEC;
	if (queryDuration >= gTimeOutAfter)
	{
		globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"Evaluator",__FILE__,"Query Timed Out.");
		return FAILURE;
	}
#endif
	}

	if (!outCont.IsEmpty())
	{
		if (writeContainerToList(&outCont,&sortLists[sortListsNum]) == FAILURE)
			return FAILURE;
	}
	sortListsNum++;
	return SUCCESS;
}

int ExternalValueSortIterator::mergeAndOutputContainers()
{
	if (!allNull)
	{
		int first = whoseFirst();
		if (first == FAILURE)
			return FAILURE;
		
		resultBuffer->copyTree(&inTree[first]);
		res[first] = readWitnessTreeFromContainer(&inTree[first], &cont[first]);
		if (!inMemSort && res[first] == FAILURE)
		{
			res[first] = sortLists[first].GetNext(&cont[first]);
			if (res[first] == SUCCESS)
				res[first] = readWitnessTreeFromContainer(&inTree[first], &cont[first]);
		}
		allNull = !atLeastOneSuccess();
		return SUCCESS;
	}
	return FAILURE;
}


int ExternalValueSortIterator::whoseFirst()
{	
	int firstTree = 0;
	int j = 0;
	for (j=0; j<numContIn; j++)
		if (res[j] == SUCCESS)
		{
			firstTree = j;
			break;
		}
	if (j == numContIn)
		return FAILURE;
	for (int currTree=firstTree+1; currTree<numContIn; currTree++)
	{
		if (res[currTree] == SUCCESS)
			if (compareNodesValSortX((const void *)&inTree[firstTree],(const void *)&inTree[currTree]) > 0)
				firstTree = currTree;
	}
	return firstTree;
}


int ExternalValueSortIterator::writeContainerToList(ContainerClass *cont, ShoreList *list)
{
	if (list->IsEmpty())
	{
		//first write to list
		serial_t currRecID = startID;
		if (startID.increment(1) == true)
			//overflow of shore logical ids
		{
			globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"Evaluator",__FILE__,"Shore Logical ID overflow.");
			return FAILURE;
		}
		if (SBJoinAncsStackNode::WriteBufferToList(cont,list,fileID,volumeID,currRecID,startID) == FAILURE)
			return FAILURE;
		if (startID.increment(1) == true)
			//overflow of shore logical ids
		{
			globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"Evaluator",__FILE__,"Shore Logical ID overflow.");
			return FAILURE;
		}
	}
	else
	{
		if (SBJoinAncsStackNode::WriteBufferToList(cont,list,startID) == FAILURE)
			return FAILURE;
		if (startID.increment(1) == true)
			//overflow of shore logical ids
		{
			globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"Evaluator",__FILE__,"Shore Logical ID overflow.");
			return FAILURE;
		}
	}
	numCont++;
	cont->Initialize();
	return SUCCESS;
}

int ExternalValueSortIterator::treeSize(WitnessTree *tree)
{
	return sizeof(double) + sizeof(int) + (treeNodeSz * tree->length());
}


int ExternalValueSortIterator::writeWitnessTreeIntoContainer(WitnessTree *tree, ContainerClass *cont)
{	
	int size = treeSize(tree);

	if (cont->EnoughSpace(size))
	{
		double sc = tree->getScore();
		int treeSz = tree->length();
		cont->AddData((char *)&sc,sizeof(double));
		cont->AddData((char *)&treeSz,sizeof(int));
		cont->AddData((char *)tree->getBuffer(),treeNodeSz*tree->length());
		return SUCCESS;
	}
	else {
		//globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"Evaluator",__FILE__,"Possibly not enough space on a container");
		return FAILURE;
	}
}

int ExternalValueSortIterator::readWitnessTreeFromContainer(WitnessTree *tree, ContainerClass *cont)
{
	double sc;
	if (cont->GetNext(sizeof(double),(char *)&sc) == FAILURE)
		return FAILURE;

	tree->initialize();
	tree->setScore(sc);

	int treeSz;
	cont->GetNext(sizeof(int),(char *)&treeSz);

	if (treeNodeSz == sizeof(ListNode))
		tree->appendList((ListNode *)cont->GetNextPtr(treeSz*treeNodeSz),treeSz);
	else
		tree->appendList((ComplexListNode *)cont->GetNextPtr(treeSz*treeNodeSz),dataMng,treeSz);

	return SUCCESS;
}

int ExternalValueSortIterator::createFileAndID()
{
	cout<<"create file for nres: "<<this->nre[0]<<endl;
	rc = ss_m::create_file(volumeID, fileID,ss_m::t_regular);
	if (rc) 
	{
		stringstream msg;
		msg<<rc<<'\0';
		globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"Evaluator",__FILE__,msg.rdbuf()->str().c_str());
		return FAILURE;				
	}
	fileCreated = true;
	int maxIDs = gSettings->getIntegerValue("MAX_ID_PER_FILE_EXTERNAL_SORT",1000000);
	rc = ss_m::create_id(volumeID,maxIDs,startID);

	if (rc) 
	{
		stringstream msg;
		msg<<rc<<'\0';
		globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"Evaluator",__FILE__,msg.rdbuf()->str().c_str());	
		return FAILURE;				
	}
	numWrites = maxIDs;
	return SUCCESS;
}

void ExternalValueSortIterator::buildSortArray()
{
	int witTreeMinSz = sizeof(int) + sizeof(double) + sizeof(ComplexListNode);
	int potSz = (int)ceil((double)(cont[0].GetSize() / witTreeMinSz));
	sortArray = new WitnessTree[potSz];
}

void ExternalValueSortIterator::getAllNodesToCompare(WitnessTree* elem1)
{
	for (int i=0; i<gNumValX; i++)
	{
		int index1 = ((WitnessTree *)elem1)->getIndexOfNRE(gNREValX[i]);
		if (index1 == FAILURE)
			continue;


		FileIDType fileid1 = EvaluatorClass::getFileID(((ComplexListNode *)((WitnessTree *)elem1)->getNodeByIndex(index1))->getFileIndex());
		if (fileid1 == -1)
			return;


		switch (gSortByValX[i])
		{
		case SORTBY_TEXT_NUM:
		case SORTBY_TEXT_STR:
			{
				int res1 = EvaluatorClass::GetText((WitnessTree *)elem1,index1,gdataMngValX,fileid1);
				if (res1 == FAILURE || res1 == 0)
				{
					continue;
				}

				char *txt1 = ((DM_CharNode *)((ComplexListNode *)((WitnessTree *)elem1)->getNodeByIndex(res1))->GetData())->getCharValue();

			}
			break;
		case SORTBY_ATTRIBUTE_NUM:
		case SORTBY_ATTRIBUTE_STR:
			{
				int res1 = EvaluatorClass::GetAttributes((WitnessTree *)elem1,index1,gdataMngValX,fileid1);
				if (res1 == FAILURE)
				{
					continue;
				}

				Value *val1 = ((DM_AttributeNode *)((ComplexListNode *)((WitnessTree *)elem1)->getNodeByIndex(index1+1))->GetData())->getAttr(gAttrNameValX[i]);
				
			}
			break;
		case SORTBY_TAGNAME:
			{
				ComplexListNode *n1 = (ComplexListNode *)((WitnessTree *)elem1)->getNodeByIndex(index1);
				DM_DataNode *dn1 = n1->GetData();

			}
			break;
		case SORTBY_VALUE_NUM:
		case SORTBY_VALUE_STR:
			{
				DM_DataNode *dn1 = ((ComplexListNode *)((WitnessTree *)elem1)->getNodeByIndex(index1))->GetData();

				if (dn1 == NULL)
					continue;

				char *txt1;
				Value *val1;
				if (dn1->getFlag() == ELEMENT_NODE)
					txt1 = gdataMngValX->getPhysicalDataMng()->getXMLNameTable()->getNameByCode(((DM_ElementNode *)dn1)->getTag());
				else if (dn1->getFlag() == DOCUMENT_NODE)
				{
					if (((DM_DocumentNode *)dn1)->getXMLFileName())
						txt1 = ((DM_DocumentNode *)dn1)->getXMLFileName();
					else
						txt1 = NULL;
				}
				else if (dn1->getFlag() == ATTRIBUTE_NODE)
				{
					//if attribute node, return the value of attribute "attrName"
					
					val1 = ((DM_AttributeNode *)dn1)->getAttr(gAttrNameValX[i]);
					if (val1 != NULL)
					{
						if (val1->getStrValue() != NULL && strlen(val1->getStrValue()) != 0)
							txt1 = val1->getStrValue();
						else
							txt1 = NULL;
					}
					else
						txt1 = NULL;
				} 
				else
				{
					//if text node, return the text value
					if (((DM_CharNode *)dn1)->getCharValue())
						txt1 = ((DM_CharNode *)dn1)->getCharValue();
					else
						txt1 = NULL;
				}

			

			}
			break;
			case SORT_BY_START_KEY:
				{

				}
				break;
			case SORTBY_ATTRIBUTE_KEY:
			{
				ComplexListNode *n1 = (ComplexListNode *)((WitnessTree *)elem1)->getNodeByIndex(index1);
				DM_DataNode *dn1 = n1->GetData();
				
				if (dn1 == NULL)
					continue;
				if (dn1->getFlag() != ELEMENT_NODE)
					continue;
				
				KeyType ak1 = ((DM_ElementNode*)dn1)->getAttributes();
				if (ak1 == 0)
					continue;
				
			}
			break;
		}
	}
}
