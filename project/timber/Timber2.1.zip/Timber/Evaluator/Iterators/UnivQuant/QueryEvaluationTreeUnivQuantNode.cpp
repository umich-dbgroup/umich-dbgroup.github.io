/*
COPYRIGHT  � 2000-2004 
THE REGENTS OF THE UNIVERSITY OF MICHIGAN
ALL RIGHTS RESERVED

PERMISSION IS GRANTED TO USE, COPY, CREATE DERIVATIVE WORKS AND REDISTRIBUTE THIS SOFTWARE AND SUCH DERIVATIVE WORKS FOR 
NONCOMMERCIAL EDUCATION AND RESEARCH PURPOSES, SO LONG AS NO FEE IS CHARGED, AND SO LONG AS THE COPYRIGHT NOTICE ABOVE, 
THIS GRANT OF PERMISSION, AND THE DISCLAIMER BELOW APPEAR IN ALL COPIES MADE; AND SO LONG AS THE NAME OF THE UNIVERSITY 
OF MICHIGAN IS NOT USED IN ANY ADVERTISING OR PUBLICITY PERTAINING TO THE USE OR DISTRIBUTION OF THIS SOFTWARE WITHOUT 
SPECIFIC, WRITTEN PRIOR AUTHORIZATION.

THIS SOFTWARE IS PROVIDED AS IS, WITHOUT REPRESENTATION FROM THE UNIVERSITY OF MICHIGAN AS TO ITS FITNESS FOR ANY PURPOSE, 
AND WITHOUT WARRANTY BY THE UNIVERSITY OF MICHIGAN OF ANY KIND, EITHER EXPRESS OR IMPLIED, INCLUDING WITHOUT LIMITATION THE 
IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE. THE REGENTS OF THE UNIVERSITY OF MICHIGAN SHALL 
NOT BE LIABLE FOR ANY DAMAGES, INCLUDING SPECIAL, INDIRECT, INCIDENTAL, OR CONSEQUENTIAL DAMAGES, WITH RESPECT TO ANY CLAIM 
ARISING OUT OF OR IN CONNECTION WITH THE USE OF THE SOFTWARE, EVEN IF IT HAS BEEN OR IS HEREAFTER ADVISED OF THE POSSIBILITY 
OF SUCH DAMAGES.
*/

#include "QueryEvaluationTreeUnivQuantNode.h"


QueryEvaluationTreeUnivQuantNode::QueryEvaluationTreeUnivQuantNode(QueryEvaluationTreeNode* operand,
		NREType rootNRE ,int num,
		IteratorClass **pattern, int *relation,
		UnivQuantCondition *condition)
: QueryEvaluationTreeNode()
{
	this->condition = condition;
	this->pattern = pattern;
	this->relation = relation;
	this->rootNRE = rootNRE;
	this->operand = operand;
	this->num = num;
}

QueryEvaluationTreeUnivQuantNode::~QueryEvaluationTreeUnivQuantNode()
{
	if (operand)
		delete operand;
}

NREType QueryEvaluationTreeUnivQuantNode::getRootNRE()
{
	return this->rootNRE;
}

void QueryEvaluationTreeUnivQuantNode::setRootNRE(NREType rootNRE)
{
	this->rootNRE = rootNRE;
}


IteratorClass **QueryEvaluationTreeUnivQuantNode::getPattern()
{
	return this->pattern;
}

void QueryEvaluationTreeUnivQuantNode::setPattern(IteratorClass **pattern)
{
	this->pattern = pattern;
}

int *QueryEvaluationTreeUnivQuantNode::getRelation()
{
	return this->relation;
}

void QueryEvaluationTreeUnivQuantNode::setRelation(int *relation)
{
	this->relation = relation;
}

UnivQuantCondition *QueryEvaluationTreeUnivQuantNode::getCondition()
{
	return this->condition;
}

void QueryEvaluationTreeUnivQuantNode::setCondition(UnivQuantCondition* condition)
{
	this->condition = condition;
}

	
QueryEvaluationTreeNode* QueryEvaluationTreeUnivQuantNode::getOperand()
{
	return operand;
}

void QueryEvaluationTreeUnivQuantNode::setOperand(QueryEvaluationTreeNode *operand)
{
	this->operand = operand;
}

int QueryEvaluationTreeUnivQuantNode::getNum()
{
	return this->num;
}

void QueryEvaluationTreeUnivQuantNode::setNum(int num)
{
	this->num = num;
}

void QueryEvaluationTreeUnivQuantNode::deleteStructures()
{
	if (condition) delete condition;
	if (relation) delete [] relation;
	if (pattern)
	{
		for (int i=0; i<num; i++)
			if (pattern[i]) delete pattern[i];
		delete [] pattern;
	}
	operand->deleteStructures();
}
