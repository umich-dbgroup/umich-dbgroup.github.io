/*
COPYRIGHT  � 2000-2004 
THE REGENTS OF THE UNIVERSITY OF MICHIGAN
ALL RIGHTS RESERVED

PERMISSION IS GRANTED TO USE, COPY, CREATE DERIVATIVE WORKS AND REDISTRIBUTE THIS SOFTWARE AND SUCH DERIVATIVE WORKS FOR 
NONCOMMERCIAL EDUCATION AND RESEARCH PURPOSES, SO LONG AS NO FEE IS CHARGED, AND SO LONG AS THE COPYRIGHT NOTICE ABOVE, 
THIS GRANT OF PERMISSION, AND THE DISCLAIMER BELOW APPEAR IN ALL COPIES MADE; AND SO LONG AS THE NAME OF THE UNIVERSITY 
OF MICHIGAN IS NOT USED IN ANY ADVERTISING OR PUBLICITY PERTAINING TO THE USE OR DISTRIBUTION OF THIS SOFTWARE WITHOUT 
SPECIFIC, WRITTEN PRIOR AUTHORIZATION.

THIS SOFTWARE IS PROVIDED AS IS, WITHOUT REPRESENTATION FROM THE UNIVERSITY OF MICHIGAN AS TO ITS FITNESS FOR ANY PURPOSE, 
AND WITHOUT WARRANTY BY THE UNIVERSITY OF MICHIGAN OF ANY KIND, EITHER EXPRESS OR IMPLIED, INCLUDING WITHOUT LIMITATION THE 
IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE. THE REGENTS OF THE UNIVERSITY OF MICHIGAN SHALL 
NOT BE LIABLE FOR ANY DAMAGES, INCLUDING SPECIAL, INDIRECT, INCIDENTAL, OR CONSEQUENTIAL DAMAGES, WITH RESPECT TO ANY CLAIM 
ARISING OUT OF OR IN CONNECTION WITH THE USE OF THE SOFTWARE, EVEN IF IT HAS BEEN OR IS HEREAFTER ADVISED OF THE POSSIBILITY 
OF SUCH DAMAGES.
*/

#include "UniversalQuantification.h"

UniversalQuantification::UniversalQuantification(IteratorClass *input, NREType rootNRE,
												 UnivQuantCondition *condition, int num, 
												 IteratorClass **pattern, int *relation,
												 DataMng *dataMng)
{
	this->input = input;
	this->rootNRE = rootNRE;
	this->relation = relation;
	this->condition = condition;
	this->num = num;
	this->pattern = pattern;
	this->dataMng = dataMng;

	this->volumeID = dataMng->getVolumeID();

	if (num > 0)
		inTuple = new WitnessTree *[num+1];


	if (num > 1)
		stacks = new stack<SimpleStackNode>[num-1];
	else
		stacks = NULL;

	getInputs();

	first = -1;

	if (inTuple[0])
	{
		if (inTuple[0]->isSimple())
		{
			resultBuffer = new WitnessTree;
			listNodeSize = sizeof(ListNode);
		}
		else
		{
			resultBuffer = new WitnessTree(LIST_NODE_WITH_DATA,dataMng);
			listNodeSize = sizeof(ComplexListNode);
		}
	//	if (inTuple[0]->length() > 1)
	//	{
			rc = ss_m::create_file(volumeID, fileID,ss_m::t_regular);
			if (rc) 
			{
				printf("after create file\n");
				cerr << rc << endl;
				return;				
			}


			rc = ss_m::create_id(volumeID,gSettings->getIntegerValue("MAX_ID_PER_FILE_STRUCTURAL_JOINS",10000),startID);

			if (rc) 
			{
				printf("after create id\n");
				cerr << rc << endl;
				return;				
			}	
			fileCreated = true;
//		}
	}
	else
	{
		resultBuffer = NULL;
		fileCreated = false;
	}
	stackElementHasBuf = false;
}

UniversalQuantification::~UniversalQuantification()
{
	delete input;
	if (resultBuffer) delete resultBuffer;

	if (condition) delete condition;

	if (pattern)
	{
		for (int i=0; i<num; i++)
			delete pattern[i];
		delete [] pattern;
		delete [] relation;
	}

	if (stacks)
		delete [] stacks;

	if (fileCreated)
	{
		rc = ss_m::destroy_file(volumeID, fileID);
		if (rc) 
		{
			printf("after destroy file\n");
			cerr << rc << endl;
			return;				
		}
	}
}

void UniversalQuantification::next(WitnessTree *&node)
{
	if (stackElementHasBuf)
	{
		if (constructOutput() == SUCCESS)
		{
			node = resultBuffer;
			return;
		}
		stackElementHasBuf = false;
	}

	while (stillHaveInput(first))
	{
		first = whoseFirst();

		if (first == 0)
		{
			if (handleRoot() == SUCCESS)
			{
				node = resultBuffer;
				return;
			}
		}
		else if (first == num)
		{
			if (handleLeaf() == SUCCESS)
			{
				node = resultBuffer;
				return;
			}
		}
		else
		{
			if (handleMiddle(first) == SUCCESS)
			{
				node = resultBuffer;
				return;
			}		
		}
		getInputs(first);
	}

	if (first == num)
	{
		if (popStackIfNeeded(0,-1) == SUCCESS)
		{
			node = resultBuffer;
			return;
		}
	}
	else if (first == 0)
	{
	}
	else
	{
		if (stacks[first - 1].IsEmpty())
		{
			if (popStackIfNeeded(0,-1) == SUCCESS)
			{
				node = resultBuffer;
				return;
			}
		}
		else
		{
		}
	}
	node = NULL;
}

void UniversalQuantification::getInputs(int which)
{
	//this method gets the next input of input at which, if which==-1, then all
	//inputs are read for new inputs
	if (which == -1)
	{
		input->next(inTuple[0]);
		for (int i=0; i<num; i++)
			pattern[i]->next(inTuple[i+1]);
	}
	else if (which == 0)
		input->next(inTuple[0]);
	else
		pattern[which-1]->next(inTuple[which]);
}

int UniversalQuantification::whoseFirst()
{
	//in this method, it is decided which occurance of the words comes first
	KeyType minSK = DBL_MAX;
	int minIndex = -1;
	for (int i=0; i<num+1; i++)
	{
		//for each input, compare the start key and find the one with the min
		if (inTuple[i])
		{
			KeyType SK = (i != 0? ((ListNode *)inTuple[i]->findNode(0))->GetStartPos() :
						(inTuple[0]->isSimple()? ((ListNode *)inTuple[0]->findNodeNRE(rootNRE))->GetStartPos(): 
						((ComplexListNode *)inTuple[0]->findNodeNRE(rootNRE))->GetStartPos()));
			if (SK < minSK)
			{
				minSK = SK;
				minIndex = i;
			}
		}
	}
	return minIndex;
}

int UniversalQuantification::handleRoot()
{
	KeyType SK = (inTuple[0]->isSimple() ? ((ListNode *)inTuple[0]->findNodeNRE(rootNRE))->GetStartPos() : 
					((ComplexListNode *)inTuple[0]->findNodeNRE(rootNRE))->GetStartPos());
	
	if (this->popStackIfNeeded(0,SK) == SUCCESS)
		return SUCCESS;

	pushRootIntoStack();

	return FAILURE;
}

void UniversalQuantification::pushRootIntoStack()
{
	//you need to deal with adding to the buffer only. not just pushing.
	if (inTuple[0]->isSimple())
		mainStack.Push((ListNode *)(inTuple[0]->findNodeNRE(rootNRE)));
	else
		mainStack.Push((ComplexListNode *)(inTuple[0]->findNodeNRE(rootNRE)));

	//if (inTuple[0]->length() > 1)
	//{
	//	mainStack.GetTop()->SetListsVolumeAndFileIDs(volumeID,fileID);
	//	mainStack.GetTop()->GetListOfBuffers()->StartScan();
//	}

//	this->writeTreeToBuffer(mainStack.GetTop()->GetBuffer(),inTuple[0]);
}


int UniversalQuantification::popStackIfNeeded(int index, KeyType startPosition)
{
	if (startPosition == -1)  // this means POP all
		startPosition = DBL_MAX;
	if (index == 0)
	{
		if (mainStack.IsEmpty())
			return FAILURE;
		if (startPosition > mainStack.GetTop()->GetActualAncs()->GetEndPos())
		{
			for (int i=0; i<num-1; i++)
				stacks[i].Initialize();
		}

		while (startPosition > mainStack.GetTop()->GetActualAncs()->GetEndPos())
		{
			//SBJoinDescStackNode *popped = mainStack.Pop();
			SimpleStackNode *popped = mainStack.Pop();
			if (popped->hasBeenJoined())
			{
				outputStackElement = popped;
				constructOutput();
				return SUCCESS;
			}
			if (mainStack.IsEmpty())
				return FAILURE;
		}
	}
	else
	{
		if (stacks[index-1].IsEmpty())
			return FAILURE;
		if (startPosition > stacks[index-1].GetTop()->GetActualAncs()->GetEndPos())
		{
			for (int i=index; i<num-1; i++)
				stacks[i].Initialize();
		}

		while (startPosition > stacks[index-1].GetTop()->GetActualAncs()->GetEndPos())
		{
			stacks[index-1].Pop();
			if (stacks[index-1].IsEmpty())
				return FAILURE;
		}
	}
	return FAILURE;
}

void UniversalQuantification::writeTreeToBuffer(ContainerClass *buf, WitnessTree *tree)
{
	// a single tree in the buffer should look like:
	// score treeSize ancsIndex tree 
	
	//adding score
	double sc = tree->getScore();
	buf->AddData((char *)&sc,sizeof(double));

	//adding the tree size
	int treeSz = tree->length() - 1;
	buf->AddData((char *)&treeSz,sizeof(int));

	// if the ancs has a list associated with it, add the list to the buffer.
	if (treeSz > 0)
	{
		int rootIndex = tree->getIndexOfNRE(rootNRE);
		buf->AddData((char *)&rootIndex,sizeof(int));
		for (int i =0; i < rootIndex; i++)
			buf->AddData((char *)tree->getNodeByIndex(i),listNodeSize);
		
		for (int i = rootIndex+1; i < tree->length(); i++)
			buf->AddData((char *)tree->getNodeByIndex(i),listNodeSize);
	}
}

int UniversalQuantification::readTreeFromBuffer(/*ContainerClass *buf, */ListNode *rootData, ComplexListNode *rootDataComplex)
{	
	//reading score
//	double scr;
	//int res;
	/*= buf->GetNext(sizeof(double),(char *)&scr);

	if (res == FAILURE)
		return FAILURE;

	resultBuffer->setScore(scr);

	int treeSz;
	buf->GetNext(sizeof(int),(char *)&treeSz);

	if (treeSz > 0)
	{
		int rootIndex;
		buf->GetNext(sizeof(int),(char *)&rootIndex);

		if (rootData)
		{
			resultBuffer->appendList((ListNode *)buf->GetNextPtr(rootIndex*listNodeSize),rootIndex);
			resultBuffer->appendList(rootData,1);
			resultBuffer->appendList((ListNode *)buf->GetNextPtr((treeSz-rootIndex)*listNodeSize),
				treeSz-rootIndex);
		}
		else
		{
			resultBuffer->appendList((ComplexListNode *)buf->GetNextPtr(rootIndex*listNodeSize),dataMng,rootIndex);
			resultBuffer->appendList(rootDataComplex,dataMng,1);
			resultBuffer->appendList((ComplexListNode *)buf->GetNextPtr((treeSz-rootIndex)*listNodeSize),dataMng,
				treeSz-rootIndex);
		}
	}
	else
	{*/
		if (rootData)
			resultBuffer->appendList(rootData,1);
		else
			resultBuffer->appendList(rootDataComplex,dataMng,1);
//	}	
	return SUCCESS;
}

int UniversalQuantification::handleLeaf()
{
	KeyType SK = ((ListNode *)inTuple[num]->getNodeByIndex(0))->GetStartPos();

	if (this->popStackIfNeeded(0,SK) == SUCCESS)
		return SUCCESS;

	for (int i=1; i<=num-1; i++)
		this->popStackIfNeeded(i,SK);

	if (num > 1)
	{
		if (stacks[num-2].IsEmpty())
			return FAILURE;
	}

	if (relation[num-1] == PARENT_CHILD)
	{
		int lev = ((ListNode *)inTuple[num]->getNodeByIndex(0))->GetLevel() - 1;
		if (stacks[num-2].GetTop()->GetActualAncs()->GetLevel() != lev)
			return FAILURE;
	}

	char fileIndex = ((ListNode *)inTuple[num]->getNodeByIndex(0))->getFileIndex();

	if (!satisfiesCondition(SK,fileIndex,condition))
	{
		mainStack.Initialize();
		for (int i=0; i<num-1; i++)
			stacks[i].Initialize();
	}
	else
	{
		if (relation[0] == PARENT_CHILD)
			mainStack.GetTop()->setBeenJoined(true);
		else
		{
			for (int i=0; i<mainStack.Size(); i++)
				mainStack.GetByIndex(i)->setBeenJoined(true);
		}
	}
	return FAILURE;
}

bool UniversalQuantification::satisfiesCondition(KeyType SK, char fileIndex, UnivQuantCondition *condition)
{
	char *txt = NULL;
	FileIDType fid = EvaluatorClass::getFileID((int) fileIndex);
	if (fid == -1)
		return false;
	WitnessTree t(LIST_NODE_WITH_DATA,dataMng);
	ComplexListNode n;
	n.SetStartPos(SK);
	n.setFileIndex(fileIndex);
	t.appendList(&n,dataMng,1);
	switch (condition->getCompareWhat())
	{
	case UQC_COMPARE_TEXT:
		{
		//	txt = EvaluatorClass::returnText(&t,0,dataMng,fid);

			int res = EvaluatorClass::GetText(&t,0,dataMng,fid);
			if (res == FAILURE)
				return false;
			ComplexListNode *an = (ComplexListNode *)t.getNodeByIndex(res);
			txt = ((DM_CharNode *)an->GetData())->getCharValue();
			if (!txt)
				return false;
		}
		break;
	case UQC_COMPARE_ATTR:
		{
			if (EvaluatorClass::GetAttributes(&t,0,dataMng,fid) == FAILURE)
				return false;
			ComplexListNode *an = (ComplexListNode *)t.getNodeByIndex(1);
			Value *val = ((DM_AttributeNode *)an->GetData())->getAttr(condition->getAttrName());
			if (val == NULL)
				return false;
			if (val->getStrValue() == NULL || strlen(val->getStrValue()) == 0)
				return false;
			txt = val->getStrValue();
		}
		break;
	}

	bool res = false;

	switch (condition->getOperation())
	{
	case UQC_EQ_NUM	: res = (atof(txt) == condition->getNum()); break;
	case UQC_LT_NUM	: res = (atof(txt) <  condition->getNum()); break;
	case UQC_LE_NUM	: res = (atof(txt) <= condition->getNum()); break;
	case UQC_NE_NUM	: res = (atof(txt) != condition->getNum()); break;
	case UQC_GT_NUM	: res = (atof(txt) >  condition->getNum()); break;
	case UQC_GE_NUM	: res = (atof(txt) >= condition->getNum()); break;

	case UQC_EQ_STR : res = (strcmp(txt,condition->getStr()) == 0); break;
	case UQC_LT_STR	: res = (strcmp(txt,condition->getStr()) < 0); break;
	case UQC_LE_STR	: res = (strcmp(txt,condition->getStr()) <= 0); break;
	case UQC_NE_STR	: res = (strcmp(txt,condition->getStr()) != 0); break;
	case UQC_GT_STR	: res = (strcmp(txt,condition->getStr()) >  0); break;
	case UQC_GE_STR : res = (strcmp(txt,condition->getStr()) >= 0); break;
	case UQC_CONTAINS : res = (strstr(txt,condition->getStr()) != NULL); break;
	case UQC_STARTS_WITH: res = (strncmp(txt,condition->getStr(),strlen(condition->getStr())) == 0); break;
	}

//	if (condition->getCompareWhat() == UQC_COMPARE_TEXT)
//		delete [] txt;

	return res;
}

int UniversalQuantification::handleMiddle(int index)
{
	KeyType SK = ((ListNode *)inTuple[index]->getNodeByIndex(0))->GetStartPos();

	if (this->popStackIfNeeded(0,SK) == SUCCESS)
		return SUCCESS;

	for (int i=1; i<=num-1; i++)
		this->popStackIfNeeded(i,SK);
	
	if (index == 1)
	{
		if (mainStack.IsEmpty())
			return FAILURE;
	}
	else
	{
		if (stacks[index-2].IsEmpty())
			return FAILURE;
	}

	if (relation[index-1] == PARENT_CHILD)
	{
		int lev = ((ListNode *)inTuple[index]->getNodeByIndex(0))->GetLevel() - 1;
		if (index == 1)
		{
			if (mainStack.GetTop()->GetActualAncs()->GetLevel() != lev)
				return FAILURE;
		}
		else
		{
			if (stacks[index-2].GetTop()->GetActualAncs()->GetLevel() != lev)
				return FAILURE;
		}
	}
	stacks[index-1].Push((ListNode *)(inTuple[index]->getNodeByIndex(0)));
	return FAILURE;
}

int UniversalQuantification::constructOutput()
{
	resultBuffer->initialize();

	if (outputStackElement->isSimple())
		return this->readTreeFromBuffer(/*outputStackElement->GetBuffer(),*/outputStackElement->GetActualAncs(),NULL);
	else
		return this->readTreeFromBuffer(/*outputStackElement->GetBuffer(),*/NULL,outputStackElement->GetActualAncsComplex());
}

bool UniversalQuantification::stillHaveInput(int which)
{
	if (which == -1)
	{
		for (int i=0; i<=num; i++)
			if (inTuple[i] == NULL)
				return false;
	}
	else
		return (inTuple[which] != NULL);
	return true;
}
