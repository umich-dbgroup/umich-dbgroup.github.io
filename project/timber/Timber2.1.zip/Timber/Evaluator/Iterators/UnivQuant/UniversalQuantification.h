/*
COPYRIGHT  � 2000-2004 
THE REGENTS OF THE UNIVERSITY OF MICHIGAN
ALL RIGHTS RESERVED

PERMISSION IS GRANTED TO USE, COPY, CREATE DERIVATIVE WORKS AND REDISTRIBUTE THIS SOFTWARE AND SUCH DERIVATIVE WORKS FOR 
NONCOMMERCIAL EDUCATION AND RESEARCH PURPOSES, SO LONG AS NO FEE IS CHARGED, AND SO LONG AS THE COPYRIGHT NOTICE ABOVE, 
THIS GRANT OF PERMISSION, AND THE DISCLAIMER BELOW APPEAR IN ALL COPIES MADE; AND SO LONG AS THE NAME OF THE UNIVERSITY 
OF MICHIGAN IS NOT USED IN ANY ADVERTISING OR PUBLICITY PERTAINING TO THE USE OR DISTRIBUTION OF THIS SOFTWARE WITHOUT 
SPECIFIC, WRITTEN PRIOR AUTHORIZATION.

THIS SOFTWARE IS PROVIDED AS IS, WITHOUT REPRESENTATION FROM THE UNIVERSITY OF MICHIGAN AS TO ITS FITNESS FOR ANY PURPOSE, 
AND WITHOUT WARRANTY BY THE UNIVERSITY OF MICHIGAN OF ANY KIND, EITHER EXPRESS OR IMPLIED, INCLUDING WITHOUT LIMITATION THE 
IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE. THE REGENTS OF THE UNIVERSITY OF MICHIGAN SHALL 
NOT BE LIABLE FOR ANY DAMAGES, INCLUDING SPECIAL, INDIRECT, INCIDENTAL, OR CONSEQUENTIAL DAMAGES, WITH RESPECT TO ANY CLAIM 
ARISING OUT OF OR IN CONNECTION WITH THE USE OF THE SOFTWARE, EVEN IF IT HAS BEEN OR IS HEREAFTER ADVISED OF THE POSSIBILITY 
OF SUCH DAMAGES.
*/


#ifndef __UniversalQuantification_h
#define __UniversalQuantification_h
#include <timber-compat.h>

#include "../../Evaluator/EvaluatorClass.h"
#include "UnivQuantCondition.h"
#include "../StructuralJoin/SBJoinDescStackNode.h"
#include <float.h>

class UniversalQuantification : public IteratorClass
{
public:
	UniversalQuantification(IteratorClass *input, NREType rootNRE, 
		UnivQuantCondition *condition, int num, IteratorClass **pattern, int *relation, DataMng *dataMng);
	~UniversalQuantification();

	void next(WitnessTree *&node);
private:
	void getInputs(int which = -1);
	int whoseFirst();
	int handleRoot();
	int handleLeaf();
	int handleMiddle(int index);
	void pushRootIntoStack();
	void writeTreeToBuffer(ContainerClass *buf, WitnessTree *tree);
	int readTreeFromBuffer(/*ContainerClass *buf, */ListNode *rootData, ComplexListNode *rootDataComplex);
	int popStackIfNeeded(int index, KeyType startPosition);
	int constructOutput();
	bool satisfiesCondition(KeyType SK, char fileIndex,  UnivQuantCondition *condition);
	bool stillHaveInput(int which);
	
	IteratorClass *input;
	NREType rootNRE;
	WitnessTree *resultBuffer;
	WitnessTree **inTuple;
	UnivQuantCondition *condition;
	int num;
	IteratorClass **pattern;
	int *relation;
	DataMng *dataMng;
	//stack<SBJoinDescStackNode> mainStack;
	stack<SimpleStackNode> mainStack;
	stack<SimpleStackNode> *stacks;
	int listNodeSize;
	bool fileCreated;
	serial_t startID;
	lvid_t volumeID;
	serial_t fileID;
	rc_t rc;
	//SBJoinDescStackNode *outputStackElement;
	SimpleStackNode *outputStackElement;
	bool stackElementHasBuf;
	int first;

};

#endif
