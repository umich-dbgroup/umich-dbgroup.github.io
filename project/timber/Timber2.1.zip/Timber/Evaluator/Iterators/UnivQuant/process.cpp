#include "../../Evaluator/EvaluatorClass.h"

#include "QueryEvaluationTreeUnivQuantNode.h"

#include "UniversalQuantification.h"
#include "extra.h"

void QueryEvaluationTreeUnivQuantNode::processQueryEvalNode(EvaluatorClass* evaluator, IteratorClass*& curr)
	    {
		IteratorClass *opr = evaluator->processQueryEvalNode(getOperand());
		if (opr == NULL)
		    curr=NULL; return;
		curr = new UniversalQuantification(opr,getRootNRE(),getCondition(),getNum(),getPattern(),
			getRelation(),evaluator->getDataManager());
	    }

