
#include "parse.hpp"

char QueryEvaluationTreeNavigationalGetRelativeNode::getIdentifier(void) { return 'V'; }

char NavigationalGetRelativePlanParser::getIteratorIdentifier(void) { return 'V'; }

void 
NavigationalGetRelativePlanParser::getQueryEvalNode(EvaluatorClass* evaluator, char* line, void* queryInput, QueryEvaluationTreeNode*& curr)
	    {
		char *token = strtok(line+2,",");                    
		if (token == NULL)
		{
		    globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"Evaluator",__FILE__,"Error input from file... expecting NRE... navigational get relative line...");
		    curr=NULL; return;
		}
		NREType nre = (NREType)atoi(token);
		if (nre < 1)
		{
		    globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"Evaluator",__FILE__,"NRE should be positive.");
		    curr=NULL; return;
		}
		if (nre > evaluator->maxNRE)
		    evaluator->maxNRE = nre;
		token = strtok(NULL,",");
		if (token == NULL)
		{
		    globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"Evaluator",__FILE__,"Error input from file... expecting relation... navigational get relative line...");
		    curr=NULL; return;
		}
		int relation; 

		if (strcmp(token,"1A") == 0)
		    relation = N_GET_ONE_ANCS;
		else if (strcmp(token,"1C") == 0)
		    relation = N_GET_ONE_CHILD;
		else if (strcmp(token,"AAO") == 0)
		    relation = N_GET_ALL_ANCS_ONEBYONE;
		else if (strcmp(token,"ACO") == 0)
		    relation = N_GET_ALL_CHILDREN_ONEBYONE;
		else if (strcmp(token,"ADO") == 0)
		    relation = N_GET_ALL_DESC_ONEBYONE;
		else if (strcmp(token,"AAOI") == 0)
		    relation = N_GET_ALL_ANCS_ONEBYONE_INCL;
		else if (strcmp(token,"ACOI") == 0)
		    relation = N_GET_ALL_CHILDREN_ONEBYONE_INCL;
		else if (strcmp(token,"ADOI") == 0)
		    relation = N_GET_ALL_DESC_ONEBYONE_INCL;
		else if (strcmp(token,"AAT") == 0)
		    relation = N_GET_ALL_ANCS_TOGETHER;
		else if (strcmp(token,"ACT") == 0)
		    relation = N_GET_ALL_CHILDREN_TOGETHER;
		else if (strcmp(token,"ADT") == 0)
		    relation = N_GET_ALL_DESC_TOGETHER;
		else if (strcmp(token,"AT") == 0)
		    relation = N_GET_DESC_TEXT;
		else if (strcmp(token,"CT") == 0)
		    relation = N_GET_CHILD_TEXT;
		else if (strcmp(token,"DP") == 0)
		    relation = N_GET_DEPTH;
		else if (strcmp(token,"A") == 0)
		    relation = N_GET_ATTR;
		else
		{
		    globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"Evaluator",__FILE__,"Error input from file... unrecognized relation... navigational get relative line...");
		    curr=NULL; return;
		}
		token = strtok(NULL,",");
		if (token == NULL)
		{
		    globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"Evaluator",__FILE__,"Error input from file... expecting num... navigational get relative line...");
		    curr=NULL; return;
		}
		int num = atoi(token);

		token = strtok(NULL,",");
		if (token == NULL)
		{
		    globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"Evaluator",__FILE__,"Error input from file... expecting assigned NRE... navigational get relative line...");
		    curr=NULL; return;
		}
		NREType assignedNRE = (NREType)atoi(token);
		if (assignedNRE < 1)
		{
		    globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"Evaluator",__FILE__,"NRE should be positive.");
		    curr=NULL; return;
		}
		if (assignedNRE > evaluator->maxNRE)
		    evaluator->maxNRE = assignedNRE;

		char newLine[MAX_FILE_INTERFACE_LINE_SIZE];
		if (((std::iostream *)queryInput)->eof() == 0)
		    ((std::iostream *)queryInput)->getline(newLine,MAX_FILE_INTERFACE_LINE_SIZE);
		else
		{
		    globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"Evaluator",__FILE__,"Unexpected end of file... navigational get relative line...");
		    curr=NULL; return;
		}
		QueryEvaluationTreeNode *oper = evaluator->getQueryEvalNode(newLine,queryInput);
		if (oper == NULL)
		{
		    globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"Evaluator",__FILE__,"Unexpected operand returned... navigational get relative line...");
		    curr=NULL; return;
		}
		curr = new QueryEvaluationTreeNavigationalGetRelativeNode(oper,nre,relation,num,assignedNRE);
	    }

