#include "../../Evaluator/EvaluatorClass.h"
#include "NavigationalGetRelative.h"

#include "extra.h"

class NavigationalGetRelativePlanParser
{
public:

	static char getIteratorIdentifier(void) ;

	static void getQueryEvalNode(EvaluatorClass* evaluator, char* line, void* queryInput, QueryEvaluationTreeNode*& curr) ;

} ;

#ifndef WIN32

extern "C" char getIteratorIdentifier(void)
{
	return NavigationalGetRelativePlanParser::getIteratorIdentifier() ;
} ;

extern "C" void getQueryEvalNode(EvaluatorClass* evaluator, char* line, void* queryInput, QueryEvaluationTreeNode*& curr)
{
	return NavigationalGetRelativePlanParser::getQueryEvalNode(evaluator, line, queryInput, curr) ;
} ;

#endif
