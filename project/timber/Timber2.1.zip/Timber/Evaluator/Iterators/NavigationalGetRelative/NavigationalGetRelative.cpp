/*
COPYRIGHT  � 2000-2004 
THE REGENTS OF THE UNIVERSITY OF MICHIGAN
ALL RIGHTS RESERVED

PERMISSION IS GRANTED TO USE, COPY, CREATE DERIVATIVE WORKS AND REDISTRIBUTE THIS SOFTWARE AND SUCH DERIVATIVE WORKS FOR 
NONCOMMERCIAL EDUCATION AND RESEARCH PURPOSES, SO LONG AS NO FEE IS CHARGED, AND SO LONG AS THE COPYRIGHT NOTICE ABOVE, 
THIS GRANT OF PERMISSION, AND THE DISCLAIMER BELOW APPEAR IN ALL COPIES MADE; AND SO LONG AS THE NAME OF THE UNIVERSITY 
OF MICHIGAN IS NOT USED IN ANY ADVERTISING OR PUBLICITY PERTAINING TO THE USE OR DISTRIBUTION OF THIS SOFTWARE WITHOUT 
SPECIFIC, WRITTEN PRIOR AUTHORIZATION.

THIS SOFTWARE IS PROVIDED AS IS, WITHOUT REPRESENTATION FROM THE UNIVERSITY OF MICHIGAN AS TO ITS FITNESS FOR ANY PURPOSE, 
AND WITHOUT WARRANTY BY THE UNIVERSITY OF MICHIGAN OF ANY KIND, EITHER EXPRESS OR IMPLIED, INCLUDING WITHOUT LIMITATION THE 
IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE. THE REGENTS OF THE UNIVERSITY OF MICHIGAN SHALL 
NOT BE LIABLE FOR ANY DAMAGES, INCLUDING SPECIAL, INDIRECT, INCIDENTAL, OR CONSEQUENTIAL DAMAGES, WITH RESPECT TO ANY CLAIM 
ARISING OUT OF OR IN CONNECTION WITH THE USE OF THE SOFTWARE, EVEN IF IT HAS BEEN OR IS HEREAFTER ADVISED OF THE POSSIBILITY 
OF SUCH DAMAGES.
*/


#include "NavigationalGetRelative.h"


NavigationalGetRelative::NavigationalGetRelative(IteratorClass *input, NREType nre, int relation, int num,
						  NREType assignedNRE, DataMng *dataMng)
{
	this->input = input;
	this->nre = nre;
	this->relation = relation;
	this->num = num;
	this->assignedNRE = assignedNRE;
	
	this->dataMng = dataMng;

	if (this->relation == N_GET_ALL_ANCS_ONEBYONE_INCL || 
		this->relation == N_GET_ALL_DESC_ONEBYONE_INCL ||
		this->relation == N_GET_ALL_CHILDREN_ONEBYONE_INCL)
		inclusive = true;
	else
		inclusive = false;
	resultBuffer =  new WitnessTree(LIST_NODE_WITH_DATA,dataMng);
	fileid = -1;
	getNextInput();
}


NavigationalGetRelative::~NavigationalGetRelative()
{
	delete resultBuffer;
	delete input;
}


void NavigationalGetRelative::next(WitnessTree *&node)
{
#ifdef EVAL_TIME_OUT
	clock_t currTime = clock();
	double queryDuration = (double)(currTime - gQueryStartTime) / CLOCKS_PER_SEC;
	if (queryDuration >= gTimeOutAfter)
	{
		globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"Evaluator",__FILE__,"Query Timed Out.");
		node = NULL;
		return;
	}
#endif
	//if file id == -1 then we have a problem in reading the input-->file is not
	//in DB
	if (fileid == -1)
	{
		node = NULL;
		return;
	}

	while (lastSK != -1)
	{
		int res = FAILURE;
		//according to relation
		if (this->relation == N_GET_ALL_ANCS_ONEBYONE || 
			this->relation == N_GET_ALL_DESC_ONEBYONE ||
			this->relation == N_GET_ALL_CHILDREN_ONEBYONE ||
			this->relation == N_GET_ALL_ANCS_ONEBYONE_INCL || 
			this->relation == N_GET_ALL_DESC_ONEBYONE_INCL ||
			this->relation == N_GET_ALL_CHILDREN_ONEBYONE_INCL )
		{
			switch (this->relation)
			{
			case N_GET_ALL_ANCS_ONEBYONE_INCL:
			case N_GET_ALL_ANCS_ONEBYONE: res = getAllAncsOneByOne(); break;
			case N_GET_ALL_DESC_ONEBYONE_INCL:
			case N_GET_ALL_DESC_ONEBYONE: res = getAllDescOneByOne(); break;
			case N_GET_ALL_CHILDREN_ONEBYONE_INCL:
			case N_GET_ALL_CHILDREN_ONEBYONE: res = getAllChildrenOneByOne();break;
			default: 
				globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"Evaluator",__FILE__,"Unrecognized relation passed to iterator.");
				node = NULL; res = FAILURE; return;
			}
		}
		else
		{
			while (index != FAILURE)
			{
				switch (this->relation)
				{
				case N_GET_ONE_ANCS: res = getOneAncs(); break;
				case N_GET_ONE_CHILD: res = getOneChild();  break;
				case N_GET_ALL_ANCS_TOGETHER: res = getAllAncsTogether(); break;
				case N_GET_ALL_DESC_TOGETHER:res = getAllDescTogether();break;
				case N_GET_ALL_CHILDREN_TOGETHER:res = getAllChildrenTogether();break;
				case N_GET_DESC_TEXT: res = getDescText(); break;
				case N_GET_CHILD_TEXT: res = getChildText();  break;
				case N_GET_ATTR: res = getAttr();  break;
				case N_GET_DEPTH: res = this->getDepth();break;
				default:	
					globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"Evaluator",__FILE__,"Unrecognized relation passed to iterator.");
				node = NULL; res = FAILURE; return;
				}
				index = inTuple->getNextIndexNRE();
			}
			getNextInput();
		}

		//if getting relative was successful, output resultBuffer
		if (res == SUCCESS)
		{
			node = resultBuffer;
			return;
		}
		else
			//if not successful, get next input
			getNextInput();
#ifdef EVAL_TIME_OUT
	clock_t currTime = clock();
	double queryDuration = (double)(currTime - gQueryStartTime) / CLOCKS_PER_SEC;
	if (queryDuration >= gTimeOutAfter)
	{
		globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"Evaluator",__FILE__,"Query Timed Out.");
		node = NULL;
		return;
	}
#endif
	}
	node = NULL;
	return;
}

int NavigationalGetRelative::getDepth()
{
	//in this method, we get the depth of node at index "index" in the input
	//witness tree and write the depth to resultBuffer.
	resultBuffer->initialize();
	int actualIndex = index;//inTuple->getActualIndex(index);

	//get depth
	int depth = EvaluatorClass::GetSubtreeDepth(inTuple,actualIndex,dataMng,fileid);
	ComplexListNode n;

	//write depth to resultBuffer
	n.SetDummy(true);
	n.SetDummyName("<depth>");
	resultBuffer->appendList(&n,dataMng,1);
	char tmp[40];
	n.SetDummyName(itoa(depth,tmp,10));
	n.setNRE(assignedNRE);
	resultBuffer->appendList(&n,dataMng,1);
	return SUCCESS;
}

int NavigationalGetRelative::getOneAncs()
{
	//in this method, we get one ancs of node at index "index" in the input
	//witness tree. the ancs is "num" levels up
	resultBuffer->copyTree(inTuple);

	//get the needed ancs from DB
	int r = EvaluatorClass::getAncs(resultBuffer,index,num,dataMng,fileid,assignedNRE);

	if (r == FAILURE)
		return FAILURE;
	
	return SUCCESS;
}

int NavigationalGetRelative::getOneChild()
{
	//in this method, we get one child of node at index "index" in the input
	//witness tree. the child is # "num" among the other children
	resultBuffer->copyTree(inTuple);

	//get the needed child from DB
	int r = EvaluatorClass::GetChild(resultBuffer,index,num,dataMng,fileid,assignedNRE);
	if (r == FAILURE)
		return FAILURE;
	return SUCCESS;
}

int NavigationalGetRelative::getAllAncsOneByOne()
{
	//in this method, we get all ancs of node at index "index" in the input
	//witness tree. each is output one at a time
	if (inclusive && firstTime)
	{
		firstTime = false;
		resultBuffer->copyTree(inTuple);

		ComplexListNode nd;
		nd = *((ComplexListNode *)inTuple->getNodeByIndex(index));
		nd.setNRE(assignedNRE);
		resultBuffer->insertNode(index,&nd,dataMng);
		return SUCCESS;
	}
	WitnessTree t(LIST_NODE_WITH_DATA,dataMng);
	ComplexListNode nd;
	nd.SetStartPos(lastSK);
	nd.setFileIndex(fileIndex);
	t.appendList(&nd,dataMng,1);

	//get the ancs from DB
	int r = EvaluatorClass::getAncs(&t,0,1,dataMng,fileid,assignedNRE);
	if (r == FAILURE)
		return FAILURE;
	if (((ComplexListNode *)t.getNodeByIndex(r))->GetData()->getFlag() != ELEMENT_NODE)
		return FAILURE;
	lastSK = ((ComplexListNode *)t.getNodeByIndex(r))->GetStartPos();

	resultBuffer->copyTree(inTuple);

	//add the ancs to resultBuffer
	resultBuffer->sortedInsertNode((ComplexListNode *)t.getNodeByIndex(r),dataMng);
	return SUCCESS;
}

int NavigationalGetRelative::getAllDescOneByOne()
{
	//in this method, we get all desc of node at index "index" in the input
	//witness tree. each is output one at a time

	if (inclusive && firstTime)
	{
		firstTime = false;
		resultBuffer->copyTree(inTuple);

		ComplexListNode nd;
		nd = *((ComplexListNode *)inTuple->getNodeByIndex(index));
		nd.setNRE(assignedNRE);
		resultBuffer->insertNode(index+1,&nd,dataMng);
		return SUCCESS;
	}

	//we keep a cursor that points to the desc to be output this time
	if (childDescCursor == -1)
	{ 
		//first time here
		int oldIndex = index;
		int sz = inTuple->length();
		inTuple->switchToComplex(dataMng);

		//get all the desc from DB
		EvaluatorClass::GetAllDesc(inTuple,index,dataMng,fileid,-1,assignedNRE);
		if (sz == inTuple->length())
			return FAILURE;
		resultBuffer->copyTree(inTuple);
		childDescCursor = oldIndex + 1;
		childDescLastIndex = inTuple->length() - sz + oldIndex;

		//write the curr desc to resultBuffer
		//((ComplexListNode *)inTuple->getNodeByIndex(childDescCursor))->setNRE(assignedNRE);
		resultBuffer->appendList((ComplexListNode *)inTuple->getNodeByIndex(childDescCursor),dataMng,1);
		childDescCursor++;
		return SUCCESS;
	}
	if (childDescCursor > childDescLastIndex)
	{
		//we reached the last desc
		childDescCursor = -1;
		return FAILURE;
	}
	//remove the old desc and write the new one
	resultBuffer->deleteNode(resultBuffer->length() -1);
	//((ComplexListNode *)inTuple->getNodeByIndex(childDescCursor))->setNRE(assignedNRE);
	resultBuffer->appendList((ComplexListNode *)inTuple->getNodeByIndex(childDescCursor),dataMng,1); 
	resultBuffer->setScore(inTuple->getScore());
	childDescCursor++;
	return SUCCESS;
}

int NavigationalGetRelative::getAllChildrenOneByOne()
{
	//in this method, we get all children of node at index "index" in the input
	//witness tree. each is output one at a time

	if (inclusive && firstTime)
	{
		firstTime = false;
		resultBuffer->copyTree(inTuple);

		ComplexListNode nd;
		nd = *((ComplexListNode *)inTuple->getNodeByIndex(index));
		nd.setNRE(assignedNRE);
		resultBuffer->insertNode(index+1,&nd,dataMng);
		return SUCCESS;
	}

	//we keep a cursor that points to the child to be output this time
	if (childDescCursor == -1)
	{
		//first time here
		int oldIndex = index;
		int sz = inTuple->length();
		inTuple->switchToComplex(dataMng);
		//get teh children from the DB
		EvaluatorClass::GetChildren(inTuple,index,dataMng,fileid,assignedNRE);
		if (sz == inTuple->length())
			return FAILURE;
		resultBuffer->copyTree(inTuple);
		childDescCursor = oldIndex + 1;
		childDescLastIndex = inTuple->length() - sz + oldIndex;
		//write the curr child to resultBuffer
		//((ComplexListNode *)inTuple->getNodeByIndex(childDescCursor))->setNRE(assignedNRE);
		resultBuffer->appendList((ComplexListNode *)inTuple->getNodeByIndex(childDescCursor),dataMng,1);
		childDescCursor++;
		return SUCCESS;
	}
	if (childDescCursor > childDescLastIndex)
	{
		//we output the last child
		childDescCursor = -1;
		return FAILURE;
	}

	//delete the last child you output from resultBuffer and write teh new child
	resultBuffer->deleteNode(resultBuffer->length() -1);
	//((ComplexListNode *)inTuple->getNodeByIndex(childDescCursor))->setNRE(assignedNRE);
	resultBuffer->appendList((ComplexListNode *)inTuple->getNodeByIndex(childDescCursor),dataMng,1); 
	resultBuffer->setScore(inTuple->getScore());
	childDescCursor++;
	return SUCCESS;
}

int NavigationalGetRelative::getAllAncsTogether()
{
	//in this method, we get all ancs of a node til the root and output them all together
	// with the node at index "index"
	resultBuffer->copyTree(inTuple);

	while (index != FAILURE)
	{	
		//get the one ancs at aa time and write it to resultBuffer
		int r = EvaluatorClass::getAncs(resultBuffer,index,1,dataMng,fileid,assignedNRE);
		if (r == FAILURE)
			return SUCCESS;
		if (((ComplexListNode *)resultBuffer->getNodeByIndex(r))->GetData()->getFlag() != ELEMENT_NODE)
		{
			resultBuffer->deleteNode(r);
			return SUCCESS;
		}
		
		index = r;
	}
	return SUCCESS;
}

int NavigationalGetRelative::getAllDescTogether()
{
	//in this method, we get all desc of a node and output them all together
	// with the node at index "index"
	resultBuffer->copyTree(inTuple);
	//get all desc from DB
	EvaluatorClass::GetAllDesc(resultBuffer,index,dataMng,fileid,-1,assignedNRE);
	return SUCCESS;
}

int NavigationalGetRelative::getAllChildrenTogether()
{
	//in this method, we get all children of a node and output them all together
	// with the node at index "index"
	resultBuffer->copyTree(inTuple);
	//get all children from DB
	EvaluatorClass::GetChildren(resultBuffer,index,dataMng,fileid,assignedNRE);
	return SUCCESS;
}

int NavigationalGetRelative::getDescText()
{
	//in this method, we get all desc text nodes of a node and output them all together
	// with the node at index "index"
	resultBuffer->copyTree(inTuple);

	//get all desc text nodes from DB
	EvaluatorClass::GetAllDescText(resultBuffer,index,dataMng,fileid,-1,assignedNRE);
	return SUCCESS;
}

int NavigationalGetRelative::getChildText()
{
	//in this method, we get all children text nodes of a node and output them all together
	// with the node at index "index"
	resultBuffer->copyTree(inTuple);

	//get all children text nodes from DB
	EvaluatorClass::GetChildrenText(resultBuffer,index,dataMng,fileid,assignedNRE);
	return SUCCESS;
}

int NavigationalGetRelative::getAttr()
{
	//in this method, we get the attr node of a node 
	resultBuffer->copyTree(inTuple);

	//get attribute node from DB
	int r = EvaluatorClass::GetAttributes(resultBuffer,index,dataMng,fileid,-1,assignedNRE);
//	if (r != FAILURE)
//		((ComplexListNode *)resultBuffer->getNodeByIndex(actualIndex+1))->setNRE(assignedNRE);
	//if (r == FAILURE)
	//	return FAILURE;
	return SUCCESS;
}

void NavigationalGetRelative::getNextInput()
{
	//in this method, we get the next input tree from the input iterator and set some vars and flags
	input->next(inTuple);
	firstTime = true;
	lastSK = -1;
	childDescCursor = -1;
	if (inTuple)
	{
		inTuple->startFindNodesNRE(nre);
		index = inTuple->getNextIndexNRE();
		if (index == FAILURE)
		{
			inTuple = NULL;
			fileid = -1;
			globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"Evaluator",__FILE__,"Could not find node with passed NRE.");
			return;
		}
		if (inTuple->isSimple())
		{
			if ((ListNode *)inTuple->getNodeByIndex(index))
			{
				lastSK = ((ListNode *)inTuple->getNodeByIndex(index))->GetStartPos();
				fileIndex = ((ListNode *)inTuple->getNodeByIndex(index))->getFileIndex();
				fileid = EvaluatorClass::getFileID(fileIndex);
				if (fileid == -1)
				{
					globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"Evaluator",__FILE__,"File is unloaded in Timber.");
					lastSK = -1;
				}
			}
		}
		else
		{
			if ((ComplexListNode *)inTuple->getNodeByIndex(index))
			{
				lastSK = ((ComplexListNode *)inTuple->getNodeByIndex(index))->GetStartPos();
				fileIndex = ((ComplexListNode *)inTuple->getNodeByIndex(index))->getFileIndex();
				fileid = EvaluatorClass::getFileID(fileIndex);
				if (fileid == -1)
				{
					globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"Evaluator",__FILE__,"File is unloaded in Timber.");
					lastSK = -1;
				}
			}
		}
	}
}
