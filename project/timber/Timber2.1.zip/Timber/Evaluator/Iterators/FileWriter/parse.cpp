
#include "parse.hpp"

char QueryEvaluationTreeFileWriterNode::getIdentifier(void) { return 'w'; }

char FileWriterPlanParser::getIteratorIdentifier(void) { return 'w'; }

void 
FileWriterPlanParser::getQueryEvalNode(EvaluatorClass* evaluator, char* line, void* queryInput, QueryEvaluationTreeNode*& curr)
	    {
		char *token = strtok(line+2,",");
		char *fileName;
		if (token == NULL)
		{
		    globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"Evaluator",__FILE__,"Error input from file... expecting fileName... file writer line...");
		    curr=NULL; return;
		}
		fileName = new char[strlen(token)+1];
		strcpy(fileName,token);
		char newLine[MAX_FILE_INTERFACE_LINE_SIZE];
		if (((std::iostream *)queryInput)->eof() == 0)
		    ((std::iostream *)queryInput)->getline(newLine,MAX_FILE_INTERFACE_LINE_SIZE);
		else
		{
		    globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"Evaluator",__FILE__,"Unexpected end of file... val join line...");
		    curr=NULL; return;
		}
		QueryEvaluationTreeNode *oper = evaluator->getQueryEvalNode(newLine,queryInput);
		if (oper == NULL)
		{
		    globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"Evaluator",__FILE__,"Unexpected operand returned... fileWriter line...");
		    curr=NULL; return;
		}
		curr = new QueryEvaluationTreeFileWriterNode(oper,fileName);
	    }

