#include "../../Evaluator/EvaluatorClass.h"

#include "QueryEvaluationTreeFileWriterNode.h"

#include "FileWriterIterator.h"
#include "extra.h"

void QueryEvaluationTreeFileWriterNode::processQueryEvalNode(EvaluatorClass* evaluator, IteratorClass*& curr)
	    {
		IteratorClass *opr = evaluator->processQueryEvalNode(getOperand());
		if (opr == NULL)
		{
		    globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"Evaluator",__FILE__, "operand returned is NULL. file writer process eval node..." );
		    curr=NULL; return;
		}
		curr = new FileWriterIterator(opr,getFileName(),evaluator->getDataManager());
		setFileName(NULL);
	    }

