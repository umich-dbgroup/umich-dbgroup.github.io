#include "../../Evaluator/EvaluatorClass.h"

#include "extra.h"

class PhraseFinderPlanParser
{
public:

	static char getIteratorIdentifier(void) ;

	static void getQueryEvalNode(EvaluatorClass* evaluator, char* line, void* queryInput, QueryEvaluationTreeNode*& curr) ;

} ;

#ifndef WIN32

extern "C" char getIteratorIdentifier(void)
{
	return PhraseFinderPlanParser::getIteratorIdentifier() ;
} ;

extern "C" void getQueryEvalNode(EvaluatorClass* evaluator, char* line, void* queryInput, QueryEvaluationTreeNode*& curr)
{
	return PhraseFinderPlanParser::getQueryEvalNode(evaluator, line, queryInput, curr) ;
} ;

#endif
