/*
COPYRIGHT  � 2000-2004 
THE REGENTS OF THE UNIVERSITY OF MICHIGAN
ALL RIGHTS RESERVED

PERMISSION IS GRANTED TO USE, COPY, CREATE DERIVATIVE WORKS AND REDISTRIBUTE THIS SOFTWARE AND SUCH DERIVATIVE WORKS FOR 
NONCOMMERCIAL EDUCATION AND RESEARCH PURPOSES, SO LONG AS NO FEE IS CHARGED, AND SO LONG AS THE COPYRIGHT NOTICE ABOVE, 
THIS GRANT OF PERMISSION, AND THE DISCLAIMER BELOW APPEAR IN ALL COPIES MADE; AND SO LONG AS THE NAME OF THE UNIVERSITY 
OF MICHIGAN IS NOT USED IN ANY ADVERTISING OR PUBLICITY PERTAINING TO THE USE OR DISTRIBUTION OF THIS SOFTWARE WITHOUT 
SPECIFIC, WRITTEN PRIOR AUTHORIZATION.

THIS SOFTWARE IS PROVIDED AS IS, WITHOUT REPRESENTATION FROM THE UNIVERSITY OF MICHIGAN AS TO ITS FITNESS FOR ANY PURPOSE, 
AND WITHOUT WARRANTY BY THE UNIVERSITY OF MICHIGAN OF ANY KIND, EITHER EXPRESS OR IMPLIED, INCLUDING WITHOUT LIMITATION THE 
IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE. THE REGENTS OF THE UNIVERSITY OF MICHIGAN SHALL 
NOT BE LIABLE FOR ANY DAMAGES, INCLUDING SPECIAL, INDIRECT, INCIDENTAL, OR CONSEQUENTIAL DAMAGES, WITH RESPECT TO ANY CLAIM 
ARISING OUT OF OR IN CONNECTION WITH THE USE OF THE SOFTWARE, EVEN IF IT HAS BEEN OR IS HEREAFTER ADVISED OF THE POSSIBILITY 
OF SUCH DAMAGES.
*/

#include "PhraseFinderIterator.h"

#define CONG_DBG 1

PhraseFinderIterator::PhraseFinderIterator(char *phrase, char *indexName,  char openFileIndex, NREType assignedNRE)
{
	this->phrase = phrase;
	this->indexName = indexName;
	this->openFileIndex = openFileIndex;
	this->assignedNRE = assignedNRE;

	this->offsets = NULL;
	this->inTuple = NULL;
	this->indices = NULL;

	if (!phrase)
	{
		globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"Evaluator",__FILE__,"Phrase is NULL.");
		return;
	}
	
	if (!indexName)
	{
		globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"Evaluator",__FILE__,"No index name passed.");
		return;
	}

	wordNum = wordCount(phrase);
	if (wordNum == 0)
	{
		globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"Evaluator",__FILE__,"We have 0 words.");
		return;
	}

	this->offsets = new int[wordNum];
	for (int i=0; i<wordNum; i++)
		this->offsets[i]=1;
	this->indices = new GistIndexAccess *[wordNum];
	inTuple = new WitnessTree *[wordNum];
    for (int i=0; i<wordNum; i++)
        inTuple[i] = NULL;

	extractWords(phrase, indices, offsets, indexName, openFileIndex,assignedNRE);

	getInputs();
	
	resultBuffer = new WitnessTree;
}

PhraseFinderIterator::~PhraseFinderIterator()
{
	delete resultBuffer;
	if (phrase) delete [] phrase;
	if (indexName) delete [] indexName;
	if (offsets) delete [] offsets;
	if (indices)
	{
		for (int i=0; i<wordNum; i++)
        {
            if (indices[i])
			    delete indices[i];
        }
		delete [] indices;
	}
	if (inTuple)
		delete [] inTuple;
}

void PhraseFinderIterator::next(WitnessTree *&node)
{

	if (!inTuple)
	{
		node = NULL;
		return;
	}
#ifdef EVAL_TIME_OUT
	clock_t currTime = clock();
	double queryDuration = (double)(currTime - gQueryStartTime) / CLOCKS_PER_SEC;
	if (queryDuration >= gTimeOutAfter)
	{
		globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"Evaluator",__FILE__,"Query Timed Out.");
		node = NULL;
		return;
	}
#endif
	bool finished = false;

	//first, get from the indices nodes that have different words in the phrase and are
	//the same node --> get the node that has the phrase
	if (getSameNodes(0,-1,-1,finished) == FAILURE)
	{
		//if this fails-->we ran out of inputs
		node = NULL;
		return;
	}
	else
	{
		//we have an output
		resultBuffer->initialize();
		resultBuffer->appendList((ListNode *)inTuple[0]->getBuffer(),1);
		node = resultBuffer;
		getInputs(0);
		return;
	}
	//node = NULL;
}

int PhraseFinderIterator::wordCount(char *str)
{
	//this method gets the number of words in the phrase str after
	//getting rid of leading, trailing and multiple spaces in the string

	//leading spaces
	int spaceNum = 0;
	while (str[spaceNum] == ' ')
		spaceNum++;
	if (spaceNum > 0)
		memcpy(str,str+spaceNum,strlen(str) - spaceNum + 1);

	if (str[0] == '\0')
		return 0;

	//trailing spaces and stars
	spaceNum = strlen(str);
	while (str[spaceNum-1] == ' ' || str[spaceNum-1] == '*')
		spaceNum--;

	spaceNum = strlen(str) - spaceNum;
	if (spaceNum > 0)
		str[strlen(str) - spaceNum] = '\0';

	if (str[0] == '\0')
		return 0;

	//multi middle spaces
	bool preSpace = false;
	int i = 0;
	while (str[i] != '\0')
	{
		if (str[i] == ' ')
		{
			if (preSpace)
			{
				spaceNum = 0;
				int origI = i;
				while (str[i] == ' ')
				{
					spaceNum++;
					i++;
				}
				if (spaceNum > 0)
					memcpy(str+origI,str+origI+spaceNum,strlen(str) - spaceNum - origI + 1);
			}
			else
				preSpace = true;
		}
		else
			preSpace = false;
		i++;
	}

	int cnt = 0;
	char *oldCurr = str;
	char *curr = strchr(str,' ');
	while (curr)
	{
		if (oldCurr[0] != '*')
			cnt++;
		curr++;
		oldCurr = curr;
		curr = strchr(curr,' ');
	}

	if (oldCurr[0] != '*')
		cnt++;
	return cnt;
}

void PhraseFinderIterator::extractWords(char *str, GistIndexAccess **indices, 
                                        int *offsets, char *indexName, char openFileIndex, NREType assignedNRE)
{
	//this method extracts the words from the phrase and 
    //initializes index accesses to read them
	char *curr = strchr(str,' ');
	char *oldCurr = str;
	int i = 0;
	char *word;
	bt_query_t *query;

	while (curr)
	{
		//extracting the word
		word =  new char[strlen(oldCurr) - strlen(curr)+1];
		strncpy(word,oldCurr,strlen(oldCurr) - strlen(curr));
		word[strlen(oldCurr) - strlen(curr)] = '\0';	
		if (word[0] == '*' && offsets)
			offsets[i] = strlen(word) + 1; 
		else
		{
			query = new bt_query_t(bt_query_t::bt_eq,word,NULL);
			indices[i] = new GistIndexAccess(indexName,query,STRING_INDEX,openFileIndex,assignedNRE);
			i++;
		}
		oldCurr = curr+1;
		curr = strchr(oldCurr,' ');
	}

	//TODO: should query be freed before another new below?

	word = new char[strlen(oldCurr)+1];
	strncpy(word,oldCurr,strlen(oldCurr));
	word[strlen(oldCurr)] = '\0';
	query = new bt_query_t(bt_query_t::bt_eq,word,NULL);
	indices[i] = new GistIndexAccess(indexName,query,STRING_INDEX,openFileIndex,assignedNRE);
}

void PhraseFinderIterator::getInputs(int which)
{
	//this method gets the next input of an index at index which, if which==-1, then all
	//indices are read for new inputs
	if (which == -1)
	{
		for (int i=0; i<wordNum; i++)
			indices[i]->next(inTuple[i]);
	}
	else
		indices[which]->next(inTuple[which]);
}

int PhraseFinderIterator::getSameNodes(int index, KeyType startKey, int offset, bool &finished)
{
	//this method gets from indices the same node (intersection). the node is guranteed to have all
	//the words in the phrase
	int limit = wordNum -1;
	if (index > limit)
		return SUCCESS;
	if (!inTuple[index])
	{
		finished = true;
		return FAILURE;
	}

	if (index == 0)
	{
		if (offsets[index] != 1)
		{
			int o = offsets[index]-1;
			while (((ListNode *)inTuple[index]->getBuffer())->GetOffset() < o) 
			{
				indices[index]->next(inTuple[index]);
				if (inTuple[index] == NULL)
				{
					finished = true;
					return FAILURE;
				}
			}
		}
		while (getSameNodes(index+1,((ListNode *)inTuple[index]->getBuffer())->GetStartPos(),
					((ListNode *)inTuple[index]->getBuffer())->GetOffset(),finished) 
							== FAILURE)
		{
			if (finished)
				return FAILURE;
			indices[index]->next(inTuple[index]);
			if (inTuple[index] == NULL)
			{
				finished = true;
				return FAILURE;
			}
			if (offsets[index] != 1)
			{
				int o = offsets[index]-1;
				while (((ListNode *)inTuple[index]->getBuffer())->GetOffset() < o) 
				{
					indices[index]->next(inTuple[index]);
					if (inTuple[index] == NULL)
					{
						finished = true;
						return FAILURE;
					}
				}
			}
		}
		return SUCCESS;
	}
	else
	{
	
		while (((ListNode *)inTuple[index]->getBuffer())->GetStartPos() < startKey)
		{
			indices[index]->next(inTuple[index]);
			if (inTuple[index] == NULL)
			{
				finished = true;
				return FAILURE;
			}
		}
		if (((ListNode *)inTuple[index]->getBuffer())->GetStartPos() > startKey)
		{
			finished = false;
			return FAILURE;
		}

		while (((ListNode *)inTuple[index]->getBuffer())->GetOffset() <= offset)
		{
			indices[index]->next(inTuple[index]);
			if (inTuple[index] == NULL)
			{
				finished = true;
				return FAILURE;
			}
			if (((ListNode *)inTuple[index]->getBuffer())->GetStartPos() > startKey)
			{
				finished = false;
				return FAILURE;
			}
		}
		int o = ((ListNode *)inTuple[index]->getBuffer())->GetOffset();
		o -= offsets[index];
		if (o == offset)
		{
			
			if (index == limit)
				return SUCCESS;
			else
				return getSameNodes(index+1,((ListNode *)inTuple[index]->getBuffer())->GetStartPos(),
				((ListNode *)inTuple[index]->getBuffer())->GetOffset(),finished);
		}
		else
		{
			finished = false;
			return FAILURE;
		}
	}
	//return SUCCESS;
}

