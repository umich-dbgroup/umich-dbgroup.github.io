
#include "parse.hpp"

char QueryEvaluationTreePhraseFinderNode::getIdentifier(void) { return 'n'; }

char PhraseFinderPlanParser::getIteratorIdentifier(void) { return 'n'; }

void 
PhraseFinderPlanParser::getQueryEvalNode(EvaluatorClass* evaluator, char* line, void* queryInput, QueryEvaluationTreeNode*& curr)
	    {
		// index name
		char *token = strtok(line+2,",");
		if (token == NULL)
		{
		    globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"Evaluator",__FILE__,"Error input from file... expecting assigned NRE... Phrase finder line...");
		    curr=NULL; return;
		}
		NREType assignedNRE = (NREType)atoi(token);
		if (assignedNRE < 1)
		{
		    globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"Evaluator",__FILE__,"NRE should be positive.");   
		    curr=NULL; return;
		}
		if (assignedNRE > evaluator->maxNRE)
		    evaluator->maxNRE = assignedNRE;

		token = strtok(NULL,",");
		char *indexName;
		if (token == NULL)
		{
		    globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"Evaluator",__FILE__,"Error input from file... expecting index name... phrase finder line...");
		    curr=NULL; return;
		}
		indexName = new char[strlen(token)+1];
		strcpy(indexName,token);

		// index file name
		token = strtok(NULL,",");
		char *fileName;
		if (token == NULL)
		{
		    globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"Evaluator",__FILE__,"Error input from file... expecting xml fileName... phrase finder line...");
		    delete [] indexName;      
		    curr=NULL; return;
		}
		fileName = new char[strlen(token)+1];
		strcpy(fileName,token);

		// phrases
		token = strtok(NULL,",");
		if (token == NULL)
		{
		    globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"Evaluator",__FILE__,"Error input from file... expecting phrase... phrase finder line...");
		    delete [] indexName;
		    delete [] fileName;
		    curr=NULL; return;
		}
		char *phrase = new char[strlen(token)+1];
		strcpy(phrase,token);

		curr  = new QueryEvaluationTreePhraseFinderNode(assignedNRE,indexName,fileName,phrase);
	    }

