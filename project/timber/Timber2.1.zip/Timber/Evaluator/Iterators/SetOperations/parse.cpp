
#include "parse.hpp"

char QueryEvaluationTreeSetOperationsNode::getIdentifier(void) { return 'T'; }

char SetOperationsPlanParser::getIteratorIdentifier(void) { return 'T'; }

void 
SetOperationsPlanParser::getQueryEvalNode(EvaluatorClass* evaluator, char* line, void* queryInput, QueryEvaluationTreeNode*& curr)
	    {
		int which;
		int length = -1;

		// types of set operation
		char *token = strtok(line+2,",");                    
		if (token == NULL)
		{
		    globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"Evaluator",__FILE__,"Error input from file... expecting which set operation... Set operations line...");
		    curr=NULL; return;
		}
		if (strcmp(token,"U") == 0)
		    which = UNION_OPERATOR;
		else if (strcmp(token,"I") == 0)
		    which = INTERSECTION_OPERATOR;
		else if (strcmp(token,"D") == 0)
		    which = DIFFERENCE_OPERATOR;
		else
		{
		    globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"Evaluator",__FILE__,"Error input from file... unrecognized set operation... Set operations line...");
		    curr=NULL; return;
		}


		// length
		token = strtok(NULL,",");
		if (token == NULL)
		    length = -1;
		else
		{
		    length = atoi(token);

		    if (length <= 0)
		    {
			globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"Evaluator",__FILE__,"Error input from file... length should be positive... Set operations line...");
			curr=NULL; return;
		    }
		}

		// return P/R
		bool returnPR = false;

		strtok(NULL,",");
		if (token != NULL)
		{
		    if (strcmp(token, "P"))
			returnPR = true;
		}

		// grab the set operands
		char newLine[MAX_FILE_INTERFACE_LINE_SIZE];
		if (((std::iostream *)queryInput)->eof() == 0)
		    ((std::iostream *)queryInput)->getline(newLine,MAX_FILE_INTERFACE_LINE_SIZE);
		else
		{
		    globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"Evaluator",__FILE__,"Unexpected end of file... set op line...");
		    curr=NULL; return;
		}
		QueryEvaluationTreeNode *oper1 = evaluator->getQueryEvalNode(newLine,queryInput);
		if (oper1 == NULL)
		{
		    globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"Evaluator",__FILE__,"Unexpected operand1 returned... set op line...");
		    curr=NULL; return;
		}
		if (((std::iostream *)queryInput)->eof() == 0)
		    ((std::iostream *)queryInput)->getline(newLine,MAX_FILE_INTERFACE_LINE_SIZE);
		else
		{
		    globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"Evaluator",__FILE__,"Unexpected end of file... set op line...");
		    delete oper1;
		    curr=NULL; return;
		}
		QueryEvaluationTreeNode *oper2 = evaluator->getQueryEvalNode(newLine,queryInput);
		if (oper2 == NULL)
		{
		    globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"Evaluator",__FILE__,"Unexpected operand2 returned... set op line...");
		    delete oper1;
		    curr=NULL; return;
		}
		curr = new QueryEvaluationTreeSetOperationsNode(oper1,oper2,which, length);
	    }

