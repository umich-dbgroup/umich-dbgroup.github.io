#include "../../Evaluator/EvaluatorClass.h"

#include "QueryEvaluationTreeSetOperationsNode.h"

#include "UnionIterator.h"
#include "IntersectionIterator.h"
#include "DifferenceIterator.h"
#include "extra.h"

void QueryEvaluationTreeSetOperationsNode::processQueryEvalNode(EvaluatorClass* evaluator, IteratorClass*& curr)
	    {
		IteratorClass *opr1 = evaluator->processQueryEvalNode(getOperand1());

		if (opr1 == NULL)
		{
		    globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"Evaluator",__FILE__, "operand1 returned is NULL. set operations process eval node..." );
		    curr=NULL; return;
		}
		IteratorClass *opr2 = evaluator->processQueryEvalNode(getOperand2());
		if (opr2 == NULL)
		{
		    globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"Evaluator",__FILE__, "operand2 returned is NULL. set operations process eval node..." );
		    delete opr1;
		    curr=NULL; return;
		}

		switch (getWhichOperator())
		{
		    case UNION_OPERATOR: curr = new UnionIterator(opr1,opr2,evaluator->getDataManager(),getLength()); break;
		    case INTERSECTION_OPERATOR: curr = new IntersectionIterator(opr1,opr2,evaluator->getDataManager(),getLength()); break;
		    case DIFFERENCE_OPERATOR: curr = new DifferenceIterator(opr1,opr2,evaluator->getDataManager(),getLength()); break;
		    default:
					      globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"Evaluator",__FILE__, "unrecognized set operation. set operations process eval node..." );
					      curr=NULL; return;
		}
	    }

