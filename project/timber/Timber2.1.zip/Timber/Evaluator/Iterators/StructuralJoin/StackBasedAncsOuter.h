/*
COPYRIGHT  � 2000-2004 
THE REGENTS OF THE UNIVERSITY OF MICHIGAN
ALL RIGHTS RESERVED

PERMISSION IS GRANTED TO USE, COPY, CREATE DERIVATIVE WORKS AND REDISTRIBUTE THIS SOFTWARE AND SUCH DERIVATIVE WORKS FOR 
NONCOMMERCIAL EDUCATION AND RESEARCH PURPOSES, SO LONG AS NO FEE IS CHARGED, AND SO LONG AS THE COPYRIGHT NOTICE ABOVE, 
THIS GRANT OF PERMISSION, AND THE DISCLAIMER BELOW APPEAR IN ALL COPIES MADE; AND SO LONG AS THE NAME OF THE UNIVERSITY 
OF MICHIGAN IS NOT USED IN ANY ADVERTISING OR PUBLICITY PERTAINING TO THE USE OR DISTRIBUTION OF THIS SOFTWARE WITHOUT 
SPECIFIC, WRITTEN PRIOR AUTHORIZATION.

THIS SOFTWARE IS PROVIDED AS IS, WITHOUT REPRESENTATION FROM THE UNIVERSITY OF MICHIGAN AS TO ITS FITNESS FOR ANY PURPOSE, 
AND WITHOUT WARRANTY BY THE UNIVERSITY OF MICHIGAN OF ANY KIND, EITHER EXPRESS OR IMPLIED, INCLUDING WITHOUT LIMITATION THE 
IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE. THE REGENTS OF THE UNIVERSITY OF MICHIGAN SHALL 
NOT BE LIABLE FOR ANY DAMAGES, INCLUDING SPECIAL, INDIRECT, INCIDENTAL, OR CONSEQUENTIAL DAMAGES, WITH RESPECT TO ANY CLAIM 
ARISING OUT OF OR IN CONNECTION WITH THE USE OF THE SOFTWARE, EVEN IF IT HAS BEEN OR IS HEREAFTER ADVISED OF THE POSSIBILITY 
OF SUCH DAMAGES.
*/

#ifndef __StackBasedAncsOuter_h
#define __StackBasedAncsOuter_h
#include <timber-compat.h>

#include "StackBasedAncs.h"
#include <float.h>

/**
* This class represents the binary stack-based join algorithm used in evaluating pattern
*   trees. The result of this join is sorted by ancs.
* @see WitnessTree
* @see stack
* @see SBJoinAncsStackNode
* @see DataMng
* @see IteratorClass
* @author Shurug Al-Khalifa 
* @version 1.0
*/

class StackBasedAncsOuter : public IteratorClass
{
public:
	/**
	Constructor.
	@param ancs the iterator from which we get ancs trees.
	@param desc the iterator from which we get desc trees.
	@param relation is the relation between the input nodes (ancs-desc or parent-child)
	@param distinguishedAncs is the index of the ancs to join in ancs input tree.
	@param distinguishedDesc is the index of the desc to join in desc input tree.
	@param leftSibling in ordered semantics, this is the index of the left sibling in the ancs
			tree. if it is -1, use unordered semantics.
	@param rightSibling in ordered semantics, this is the index of the right sibling in the ancs
			tree. if it is -1, use unordered semantics.
	@param projectWhich which to keep in the result of the join (ANCESTOR, BOTH).
	@param expectedDepth is the estimated depth of the ancs (nesting of ancs nodes within each
			other).
	@param volumeID is the id of the current volume.
	**/
	StackBasedAncsOuter(IteratorClass *ancs,IteratorClass *desc,	int relation, NREType ancsNRE,
				NREType descNRE, NREType leftSiblingNRE, NREType rightSiblingNRE, 
					int expectedDepth, DataMng *dataMng, bool nest , serial_t fileID);

	
	/**
	Destructor.
	releases mem used by output buffer and other arrays and buffers.
	**/
	~StackBasedAncsOuter();

	/**
	Access Method
	gets the next output from this iterator.
	@param node is a pointer that well be set to the output buffer or NULL (indicating that
	there are no more results).
	**/
	void next(WitnessTree *&node);

private:

	int HandleAncs();
	int HandleDesc();
	int PopStack(KeyType startPosition);
	int PushAncs();
	int AddToTopOfStack();
	int JoinWithAllStack();
	int JoinWithTopOnly();
	int MergeNodes(ListNode *ancsData, ComplexListNode *ancsDataComplex);
	int StartOutputLists(SBJoinAncsStackNode *node1);
//	int OutputNext(SBJoinAncsStackNode *node1);
	int CopyLists(SBJoinAncsStackNode *source, SBJoinAncsStackNode *target);
	int WriteBufferOrListRid(ContainerClass *cont1, ShoreList *list1, 
										  ContainerClass *cont2, ShoreList *list2);
	int WriteListRidToBuffer(ContainerClass *cont1, ShoreList *list,ContainerClass *cont2);
	void WriteContainerToBuffer(ContainerClass *cont1,ContainerClass *cont2,ShoreList *list);
	int GetOneRecord(ContainerClass *cont, char *str, int *strSize);
	int ProcessOneRecord(char *str, int strSize);
	int WriteBufferToItsList(ContainerClass *cont, ShoreList *list);
	int GetActualAncs(char *str, int strSize, int *strScanner, ListNode *ancsData, ComplexListNode *ancsDataComplex);
	bool DoWeHaveAList(char *str, int strSize, int *strScanner);
	void GetList(char *str, int strSize, int *strScanner, ShoreList *target);
	void GetBuffer(char *source, int strSize,int *strScanner,ContainerClass *target);
	//void GetScore(char *source, int strSize,int *strScanner,double *target);
	int JoinWithStackElement(int index);

	int CalculateRecordSize(SBJoinAncsStackNode *node1);
	int CalculateSubRecordSize(ContainerClass *cont, ShoreList *list);

	int OutputStackElement(int index);
	int OutputtingLists();

	int isAncsFirst();
	KeyType getStartKeyOf(WitnessTree *tree, NREType nre, char *str);
	int handleBottom();
	//temp method
	double resScore(double ancsScore, double descScore);

	double writeContainerToResult(ContainerClass *cont);
	void writeNRETableToBuffer(ContainerClass *buf, NRETable *nreTable);

	int writeAncsTreeToBuffer(ContainerClass *buf, WitnessTree *tree);
	int writeDescTreeToBuffer(ContainerClass *buf, WitnessTree *tree);
	int calculateSizeOfAncsTree(WitnessTree *tree);
	int calculateSizeOfDescTree(WitnessTree *tree);
	int calculateSizeOfNRETable(NRETable *tab);

	double readAncsIntoResult(ContainerClass *buf, ListNode *ancsData, ComplexListNode *ancsDataComplex);
	double readDescIntoResult(ContainerClass *buf);

	IteratorClass *ancs;
	IteratorClass *desc;
	WitnessTree *ancsTuple;
	WitnessTree *descTuple;
	 DataMng *dataMng;
	
	 bool nest;
	int relation;
	NREType ancsNRE;
	NREType descNRE;
	NREType leftSiblingNRE;
	NREType rightSiblingNRE;
	int expectedDepth;
	stack<SBJoinAncsStackNode> *ancsStack;

	int ancsNodeType;
	int ancsListNodeSize;

	
	int descNodeType;
	int descListNodeSize;

	bool firstTimeHere;
	bool getNewDesc;
	WitnessTree *resultBuffer;
	serial_t startID;
	lvid_t volumeID;
	serial_t fileID;
	rc_t rc;
	
	SBJoinAncsStackNode *stackElement;
	bool fromBuf;

	ContainerClass *readContainer;
	char *tmpStr; 
	char *readString;
	int readStringSize;
	bool outputtingStackBottomList;
	ShoreList selfListOutput;
	bool selfListExists;
	ContainerClass selfCurrentOutput;

	ShoreList bufferListOutput; 
	bool bufferListExists;
	ContainerClass bufferCurrentOutput;
	bool fileCreated;

	bool continueWithBottom;

	ListNode ancsData;
	ComplexListNode ancsDataComplex;

	int numWrites;
	bool continueWithDescList;
};
#endif
