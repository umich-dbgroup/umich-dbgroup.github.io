
#include "parse.hpp"

char QueryEvaluationTreeStructuralJoinNode::getIdentifier(void) { return 'J'; }

char StructuralJoinPlanParser::getIteratorIdentifier(void) { return 'J'; }

void 
StructuralJoinPlanParser::getQueryEvalNode(EvaluatorClass* evaluator, char* line, void* queryInput, QueryEvaluationTreeNode*& curr)
	    {
		// which algorithm
		char *token = strtok(line+2,",");
		if (token == NULL)
		{
		    globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"Evaluator",__FILE__,"Error input from file... expecting Algorithm... SJoin line...");
		    curr=NULL; return;
		}
		curr = new QueryEvaluationTreeStructuralJoinNode();
		if (strcmp(token,"A") == 0)
		    ((QueryEvaluationTreeStructuralJoinNode *)curr)->setAlgorithmChoice(JOIN_ALGORITHM_STACK_ANCS);
		else if (strcmp(token,"D") == 0)
		    ((QueryEvaluationTreeStructuralJoinNode *)curr)->setAlgorithmChoice(JOIN_ALGORITHM_STACK_DESC);
		else if (strcmp(token,"N") == 0)
		    ((QueryEvaluationTreeStructuralJoinNode *)curr)->setAlgorithmChoice(JOIN_ALGORITHM_STACK_NEGATIVE);
		else if (strcmp(token,"a") == 0)
		    ((QueryEvaluationTreeStructuralJoinNode *)curr)->setAlgorithmChoice(JOIN_ALGORITHM_STACK_OUTERANCS);
		else
		    //((QueryEvaluationTreeStructuralJoinNode *)curr)->setAlgorithmChoice(JOIN_ALGORITHM_STACK_OUTERDESC);
		{
		    globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"Evaluator",__FILE__,"Unexpected algorithm... SJoin line...");
		    delete curr;
		    curr=NULL; return;
		}

		// ancestor position
		token = strtok(NULL,",");
		if (token == NULL)
		{
		    globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"Evaluator",__FILE__,"Error input from file... expecting Ancestor NRE... SJoin line...");
		    delete curr;           
		    curr=NULL; return;
		}
		NREType ancsNRE = (NREType) atoi(token);
		if (ancsNRE < 1)
		{
		    globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"Evaluator",__FILE__,"NRE should be positive.");
		    delete curr;
		    curr=NULL; return;
		}
		((QueryEvaluationTreeStructuralJoinNode *)curr)->setAncsNRE(ancsNRE);
		if (ancsNRE > evaluator->maxNRE)
		    evaluator->maxNRE = ancsNRE;

		// descendent position
		token = strtok(NULL,",");
		if (token == NULL)
		{
		    globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"Evaluator",__FILE__,"Error input from file... expecting Desc NRE... SJoin line...");
		    delete curr;
		    curr=NULL; return;
		}
		NREType descNRE = (NREType) atoi(token);
		if (descNRE < 1)
		{
		    globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"Evaluator",__FILE__,"NRE should be positive.");
		    delete curr;
		    curr=NULL; return;
		}
		((QueryEvaluationTreeStructuralJoinNode *)curr)->setDescNRE(descNRE);
		if (descNRE > evaluator->maxNRE)
		    evaluator->maxNRE = descNRE;
		// left sibling position: -1
		token = strtok(NULL,",");
		if (token == NULL)
		{
		    globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"Evaluator",__FILE__,"Error input from file... expecting Left Sibling NRE... SJoin line...");
		    delete curr;
		    curr=NULL; return;
		}
		int leftNRE = atoi(token);
		if (leftNRE > evaluator->maxNRE)
		    evaluator->maxNRE = leftNRE;
		if (leftNRE == -1)
		    leftNRE =  NULL_NRE;
		((QueryEvaluationTreeStructuralJoinNode *)curr)->setLeftNRE((NREType)leftNRE);


		// right sibling position: -1
		token = strtok(NULL,",");
		if (token == NULL)
		{
		    globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"Evaluator",__FILE__,"Error input from file... expecting Right Sibling NRE... SJoin line...");
		    delete curr;           
		    curr=NULL; return;
		}
		int rightNRE = atoi(token);
		if (rightNRE > evaluator->maxNRE)
		    evaluator->maxNRE = rightNRE;
		if (rightNRE == -1)
		    rightNRE = NULL_NRE;
		((QueryEvaluationTreeStructuralJoinNode *)curr)->setRightNRE((NREType)rightNRE);


		if (leftNRE == NULL_NRE && rightNRE == NULL_NRE)
		    ((QueryEvaluationTreeStructuralJoinNode *)curr)->setOrderingSemantics(false);

		// expected depth: -1
		token = strtok(NULL,",");
		if (token == NULL)
		{
		    globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"Evaluator",__FILE__,"Error input from file... expecting Expected Depth... SJoin line...");
		    delete curr;
		    curr=NULL; return;
		}
		int depth = atoi(token);

		((QueryEvaluationTreeStructuralJoinNode *)curr)->setEstimatedDepth(depth);

		// relationship: ancs-desc or parent-child
		token = strtok(NULL,",");
		if (token == NULL)
		{
		    globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"Evaluator",__FILE__,"Error input from file... expecting Relationship... SJoin line...");
		    delete curr;
		    curr=NULL; return;
		}
		if (strcmp(token,"A") == 0)
		    ((QueryEvaluationTreeStructuralJoinNode *)curr)->setRelationship(JOIN_NODE_RELATION_DESCENDANT);
		else if (strcmp(token,"P") == 0)
		    ((QueryEvaluationTreeStructuralJoinNode *)curr)->setRelationship(JOIN_NODE_RELATION_CHILD);
		else
		{
		    globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"Evaluator",__FILE__,"Unrecognized relation... SJoin line...");
		    delete curr;
		    curr=NULL; return;
		}

		// keep which
		token = strtok(NULL,",");
		if (token == NULL)
		{
		    globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"Evaluator",__FILE__,"Error input from file... expecting ProjectWhich... SJoin line...");
		    delete curr;
		    curr=NULL; return;
		}
		if (strcmp(token,"A") == 0)
		{
		    ((QueryEvaluationTreeStructuralJoinNode *)curr)->setProjectWhich(ANCESTOR);
		    if (((QueryEvaluationTreeStructuralJoinNode *)curr)->getAlgorithmChoice() != JOIN_ALGORITHM_STACK_ANCS)
		    {
			globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"Evaluator",__FILE__,"Error input from file... Cannot project ancs unless using stack based ancs algorithm... SJoin line...");
			delete curr;
			curr=NULL; return;
		    }
		}
		else if (strcmp(token,"D") == 0)
		{
		    ((QueryEvaluationTreeStructuralJoinNode *)curr)->setProjectWhich(DESCENDANT);
		    if (((QueryEvaluationTreeStructuralJoinNode *)curr)->getAlgorithmChoice() != JOIN_ALGORITHM_STACK_DESC)
		    {
			globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"Evaluator",__FILE__,"Error input from file... Cannot project desc unless using stack based desc algorithm... SJoin line...");
			delete curr;
			curr=NULL; return;
		    }
		}
		else if (strcmp(token,"B") == 0)
		    ((QueryEvaluationTreeStructuralJoinNode *)curr)->setProjectWhich(BOTH);
		else
		{
		    globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"Evaluator",__FILE__,"Unrecognized project which... SJoin line...");
		    delete curr;
		    curr=NULL; return;
		}

		token = strtok(NULL,",");
		bool nest = false;
		if (token != NULL)
		{
		    if (strcmp(token,"N") == 0)
			nest = true;
		}
		((QueryEvaluationTreeStructuralJoinNode *)curr)->setNest(nest);

		// grab the ansc node
		char newLine[MAX_FILE_INTERFACE_LINE_SIZE];
		if (((std::iostream *)queryInput)->eof() == 0)
		    ((std::iostream *)queryInput)->getline(newLine,MAX_FILE_INTERFACE_LINE_SIZE);
		else
		{
		    globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"Evaluator",__FILE__,"Unexpected end of file... Sjoin line...");
		    delete curr;
		    curr=NULL; return;
		}
		QueryEvaluationTreeNode *ancs = evaluator->getQueryEvalNode(newLine,queryInput);
		if (ancs == NULL)
		{
		    globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"Evaluator",__FILE__,"Unexpected ancs returned... Sjoin line...");
		    delete curr;
		    curr=NULL; return;
		}

		// grab the desc node
		if (((std::iostream *)queryInput)->eof() == 0)
		    ((std::iostream *)queryInput)->getline(newLine,MAX_FILE_INTERFACE_LINE_SIZE);
		else
		{
		    globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"Evaluator",__FILE__,"Unexpected end of file... Sjoin line...");
		    delete curr;
		    delete ancs;
		    curr=NULL; return;
		}
		QueryEvaluationTreeNode *desc = evaluator->getQueryEvalNode(newLine,queryInput);
		if (desc == NULL)
		{
		    globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"Evaluator",__FILE__,"Unexpected desc returned... Sjoin line...");
		    delete curr;
		    delete ancs;
		    curr=NULL; return;
		}
		((QueryEvaluationTreeStructuralJoinNode *)curr)->setAncestor(ancs);
		((QueryEvaluationTreeStructuralJoinNode *)curr)->setDescendant(desc);
		evaluator->fileIDsArraySize++;
	    }

