/*
COPYRIGHT  � 2000-2004 
THE REGENTS OF THE UNIVERSITY OF MICHIGAN
ALL RIGHTS RESERVED

PERMISSION IS GRANTED TO USE, COPY, CREATE DERIVATIVE WORKS AND REDISTRIBUTE THIS SOFTWARE AND SUCH DERIVATIVE WORKS FOR 
NONCOMMERCIAL EDUCATION AND RESEARCH PURPOSES, SO LONG AS NO FEE IS CHARGED, AND SO LONG AS THE COPYRIGHT NOTICE ABOVE, 
THIS GRANT OF PERMISSION, AND THE DISCLAIMER BELOW APPEAR IN ALL COPIES MADE; AND SO LONG AS THE NAME OF THE UNIVERSITY 
OF MICHIGAN IS NOT USED IN ANY ADVERTISING OR PUBLICITY PERTAINING TO THE USE OR DISTRIBUTION OF THIS SOFTWARE WITHOUT 
SPECIFIC, WRITTEN PRIOR AUTHORIZATION.

THIS SOFTWARE IS PROVIDED AS IS, WITHOUT REPRESENTATION FROM THE UNIVERSITY OF MICHIGAN AS TO ITS FITNESS FOR ANY PURPOSE, 
AND WITHOUT WARRANTY BY THE UNIVERSITY OF MICHIGAN OF ANY KIND, EITHER EXPRESS OR IMPLIED, INCLUDING WITHOUT LIMITATION THE 
IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE. THE REGENTS OF THE UNIVERSITY OF MICHIGAN SHALL 
NOT BE LIABLE FOR ANY DAMAGES, INCLUDING SPECIAL, INDIRECT, INCIDENTAL, OR CONSEQUENTIAL DAMAGES, WITH RESPECT TO ANY CLAIM 
ARISING OUT OF OR IN CONNECTION WITH THE USE OF THE SOFTWARE, EVEN IF IT HAS BEEN OR IS HEREAFTER ADVISED OF THE POSSIBILITY 
OF SUCH DAMAGES.
*/

#include "SBJoinAncsStackNode.h"

SBJoinAncsStackNode::SBJoinAncsStackNode()
{
	SBJoinDescStackNode::SBJoinDescStackNode();
	this->initialize();
}

SBJoinAncsStackNode::~SBJoinAncsStackNode()
{
	//SBJoinDescStackNode::~SBJoinDescStackNode();
}

void SBJoinAncsStackNode::initialize()
{
	SBJoinDescStackNode::initialize();
	selfBuffer.Initialize();
	selfList.Initialize();
	descBuffer.Initialize();
	descList.Initialize();
	markedForOutput = false;
}

ContainerClass *SBJoinAncsStackNode::GetSelfBuffer()
{
	return &selfBuffer;
}

ContainerClass *SBJoinAncsStackNode::GetDescBuffer()
{
	return &descBuffer;
}


ShoreList *SBJoinAncsStackNode::GetSelfList()
{
	return &selfList;
}

ShoreList *SBJoinAncsStackNode::GetDescList()
{
	return &descList;
}

void SBJoinAncsStackNode::SetListsVolumeAndFileIDs(lvid_t volumeID,serial_t fileID)
{
	SBJoinDescStackNode::SetListsVolumeAndFileIDs(volumeID,fileID);
	
	selfList.SetVolumeID(volumeID);
	selfList.SetFileID(fileID);

	descList.SetVolumeID(volumeID);
	descList.SetFileID(fileID);
}

bool SBJoinAncsStackNode::hasBeenJoined()
{
	return SBJoinDescStackNode::hasBeenJoined();
}

void SBJoinAncsStackNode::setBeenJoined(bool beenJoined)
{
	SBJoinDescStackNode::setBeenJoined(beenJoined);
}

bool SBJoinAncsStackNode::IsMarkedForOutput()
{
	return this->markedForOutput;
}

void SBJoinAncsStackNode::SetMarkedForOutput(bool markedForOutput)
{
	this->markedForOutput = markedForOutput;
}

void SBJoinAncsStackNode::prepareToCopyDelete()
{
	SBJoinDescStackNode::prepareToCopyDelete();
	this->selfBuffer.nullifyContainer();
	this->descBuffer.nullifyContainer();
}
