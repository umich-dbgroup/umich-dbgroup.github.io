#include "../../Evaluator/EvaluatorClass.h"

#include "extra.h"

class StructuralJoinPlanParser
{
public:

	static char getIteratorIdentifier(void) ;

	static void getQueryEvalNode(EvaluatorClass* evaluator, char* line, void* queryInput, QueryEvaluationTreeNode*& curr) ;

} ;

#ifndef WIN32

extern "C" char getIteratorIdentifier(void)
{
	return StructuralJoinPlanParser::getIteratorIdentifier() ;
} ;

extern "C" void getQueryEvalNode(EvaluatorClass* evaluator, char* line, void* queryInput, QueryEvaluationTreeNode*& curr)
{
	return StructuralJoinPlanParser::getQueryEvalNode(evaluator, line, queryInput, curr) ;
} ;

#endif
