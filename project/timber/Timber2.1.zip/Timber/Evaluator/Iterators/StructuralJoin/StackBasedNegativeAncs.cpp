/*
COPYRIGHT  � 2000-2004 
THE REGENTS OF THE UNIVERSITY OF MICHIGAN
ALL RIGHTS RESERVED

PERMISSION IS GRANTED TO USE, COPY, CREATE DERIVATIVE WORKS AND REDISTRIBUTE THIS SOFTWARE AND SUCH DERIVATIVE WORKS FOR 
NONCOMMERCIAL EDUCATION AND RESEARCH PURPOSES, SO LONG AS NO FEE IS CHARGED, AND SO LONG AS THE COPYRIGHT NOTICE ABOVE, 
THIS GRANT OF PERMISSION, AND THE DISCLAIMER BELOW APPEAR IN ALL COPIES MADE; AND SO LONG AS THE NAME OF THE UNIVERSITY 
OF MICHIGAN IS NOT USED IN ANY ADVERTISING OR PUBLICITY PERTAINING TO THE USE OR DISTRIBUTION OF THIS SOFTWARE WITHOUT 
SPECIFIC, WRITTEN PRIOR AUTHORIZATION.

THIS SOFTWARE IS PROVIDED AS IS, WITHOUT REPRESENTATION FROM THE UNIVERSITY OF MICHIGAN AS TO ITS FITNESS FOR ANY PURPOSE, 
AND WITHOUT WARRANTY BY THE UNIVERSITY OF MICHIGAN OF ANY KIND, EITHER EXPRESS OR IMPLIED, INCLUDING WITHOUT LIMITATION THE 
IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE. THE REGENTS OF THE UNIVERSITY OF MICHIGAN SHALL 
NOT BE LIABLE FOR ANY DAMAGES, INCLUDING SPECIAL, INDIRECT, INCIDENTAL, OR CONSEQUENTIAL DAMAGES, WITH RESPECT TO ANY CLAIM 
ARISING OUT OF OR IN CONNECTION WITH THE USE OF THE SOFTWARE, EVEN IF IT HAS BEEN OR IS HEREAFTER ADVISED OF THE POSSIBILITY 
OF SUCH DAMAGES.
*/

#include "StackBasedNegativeAncs.h"	


StackBasedNegativeAncs::StackBasedNegativeAncs(IteratorClass *ancs,IteratorClass *desc,		
					int relation,	NREType ancsNRE,
					int expectedDepth,
					DataMng *dataMng, serial_t fileID
					)
{
	
	this->ancs = ancs;
	this->desc = desc;
	this->relation = relation;
	this->ancsNRE = ancsNRE;
	this->dataMng = dataMng;
	this->volumeID = dataMng->getVolumeID();
	this->expectedDepth = expectedDepth;

	tmpStr = NULL;
		readString = NULL;
	numWrites = 0;
	listNodeSize = sizeof(ListNode);   
	resultBuffer = new WitnessTree(LIST_NODE);
	readStringSize = 0 ;
	outputtingStackBottomList = false;
	bufferListExists = false;
	ancsStack = new stack<SBJoinAncsStackNode>(expectedDepth);
	fileCreated = true;
	this->fileID = fileID;
	readBuffer = new ListNode[ancsListLength];
	readContainer = new ContainerClass;
	ancs->next(ancsTuple);
	if (ancsTuple)
	{
		ancsListLength = ancsTuple->length();
		daa = ancsTuple->getIndexOfNRE(ancsNRE);//ancsTuple->getActualIndex(distinguishedAncs);
	}
	else
	{
		ancsListLength = 0;
		if (globalErrorInfo.doWeHaveAProblem())
		{
			descTuple = NULL;
			return;
		}
	}

	if (ancsListLength > 1)
		ancsListLong = true;
	else
		ancsListLong = false;
	desc->next(descTuple);

	if (!descTuple)
	{
		if (globalErrorInfo.doWeHaveAProblem())
		{
			ancsTuple = NULL;
			return;
		}
	}
	
	tmpStr = new char[gSettings->getIntegerValue("CONTAINER_SIZE",CONTAINER_SIZE_DEFAULT)];
	readString = new char[gSettings->getIntegerValue("CONTAINER_SIZE",CONTAINER_SIZE_DEFAULT)];
	
/*	rc = ss_m::create_file(volumeID, fileID,ss_m::t_regular);
	if (rc) 
	{
		stringstream msg;
		msg<<rc<<'\0';
		globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"Evaluator",__FILE__,msg.rdbuf()->str().c_str());
		ancsTuple = NULL;
		descTuple = NULL;
		return;				
	}
	fileCreated = true;*/
	int maxIDs = gSettings->getIntegerValue("MAX_ID_PER_FILE_STRUCTURAL_JOINS",10000);
	rc = ss_m::create_id(volumeID,maxIDs,startID);

	if (rc) 
	{
		stringstream msg;
		msg<<rc<<'\0';
		globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"Evaluator",__FILE__,msg.rdbuf()->str().c_str());
		ancsTuple = NULL;
		descTuple = NULL;			
		return;				
	}	
	numWrites = maxIDs;
}

StackBasedNegativeAncs::~StackBasedNegativeAncs()
{
	delete ancsStack;

	delete resultBuffer;

	if (tmpStr) delete [] tmpStr;

	if (readString) delete [] readString;
	if (readBuffer)
		delete [] readBuffer;

	if (readContainer)
		delete readContainer;
	


	if (fileCreated)
	{
		rc = ss_m::destroy_file(volumeID, fileID, true, numWrites);
		if (rc) 
		{
			stringstream msg;
			msg<<rc<<'\0';
			globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"Evaluator",__FILE__,msg.rdbuf()->str().c_str());	
		}
	}
	
	delete desc;
	delete ancs;
}


void StackBasedNegativeAncs::next(WitnessTree *&node)
{
	// this block will be entered only if there are lists to be output
	// meaning, we popped the last element in the stack and we want to
	// output its desc list. Since it is a pipeline, we need to have 
	// this block here
	if (outputtingStackBottomList)
	{
		int r = OutputtingLists();
		if (r == SUCCESS)
		{
			node = resultBuffer;
			return;
		}
		else if (r == EV_ERROR)
		{
			node  = NULL;
			return;
		}
	}

	// this is the main loop. When we are still having ancs and desc
	while (ancsTuple && descTuple)
	{
		if (((ListNode *)(ancsTuple->getNodeByIndex(daa)))->GetStartPos() 
			    < ((ListNode *)(descTuple->findNode(0)))->GetStartPos())
		{// ancs comes first
			int r = HandleAncs();
			if (r == SUCCESS)
			{
				node = resultBuffer;
				return;
			}
			else if (r == EV_ERROR)
			{
				node = NULL;
				return;
			}
			ancs->next(ancsTuple);
			if (ancsTuple)
				daa = ancsTuple->getIndexOfNRE(ancsNRE);
		}
		else
		{// desc comes first
			int r = HandleDesc();
			if (r == SUCCESS)
			{
				node = resultBuffer;
				return;
			}
			else if (r == EV_ERROR)
			{
				node = NULL;
				return;
			}
			desc->next(descTuple);	
		}
	}


	// now we need to finish desc
	while (descTuple)
	{
		int r = HandleDesc();
		if (r == SUCCESS)
		{
			node = resultBuffer;
			return;
		}
		else if (r == EV_ERROR)
		{
			node = NULL;
			return;
		}
		else
		{
			// if handleDesc returned FAILURE, this might mean that the stack
			// is empty. If it is, we are done
			if (ancsStack->IsEmpty())
			{
				node = NULL;
				return;
			}
			else
				desc->next(descTuple);
		}
	}



	// now we need to finish output what's in the stack 
	// passing -1 pops all the stack
	int r = PopStack(-1);
	if (r == SUCCESS)
	{
		node = resultBuffer;
		return;
	}
	else if (r == EV_ERROR)
	{
		node = NULL;
		return;
	}
	
	while (ancsTuple)
	{
		resultBuffer->initialize();
		resultBuffer->appendList((ListNode *)ancsTuple->getBuffer(),ancsTuple->length());
		node = resultBuffer;
		ancs->next(ancsTuple);
		if (ancsTuple)
			daa = ancsTuple->getIndexOfNRE(ancsNRE);
		return;
	}

	node = NULL;
}

int StackBasedNegativeAncs::OutputtingLists()
{
	// here we are outputting lists of the bottom of the stack. 
	// mergeNodes will produce output from current buffers and lists. if it returns 
	// FAILURE, then we should get next set of buffers and lists.
	if (MergeNodes((ListNode *)resultBuffer->getNodeByIndex(daa)) == SUCCESS)
		return SUCCESS;
	else
	{ //getting next set of lists and buffers.
		if (GetOneRecord(readContainer,readString, &readStringSize) == SUCCESS)
		{
			int r = ProcessOneRecord(readString, readStringSize);
			if (r == SUCCESS)
				return SUCCESS;
			else if (r == EV_ERROR)
				return EV_ERROR;
			else
			{
				if (stackElement->EmptyListOfBuffers(stackElement->GetDescList()))
					{

					}
					else
					{
						while (stackElement->GetDescList()->GetNext(readContainer) == SUCCESS)
						{
							if (GetOneRecord(readContainer,readString, &readStringSize) == SUCCESS)
							{
								r = ProcessOneRecord(readString, readStringSize);
								if (r == SUCCESS)
									return SUCCESS;
								else if (r == EV_ERROR)
									return EV_ERROR;
							}
						}
						stackElement->GetDescList()->Initialize();
					}
			}
		}
		else
		{
				if (stackElement->EmptyListOfBuffers(stackElement->GetDescList()))
					{

					}
					else
					{
						while (stackElement->GetDescList()->GetNext(readContainer) == SUCCESS)
						{
							if (GetOneRecord(readContainer,readString, &readStringSize) == SUCCESS)
							{
								int r = ProcessOneRecord(readString, readStringSize);
								if (r == SUCCESS)
									return SUCCESS;
								else if (r == EV_ERROR)
									return EV_ERROR;
							}
						}
						stackElement->GetDescList()->Initialize();
					}
		}
		if (getNewDesc)
			desc->next(descTuple);
		getNewDesc = false;
		outputtingStackBottomList = false;
	}
	return FAILURE;
}



int StackBasedNegativeAncs::HandleAncs()
{
	// pop stack as needed. if this returns success, it means we popped the bottom 
	// element in the stack and we need to output its list.
	int r = PopStack(((ListNode *)(ancsTuple->getNodeByIndex(daa)))->GetStartPos());
	if (r == SUCCESS)
		return SUCCESS;
	else if (r == EV_ERROR)
		return EV_ERROR;

	// no lists, just the node itself we needn't worry about buffers and so we 
	// just push it
	if (!ancsListLong)   
	{
		SBJoinAncsStackNode pushed;
		pushed.SetActualAncs(((ListNode *)(ancsTuple->getNodeByIndex(daa))));
		pushed.SetListsVolumeAndFileIDs(volumeID,fileID);
		ancsStack->push(&pushed);
		return FAILURE;
	}

	// now, the more complex case... we have lists that are common between nodes 
	// exp. A1B1C1 and A1B2C1 , we need to keep A1 on stack and the rest in buffers
	if (ancsStack->IsEmpty())
	{ // if stack is empty, just push the new ancs and make sure to put additional
		// things in buffer
		PushAncs();
		return FAILURE;
	}

	SBJoinAncsStackNode *topOfStack = ancsStack->GetTop();

	// so, we found out that A1 is common between the newcomer and the top of the stack
	// we need to add Bs and Cs to the buffer of the top of the stack
	if (topOfStack->GetActualAncs()->GetStartPos() 
			== ((ListNode *)(ancsTuple->getNodeByIndex(daa)))->GetStartPos())
	{
		if (AddToTopOfStack() == FAILURE)
			return EV_ERROR;
	}
	else
		PushAncs();

	return FAILURE;
}

int StackBasedNegativeAncs::HandleDesc()
{	// pop stack as needed. if this returns success, it means we popped the bottom 
	// element in the stack and we need to output its list.
	int r = PopStack(((ListNode *)(descTuple->findNode(0)))->GetStartPos()) ;
	if (r == SUCCESS)
		return SUCCESS;
	else if (r == EV_ERROR)
		return EV_ERROR;

	// if stack is empty, no need to output anything
	if (ancsStack->IsEmpty())
		return FAILURE; 

	if (relation == PARENT_CHILD) 
		return JoinWithTopOnly();
	else
		return JoinWithAllStack();
}


void StackBasedNegativeAncs::PushAncs()
{
	//we are pusjing an ancs into stack
	SBJoinAncsStackNode pushed;
	pushed.SetActualAncs(((ListNode *)(ancsTuple->getNodeByIndex(daa))));
	ancsStack->push(&pushed);
	ancsStack->GetTop()->SetListsVolumeAndFileIDs(volumeID,fileID);


	// adding to the buffer all data in ancs other than ancs itself
	for (int i =0; i < daa; i++)
		ancsStack->GetTop()->AddToBuffer(ancsStack->GetTop()->GetBuffer(),
		(char *)ancsTuple->getNodeByIndex(i),listNodeSize);
	
	for (int i = daa+1; i < ancsTuple->length(); i++)
		ancsStack->GetTop()->AddToBuffer(ancsStack->GetTop()->GetBuffer(),
		(char *)ancsTuple->getNodeByIndex(i),listNodeSize);
}


int StackBasedNegativeAncs::AddToTopOfStack()
{
	SBJoinAncsStackNode *topOfStack = ancsStack->GetTop();

	// if the buffer has not enough space to carry more data, write it to shore
	if (!(topOfStack->EnoughSpace(topOfStack->GetBuffer(),(ancsTuple->length()-1)*listNodeSize)))    
			// in buffer
		if (WriteBufferToItsList(topOfStack->GetBuffer(),topOfStack->GetListOfBuffers()) == FAILURE)
			return FAILURE;

	// copying all list nodes of ancs to buffer except the ancs itself
	for (int i =0; i < daa; i++)
		topOfStack->AddToBuffer(topOfStack->GetBuffer(),
					(char *)ancsTuple->getNodeByIndex(i),listNodeSize);

	for (int i = daa+1; i < ancsTuple->length(); i++)
		topOfStack->AddToBuffer(topOfStack->GetBuffer(),
					(char *)ancsTuple->getNodeByIndex(i),listNodeSize);	
	return SUCCESS;
}

int StackBasedNegativeAncs::JoinWithAllStack()
{
	// it joins with all stack   ----> pop it all
	// mark them first
	for (int i=0; i<ancsStack->Size(); i++)
		ancsStack->GetByIndex(i)->SetMarkedForOutput(true);

	return PopStack(-1);
}


int StackBasedNegativeAncs::JoinWithTopOnly()
{

	// since we are joining with top of the stack only, we ned to check for level
	//condition because the relation must have been parent-child
	if (ancsStack->GetTop()->GetActualAncs()->GetLevel() == 
		                  ((ListNode *)(descTuple->findNode(0)))->GetLevel()-1)
	{
		// if we are joining with botom element in the stack, then output it
		if (ancsStack->GetTop() == ancsStack->GetBottom())
		{
			ancsStack->GetTop()->SetMarkedForOutput(true);
			return PopStack(-1);
		}
		else
		{ // if not, then copy its lists to the new top and still pop it
			SBJoinAncsStackNode *popped = ancsStack->Pop();
			popped->SetMarkedForOutput(true);
			if (CopyLists(popped,ancsStack->GetTop()) == FAILURE)
				return EV_ERROR;
		}
	}

	return FAILURE;
}

int StackBasedNegativeAncs::MergeNodes(ListNode *ancsData)
{
	// in this method, we are copying stuff to the resultBuffer
	resultBuffer->initialize();
	
	if (!(bufferCurrentOutput.IsEmpty()))
	{
		if (bufferCurrentOutput.GetScanCursor() == bufferCurrentOutput.GetAddCursor())
		{
			if (bufferListExists)
			{
				if (bufferListOutput.GetNext(&bufferCurrentOutput) == FAILURE)
					return FAILURE;
			}
			else
				return FAILURE;
		}
	}
	else
	{
		//this means that we just output this ancs, we are done with it
		if (((ListNode *)(resultBuffer->getNodeByIndex(daa,true)))->GetStartPos()
				== ancsData->GetStartPos())
			return FAILURE;
	}

	//copying the ancs list
	for (int i=0; i<daa; i++)
	{
		bufferCurrentOutput.GetNext(listNodeSize,(char *)readBuffer);
		resultBuffer->appendList(readBuffer,1);
	}

	//copying ancs itself
	resultBuffer->appendList(ancsData,1);

	//copying the rest of the list. remember, we are maintaining order
	for (int i=daa+1; i<ancsListLength; i++)
	{
		bufferCurrentOutput.GetNext(listNodeSize,(char *)readBuffer);
		resultBuffer->appendList(readBuffer,1);
	}

	return SUCCESS;
}

int StackBasedNegativeAncs::PopStack(KeyType startPosition)
{
	if (ancsStack->IsEmpty())
		return FAILURE;

	if (startPosition == -1)  // this means POP all
		startPosition = FLT_MAX;

	while (startPosition > ancsStack->GetTop()->GetActualAncs()->GetEndPos())
	{
		//it is time to pop the top element 
		SBJoinAncsStackNode *popped = ancsStack->Pop();
		if (ancsStack->IsEmpty())
		{ // if stack is empty, then output the lists of the just popped element
			stackElement = popped;
			return StartOutputLists(popped);
		}
		// if the stack is not empty then just copy lists of the popped to the new 
		// top of the stack.
		if (CopyLists(popped,ancsStack->GetTop()) == FAILURE)
			return EV_ERROR;
	}
	return FAILURE;
}

int StackBasedNegativeAncs::StartOutputLists(SBJoinAncsStackNode *node1)
{
	outputtingStackBottomList = true;
	getNewDesc = false;
	// node1 is the bottom element in the stack
	if (!(node1->EmptyListOfBuffers(node1->GetDescList())))
	{	//if it has a list then we need to read from it	
		if (node1->BufferExistsAndNotEmpty(node1->GetDescBuffer()))
			if (WriteBufferToItsList(node1->GetDescBuffer(),node1->GetDescList()) == FAILURE)
				return EV_ERROR;
	
		node1->GetDescList()->StartScan();
		
		while (node1->GetDescList()->GetNext(readContainer) == SUCCESS)
		{
			if (GetOneRecord(readContainer,readString, &readStringSize) == SUCCESS)
				return ProcessOneRecord(readString, readStringSize);
		}
		node1->GetDescList()->Initialize();
		outputtingStackBottomList = false;
		return FAILURE;
	}
	else
	{ // if node1 doesn't have a list, then we need to output from buffer.
		if (!(node1->BufferExistsAndNotEmpty(node1->GetDescBuffer())))
		{ // if it doesn't have a buffer, then we need to output node1 only if it is marked for
			// output
			outputtingStackBottomList = false;
			if (node1->IsMarkedForOutput())
				return FAILURE;
			return MergeNodes(node1->GetActualAncs());
		}
		else // if it has a buffer, we need to start reading from it.
			readContainer->CopyContainer(node1->GetDescBuffer());
		if (!(node1->IsMarkedForOutput()))
			return MergeNodes(node1->GetActualAncs());
		if (GetOneRecord(readContainer,readString, &readStringSize) == SUCCESS)
			return ProcessOneRecord(readString, readStringSize);
	}
	return FAILURE;
}

int StackBasedNegativeAncs::GetOneRecord(ContainerClass *cont, char *str, int *strSize)
{
	// getting size of record
	if (cont->GetNext(sizeof(int),(char *) strSize) == FAILURE)
		return FAILURE;

	// getting record itself
	if (cont->GetNext(*strSize,str) == FAILURE)
		return FAILURE;
	return SUCCESS;
}

int StackBasedNegativeAncs::ProcessOneRecord(char *str, int strSize)
{
	ListNode ancsData;
	int strScanner = 0;

	// get the ancs itself from str
	if (GetActualAncs(str,strSize,&strScanner,&ancsData) == FAILURE)
	{
		// if we don't get one, it means we a have a list from another element in the stack
			ContainerClass tmpCont;
			ShoreList tmpList;
			//get this list
			GetList(str,strSize,&strScanner,&tmpList);	
			
			int start = readContainer->GetScanCursor();
			int sizeCopied = readContainer->GetAddCursor() - start;
			if(stackElement->EmptyListOfBuffers(stackElement->GetDescList()))
			{
				stackElement->GetDescList()->SetVolumeID(volumeID);
				stackElement->GetDescList()->SetFileID(fileID);
				if (stackElement->GetDescList()->copyList(&tmpList,startID) == FAILURE)
					return EV_ERROR;
			
				if (startID.increment(1) == true)
					//overflow of shore logical ids
				{
					globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"Evaluator",__FILE__,"Shore Logical ID overflow.");
					return EV_ERROR;
				}
				if (sizeCopied != 0)
				{
					readContainer->GetData(start,sizeCopied,tmpStr);
					tmpCont.AddData(tmpStr,sizeCopied);
					if (stackElement->GetDescList()->AddToList(&tmpCont,startID) == FAILURE)
						return EV_ERROR;
					if (startID.increment(1) == true)
						//overflow of shore logical ids
					{
						globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"Evaluator",__FILE__,"Shore Logical ID overflow.");
						return EV_ERROR;
					}
				}
				
			}
			else
			{
				if (sizeCopied == 0)
				{
					if (stackElement->GetDescList()->simplePrependToList(&tmpList,startID) == FAILURE)
						return EV_ERROR;
				}
				else
				{
					readContainer->GetData(start,sizeCopied,tmpStr);
					tmpCont.AddData(tmpStr,sizeCopied);
					if (stackElement->GetDescList()->complexPrependToList(&tmpList,
						&tmpCont,startID) == FAILURE)
						return EV_ERROR;
				}
				if (startID.increment(1) == true)
					//overflow of shore logical ids
				{
					globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"Evaluator",__FILE__,"Shore Logical ID overflow.");
					return EV_ERROR;
				}
			}
		
			stackElement->GetDescList()->StartScan();
			while (stackElement->GetDescList()->GetNext(readContainer) == SUCCESS)	
			{
				if (GetOneRecord(readContainer,readString, &readStringSize) == SUCCESS)
					return ProcessOneRecord(readString, readStringSize);
			}
	}
	
	if (DoWeHaveAList(str, strSize, &strScanner))
	{   // initializing the buffer list
		bufferListExists = true;
		GetList(str,strSize,&strScanner,&bufferListOutput);	
		
		bufferListOutput.SetVolumeID(volumeID);
		bufferListOutput.SetFileID(fileID);
		bufferListOutput.StartScan();
		bufferListOutput.GetNext(&bufferCurrentOutput);
	}
	else
	{
		bufferListExists = false;
		GetBuffer(str, strSize, &strScanner, &bufferCurrentOutput);
	}

	// now we have our self data and buffer data in containers
	return MergeNodes(&ancsData);
	
}

int StackBasedNegativeAncs::GetActualAncs(char *str, int strSize, int *strScanner, ListNode *ancsData)
{
	// we are getting the ancs from str
	if (strSize - *strScanner < sizeof(*ancsData))
		return FAILURE;

	memcpy(ancsData,str + *strScanner, sizeof(*ancsData));
	*strScanner += sizeof(*ancsData);
	return SUCCESS;
}

bool StackBasedNegativeAncs::DoWeHaveAList(char *str, int strSize, int *strScanner)
{
	int subRecSize;
	strSize =strSize;
	memcpy(&subRecSize,str+(*strScanner),sizeof(int));
	if (subRecSize == 2*sizeof(serial_t))  
	{	// this means we have a list
		*strScanner += sizeof(int);
		return true;
	}
	else
		return false;

}

void StackBasedNegativeAncs::GetList(char *str, int strSize, int *strScanner, ShoreList *target)
{
	// we are getting list head and tail from str
	strSize =strSize;
	target->Initialize();
	serial_t listRid;
	memcpy(&listRid, str+(*strScanner), sizeof(serial_t));
	target->SetHead(listRid);
	*strScanner += sizeof(serial_t);

	memcpy(&listRid, str+(*strScanner), sizeof(serial_t));
	target->SetTail(listRid);
	*strScanner += sizeof(serial_t);
}

void StackBasedNegativeAncs::GetBuffer(char *str, int strSize, int *strScanner, ContainerClass *target)
{
	// we are getting a buffer from str
	target->Initialize();
	strSize =strSize;
	int bufferSize;
	memcpy(&bufferSize,str+(*strScanner),sizeof(int));
	*strScanner += sizeof(int);
	
	if (bufferSize == -1)
		return;

	target->AddData(str+(*strScanner),bufferSize);
	*strScanner += bufferSize;
}

int StackBasedNegativeAncs::CopyLists(SBJoinAncsStackNode *source, SBJoinAncsStackNode *target)
{
	int recSize;

	// we are copying lists of source to lists and buffers of target
	if (!(source->IsMarkedForOutput()))
	{
		recSize = CalculateRecordSize(source);

		if (!(target->EnoughSpace(target->GetDescBuffer(),recSize + sizeof(int))))
			if (WriteBufferToItsList(target->GetDescBuffer(),target->GetDescList()) == FAILURE)
				return FAILURE;

		// writing total size of record
		target->AddToBuffer(target->GetDescBuffer(),(char *)&recSize,sizeof(int));
		// writing the ancs itself
		target->AddToBuffer(target->GetDescBuffer(),(char *)source->GetActualAncs(),
											sizeof(*(source->GetActualAncs())));

		//writing size of buffer 
		recSize = CalculateSubRecordSize(source->GetBuffer(),source->GetListOfBuffers());
		if (recSize == 0)
			recSize = -1;
		target->AddToBuffer(target->GetDescBuffer(),(char *)&recSize,sizeof(int));
		// writing buffer
		if (WriteBufferOrListRid(source->GetBuffer(),source->GetListOfBuffers(),
									target->GetDescBuffer(),target->GetDescList()) == FAILURE)
									return FAILURE;

	}
	recSize = CalculateSubRecordSize(source->GetDescBuffer(),source->GetDescList());
	if (recSize != 0)
	{	// we are writing a list head and tail
		if (recSize == sizeof(serial_t) + sizeof(serial_t))
		{
			if (!(target->EnoughSpace(target->GetDescBuffer(),recSize + sizeof(int))))
				if (WriteBufferToItsList(target->GetDescBuffer(),target->GetDescList()) == FAILURE)
					return FAILURE;

			target->AddToBuffer(target->GetDescBuffer(),(char *)&recSize,sizeof(int));
		}
		else
		{
			if (!(target->EnoughSpace(target->GetDescBuffer(),recSize)))
				if (WriteBufferToItsList(target->GetDescBuffer(),target->GetDescList()) == FAILURE)
					return FAILURE;
		}

		if (WriteBufferOrListRid(source->GetDescBuffer(),source->GetDescList(),
								target->GetDescBuffer(),target->GetDescList()) == FAILURE)
								return FAILURE;
	}
	return SUCCESS;
}

int StackBasedNegativeAncs::CalculateRecordSize(SBJoinAncsStackNode *node1)
{
	int recSize = 0;

	recSize += sizeof(*(node1->GetActualAncs())) ; 
	recSize += CalculateSubRecordSize(node1->GetBuffer(), node1->GetListOfBuffers());
	recSize += sizeof(int);   // the size itself
	return recSize; 
}

int StackBasedNegativeAncs::CalculateSubRecordSize(ContainerClass *cont, ShoreList *list)
{
	int recSize = 0;

	if (list->IsEmpty())
		recSize += (cont->GetAddCursor());
	else
		recSize += (2*sizeof(serial_t));

	return recSize;
}

int StackBasedNegativeAncs::WriteBufferOrListRid(ContainerClass *cont1, ShoreList *list1, 
										  ContainerClass *cont2, ShoreList *list2)
{
	// here we are writing cont1 and list1 to cont2 and list2
	if (!(list1->IsEmpty()))
		return WriteListRidToBuffer(cont1,list1,cont2);
	else
		WriteContainerToBuffer(cont1,cont2,list2);
	return SUCCESS;
}


int StackBasedNegativeAncs::WriteListRidToBuffer(ContainerClass *cont1, ShoreList *list,
											  ContainerClass *cont2)
{
	// we are writing cont1 and list to cont2
	if (WriteBufferToItsList(cont1,list) == FAILURE)
		return FAILURE;

	serial_t h = list->GetHead();
	serial_t t = list->GetTail();
	SBJoinAncsStackNode::AddToBuffer(cont2,(char *) (&h),sizeof(list->GetHead()));
	SBJoinAncsStackNode::AddToBuffer(cont2,(char *) (&t),sizeof(list->GetTail()));
	return SUCCESS;
}

void StackBasedNegativeAncs::WriteContainerToBuffer(ContainerClass *cont1,
											  ContainerClass *cont2,ShoreList *list)
{
	// we are writing cont1 to cont2
	if (cont1->IsEmpty())
		return;

	list = list;
	int length = cont1->GetAddCursor();
	cont1->GetData(0,length,tmpStr);
	SBJoinAncsStackNode::AddToBuffer(cont2,tmpStr,length);
}

int StackBasedNegativeAncs::WriteBufferToItsList(ContainerClass *cont, ShoreList *list)
{
	if (cont->IsEmpty())
		return SUCCESS;

	if (list->IsEmpty())
	{
		serial_t currRecID = startID;
		if (startID.increment(1) == true)
			//overflow of shore logical ids
		{
			globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"Evaluator",__FILE__,"Shore Logical ID overflow.");
			return FAILURE;
		}
		if (SBJoinAncsStackNode::WriteBufferToList(cont,list,fileID,volumeID,currRecID,startID) == FAILURE)
			return FAILURE;
		if (startID.increment(1) == true)
			//overflow of shore logical ids
		{
			globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"Evaluator",__FILE__,"Shore Logical ID overflow.");
			return FAILURE;
		}
	}
	else
	{
		if (SBJoinAncsStackNode::WriteBufferToList(cont,list,startID) == FAILURE)
			return FAILURE;
		if (startID.increment(1) == true)
			//overflow of shore logical ids
		{
			globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"Evaluator",__FILE__,"Shore Logical ID overflow.");
			return FAILURE;
		}
	}
	cont->Initialize();
	return SUCCESS;
}


