#include "../../Evaluator/EvaluatorClass.h"

#include "QueryEvaluationTreeStructuralJoinNode.h"

#include "StackBasedAncs.h"
#include "StackBasedDesc.h"
#include "StackBasedNegativeAncs.h"
#include "StackBasedAncsProjAncs.h"
#include "StackBasedAncsOuter.h"
#include "extra.h"

void QueryEvaluationTreeStructuralJoinNode::processQueryEvalNode(EvaluatorClass* evaluator, IteratorClass*& curr)
	    {
		IteratorClass *ancs = evaluator->processQueryEvalNode(getAncestor());
		if (ancs == NULL)
		{
		    globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"Evaluator",__FILE__, "ancs returned is NULL. structural join process eval node..." );
		    curr=NULL; return;
		}
		IteratorClass *desc = evaluator->processQueryEvalNode(getDescendant());
		if (desc == NULL)
		{
		    globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"Evaluator",__FILE__, "desc returned is NULL. structural join process eval node..." );
		    delete ancs;
		    curr=NULL; return;
		}
		int relation = (getRelationship() == JOIN_NODE_RELATION_CHILD? PARENT_CHILD : ANCS_DESC);
		serial_t fileID = evaluator->fileIDsArray[evaluator->fileIDsArrayPtr];
		evaluator->fileIDsArrayPtr++;
		switch (getAlgorithmChoice())
		{
		    case JOIN_ALGORITHM_STACK_ANCS: 
			if (getProjectWhich() == ANCESTOR)
			    curr = new StackBasedAncsProjAncs(ancs,desc,relation,getAncsNRE(),
				    getDescNRE(),getLeftNRE(),
				    getRightNRE(),
				    getEstimatedDepth(),evaluator->getDataManager(),fileID);
			else
			    curr = new StackBasedAncs(ancs,desc,relation,getAncsNRE(),
				    getDescNRE(),getLeftNRE(),
				    getRightNRE(),
				    getEstimatedDepth(),evaluator->getDataManager(),getNest(),fileID);
			break;
		    case JOIN_ALGORITHM_STACK_DESC:
			curr = new StackBasedDesc(ancs,desc,relation,getAncsNRE(),
				getDescNRE(),getLeftNRE(),
				getRightNRE(),getProjectWhich(),
				getEstimatedDepth(),evaluator->getDataManager(),fileID);

			break;
		    case JOIN_ALGORITHM_STACK_NEGATIVE:
			curr = new StackBasedNegativeAncs(ancs,desc,relation,getAncsNRE(),
				getEstimatedDepth(),evaluator->getDataManager(),fileID);

			break;
		    case JOIN_ALGORITHM_STACK_OUTERANCS: 
			curr = new StackBasedAncsOuter(ancs,desc,relation,getAncsNRE(),
				getDescNRE(),getLeftNRE(),
				getRightNRE(),
				getEstimatedDepth(),evaluator->getDataManager(),getNest(),fileID);

			break;
		    default:
			globalErrorInfo.insertProblem(ERR_TYPE_ERROR,__LINE__,"Evaluator",__FILE__, "unrecognized algorithm. structural join process eval node..." );
			curr=NULL; return;
		}
	    }

