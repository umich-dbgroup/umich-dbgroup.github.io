#ifndef __UpdatesIterator_h
#define __UpdatesIterator_h
#include <timber-compat.h>

#include "IndexMng/IndexOperation/IndexIncrementalUpdate.h"
#include "Common/IteratorClass.h"
#include "QueryEvaluationTreeUpdatesNode.h"
#include "Evaluator/EvaluatorClass.h"
#include "AttributeInfo.h"
#include "../FileReader/FileReaderIterator.h"
#include "../FileWriter/FileWriterIterator.h"

#include <string>
#include <vector>
using std::vector;

#include <iostream>
#include <sstream>

// using namespace std;

/**
* The UpdatesIterator handles all updates to the data file.
*
* @see IteratorClass
* @see WitnessTree 
* @see EvaluatorClass
*/
class UpdatesIterator : public IteratorClass
{
public:
	/**
	* Constructor
	* initializes variables.
	* @param input is another iterator that produces the input trees to this iterator.
	* @param dataMng is an instance of the data manager
	* @param indexUpdater is an instance of IndexIncrementalUpdate and is used to update
	* the indices in response to changes in the data.
	**/
	UpdatesIterator(IteratorClass *input, DataMng *dataMng, IndexIncrementalUpdate *indexUpdater,
		int updateType, NREType nre, //char* indexToUpdate, 
		char* textValue1, char* textValue2, char* textValue3, char* textValue4,
		vector<AttributeInfo> repeated, int ind);

	/**
	* Destructor
	* frees the output buffer.
	*/
	~UpdatesIterator();
	
	/**
	* Access Method
	* gets the next output from this iterator.
	* @param node is a pointer that will be set to the output buffer or NULL (indicating that
	* there are no more results).
	*/
	void next(WitnessTree *&node);

private:

	void setInput(IteratorClass *input);

	bool setAttributeValue(char* attributeName, Value* newAttributeValue, Value* oldAttributeValue,
										DM_AttributeNode* attributeNode, DM_ElementNode* parentNode,
										IndexIncrementalUpdate* indexUpdater, DataMng* dataMng, FileIDType fileid);
	/**
	* an IteratorClass that produces input for this iterator.
	*/
	IteratorClass *input;

	/**
	* an instance of the data Manager
	*/
	DataMng *dataMng;

	/**
	* Used for updating indices to coincide with the udpated data
	*/
	IndexIncrementalUpdate *indexUpdater;

	/**
	* The input tree read from input (only a single input)
	*/
	WitnessTree *inTuple;

	/**
	* A buffer that holds the output tree.
	*/
	WitnessTree *resultBuffer;

	int updateType;
	NREType nre;

	//hack to limit (somewhat redundant) warning messages for attribute insertion:
	KeyType lastElementKeyProcessed;

	char *textValue1;
	char *textValue2;
	char *textValue3;
	char *textValue4;

	/**
	* stores the information about attributes
	*/
	std::vector<AttributeInfo> repeated;

	/**
	* temporary file used by FileWriter/FileReader where we dump all witness trees.
	* see comments in UpdatesIterator.cpp regarding logical IDs and flushing the pipeline.
	*/
	string tempFileName;

	int ind;
};

#endif

