#include "../../Evaluator/EvaluatorClass.h"

#include "QueryEvaluationTreeUpdatesNode.h"

#include "UpdatesIterator.h"
#include "extra.h"

void QueryEvaluationTreeUpdatesNode::processQueryEvalNode(EvaluatorClass* evaluator, IteratorClass*& curr)
	    {
		IteratorClass *opr = evaluator->processQueryEvalNode(getOperand());
		if (opr == NULL)
		    curr=NULL; return;
		curr = new UpdatesIterator(opr, evaluator->getDataManager(), new IndexIncrementalUpdate(evaluator->getIndexMng()), 
			getUpdateType(), getNRE(), //getIndexToUpdate(), 
			getTextValue1(), getTextValue2(), getTextValue3(), getTextValue4(),
			getRepeated(), evaluator->updatesCursor);
		evaluator->updatesCursor++;
	    }

