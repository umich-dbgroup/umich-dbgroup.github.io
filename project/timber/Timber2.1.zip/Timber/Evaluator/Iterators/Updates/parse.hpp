#include "../../Evaluator/EvaluatorClass.h"

#include "extra.h"

class UpdatesPlanParser
{
public:

	static char getIteratorIdentifier(void) ;

	static void getQueryEvalNode(EvaluatorClass* evaluator, char* line, void* queryInput, QueryEvaluationTreeNode*& curr) ;

} ;

#ifndef WIN32

extern "C" char getIteratorIdentifier(void)
{
	return UpdatesPlanParser::getIteratorIdentifier() ;
} ;

extern "C" void getQueryEvalNode(EvaluatorClass* evaluator, char* line, void* queryInput, QueryEvaluationTreeNode*& curr)
{
	return UpdatesPlanParser::getQueryEvalNode(evaluator, line, queryInput, curr) ;
} ;

#endif
