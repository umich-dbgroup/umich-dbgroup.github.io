
#ifndef _STRTIME_COMPAT_H
#define _STRTIME_COMPAT_H

char* strtime(char* timestr);

#endif
