
#ifndef _STRLWR_COMPAT_H
#define _STRLWR_COMPAT_H

#include <timber-compat.h>
char* strlwr(char* str);
char* strupr(char* str);

#endif
