// gist_btree.cc
// Copyright (c) 1997, 1998, Regents of the University of California
// $Id: gist_btree.cc,v 1.28 2000/03/15 00:24:09 mashah Exp $
#include <float.h>
#ifdef __GNUG__
#pragma implementation "gist_btree.h"
#endif

#include <string.h>
#include <stdlib.h>

#include <iostream>

using namespace std;

#include "gist_compat.h"	// for MAXINT/MININT
#include "gist_btree.h"
#include "gist_cursorext.h"	// for gist_cursorext_t::*
#include "gist_support.h"	// for print<>, parse<>, etc.
#include <assert.h>

bt_query_t::bt_query_t(bt_oper oper, void *val1, void *val2)
    : oper(oper), val1(val1), val2(val2), data1(NULL), data2(NULL)
{
}

bt_query_t::bt_query_t(bt_oper oper, void *val1, void *val2, void* data1, void* data2)
    : oper(oper), val1(val1), val2(val2), data1(data1), data2(data2)
{
}

bt_query_t::~bt_query_t()
{	
   if (val1 != NULL) delete val1;
   if (val2 != NULL) delete val2;
   if (data1 != NULL) delete data1;
   if (data2 != NULL) delete data2;
   val1 = NULL;
   val2 = NULL;
   data1 = NULL;
   data2 = NULL;
}

static int
int_cmp(const void *a, const void *b)
{
    // can't simply copy ints, alignment might be wrong
    int x, y;
    (void) memcpy((void *) &x, a, sizeof(x));
    (void) memcpy((void *) &y, b, sizeof(y));
    if (x < y) { 
        return -1;
    } else if (x > y) {
        return 1;
    } else {
        return 0;
    }
    // this doesn't work when a is close to -2^31
    //int res = (*((int *) a) - *((int *) b));
}

static int
double_cmp(const void *a, const void *b)
{
	double x, y;
    (void) memcpy((void *) &x, a, sizeof(x));
    (void) memcpy((void *) &y, b, sizeof(y));
    if (x < y) {
        return -1;
    } else if (x > y) {
        return 1;
    } else {
        return 0;
    }
}

static int
float_cmp(const void *a, const void *b)
{
	float x, y;
    (void) memcpy((void *) &x, a, sizeof(x));
    (void) memcpy((void *) &y, b, sizeof(y));
    if (x < y) {
        return -1;
    } else if (x > y) {
        return 1;
    } else {
        return 0;
    }
}

static int
str_cmp(const void *a, const void *b)
{
    return (strcmp((const char *) a, (const char *) b));
}

static int
listnodedbl_cmp(const void *a, const void *b)
{
	double sk1, sk2;
	short offset1, offset2;

	memcpy((void *) &sk1, a, sizeof(sk1));
	memcpy((void *) &sk2, b, sizeof(sk2));
	memcpy((void *) &offset1, (char*)a+2*sizeof(double)+sizeof(short),sizeof(offset1));
	memcpy((void *) &offset2, (char*)b+2*sizeof(double)+sizeof(short),sizeof(offset2));
	//double sk1 = *((double *) a);
	////skip two doubles (start key and end key) and one int (level) to read in the offset:
	//int offset1 = *((int *) a + 2* (sizeof(double)) + sizeof(int) );
	//double sk2 = *((double *) b);
	//int offset2 = *((int *) b + 2* (sizeof(double)) + sizeof(int) );

    if (sk1 < sk2) {
        return -1;
    } else if (sk1 > sk2) {
        return 1;
    } else if (offset1 < offset2) {
        return -1;
	} else if (offset1 > offset2) {
        return 1;
    } else
		return 0;
}

//static int
//nodedbl_cmp(const void *a, const void *b)
//{
//	double sk1, sk2;
//
//	memcpy((void *) &sk1, a, sizeof(sk1));
//	memcpy((void *) &sk2, b, sizeof(sk2));
//    if (sk1 < sk2) {
//        return -1;
//    } else if (sk1 > sk2) {
//        return 1;
//    } else
//		return 0;
//}
///////////////////////////////////////////////////////////////////////////////
// gist_btree::gist_btree - constructor
//
// Description:
//
///////////////////////////////////////////////////////////////////////////////

bt_ext_t::bt_ext_t(
    gist_ext_t::gist_ext_ids id,
    const char* name,
    PrintPredFct printPred,
    PrintDataFct printData,
    ParseFct parsePred,
    ParseFct parseData,
    ParseQueryFct parseQuery,
    CmpFct keyCmp,
    CmpFct dataCmp,
    SizeFct keySize,
    SizeFct dataSize,
    NegInftyFct negInftyKey,
    NegInftyFct negInftyData) :
    gist_ext_t(id, name, printPred, printData, parsePred, parseData, parseQuery),
    keyCmp(keyCmp), dataCmp(dataCmp), keySize(keySize),
    dataSize(dataSize), negInftyKey(negInftyKey), negInftyData(negInftyData)
{
};


///////////////////////////////////////////////////////////////////////////////
// gist_btree::insert - insert new entry in sort order
//
// Description:
//	- insert after rightmost slot with item <= (key, data)
// Return Values:
//      RCOKGist
///////////////////////////////////////////////////////////////////////////////

rc_tGist
bt_ext_t::insert(
    gist_p& page,
    const vec_tGist& key,
    const vec_tGist& dataPtr,
    shpid_tGist child)
{
    const void* data;
    if (page.is_leaf()) {
        data = dataPtr.ptr(0);
    } else {
        // by convention, our key also contains a data pointer (to
        // make the internal node keys unique); we don't want to use
        // this during _binSearch(), so we 'skip' over it.
	data = (const void *) (((char *) key.ptr(0)) + this->keySize(key.ptr(0)));
    }
    int slot = _binSearch(page, key.ptr(0), data, false);
    W_DOGist(page.insert(key, dataPtr, slot + 1, child));
    return RCOKGist;
}


///////////////////////////////////////////////////////////////////////////////
// gist_btree::remove - remove number of slots
//
// Description:
// Return Values:
//      RCOKGist
///////////////////////////////////////////////////////////////////////////////

rc_tGist 
bt_ext_t::remove(
    gist_p& page,
    const int slots[],
    int numSlots)
{
    for (int i = numSlots - 1; i >= 0; i--) {
        W_DOGist(page.remove(slots[i]));
    }
    return RCOKGist;
}


///////////////////////////////////////////////////////////////////////////////
// gist_btree::updateKey - nothing to do
//
// Description:
//	- B-tree partitions the data space, no BPs to update 
//
// Return Values:
//      RCOKGist
///////////////////////////////////////////////////////////////////////////////
#ifdef YUNYAO_GIST_WARNINGS_LEVEL_4
#pragma warning(disable: 4100)    
#endif 
rc_tGist
bt_ext_t::updateKey(
    gist_p& page,
    int& slot,
    const vec_tGist& newKey)
{
    return RCOKGist;
}
#ifdef YUNYAO_GIST_WARNINGS_LEVEL_4
#pragma warning(default: 4100)    
#endif 


///////////////////////////////////////////////////////////////////////////////
// gist_btree::findMinPen - return insertion subtree of (key, data)
//
// Description:
//	- return slof of rightmost item that is <= (key, data)
//
// Return Values:
//      RCOKGist
///////////////////////////////////////////////////////////////////////////////

void
bt_ext_t::findMinPen(
    const gist_p& page,
    const vec_tGist& key,
    const vec_tGist& data,
    int& slot)
{
    slot = _binSearch(page, key.ptr(0), data.ptr(0), false);
    assert(slot != -1);
}


///////////////////////////////////////////////////////////////////////////////
// gist_btree::search - return qualifying slots
//
// Description:
//	- return slof of rightmost item that is <= (key, data)
//
// Return Values:
//      RCOKGist
///////////////////////////////////////////////////////////////////////////////
#ifdef YUNYAO_GIST_WARNINGS_LEVEL_4
#pragma warning(disable: 4701)    
#endif 

void 
bt_ext_t::search(
    gist_p& page,
    const gist_query_t* query,
    int matches[],
    int& numMatches)
{
    const bt_query_t* q = (const bt_query_t *) query;
    int start, end; // start and end slot to scan

    numMatches = 0;
    switch (q->oper) {
    case bt_query_t::bt_nooper:
        start = 0;
	end = page.nrecs() - 1;
	break;
    case bt_query_t::bt_eq:
		// Nuwee: added for searching both key & data
		if(page.is_leaf() && (q->data1 != NULL))
			start = _binSearch(page, q->val1, q->data1, false);
		else
			start = _binSearch(page, q->val1, NULL, true);

        //start = _binSearch(page, q->val1, NULL, true);
	if (start == -1) {
	    // we're not going to find anything here
	    return;
	}
	// if we're at an internal node and val1 == key[start], there might be 
	// duplicates of val on the child to the left of child[start] (unless
	// we're already at the left boundary)
	if (!page.is_leaf() && start > 0 &&
	    keyCmp(page.rec(start).key(), q->val1) == 0) {

	    start--;
	}

	// The end of the range would be the rightmost slot with the same key,
	// but since _binSearch() can't find that or the position of the next higher
	// key, we pretend our range extends to the end of the page and check the 
	// keys as we go through the slots.
	end = page.nrecs() - 1;
	break;
	//Nuwee comment: this is not correct for le, since it finds only first item of duplicate
	//   case bt_query_t::bt_lt:
	//   case bt_query_t::bt_le:
	//       start = 0;
	//end = _binSearch(page, q->val1, NULL, true); 
	////should be le: end = page.nrecs()-1
	
	//Nuwee: hacked
	case bt_query_t::bt_lt:
		start = 0;
		end = _binSearch(page, q->val1, NULL, true); 
	break;
	case bt_query_t::bt_le:
		start = 0;
		end = page.nrecs()-1; 
	//end hack

	break;
    case bt_query_t::bt_gt:
    case bt_query_t::bt_ge: //bin search should return the first one in the series of duplicate, so ok
        start = _binSearch(page, q->val1, NULL, true);
	if (start == -1) start = 0;
	
	// if we're at an internal node and val1 == key[start], there might be 
	// duplicates of val on the child to the left of child[start] (unless
	// we're already at the left boundary)
	if (!page.is_leaf() && start > 0 &&
	    keyCmp(page.rec(start).key(), q->val1) == 0) {

	    start--;
	}
	end = page.nrecs() - 1;
	break;
	case bt_query_t::bt_betw:  // equiv. to >= val1 && <= val2
		start = _binSearch(page, q->val1, NULL, true);
		if (start == -1) start = 0;

		// if we're at an internal node and val1 == key[start], there might be 
		// duplicates of val on the child to the left of child[start] (unless
		// we're already at the left boundary)
		if (!page.is_leaf() && start > 0 &&
			keyCmp(page.rec(start).key(), q->val1) == 0) {

				start--;
			}
		// AN: if we have keys equal to val2, _binSearch sets end to be the first of these keys
		// rather than the last!  so, like bt_eq, we pretend our range extends to the end of the page
		// and check the keys as we go through the slots.
		end = page.nrecs() - 1;
		//end = _binSearch(page, q->val2, NULL, true);

	//Nuwee: hacked
	//case bt_query_t::bt_betw:  // equiv. to >= val1 && <= val2
	//	start = _binSearch(page, q->val1, NULL, true);
	//	if (start == -1) start = 0;
	//	end = page.nrecs() - 1;
	//end hack

	break;

	case bt_query_t::bt_betw_unique_keys:  // equiv. to >= val1 && <= val2 (but keys must be unique)
		start = _binSearch(page, q->val1, NULL, true);
		if (start == -1) start = 0;
		end = _binSearch(page, q->val2, NULL, true);
	break;
	default: // something's wrong
        assert(0);
    };

    bool hit = false;
    bool stop = false; // bt_eq might tell us to stop
    for (int slot = start; slot <= end; slot++) {
        if (page.is_leaf()) {
	    switch (q->oper) {
	    case bt_query_t::bt_nooper:
		hit = true;
		break;
	    case bt_query_t::bt_eq:

			if (keyCmp(page.rec(slot).key(), q->val1) == 0) {
				// Nuwee: added for searching both key & data
				if (q->data1 !=NULL) {
					if (dataCmp(page.rec(slot).elem(), q->data1) == 0) {
						hit = true;
					}
					else
					{
						hit = false;
						stop = true;
					}
				}
				else
					hit = true;
		} else {
		    hit = false;
		    stop = true; // no more equal keys on this page
		}
		break;
	    case bt_query_t::bt_lt:
	        if (slot != end || keyCmp(page.rec(slot).key(), q->val1) < 0) {
		    hit = true;
		}
		break;
	    case bt_query_t::bt_le:
		 //Nuwee: hacked
		 //hit = true; 
		//hack
			if (keyCmp(page.rec(slot).key(), q->val1) > 0){
				hit = false;
				stop = true;
			}
			else {
				hit = true;
			}
		break;
	    case bt_query_t::bt_gt:
	        if (slot != start || keyCmp(page.rec(slot).key(), q->val1) > 0) {
		    hit = true;
		}
		break;
	    case bt_query_t::bt_ge:
		// start positioned on rightmost item <= key, we must only return
		// items < key
	        if (slot != start || keyCmp(page.rec(slot).key(), q->val1) >= 0) {
		    hit = true;
		}
		break;
	    case bt_query_t::bt_betw:
			if (slot != start || keyCmp(page.rec(slot).key(), q->val1) >= 0) {
				hit = true;
			}

			// AN: since we're (artificially) searching to the end of the page (like bt_eq):
			if (keyCmp(page.rec(slot).key(), q->val2) > 0) {
				hit = false;
				stop = true; // no more equal keys on this page
			}

			//Nuwee: hacked
			//if ((keyCmp(page.rec(slot).key(),q->val1) >= 0) && (keyCmp(page.rec(slot).key(), q->val2) <= 0)) {
			//	hit = true;
			//}
			//else if (keyCmp(page.rec(slot).key(), q->val2) > 0) {
			//	hit = false;
			//	stop = true;
			//}
			//end hacked
		break;
		case bt_query_t::bt_betw_unique_keys:
			if (slot != start || keyCmp(page.rec(slot).key(), q->val1) >= 0) {
				hit = true;
			}
		break;
	    default: // something's fishy
	        assert(0);
	    }

	} else { // internal node
	    switch (q->oper) {
	    case bt_query_t::bt_lt: 
		if (slot == end) {
		    // only goto child if its smallest key < val1; _binSearch()
		    // might have found key == val1)
			//AN: why is this if () true else true ?
		    if (keyCmp(page.rec(slot).key(), q->val1) < 0) hit = true;
		} else {
		    hit = true;
		}
		break;
	    case bt_query_t::bt_eq: 
		// stop checking the entries when we hit one that's > val1
	        if (keyCmp(page.rec(slot).key(), q->val1) > 0) {
		    hit = false;
		    stop = true;
		} else {
		    hit = true;
		}
		break;
	    case bt_query_t::bt_betw:
			// AN: since we're (artificially) searching to the end of the page (like bt_eq):
			if (keyCmp(page.rec(slot).key(), q->val2) > 0) {
				hit = false;
				stop = true;
			}
			else {
				hit = true;
			}
		break;
	    default:
	        hit = true;
	    }
	}
	if (hit) {
	    matches[numMatches] = slot;
	    numMatches++;
	    hit = false;
	}
	if (stop) {
	    break;
	}
    }
}

#ifdef YUNYAO_GIST_WARNINGS_LEVEL_4
#pragma warning(default: 4701)    
#endif 
///////////////////////////////////////////////////////////////////////////////
// gist_btree:getKey - return pointer to key on page
//
// Description:
//
///////////////////////////////////////////////////////////////////////////////

void 
bt_ext_t::getKey(
    const gist_p& page,
    int slot,
    vec_tGist& key)
{
    const keyrec_tGist& tup = page.rec(slot);
    key.set(tup.key(), tup.klen());
}


///////////////////////////////////////////////////////////////////////////////
// gist_btree::pickSplit - choose split point that balances size of nodes
//
// Description:
// 	- Chooses a split point that roughly balances the size of the two new
//	  nodes. Also takes sizes of new entries into account.
//
// Preconditions:
// Postconditions:
// Notes:
//
// Return Values:
//      RCOKGist
///////////////////////////////////////////////////////////////////////////////

rc_tGist 
bt_ext_t::pickSplit(
    gist_p& page,
    int rightEntries[],
    int& numRight,
    const vec_tGist& oldBp,
    vec_tGist& leftBp,
    vec_tGist& rightBp,
    const vec_tGist& entry1,
    bool& oneGoesRight,
    const vec_tGist& entry2,
    bool& twoGoesRight)
{
    // first, count the number of bytes used for all keys (also the new ones)
    int totalBytes = 0;
    int slotCnt = page.nrecs();
    int i;
    for (i = 0; i < slotCnt; i++) {
	// for internal entries, we include the data pointers, because
	// these will also be distributed (and who knows, they might
	// even be varying length)
	totalBytes += page.rec(i).klen();
    }
    totalBytes += entry1.len(0);
    if (entry1.size() != 0) slotCnt++;
    totalBytes += entry2.len(0);
    if (entry2.size() != 0) slotCnt++;

    PosInfo entries[gist_p::max_scnt + 2];
    keyrec_tGist::hdr_s hdr1, hdr2;
    _loadPosInfo(page, entry1, entry2, hdr1, hdr2, entries);
    // now, accumulate entries until you exceed half the total size
    // (entries[] contains sizes for all entries in key/data order, including new entries)
    int total = 0;
    i = 0;
    while (total < totalBytes/2 && i < slotCnt) {
        total += entries[i].hdr->klen();
	i++;
    }
    assert(i != slotCnt); // can't be...

    // everything from slot i on goes right ...
    numRight = 0;
    oneGoesRight = false;
    twoGoesRight = false;
    for (int j = i; j < slotCnt; j++) {
	if (entries[j].slot > 0) {
	    rightEntries[numRight] = entries[j].slot;
	    numRight++;
	} else if (entries[j].slot == -1) {
	    oneGoesRight = true;
	} else {
	    assert(entries[j].slot == -2);
	    twoGoesRight = true;
	}
    }

    // the BP of the original node stays the same
    if (oldBp.size() != 0) {
	(void) memcpy(leftBp.ptr(0), oldBp.ptr(0), oldBp.len(0));
	const void *leftptr = leftBp.ptr(0);
	leftBp.set(leftptr, oldBp.len(0));
    } else {
        // this is what used to be the root;
	// the BP becomes -infinity
	void *leftptr = leftBp.ptr(0);
	negInftyKey(leftptr);
	int leftsz = this->keySize(leftptr);
	void *dataptr = (void *) ((char *) leftptr + leftsz);
	negInftyData(dataptr);
	leftsz += this->dataSize(dataptr);
	leftBp.set(leftptr, leftsz);
    }

    // the BP of the new right sibling is the item at the split point
    void* rightptr = rightBp.ptr(0);
    int rightlen;
    if (entries[i].slot > 0) {
        // take then BP from the page
	const keyrec_tGist& tup = page.rec(entries[i].slot);
	(void) memcpy(rightptr, tup.key(), tup.klen());
	rightlen = tup.klen();
	if (page.is_leaf()) {
	    // also copy the data ptr
	    (void) memcpy((void *) ((char *) rightptr + rightlen), tup.elem(), tup.elen());
	    rightlen += tup.elen();
	}
    } else {
        const vec_tGist* e;
	if (entries[i].slot == -1) {
	    e = &entry1;
	} else {
	    assert(entries[i].slot == -2);
	    e = &entry2;
	}
	(void) memcpy(rightptr, e->ptr(0), e->len(0));
	rightlen = e->len(0);
	if (page.is_leaf()) {
	    (void) memcpy((void *) ((char *) rightptr + (int) rightlen), e->ptr(1), e->len(1));
	    rightlen += e->len(1);
	}
    }
    rightBp.set(rightptr, rightlen);

    return RCOKGist;
}


/////////////////////////////////////////////////////////////////////////
// bt_ext_t::unionBp - generate BP
//
// Description:
//	- B-trees partition the data space, which means that BPs do not
//	  change when data is added to or delete from a page
//	- unfortunately, we can't generally provide the correct BP 
// 	  for bulk-loading (don't know when to return -\infty)
//
/////////////////////////////////////////////////////////////////////////
#ifdef YUNYAO_GIST_WARNINGS_LEVEL_4
#pragma warning(disable: 4100)    
#endif 

void
bt_ext_t::unionBp(
    const gist_p& page, // in
    vec_tGist& bp, // in/out
    bool bpIsValid, // in
    const vec_tGist& pred1, // in
    const vec_tGist& pred2, // in
    bool& bpChanged) // out
{
    bpChanged = false;
}

gist_cursorext_t*
bt_ext_t::queryCursor(
    const gist_query_t* query) const
{
    return gist_cursorext_t::gist_cursorext_list[gist_cursorext_t::cext_stack_id];
}
#ifdef YUNYAO_GIST_WARNINGS_LEVEL_4
#pragma warning(default: 4100)    
#endif 

bool 
bt_ext_t::check(
    const vec_tGist& bp,
    const vec_tGist& pred,
    int level)
{
    if (keyCmp(pred.ptr(0), bp.ptr(0)) < 0) return false;
    if (level > 1) {
        // check data contained in predicate
	void* bpData = (char *) bp.ptr(0) + keySize(bp.ptr(0));
	void* predData = (char *) pred.ptr(0) + keySize(pred.ptr(0));
	return (dataCmp(predData, bpData) >= 0);
    }
    return true;
}

int
bt_ext_t::_binSearch(
    const gist_p& page,
    const void* key,
    const void* data,
    bool keyOnly) // true: only compare keys
{
    int hi = page.nrecs() - 1;
    if (hi == -1) {
        // nothing on this page yet
	return -1;
    }
    int lo = 0;
    int mid;
    const void* midkey;
    const void* middata;
    int res;

    for (;;) {
	mid = (hi + lo) / 2;
        const keyrec_tGist& tup = page.rec(mid);
	midkey = tup.key();
	if (page.is_leaf()) {
	    middata = tup.elem();
	} else {
	    int sz = this->keySize(midkey);
	    middata = (const void *) (((char *) midkey) + sz);
	}
	res = keyCmp(key, midkey);
	if (!keyOnly && res == 0) {
	    res = dataCmp(data, middata);
	}
	if (res < 0) {
	    // key is smaller than midpoint
	    hi = mid - 1;
	} else if (res > 0) {
	    lo = mid + 1;
	} else {
	    // found an exact match, but not sure it's the first one
	    hi = mid; // not mid - 1, we might end up returning mid
	    if (hi == lo) return hi;
	}
	if (hi < lo) return hi;
    }
#if 0 // just for explanatory purposes
    if (res < 0) {
        return mid-1;
	// because mid-1 is our upper bound, but also our lower bound
	// (hi <= lo) 
    } else {
        // res > 0: lo = hi, because mid < hi and lo now = mid + 1
        return hi;
    }
#endif
}

// Determine where the two new entries would go on the page (which slots they
// would occupy). Returns this info through array of PosInfos, two of which will 
// contain info for new entries

	
#ifdef YUNYAO_GIST_WARNINGS_LEVEL_4
#pragma warning(disable: 4244)
#endif 
void
bt_ext_t::_loadPosInfo(
    gist_p& page,
    const vec_tGist& entry1,
    const vec_tGist& entry2,
    keyrec_tGist::hdr_s& hdr1, // in: hdr_s for 1st entry, needed for entries[]
    keyrec_tGist::hdr_s& hdr2, // in: hdr_s for 2nd entry, needed for entries[]
    PosInfo entries[]) // out: hdrs of all items of page + new entries, sorted in key/data order
{
    int cnt = page.nrecs();
    int numEntries = cnt;
    int k;
    for (k = 0; k < cnt; k++) {
        entries[k].hdr = &page.rec(k);
	entries[k].slot = k;
    }
    
    if (entry1.size() == 0) {
	// no entries to add to PosInfo, we're done
        return;
    }

    // Figure out where entry1/-2 would go.
    const void *data1, *data2;
    if (page.is_leaf()) {
	data1 = entry1.ptr(1);
	data2 = entry2.ptr(1);
    } else {
	// extract data portion from "key"
	data1 = (((char *) entry1.ptr(0)) + this->keySize(entry1.ptr(0)));
	data2 = (((char *) entry2.ptr(0)) + this->keySize(entry2.ptr(0)));
    }
    int oneSlot = _binSearch(page, entry1.ptr(0), data1, false) + 1;
    int twoSlot = -1;
    const vec_tGist* firstEntry = NULL; // new entry with "lower" slot index
    const vec_tGist* secondEntry = NULL; // new entry with "higher" slot index
    if (entry2.size() != 0) {
	twoSlot = _binSearch(page, entry2.ptr(0), data2, false) + 1;
	if (oneSlot == twoSlot) {
	    // we have to determine which one of the entries goes first
	    int res = keyCmp(entry1.ptr(0), entry2.ptr(0));
	    if (res == 0) {
	        res = dataCmp(data1, data2);
	    }
	    if (res < 0) {
	        firstEntry = &entry1;
		secondEntry = &entry2;
	    } else if (res > 0) {
	        firstEntry = &entry2;
		secondEntry = &entry1;
	    } else {
	        // res == 0: something's wrong (we've got perfect duplicates)
		assert(0);
	    }
	} else if (oneSlot < twoSlot) {
	    firstEntry = &entry1;
	    secondEntry = &entry2;
	} else { // oneSlot > twoSlot
	    firstEntry = &entry2;
	    secondEntry = &entry2;
	}
    } else {
        // we only have entry1
	secondEntry = &entry1;
    }
    int firstSlot = (oneSlot > twoSlot ? twoSlot : oneSlot);
    int secondSlot = (oneSlot > twoSlot ? oneSlot : twoSlot);
    bool oneGoesFirst = (firstEntry == &entry1);

    // insert one entry
    hdr1.klen = secondEntry->len(0);
    numEntries++;
    for (k = numEntries-1; k > secondSlot; k--) {
        entries[k] = entries[k-1];
    }
    entries[secondSlot].hdr = (keyrec_tGist *) &hdr1;
    entries[secondSlot].slot = (oneGoesFirst ? -2 : -1);

    // insert other entry
    if (entry2.size() != 0) {
	hdr2.klen = firstEntry->len(0);
	numEntries++;
	for (k = numEntries-1; k > firstSlot; k--) {
	    entries[k] = entries[k-1];
	}
	entries[firstSlot].hdr = (keyrec_tGist *) &hdr2;
	entries[firstSlot].slot = (oneGoesFirst ? -1 : -2);
    }
}

#ifdef YUNYAO_GIST_WARNINGS_LEVEL_4
#pragma warning(default: 4244)
#endif 

#ifdef YUNYAO_GIST_WARNINGS_LEVEL_4
#pragma warning(disable: 4100)    
#endif 

static int
int_size(const void *i)
{
    return sizeof(int);
}
#ifdef YUNYAO_GIST_WARNINGS_LEVEL_4
#pragma warning(disable: 4554)    
#endif

static void
int_negInfty(void *i)
{
    // can't use assignment, i might not be aligned properly
    int min = MININT;
    (void) (memcpy(i, ((void *) &min), sizeof(min)));
}
#ifdef YUNYAO_GIST_WARNINGS_LEVEL_4
#pragma warning(default: 4554)    
#endif

static void
flt_negInfty(void *i)
{
    // can't use assignment, i might not be aligned properly
    float min = FLT_MIN;
    (void) memcpy(i, (void *) &min, sizeof(min));
}

static void
dbl_negInfty(void *i)
{
    // can't use assignment, i might not be aligned properly
    double min = DBL_MIN;
    (void) memcpy(i, (void *) &min, sizeof(min));
}

static int
str_size(const void *s)
{
    return strlen((char *) s) + 1;
}

static int
dbl_size(const void *s)
{
    return sizeof(double);
}

static int
flt_size(const void *s)
{
    return sizeof(float);
}

static int
list_node_size(const void *n)
{
    return (sizeof(double) + sizeof(double) + sizeof(short)+ sizeof(short)+ sizeof(char)+ sizeof(int));
}
//static int
//node_size(const void *n)
//{
//    return (sizeof(double) + sizeof(double) + sizeof(short));
//}
#ifdef YUNYAO_GIST_WARNINGS_LEVEL_4
#pragma warning(default: 4100)    
#endif 

#ifdef YUNYAO_GIST_WARNINGS_LEVEL_4
#pragma warning(disable: 4554)    
#endif 
static void
list_node_negInfty(void *i)
{
	short minShort = SHRT_MIN;
	int minInt = INT_MIN;
	double minDbl = DBL_MIN;
	int sz = 0;
	char st = '\0';
	//start key
    memcpy((void *)((double *)i+sz), (void *) &minDbl, sizeof(minDbl));
	sz +=  sizeof(minDbl);
	//end key
    (void) memcpy((void *)((double *)i+sz), (void *) &minDbl, sizeof(minDbl));
	sz +=  sizeof(minDbl);
	//level
   (void) memcpy((void *)((short *)i+sz), (void *) &minShort, sizeof(minShort));
	sz +=  sizeof(minShort);
	//offset
	 (void) memcpy((void *)((short *)i+sz), (void *) &minShort, sizeof(minShort));
	sz +=  sizeof(minShort);
	//fileIndex
	 (void) memcpy((void *)((char *)i+sz), &st, sizeof(char));
	sz +=  sizeof(char);
	//nre
	 (void) memcpy((void *)((int *)i+sz), (void *) &minInt, sizeof(minInt));
	sz +=  sizeof(minInt);
}
//static void
//node_negInfty(void *i)
//{
//	short minShort = SHRT_MIN;
//	double minDbl = DBL_MIN;
//	int sz = 0;
//	//start key
//    memcpy((void *)((double *)i+sz), (void *) &minDbl, sizeof(minDbl));
//	sz +=  sizeof(minDbl);
//	//end key
//    (void) memcpy((void *)((double *)i+sz), (void *) &minDbl, sizeof(minDbl));
//	sz +=  sizeof(minDbl);
//	//level
//   (void) memcpy((void *)((short *)i+sz), (void *) &minShort, sizeof(minShort));
//	sz +=  sizeof(minShort);
//}
#ifdef YUNYAO_GIST_WARNINGS_LEVEL_4
#pragma warning(default: 4554)    
#endif 

static void
str_negInfty(void *s)
{
    *((char *) s) = '\0';
}
/*
// modified 07/17 int_cmp -> double_cmp
bt_ext_t bt_str_ext(gist_ext_t::bt_str_ext_id, "bt_str_ext",
    gist_support::printStringBtPred, gist_support::printInt,
    gist_support::parseString, gist_support::parseInt,
    gist_support::parseStringQuery, str_cmp, double_cmp,
    str_size, int_size, str_negInfty, int_negInfty);
*/

bt_ext_t bt_int_ext(gist_ext_t::bt_int_ext_id, "bt_int_ext",
    gist_support::printIntBtPred, gist_support::printData,
    gist_support::parseInt, gist_support::parseInt,
    gist_support::parseIntQuery, int_cmp, listnodedbl_cmp,
    int_size, list_node_size, int_negInfty, list_node_negInfty);

bt_ext_t bt_str_ext(gist_ext_t::bt_str_ext_id, "bt_str_ext",
    gist_support::printStringBtPred, gist_support::printData,
    gist_support::parseString, gist_support::parseString,
    //gist_support::parseStringQuery, str_cmp, str_cmp,
    gist_support::parseStringQuery, str_cmp, listnodedbl_cmp,
    str_size, list_node_size, str_negInfty, list_node_negInfty);

bt_ext_t bt_dbl_ext(gist_ext_t::bt_dbl_ext_id, "bt_dbl_ext",
    gist_support::printDoubleBtPred, gist_support::printData,
    gist_support::parseDouble, gist_support::parseString,
    gist_support::parseStringQuery, double_cmp, listnodedbl_cmp,
    dbl_size, list_node_size, dbl_negInfty, list_node_negInfty);

bt_ext_t bt_flt_ext(gist_ext_t::bt_flt_ext_id, "bt_flt_ext",
    gist_support::printFloatBtPred, gist_support::printData,
    gist_support::parseFloat, gist_support::parseString,
    gist_support::parseStringQuery, float_cmp, listnodedbl_cmp,
    flt_size, list_node_size, flt_negInfty, list_node_negInfty);

bt_ext_t bt_str_str_ext(gist_ext_t::bt_str_str_ext_id, "bt_str_str_ext",
    gist_support::printStringBtPred, gist_support::printData,
    gist_support::parseString, gist_support::parseString,
    gist_support::parseStringQuery, str_cmp, str_cmp,
    str_size, str_size, str_negInfty, str_negInfty);
//for inverted tex with offset
//bt_ext_t bt_int_offset_ext(gist_ext_t::bt_int_offset_ext_id, "bt_int_offset_ext",
//    gist_support::printIntBtPred, gist_support::printDataOffset,
//    gist_support::parseInt, gist_support::parseInt,
//    gist_support::parseIntQuery, int_cmp, listnodedbl_cmp,
//    int_size, list_node_size, int_negInfty, list_node_negInfty);
//
//bt_ext_t bt_str_offset_ext(gist_ext_t::bt_str_offset_ext_id, "bt_str_offset_ext",
//    gist_support::printStringBtPred, gist_support::printDataOffset,
//    gist_support::parseString, gist_support::parseString,
//    gist_support::parseStringQuery, str_cmp, listnodedbl_cmp,
//    str_size, list_node_size, str_negInfty, list_node_negInfty);
//
//bt_ext_t bt_dbl_offset_ext(gist_ext_t::bt_dbl_offset_ext_id, "bt_dbl_offset_ext",
//    gist_support::printDoubleBtPred, gist_support::printDataOffset,
//    gist_support::parseDouble, gist_support::parseString,
//    gist_support::parseStringQuery, double_cmp, listnodedbl_cmp,
//    dbl_size, list_node_size, dbl_negInfty, list_node_negInfty);
//
//bt_ext_t bt_flt_offset_ext(gist_ext_t::bt_flt_offset_ext_id, "bt_flt_offset_ext",
//    gist_support::printFloatBtPred, gist_support::printDataOffset,
//    gist_support::parseFloat, gist_support::parseString,
//    gist_support::parseStringQuery, float_cmp, listnodedbl_cmp,
//    flt_size, list_node_size, flt_negInfty, list_node_negInfty);

