// gist_unorderedn.h						-*- c++ -*-
// Copyright (c) 1997, Regents of the University of California
// $Id: gist_unorderedn.h,v 1.16 1998/11/12 20:25:44 marcel Exp $

#ifndef GIST_UNORDEREDN_H
#define GIST_UNORDEREDN_H

#ifdef __GNUG__
#pragma interface "gist_unorderedn.h"
#endif

/*
 * Gist extension for unordered nodes.
 *
 * The node layout implemented here is the same as that of R-trees:
 * items are stored in arbitrary order on the page (so that all items
 * must be examined when looking for a matching one or minimum-penalty
 * item).  This class does not implement any datatype-specific
 * behavior; this is delegated to gist_unordered_ext_t (note the
 * missing 'n'), which offers an interface similar to what is
 * described in the original Gist publication.
 */

#include "gist_ext.h"		// for gist_ext_t

class gist_unordered_ext_t; // vanilla Gist extension interface

#ifdef YUNYAO_GIST_WARNINGS_LEVEL_4
#pragma warning(disable: 4512)    
#endif
class gist_unorderedn_ext_t : public gist_ext_t {
public:

    const gist_unordered_ext_t& ext;

    virtual rc_tGist insert(
        gist_p& page,
	const vec_tGist& key,
	const vec_tGist& data,
	shpid_tGist child);

    virtual rc_tGist remove(
        gist_p& page,
	const int slots[],
	int numSlots);

    virtual rc_tGist updateKey(
        gist_p& page,
	int& slot,
	const vec_tGist& newKey);

    virtual void findMinPen(
        const gist_p& page,
	const vec_tGist& newKey,
	const vec_tGist& data,
	int& slot);

    virtual void search(
        gist_p& page,
	const gist_query_t* query,
	int matches[],
	int& numMatches);

    virtual void getKey(
        const gist_p& page,
	int slot,
	vec_tGist& key);

    virtual rc_tGist pickSplit(
        gist_p& page,
	int rightEntries[],
	int& numRight,
	const vec_tGist& oldBp,
	vec_tGist& leftBp,
	vec_tGist& rightBp,
	const vec_tGist& entry1,
	bool& oneGoesRight,
	const vec_tGist& entry2,
	bool& twoGoesRight);

    virtual void unionBp(
        const gist_p& page,
	vec_tGist& bp,
	bool bpIsValid,
	const vec_tGist& pred1,
	const vec_tGist& pred2,
	bool& bpChanged);

    virtual gist_cursorext_t* queryCursor(
	const gist_query_t* query) const;

    virtual bool check(
	const vec_tGist& bp,
	const vec_tGist& pred,
	int level);

    gist_unorderedn_ext_t(
        gist_ext_t::gist_ext_ids myId,
	const char* name,
	PrintPredFct printPred,
	PrintDataFct printData,
	ParseFct parsePred,
	ParseFct parseData,
	ParseQueryFct parseQuery,
	gist_unordered_ext_t& ext);

};

#ifdef YUNYAO_GIST_WARNINGS_LEVEL_4
#pragma warning(default: 4512)    
#endif
#endif // ifndef GIST_UNORDEREDN_H

