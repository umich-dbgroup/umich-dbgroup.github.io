You can still use these instructions to build documentation,
but the preferred (easier) method is to use the doxygen add-ins 
for visual studio, as described in the current README.txt file.

The perl files described in this readme may still be useful to 
set the group (enabling modules in the documentation) for the
various cpp files.

-AN

##########

1. get the newest Timber projects from sourcesafe
(put these in a new location, you won't be building the project, we'll just use the source files
for creating the documentation).

2. make all of the files writeable.

3. remove the folders from E:\Timber that you don't want documentation for.

4. run the fix-comments2.pl file to create modules in the files, for example:
(note: this will modify the source files, and we don't want to save these changes permanently!
that's why you downloaded a new version (in a new location) in step 1)

perl fix-comments2.pl E:/Timber/DataMng E:/Timber/Evaluator E:/Timber/IndexMng E:/Timber/Optimizer E:/Timber/StatisticalInfoMng E:/Timber/Timber E:/Timber/TimberS

5. type doxygen at the command line (in a directory where the file "Doxyfile" is available).

the documentation will be created in E:\docs-doxygen
(if you want the docs to be placed in another directory, then modify the Doxyfile settings)

6. delete the Timber projects that you just "got" from sourcesafe from the local drive (do not check them
back in, they have been modified by the perl program to make the documentation better (more readable)).

-Andrew