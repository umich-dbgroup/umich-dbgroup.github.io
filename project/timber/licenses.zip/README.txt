List of License files:
----------------------

1. Axis - Web Services (used in TIMBER SOAP Server)
2. Apache Software License (for Axis)
3. Berkeley DB (Sleepycat Software)
4. GiST - libgist v.2.0/amdb v.1.0 Licensing Information
5. GOLD Parser - Freeware License Agreement
6. gSOAP Public License - text
7. gSOAP Public License - detailed pdf
8. MS XML - Microsoft Copyright and Legal Information
9. Shore
10. Shore NewThreads
11. WordNet (Commerical Use License)