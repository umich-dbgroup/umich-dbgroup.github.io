//COPYRIGHT  � 2000-2004 
//THE REGENTS OF THE UNIVERSITY OF MICHIGAN
//ALL RIGHTS RESERVED
//
//PERMISSION IS GRANTED TO USE, COPY, CREATE DERIVATIVE WORKS AND REDISTRIBUTE 
//THIS SOFTWARE AND SUCH DERIVATIVE WORKS FOR NONCOMMERCIAL EDUCATION AND 
//RESEARCH PURPOSES, SO LONG AS NO FEE IS CHARGED, AND SO LONG AS THE 
//COPYRIGHT NOTICE ABOVE, THIS GRANT OF PERMISSION, AND THE DISCLAIMER 
//BELOW APPEAR IN ALL COPIES MADE; AND SO LONG AS THE NAME OF THE UNIVERSITY 
//OF MICHIGAN IS NOT USED IN ANY ADVERTISING OR PUBLICITY PERTAINING TO THE 
//USE OR DISTRIBUTION OF THIS SOFTWARE WITHOUT SPECIFIC, WRITTEN PRIOR AUTHORIZATION.
//
//THIS SOFTWARE IS PROVIDED AS IS, WITHOUT REPRESENTATION FROM THE UNIVERSITY 
//OF MICHIGAN AS TO ITS FITNESS FOR ANY PURPOSE, AND WITHOUT WARRANTY BY THE 
//UNIVERSITY OF MICHIGAN OF ANY KIND, EITHER EXPRESS OR IMPLIED, INCLUDING 
//WITHOUT LIMITATION THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS 
//FOR A PARTICULAR PURPOSE. THE REGENTS OF THE UNIVERSITY OF MICHIGAN SHALL 
//NOT BE LIABLE FOR ANY DAMAGES, INCLUDING SPECIAL, INDIRECT, INCIDENTAL, 
//OR CONSEQUENTIAL DAMAGES, WITH RESPECT TO ANY CLAIM ARISING OUT OF OR IN 
//CONNECTION WITH THE USE OF THE SOFTWARE, EVEN IF IT HAS BEEN OR IS 
//HEREAFTER ADVISED OF THE POSSIBILITY OF SUCH DAMAGES.

// Author: Stelios Paparizos
// e-mail: spapariz@umich.edu




using System;
using System.Collections;
using System.ComponentModel;
using System.Data;
using System.Diagnostics;
using System.Web;
using System.Web.Services;

namespace Timber.XQueryParser
{
	/// <summary>
	/// Summary description for Service1.
	/// Use the following url to access the service.
	/// http://localhost/xqsoap/xqueryservice.asmx
	/// </summary>
	//[SoapRpcService]
	[WebService(Namespace="http://Timber/XQParserService")]
	public class xqueryservice : System.Web.Services.WebService
	{
		public xqueryservice()
		{
			//CODEGEN: This call is required by the ASP.NET Web Services Designer
			InitializeComponent();
		}

		#region Component Designer generated code
		
		//Required by the Web Services Designer 
		private IContainer components = null;
				
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
		}

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		protected override void Dispose( bool disposing )
		{
			if(disposing && components != null)
			{
				components.Dispose();
			}
			base.Dispose(disposing);		
		}
		
		#endregion

	
//		[WebMethod]
//		public string HelloWorld()
//		{
//			return "Hello World";
//		}

		//[WebMethod, SoapRpcMethod]

		[WebMethod]
		public string xQueryToLogicalAlgebra(string query)
		{
			XQParser xqparser = new XQParser();
			string output = xqparser.parseString(query, 0);
			return output;
		}

		[WebMethod]
		public string xQueryFileToLogicalAlgebra(string queryFileName)
		{
			XQParser xqparser = new XQParser();
			string output = xqparser.parseFile(queryFileName, 0); 
			return output;
		}
	}
}
