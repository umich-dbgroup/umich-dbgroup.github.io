//COPYRIGHT  � 2000-2004 
//THE REGENTS OF THE UNIVERSITY OF MICHIGAN
//ALL RIGHTS RESERVED
//
//PERMISSION IS GRANTED TO USE, COPY, CREATE DERIVATIVE WORKS AND REDISTRIBUTE 
//THIS SOFTWARE AND SUCH DERIVATIVE WORKS FOR NONCOMMERCIAL EDUCATION AND 
//RESEARCH PURPOSES, SO LONG AS NO FEE IS CHARGED, AND SO LONG AS THE 
//COPYRIGHT NOTICE ABOVE, THIS GRANT OF PERMISSION, AND THE DISCLAIMER 
//BELOW APPEAR IN ALL COPIES MADE; AND SO LONG AS THE NAME OF THE UNIVERSITY 
//OF MICHIGAN IS NOT USED IN ANY ADVERTISING OR PUBLICITY PERTAINING TO THE 
//USE OR DISTRIBUTION OF THIS SOFTWARE WITHOUT SPECIFIC, WRITTEN PRIOR AUTHORIZATION.
//
//THIS SOFTWARE IS PROVIDED AS IS, WITHOUT REPRESENTATION FROM THE UNIVERSITY 
//OF MICHIGAN AS TO ITS FITNESS FOR ANY PURPOSE, AND WITHOUT WARRANTY BY THE 
//UNIVERSITY OF MICHIGAN OF ANY KIND, EITHER EXPRESS OR IMPLIED, INCLUDING 
//WITHOUT LIMITATION THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS 
//FOR A PARTICULAR PURPOSE. THE REGENTS OF THE UNIVERSITY OF MICHIGAN SHALL 
//NOT BE LIABLE FOR ANY DAMAGES, INCLUDING SPECIAL, INDIRECT, INCIDENTAL, 
//OR CONSEQUENTIAL DAMAGES, WITH RESPECT TO ANY CLAIM ARISING OUT OF OR IN 
//CONNECTION WITH THE USE OF THE SOFTWARE, EVEN IF IT HAS BEEN OR IS 
//HEREAFTER ADVISED OF THE POSSIBILITY OF SUCH DAMAGES.

// Author: Stelios Paparizos
// e-mail: spapariz@umich.edu
// Summary: A set of constants used for the parsing procedure.



namespace Timber.XQueryParser
{

	enum SymbolConstants : int
	{
		SymbolEof                                  = 0  , // (EOF)
		SymbolError                                = 1  , // (Error)
		SymbolWhitespace                           = 2  , // (Whitespace)
		SymbolCommentend                           = 3  , // (Comment End)
		SymbolCommentstart                         = 4  , // (Comment Start)
		SymbolApost                                = 5  , // ''
		SymbolMinus                                = 6  , // '-'
		SymbolExclameq                             = 7  , // '!='
		SymbolDollar                               = 8  , // '$'
		SymbolLparan                               = 9  , // '('
		SymbolLparanrparan                         = 10 , // '()'
		SymbolRparan                               = 11 , // ')'
		SymbolTimes                                = 12 , // '*'
		SymbolTimescolon                           = 13 , // '*:'
		SymbolTimescolontimes                      = 14 , // '*:*'
		SymbolComma                                = 15 , // ','
		SymbolDot                                  = 16 , // '.'
		SymbolDotdot                               = 17 , // '..'
		SymbolDiv                                  = 18 , // '/'
		SymbolDivdiv                               = 19 , // '//'
		SymbolDivgt                                = 20 , // '/>'
		SymbolColon                                = 21 , // ':'
		SymbolColontimes                           = 22 , // ':*'
		SymbolColoneq                              = 23 , // ':='
		SymbolQuestion                             = 24 , // '?'
		SymbolQuestiongt                           = 25 , // '?>'
		SymbolAt                                   = 26 , // '@'
		SymbolLbracket                             = 27 , // '['
		SymbolRbracket                             = 28 , // ']'
		SymbolRbracketrbracketgt                   = 29 , // ']]>'
		SymbolLbrace                               = 30 , // '{'
		SymbolLbracelbrace                         = 31 , // '{{'
		SymbolLbracerbrace                         = 32 , // '{}'
		SymbolPipe                                 = 33 , // '|'
		SymbolRbrace                               = 34 , // '}'
		SymbolRbracerbrace                         = 35 , // '}}'
		SymbolPlus                                 = 36 , // '+'
		SymbolLt                                   = 37 , // '<'
		SymbolLtexclamminusminus                   = 38 , // '<!--'
		SymbolLtexclamlbracketcdatalbracket        = 39 , // '<![CDATA['
		SymbolLtdiv                                = 40 , // '</'
		SymbolLtquestion                           = 41 , // '<?'
		SymbolLtlt                                 = 42 , // '<<'
		SymbolLteq                                 = 43 , // '<='
		SymbolEq                                   = 44 , // '='
		SymbolGt                                   = 45 , // '>'
		SymbolMinusminusgt                         = 46 , // '-->'
		SymbolGteq                                 = 47 , // '>='
		SymbolGtgt                                 = 48 , // '>>'
		SymbolAnd                                  = 49 , // AND
		SymbolAs                                   = 50 , // AS
		SymbolAscending                            = 51 , // ASCENDING
		SymbolAttribute                            = 53 , // ATTRIBUTE
		SymbolAttributelparan                      = 54 , // 'ATTRIBUTE('
		SymbolAttributelparanrparan                = 55 , // 'ATTRIBUTE()'
		SymbolAttributecoloncolon                  = 56 , // 'ATTRIBUTE::'
		SymbolAttributelbrace                      = 57 , // 'ATTRIBUTE{'
		SymbolBy                                   = 58 , // BY
		SymbolCase                                 = 59 , // CASE
		SymbolCast                                 = 60 , // CAST
		SymbolCastable                             = 61 , // CASTABLE
		SymbolChildcoloncolon                      = 62 , // 'CHILD::'
		SymbolCollation                            = 63 , // COLLATION
		SymbolCommentlparanrparan                  = 64 , // 'COMMENT()'
		SymbolContext                              = 65 , // CONTEXT
		SymbolDecimalliteral                       = 66 , // DecimalLiteral
		SymbolDeclare                              = 67 , // DECLARE
		SymbolDefault                              = 68 , // DEFAULT
		SymbolDefinefunction                       = 69 , // 'DEFINE FUNCTION'
		SymbolDefinevariabledollar                 = 70 , // 'DEFINE VARIABLE $'
		SymbolDescendantcoloncolon                 = 71 , // 'DESCENDANT::'
		SymbolDescendantminusorminusselfcoloncolon = 72 , // 'DESCENDANT-OR-SELF::'
		SymbolDescending                           = 73 , // DESCENDING
		SymbolDocumentlbrace                       = 75 , // 'DOCUMENT{'
		SymbolDocumentminusnodelparan              = 76 , // 'DOCUMENT-NODE('
		SymbolDocumentminusnodelparanrparan        = 77 , // 'DOCUMENT-NODE()'
		SymbolDquote                               = 78 , // DQuote
		SymbolElement                              = 79 , // ELEMENT
		SymbolElementlparan                        = 80 , // 'ELEMENT('
		SymbolElementlparanrparan                  = 81 , // 'ELEMENT()'
		SymbolElementlbrace                        = 82 , // 'ELEMENT{'
		SymbolElse                                 = 83 , // ELSE
		SymbolEmpty                                = 84 , // EMPTY
		SymbolEmptylparanrparan                    = 85 , // 'EMPTY()'
		SymbolEvery                                = 87 , // EVERY
		SymbolExcept                               = 88 , // EXCEPT
		SymbolExternal                             = 89 , // EXTERNAL
		SymbolFor                                  = 90 , // FOR
		SymbolFunction                             = 91 , // FUNCTION
		SymbolGe                                   = 92 , // GE
		SymbolGlobal                               = 93 , // GLOBAL
		SymbolGreatest                             = 94 , // GREATEST
		SymbolIdiv                                 = 96 , // IDIV
		SymbolIf                                   = 97 , // IF
		SymbolImport                               = 98 , // IMPORT
		SymbolIn                                   = 99 , // IN
		SymbolInstance                             = 100, // INSTANCE
		SymbolIntegerliteral                       = 101, // IntegerLiteral
		SymbolIntersect                            = 102, // INTERSECT
		SymbolIs                                   = 103, // IS
		SymbolIsnot                                = 104, // ISNOT
		SymbolItemlparanrparan                     = 105, // 'ITEM()'
		SymbolLax                                  = 106, // LAX
		SymbolLe                                   = 107, // LE
		SymbolLeast                                = 108, // LEAST
		SymbolLet                                  = 109, // LET
		SymbolMod                                  = 111, // MOD
		SymbolModule                               = 112, // MODULE
		SymbolNamespace                            = 113, // NAMESPACE
		SymbolNcname                               = 114, // NCName
		SymbolNe                                   = 115, // NE
		SymbolNillable                             = 116, // NILLABLE
		SymbolNodelparanrparan                     = 117, // 'NODE()'
		SymbolOf                                   = 118, // OF
		SymbolOr                                   = 119, // OR
		SymbolOrder                                = 120, // ORDER
		SymbolParentcoloncolon                     = 121, // 'PARENT::'
		SymbolPreserve                             = 122, // PRESERVE
		SymbolProcessingminusinstructionlparan     = 123, // 'PROCESSING-INSTRUCTION('
		SymbolReturn                               = 124, // RETURN
		SymbolSatisfies                            = 125, // SATISFIES
		SymbolSchema                               = 126, // SCHEMA
		SymbolSelfcoloncolon                       = 127, // 'SELF::'
		SymbolSkip                                 = 128, // SKIP
		SymbolSome                                 = 129, // SOME
		SymbolStable                               = 130, // STABLE
		SymbolStrict                               = 131, // STRICT
		SymbolStringliteral                        = 132, // StringLiteral
		SymbolStrip                                = 133, // STRIP
		SymbolTextlparanrparan                     = 134, // 'TEXT()'
		SymbolTextlbrace                           = 135, // 'TEXT{'
		SymbolTextlbracerbrace                     = 136, // 'TEXT{}'
		SymbolThen                                 = 137, // THEN
		SymbolTo                                   = 138, // TO
		SymbolTreat                                = 139, // TREAT
		SymbolType                                 = 140, // TYPE
		SymbolTypelparan                           = 141, // 'TYPE('
		SymbolTypeswitch                           = 142, // TYPESWITCH
		SymbolUnion                                = 143, // UNION
		SymbolValidate                             = 144, // VALIDATE
		SymbolValidation                           = 145, // VALIDATION
		SymbolVersion                              = 146, // VERSION
		SymbolWhere                                = 147, // WHERE
		SymbolXmlspace                             = 148, // XMLSPACE
		SymbolXquery                               = 149, // XQUERY
		SymbolAbbreviatedforwardstep               = 150, // <AbbreviatedForwardStep>
		SymbolAbbreviatedreversestep               = 151, // <AbbreviatedReverseStep>
		SymbolAdditiveexpr                         = 152, // <AdditiveExpr>
		SymbolAndexpr                              = 153, // <AndExpr>
		SymbolAnykindtest                          = 154, // <AnyKindTest>
		SymbolAscdescop                            = 155, // <AscDescOp>
		SymbolAtomictype                           = 156, // <AtomicType>
		SymbolAttributelist                        = 157, // <AttributeList>
		SymbolAttributetest                        = 158, // <AttributeTest>
		SymbolAttributevalue                       = 159, // <AttributeValue>
		SymbolAttributevaluecontent                = 160, // <AttributeValueContent>
		SymbolAttributevaluecontentplus            = 161, // <AttributeValueContentPlus>
		SymbolAxisstep                             = 162, // <AxisStep>
		SymbolCaseclause                           = 163, // <CaseClause>
		SymbolCaseclauseplus                       = 164, // <CaseClausePlus>
		SymbolCastableexpr                         = 165, // <CastableExpr>
		SymbolCastexpr                             = 166, // <CastExpr>
		SymbolCdatasection                         = 167, // <CdataSection>
		SymbolCommenttest                          = 168, // <CommentTest>
		SymbolComparisonexpr                       = 169, // <ComparisonExpr>
		SymbolComparisonkind                       = 170, // <ComparisonKind>
		SymbolComputedattributeconstructor         = 171, // <ComputedAttributeConstructor>
		SymbolComputeddocumentconstructor          = 172, // <ComputedDocumentConstructor>
		SymbolComputedelementconstructor           = 173, // <ComputedElementConstructor>
		SymbolComputedtextconstructor              = 174, // <ComputedTextConstructor>
		SymbolConstructor                          = 175, // <Constructor>
		SymbolDefaultcollationdecl                 = 176, // <DefaultCollationDecl>
		SymbolDefaultnamespacedecl                 = 177, // <DefaultNamespaceDecl>
		SymbolDocumenttest                         = 178, // <DocumentTest>
		SymbolElementconstructor                   = 179, // <ElementConstructor>
		SymbolElementcontent                       = 180, // <ElementContent>
		SymbolElementcontentplus                   = 181, // <ElementContentPlus>
		SymbolElementtest                          = 182, // <ElementTest>
		SymbolEmptyop                              = 183, // <EmptyOp>
		SymbolEnclosedexpr                         = 184, // <EnclosedExpr>
		SymbolExpr                                 = 185, // <Expr>
		SymbolExprsingle                           = 186, // <ExprSingle>
		SymbolFilterstep                           = 187, // <FilterStep>
		SymbolFlworexpr                            = 188, // <FLWORExpr>
		SymbolForclause                            = 189, // <ForClause>
		SymbolForlet                               = 190, // <FORLET>
		SymbolForletplus                           = 191, // <FORLETPlus>
		SymbolForvar                               = 192, // <ForVar>
		SymbolForvarplus                           = 193, // <ForVarPlus>
		SymbolForwardaxis                          = 194, // <ForwardAxis>
		SymbolForwardstep                          = 195, // <ForwardStep>
		SymbolFunctioncall                         = 196, // <FunctionCall>
		SymbolFunctiondefn                         = 197, // <FunctionDefn>
		SymbolFunctiondefnplus                     = 198, // <FunctionDefnPlus>
		SymbolGeneralcomp                          = 199, // <GeneralComp>
		SymbolIfexpr                               = 200, // <IfExpr>
		SymbolInstanceofexpr                       = 201, // <InstanceofExpr>
		SymbolIntersectexceptexpr                  = 202, // <IntersectExceptExpr>
		SymbolIntersectexceptop                    = 203, // <IntersectExceptOp>
		SymbolItemtype                             = 204, // <ItemType>
		SymbolKindtest                             = 205, // <KindTest>
		SymbolLetclause                            = 206, // <LetClause>
		SymbolLetvar                               = 207, // <LetVar>
		SymbolLetvarplus                           = 208, // <LetVarPlus>
		SymbolLibrarymodule                        = 209, // <LibraryModule>
		SymbolLiteral                              = 210, // <Literal>
		SymbolMainmodule                           = 211, // <MainModule>
		SymbolModuledecl                           = 213, // <ModuleDecl>
		SymbolModuleimport                         = 214, // <ModuleImport>
		SymbolMultiplicativeexpr                   = 215, // <MultiplicativeExpr>
		SymbolMultop                               = 216, // <MultOp>
		SymbolNamespacedecl                        = 217, // <NamespaceDecl>
		SymbolNametest                             = 218, // <NameTest>
		SymbolNodecomp                             = 219, // <NodeComp>
		SymbolNodename                             = 220, // <NodeName>
		SymbolNodetest                             = 221, // <NodeTest>
		SymbolNumericliteral                       = 222, // <NumericLiteral>
		SymbolOccurrenceindicator                  = 223, // <OccurrenceIndicator>
		SymbolOrderbyclause                        = 224, // <OrderByClause>
		SymbolOrdercomp                            = 225, // <OrderComp>
		SymbolOrdermodifier                        = 226, // <OrderModifier>
		SymbolOrderspec                            = 227, // <OrderSpec>
		SymbolOrderspeclist                        = 228, // <OrderSpecList>
		SymbolOrexpr                               = 229, // <OrExpr>
		SymbolParam                                = 230, // <Param>
		SymbolParamlist                            = 231, // <ParamList>
		SymbolParenthesizedexpr                    = 232, // <ParenthesizedExpr>
		SymbolPathexpr                             = 233, // <PathExpr>
		SymbolPlusorminus                          = 234, // <PlusOrMinus>
		SymbolPositionalvar                        = 235, // <PositionalVar>
		SymbolPredicates                           = 236, // <Predicates>
		SymbolPrimaryexpr                          = 237, // <PrimaryExpr>
		SymbolProcessinginstructiontest            = 238, // <ProcessingInstructionTest>
		SymbolProlog                               = 239, // <Prolog>
		SymbolQname                                = 240, // <QName>
		SymbolQuantifiedexpr                       = 241, // <QuantifiedExpr>
		SymbolQuerybody                            = 242, // <QueryBody>
		SymbolQueryprologa                         = 243, // <QueryPrologA>
		SymbolQueryprologplus                      = 244, // <QueryPrologPlus>
		SymbolRangeexpr                            = 245, // <RangeExpr>
		SymbolRelativepathexpr                     = 246, // <RelativePathExpr>
		SymbolReverseaxis                          = 247, // <ReverseAxis>
		SymbolReversestep                          = 248, // <ReverseStep>
		SymbolSchemacontext                        = 249, // <SchemaContext>
		SymbolSchemacontextlocation                = 250, // <SchemaContextLocation>
		SymbolSchemacontextpath                    = 251, // <SchemaContextPath>
		SymbolSchemaimport                         = 252, // <SchemaImport>
		SymbolSchemamode                           = 253, // <SchemaMode>
		SymbolSchematype                           = 254, // <SchemaType>
		SymbolSequencetype                         = 255, // <SequenceType>
		SymbolSingletype                           = 256, // <SingleType>
		SymbolSlashop                              = 257, // <SlashOp>
		SymbolSomeorevery                          = 258, // <SomeOrEvery>
		SymbolStepexpr                             = 259, // <StepExpr>
		SymbolSubnamespacedecl                     = 260, // <SubNamespaceDecl>
		SymbolTexttest                             = 261, // <TextTest>
		SymbolTreatexpr                            = 262, // <TreatExpr>
		SymbolTypedeclaration                      = 263, // <TypeDeclaration>
		SymbolTypename                             = 264, // <TypeName>
		SymbolTypeswitchexpr                       = 265, // <TypeswitchExpr>
		SymbolUnaryexpr                            = 266, // <UnaryExpr>
		SymbolUnionexpr                            = 267, // <UnionExpr>
		SymbolUnionop                              = 268, // <UnionOp>
		SymbolValidateexpr                         = 269, // <ValidateExpr>
		SymbolValidationdecl                       = 270, // <ValidationDecl>
		SymbolValuecomp                            = 271, // <ValueComp>
		SymbolValueexpr                            = 272, // <ValueExpr>
		SymbolVardecl                              = 273, // <VarDecl>
		SymbolVardeclplus                          = 274, // <VarDeclPlus>
		SymbolVardefn                              = 275, // <VarDefn>
		SymbolWhereclause                          = 277, // <WhereClause>
		SymbolWildcard                             = 278, // <Wildcard>
		SymbolXmlcomment                           = 279, // <XmlComment>
		SymbolXmlprocessinginstruction             = 280, // <XmlProcessingInstruction>
		SymbolXmlspacedecl                         = 281 // <XMLSpaceDecl>
	};

	enum RuleConstants : int
	{
		RuleModule                                                                       = 0  , // <Module> ::= <MainModule>
		RuleModule2                                                                      = 1  , // <Module> ::= <LibraryModule>
		RuleQnameNcnameColonNcname                                                       = 2  , // <QName> ::= NCName ':' NCName
		RuleQnameNcname                                                                  = 3  , // <QName> ::= NCName
		RuleMainmodule                                                                   = 4  , // <MainModule> ::= <Prolog> <QueryBody>
		RuleMainmodule2                                                                  = 5  , // <MainModule> ::= <QueryBody>
		RuleMainmodule3                                                                  = 6  , // <MainModule> ::= <Prolog>
		RuleLibrarymodule                                                                = 7  , // <LibraryModule> ::= <ModuleDecl> <Prolog>
		RuleModuledeclModuleStringliteral                                                = 8  , // <ModuleDecl> ::= MODULE StringLiteral
		RuleProlog                                                                       = 9  , // <Prolog> ::= <Version>
		RuleProlog2                                                                      = 10 , // <Prolog> ::= <Version> <QueryPrologPlus> <FunctionDefnPlus>
		RuleProlog3                                                                      = 11 , // <Prolog> ::= <Version> <QueryPrologPlus>
		RuleProlog4                                                                      = 12 , // <Prolog> ::= <Version> <FunctionDefnPlus>
		RuleProlog5                                                                      = 13 , // <Prolog> ::= <QueryPrologPlus> <FunctionDefnPlus>
		RuleProlog6                                                                      = 14 , // <Prolog> ::= <QueryPrologPlus>
		RuleProlog7                                                                      = 15 , // <Prolog> ::= <FunctionDefnPlus>
		RuleVersionXqueryVersionStringliteral                                            = 16 , // <Version> ::= XQUERY VERSION StringLiteral
		RuleModuleimportImportModuleNamespaceNcnameEqStringliteralAtStringliteral        = 17 , // <ModuleImport> ::= IMPORT MODULE NAMESPACE NCName '=' StringLiteral AT StringLiteral
		RuleModuleimportImportModuleStringliteralAtStringliteral                         = 18 , // <ModuleImport> ::= IMPORT MODULE StringLiteral AT StringLiteral
		RuleModuleimportImportModuleStringliteral                                        = 19 , // <ModuleImport> ::= IMPORT MODULE StringLiteral
		RuleModuleimportImportModuleNamespaceNcnameEqStringliteral                       = 20 , // <ModuleImport> ::= IMPORT MODULE NAMESPACE NCName '=' StringLiteral
		RuleVardefnDefinevariabledollarExternal                                          = 21 , // <VarDefn> ::= 'DEFINE VARIABLE $' <QName> EXTERNAL
		RuleVardefnDefinevariabledollarLbraceRbrace                                      = 22 , // <VarDefn> ::= 'DEFINE VARIABLE $' <QName> '{' <Expr> '}'
		RuleVardefnDefinevariabledollarLbraceRbrace2                                     = 23 , // <VarDefn> ::= 'DEFINE VARIABLE $' <QName> <TypeDeclaration> '{' <Expr> '}'
		RuleVardefnDefinevariabledollarExternal2                                         = 24 , // <VarDefn> ::= 'DEFINE VARIABLE $' <QName> <TypeDeclaration> EXTERNAL
		RuleQueryprologplus                                                              = 25 , // <QueryPrologPlus> ::= <QueryPrologA> <QueryPrologPlus>
		RuleQueryprologplus2                                                             = 26 , // <QueryPrologPlus> ::= <QueryPrologA>
		RuleQueryprologa                                                                 = 27 , // <QueryPrologA> ::= <NamespaceDecl>
		RuleQueryprologa2                                                                = 28 , // <QueryPrologA> ::= <XMLSpaceDecl>
		RuleQueryprologa3                                                                = 29 , // <QueryPrologA> ::= <DefaultNamespaceDecl>
		RuleQueryprologa4                                                                = 30 , // <QueryPrologA> ::= <DefaultCollationDecl>
		RuleQueryprologa5                                                                = 31 , // <QueryPrologA> ::= <SchemaImport>
		RuleQueryprologa6                                                                = 32 , // <QueryPrologA> ::= <ModuleImport>
		RuleQueryprologa7                                                                = 33 , // <QueryPrologA> ::= <VarDefn>
		RuleQueryprologa8                                                                = 34 , // <QueryPrologA> ::= <ValidationDecl>
		RuleFunctiondefnplus                                                             = 35 , // <FunctionDefnPlus> ::= <FunctionDefn> <FunctionDefnPlus>
		RuleFunctiondefnplus2                                                            = 36 , // <FunctionDefnPlus> ::= <FunctionDefn>
		RuleQuerybody                                                                    = 37 , // <QueryBody> ::= <Expr>
		RuleExprComma                                                                    = 38 , // <Expr> ::= <ExprSingle> ',' <Expr>
		RuleExpr                                                                         = 39 , // <Expr> ::= <ExprSingle>
		RuleExprsingle                                                                   = 40 , // <ExprSingle> ::= <FLWORExpr>
		RuleExprsingle2                                                                  = 41 , // <ExprSingle> ::= <QuantifiedExpr>
		RuleExprsingle3                                                                  = 42 , // <ExprSingle> ::= <TypeswitchExpr>
		RuleExprsingle4                                                                  = 43 , // <ExprSingle> ::= <IfExpr>
		RuleExprsingle5                                                                  = 44 , // <ExprSingle> ::= <OrExpr>
		RuleExprsingle6                                                                  = 45 , // <ExprSingle> ::= <Constructor>
		RuleOrexpr                                                                       = 46 , // <OrExpr> ::= <AndExpr>
		RuleOrexprOr                                                                     = 47 , // <OrExpr> ::= <AndExpr> OR <OrExpr>
		RuleAndexpr                                                                      = 48 , // <AndExpr> ::= <InstanceofExpr>
		RuleAndexprAnd                                                                   = 49 , // <AndExpr> ::= <InstanceofExpr> AND <AndExpr>
		RuleFlworexprReturn                                                              = 50 , // <FLWORExpr> ::= <FORLETPlus> <WhereClause> <OrderByClause> RETURN <ExprSingle>
		RuleFlworexprReturn2                                                             = 51 , // <FLWORExpr> ::= <FORLETPlus> <WhereClause> RETURN <ExprSingle>
		RuleFlworexprReturn3                                                             = 52 , // <FLWORExpr> ::= <FORLETPlus> <OrderByClause> RETURN <ExprSingle>
		RuleFlworexprReturn4                                                             = 53 , // <FLWORExpr> ::= <FORLETPlus> RETURN <ExprSingle>
		RuleForletplus                                                                   = 54 , // <FORLETPlus> ::= <FORLET> <FORLETPlus>
		RuleForletplus2                                                                  = 55 , // <FORLETPlus> ::= <FORLET>
		RuleForlet                                                                       = 56 , // <FORLET> ::= <ForClause>
		RuleForlet2                                                                      = 57 , // <FORLET> ::= <LetClause>
		RuleQuantifiedexprSatisfies                                                      = 58 , // <QuantifiedExpr> ::= <SomeOrEvery> <VarDeclPlus> SATISFIES <ExprSingle>
		RuleVardeclDollarIn                                                              = 59 , // <VarDecl> ::= '$' <QName> IN <ExprSingle>
		RuleVardeclDollarIn2                                                             = 60 , // <VarDecl> ::= '$' <QName> <TypeDeclaration> IN <ExprSingle>
		RuleVardeclplus                                                                  = 61 , // <VarDeclPlus> ::= <VarDecl>
		RuleVardeclplusComma                                                             = 62 , // <VarDeclPlus> ::= <VarDecl> ',' <VarDeclPlus>
		RuleSomeoreverySome                                                              = 63 , // <SomeOrEvery> ::= SOME
		RuleSomeoreveryEvery                                                             = 64 , // <SomeOrEvery> ::= EVERY
		RuleTypeswitchexprTypeswitchLparanRparanDefaultReturn                            = 65 , // <TypeswitchExpr> ::= TYPESWITCH '(' <ExprSingle> ')' <CaseClausePlus> DEFAULT RETURN <ExprSingle>
		RuleTypeswitchexprTypeswitchLparanRparanDefaultDollarReturn                      = 66 , // <TypeswitchExpr> ::= TYPESWITCH '(' <ExprSingle> ')' <CaseClausePlus> DEFAULT '$' <QName> RETURN <ExprSingle>
		RuleCaseclauseplus                                                               = 67 , // <CaseClausePlus> ::= <CaseClause>
		RuleCaseclauseplus2                                                              = 68 , // <CaseClausePlus> ::= <CaseClause> <CaseClausePlus>
		RuleIfexprIfLparanRparanThenElse                                                 = 69 , // <IfExpr> ::= IF '(' <ExprSingle> ')' THEN <ExprSingle> ELSE <ExprSingle>
		RuleInstanceofexpr                                                               = 70 , // <InstanceofExpr> ::= <TreatExpr>
		RuleInstanceofexprInstanceOf                                                     = 71 , // <InstanceofExpr> ::= <TreatExpr> INSTANCE OF <SequenceType>
		RuleTreatexpr                                                                    = 72 , // <TreatExpr> ::= <CastableExpr>
		RuleTreatexprTreatAs                                                             = 73 , // <TreatExpr> ::= <CastableExpr> TREAT AS <SequenceType>
		RuleCastableexpr                                                                 = 74 , // <CastableExpr> ::= <CastExpr>
		RuleCastableexprCastableAs                                                       = 75 , // <CastableExpr> ::= <CastExpr> CASTABLE AS <SingleType>
		RuleCastexpr                                                                     = 76 , // <CastExpr> ::= <ComparisonExpr>
		RuleCastexprCastAs                                                               = 77 , // <CastExpr> ::= <ComparisonExpr> CAST AS <SingleType>
		RuleComparisonexpr                                                               = 78 , // <ComparisonExpr> ::= <RangeExpr>
		RuleComparisonexpr2                                                              = 79 , // <ComparisonExpr> ::= <RangeExpr> <ComparisonKind> <RangeExpr>
		RuleComparisonkind                                                               = 80 , // <ComparisonKind> ::= <ValueComp>
		RuleComparisonkind2                                                              = 81 , // <ComparisonKind> ::= <GeneralComp>
		RuleComparisonkind3                                                              = 82 , // <ComparisonKind> ::= <NodeComp>
		RuleComparisonkind4                                                              = 83 , // <ComparisonKind> ::= <OrderComp>
		RuleRangeexpr                                                                    = 84 , // <RangeExpr> ::= <AdditiveExpr>
		RuleRangeexprTo                                                                  = 85 , // <RangeExpr> ::= <AdditiveExpr> TO <AdditiveExpr>
		RuleAdditiveexpr                                                                 = 86 , // <AdditiveExpr> ::= <MultiplicativeExpr>
		RuleAdditiveexpr2                                                                = 87 , // <AdditiveExpr> ::= <MultiplicativeExpr> <PlusOrMinus> <AdditiveExpr>
		RulePlusorminusPlus                                                              = 88 , // <PlusOrMinus> ::= '+'
		RulePlusorminusMinus                                                             = 89 , // <PlusOrMinus> ::= '-'
		RuleMultiplicativeexpr                                                           = 90 , // <MultiplicativeExpr> ::= <UnaryExpr>
		RuleMultiplicativeexpr2                                                          = 91 , // <MultiplicativeExpr> ::= <UnaryExpr> <MultOp> <MultiplicativeExpr>
		RuleMultopTimes                                                                  = 92 , // <MultOp> ::= '*'
		RuleMultopDiv                                                                    = 93 , // <MultOp> ::= DIV
		RuleMultopIdiv                                                                   = 94 , // <MultOp> ::= IDIV
		RuleMultopMod                                                                    = 95 , // <MultOp> ::= MOD
		RuleUnaryexpr                                                                    = 96 , // <UnaryExpr> ::= <UnionExpr>
		RuleUnaryexpr2                                                                   = 97 , // <UnaryExpr> ::= <PlusOrMinus> <UnionExpr>
		RuleUnionexpr                                                                    = 98 , // <UnionExpr> ::= <IntersectExceptExpr>
		RuleUnionexpr2                                                                   = 99 , // <UnionExpr> ::= <IntersectExceptExpr> <UnionOp> <UnionExpr>
		RuleUnionopUnion                                                                 = 100, // <UnionOp> ::= UNION
		RuleUnionopPipe                                                                  = 101, // <UnionOp> ::= '|'
		RuleIntersectexceptexpr                                                          = 102, // <IntersectExceptExpr> ::= <ValueExpr>
		RuleIntersectexceptexpr2                                                         = 103, // <IntersectExceptExpr> ::= <ValueExpr> <IntersectExceptOp> <IntersectExceptExpr>
		RuleIntersectexceptopIntersect                                                   = 104, // <IntersectExceptOp> ::= INTERSECT
		RuleIntersectexceptopExcept                                                      = 105, // <IntersectExceptOp> ::= EXCEPT
		RuleValueexpr                                                                    = 106, // <ValueExpr> ::= <ValidateExpr>
		RuleValueexpr2                                                                   = 107, // <ValueExpr> ::= <PathExpr>
		RulePathexpr                                                                     = 108, // <PathExpr> ::= <SlashOp> <RelativePathExpr>
		RulePathexpr2                                                                    = 109, // <PathExpr> ::= <RelativePathExpr>
		RulePathexpr3                                                                    = 110, // <PathExpr> ::= <SlashOp>
		RuleRelativepathexpr                                                             = 111, // <RelativePathExpr> ::= <StepExpr>
		RuleRelativepathexpr2                                                            = 112, // <RelativePathExpr> ::= <StepExpr> <SlashOp> <RelativePathExpr>
		RuleSlashopDiv                                                                   = 113, // <SlashOp> ::= '/'
		RuleSlashopDivdiv                                                                = 114, // <SlashOp> ::= '//'
		RuleStepexpr                                                                     = 115, // <StepExpr> ::= <AxisStep>
		RuleStepexpr2                                                                    = 116, // <StepExpr> ::= <FilterStep>
		RuleAxisstep                                                                     = 117, // <AxisStep> ::= <ForwardStep> <Predicates>
		RuleAxisstep2                                                                    = 118, // <AxisStep> ::= <ReverseStep> <Predicates>
		RuleAxisstep3                                                                    = 119, // <AxisStep> ::= <ForwardStep>
		RuleAxisstep4                                                                    = 120, // <AxisStep> ::= <ReverseStep>
		RuleFilterstep                                                                   = 121, // <FilterStep> ::= <PrimaryExpr> <Predicates>
		RuleFilterstep2                                                                  = 122, // <FilterStep> ::= <PrimaryExpr>
		RuleForclauseFor                                                                 = 123, // <ForClause> ::= FOR <ForVarPlus>
		RuleForvarDollarIn                                                               = 124, // <ForVar> ::= '$' <QName> IN <ExprSingle>
		RuleForvarDollarIn2                                                              = 125, // <ForVar> ::= '$' <QName> <TypeDeclaration> IN <ExprSingle>
		RuleForvarDollarIn3                                                              = 126, // <ForVar> ::= '$' <QName> <PositionalVar> IN <ExprSingle>
		RuleForvarDollarIn4                                                              = 127, // <ForVar> ::= '$' <QName> <TypeDeclaration> <PositionalVar> IN <ExprSingle>
		RuleForvarplus                                                                   = 128, // <ForVarPlus> ::= <ForVar>
		RuleForvarplusComma                                                              = 129, // <ForVarPlus> ::= <ForVar> ',' <ForVarPlus>
		RuleLetclauseLet                                                                 = 130, // <LetClause> ::= LET <LetVarPlus>
		RuleLetvarplus                                                                   = 131, // <LetVarPlus> ::= <LetVar>
		RuleLetvarplusComma                                                              = 132, // <LetVarPlus> ::= <LetVar> ',' <LetVarPlus>
		RuleLetvarDollarColoneq                                                          = 133, // <LetVar> ::= '$' <QName> ':=' <ExprSingle>
		RuleLetvarDollarColoneq2                                                         = 134, // <LetVar> ::= '$' <QName> <TypeDeclaration> ':=' <ExprSingle>
		RuleWhereclauseWhere                                                             = 135, // <WhereClause> ::= WHERE <ExprSingle>
		RulePositionalvarAtDollar                                                        = 136, // <PositionalVar> ::= AT '$' <QName>
		RuleValidateexprValidateLbraceRbrace                                             = 137, // <ValidateExpr> ::= VALIDATE '{' <ExprSingle> '}'
		RuleValidateexprValidateGlobalLbraceRbrace                                       = 138, // <ValidateExpr> ::= VALIDATE GLOBAL '{' <ExprSingle> '}'
		RuleValidateexprValidateContextLbraceRbrace                                      = 139, // <ValidateExpr> ::= VALIDATE CONTEXT <SchemaContextLocation> '{' <ExprSingle> '}'
		RuleValidateexprValidateLbraceRbrace2                                            = 140, // <ValidateExpr> ::= VALIDATE <SchemaMode> '{' <ExprSingle> '}'
		RuleValidateexprValidateLbraceRbrace3                                            = 141, // <ValidateExpr> ::= VALIDATE <SchemaMode> <SchemaContext> '{' <ExprSingle> '}'
		RuleConstructor                                                                  = 142, // <Constructor> ::= <ElementConstructor>
		RuleConstructor2                                                                 = 143, // <Constructor> ::= <XmlComment>
		RuleConstructor3                                                                 = 144, // <Constructor> ::= <XmlProcessingInstruction>
		RuleConstructor4                                                                 = 145, // <Constructor> ::= <CdataSection>
		RuleConstructor5                                                                 = 146, // <Constructor> ::= <ComputedDocumentConstructor>
		RuleConstructor6                                                                 = 147, // <Constructor> ::= <ComputedElementConstructor>
		RuleConstructor7                                                                 = 148, // <Constructor> ::= <ComputedAttributeConstructor>
		RuleConstructor8                                                                 = 149, // <Constructor> ::= <ComputedTextConstructor>
		RuleGeneralcompEq                                                                = 150, // <GeneralComp> ::= '='
		RuleGeneralcompExclameq                                                          = 151, // <GeneralComp> ::= '!='
		RuleGeneralcompLt                                                                = 152, // <GeneralComp> ::= '<'
		RuleGeneralcompLteq                                                              = 153, // <GeneralComp> ::= '<='
		RuleGeneralcompGt                                                                = 154, // <GeneralComp> ::= '>'
		RuleGeneralcompGteq                                                              = 155, // <GeneralComp> ::= '>='
		RuleValuecompEq                                                                  = 156, // <ValueComp> ::= EQ
		RuleValuecompNe                                                                  = 157, // <ValueComp> ::= NE
		RuleValuecompLt                                                                  = 158, // <ValueComp> ::= LT
		RuleValuecompLe                                                                  = 159, // <ValueComp> ::= LE
		RuleValuecompGt                                                                  = 160, // <ValueComp> ::= GT
		RuleValuecompGe                                                                  = 161, // <ValueComp> ::= GE
		RuleNodecompIs                                                                   = 162, // <NodeComp> ::= IS
		RuleNodecompIsnot                                                                = 163, // <NodeComp> ::= ISNOT
		RuleOrdercompLtlt                                                                = 164, // <OrderComp> ::= '<<'
		RuleOrdercompGtgt                                                                = 165, // <OrderComp> ::= '>>'
		RuleOrderbyclauseOrderBy                                                         = 166, // <OrderByClause> ::= ORDER BY <OrderSpecList>
		RuleOrderbyclauseStableOrderBy                                                   = 167, // <OrderByClause> ::= STABLE ORDER BY <OrderSpecList>
		RuleOrderspeclist                                                                = 168, // <OrderSpecList> ::= <OrderSpec>
		RuleOrderspeclistComma                                                           = 169, // <OrderSpecList> ::= <OrderSpec> ',' <OrderSpecList>
		RuleOrderspec                                                                    = 170, // <OrderSpec> ::= <ExprSingle> <OrderModifier>
		RuleOrderspec2                                                                   = 171, // <OrderSpec> ::= <ExprSingle>
		RuleOrdermodifierCollationStringliteral                                          = 172, // <OrderModifier> ::= <AscDescOp> <EmptyOp> COLLATION StringLiteral
		RuleOrdermodifierCollationStringliteral2                                         = 173, // <OrderModifier> ::= <EmptyOp> COLLATION StringLiteral
		RuleOrdermodifierCollationStringliteral3                                         = 174, // <OrderModifier> ::= COLLATION StringLiteral
		RuleOrdermodifierCollationStringliteral4                                         = 175, // <OrderModifier> ::= <AscDescOp> COLLATION StringLiteral
		RuleOrdermodifier                                                                = 176, // <OrderModifier> ::= <AscDescOp> <EmptyOp>
		RuleOrdermodifier2                                                               = 177, // <OrderModifier> ::= <AscDescOp>
		RuleOrdermodifier3                                                               = 178, // <OrderModifier> ::= <EmptyOp>
		RuleAscdescopAscending                                                           = 179, // <AscDescOp> ::= ASCENDING
		RuleAscdescopDescending                                                          = 180, // <AscDescOp> ::= DESCENDING
		RuleEmptyopEmptyGreatest                                                         = 181, // <EmptyOp> ::= EMPTY GREATEST
		RuleEmptyopEmptyLeast                                                            = 182, // <EmptyOp> ::= EMPTY LEAST
		RuleCaseclauseCaseReturn                                                         = 183, // <CaseClause> ::= CASE <SequenceType> RETURN <ExprSingle>
		RuleCaseclauseCaseDollarAsReturn                                                 = 184, // <CaseClause> ::= CASE '$' <QName> AS <SequenceType> RETURN <ExprSingle>
		RulePrimaryexpr                                                                  = 185, // <PrimaryExpr> ::= <Literal>
		RulePrimaryexpr2                                                                 = 186, // <PrimaryExpr> ::= <FunctionCall>
		RulePrimaryexprDollar                                                            = 187, // <PrimaryExpr> ::= '$' <QName>
		RulePrimaryexpr3                                                                 = 188, // <PrimaryExpr> ::= <ParenthesizedExpr>
		RuleForwardaxisChildcoloncolon                                                   = 189, // <ForwardAxis> ::= 'CHILD::'
		RuleForwardaxisDescendantcoloncolon                                              = 190, // <ForwardAxis> ::= 'DESCENDANT::'
		RuleForwardaxisAttributecoloncolon                                               = 191, // <ForwardAxis> ::= 'ATTRIBUTE::'
		RuleForwardaxisSelfcoloncolon                                                    = 192, // <ForwardAxis> ::= 'SELF::'
		RuleForwardaxisDescendantminusorminusselfcoloncolon                              = 193, // <ForwardAxis> ::= 'DESCENDANT-OR-SELF::'
		RuleReverseaxisParentcoloncolon                                                  = 194, // <ReverseAxis> ::= 'PARENT::'
		RuleNodetest                                                                     = 195, // <NodeTest> ::= <KindTest>
		RuleNodetest2                                                                    = 196, // <NodeTest> ::= <NameTest>
		RuleNametest                                                                     = 197, // <NameTest> ::= <QName>
		RuleNametest2                                                                    = 198, // <NameTest> ::= <Wildcard>
		RuleWildcardTimescolontimes                                                      = 199, // <Wildcard> ::= '*:*'
		RuleWildcardNcnameColontimes                                                     = 200, // <Wildcard> ::= NCName ':*'
		RuleWildcardTimescolonNcname                                                     = 201, // <Wildcard> ::= '*:' NCName
		RuleKindtest                                                                     = 202, // <KindTest> ::= <ProcessingInstructionTest>
		RuleKindtest2                                                                    = 203, // <KindTest> ::= <CommentTest>
		RuleKindtest3                                                                    = 204, // <KindTest> ::= <TextTest>
		RuleKindtest4                                                                    = 205, // <KindTest> ::= <AnyKindTest>
		RuleKindtest5                                                                    = 206, // <KindTest> ::= <DocumentTest>
		RuleKindtest6                                                                    = 207, // <KindTest> ::= <ElementTest>
		RuleKindtest7                                                                    = 208, // <KindTest> ::= <AttributeTest>
		RuleElementtestElementlparanrparan                                               = 209, // <ElementTest> ::= 'ELEMENT()'
		RuleElementtestElementlparanRparan2                                              = 210, // <ElementTest> ::= 'ELEMENT(' <SchemaContextPath> <QName> ')'
		RuleElementtestElementlparanRparan3                                              = 211, // <ElementTest> ::= 'ELEMENT(' <NodeName> ')'
		RuleElementtestElementlparanCommaRparan                                          = 212, // <ElementTest> ::= 'ELEMENT(' <NodeName> ',' <TypeName> ')'
		RuleElementtestElementlparanCommaNillableRparan                                  = 213, // <ElementTest> ::= 'ELEMENT(' <NodeName> ',' <TypeName> NILLABLE ')'
		RuleAttributetestAttributelparanrparan                                           = 214, // <AttributeTest> ::= 'ATTRIBUTE()'
		RuleAttributetestAttributelparanAtRparan                                         = 215, // <AttributeTest> ::= 'ATTRIBUTE(' <SchemaContextPath> '@' <QName> ')'
		RuleAttributetestAttributelparanAtRparan2                                        = 216, // <AttributeTest> ::= 'ATTRIBUTE(' '@' <NodeName> ')'
		RuleAttributetestAttributelparanAtCommaRparan                                    = 217, // <AttributeTest> ::= 'ATTRIBUTE(' '@' <NodeName> ',' <TypeName> ')'
		RuleProcessinginstructiontestProcessingminusinstructionlparanStringliteralRparan = 218, // <ProcessingInstructionTest> ::= 'PROCESSING-INSTRUCTION(' StringLiteral ')'
		RuleDocumenttestDocumentminusnodelparanrparan                                    = 219, // <DocumentTest> ::= 'DOCUMENT-NODE()'
		RuleDocumenttestDocumentminusnodelparanRparan2                                   = 220, // <DocumentTest> ::= 'DOCUMENT-NODE(' <ElementTest> ')'
		RuleCommenttestCommentlparanrparan                                               = 221, // <CommentTest> ::= 'COMMENT()'
		RuleTexttestTextlparanrparan                                                     = 222, // <TextTest> ::= 'TEXT()'
		RuleAnykindtestNodelparanrparan                                                  = 223, // <AnyKindTest> ::= 'NODE()'
		RuleSchemacontextpathDiv                                                         = 224, // <SchemaContextPath> ::= <QName> '/'
		RuleSchemacontextpathTypelparanRparanDiv                                         = 225, // <SchemaContextPath> ::= 'TYPE(' <QName> ')' '/'
		RuleSchemacontextlocation                                                        = 226, // <SchemaContextLocation> ::= <SchemaContextPath> <QName>
		RuleSchemacontextlocationTypelparanRparan                                        = 227, // <SchemaContextLocation> ::= 'TYPE(' <QName> ')'
		RuleNodename                                                                     = 228, // <NodeName> ::= <QName>
		RuleNodenameTimes                                                                = 229, // <NodeName> ::= '*'
		RuleTypename                                                                     = 230, // <TypeName> ::= <QName>
		RuleTypenameTimes                                                                = 231, // <TypeName> ::= '*'
		RuleValidationdeclValidation                                                     = 232, // <ValidationDecl> ::= VALIDATION <SchemaMode>
		RuleForwardstep                                                                  = 233, // <ForwardStep> ::= <ForwardAxis> <NodeTest>
		RuleForwardstep2                                                                 = 234, // <ForwardStep> ::= <AbbreviatedForwardStep>
		RuleReversestep                                                                  = 235, // <ReverseStep> ::= <ReverseAxis> <NodeTest>
		RuleReversestep2                                                                 = 236, // <ReverseStep> ::= <AbbreviatedReverseStep>
		RuleAbbreviatedforwardstepDot                                                    = 237, // <AbbreviatedForwardStep> ::= '.'
		RuleAbbreviatedforwardstepAt                                                     = 238, // <AbbreviatedForwardStep> ::= '@' <NameTest>
		RuleAbbreviatedforwardstep                                                       = 239, // <AbbreviatedForwardStep> ::= <NodeTest>
		RuleAbbreviatedreversestepDotdot                                                 = 240, // <AbbreviatedReverseStep> ::= '..'
		RulePredicatesLbracketRbracket                                                   = 241, // <Predicates> ::= '[' <ExprSingle> ']'
		RulePredicatesLbracketRbracket2                                                  = 242, // <Predicates> ::= '[' <ExprSingle> ']' <Predicates>
		RuleNumericliteralIntegerliteral                                                 = 243, // <NumericLiteral> ::= IntegerLiteral
		RuleNumericliteralDecimalliteral                                                 = 244, // <NumericLiteral> ::= DecimalLiteral
		RuleLiteral                                                                      = 245, // <Literal> ::= <NumericLiteral>
		RuleLiteralStringliteral                                                         = 246, // <Literal> ::= StringLiteral
		RuleParenthesizedexprLparanRparan                                                = 247, // <ParenthesizedExpr> ::= '(' <Expr> ')'
		RuleParenthesizedexprLparanrparan2                                               = 248, // <ParenthesizedExpr> ::= '()'
		RuleFunctioncall                                                                 = 249, // <FunctionCall> ::= <QName> <ParenthesizedExpr>
		RuleParamDollar                                                                  = 250, // <Param> ::= '$' <QName>
		RuleParamDollar2                                                                 = 251, // <Param> ::= '$' <QName> <TypeDeclaration>
		RuleSchemacontextContext                                                         = 252, // <SchemaContext> ::= CONTEXT <SchemaContextLocation>
		RuleSchemacontextGlobal                                                          = 253, // <SchemaContext> ::= GLOBAL
		RuleTypedeclarationAs                                                            = 254, // <TypeDeclaration> ::= AS <SequenceType>
		RuleSingletype                                                                   = 255, // <SingleType> ::= <AtomicType>
		RuleSingletypeQuestion                                                           = 256, // <SingleType> ::= <AtomicType> '?'
		RuleSequencetype                                                                 = 257, // <SequenceType> ::= <ItemType>
		RuleSequencetypeEmptylparanrparan                                                = 258, // <SequenceType> ::= 'EMPTY()'
		RuleSequencetype2                                                                = 259, // <SequenceType> ::= <ItemType> <OccurrenceIndicator>
		RuleItemtype                                                                     = 260, // <ItemType> ::= <AtomicType>
		RuleItemtype2                                                                    = 261, // <ItemType> ::= <KindTest>
		RuleItemtypeItemlparanrparan                                                     = 262, // <ItemType> ::= 'ITEM()'
		RuleSchematypeOfType                                                             = 263, // <SchemaType> ::= OF TYPE <QName>
		RuleAtomictype                                                                   = 264, // <AtomicType> ::= <QName>
		RuleOccurrenceindicatorTimes                                                     = 265, // <OccurrenceIndicator> ::= '*'
		RuleOccurrenceindicatorPlus                                                      = 266, // <OccurrenceIndicator> ::= '+'
		RuleOccurrenceindicatorQuestion                                                  = 267, // <OccurrenceIndicator> ::= '?'
		RuleElementconstructorLtDivgt                                                    = 268, // <ElementConstructor> ::= '<' <QName> <AttributeList> '/>'
		RuleElementconstructorLtDivgt2                                                   = 269, // <ElementConstructor> ::= '<' <QName> '/>'
		RuleElementconstructorLtGtLtdivGt                                                = 270, // <ElementConstructor> ::= '<' <QName> <AttributeList> '>' '</' <QName> '>'
		RuleElementconstructorLtGtLtdivGt2                                               = 271, // <ElementConstructor> ::= '<' <QName> '>' '</' <QName> '>'
		RuleElementconstructorLtGtLtdivGt3                                               = 272, // <ElementConstructor> ::= '<' <QName> <AttributeList> '>' <ElementContentPlus> '</' <QName> '>'
		RuleElementconstructorLtGtLtdivGt4                                               = 273, // <ElementConstructor> ::= '<' <QName> '>' <ElementContentPlus> '</' <QName> '>'
		RuleElementcontentplus                                                           = 274, // <ElementContentPlus> ::= <ElementContent>
		RuleElementcontentplus2                                                          = 275, // <ElementContentPlus> ::= <ElementContent> <ElementContentPlus>
		RuleComputeddocumentconstructorDocumentlbraceRbrace                              = 276, // <ComputedDocumentConstructor> ::= 'DOCUMENT{' <Expr> '}'
		RuleComputedelementconstructorElementLbraceRbrace                                = 277, // <ComputedElementConstructor> ::= ELEMENT <QName> '{' <Expr> '}'
		RuleComputedelementconstructorElementlbraceRbraceLbraceRbrace                    = 278, // <ComputedElementConstructor> ::= 'ELEMENT{' <ExprSingle> '}' '{' <Expr> '}'
		RuleComputedelementconstructorElementlbraceRbraceLbracerbrace2                   = 279, // <ComputedElementConstructor> ::= 'ELEMENT{' <ExprSingle> '}' '{}'
		RuleComputedelementconstructorElementLbracerbrace2                               = 280, // <ComputedElementConstructor> ::= ELEMENT <QName> '{}'
		RuleComputedattributeconstructorAttributeLbraceRbrace                            = 281, // <ComputedAttributeConstructor> ::= ATTRIBUTE <QName> '{' <Expr> '}'
		RuleComputedattributeconstructorAttributelbraceRbraceLbraceRbrace                = 282, // <ComputedAttributeConstructor> ::= 'ATTRIBUTE{' <ExprSingle> '}' '{' <Expr> '}'
		RuleComputedattributeconstructorAttributelbraceRbraceLbracerbrace2               = 283, // <ComputedAttributeConstructor> ::= 'ATTRIBUTE{' <ExprSingle> '}' '{}'
		RuleComputedattributeconstructorAttributeLbracerbrace2                           = 284, // <ComputedAttributeConstructor> ::= ATTRIBUTE <QName> '{}'
		RuleComputedtextconstructorTextlbraceRbrace                                      = 285, // <ComputedTextConstructor> ::= 'TEXT{' <Expr> '}'
		RuleComputedtextconstructorTextlbracerbrace2                                     = 286, // <ComputedTextConstructor> ::= 'TEXT{}'
		RuleCdatasectionLtexclamlbracketcdatalbracketRbracketrbracketgt                  = 287, // <CdataSection> ::= '<![CDATA[' ']]>'
		RuleXmlprocessinginstructionLtquestionNcnameQuestiongt                           = 288, // <XmlProcessingInstruction> ::= '<?' NCName '?>'
		RuleXmlcommentLtexclamminusminusMinusminusgt                                     = 289, // <XmlComment> ::= '<!--' '-->'
		RuleElementcontent                                                               = 290, // <ElementContent> ::= <XmlProcessingInstruction>
		RuleElementcontentLbracelbrace                                                   = 291, // <ElementContent> ::= '{{'
		RuleElementcontentRbracerbrace                                                   = 292, // <ElementContent> ::= '}}'
		RuleElementcontent2                                                              = 293, // <ElementContent> ::= <ElementConstructor>
		RuleElementcontent3                                                              = 294, // <ElementContent> ::= <EnclosedExpr>
		RuleElementcontent4                                                              = 295, // <ElementContent> ::= <CdataSection>
		RuleElementcontent5                                                              = 296, // <ElementContent> ::= <XmlComment>
		RuleAttributelistEq                                                              = 297, // <AttributeList> ::= <QName> '=' <AttributeValue>
		RuleAttributelistEq2                                                             = 298, // <AttributeList> ::= <QName> '=' <AttributeValue> <AttributeList>
		RuleAttributevalueDquoteDquote                                                   = 299, // <AttributeValue> ::= DQuote <AttributeValueContentPlus> DQuote
		RuleAttributevalueApostApost                                                     = 300, // <AttributeValue> ::= '' <AttributeValueContentPlus> ''
		RuleAttributevalue                                                               = 301, // <AttributeValue> ::= <AttributeValueContentPlus>
		RuleAttributevaluecontentplus                                                    = 302, // <AttributeValueContentPlus> ::= <AttributeValueContent>
		RuleAttributevaluecontentplus2                                                   = 303, // <AttributeValueContentPlus> ::= <AttributeValueContent> <AttributeValueContentPlus>
		RuleAttributevaluecontent                                                        = 304, // <AttributeValueContent> ::= <EnclosedExpr>
		RuleAttributevaluecontentLbracelbrace                                            = 305, // <AttributeValueContent> ::= '{{'
		RuleAttributevaluecontentRbracerbrace                                            = 306, // <AttributeValueContent> ::= '}}'
		RuleEnclosedexprLbraceRbrace                                                     = 307, // <EnclosedExpr> ::= '{' <Expr> '}'
		RuleXmlspacedeclDeclareXmlspaceEqPreserve                                        = 308, // <XMLSpaceDecl> ::= DECLARE XMLSPACE '=' PRESERVE
		RuleXmlspacedeclDeclareXmlspaceEqStrip                                           = 309, // <XMLSpaceDecl> ::= DECLARE XMLSPACE '=' STRIP
		RuleDefaultcollationdeclDefaultCollationEqStringliteral                          = 310, // <DefaultCollationDecl> ::= DEFAULT COLLATION '=' StringLiteral
		RuleNamespacedeclDeclareNamespaceNcnameEqStringliteral                           = 311, // <NamespaceDecl> ::= DECLARE NAMESPACE NCName '=' StringLiteral
		RuleSubnamespacedeclNamespaceNcnameEqStringliteral                               = 312, // <SubNamespaceDecl> ::= NAMESPACE NCName '=' StringLiteral
		RuleDefaultnamespacedeclDefaultElementNamespaceEqStringliteral                   = 313, // <DefaultNamespaceDecl> ::= DEFAULT ELEMENT NAMESPACE '=' StringLiteral
		RuleDefaultnamespacedeclDefaultFunctionNamespaceEqStringliteral                  = 314, // <DefaultNamespaceDecl> ::= DEFAULT FUNCTION NAMESPACE '=' StringLiteral
		RuleFunctiondefnDefinefunctionLparanRparan                                       = 315, // <FunctionDefn> ::= 'DEFINE FUNCTION' <QName> '(' <ParamList> ')' <EnclosedExpr>
		RuleFunctiondefnDefinefunctionLparanRparanAs                                     = 316, // <FunctionDefn> ::= 'DEFINE FUNCTION' <QName> '(' <ParamList> ')' AS <SequenceType> <EnclosedExpr>
		RuleFunctiondefnDefinefunctionLparanRparan2                                      = 317, // <FunctionDefn> ::= 'DEFINE FUNCTION' <QName> '(' ')' <EnclosedExpr>
		RuleParamlist                                                                    = 318, // <ParamList> ::= <Param>
		RuleParamlistComma                                                               = 319, // <ParamList> ::= <Param> ',' <ParamList>
		RuleSchemaimportImportSchemaStringliteralAtStringliteral                         = 320, // <SchemaImport> ::= IMPORT SCHEMA StringLiteral AT StringLiteral
		RuleSchemaimportImportSchemaAtStringliteral                                      = 321, // <SchemaImport> ::= IMPORT SCHEMA <SubNamespaceDecl> AT StringLiteral
		RuleSchemaimportImportSchemaAtStringliteral2                                     = 322, // <SchemaImport> ::= IMPORT SCHEMA <DefaultNamespaceDecl> AT StringLiteral
		RuleSchemamodeLax                                                                = 323, // <SchemaMode> ::= LAX
		RuleSchemamodeStrict                                                             = 324, // <SchemaMode> ::= STRICT
		RuleSchemamodeSkip                                                               = 325 // <SchemaMode> ::= SKIP
	};
}