//COPYRIGHT  � 2000-2004 
//THE REGENTS OF THE UNIVERSITY OF MICHIGAN
//ALL RIGHTS RESERVED
//
//PERMISSION IS GRANTED TO USE, COPY, CREATE DERIVATIVE WORKS AND REDISTRIBUTE 
//THIS SOFTWARE AND SUCH DERIVATIVE WORKS FOR NONCOMMERCIAL EDUCATION AND 
//RESEARCH PURPOSES, SO LONG AS NO FEE IS CHARGED, AND SO LONG AS THE 
//COPYRIGHT NOTICE ABOVE, THIS GRANT OF PERMISSION, AND THE DISCLAIMER 
//BELOW APPEAR IN ALL COPIES MADE; AND SO LONG AS THE NAME OF THE UNIVERSITY 
//OF MICHIGAN IS NOT USED IN ANY ADVERTISING OR PUBLICITY PERTAINING TO THE 
//USE OR DISTRIBUTION OF THIS SOFTWARE WITHOUT SPECIFIC, WRITTEN PRIOR AUTHORIZATION.
//
//THIS SOFTWARE IS PROVIDED AS IS, WITHOUT REPRESENTATION FROM THE UNIVERSITY 
//OF MICHIGAN AS TO ITS FITNESS FOR ANY PURPOSE, AND WITHOUT WARRANTY BY THE 
//UNIVERSITY OF MICHIGAN OF ANY KIND, EITHER EXPRESS OR IMPLIED, INCLUDING 
//WITHOUT LIMITATION THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS 
//FOR A PARTICULAR PURPOSE. THE REGENTS OF THE UNIVERSITY OF MICHIGAN SHALL 
//NOT BE LIABLE FOR ANY DAMAGES, INCLUDING SPECIAL, INDIRECT, INCIDENTAL, 
//OR CONSEQUENTIAL DAMAGES, WITH RESPECT TO ANY CLAIM ARISING OUT OF OR IN 
//CONNECTION WITH THE USE OF THE SOFTWARE, EVEN IF IT HAS BEEN OR IS 
//HEREAFTER ADVISED OF THE POSSIBILITY OF SUCH DAMAGES.

// Author: Stelios Paparizos
// e-mail: spapariz@umich.edu
// Summary: Main file of the parsing procedure. 
// It contains the reductions procedure that processes the parse tree.
// But it also contains the procedures to generate the logical algebra plan
// and perform any potential rewrites that can be identified.

using System;
using System.Text;
using System.Collections;

using GoldParser;



namespace Timber.XQueryParser
{

	internal class InternalXQParser
	{
		private Parser m_parser;
		internal string reproducedQuery;
		internal string internalString;
		internal string parseErrorString;
		internal string parseString;
		internal bool errorHappened;
		internal ArrayList patternTrees;
		private ArrayList variableListCurrent;
		private ArrayList variableListGlobal;
		internal string variableString;
		internal ProcessTreeNode processTreeNode;
		private ArrayList usedPatternTrees;

		internal InternalXQParser()
		{
			HelpFunctions.lcl = 1;
			HelpFunctions.reflcl = 1000;
			HelpFunctions.nodeID = 1;
			HelpFunctions.treeID = 1;
			patternTrees = new ArrayList();
			variableListCurrent = new ArrayList();
			this.variableListGlobal = new ArrayList();
			this.processTreeNode = null;
			this.usedPatternTrees = new ArrayList();

			this.variableString = "";
			reproducedQuery = "";
			internalString = "";
			HelpFunctions.errorString = "";
			parseErrorString = "";
			parseString = "";
			HelpFunctions.success = true;
			this.errorHappened = false;
			try
			{
				m_parser = new Parser("xquery.cgt");
			}
			catch (Exception e)
			{
				HelpFunctions.errorString = e.ToString();
				HelpFunctions.success = false;
				this.errorHappened = true;
				throw(e);
			}	


		}

		/// <summary>
		/// Input is an XQuery, output a generated logical algebra plan
		/// </summary>
		/// <param name="queryInput">The XQuery to parse</param>
		/// <param name="stringOrFile">If the input is in file format instead of a string</param>
		/// <returns>A string with the generated logical algebra plan</returns>
		internal string parse(string queryInput, bool stringOrFile)
		{
			string output = "myout";

			try
			{
				if (stringOrFile)
					m_parser.OpenString(queryInput);
				else 
					m_parser.OpenFile(queryInput);
				this.Execute();
			}
			catch (Exception e)
			{
				HelpFunctions.errorString = e.ToString();
				HelpFunctions.success = false;
				this.errorHappened = true;
			}	

			m_parser.CloseFile();

			if(!HelpFunctions.success) 
			{
				output = "ERROR: " + HelpFunctions.errorString;
				parseErrorString = HelpFunctions.errorString;;
				this.errorHappened = true;
				return output;
			}

			try
			{
				this.processTreeNode = this.rewriteTree((FLWORNode)(this.processTreeNode));
			}
			catch (Exception e)
			{
				HelpFunctions.errorString += "\n" + e.ToString();
				output = "ERROR: Internal error while performing rewrite optimizations.\n The error is:\n" + HelpFunctions.errorString;
				parseErrorString = HelpFunctions.errorString;
				HelpFunctions.success = false;
				this.errorHappened = true;
				return output;
			}	

			try
			{

				output = this.generateLogicalPlan();
			}
			catch (Exception e)
			{
				HelpFunctions.errorString = e.ToString();
				output = "ERROR: An internal error happened while generating the Logical plan.\n\n\n The exception thrown is:\n" + HelpFunctions.errorString;
				parseErrorString = HelpFunctions.errorString;;
				HelpFunctions.success = false;
				this.errorHappened = true;
				return output;
			}	
			return output;
		}//parse



		/// <summary>
		/// Input the process tree, rewrite it to perform optimizations, an output the new tree.
		/// </summary>
		/// <param name="nin">The input process tree node</param>
		/// <returns>The output node after the rewrites have been performed</returns>
		private FLWORNode rewriteTree(FLWORNode nin)
		{
			FLWORNode outnode = null;
			FLWORNode tmpnode = nin;

			try
			{
				tmpnode = this.rewriteMoveSortNodes(tmpnode);
			}
			catch (Exception e)
			{
				HelpFunctions.errorString = "Problem with moving the Sort Node.\n";
				this.parseErrorString = HelpFunctions.errorString;;
				HelpFunctions.success = false;
				this.errorHappened = true;
				throw(e);
			}	

			try
			{
				tmpnode = this.rewriteMergeSelectsForConstruct(tmpnode);
			}
			catch (Exception e)
			{
				HelpFunctions.errorString = "Problem with merging the selects for construct.\n";
				this.parseErrorString = HelpFunctions.errorString;;
				HelpFunctions.success = false;
				this.errorHappened = true;
				throw(e);
			}	

			try
			{
				tmpnode = this.adjustMLCANodes(tmpnode);
			}
			catch (Exception e)
			{
				HelpFunctions.errorString = "Problem when adjusting the MLCA nodes.\n";
				this.parseErrorString = HelpFunctions.errorString;;
				HelpFunctions.success = false;
				this.errorHappened = true;
				throw(e);
			}	

			try
			{
				tmpnode = this.rewriteMoveUpdateNodes(tmpnode);
			}
			catch (Exception e)
			{
				HelpFunctions.errorString = "Problem with moving the Update Nodes.\n";
				this.parseErrorString = HelpFunctions.errorString;;
				HelpFunctions.success = false;
				this.errorHappened = true;
				throw(e);
			}	


			outnode = tmpnode;
			return outnode;
		}//rewriteTree



		/// <summary>
		/// Used as a rewrite to mode the sort node before the construct node.
		/// </summary>
		/// <param name="nin">A process tree node to work with</param>
		/// <returns>The input node after the sort nodes have been moved</returns>
		private FLWORNode rewriteMoveSortNodes(FLWORNode nin)
		{
			FLWORNode nout = nin;
			FLWORNode constructNode = null;
			FLWORNode sortNode = null;
			FLWORNode iter = null;

			iter = nin;

			while(iter!=null)
			{
				// find a construct operator
				if (iter.GetType().Name == "ConstructNode")	constructNode = iter;
				// find a sort node
				if (iter.GetType().Name == "SortNode")
				{
					sortNode = iter;
					if (constructNode != null)
					{
						FLWORNode tmp1 = (FLWORNode)(sortNode.getParent());
						if (tmp1 != constructNode)
						{
							tmp1.removeChild(sortNode);
							tmp1.addChild((Node)(sortNode.getChildren()[0]));
							sortNode.removeChild((Node)(sortNode.getChildren()[0]));
							sortNode.addChild((Node)(constructNode.getChildren()[0]));
							constructNode.removeChild((Node)(constructNode.getChildren()[0]));
							constructNode.addChild(sortNode);
							iter = (FLWORNode)(iter.getChildren()[0]); 
							constructNode = null;
							sortNode = null;
						}
					}
				}
				if (iter.GetType().Name == "JoinNode") iter = (FLWORNode)(iter.getChildren()[1]);
				else 
				{
					if (iter.getChildren().Count == 0) break;
					iter = (FLWORNode)(iter.getChildren()[0]);
				}
			}
			return nout;
		}//rewriteMoveSortNodes


		/// <summary>
		/// Merge the select operators that have the same root by reference and are used for the construct.
		/// Generate smaller plans and easier for the optimizer to choose which path to access first.
		/// </summary>
		/// <param name="nin">The input process tree node</param>
		/// <returns>The output node after the rewrite has been performed</returns>
		private FLWORNode rewriteMergeSelectsForConstruct(FLWORNode nin)
		{
			FLWORNode nout = nin;
			FLWORNode constructNode = null;
			FLWORNode iter = null;
			ArrayList selectList = new ArrayList();

			iter = nin;


			// stop when duplicate elimination
			while(iter!=null)
			{
				// find a construct operator
				if (iter.GetType().Name == "ConstructNode")	constructNode = iter;
				// find all selects after construct
				if ((constructNode!=null)&&(iter.GetType().Name == "SelectNode")) 
				{ 
					FLWORNode select = (FLWORNode)(iter);
					FLWORNode parent = (FLWORNode)(iter.getParent());
					FLWORNode child = (FLWORNode)(iter.getChildren()[0]);
					select.removeChild(child);
					select.setParent(null);
					parent.removeChild(select);
					child.setParent(parent);
					parent.addChild(child);
					selectList.Add(select); 
					iter = parent;
				}
				// find a succeeding duplicate elimination node node
				if ((constructNode!=null)&&(iter.GetType().Name == "DuplicateEliminationNode"))
				{
					// end of processing, perform the rewrite
					if (selectList.Count >0)
					{
						// iterate over the list, if the select operators have the root reference
						// to the same node, then merge them
						for(int i=0;i<selectList.Count;i++)
						{
							SelectNode si = (SelectNode)(selectList[i]);
							PatternTree pi = si.getPatternTree();
							PatternTreeNode piroot = (PatternTreeNode)(pi.getRoot()); 
							for(int j=i+1;j<selectList.Count;j++)
							{
								SelectNode sj = (SelectNode)(selectList[j]);
								PatternTree pj = sj.getPatternTree();
								PatternTreeNode pjroot = (PatternTreeNode)(pj.getRoot()); 
								if (piroot.getTagName() == pjroot.getTagName())
								{
									for(int k=0;k<pjroot.getChildren().Count;k++)
									{
										piroot.addChild((Node)(pjroot.getChildren()[k]));
									}
									this.patternTrees.Remove(pj);
									selectList.Remove(sj);
									j--;
								}
							}
						}
						for(int i=0;i<selectList.Count;i++)
						{
							FLWORNode flout = null;
							this.addParentToProcessTreeNodeWithId((FLWORNode)(selectList[i]), iter.getId(), nout, out flout);
							if (flout!=null) nout = flout;
						}
						
					}
					// reset the variables
					constructNode = null;
					selectList = new ArrayList();
				}
				if (iter.GetType().Name == "JoinNode") iter = (FLWORNode)(iter.getChildren()[1]);
				else 
				{
					if (iter.getChildren().Count == 0) break;
					iter = (FLWORNode)(iter.getChildren()[0]);
				}
			}
			return nout;
		}//rewriteMergeSelectsForConstruct

		private FLWORNode rewriteMoveUpdateNodes(FLWORNode nin)
		{
			FLWORNode nout = nin;
			FLWORNode constructNode = null;
			FLWORNode uNode = null;
			FLWORNode iter = null;

			iter = nin;

			while(iter!=null)
			{
				// find a construct operator
				if (iter.GetType().Name == "ConstructNode")	constructNode = iter;
				// find update node, delete, insert, update
				if ((iter.GetType().Name == "DeleteNode")||(iter.GetType().Name == "InsertNode")||(iter.GetType().Name == "UpdateNode"))
				{
					uNode = iter;
					if (constructNode != null)
					{
						FLWORNode cnchild = (FLWORNode)(constructNode.getChildren()[0]);
						while ((cnchild.GetType().Name == "DeleteNode")||(cnchild.GetType().Name == "InsertNode")||(cnchild.GetType().Name == "UpdateNode"))
						{
							constructNode = cnchild;
							cnchild = (FLWORNode)(constructNode.getChildren()[0]);
						}
						FLWORNode tmp1 = (FLWORNode)(uNode.getParent());
						if (tmp1 != constructNode)
						{
							tmp1.removeChild(uNode);
							tmp1.addChild((Node)(uNode.getChildren()[0]));
							uNode.removeChild((Node)(uNode.getChildren()[0]));
							uNode.addChild((Node)(constructNode.getChildren()[0]));
							constructNode.removeChild((Node)(constructNode.getChildren()[0]));
							constructNode.addChild(uNode);
							iter = (FLWORNode)(iter.getChildren()[0]); 
							//constructNode = null;
							uNode = null;
						}
					}
				}
				if (iter.GetType().Name == "JoinNode") iter = (FLWORNode)(iter.getChildren()[1]);
				else 
				{
					if (iter.getChildren().Count == 0) break;
					iter = (FLWORNode)(iter.getChildren()[0]);
				}
			}
			return nout;
		}//rewriteMoveUpdateNodes


		private FLWORNode generateFiltersForMLCANode(PatternTreeNode pnode, FLWORNode input)
		{
			FLWORNode output = input;

			PatternTreeNodeCondition ptnc = pnode.getPatternTreeNodeCondition();
			if (ptnc != null)
			{
				FilterNode fn = new FilterNode(HelpFunctions.nodeID++);
				fn.setCondition(ptnc);
				if (output == null) output = fn;
				else 
				{
					fn.addChild(output);
					output.setParent(fn);
					output = fn;
				}
				pnode.setPatternTreeNodeCondition(null);
			}

			for(int i=0;i<pnode.getChildren().Count;i++)
			{
				output = this.generateFiltersForMLCANode((PatternTreeNode)(pnode.getChildren()[i]), output);
			}

			return output;
		}


		private FLWORNode adjustMLCANodes(FLWORNode nin)
		{
			FLWORNode nout = nin;
			MLCANode mlcaNode = null;
			FLWORNode iter = null;

			iter = nin;

			while(iter!=null)
			{
				// find an MLCA operator
				if (iter.GetType().Name == "MLCANode")
				{
					mlcaNode = (MLCANode)(iter);
					// check if mlca variable match paths in the pattern tree
					PatternTree mpt = mlcaNode.getPatternTree();
					PatternTreeNode mptr = (PatternTreeNode)(mpt.getRoot());
					int varnum = mlcaNode.getMLCAList().Count - 1;
					if (mptr.getChildren().Count > varnum)
					{
						// extract the paths as a separate select operator

						PatternTreeNode pr = new PatternTreeNode(HelpFunctions.reflcl++, mptr.getId().ToString(), false, (int)(values.child), (int)(values.referenceNode));
						pr.setStructuralJoinType((int)(values.structuralJoinOne));
						for(int j=varnum;j<mptr.getChildren().Count;j++)
						{
							PatternTreeNode child = (PatternTreeNode)(mptr.getChildren()[j]);
							mptr.removeChild(child);
							pr.addChild(child);
							j--;
						}
						PatternTree spt = new PatternTree(HelpFunctions.treeID++);
						spt.setRoot(pr);

						SelectNode s1 = new SelectNode(HelpFunctions.nodeID++);
						s1.setPatternTree(spt);
						this.patternTrees.Add(spt);

						FLWORNode parent = (FLWORNode)(mlcaNode.getParent());
						s1.setParent(parent);
						// iterate over all nodes and pull out the conditions as filters
						FLWORNode filters = this.generateFiltersForMLCANode(mptr, null);
						if (filters!=null)
						{
							FLWORNode last = filters;
							while (last.getChildren().Count > 0)
							{
								last = (FLWORNode)(last.getChildren()[0]);
							}

							s1.addChild(filters);
							filters.setParent(s1);
							last.addChild(mlcaNode);
							mlcaNode.setParent(last);
						}
						else
						{
							s1.addChild(mlcaNode);
							mlcaNode.setParent(s1);
						}

						if (parent.GetType().Name == "JoinNode")
						{
							return s1;
						}
						else
						{
							parent.removeChild(mlcaNode);
							parent.addChild(s1);
						}

					}
					else
					{
						// iterate over all nodes and pull out the conditions as filters
						FLWORNode filters = this.generateFiltersForMLCANode(mptr, null);
						if (filters!=null)
						{
							FLWORNode last = filters;
							while (last.getChildren().Count > 0)
							{
								last = (FLWORNode)(last.getChildren()[0]);
							}

							FLWORNode parent = (FLWORNode)(mlcaNode.getParent());
							last.addChild(mlcaNode);
							mlcaNode.setParent(last);
							filters.setParent(parent);
							if (parent.GetType().Name == "JoinNode")
							{
								return filters;
							}
							else
							{
								parent.removeChild(mlcaNode);
								parent.addChild(filters);
							}
						}

					}
				}

				if (iter.GetType().Name == "JoinNode") 
				{
					iter.getChildren()[0] = this.adjustMLCANodes((FLWORNode)(iter.getChildren()[0]));
					iter.getChildren()[1] = this.adjustMLCANodes((FLWORNode)(iter.getChildren()[1]));
					break;
				}
				else 
				{
					if (iter.getChildren().Count == 0) break;
					iter = (FLWORNode)(iter.getChildren()[0]);
				}
			}//end while(iter!=null)
			return nout;
		}//adjustMLCANodes


		/// <summary>
		/// Find the node with the given pattern tree id and add the newnode as its parent in the tree,
		/// rearranging the tree if necessary.
		/// </summary>
		/// <param name="newNode">The node to be added</param>
		/// <param name="pid">The pid of the operator to be found</param>
		/// <param name="ptn">A process tree operator to act as a starting point</param>
		/// <param name="ptout">The starting point operator, after the new node has been added to the tree</param>
		private void addParentToProcessTreeNodeWithPid(FLWORNode newNode, int pid, FLWORNode ptn, out FLWORNode ptout)
		{
			ptout = null;
			if (pid < 0)
			{
				HelpFunctions.success = false;
				HelpFunctions.errorString = "Error: Invalid pattern tree number in addProcessNode pid: " + pid.ToString() + "\n";
			}
			else
			{
				if ((ptn.getPatternTree() != null) && (pid == ptn.getPatternTree().getId()))
				{
					FLWORNode parent = (FLWORNode)(ptn.getParent());
					if (parent != null)
					{
						int position = -1;
						if (parent.getChildren()[0] == ptn) position = 0;
						else if (parent.getChildren()[1] == ptn) position = 1;
						//						int position = children.BinarySearch(ptn);
						parent.getChildren()[position] = newNode;
						newNode.setParent(parent);
					}
					ptn.setParent(newNode);
					newNode.addChild(ptn);
					ptout = newNode;
				}
				else if (ptn.getChildren().Count != 0)
				{
					for(int i = 0; i<ptn.getChildren().Count;i++)
					{
						FLWORNode pto = null;
						this.addParentToProcessTreeNodeWithPid(newNode, pid, (FLWORNode)(ptn.getChildren()[i]), out pto);
						if (pto!= null) {ptout = ptn; break;}
					}
				}
			}
		}//addParentToProcessTreeNodeWithPid

		/// <summary>
		/// Find the node with the given operator id and add the newnode as its parent in the tree,
		/// rearranging the tree if necessary.
		/// </summary>
		/// <param name="newNode">The node to be added</param>
		/// <param name="id">The id of the operator to be found</param>
		/// <param name="ptn">A process tree operator to act as a starting point</param>
		/// <param name="ptout">The starting point operator, after the new node has been added to the tree</param>
		private void addParentToProcessTreeNodeWithId(FLWORNode newNode, int id, FLWORNode ptn, out FLWORNode ptout)
		{
			ptout = null;
			if (id < 0)
			{
				HelpFunctions.success = false;
				HelpFunctions.errorString = "Error: Invalid node number in addProcessNode: " + id.ToString() + "\n";
			}
			else
			{
				if (id == ptn.getId())
				{
					FLWORNode parent = (FLWORNode)(ptn.getParent());
					if (parent != null)
					{
						int position = -1;
						if (parent.getChildren()[0] == ptn) position = 0;
						else if (parent.getChildren()[1] == ptn) position = 1;
						//						int position = children.BinarySearch(ptn);
						parent.getChildren()[position] = newNode;
						newNode.setParent(parent);
					}
					ptn.setParent(newNode);
					newNode.addChild(ptn);
					ptout = newNode;
				}
				else if (ptn.getChildren().Count != 0)
				{
					for(int i = 0; i<ptn.getChildren().Count;i++)
					{
						FLWORNode pto = null;
						this.addParentToProcessTreeNodeWithId(newNode, id, (FLWORNode)(ptn.getChildren()[i]), out pto);
						if (pto!= null) {ptout = ptn;}
					}
				}
			}
		}//addParentToProcessTreeNodeWithId


		/// <summary>
		/// Given a pattern tree id and a process tree operator, 
		/// look in its children (and self) find the operator with the given PID
		/// </summary>
		/// <param name="pid">The pattern tree id to look for</param>
		/// <param name="fln">The operator to start lookin into</param>
		/// <returns>The operator with the desired PID, null if not found</returns>
		private FLWORNode findOperatorFromPid(int pid, FLWORNode fln)
		{
			if ((fln.getPatternTree()!= null) && (fln.getPatternTree().getId() == pid)) return fln;
			for(int i=0;i<fln.getChildren().Count;i++)
			{
				FLWORNode n = this.findOperatorFromPid(pid, (FLWORNode)(fln.getChildren()[i]));
				if (n!=null) return n;
			}
			return null;
		}//findOperatorFromPid

		/// <summary>
		/// Given an operator id and a process tree operator, 
		/// look in its children (and self) find the operator with the given ID
		/// </summary>
		/// <param name="id">The operator ID to look for</param>
		/// <param name="fln">The operator to start lookin into</param>
		/// <returns>The operator with the desired PID, null if not found</returns>
		private FLWORNode findOperatorFromId(int id, FLWORNode fln)
		{
			if (fln.getId() == id) return fln;
			for(int i=0;i<fln.getChildren().Count;i++)
			{
				FLWORNode n = this.findOperatorFromId(id, (FLWORNode)(fln.getChildren()[i]));
				if (n!=null) return n;
			}
			return null;
		}//findOperatorFromId

		/// <summary>
		/// Given two operators in the process tree, return their first common ancestor
		/// </summary>
		/// <param name="op1">The first operator</param>
		/// <param name="op2">The second operator</param>
		/// <returns>The common ancestor, null if not found</returns>
		private FLWORNode findCommonOperator(FLWORNode op1, FLWORNode op2)
		{
			FLWORNode p1 = op1;
			bool found = false;
			while(!found)
			{
				FLWORNode p2 = op2;
				bool found2 = false;
				while(!found2)
				{
					if(p1 == p2) return p1;
					else
					{
						p2 = (FLWORNode)(p2.getParent());
						if (p2 == null) {found2 = true; break;}
					}
				}
				p1 = (FLWORNode)(p1.getParent());
				if (p1 == null) found = true;
			}
			return null;
		}//findCommonOperator

		/// <summary>
		/// Given two operators, find the first common ancestor that is a join.
		/// </summary>
		/// <param name="op1">The first operator</param>
		/// <param name="op2">The second operator</param>
		/// <returns>The first common ancestor that is a join, null if not found</returns>
		private FLWORNode findJoin(FLWORNode op1, FLWORNode op2)
		{
			FLWORNode p1 = (FLWORNode)(op1.getParent());
			bool found = false;
			while(!found)
			{
				while(p1.GetType().Name != "JoinNode")
				{
					p1 = (FLWORNode)(p1.getParent());
					if (p1 == null) return null;
				}
				FLWORNode p2 = (FLWORNode)(op2.getParent());
				bool found2 = false;
				while(!found2)
				{
					if(p1 == p2) return p1;
					else
					{
						p2 = (FLWORNode)(p2.getParent());
						if (p2 == null) {found2 = true; break;}
					}
					while(p2.GetType().Name != "JoinNode")
					{
						p2 = (FLWORNode)(p2.getParent());
						if (p2 == null) found2 = true;
					}
				}
				p1 = (FLWORNode)(p1.getParent());
				if (p1 == null) found = true;
			}

			return null;
		}//findJoin

		/// <summary>
		/// Given a variable name, return true if it already exists in the system.
		/// </summary>
		/// <param name="varname">The variable name to test for</param>
		/// <returns>True if the variable name already exists</returns>
		private bool checkIfVariableNameExists(string varname)
		{
			for(int i=0;i<this.variableListCurrent.Count;i++)
			{
				VariableMapping vm = (VariableMapping)(this.variableListCurrent[i]);
				if (vm.getName() == varname) return true;
			}
			for(int i=0;i<this.variableListGlobal.Count;i++)
			{
				VariableMapping vm = (VariableMapping)(this.variableListGlobal[i]);
				if (vm.getName() == varname) return true;
			}
			return false;
		}


		/// <summary>
		/// Returns true if the input pattern tree is actually a path
		/// </summary>
		/// <param name="pt">Pattern Tree to be checked</param>
		/// <returns>True if path, false otherwise</returns>
		private bool checkPatternTreeIsPath(PatternTree pt)
		{
			PatternTreeNode rn = (PatternTreeNode)(pt.getRoot());
			if (rn.getChildren().Count == 0) return true;
			while (rn.getChildren().Count != 0)
			{
				if (rn.getChildren().Count > 1) return false;
				rn = (PatternTreeNode)(rn.getChildren()[0]);
			}
			return true;
		}//checkPatternTreeIsPath


		/// <summary>
		/// An internal funtion that generates a logical algebra plan from the global process tree
		/// </summary>
		/// <returns>A string with the logical algebra plan</returns>
		private string generateLogicalPlan()
		{
			int patternTreeNodeCountOut;
			int patternTreeCountOut;
			int processTreeNodeCountOut;
			string patternTreeNodesOut;
			string patternTreesOut;
			string processTreeNodesOut;
			string processTreeOut;

			//			ProcessTreeNode ptn = (ProcessTreeNode)(this.processTree.getRoot());
			ProcessTreeNode ptn = this.processTreeNode;
			ptn.getLogicalPlan(
				0, out patternTreeNodeCountOut,
				0, out patternTreeCountOut,
				0, out processTreeNodeCountOut,
				"", out patternTreeNodesOut,
				"", out patternTreesOut,
				"", out processTreeNodesOut,
				"", out processTreeOut,
				this.variableListGlobal);

			string[] elements = processTreeOut.Split(' ');
			int rootID = int.Parse(elements[0]);
			processTreeOut = "0 " + processTreeNodeCountOut + " " + rootID + "\n" + processTreeOut;

			string output = "// Logical plan\n";
			output += "// number of Pattern Tree Nodes, Pattern Trees and Process Tree Nodes\n";
			output += patternTreeNodeCountOut + "\n" + patternTreeCountOut + "\n" + processTreeNodeCountOut + "\n";
			output += "// list of pattern tree nodes \n";
			output += patternTreeNodesOut;
			output += "// list of pattern trees \n";
			output += patternTreesOut;
			output += "// list of process tree nodes \n";
			output += processTreeNodesOut;
			output += "// process tree \n";
			output += processTreeOut;
			return output;
		}//generateLogicalPlan




		/// <summary>
		/// Retrieves the stack element for a given production rule posistion
		/// </summary>
		/// <param name="num">The position in the production rule</param>
		/// <param name="reduction">The input reduction object containing the tokens</param>
		/// <returns>A stack element object with the information in the given position</returns>
		private myStackElement getMyStackElementFromProduction(int num, Reduction reduction)
		{
			Token tok = reduction.GetToken(num);
			myStackElement myEl = (myStackElement)(((Reduction)(tok.Data)).Tag);
			return myEl;
		}

		/// <summary>
		/// Generates the stack element for a given lexeme
		/// </summary>
		/// <param name="num">The position the data is in</param>
		/// <param name="reduction">The redunction object containing the information</param>
		/// <returns>A stack element object</returns>
		private myStackElement getMyStackElementFromLexeme(int num, Reduction reduction)
		{
			Token tok = reduction.GetToken(num);
			string nameVal = (string)(tok.Data);
			myStackElement myEl = new myStackElement();
			myEl.setMyName(nameVal);
			return myEl;
		}

		/// <summary>
		/// The stack element corresponds to a pattern tree node, return it if it exists, construct the necessary info if not.
		/// </summary>
		/// <param name="myEl">The stack element input</param>
		/// <returns>The pattern tree node that corresponds to the input stack element</returns>
		private PatternTreeNode getPatternTreeNodeFromMyStackElement(myStackElement myEl)
		{
			PatternTreeNode ptn = (PatternTreeNode)(myEl.getMyNode());
			if (ptn == null)
			{
				string tag = myEl.getMyName();
				if (tag == "text()") ptn = new PatternTreeNode(0);
				else ptn = new PatternTreeNode(HelpFunctions.lcl++);
				if (tag.StartsWith("@")) {tag = tag.Substring(1);ptn.setSpecial((int)(values.attribute));}
				ptn.setTagName(tag); 
				
			}
			return ptn;
		}

		/// <summary>
		/// The stack element maps to a FOR/LET node, get the information from it
		/// </summary>
		/// <param name="myEl">The stack element with the info</param>
		/// <returns>A FOR/LET node containing the information of the stack element</returns>
		private FLNode getFLNodeFromMyStackElement(myStackElement myEl)
		{
			FLNode ptn = null;
			Node node = myEl.getMyNode();
			string mytyp = node.GetType().ToString();
			if (node.GetType() == Type.GetType("Timber.XQueryParser.FLNode"))
			{
				ptn = (FLNode)(node);
			}
			if (ptn == null)
			{
				// we must create a new process tree node and associate the selection
				// with the given pattern tree
				ptn = new FLNode(HelpFunctions.nodeID++);
				PatternTree mypt = (PatternTree)(myEl.getMyTree());
				if (mypt == null) 
				{
					HelpFunctions.success = false;
					HelpFunctions.errorString = "Internal Error: No pattern tree was generated with the process tree node";
				}
				else if (!this.checkPatternTreeIsPath(mypt))
				{
					HelpFunctions.success = false;
					HelpFunctions.errorString = "Error: Currently we only support simple path expressions for the bound variables";
				}
				ptn.setPatternTree(mypt);
				if (myEl.getMyName().StartsWith("FOR")) ptn.setNodeSubType((int)values.forSubType);
				else if(myEl.getMyName().StartsWith("LET")) ptn.setNodeSubType((int)values.letSubType);
			}
			return ptn;
		}//getFLNodeFromMyStackElement


		/// <summary>
		/// Process the stack element and retrieve the where node information from it
		/// </summary>
		/// <param name="myEl">A stack element containing where node information</param>
		/// <returns>The corresponding WhereNode</returns>
		private WhereNode getWhereNodeFromMyStackElement(myStackElement myEl)
		{
			WhereNode ptn = null;
			Node node = myEl.getMyNode();
			if (node.GetType() == Type.GetType("Timber.XQueryParser.WhereNode"))
			{
				ptn = (WhereNode)(node);
			}
			if (ptn == null)
			{
				PatternTree pt = new PatternTree(HelpFunctions.treeID++);
				pt.setRoot(node);
				ptn = new WhereNode(HelpFunctions.nodeID++);
				ptn.setPatternTree(pt);
				//ptn.setNodeSubType((int)values.whereSubType); 
			}
			return ptn;
		}//getWhereNodeFromMyStackElement


		/// <summary>
		/// Process the stack element and generate an order by node
		/// </summary>
		/// <param name="myEl">The stack element containing the info</param>
		/// <returns>An order by node</returns>
		private OrderByNode getOrderByNodeFromMyStackElement(myStackElement myEl)
		{
			OrderByNode ptn = null;
			Node node = myEl.getMyNode();
			ArrayList mylist = myEl.getMyList();
			if (mylist.Count == 0)
			{
				// sort by one thing
				if (node.GetType() == Type.GetType("Timber.XQueryParser.OrderByNode"))
					ptn = (OrderByNode)(node);
				if (ptn == null)
				{
					ptn = new OrderByNode(HelpFunctions.nodeID++);
					if (node.GetType().Name == "SortPatternTreeNode") ptn.addToSortList((SortPatternTreeNode)(node));
					else 
					{
						SortPatternTreeNode sptn = new SortPatternTreeNode(0);
						sptn.setMyNode((PatternTreeNode)(node));
						ptn.addToSortList(sptn);
					}
				}
			}
			else
			{
				ptn = new OrderByNode(HelpFunctions.nodeID++);
				// sort by multiple items
				for(int i=0;i<mylist.Count;i++)
					ptn.addToSortList((PatternTreeNode)(mylist[i]));
			}
			return ptn;
		}//getOrderByNodeFromMyStackElement


		/// <summary>
		/// Process the stack element and generate the appropriate return node information
		/// </summary>
		/// <param name="myEl">The stack element with the info</param>
		/// <returns>The corresponding Return node</returns>
		private ReturnNode getReturnNodeFromMyStackElement(myStackElement myEl)
		{
			ReturnNode rN = null;
			Node node = myEl.getMyNode();
			if (node.GetType() == Type.GetType("Timber.XQueryParser.ReturnNode"))
				rN = (ReturnNode)(node);
			if (rN == null)
			{
				// the return expression returns a construct tree
				// we create a construct tree and add it to the process tree
				PatternTree pt = new PatternTree(HelpFunctions.treeID++);
				pt.setRoot(node);
				rN = new ReturnNode(HelpFunctions.nodeID++);
				rN.setPatternTree(pt);
			}
			return rN;
		}//getReturnNodeFromMyStackElement


		/// <summary>
		/// Generate an element constructor from a reduction, output the stack element containing the necessary info.
		/// </summary>
		/// <param name="QName1">The starting tagname in the input</param>
		/// <param name="QName2">The closing tagname in the input, to see if the tagnames match</param>
		/// <param name="ElementContent">A pointer to the element content in the reduction</param>
		/// <param name="AttributeContent">A pointer to the attribute content in the reduction</param>
		/// <param name="reduction">The reduction</param>
		/// <param name="myEl">The output stack element containing the constructor information</param>
		/// <returns>True if the two tagnames do not match, false if everything went ok</returns>
		private bool generateElementConstructorFromReduction(
			int QName1, int QName2, int ElementContent, int AttributeContent, 
			GoldParser.Reduction reduction, out myStackElement myEl)
		{
			myEl = null;
			myStackElement myElQ1 = this.getMyStackElementFromProduction(QName1, reduction);
			myStackElement myElQ2 = this.getMyStackElementFromProduction(QName2, reduction);
			string myQName = myElQ1.getMyName();
			if (myQName != myElQ2.getMyName()) //check for matching tag names
				return true;

			// create construct pattern node
			ConstructElementPatternTreeNode cnode = new ConstructElementPatternTreeNode(HelpFunctions.lcl++);
			// add name, attribute list and content to it
			cnode.setEnclosingTagName(myQName);

			string outputName = "\n<" + myQName;

			if (AttributeContent != -1)
			{
				// get AttributeContent
				myStackElement myElA = this.getMyStackElementFromProduction(AttributeContent, reduction);
				if (myElA.getMyList().Count == 0) myElA.addToMyList(myElA.getMyNode());
				cnode.setAttributeList(myElA.getMyList());
				outputName += " " + myElA.getMyName();
			}

			if (ElementContent != -1)
			{
				// get ElementContent
				myStackElement myElC = this.getMyStackElementFromProduction(ElementContent, reduction);
				if (myElC.getMyList().Count == 0) myElC.addToMyList(myElC.getMyNode());
				cnode.setContentList(myElC.getMyList());
				outputName +=  ">\n\t" + myElC.getMyName();
			}
			outputName += "\n</" + myQName + ">";

			// create node to be returned, add construct information
			myEl = new myStackElement();
			myEl.setMyNode(cnode);
			myEl.setMyName(outputName);

			return false;
		}//generateElementConstructorFromReduction


		/// <summary>
		/// Process a reduction and generate a FLWORNode, output a stack element with the info.
		/// Also generate the corresponding operators for the process tree.
		/// </summary>
		/// <param name="FORLETpos">Position of the FOR/LET node in the reduction</param>
		/// <param name="WHEREpos">Position of the Where node in the reduction</param>
		/// <param name="ORDERBYpos">Position of the order by node in the reduction</param>
		/// <param name="RETURNpos">Position of the return node in the reduction</param>
		/// <param name="reduction">The input reduction</param>
		/// <param name="myEl">The generated stack element containing the FLWORNode</param>
		private void generateFLWORStmtFromReduction(
			int FORLETpos, int WHEREpos, int ORDERBYpos, int RETURNpos,
			GoldParser.Reduction reduction, out myStackElement myEl)
		{
			myStackElement myElFL = this.getMyStackElementFromProduction(FORLETpos, reduction);
			myStackElement myElR = this.getMyStackElementFromProduction(RETURNpos, reduction);

			string outputName = myElFL.getMyName();

			int operatorId = -1;
			if (this.processTreeNode!=null) operatorId = this.processTreeNode.getId();
			int lastOperatorId = operatorId;

			// check if node exists
			FLNode ptnFL = this.getFLNodeFromMyStackElement(myElFL);
			this.processAllForLets(ptnFL, operatorId, out lastOperatorId);
			operatorId = lastOperatorId;


			FLWORNode flworNode = new FLWORNode(HelpFunctions.nodeID++);
			flworNode.addChild(ptnFL);

			if (!HelpFunctions.success) 
			{
				myEl = new myStackElement();
				myEl.setMyName(outputName);
				myEl.setMyNode(flworNode);
				return;
			}


			if (WHEREpos != -1)
			{
				myStackElement myElW = this.getMyStackElementFromProduction(WHEREpos, reduction);
				WhereNode ptnW = this.getWhereNodeFromMyStackElement(myElW);
				flworNode.addChild(ptnW);
				outputName += myElW.getMyName();
				this.processWhereNode(ptnW.getPatternTree(), operatorId, out lastOperatorId);
				operatorId = lastOperatorId;
			}

			// create projection and duplicate elimination on the bound variables
			ProjectNode pjn = new ProjectNode(HelpFunctions.nodeID++);
			FLWORNode f1 = this.findOperatorFromId(operatorId, (FLWORNode)(this.processTreeNode));
			pjn.setRoot(f1.getRootLCL());
			for(int i=0; i < this.variableListCurrent.Count; i++)
			{
				VariableMapping vm = (VariableMapping)(this.variableListCurrent[i]);
				FLWORNode f1vm = this.findOperatorFromId(vm.getOid(), f1);
				if (f1vm!=null) 
				{
					pjn.addToProjectionList(vm.getWid());
				}
			}
		{
			FLWORNode ptout = null;
			this.addParentToProcessTreeNodeWithId(pjn, operatorId, (FLWORNode)(this.processTreeNode), out ptout);
			if (ptout != null) {this.processTreeNode = ptout; lastOperatorId = pjn.getId(); operatorId = lastOperatorId;}
		}
			DuplicateEliminationNode denode = new DuplicateEliminationNode(HelpFunctions.nodeID++);
			denode.setDENode(pjn.getRootLCL());
		{
			FLWORNode ptout = null;
			this.addParentToProcessTreeNodeWithId(denode, operatorId, (FLWORNode)(this.processTreeNode), out ptout);
			if (ptout != null) {this.processTreeNode = ptout; lastOperatorId = denode.getId(); operatorId = lastOperatorId;}
		}

			bool orderByExists = false;
			if (ORDERBYpos != -1)
			{
				myStackElement myElOB = this.getMyStackElementFromProduction(ORDERBYpos, reduction);
				OrderByNode ptnOB = this.getOrderByNodeFromMyStackElement(myElOB);
				flworNode.addChild(ptnOB);
				outputName += myElOB.getMyName();
				this.processOrderByNode(ptnOB.getSortList(), operatorId, out lastOperatorId);
				operatorId = lastOperatorId;
				orderByExists = true;
			}


			ReturnNode ptnR = this.getReturnNodeFromMyStackElement(myElR);
			flworNode.addChild(ptnR);
			outputName += "\nRETURN " + myElR.getMyName();
			this.processReturnTree(ptnR.getPatternTree(), operatorId, out lastOperatorId);
			operatorId = lastOperatorId;

			// remove variables from the list, their scope is over
			FLWORNode flret = this.findOperatorFromId(operatorId, (FLWORNode)(this.processTreeNode));
			if (flret.GetType().Name == "ConstructNode")
				flret = (FLWORNode)(flret.getChildren()[0]);
			ArrayList sortVarList = new ArrayList();
			for(int i=0; i < this.variableListCurrent.Count; i++)
			{
				VariableMapping vm = (VariableMapping)(this.variableListCurrent[i]);
				FLWORNode f1vm = this.findOperatorFromId(vm.getOid(), flret);
				if (f1vm!=null) 
				{
					this.variableString += vm.ToStringOut() + "\n";
					this.variableListGlobal.Add(vm);
					if (vm.getBindingType() == (int)(values.forBinding)) sortVarList.Add(vm);
					this.variableListCurrent.Remove(vm); 
					i--;
				}
			}

			if (!orderByExists)
			{
				if (sortVarList.Count>0)
				{
					// order by does not exist, create a sort operator on the For bound variables
					SortNode sn = new SortNode(HelpFunctions.nodeID++);
					for(int i=0;i<sortVarList.Count;i++)
					{
						VariableMapping vm = (VariableMapping)(sortVarList[i]);
						SortObject so = new SortObject(vm.getWid());
						so.setSortByType((int)(values.sortByKey));
						sn.addToSortList(so);
					}

					// last node should be the construct node
					FLWORNode c = this.findOperatorFromId(operatorId, (FLWORNode)(this.processTreeNode));
					if (c.GetType().Name == "ConstructNode")
					{
						FLWORNode child = (FLWORNode)(c.getChildren()[0]);
						c.removeChild(child);
						c.addChild(sn);
						sn.addChild(child);
					}
				}
			}


			this.reproducedQuery = outputName;

			myEl = new myStackElement();
			myEl.setMyName(outputName);
			myEl.setMyNode(flworNode);
		}//generateFLWORStmtFromReduction

		/// <summary>
		/// Adjusts the project and duplicate elinination operators so that they don't contain zero.
		/// This would happen if a reference node is used and it is updated afterwards.
		/// </summary>
		/// <param name="flop">The process tree node used as starting point to find project and DE operators</param>
		private void adjustProjectionAndDEZero(FLWORNode flop)
		{
			FLWORNode iter = flop;
			while (iter.GetType().Name != "ProjectNode")
			{
				iter = (FLWORNode)(iter.getChildren()[0]);
			}
			ProjectNode pn = (ProjectNode)(iter);
			pn.getProjectionList().Remove(0);
			FLWORNode child = (FLWORNode)(pn.getChildren()[0]);
			int rootwid = child.getRootLCL();
			pn.setRoot(rootwid);
			DuplicateEliminationNode denode = (DuplicateEliminationNode)(pn.getParent());
			denode.setDENode(rootwid);
		}


		/// <summary>
		/// If the variable points to a reference node, then change that to point to the node
		/// the reference node was referring to. Seen as a construct referenced node.
		/// </summary>
		/// <param name="flop">The operator to start looking in.</param>
		/// <param name="joinwidleft">Output the root id</param>
		/// <param name="joinwidright">Output the new id</param>
		private void replaceVariable(FLWORNode flop, out int joinwidleft, out int joinwidright)
		{
			joinwidleft = -1;
			joinwidright = -1;
			if (flop.GetType().Name == "SelectNode")
			{
				PatternTree pt = flop.getPatternTree();
				PatternTreeNode rootpt = (PatternTreeNode)(pt.getRoot());
				if (rootpt.getId() == 0)
				{
					string vname = rootpt.getTagName();
					int pid = -1;
					int wid = -1;
					// find where the variable points to
					for(int i=0;i<this.variableListCurrent.Count;i++)
					{
						VariableMapping vm = (VariableMapping)(this.variableListCurrent[i]);
						if (vname == vm.getName())
						{
							pid = vm.getPid();
							wid = vm.getWid();
							break;
						}
					}
					// find the pattern tree
					PatternTreeNode refnode = null;
					PatternTreeNode docnode = null;
					for(int i=0; i<this.patternTrees.Count;i++)
					{
						PatternTree pttmp = (PatternTree)(this.patternTrees[i]);
						if (pttmp.getId() == pid)
						{
							docnode = (PatternTreeNode)(pttmp.getRoot());
							refnode = docnode.findPatternTreeNode(wid);
							break;
						}
					}
					rootpt.setId(HelpFunctions.lcl++);
					rootpt.setTagName(refnode.getTagName());
					PatternTreeNode newdocnode = new PatternTreeNode(HelpFunctions.lcl++);
					newdocnode.setTagName(docnode.getTagName());
					newdocnode.addChild(rootpt);
					joinwidright = rootpt.getId();
					joinwidleft = wid;
					pt.setRoot(newdocnode);
					return;
				}
			}
			for(int i=0; i< flop.getChildren().Count; i++)
			{
				FLWORNode fl = (FLWORNode)(flop.getChildren()[i]);
				this.replaceVariable(fl, out joinwidleft, out joinwidright);
				if (joinwidleft != -1) return;
			}
		}


		/// <summary>
		/// Creates (merges to) a select operator for a given FOR/LET path. Returns the operator id that the bound variable points to
		/// </summary>
		/// <param name="ptin">The pattern tree for the path</param>
		/// <param name="operatorId">Current position in the process tree</param>
		/// <param name="lastOperatorId">The operator id on the top of the list</param>
		/// <param name="nestedQuery">If we are in a nested query</param>
		/// <returns>The operator id that the bound variable should point to</returns>
		private int	processSelectFromForLetPath(PatternTree ptin, int operatorId, out int lastOperatorId, bool nestedQuery)
		{

			if (this.usedPatternTrees.Contains(ptin.getId()))
			{
				lastOperatorId = operatorId;
				FLWORNode flop = this.findOperatorFromPid(ptin.getId(), (FLWORNode)(this.processTreeNode));
				if(flop == null)// this will happen for nested queries when merging variables had occured
				{
					string rname = ((PatternTreeNode)(ptin.getRoot())).getTagName();
					if (rname.StartsWith("$"))
					{
						// find variable and where it was merged to
						int pid = -1;
						for(int i=0; i<this.variableListCurrent.Count; i++)
						{
							VariableMapping vm = (VariableMapping)(this.variableListCurrent[i]);
							if (vm.getName() == rname) {pid = vm.getPid(); break;}
						}
						if (pid == -1)
						{
							HelpFunctions.success = false;
							HelpFunctions.errorString = "Error: Variable Not Found!" + rname;
							return -1;
						}
						flop = this.findOperatorFromPid(pid, (FLWORNode)(this.processTreeNode));
						// find operator and return id
					}
					else 
					{
						HelpFunctions.success = false;
						HelpFunctions.errorString = "Error: Operator Not Found! Pid:" + ptin.getId();
						return -1;
					}
				}
				return flop.getId();
			}

			this.usedPatternTrees.Add(ptin.getId());
			int rid = -1;
			lastOperatorId = operatorId;
			PatternTreeNode pta = (PatternTreeNode)(ptin.getRoot());
			// generate the appropriate process tree node
			if (this.processTreeNode == null)
			{
				// this is the first operator
				SelectNode snode = new SelectNode(HelpFunctions.nodeID++);
				snode.setPatternTree(ptin);
				this.processTreeNode = snode;
				rid = snode.getId();
				lastOperatorId = rid;
				return rid;
			}
			else // other operators exist
			{
				string tagName = pta.getTagName();
				// check if starts with document
				bool nestedStructural = false;
				int refwidleft = -1;
				int refwidright = -1;
				if (this.processTreeNode.GetType().Name == "ConstructNode")
				{
					nestedStructural = true;
					nestedQuery = true;
					// find nodes with id 0, they are reference nodes,
					// substitute the variable binding with the node it maps to
					this.replaceVariable((FLWORNode)(this.processTreeNode), out refwidleft, out refwidright);
					this.adjustProjectionAndDEZero((FLWORNode)(this.processTreeNode));
				}
				if ((tagName.StartsWith("document"))||(pta.GetType().Name == "MLCAPatternTreeNode"))
				{
					// since other operator exist and the input path starts with document
					// we need to build a join/cartesian product
					// create information for join
					// left side is the existing side
					int leftSideRootRef = this.processTreeNode.getRootLCL();
					PatternTreeNode pnode1 = new PatternTreeNode(HelpFunctions.reflcl++, leftSideRootRef.ToString(), false, (int)(values.child), (int)(values.referenceNode));
					pnode1.setStructuralJoinType((int)(values.structuralJoinOne));
					// right side is the new select operator
					PatternTreeNode pnode2 = null;
					if(pta.GetType().Name == "MLCAPatternTreeNode")
					{
						MLCAPatternTreeNode mpta = (MLCAPatternTreeNode)(pta);
						pnode2 = new PatternTreeNode(HelpFunctions.reflcl++, mpta.getPatternTree().getRoot().getId().ToString(), false, (int)(values.child), (int)(values.referenceNode));
					}
					else pnode2 = new PatternTreeNode(HelpFunctions.reflcl++, pta.getId().ToString(), false, (int)(values.child), (int)(values.referenceNode));
					pnode2.setStructuralJoinType((int)(values.structuralJoinOne));
					// if nested query switch sides
					if (nestedQuery)
					{
						PatternTreeNode tmp = null;
						tmp = pnode1;
						pnode1 = pnode2;
						pnode2 = tmp;
					}
					// create a cartesian product at first, if a join condition is in the where clause this will updated when processed
					JoinDualPatternTreeNode jnode = new JoinDualPatternTreeNode(HelpFunctions.lcl++, "JOIN", (int)(values.cartesianProduct), pnode1, pnode2, -1, "=", -1);
					if (nestedStructural)
					{
						PatternTreeJoinCondition ptjc = new PatternTreeJoinCondition(refwidleft, "is", refwidright);
						jnode.setSpecial((int)(values.join));
						jnode.setJoinCondition(ptjc);
					}
					PatternTree jpt = new PatternTree(HelpFunctions.treeID++);
					jpt.setRoot(jnode);
					this.patternTrees.Add(jpt);

					// left side is the existing side
					FLWORNode child1 = (FLWORNode)(this.processTreeNode); 
					FLWORNode child2 = null; 


					if(pta.GetType().Name == "MLCAPatternTreeNode")
					{
						MLCAPatternTreeNode ar = (MLCAPatternTreeNode)(pta);
						MLCANode mn = new MLCANode(HelpFunctions.nodeID++);
						mn.setMLCAList(ar.getBoundNodes());
						mn.setPatternTree(ar.getPatternTree());
						this.patternTrees.Add(mn.getPatternTree());

						// update the variable table, the variable should bind to the mlca root, not the function node
						string fname = "empty";
						for(int i=0; i<this.variableListCurrent.Count; i++)
						{
							VariableMapping vm = (VariableMapping)(this.variableListCurrent[i]);
							if (vm.getPid() == mn.getPatternTree().getId()) 
							{
								vm.setOid(mn.getId());
								fname = vm.getFileName();
							}
							if (vm.getPid() == ptin.getId()) 
							{
								vm.setOid(mn.getId()); 
								vm.setPid(mn.getPatternTree().getId());
								vm.setMLCA();
								vm.setFileName(fname);
							}
							//					if (vm.getWid() == ar.getId()) 
							//					{
							//						PatternTreeNode r1 = (PatternTreeNode)(ar.getPatternTree().getRoot());
							//						VariableMapping vp = (VariableMapping)(this.variableListCurrent[i-1]);// the previous binding is an MLCA one
							//						VariableMapping v1 = new VariableMapping(vm.getName(), ar.getPatternTree().getId(), r1.getId(), mn.getId(), vp.getFileName(), (int)(values.mlcaBinding), (int)(values.mlca));
							//						this.variableListCurrent[i] = v1;
							//					}
						}
						child2 = mn; 
					}
					else
					{
						// right side is the new select operator
						SelectNode snode2 = new SelectNode(HelpFunctions.nodeID++);
						snode2.setPatternTree(ptin);
						child2 = snode2; 
					}

					// if nested query switch sides
					if (nestedQuery)
					{
						FLWORNode tmp = null;
						tmp = child1;
						child1 = child2;
						child2 = tmp;
					}
					JoinNode jn = new JoinNode(HelpFunctions.nodeID++);
					jn.subType = (int)(values.cartesianProduct);
					jn.setPatternTree(jpt);
					jn.addChild(child1);
					jn.addChild(child2);
					rid = child2.getId();
					this.processTreeNode = jn;

					lastOperatorId = jn.getId();
					return rid;
				}
					// check if starts with variable
				else if (tagName.StartsWith("$"))
				{ 
					int pid = -1;
					for(int i=0; i<this.variableListCurrent.Count; i++)
					{
						VariableMapping vm = (VariableMapping)(this.variableListCurrent[i]);
						if (vm.getName() == tagName) {pid = vm.getPid(); break;}
					}
					if (pid == -1)
					{
						HelpFunctions.success = false;
						HelpFunctions.errorString = "Error: Variable Not Found!" + tagName;
						return rid;
					}
					PatternTree pti = null;
					for(int j=0; j<this.patternTrees.Count; j++)
					{
						pti = (PatternTree)(this.patternTrees[j]);
						if (pid == pti.getId()) {HelpFunctions.mergePatternTrees(pti, ptin, this.variableListCurrent);break;}
					}
					// find operator that var was merged to
					FLWORNode op = findOperatorFromPid(pid, (FLWORNode)(this.processTreeNode));
					if (op == null)
					{
						if (nestedQuery)
						{
							rid = this.processSelectFromForLetPath(pti, operatorId, out lastOperatorId, nestedQuery);
							op = findOperatorFromPid(pid, (FLWORNode)(this.processTreeNode));
						}
						else 
						{
							HelpFunctions.success = false;
							HelpFunctions.errorString = "Error: Operator Not Found! Variable:" + tagName;
							return rid;
						}
					}
					rid = op.getId();
					for(int i=0; i<this.variableListCurrent.Count; i++)
					{
						VariableMapping vm = (VariableMapping)(this.variableListCurrent[i]);
						if (vm.getPid() == pid) {vm.setOid(rid);}
					}

					return rid;
				}
			}
			return rid;
		}//processSelectFromForLetPath


		/// <summary>
		/// Creates a select operator from an input path, the path is assumed to have a reference node at the top.
		/// This operator is called during order by and return clause 
		/// </summary>
		/// <param name="n1">The pattern tree describing the path</param>
		/// <param name="structJoinType">What structural join type to use in the select</param>
		/// <param name="operatorId">Current position in the process tree</param>
		/// <param name="newOperatorId">Position of last operator created, accessed etc</param>
		/// <param name="nRefWid">Outputs the reference inner construct node WID, if inner construct node is c_element</param>
		/// <returns>A WID pointing to the node referenced at the end of the path</returns>
		private int createReferenceSelectFromPath(PatternTreeNode n1, int structJoinType, int operatorId, out int newOperatorId, out int nRefWid)
		{
			string tname = n1.getTagName();
			int wid = -1;
			newOperatorId = operatorId;
			nRefWid = -1;
			bool nestedVar = false;
			int pid = -1;
			for(int i=0;i<this.variableListCurrent.Count;i++)
			{
				VariableMapping vm = (VariableMapping)(this.variableListCurrent[i]);
				if (vm.getName()==tname) 
				{
					wid = vm.getWid();
					pid = vm.getPid();
					if (vm.getFunction() == (int)(values.nestedQuery))
						nestedVar = true;
					break;
				}
			}
			if (wid == -1) 
			{
				HelpFunctions.success = false;
				HelpFunctions.errorString = "Error: Variable Name not found! : " + tname;
				return -1;
			}
			PatternTree pt1 = new PatternTree(HelpFunctions.treeID++);
			PatternTreeNode r1 = new PatternTreeNode(HelpFunctions.reflcl++, wid.ToString(), false, (int)(values.child), (int)(values.referenceNode));
			r1.setStructuralJoinType((int)(values.structuralJoinOne));
			// copy the rest of the path, but set join to star, keep last node lcl
			if (n1.getChildren().Count!=0)
			{
				if (nestedVar)
				{
					int refwid = n1.findWIDAtEndOfPath();
					HelpFunctions.setStructuralJoin(n1, structJoinType);
					int outNestedConstructWid = -1;
					int numoid = this.mergePathToSelect(n1, out outNestedConstructWid);
					if ((numoid == -3) && (outNestedConstructWid != -1))
					{
						FLWORNode flop = this.findOperatorFromId(operatorId, (FLWORNode)(this.processTreeNode));
						int num = flop.surviveProjection(outNestedConstructWid, false, false);
						nRefWid = outNestedConstructWid;
						// find construct node that contains node 10
						FLWORNode cop = (FLWORNode)(this.processTreeNode);
						bool found = false;
						while(!found)
						{
							if (cop.GetType().Name == "ConstructNode")
							{
								PatternTreeNode ptn = (PatternTreeNode)(((ConstructNode)(cop)).getPatternTree().getRoot());
								ptn = ptn.findPatternTreeNode(nRefWid);
								this.innerConstructTreeSurviveProjection(ptn);
								found = true;
							}
							else if (cop.GetType().Name == "JoinNode")
							{
								cop = (FLWORNode)(cop.getChildren()[1]);
							}
							else
							{
								if (cop.getChildren().Count > 0)
									cop = (FLWORNode)(cop.getChildren()[0]);
								else break;
							}
						}


						return outNestedConstructWid;
					}
					FLWORNode fln =	this.findOperatorFromId(operatorId, (FLWORNode)(this.processTreeNode));
					while (!(fln.GetType().Name == "JoinNode"))
					{
						fln = (FLWORNode)(fln.getChildren()[0]);
					}
					fln = (FLWORNode)(fln.getChildren()[1]);
					refwid = fln.surviveProjection(refwid, true, false);
					if (refwid != -1) wid = refwid;
					fln = this.findOperatorFromId(operatorId, (FLWORNode)(this.processTreeNode));
					int tmpnum = fln.surviveProjection(refwid, false, false);
					return wid;
				}
				PatternTreeNode c1 = (PatternTreeNode)(n1.getChildren()[0]);
				r1.addChild(c1);
				c1.setParent(r1);
			}
			else 
			{
				// case {$a}
				if (nestedVar)
				{
					// find wid for referenced node
					PatternTreeNode ptroot = null;
					for(int i=0;i<this.patternTrees.Count;i++)
					{
						PatternTree pt = (PatternTree)(this.patternTrees[i]);
						if (pt.getId() == pid)
						{
							ptroot = (PatternTreeNode)(pt.getRoot());
							if (ptroot.GetType().Name == "ConstructReferencePatternTreeNode")
							{
								ConstructReferencePatternTreeNode crptn = (ConstructReferencePatternTreeNode)(ptroot);
								crptn.setNode();
							}
							else if (ptroot.GetType().Name == "ConstructElementPatternTreeNode")
							{
								nRefWid = wid;
							}
							break;
						}
					}
					// make sure the tree survives projection
					this.innerConstructTreeSurviveProjection(ptroot);
				}
				return wid;
			}
			pt1.setRoot(r1);
			HelpFunctions.setStructuralJoin(r1, structJoinType);
			r1.setStructuralJoinType((int)(values.structuralJoinOne));
			wid = r1.findWIDAtEndOfPath();
			SelectNode s1 = new SelectNode(HelpFunctions.nodeID++);
			s1.setPatternTree(pt1);
			this.patternTrees.Add(pt1);
			// add select node to operators, return number for the construct
			FLWORNode ptout = null;
			this.addParentToProcessTreeNodeWithId(s1, operatorId, (FLWORNode)(this.processTreeNode), out ptout);
			if (ptout != null) 
			{
				this.processTreeNode = ptout; 			
				newOperatorId = s1.getId();
			}
			return wid;
		}//createReferenceSelectFromPath


		/// <summary>
		/// Checks if an input path exists in a given construct tree.
		/// Used for conditions on inner querys when complex construct statements are used.
		/// If the path exists in the construct tree, the wid to the matching node is returned
		/// </summary>
		/// <param name="nin">The pattern tree node containing the path to compare against</param>
		/// <param name="cin">The construct tree node corresponding to the construct tree</param>
		/// <param name="wid">The wid of the matching node</param>
		/// <returns>True if the path exists in the construct, false otherwise</returns>
		private bool checkIfPathExistsInConstructTree(PatternTreeNode nin, ConstructReferencePatternTreeNode cin, out int wid)
		{
			wid = -2;
			if (nin.getSpecial() == (int)(values.attribute))
			{
				ConstructElementPatternTreeNode ceptn = (ConstructElementPatternTreeNode)(cin);
				for(int i=0;i<ceptn.getAttributeList().Count;i++)
				{
					ConstructAttributePatternTreeNode ca = (ConstructAttributePatternTreeNode)(ceptn.getAttributeList()[i]);
					if (nin.getTagName() == ca.getAttributeTagName()) 
					{
						wid = ca.getId();
						return true;
					}
				}
			}
			else
			{
				if (cin.GetType().Name == "ConstructElementPatternTreeNode")
				{
					ConstructElementPatternTreeNode ceptn = (ConstructElementPatternTreeNode)(cin);
					for(int i=0;i<ceptn.getContentList().Count;i++)
					{
						if (ceptn.getContentList()[i].GetType().Name == "ConstructElementPatternTreeNode")
						{
							ConstructElementPatternTreeNode ce = (ConstructElementPatternTreeNode)(ceptn.getContentList()[i]);
							if (nin.getTagName() == ce.getEnclosingTagName()) 
							{
								if (nin.getChildren().Count == 0) 
								{
									wid = ce.getId();
									return true;
								}
								else return this.checkIfPathExistsInConstructTree((PatternTreeNode)(nin.getChildren()[0]), ce, out wid);
							}
						}
					}
				}

			}
			return false;
		}//checkIfPathExistsInConstructTree

		/// <summary>
		/// Given a path starting with a variable name, merge it to the corresponding select operator
		/// </summary>
		/// <param name="n1">The pattern tree describing the path, it must start with a variable</param>
		/// <param name="nestedConstructWid">Used only for nested query, with complex construct, it points to the node in the nested construct</param>
		/// <returns>The operator the path was merged to</returns>
		private int mergePathToSelect(PatternTreeNode n1, out int nestedConstructWid)	
		{
			// check if pt starts with variable
			int pid = -1;
			int wid = -1;
			int outoid = -1;
			nestedConstructWid = -1;
			bool nestedVar = false;
			for(int i=0;i<this.variableListCurrent.Count;i++)
			{
				VariableMapping vm = (VariableMapping)(this.variableListCurrent[i]);
				if (vm.getName() == n1.getTagName()) 
				{
					pid = vm.getPid();
					if (vm.getFunction() == (int)(values.specialAggregateNode)) wid = vm.getWid();
					if (vm.getFunction() == (int)(values.nestedQuery)) nestedVar = true;
					break;
				}
			}
			if (wid == -1)
			{
				if (!nestedVar)
				{
					// variable points to path, merge condition with pattern tree
					PatternTree pt1 = null;
					for(int j=0;j<this.patternTrees.Count;j++)
					{
						pt1 = (PatternTree)(this.patternTrees[j]);
						if (pt1.getId() == pid) break; 
					}
					PatternTree pt = new PatternTree(0);
					pt.setRoot(n1);
					PatternTree pt2 = HelpFunctions.mergePatternTrees(pt1, pt, this.variableListCurrent);
					pt1 = pt2;
					FLWORNode lop = this.findOperatorFromPid(pt1.getId(), (FLWORNode)(this.processTreeNode));
					if (lop!=null) outoid = lop.getId();
					else outoid = -1;
				}
				else 
				{
					// variable points to a nested query
					// find where the variable points to,
					PatternTree pt1 = null;
					for(int j=0;j<this.patternTrees.Count;j++)
					{
						pt1 = (PatternTree)(this.patternTrees[j]);
						if (pt1.getId() == pid) break; 
					}
					// the variable points to the root
					PatternTreeNode ptn = (PatternTreeNode)(pt1.getRoot());

					if (ptn.GetType().Name == "ConstructElementPatternTreeNode")
					{
						// if a construct node, check to see if the children match the tagnames
						// ptn is the construct root, n1 is the input path
						if (n1.getChildren().Count > 0)
						{
							PatternTreeNode nc = (PatternTreeNode)(n1.getChildren()[0]);
							ConstructElementPatternTreeNode ce = (ConstructElementPatternTreeNode)(ptn);
							int refwid = -1;
							if (this.checkIfPathExistsInConstructTree(nc, ce, out refwid))
							{
								nestedConstructWid = refwid;
								outoid = -3;
							}
							else outoid = -1;
						}
						else
						{
							// case $a = 5
							nestedConstructWid = ptn.getId();
							outoid = -3;
						}
					}
					else if (ptn.GetType().Name == "ConstructReferencePatternTreeNode")
					{
						// create a construct ref node and point to wid
						int lastwid =  n1.findWIDAtEndOfPath();
						ConstructReferencePatternTreeNode crptn = (ConstructReferencePatternTreeNode)(ptn);
						if (lastwid == 0) 
						{
							nestedConstructWid = crptn.getId();
							crptn.setNode();
							outoid = -2;
						}
						else
						{
							// if a reference node, track the reference down and add the rest of the path to it
							crptn.setNode();
							int refwid = int.Parse(crptn.getTagName());
							pid = -1;
							string nestedTag = "empty";
							VariableMapping vmout = null;
							for(int i=0;i<this.variableListGlobal.Count;i++)
							{
								VariableMapping vm = (VariableMapping)(this.variableListGlobal[i]);
								if (vm.getWid() == refwid) 
								{
									pid = vm.getPid();
									nestedTag = vm.getName();
									vmout = vm;
									break;
								}
							}
							if (vmout != null) this.variableListCurrent.Add(vmout);
							pt1 = null;
							for(int j=0;j<this.patternTrees.Count;j++)
							{
								pt1 = (PatternTree)(this.patternTrees[j]);
								if (pt1.getId() == pid) break; 
							}
							PatternTree pt = new PatternTree(0);
							n1.setTagName(nestedTag);
							HelpFunctions.setStructuralJoin(n1, (int)(values.structuralJoinZeroMore));
							pt.setRoot(n1);
							PatternTree pt2 = HelpFunctions.mergePatternTrees(pt1, pt, this.variableListCurrent);
							pt1 = pt2;
							outoid = -2;
							if (vmout != null) this.variableListCurrent.Remove(vmout);

							nestedConstructWid = lastwid;
						}
					}// end case nested var points to reference
				
				}
			}
			return outoid;
		}//mergePathToSelect



		/// <summary>
		/// Process all FOR/LET nodes in a list
		/// </summary>
		/// <param name="flin">The FOR/LET node list</param>
		/// <param name="operatorId">Current position in the process tree</param>
		/// <param name="lastOperatorId">Position of the last operator added</param>
		private void processAllForLets(FLNode flin, int operatorId, out int lastOperatorId)
		{
			this.processForLetNode(flin.getPatternTree(), operatorId, out lastOperatorId);
			operatorId = lastOperatorId;

			FLWORNode flr = flin;
			while(flr.getChildren().Count !=0)
			{
				flr = (FLWORNode)(flr.getChildren()[0]);
				this.processForLetNode(flr.getPatternTree(), operatorId, out lastOperatorId);
				operatorId = lastOperatorId;
			}
		}//processAllForLets



		/// <summary>
		/// Processes each FOR/LET node and generated the appropriate operators
		/// </summary>
		/// <param name="ptin">The pattern tree associated with the FOR/LET clause</param>
		/// <param name="operatorId">Current position in the process tree</param>
		/// <param name="lastOperatorId">Position of last node added, created, accessed etc</param>
		private void processForLetNode(PatternTree ptin, int operatorId, out int lastOperatorId)
		{
			lastOperatorId = operatorId;
			PatternTreeNode pta = (PatternTreeNode)(ptin.getRoot());
			if (!this.checkPatternTreeIsPath(ptin))
			{
				HelpFunctions.success = false;
				HelpFunctions.errorString = "Error: Currently we only support simple path expressions for the bound variables";
			}
			else if ((pta.getTagName().StartsWith("$"))||(pta.getTagName().StartsWith("document")))
			{ 
				int nid = this.processSelectFromForLetPath(ptin, operatorId, out lastOperatorId, false);
				for(int i=0; i<this.variableListCurrent.Count; i++)
				{
					VariableMapping vm = (VariableMapping)(this.variableListCurrent[i]);
					if (vm.getPid() == ptin.getId()) vm.setOid(nid);
				}
			}
			else if (pta.GetType().Name == "AggregatePatternTreeNode")
			{
				int oid = HelpFunctions.nodeID++;
				AggregatePatternTreeNode ar = (AggregatePatternTreeNode)(pta);
				for(int i=0; i<this.variableListCurrent.Count; i++)
				{
					VariableMapping vm = (VariableMapping)(this.variableListCurrent[i]);
					if (vm.getWid() == ar.getId()) 
					{
						vm.setFunction((int)(values.specialAggregateNode)); 
						vm.setOid(oid);
						break;
					}
				}
				PatternTreeNode node1 = ar.getMyNode();
				int wid = 0;
				if (node1.getChildren().Count == 0)
				{
					string ntname = node1.getTagName();
					for(int i=0;i<this.variableListCurrent.Count;i++)
					{
						VariableMapping vm = (VariableMapping)(this.variableListCurrent[i]);
						if (vm.getName() == ntname) {wid = vm.getWid(); break;}
					}
				}
				else wid = node1.findWIDAtEndOfPath();

				AggregateNode apt = new AggregateNode(oid);
				apt.setFunctionName(ar.getFunctionName());
				apt.setMyWID(ar.getId());
				apt.setRefWID(wid);
				// process Path, get id for node, add aggregate after the select node
				PatternTree mypt = new PatternTree(HelpFunctions.treeID++);
				mypt.setRoot(node1);
				int nid = this.processSelectFromForLetPath(mypt, operatorId, out lastOperatorId, false);
				FLWORNode ptout = null;
				this.addParentToProcessTreeNodeWithId(apt, nid, (FLWORNode)(this.processTreeNode), out ptout);
				if (ptout != null) {this.processTreeNode = ptout; nid = apt.getId();}
				FLWORNode flop = this.findOperatorFromId(operatorId, (FLWORNode)(this.processTreeNode));
				if (flop.GetType().Name != "JoinNode") lastOperatorId = nid;
			}//aggregate
			else if (pta.GetType().Name == "MLCAPatternTreeNode")
			{
				
				if (this.usedPatternTrees.Contains(ptin.getId()))
				{
					lastOperatorId = operatorId;
					return;
				}
				MLCAPatternTreeNode ar = (MLCAPatternTreeNode)(pta);

				MLCANode mn = new MLCANode(HelpFunctions.nodeID++);
				mn.setMLCAList(ar.getBoundNodes());
				mn.setPatternTree(ar.getPatternTree());
				this.patternTrees.Add(mn.getPatternTree());

				// update the variable table, the variable should bind to the mlca root, not the function node
				string fname = "empty";
				for(int i=0; i<this.variableListCurrent.Count; i++)
				{
					VariableMapping vm = (VariableMapping)(this.variableListCurrent[i]);
					if (vm.getPid() == mn.getPatternTree().getId()) 
					{
						vm.setOid(mn.getId());
						fname = vm.getFileName();
					}
					if (vm.getPid() == ptin.getId()) 
					{
						vm.setOid(mn.getId()); 
						vm.setPid(mn.getPatternTree().getId());
						vm.setMLCA();
						vm.setFileName(fname);
					}
					//					if (vm.getWid() == ar.getId()) 
					//					{
					//						PatternTreeNode r1 = (PatternTreeNode)(ar.getPatternTree().getRoot());
					//						VariableMapping vp = (VariableMapping)(this.variableListCurrent[i-1]);// the previous binding is an MLCA one
					//						VariableMapping v1 = new VariableMapping(vm.getName(), ar.getPatternTree().getId(), r1.getId(), mn.getId(), vp.getFileName(), (int)(values.mlcaBinding), (int)(values.mlca));
					//						this.variableListCurrent[i] = v1;
					//					}
				}

				if (this.processTreeNode == null) this.processTreeNode = mn;
				else
				{
					// left side is the existing side
					int leftSideRootRef = this.processTreeNode.getRootLCL();
					PatternTreeNode pnode1 = new PatternTreeNode(HelpFunctions.reflcl++, leftSideRootRef.ToString(), false, (int)(values.child), (int)(values.referenceNode));
					pnode1.setStructuralJoinType((int)(values.structuralJoinOne));
					// right side is the new mlca operator
					PatternTreeNode pnode2 = new PatternTreeNode(HelpFunctions.reflcl++, mn.getRootLCL().ToString(), false, (int)(values.child), (int)(values.referenceNode));
					pnode2.setStructuralJoinType((int)(values.structuralJoinOne));
					// create a cartesian product at first, if a join condition is in the where clause this will updated when processed
					JoinDualPatternTreeNode jnode = new JoinDualPatternTreeNode(HelpFunctions.lcl++, "JOIN", (int)(values.cartesianProduct), pnode1, pnode2, -1, "=", -1);
					PatternTree jpt = new PatternTree(HelpFunctions.treeID++);
					jpt.setRoot(jnode);
					this.patternTrees.Add(jpt);

					JoinNode jn = new JoinNode(HelpFunctions.nodeID++);
					jn.subType = (int)(values.cartesianProduct);
					jn.setPatternTree(jpt);
					// left side is the existing side
					jn.addChild(this.processTreeNode);
					// right side is the new mlca operator
					jn.addChild(mn);
					this.processTreeNode = jn;
				}
				lastOperatorId = this.processTreeNode.getId();
			}//mlca
			else if ((pta.getTagName().Length <= 3)||(pta.GetType().Name == "ConstructElementPatternTreeNode"))
			{ 
				// check for nested queries
				if (pta.getTagName().Length <= 3)
				{
					int refval = -1;
					try
					{
						refval = int.Parse(pta.getTagName());
					}
					catch (Exception e)
					{
						HelpFunctions.success = false;
						HelpFunctions.errorString = "Error: Nested query not in correct input format!" + e.ToString() + "\n";
						return;
					}
				}
				// find the join operator with right child a construct, add nest for LET
				int pid = -1;
				int binding = -1;
				for(int i=0;i<this.variableListCurrent.Count;i++)
				{
					VariableMapping vm = (VariableMapping)(this.variableListCurrent[i]);
					if (vm.getWid() == pta.getId()) 
					{
						pid = vm.getPid();
						binding = vm.getBindingType();
						break;
					}
				}
				FLWORNode flop = this.findOperatorFromPid(ptin.getId(), (FLWORNode)(this.processTreeNode));
				FLWORNode jparent = (FLWORNode)(flop.getParent());
				if (jparent.GetType().Name == "JoinNode")
				{
					PatternTree pt = jparent.getPatternTree();
					JoinDualPatternTreeNode jroot = (JoinDualPatternTreeNode)(pt.getRoot());
					PatternTreeNode ptn2 = (PatternTreeNode)(jroot.getNode2());
					if (binding == (int)(values.letBinding))
						ptn2.setStructuralJoinType((int)(values.structuralJoinZeroMore));
					ptn2.setTagName(pta.getId().ToString());
					int wid2 = flop.surviveProjection(jroot.getJoinWID2(), true, false);
					jroot.setJoinWID2(wid2);

					// set it as join node, so that it does not appear in the final result
//					PatternTree constructTree = flop.getPatternTree();
//					ConstructReferencePatternTreeNode cr = (ConstructReferencePatternTreeNode)(constructTree.getRoot());
//					ConstructReferencePatternTreeNode cj = (ConstructReferencePatternTreeNode)(cr.findPatternTreeNode(wid2));
//					cj.setIsJoinNode();
				}
			}// end nested queries
			else 
			{
				HelpFunctions.success = false;
				HelpFunctions.errorString = "Error: Unsupported input at the FOR/LET clause!";
			}
		}//processForLetNode

		
		/// <summary>
		/// Given a parsed where pattern tree, process all the paths, aggregates etc
		/// generating a series of operators that are added to the process tree.
		/// </summary>
		/// <param name="pt">The parsed pattern tree corresponding to a where clause</param>
		/// <param name="operatorId">Current position in the process tree</param>
		/// <param name="lastOperatorId">Position of the last operator added or accessed</param>
		private void processWhereNode(PatternTree pt, int operatorId, out int lastOperatorId)
		{
			PatternTreeNode n1 = (PatternTreeNode)(pt.getRoot());
			string tname = n1.getTagName();
			lastOperatorId = operatorId;

			if(tname.StartsWith("$")) // case $b/author = "stelios", $b > 5
			{
				// check if pt starts with variable
				int wid = -1; bool foundvar = false;
				for(int i=0;i<this.variableListCurrent.Count;i++)
				{
					VariableMapping vm = (VariableMapping)(this.variableListCurrent[i]);
					if (vm.getName()==tname) 
					{
						foundvar = true;
						if (vm.getFunction() == (int)(values.specialAggregateNode)) wid = vm.getWid();
						break;
					}
				}
				if (!foundvar)
				{
					HelpFunctions.success = false;
					HelpFunctions.errorString = "Undeclared variable used: " + tname + "\n";
				}
				else
				{
					if (wid == -1)
					{
						int tmp = -1;
						int num = this.mergePathToSelect(n1, out tmp);
						if (tmp!=-1)//nested queries outer filter
						{
							FilterNode fn = new FilterNode(HelpFunctions.nodeID++);
							int lastwid = n1.findWIDAtEndOfPath();
							if ((lastwid == 0)||(num == -3)) //case $b or case refer to nested c_element
							{
								PatternTreeNode plast = n1.findPatternTreeNode(lastwid);
								PatternTreeNodeCondition ptnc = plast.getPatternTreeNodeCondition();
								fn.setCondition(ptnc);
								FLWORNode flop = this.findOperatorFromId(operatorId, (FLWORNode)(this.processTreeNode));
								ptnc.setNodeWID(tmp);
								FLWORNode ptout = null;
								this.addParentToProcessTreeNodeWithId(fn, flop.getId(), (FLWORNode)(this.processTreeNode), out ptout);
								if (ptout!=null) {this.processTreeNode = ptout; lastOperatorId = fn.getId(); operatorId = lastOperatorId;}
								plast.setPatternTreeNodeCondition(null);
							}
							else
							{
								PatternTreeNode plast = n1.findPatternTreeNode(lastwid);
								PatternTreeNodeCondition ptnc = plast.getPatternTreeNodeCondition();
								fn.setCondition(ptnc);
								FLWORNode flop = this.findOperatorFromId(operatorId, (FLWORNode)(this.processTreeNode));
								// find the child join node, get construct on right side, then surviveprojection
								FLWORNode sp = flop;
								while (sp.GetType().Name != "JoinNode")
								{
									sp = (FLWORNode)(sp.getChildren()[0]);
								}
								sp = (FLWORNode)(sp.getChildren()[1]);
								int cref = sp.surviveProjection(tmp, true, false);
								ptnc.setNodeWID(cref);
								FLWORNode ptout = null;
								this.addParentToProcessTreeNodeWithId(fn, flop.getId(), (FLWORNode)(this.processTreeNode), out ptout);
								if (ptout!=null) {this.processTreeNode = ptout; lastOperatorId = fn.getId(); operatorId = lastOperatorId;}
								plast.setPatternTreeNodeCondition(null);
							}
						}
					}
					else 
					{
						// variable points to function, like aggregate, generate separate filter operator
						FilterNode fn = new FilterNode(HelpFunctions.nodeID++);
						PatternTreeNodeCondition ptnc = new PatternTreeNodeCondition(wid, n1.getComparisonTypeSymbol(), n1.getComparisonValue());
						fn.setCondition(ptnc);
						FLWORNode ptout = null;
						this.addParentToProcessTreeNodeWithId(fn, operatorId, (FLWORNode)(this.processTreeNode), out ptout);
						if (ptout != null) {this.processTreeNode = ptout; lastOperatorId = fn.getId(); operatorId = lastOperatorId;}
					}
				}
			}
			else if (n1.GetType().Name == "DualPatternTreeNode") //AND
			{
				// case AND (dualnode)
				DualPatternTreeNode dr = (DualPatternTreeNode)(n1);
				// currently only AND nodes are supported
				if (dr.getSpecial() == (int)(values.specialAndNode))
				{
					PatternTreeNode node1 = (PatternTreeNode)(dr.getNode1());
					PatternTree pt1 = new PatternTree(HelpFunctions.treeID++);
					pt1.setRoot(node1);
					this.processWhereNode(pt1, operatorId, out lastOperatorId);
					operatorId = lastOperatorId;

					// get node 2. create a pattern tree and merge it
					PatternTreeNode node2 = (PatternTreeNode)(dr.getNode2());
					PatternTree pt2 = new PatternTree(HelpFunctions.treeID++);
					pt2.setRoot(node2);
					this.processWhereNode(pt2, operatorId, out lastOperatorId);
					operatorId = lastOperatorId;
					//					FLWORNode flop = this.findOperatorFromId(operatorId, (FLWORNode)(this.processTreeNode));
					//					if ((flop.GetType().Name != "SelectNode")&&(flop.GetType().Name != "JoinNode")) lastOperatorId = operatorId;
				}
				else
				{
					HelpFunctions.success = false;
					HelpFunctions.errorString = "Only AND are currently supported!";
				}
			}// end case AND (dualnode)
			else if (n1.GetType().Name == "OrPatternTreeNode")
			{
				OrPatternTreeNode ornode = (OrPatternTreeNode)(n1);
				this.processORNode(ornode, operatorId, out lastOperatorId);

			}// end case OR 
			else if (n1.GetType().Name == "JoinDualPatternTreeNode")
			{
				JoinDualPatternTreeNode jr = (JoinDualPatternTreeNode)(n1);
				PatternTreeNode node1 = (PatternTreeNode)(jr.getNode1());
				int tmp = -1;
				int pathoid1 = this.mergePathToSelect(node1, out tmp);
				PatternTreeNode node2 = (PatternTreeNode)(jr.getNode2());
				int pathoid2 = this.mergePathToSelect(node2, out tmp);

				// make sure that the join condition is associated with the pattern tree
				PatternTreeJoinCondition ptjc = jr.getJoinCondition();

				// case $a = x or x = $b
				if (node1.getId() == ptjc.getJoinWID1())
					if (node1.getTagName().StartsWith("$"))
					{
						string myTag = node1.getTagName();
						for(int i=0; i<this.variableListCurrent.Count; i++)
						{
							VariableMapping vm = (VariableMapping)(this.variableListCurrent[i]);
							if (vm.getName() == myTag)
								ptjc.setJoinWID1(vm.getWid());
						}
					}
				
				if (node2.getId() == ptjc.getJoinWID2())
					if (node2.getTagName().StartsWith("$"))
					{
						string myTag = node2.getTagName();
						for(int i=0; i<this.variableListCurrent.Count; i++)
						{
							VariableMapping vm = (VariableMapping)(this.variableListCurrent[i]);
							if (vm.getName() == myTag)
								ptjc.setJoinWID2(vm.getWid());
						}
					}

				// find operators for each condition side
				int pid1 = -1, pid2 = -2;
				for(int i=0;i<this.variableListCurrent.Count;i++)
				{
					VariableMapping vm = (VariableMapping)(this.variableListCurrent[i]);
					if (vm.getName() == node1.getTagName()) pid1 = vm.getPid();
					if (vm.getName() == node2.getTagName()) pid2 = vm.getPid();
				}
				// find operator for pid1
				FLWORNode op1 = this.findOperatorFromPid(pid1, (FLWORNode)(this.processTreeNode));

				// case same operator
				if (pid1 == pid2)
				{
					PatternTree pta = op1.getPatternTree(); 
					pta.addCondition(ptjc);
					FilterNode fn = new FilterNode(HelpFunctions.nodeID++);
					fn.setCondition(ptjc);					
					Node op1parent = op1.getParent();
					FLWORNode ptout = null;
					this.addParentToProcessTreeNodeWithId(fn, operatorId, (FLWORNode)(this.processTreeNode), out ptout);
					if (ptout!=null){this.processTreeNode = ptout; lastOperatorId = fn.getId(); operatorId = lastOperatorId;}
				}
				else // case different operators
				{
					FLWORNode op2 = this.findOperatorFromPid(pid2, (FLWORNode)(this.processTreeNode));
					// if nested query, one of the operator does not exist
					if (op1 == null)
					{
						PatternTree pttmp = null;
						for(int i=0;i<this.patternTrees.Count;i++)
							if (((PatternTree)(this.patternTrees[i])).getId() == pid1)
							{pttmp = (PatternTree)(this.patternTrees[i]); break;}
						if (pttmp == null) // check for mlca nested queries
						{
							for(int i=0;i<this.patternTrees.Count;i++)
							{
								PatternTree ptm = (PatternTree)(this.patternTrees[i]);
								if (ptm.getRoot().GetType().Name == "MLCAPatternTreeNode")
								{
									PatternTree ptm1 = ((MLCAPatternTreeNode)(ptm.getRoot())).getPatternTree();
									if (ptm1.getId() == pid1) {pttmp = ptm; break;}
								}
							}
						}
						HelpFunctions.setStructuralJoin(node1, (int)(values.structuralJoinOneMore));
						HelpFunctions.setStructuralJoin(node2, (int)(values.structuralJoinOneMore));
						ptjc.setAnyLeft();
						int oid1 = this.processSelectFromForLetPath(pttmp, operatorId, out lastOperatorId, true);
						op1 = this.findOperatorFromPid(pid1, (FLWORNode)(this.processTreeNode));
						lastOperatorId = op2.getId();
					}
					if (op2 == null)
					{
						PatternTree pttmp = null;
						for(int i=0;i<this.patternTrees.Count;i++)
							if (((PatternTree)(this.patternTrees[i])).getId() == pid2)
							{pttmp = (PatternTree)(this.patternTrees[i]); break;}
						if (pttmp == null) // check for mlca nested queries
						{
							for(int i=0;i<this.patternTrees.Count;i++)
							{
								PatternTree ptm = (PatternTree)(this.patternTrees[i]);
								if (ptm.getRoot().GetType().Name == "MLCAPatternTreeNode")
								{
									PatternTree ptm1 = ((MLCAPatternTreeNode)(ptm.getRoot())).getPatternTree();
									if (ptm1.getId() == pid2) {pttmp = ptm; break;}
								}
							}
						}
						HelpFunctions.setStructuralJoin(node1, (int)(values.structuralJoinOneMore));
						HelpFunctions.setStructuralJoin(node2, (int)(values.structuralJoinOneMore));
						ptjc.setAnyLeft();
						int oid2 = this.processSelectFromForLetPath(pttmp, operatorId, out lastOperatorId, true);
						op2 = this.findOperatorFromPid(pid1, (FLWORNode)(this.processTreeNode));
						lastOperatorId = op1.getId();
					}
					// find common ancestor
					JoinNode jn = (JoinNode)(this.findJoin(op1, op2));

					// check if left side of condition matches the left input operator
					FLWORNode firstchild = (FLWORNode)(jn.getChildren()[0]);
					FLWORNode outc1 = this.findOperatorFromId(op1.getId(), firstchild);
					if (outc1 == null) ptjc = HelpFunctions.switchSidesInJoinCondition(ptjc);

					PatternTree jpt = jn.getPatternTree();
					JoinDualPatternTreeNode jptn = (JoinDualPatternTreeNode)(jpt.getRoot());
					if (jptn.getSpecial() == (int)(values.cartesianProduct)) 
					{
						jptn.setSpecial((int)(values.join));
						jptn.setJoinCondition(ptjc);
					}
					else 
					{
						// a multiple join, add the condition to the join
						jpt.addCondition(ptjc);
						// create a filter operator for that join
						FilterNode fn = new FilterNode(HelpFunctions.nodeID++);
						fn.setCondition(ptjc);
						FLWORNode ptout = null;
						this.addParentToProcessTreeNodeWithId(fn, jn.getId(), (FLWORNode)(this.processTreeNode), out ptout);
						if (ptout!=null) 
						{ 
							this.processTreeNode = ptout;
							lastOperatorId = fn.getId();
						}
					}
				}
			}// case JoinRoot
			else if (n1.GetType().Name == "AggregatePatternTreeNode")
			{
				int pathoid = -1;
				int wid = this.createAggregateNode(n1, operatorId, out pathoid, false);

				FilterNode fn = new FilterNode(HelpFunctions.nodeID++);
				fn.setCondition(n1.getPatternTreeNodeCondition());
				FLWORNode ptout = null;
				this.addParentToProcessTreeNodeWithId(fn, pathoid, (FLWORNode)(this.processTreeNode), out ptout);
				if (ptout != null) {this.processTreeNode = ptout; pathoid = fn.getId(); }
				FLWORNode flop = this.findOperatorFromId(operatorId, (FLWORNode)(this.processTreeNode));
				if (flop.GetType().Name != "JoinNode") lastOperatorId = pathoid;
				else
				{
					FLWORNode flc = this.findOperatorFromId(pathoid, flop);
					if (flc == null) lastOperatorId = pathoid;
				}

			}//end case aggregate
			else if (n1.GetType().Name == "QuantifiedPatternTreeNode")
			{
				PatternTreeNodeCondition outptnc = null;
				int firstWid = -1, lastWid = -1;
				int numoid = this.processQuantifierNode(n1, out outptnc, out firstWid, out lastWid);
				int pathoid = -1;
				if (numoid == -2) 
				{
					// variable points to nested structure with simple construct
					pathoid = operatorId;

					FLWORNode fln =	this.findOperatorFromId(operatorId, (FLWORNode)(this.processTreeNode));
					while (!(fln.GetType().Name == "JoinNode"))
					{
						fln = (FLWORNode)(fln.getChildren()[0]);
					}
					fln = (FLWORNode)(fln.getChildren()[1]);
					int numwid = fln.surviveProjection(outptnc.getNodeWID(), true, false);
					if (numwid!=-1) outptnc.setNodeWID(numwid);
				}// end nested query case
				else if (numoid == -3) 
				{
					// variable points to nested structure with complex construct
					pathoid = operatorId;
				}// end nested query case
				else 
				{
					// variable points to regular node
					if (numoid >= 0)
					{
						FLWORNode fln =	this.findOperatorFromId(numoid, (FLWORNode)(this.processTreeNode));
						int tmpoid = fln.getId();
						fln = (FLWORNode)(fln.getParent());
						while((fln!=null)&&(fln.GetType().Name != "SelectNode")&&(fln.GetType().Name != "JoinNode"))
						{
							tmpoid = fln.getId();
							fln = (FLWORNode)(fln.getParent());
						}
						pathoid = tmpoid;

						if (firstWid>=0)
						{
							// add aggregate and extra filter for the part after satisfies
							AggregateNode a1 = new AggregateNode(HelpFunctions.nodeID++);
							a1.setFunctionName("count");
							a1.setFunctionType((int)(values.aggregateCount));
							a1.setRefWID(firstWid);
							a1.setMyWID(HelpFunctions.lcl++);

							AggregateNode a2 = new AggregateNode(HelpFunctions.nodeID++);
							a2.setFunctionName("count");
							a2.setFunctionType((int)(values.aggregateCount));
							a2.setRefWID(lastWid);
							a2.setMyWID(HelpFunctions.lcl++);

							FilterNode ofn = new FilterNode(HelpFunctions.nodeID++);
							PatternTreeJoinCondition ptjc = new PatternTreeJoinCondition(a1.getMyWID(), "=", a2.getMyWID());
							//PatternTreeNodeCondition ptnc = new PatternTreeNodeCondition(a2.getMyWID(), "=", "0");
							ofn.setCondition(ptjc);
							//ofn.addCondition(ptnc);
	
							FLWORNode ptout1 = null;
							this.addParentToProcessTreeNodeWithId(a1, pathoid, (FLWORNode)(this.processTreeNode), out ptout1);
							if (ptout1 != null) {this.processTreeNode = ptout1; pathoid = a1.getId(); }
							this.addParentToProcessTreeNodeWithId(a2, pathoid, (FLWORNode)(this.processTreeNode), out ptout1);
							if (ptout1 != null) {this.processTreeNode = ptout1; pathoid = a2.getId(); }
							this.addParentToProcessTreeNodeWithId(ofn, pathoid, (FLWORNode)(this.processTreeNode), out ptout1);
							if (ptout1 != null) {this.processTreeNode = ptout1; pathoid = ofn.getId(); }


						}


					}
					else pathoid = numoid;
				}// end single block case

				FilterNode fn = new FilterNode(HelpFunctions.nodeID++);
				fn.setCondition(outptnc);
				FLWORNode ptout = null;
				this.addParentToProcessTreeNodeWithId(fn, pathoid, (FLWORNode)(this.processTreeNode), out ptout);
				if (ptout != null) {this.processTreeNode = ptout; pathoid = fn.getId(); }

				FLWORNode flop = this.findOperatorFromId(operatorId, (FLWORNode)(this.processTreeNode));
				if (flop.GetType().Name != "JoinNode") lastOperatorId = pathoid;
				else
				{
					FLWORNode flc = this.findOperatorFromId(pathoid, flop);
					if ((flc == null) && (pathoid>=0)) lastOperatorId = pathoid;
				}
			}//end case QuantifiedPatternTreeNode
			else
			{
				HelpFunctions.success = false;
				HelpFunctions.errorString = "Error unknown type in the WHERE clause!";
				lastOperatorId = operatorId;
			}
			
		}//processwhere node



		/// <summary>
		/// Given a parsed quantifier node, merge the paths to the necessary select operators,
		/// output the condition for the generated filter and the id pointing to the corresponding select node.
		/// </summary>
		/// <param name="n1">A quantified pattern tree node</param>
		/// <param name="outptnc">The condition to use for the filter</param>
		/// <param name="firstWid">Points to the path end before the satisfies clause. Value -1 means that no path exists after satisfies.</param>
		/// <param name="lastWid">Points to the path end after the satisfies clause.</param>
		/// <returns>The operator id pointing to the node the path was merged to</returns>
		private int processQuantifierNode(PatternTreeNode n1, out PatternTreeNodeCondition outptnc, out int firstWid, out int lastWid)
		{
			QuantifiedPatternTreeNode qptn = (QuantifiedPatternTreeNode)(n1);
			PatternTreeNode node1 = (PatternTreeNode)(qptn.getPatternTree().getRoot());
			int outnestedConstructWid = -1;
			int outoid = this.mergePathToSelect(node1, out outnestedConstructWid);
			int wid = node1.findWIDAtEndOfPath();
			PatternTreeNode plast = node1.findPatternTreeNode(wid);
			outptnc = plast.getPatternTreeNodeCondition();
			if (qptn.getSubType() == (int)(values.everySubType)) outptnc.setQuantifier("EVERY");
			else outptnc.setQuantifier("SOME");
			plast.setPatternTreeNodeCondition(null);
			if (outnestedConstructWid != -1) outptnc.setNodeWID(outnestedConstructWid);
			firstWid = qptn.getCountWid();
			lastWid = plast.getId();
			return outoid;
		}//processQuantifierNode


		/// <summary>
		/// Given an aggregate parsed node, merge the input path to the appropriate select operator
		/// and create a new aggregate node.
		/// </summary>
		/// <param name="n1">An aggregate pattern tree node</param>
		/// <param name="operatorId">Current position in the process tree</param>
		/// <param name="newOperatorId">The position of the newly added aggregate node</param>
		/// <param name="forReturn">If the aggregate is part of the return clause</param>
		/// <returns>The WID of the aggregate node that will be added to the witness tree </returns>
		private int createAggregateNode(PatternTreeNode n1, int operatorId, out int newOperatorId, bool forReturn)
		{
			AggregatePatternTreeNode aptn = (AggregatePatternTreeNode)(n1);
			PatternTreeNode nc = aptn.getMyNode();
			int wid = -1;
			newOperatorId = operatorId;
			if (forReturn)
			{
				int outnRefWid = -1;
				wid = this.createReferenceSelectFromPath(nc, (int)(values.structuralJoinZeroMore), operatorId, out newOperatorId, out outnRefWid);
				operatorId = newOperatorId;
			}
			else
			{
				if (nc.getChildren().Count == 0)
				{
					string ntname = nc.getTagName();
					for(int i=0;i<this.variableListCurrent.Count;i++)
					{
						VariableMapping vm = (VariableMapping)(this.variableListCurrent[i]);
						if (vm.getName() == ntname) {wid = vm.getWid(); break;}
					}
				}
				else wid = nc.findWIDAtEndOfPath();
				int outNestedConstructWid = -1;
				int numoid = this.mergePathToSelect(nc, out outNestedConstructWid);
				if (numoid == -2) 
				{
					// variable points to nested structure with a simple construct
					FLWORNode fln =	this.findOperatorFromId(operatorId, (FLWORNode)(this.processTreeNode));
					while (!(fln.GetType().Name == "JoinNode"))
					{
						fln = (FLWORNode)(fln.getChildren()[0]);
					}
					fln = (FLWORNode)(fln.getChildren()[1]);
					int numwid = fln.surviveProjection(wid, true, false);
					if (numwid != -1) wid = numwid;
				}
				else if (numoid == -3)
				{
					// variable points to nested structure with a complex construct
					wid = outNestedConstructWid;				
				}
				else 
				{
					// variable points to regular node
					if (numoid >= 0)
					{
						FLWORNode fln =	this.findOperatorFromId(numoid, (FLWORNode)(this.processTreeNode));
						int tmpoid = fln.getId();
						fln = (FLWORNode)(fln.getParent());
						while((fln!=null)&&(fln.GetType().Name != "SelectNode")&&(fln.GetType().Name != "JoinNode"))
						{
							tmpoid = fln.getId();
							fln = (FLWORNode)(fln.getParent());
						}
						operatorId = tmpoid;
					}
					else operatorId = numoid;
				}
			}
			AggregateNode an = new AggregateNode(HelpFunctions.nodeID++);
			an.setMyWID(aptn.getId());
			an.setRefWID(wid);
			an.setFunctionName(aptn.getFunctionName());
			FLWORNode ptout = null;
			this.addParentToProcessTreeNodeWithId(an, operatorId, (FLWORNode)(this.processTreeNode), out ptout);
			if (ptout != null) { this.processTreeNode = ptout; newOperatorId = an.getId(); }
			wid = aptn.getId();
			return wid;
		}//createAggregateNode



		/// <summary>
		/// Process a path of an OR condition, generating the appropriate operators and returning
		/// the condition to be used for the ORFILTER
		/// </summary>
		/// <param name="nin">The pattern tree node mapping to the path</param>
		/// <param name="outoid">Position of the operator that was accessed in the process tree</param>
		/// <param name="outptnc">The condition to be used by the ORFILTER</param>
		/// <param name="operatorId">Current position in the process tree</param>
		/// <param name="lastOperatorId">Position of the last operator accessed or added to the process tree</param>
		private void processORPath(PatternTreeNode nin, out int outoid, out PatternTreeNodeCondition outptnc, int operatorId, out int lastOperatorId)
		{
			outoid = -1;
			outptnc = new PatternTreeNodeCondition();
			lastOperatorId = operatorId;

			if(nin.getTagName().StartsWith("$"))
			{
				// check if pt starts with variable
				int pid = -1;
				int fwid = -1;
				int wid = -1;
				int oid = -1;
				for(int i=0;i<this.variableListCurrent.Count;i++)
				{
					VariableMapping vm = (VariableMapping)(this.variableListCurrent[i]);
					if (vm.getName() == nin.getTagName()) 
					{
						pid = vm.getPid();
						if (vm.getFunction() == (int)(values.specialAggregateNode)) fwid = vm.getWid();
						wid = vm.getWid();
						oid = vm.getOid();
						break;
					}
				}
				if (fwid == -1)
				{
					if (nin.getChildren().Count > 0)
					{
						// path, merge condition with pattern tree
						int twid = nin.findWIDAtEndOfPath();
						PatternTreeNode ptn = nin.findPatternTreeNode(twid);
						outptnc.setNodeWID(twid);
						outptnc.setCompValue(ptn.getComparisonValue());
						outptnc.setCompType(ptn.getComparisonTypeSymbol());
						outptnc.setQuantifier("SOME");
						ptn.setPatternTreeNodeCondition(null);

						int outNestedConstructWid = -1;
						outoid = this.mergePathToSelect(nin, out outNestedConstructWid);
						if (outNestedConstructWid != -1) outptnc.setNodeWID(outNestedConstructWid);
					}
					else
					{
						// we have a case like $b = 5
						if (oid != -1) outoid = oid;
						else outoid = this.findOperatorFromPid(pid, (FLWORNode)(this.processTreeNode)).getId();
						outptnc.setNodeWID(wid);
						outptnc.setCompValue(nin.getComparisonValue());
						outptnc.setCompType(nin.getComparisonTypeSymbol());
						outptnc.setQuantifier("SOME");
					}
				}
				else 
				{
					// variable points to function, like aggregate
					if (oid != -1) outoid = oid;
					else outoid = this.findOperatorFromPid(pid, (FLWORNode)(this.processTreeNode)).getId();
					outptnc.setNodeWID(fwid);
					outptnc.setCompValue(nin.getComparisonValue());
					outptnc.setCompType(nin.getComparisonTypeSymbol());
					outptnc.setQuantifier("SOME");
				}
			}// end case path
			else if (nin.GetType().Name == "AggregatePatternTreeNode")
			{
				int pathoid = -1;
				int wid = this.createAggregateNode(nin, operatorId, out pathoid, false);

				FLWORNode flop = this.findOperatorFromId(operatorId, (FLWORNode)(this.processTreeNode));
				if (flop.GetType().Name != "JoinNode") lastOperatorId = pathoid;
				outoid = pathoid;
				outptnc = nin.getPatternTreeNodeCondition();
			}//end case aggregate
			else if (nin.GetType().Name == "QuantifiedPatternTreeNode")
			{
				int firstwid = -1, lastwid = -1;
				outoid = this.processQuantifierNode(nin, out outptnc, out firstwid, out lastwid);
				if (firstwid>-1) 
				{
					// Unsupported behavior, a mix of OR and AND filter clauses
					// The Every clause should be simpler.
					HelpFunctions.success = false;
					HelpFunctions.errorString = "Using quantifier EVERY with OR in Timber requires a simplified variation of the clause.\n e.g. every $i in $b/name satisfies $i = \"John\" ";
				}
			}//end case QuantifiedPatternTreeNode

		}//processORPath


		/// <summary>
		/// Given a parsed or pattern tree node, process the paths and generate the
		/// corresponding ORFILTER operator.
		/// </summary>
		/// <param name="orNode">The parsed or pattern tree node</param>
		/// <param name="operatorId">Current position in the process tree</param>
		/// <param name="lastOperatorId">Position of the last operator (ORFILTER) added to the process tree</param>
		private void processORNode(OrPatternTreeNode orNode, int operatorId, out int lastOperatorId)
		{
			ArrayList myNodes = orNode.getNodes();
			FLWORNode ca = null;
			OrFilterNode of = new OrFilterNode(HelpFunctions.nodeID++);
			lastOperatorId = operatorId;

			for(int i=0;i<myNodes.Count;i++)
			{
				PatternTreeNode no = (PatternTreeNode)(myNodes[i]);
				PatternTreeNodeCondition ptnc = null;
				int oid = -1;
				this.processORPath(no, out oid, out ptnc, operatorId, out lastOperatorId);

				if (!HelpFunctions.success) break;

				if(oid==-1)
				{
					HelpFunctions.success = false;
					HelpFunctions.errorString = "Input to OR not using a processed node!";
					break;
				}
				else if (oid == -2)
				{
					// variable points to nested structure with simple construct
					FLWORNode fln =	this.findOperatorFromId(operatorId, (FLWORNode)(this.processTreeNode));
					if (ca == null) ca = fln;
					else ca = this.findCommonOperator(ca, fln);

					while (!(fln.GetType().Name == "JoinNode"))
					{
						fln = (FLWORNode)(fln.getChildren()[0]);
					}
					fln = (FLWORNode)(fln.getChildren()[1]);
					int numwid = fln.surviveProjection(ptnc.getNodeWID(), true, false);
					if (numwid!=-1) ptnc.setNodeWID(numwid);

					of.addCondition(ptnc);

				}
				else if (oid == -3)
				{
					// variable points to nested structure with complex construct
					FLWORNode fln =	this.findOperatorFromId(operatorId, (FLWORNode)(this.processTreeNode));
					if (ca == null) ca = fln;
					else ca = this.findCommonOperator(ca, fln);

					of.addCondition(ptnc);
				}
				else
				{
					of.addCondition(ptnc);
					FLWORNode op = this.findOperatorFromId(oid, (FLWORNode)(this.processTreeNode));
					if (ca == null) ca = op;
					else ca = this.findCommonOperator(ca, op);
				}
			}
			if (HelpFunctions.success)
			{
				FLWORNode ptout = null;
				this.addParentToProcessTreeNodeWithId(of, ca.getId(), (FLWORNode)(this.processTreeNode), out ptout);
				if (ptout!=null) {this.processTreeNode = ptout; lastOperatorId = of.getId();}
			}

		}//processORNode


		/// <summary>
		/// Given a list of sort object, process the paths and generated the corresponding sort operator
		/// </summary>
		/// <param name="mySortList">A list of sort objects</param>
		/// <param name="operatorId">Current position in the process tree</param>
		/// <param name="newOperatorId">Position of the sort node that was added</param>
		private void processOrderByNode(ArrayList mySortList, int operatorId, out int newOperatorId)
		{
			SortNode s1 = new SortNode(HelpFunctions.nodeID++);
			newOperatorId = operatorId;
			for(int i=0;i<mySortList.Count;i++)
			{
				SortPatternTreeNode sptn = (SortPatternTreeNode)(mySortList[i]);
				int outnRefWid = -1;
				int wid = this.createReferenceSelectFromPath(sptn.getMyNode(), (int)(values.structuralJoinZeroOne), operatorId, out newOperatorId, out outnRefWid);
				operatorId = newOperatorId;
				SortObject so1 = new SortObject(wid); 
				so1.setEmptyLeast(sptn.getEmptyLeast());
				so1.setSortOrder(sptn.getSortOrder());
				so1.setSortByType(sptn.getSortByType());
				s1.addToSortList(so1);
			}
			FLWORNode ptout = null;
			this.addParentToProcessTreeNodeWithId(s1, operatorId, (FLWORNode)(this.processTreeNode), out ptout);
			if (ptout != null) {this.processTreeNode = ptout; newOperatorId = s1.getId();}
		}//processOrderByNode

		/// <summary>
		/// The construct of an inner query should survive the outer projection
		/// </summary>
		/// <param name="nin">The root of the inner construct tree</param>
		private void innerConstructTreeSurviveProjection(PatternTreeNode nin)
		{
			((FLWORNode)(this.processTreeNode)).surviveProjection(nin.getId(), false, false);
			if (nin.GetType().Name == "ConstructElementPatternTreeNode")
			{
				ConstructElementPatternTreeNode cn = (ConstructElementPatternTreeNode)(nin);
				for(int i=0;i<cn.getAttributeList().Count;i++)
				{
					ConstructReferencePatternTreeNode n = (ConstructReferencePatternTreeNode)(cn.getAttributeList()[i]);
					if (!n.getNode()) this.innerConstructTreeSurviveProjection(n);
				}
				for(int i=0;i<cn.getContentList().Count;i++)
				{
					ConstructReferencePatternTreeNode n = (ConstructReferencePatternTreeNode)(cn.getContentList()[i]);
					if (!n.getNode()) this.innerConstructTreeSurviveProjection(n);
				}
			}
			for(int i=0;i<nin.getChildren().Count;i++)
			{
				ConstructReferencePatternTreeNode n = (ConstructReferencePatternTreeNode)(nin.getChildren()[i]);
				if (!n.getNode()) this.innerConstructTreeSurviveProjection(n);
			}
		}//innerConstructTreeSurviveProjection

		private void processReturnNestedQuery(FLWORNode n1, out ConstructReferencePatternTreeNode nout)
		{
			// nested query
			FLWORNode flop = n1;
			nout = null;

			// find return clause
			PatternTree pt = null;
			int wid = -1;
			for(int j=0;j<flop.getChildren().Count;j++)
			{
				if (flop.getChildren()[j].GetType().Name == "ReturnNode")
				{
					ReturnNode rn = (ReturnNode)(flop.getChildren()[j]);
					pt = rn.getPatternTree();
					break;
				}
			}
			if (pt!=null)
			{
				PatternTreeNode ptroot = (PatternTreeNode)(pt.getRoot());

				// replace the nested flwor node with a reference node pointing to the root of the construct tree
				wid = ptroot.getId();
				ConstructReferencePatternTreeNode rptn = new ConstructReferencePatternTreeNode(HelpFunctions.lcl++, wid.ToString(), false, (int)(values.child), (int)(values.referenceNode));
				if (ptroot.GetType().Name == "ConstructReferencePatternTreeNode")
				{
					ConstructReferencePatternTreeNode crptn = (ConstructReferencePatternTreeNode)(ptroot);
					crptn.setNode();
				}
				else rptn.setOuter();
				nout = rptn;

				// make sure the inner construct survives the projection
				this.innerConstructTreeSurviveProjection(ptroot);

				// find the join operator with right child a construct, convert to nest join because return
				FLWORNode constructOp = this.findOperatorFromPid(pt.getId(), (FLWORNode)(this.processTreeNode));
				FLWORNode jparent = (FLWORNode)(constructOp.getParent());
				if (jparent.GetType().Name == "JoinNode")
				{
					PatternTree jpt = jparent.getPatternTree();
					JoinDualPatternTreeNode jroot = (JoinDualPatternTreeNode)(jpt.getRoot());
					PatternTreeNode ptn2 = (PatternTreeNode)(jroot.getNode2());
					ptn2.setStructuralJoinType((int)(values.structuralJoinZeroMore));
					int wid2 = constructOp.surviveProjection(jroot.getJoinWID2(), true, false);
					jroot.setJoinWID2(wid2);

					// set it as join node, so that it does not appear in the final result
//					PatternTree constructTree = constructOp.getPatternTree();
//					ConstructReferencePatternTreeNode cr = (ConstructReferencePatternTreeNode)(constructTree.getRoot());
//					ConstructReferencePatternTreeNode cj = (ConstructReferencePatternTreeNode)(cr.findPatternTreeNode(wid2));
//					cj.setIsJoinNode();
				}


			}

		}


		/// <summary>
		/// Given a construct tree root node, generate the appropriate operators for each path, aggregate etc
		/// substitute them with the corresponding WIDs and output the construct node ready to be used
		/// for a generated construct operator.
		/// </summary>
		/// <param name="n1">The pattern tree node corresponding to the construct tree root</param>
		/// <param name="nout">The input node, after the path, aggregates etc has been replaced by WIDs</param>
		/// <param name="operatorId">Current position in the process tree</param>
		/// <param name="lastOperatorId">Position of the last operator that was added</param>
		private void processReturnNode(PatternTreeNode n1, out PatternTreeNode nout, int operatorId, out int lastOperatorId)
		{
			nout = n1;
			string tname = n1.getTagName();
			lastOperatorId = operatorId;
			// check if pt starts with variable, simple path
			if(tname.StartsWith("$"))
			{
				int outnRefWid = -1;
				int wid = this.createReferenceSelectFromPath(n1, (int)(values.structuralJoinZeroMore), operatorId, out lastOperatorId, out outnRefWid);
				ConstructReferencePatternTreeNode cptn = new ConstructReferencePatternTreeNode(HelpFunctions.lcl++, wid.ToString(), false, (int)(values.child), (int)(values.referenceNode));
				if (outnRefWid >=0) cptn.setOuter();
					else cptn.setUseTextValue(n1.findPatternTreeNode(wid).getUseTextValue());
				n1 = cptn;
				nout = cptn;
			}
			else if(tname.StartsWith("CONSTRUCT"))
			{
				ConstructElementPatternTreeNode cptn = (ConstructElementPatternTreeNode)(n1);
				ArrayList clist = cptn.getContentList(); 
				for(int i=0; i<clist.Count; i++)
				{
					if (clist[i].GetType().Name == "FLWORNode")
					{
						ConstructReferencePatternTreeNode cnout = null;
						this.processReturnNestedQuery((FLWORNode)(clist[i]), out cnout);
						clist[i] = cnout;
					}
					else 
					{
						PatternTreeNode nc = (PatternTreeNode)(clist[i]);
						PatternTreeNode ncout = null;
						this.processReturnNode(nc, out ncout, operatorId, out lastOperatorId);
						operatorId = lastOperatorId;
						clist[i] = ncout;
					}
				}
				ArrayList alist = cptn.getAttributeList();
				for(int i=0; i<alist.Count; i++)
				{
					PatternTreeNode nc = (PatternTreeNode)(alist[i]);
					PatternTreeNode ncout = null;
					this.processReturnNode(nc, out ncout, operatorId, out lastOperatorId);
					operatorId = lastOperatorId;
					alist[i] = ncout;
				}
				nout = cptn;
			}
			else if(n1.GetType().Name == "ConstructAttributePatternTreeNode")
			{
				ConstructAttributePatternTreeNode captn = (ConstructAttributePatternTreeNode)(n1);
				PatternTreeNode nc = captn.getMyNode();
				PatternTreeNode ncout = null;
				this.processReturnNode(nc, out ncout, operatorId, out lastOperatorId);
				captn.setMyNode(ncout);
				nout = captn;
			}
			else if(n1.GetType().Name == "AggregatePatternTreeNode")
			{
				int wid = this.createAggregateNode(n1, operatorId, out lastOperatorId, true);
				operatorId = lastOperatorId;

				ConstructReferencePatternTreeNode cptn = new ConstructReferencePatternTreeNode(HelpFunctions.lcl++, wid.ToString(), false, (int)(values.child), (int)(values.referenceNode));
				nout = cptn;
			}
			else if(n1.GetType().Name == "DeletePatternTreeNode")
			{
				DeletePatternTreeNode an = (DeletePatternTreeNode)(n1);
				PatternTreeNode nc = an.getMyNode();
				int outnRefWid = -1;
				int wid = this.createReferenceSelectFromPath(nc, (int)(values.structuralJoinOne), operatorId, out lastOperatorId, out outnRefWid);
				operatorId = lastOperatorId;
				DeleteNode apn = new DeleteNode(HelpFunctions.nodeID++);
				apn.setRefWID(wid);
				int eid = nc.findWIDAtEndOfPath();
				PatternTreeNode l = nc.findPatternTreeNode(eid);
				if (l.getUseTextValue()) apn.setText(); 
				FLWORNode ptout = null;
				this.addParentToProcessTreeNodeWithId(apn, operatorId, (FLWORNode)(this.processTreeNode), out ptout);
				if (ptout != null) {this.processTreeNode = ptout; lastOperatorId = apn.getId();}
				nout = null;
			}
			else if(n1.GetType().Name == "UpdatePatternTreeNode")
			{
				UpdatePatternTreeNode an = (UpdatePatternTreeNode)(n1);
				PatternTreeNode nc = an.getMyNode1();
				int outnRefWid = -1;
				int wid1 = this.createReferenceSelectFromPath(nc, (int)(values.structuralJoinZeroMore), operatorId, out lastOperatorId, out outnRefWid);
				operatorId = lastOperatorId;

				UpdateNode apn = new UpdateNode(HelpFunctions.nodeID++);
				apn.setRefWID(wid1);

				//check if comparison is to const or to reference
				PatternTreeNode n2 = an.getMyNode2();
				if ((n2.getChildren().Count == 0) && (!n2.getTagName().StartsWith("$")) && (n2.GetType().Name != "AggregatePatternTreeNode"))
				{
					// const value
					apn.setConst();
					apn.setValue(n2.getTagName().Trim('"'));
				}
				else
				{
					int wid2 = -1;
					if(n2.GetType().Name == "AggregatePatternTreeNode") wid2 = this.createAggregateNode(n2, operatorId, out lastOperatorId, true);
					else wid2 = this.createReferenceSelectFromPath(n2, (int)(values.structuralJoinZeroMore), operatorId, out lastOperatorId, out outnRefWid);
					operatorId = lastOperatorId;
					apn.setReference();
					apn.setValue(wid2.ToString());
				}

				FLWORNode ptout = null;
				this.addParentToProcessTreeNodeWithId(apn, operatorId, (FLWORNode)(this.processTreeNode), out ptout );
				if (ptout != null) {this.processTreeNode = ptout; lastOperatorId = apn.getId();}
				nout = null;
			}
			else if(n1.GetType().Name == "InsertPatternTreeNode")
			{
				InsertPatternTreeNode an = (InsertPatternTreeNode)(n1);
				PatternTreeNode nc = an.getMyNode();
				int outnRefWid = -1;
				int wid = this.createReferenceSelectFromPath(nc, (int)(values.structuralJoinZeroMore), operatorId, out lastOperatorId, out outnRefWid);
				operatorId = lastOperatorId;
				InsertNode apn = new InsertNode(HelpFunctions.nodeID++);
				apn.setRefWID(wid);
				if (an.getSpecial() == (int)(values.insertfile)) apn.setDocValue(an.getFileName());
				else
				{
					if (an.getSpecial() == (int)(values.insertattribute)) apn.setAttribute();
					ArrayList myList = an.getList();
					for(int i=0; i<myList.Count;i++)
					{
						InsertObject io = (InsertObject)(myList[i]);
						//check if comparison is to const or to reference
						PatternTreeNode nio = io.getMyNode();
						if ((nio.getChildren().Count == 0) && (!nio.getTagName().StartsWith("$")) && (nio.GetType().Name != "AggregatePatternTreeNode"))
						{
							// const value
							io.setConst();
							io.setValue(nio.getTagName().Trim('"'));
						}
						else
						{
							int wid2 = -1;
							if(nio.GetType().Name == "AggregatePatternTreeNode") wid2= this.createAggregateNode(nio, operatorId, out lastOperatorId, true);
							else wid2 = this.createReferenceSelectFromPath(nio, (int)(values.structuralJoinZeroMore), operatorId, out lastOperatorId, out outnRefWid);
							operatorId = lastOperatorId;
							io.setReference();
							io.setValue(wid2.ToString());
						}
						myList[i] = io;
						apn.addToList(io);
					}
				}

				FLWORNode ptout = null;
				this.addParentToProcessTreeNodeWithId(apn, operatorId, (FLWORNode)(this.processTreeNode), out ptout );
				if (ptout != null) {this.processTreeNode = ptout; lastOperatorId = apn.getId();}
				nout = null;
			}
		}//processReturnNode

		/// <summary>
		/// Process the parsed construct tree, generating the appropriate operators and adding a construct on top.
		/// </summary>
		/// <param name="pt">The parsed construct tree</param>
		/// <param name="operatorId">Current position in the process tree</param>
		/// <param name="lastOperatorId">Position of last operator added to the tree</param>
		private void processReturnTree(PatternTree pt, int operatorId, out int lastOperatorId)
		{
			PatternTreeNode nout = null;
			lastOperatorId = operatorId;
			if (pt.getRoot().GetType().Name == "FLWORNode")
			{
				ConstructReferencePatternTreeNode cnout = null;
				this.processReturnNestedQuery((FLWORNode)(pt.getRoot()), out cnout);
				nout = cnout;
			}
			else
			{
				PatternTreeNode n1 = (PatternTreeNode)(pt.getRoot());
				this.processReturnNode(n1, out nout, operatorId, out lastOperatorId);
				operatorId = lastOperatorId;
			}
			if (nout != null)
			{
				pt.setRoot(nout);

				ConstructNode c1 = new ConstructNode(HelpFunctions.nodeID++);
				c1.setPatternTree(pt);
				FLWORNode ptout = null;
				this.addParentToProcessTreeNodeWithId(c1, operatorId, (FLWORNode)(this.processTreeNode), out ptout);
				if (ptout != null) {this.processTreeNode = ptout; lastOperatorId = c1.getId(); operatorId = lastOperatorId;}

				this.patternTrees.Add(pt);
			}

		}//processReturnTree






	

		private bool doReduction(Reduction reduction)
		{
			string ptr = reduction.ToString();
			Rule rule = reduction.ParentRule;
			switch (rule.TableIndex)
			{
				case (int)RuleConstants.RuleQnameNcname:
				{
					myStackElement myEl = this.getMyStackElementFromLexeme(0, reduction);
					reduction.Tag = myEl;
					internalString += ptr + myEl.getMyName() + "\n";
				}
					break;


					// RuleTexttestTextlparanrparan = 222, // <TextTest> ::= 'TEXT()'
				case (int)RuleConstants.RuleTexttestTextlparanrparan:
				{
					myStackElement myEl = this.getMyStackElementFromLexeme(0, reduction);
					reduction.Tag = myEl;
					internalString += ptr + myEl.getMyName() + "\n";
				}
					break;

					// RuleSomeoreverySome = 63 , // <SomeOrEvery> ::= SOME
				case (int)RuleConstants.RuleSomeoreverySome:
				{
					myStackElement myEl = this.getMyStackElementFromLexeme(0, reduction);
					reduction.Tag = myEl;
					internalString += ptr + myEl.getMyName() + "\n";
				}
					break;

					// RuleSomeoreveryEvery = 64 , // <SomeOrEvery> ::= EVERY
				case (int)RuleConstants.RuleSomeoreveryEvery:
				{
					myStackElement myEl = this.getMyStackElementFromLexeme(0, reduction);
					reduction.Tag = myEl;
					internalString += ptr + myEl.getMyName() + "\n";
				}
					break;

					//	RuleAscdescopAscending = 179, // <AscDescOp> ::= ASCENDING
				case (int)RuleConstants.RuleAscdescopAscending:
				{
					myStackElement myEl = this.getMyStackElementFromLexeme(0, reduction);
					reduction.Tag = myEl;
					internalString += ptr + myEl.getMyName() + "\n";
				}
					break;

					//	RuleAscdescopDescending = 180, // <AscDescOp> ::= DESCENDING
				case (int)RuleConstants.RuleAscdescopDescending:
				{
					myStackElement myEl = this.getMyStackElementFromLexeme(0, reduction);
					reduction.Tag = myEl;
					internalString += ptr + myEl.getMyName() + "\n";
				}
					break;

					//	RuleEmptyopEmptyGreatest = 181, // <EmptyOp> ::= EMPTY GREATEST
				case (int)RuleConstants.RuleEmptyopEmptyGreatest:
				{
					myStackElement myEl = this.getMyStackElementFromLexeme(0, reduction);
					myStackElement myEl1 = this.getMyStackElementFromLexeme(1, reduction);
					myEl.setMyName(myEl.getMyName() + " " + myEl1.getMyName());
					reduction.Tag = myEl;
					internalString += ptr + myEl.getMyName() + "\n";
				}
					break;

					//	RuleEmptyopEmptyLeast = 182, // <EmptyOp> ::= EMPTY LEAST
				case (int)RuleConstants.RuleEmptyopEmptyLeast:
				{
					myStackElement myEl = this.getMyStackElementFromLexeme(0, reduction);
					myStackElement myEl1 = this.getMyStackElementFromLexeme(1, reduction);
					myEl.setMyName(myEl.getMyName() + " " + myEl1.getMyName());
					reduction.Tag = myEl;
					internalString += ptr + myEl.getMyName() + "\n";
				}
					break;


				//		RuleGeneralcompEq = 150, // <GeneralComp> ::= '='
				case (int)RuleConstants.RuleGeneralcompEq:
				{
					myStackElement myEl = this.getMyStackElementFromLexeme(0, reduction);
					reduction.Tag = myEl;
					internalString += ptr + myEl.getMyName() + "\n";
				}
					break;

				//		RuleGeneralcompExclameq  = 151, // <GeneralComp> ::= '!='
				case (int)RuleConstants.RuleGeneralcompExclameq:
				{
					myStackElement myEl = this.getMyStackElementFromLexeme(0, reduction);
					reduction.Tag = myEl;
					internalString += ptr + myEl.getMyName() + "\n";
				}
					break;
				//		RuleGeneralcompLt = 152, // <GeneralComp> ::= '<'
				case (int)RuleConstants.RuleGeneralcompLt:
				{
					myStackElement myEl = this.getMyStackElementFromLexeme(0, reduction);
					reduction.Tag = myEl;
					internalString += ptr + myEl.getMyName() + "\n";
				}
					break;
				
				//		RuleGeneralcompLteq = 153, // <GeneralComp> ::= '<='
				case (int)RuleConstants.RuleGeneralcompLteq:
				{
					myStackElement myEl = this.getMyStackElementFromLexeme(0, reduction);
					reduction.Tag = myEl;
					internalString += ptr + myEl.getMyName() + "\n";
				}
					break;

					//		RuleGeneralcompGt = 154, // <GeneralComp> ::= '>'
				case (int)RuleConstants.RuleGeneralcompGt:
				{
					myStackElement myEl = this.getMyStackElementFromLexeme(0, reduction);
					reduction.Tag = myEl;
					internalString += ptr + myEl.getMyName() + "\n";
				}
					break;

					//		RuleGeneralcompGteq = 155, // <GeneralComp> ::= '>='
				case (int)RuleConstants.RuleGeneralcompGteq:
				{
					myStackElement myEl = this.getMyStackElementFromLexeme(0, reduction);
					reduction.Tag = myEl;
					internalString += ptr + myEl.getMyName() + "\n";
				}
					break;

					//		RuleValuecompEq = 156, // <ValueComp> ::= EQ
				case (int)RuleConstants.RuleValuecompEq:
				{
					myStackElement myEl = this.getMyStackElementFromLexeme(0, reduction);
					reduction.Tag = myEl;
					internalString += ptr + myEl.getMyName() + "\n";
				}
					break;

					//		RuleValuecompNe = 157, // <ValueComp> ::= NE
				case (int)RuleConstants.RuleValuecompNe:
				{
					myStackElement myEl = this.getMyStackElementFromLexeme(0, reduction);
					reduction.Tag = myEl;
					internalString += ptr + myEl.getMyName() + "\n";
				}
					break;

					//		RuleValuecompLt = 158, // <ValueComp> ::= LT
				case (int)RuleConstants.RuleValuecompLt:
				{
					myStackElement myEl = this.getMyStackElementFromLexeme(0, reduction);
					reduction.Tag = myEl;
					internalString += ptr + myEl.getMyName() + "\n";
				}
					break;

					//		RuleValuecompLe = 159, // <ValueComp> ::= LE
				case (int)RuleConstants.RuleValuecompLe:
				{
					myStackElement myEl = this.getMyStackElementFromLexeme(0, reduction);
					reduction.Tag = myEl;
					internalString += ptr + myEl.getMyName() + "\n";
				}
					break;

					//		RuleValuecompGt = 160, // <ValueComp> ::= GT
				case (int)RuleConstants.RuleValuecompGt:
				{
					myStackElement myEl = this.getMyStackElementFromLexeme(0, reduction);
					reduction.Tag = myEl;
					internalString += ptr + myEl.getMyName() + "\n";
				}
					break;

					//		RuleValuecompGe = 161, // <ValueComp> ::= GE
				case (int)RuleConstants.RuleValuecompGe:
				{
					myStackElement myEl = this.getMyStackElementFromLexeme(0, reduction);
					reduction.Tag = myEl;
					internalString += ptr + myEl.getMyName() + "\n";
				}
					break;

					//		RuleNodecompIs  = 162, // <NodeComp> ::= IS
				case (int)RuleConstants.RuleNodecompIs:
				{
					myStackElement myEl = this.getMyStackElementFromLexeme(0, reduction);
					reduction.Tag = myEl;
					internalString += ptr + myEl.getMyName() + "\n";
				}
					break;

					//		RuleNodecompIsnot = 163, // <NodeComp> ::= ISNOT
				case (int)RuleConstants.RuleNodecompIsnot:
				{
					myStackElement myEl = this.getMyStackElementFromLexeme(0, reduction);
					reduction.Tag = myEl;
					internalString += ptr + myEl.getMyName() + "\n";
				}
					break;

					//		RuleOrdercompLtlt = 164, // <OrderComp> ::= '<<'
				case (int)RuleConstants.RuleOrdercompLtlt:
				{
					myStackElement myEl = this.getMyStackElementFromLexeme(0, reduction);
					reduction.Tag = myEl;
					internalString += ptr + myEl.getMyName() + "\n";
				}
					break;

					//		RuleOrdercompGtgt = 165, // <OrderComp> ::= '>>'
				case (int)RuleConstants.RuleOrdercompGtgt:
				{
					myStackElement myEl = this.getMyStackElementFromLexeme(0, reduction);
					reduction.Tag = myEl;
					internalString += ptr + myEl.getMyName() + "\n";
				}
					break;


					//		RuleSlashopDivdiv = 114, // <SlashOp> ::= '//'
				case (int)RuleConstants.RuleSlashopDivdiv:
				{
					myStackElement myEl = this.getMyStackElementFromLexeme(0, reduction);
					reduction.Tag = myEl;
					internalString += ptr + myEl.getMyName() + "\n";
				}
					break;

					//		RuleSlashopDiv = 113, // <SlashOp> ::= '/'
				case (int)RuleConstants.RuleSlashopDiv:
				{
					myStackElement myEl = this.getMyStackElementFromLexeme(0, reduction);
					reduction.Tag = myEl;
					internalString += ptr + myEl.getMyName() + "\n";
				}
					break;

				case (int)RuleConstants.RuleLiteralStringliteral:
				{
					myStackElement myEl = this.getMyStackElementFromLexeme(0, reduction);
					reduction.Tag = myEl;
					internalString += ptr + myEl.getMyName() + "\n";

				}
					break;

					// RuleNumericliteralIntegerliteral = 243, // <NumericLiteral> ::= IntegerLiteral
				case (int)RuleConstants.RuleNumericliteralIntegerliteral:
				{
					myStackElement myEl = this.getMyStackElementFromLexeme(0, reduction);
					reduction.Tag = myEl;
					internalString += ptr + myEl.getMyName() + "\n";

				}
					break;

					// RuleNumericliteralDecimalliteral = 244, // <NumericLiteral> ::= DecimalLiteral
				case (int)RuleConstants.RuleNumericliteralDecimalliteral:
				{
					myStackElement myEl = this.getMyStackElementFromLexeme(0, reduction);
					reduction.Tag = myEl;
					internalString += ptr + myEl.getMyName() + "\n";

				}
					break;

					//RulePrimaryexprDollar = 187, // <PrimaryExpr> ::= '$' <QName>
				case (int)RuleConstants.RulePrimaryexprDollar:
				{
					myStackElement myEl = this.getMyStackElementFromProduction(1, reduction);
					myEl.setMyName("$" + myEl.getMyName());
					PatternTreeNode ptn = new PatternTreeNode(0);
					ptn.setTagName(myEl.getMyName());
					myEl.setMyNode(ptn);
					reduction.Tag = myEl;
					internalString += ptr + myEl.getMyName() + "\n";
				}
					break;


					// RuleParenthesizedexprLparanRparan = 247, // <ParenthesizedExpr> ::= '(' <Expr> ')'
				case (int)RuleConstants.RuleParenthesizedexprLparanRparan:
				{
					myStackElement myEl = this.getMyStackElementFromProduction(1, reduction);
					myEl.setMyName("(" + myEl.getMyName() + ")");
					reduction.Tag = myEl;
					internalString += ptr + myEl.getMyName() + "\n";
				}
					break;

					// RuleParenthesizedexprLparanrparan2 = 248, // <ParenthesizedExpr> ::= '()'
				case (int)RuleConstants.RuleParenthesizedexprLparanrparan2:
				{
					myStackElement myEl = this.getMyStackElementFromLexeme(0, reduction);
					myEl.setMyName("()");
					reduction.Tag = myEl;
					internalString += ptr + myEl.getMyName() + "\n";
				}
					break;

					// RuleFunctioncall = 249, // <FunctionCall> ::= <QName> <ParenthesizedExpr>
				case (int)RuleConstants.RuleFunctioncall:
				{
					myStackElement myEl0 = this.getMyStackElementFromProduction(0, reduction);
					myStackElement myEl1 = this.getMyStackElementFromProduction(1, reduction);
					myStackElement myEl = new myStackElement();
					if ((myEl1.getMyNode()!=null)&&(myEl1.getMyNode().GetType().Name == "FLWORNode"))
					{
						// nested query in the function
						HelpFunctions.errorString += "Nested Query in function is not supported! " + myEl0.getMyName() + myEl1.getMyName() + "\n";
						HelpFunctions.success = false;
						return true;
					}					
					string functionName = myEl0.getMyName();
					functionName = functionName.ToLower();
					if (functionName == "document")
					{
						// for the document root node
						myEl.setMyName(functionName + myEl1.getMyName());
						PatternTreeNode ptna = new PatternTreeNode(HelpFunctions.lcl++);
						ptna.setTagName(myEl.getMyName()); 
						myEl.setMyNode(ptna);
					}
					else if ((functionName == "count")||(functionName == "avg")||(functionName == "max")||(functionName == "min")||(functionName == "sum"))
					{
						// we found an aggregate function
						AggregatePatternTreeNode ptna = new AggregatePatternTreeNode(HelpFunctions.lcl++);
						ptna.setTagName(functionName + myEl1.getMyName()); 
						ptna.setSpecial((int)(values.specialAggregateNode));
						ptna.setFunctionName(functionName);
						PatternTreeNode ptn1 = (PatternTreeNode)(myEl1.getMyNode());
						HelpFunctions.setStructuralJoin(ptn1, (int)(values.structuralJoinZeroMore));
						ptna.setMyNode(ptn1);
						myEl.setMyName(functionName + myEl1.getMyName());
						myEl.setMyNode(ptna);
					}
					else if (functionName == "timber-delete")					
					{
						// we found a delete function
						DeletePatternTreeNode ptna = new DeletePatternTreeNode(HelpFunctions.reflcl++);
						ptna.setTagName(functionName + myEl1.getMyName()); 
						ptna.setSpecial((int)(values.delete));
						PatternTreeNode ptn1 = (PatternTreeNode)(myEl1.getMyNode());
						HelpFunctions.setStructuralJoin(ptn1, (int)(values.structuralJoinOne));
						ptna.setMyNode(ptn1);
						myEl.setMyName(functionName + myEl1.getMyName());
						myEl.setMyNode(ptna);
					}
					else if (functionName == "timber-update")					
					{
						// we found an update function
						UpdatePatternTreeNode ptna = new UpdatePatternTreeNode(HelpFunctions.reflcl++);
						ptna.setTagName(functionName + myEl1.getMyName()); 
						ptna.setSpecial((int)(values.update));
						PatternTreeNode ptn0 = (PatternTreeNode)(myEl1.getMyList()[0]);
						HelpFunctions.setStructuralJoin(ptn0, (int)(values.structuralJoinOne));
						PatternTreeNode ptn1 = (PatternTreeNode)(myEl1.getMyList()[1]);
						HelpFunctions.setStructuralJoin(ptn1, (int)(values.structuralJoinZeroMore));
						ptna.setMyNode1(ptn0);
						ptna.setMyNode2(ptn1);
						//ptna.setFileName(ptn1.getTagName());
						myEl.setMyName(functionName + myEl1.getMyName());
						myEl.setMyNode(ptna);
					}
					else if (functionName == "timber-insertfile")					
					{
						// we found an insert function
						InsertPatternTreeNode ptna = new InsertPatternTreeNode(HelpFunctions.reflcl++);
						ptna.setTagName(functionName + myEl1.getMyName()); 
						ptna.setSpecial((int)(values.insertfile));
						PatternTreeNode ptn0 = (PatternTreeNode)(myEl1.getMyList()[0]);
						HelpFunctions.setStructuralJoin(ptn0, (int)(values.structuralJoinOne));
						PatternTreeNode ptn1 = (PatternTreeNode)(myEl1.getMyList()[1]);
						HelpFunctions.setStructuralJoin(ptn1, (int)(values.structuralJoinZeroMore));
						ptna.setMyNode(ptn0);
						ptna.setFileName(ptn1.getTagName());
						myEl.setMyName(functionName + myEl1.getMyName());
						myEl.setMyNode(ptna);
					}
					else if (functionName == "timber-insertelement")					
					{
						// we found an insert function
						InsertPatternTreeNode ptna = new InsertPatternTreeNode(HelpFunctions.reflcl++);
						ptna.setTagName(functionName + myEl1.getMyName()); 
						ptna.setSpecial((int)(values.insertelement));
						// where to insert the element
						PatternTreeNode ptn0 = (PatternTreeNode)(myEl1.getMyList()[0]);
						HelpFunctions.setStructuralJoin(ptn0, (int)(values.structuralJoinOne));
						ptna.setMyNode(ptn0);

						// get the element tag name and value
						PatternTreeNode ptne1 = (PatternTreeNode)(myEl1.getMyList()[1]);
						PatternTreeNode ptne2 = (PatternTreeNode)(myEl1.getMyList()[2]);
						HelpFunctions.setStructuralJoin(ptne2, (int)(values.structuralJoinZeroMore));
						InsertObject eo = new InsertObject();
						eo.setTagName(ptne1.getTagName().Trim('"'));
						eo.setMyNode(ptne2);
						ptna.addToList(eo);

						// check for attributes and add them to the list
						if (myEl1.getMyList().Count > 3)
						{
							for(int i=3; i<myEl1.getMyList().Count; i++)
							{
								PatternTreeNode ptna1 = (PatternTreeNode)(myEl1.getMyList()[i++]);
								PatternTreeNode ptna2 = (PatternTreeNode)(myEl1.getMyList()[i]);
								HelpFunctions.setStructuralJoin(ptna2, (int)(values.structuralJoinZeroMore));
								InsertObject ao = new InsertObject();
								ao.setTagName(ptna1.getTagName().Trim('"'));
								ao.setMyNode(ptna2);
								ptna.addToList(ao);
							}
						}
						
						myEl.setMyName(functionName + myEl1.getMyName());
						myEl.setMyNode(ptna);
					}
					else if (functionName == "timber-insertattribute")					
					{
						// we found an insert function
						InsertPatternTreeNode ptna = new InsertPatternTreeNode(HelpFunctions.reflcl++);
						ptna.setTagName(functionName + myEl1.getMyName()); 
						ptna.setSpecial((int)(values.insertattribute));
						// where to insert the element
						PatternTreeNode ptn0 = (PatternTreeNode)(myEl1.getMyList()[0]);
						HelpFunctions.setStructuralJoin(ptn0, (int)(values.structuralJoinOne));
						ptna.setMyNode(ptn0);

						// get the element tag name and value
						PatternTreeNode ptne1 = (PatternTreeNode)(myEl1.getMyList()[1]);
						PatternTreeNode ptne2 = (PatternTreeNode)(myEl1.getMyList()[2]);
						HelpFunctions.setStructuralJoin(ptne2, (int)(values.structuralJoinZeroMore));
						InsertObject eo = new InsertObject();
						eo.setTagName(ptne1.getTagName().Trim('"'));
						eo.setMyNode(ptne2);
						ptna.addToList(eo);

						myEl.setMyName(functionName + myEl1.getMyName());
						myEl.setMyNode(ptna);
					}
					else if (functionName == "timber-mlca")					
					{
						// we found a mlca function
						MLCAPatternTreeNode ptna = new MLCAPatternTreeNode(HelpFunctions.reflcl++);
						ptna.setTagName(functionName + myEl1.getMyName()); 
						ptna.setSpecial((int)(values.mlca));
						int pid = HelpFunctions.treeID++;
						PatternTreeNode root = new PatternTreeNode(HelpFunctions.lcl++, "MLCA-Root");
						ArrayList inputList = myEl1.getMyList();
						ArrayList nodeList = new ArrayList();
						nodeList.Add(root.getId());
						// the list should be pairs variable, path
						for(int i=0; i<inputList.Count;i++)
						{
							// for the variable node
							PatternTreeNode ptn0 = (PatternTreeNode)(inputList[i++]);
							HelpFunctions.setStructuralJoin(ptn0, (int)(values.structuralJoinOne));
							// for the path node
							PatternTreeNode ptn1 = (PatternTreeNode)(inputList[i]);
							HelpFunctions.setStructuralJoin(ptn1, (int)(values.structuralJoinOne));
							// create variable binding
							int wid = ptn1.findWIDAtEndOfPath();
							string docname = HelpFunctions.findDocumentName(ptn1, this.variableListCurrent);
							VariableMapping vm = new VariableMapping(ptn0.getTagName(), pid, wid, -1, docname, (int)(values.mlcaBinding), (int)(values.mlca));
							if (!this.checkIfVariableNameExists(vm.getName())) this.variableListCurrent.Add(vm);
							else 
							{
								HelpFunctions.errorString += "Variable name used more then once in the query! " + vm.getName() + "\n";
								HelpFunctions.success = false;
								return true;
							}
							nodeList.Add(wid);
							root.addChild(ptn1);
						}
						PatternTree pt = new PatternTree(pid);
						pt.setRoot(root);
						ptna.setPatternTree(pt);
						ptna.setBoundNodes(nodeList);

						myEl.setMyName(functionName + myEl1.getMyName());
						myEl.setMyNode(ptna);
					}
					else
					{
						internalString += "Function Not Supported! " + functionName + myEl1.getMyName() + "\n";
						HelpFunctions.errorString += "Function Not Supported! " + functionName +  myEl1.getMyName() + "\n";
						HelpFunctions.success = false;
						return true;
					}

					reduction.Tag = myEl;
					internalString += ptr + myEl.getMyName() + "\n";
					
				}
					break;

				//	RuleRelativepathexpr2 = 112, // <RelativePathExpr> ::= <StepExpr> <SlashOp> <RelativePathExpr>
				case (int)RuleConstants.RuleRelativepathexpr2:
				{
					myStackElement myEl0 = this.getMyStackElementFromProduction(0, reduction);
					myStackElement myEl1 = this.getMyStackElementFromProduction(1, reduction);
					myStackElement myEl2 = this.getMyStackElementFromProduction(2, reduction);
					myStackElement myEl = new myStackElement();
					myEl.setMyName(myEl0.getMyName() + myEl1.getMyName() + myEl2.getMyName());

					// check if node exists
					PatternTreeNode ptn0 = this.getPatternTreeNodeFromMyStackElement(myEl0);
					PatternTreeNode ptn2 = this.getPatternTreeNodeFromMyStackElement(myEl2);

					if (myEl2.getMyName().StartsWith("text()"))
					{
						ptn0.setUseTextValue(true);
					}
					else
					{
						// create path
						string slashop = myEl1.getMyName();
						if (slashop == "/") 
							ptn2.setRelationWithParent((int)(values.child));
						else if (slashop == "//")
							ptn2.setRelationWithParent((int)(values.descendant));
						ptn2.setParent(ptn0);
						ptn0.addChild(ptn2);
					}

					myEl.setMyNode(ptn0);

					reduction.Tag = myEl;
					internalString += ptr + myEl.getMyName() + "\n";
				}
					break;

					// RuleOrdermodifier = 176, // <OrderModifier> ::= <AscDescOp> <EmptyOp>
				case (int)RuleConstants.RuleOrdermodifier:
				{
					myStackElement myEl0 = this.getMyStackElementFromProduction(0, reduction);
					myStackElement myEl1 = this.getMyStackElementFromProduction(1, reduction);
					myStackElement myEl = new myStackElement();
					myEl.setMyName(myEl0.getMyName() + " " + myEl1.getMyName());
					reduction.Tag = myEl;
					internalString += ptr + myEl.getMyName() + "\n";
				}
					break;

					// RuleOrderspeclistComma = 169, // <OrderSpecList> ::= <OrderSpec> ',' <OrderSpecList>
				case (int)RuleConstants.RuleOrderspeclistComma:
				{
					myStackElement myEl0 = this.getMyStackElementFromProduction(0, reduction);
					myStackElement myEl2 = this.getMyStackElementFromProduction(2, reduction);
					myStackElement myEl = new myStackElement();
					myEl.setMyName(myEl0.getMyName() + ", " + myEl2.getMyName());

					if (myEl0.getMyNode().GetType().Name != "SortPatternTreeNode")
					{
						SortPatternTreeNode sptn = new SortPatternTreeNode(0);
						sptn.setMyNode((PatternTreeNode)(myEl0.getMyNode()));
						myEl0.setMyNode(sptn);
					}


					ArrayList newList = new ArrayList();
					newList.Add(myEl0.getMyNode());
					if (myEl2.getMyList().Count != 0) newList.AddRange(myEl2.getMyList());
					else 
					{
						if (myEl2.getMyNode().GetType().Name != "SortPatternTreeNode")
						{
							SortPatternTreeNode sptn = new SortPatternTreeNode(0);
							sptn.setMyNode((PatternTreeNode)(myEl2.getMyNode()));
							myEl2.setMyNode(sptn);
						}
						newList.Add(myEl2.getMyNode());
					}

					myEl.setMyList(newList);
					reduction.Tag = myEl;
					internalString += ptr + myEl.getMyName() + "\n";
				}
					break;

					// RuleOrderspec = 170, // <OrderSpec> ::= <ExprSingle> <OrderModifier>
				case (int)RuleConstants.RuleOrderspec:
				{
					myStackElement myEl0 = this.getMyStackElementFromProduction(0, reduction);
					myStackElement myEl1 = this.getMyStackElementFromProduction(1, reduction);
					myStackElement myEl = new myStackElement();
					myEl.setMyName(myEl0.getMyName() + " " + myEl1.getMyName());

					SortPatternTreeNode sptn = new SortPatternTreeNode(0);
					sptn.setMyNode((PatternTreeNode)(myEl0.getMyNode()));
					string ob = myEl1.getMyName();
					if (ob.Length > "EMPTY GREATEST".Length)
					{
						// both asc and empty
						if (ob.StartsWith("desc")) sptn.setSortOrder((int)(values.sortDescending));
						else sptn.setSortOrder((int)(values.sortAscending));
						if (ob.EndsWith("greatest")) sptn.setEmptyLeast((int)(values.sortEmptyGreatest));
						else sptn.setEmptyLeast((int)(values.sortEmptyLeast));
					}
					else if (ob.StartsWith("empty"))
					{
						if (ob.EndsWith("greatest")) sptn.setEmptyLeast((int)(values.sortEmptyGreatest));
						else sptn.setEmptyLeast((int)(values.sortEmptyLeast));
					}
					else if (ob.StartsWith("desc")) sptn.setSortOrder((int)(values.sortDescending));
					else sptn.setSortOrder((int)(values.sortAscending));

					myEl.setMyNode(sptn);
					reduction.Tag = myEl;
					internalString += ptr + myEl.getMyName() + "\n";
				}
					break;

					// RuleOrderbyclauseOrderBy = 166, // <OrderByClause> ::= ORDER BY <OrderSpecList>
				case (int)RuleConstants.RuleOrderbyclauseOrderBy:
				{
					myStackElement myEl2 = this.getMyStackElementFromProduction(2, reduction);
					myStackElement myEl = new myStackElement();
					myEl.setMyName("\nORDER BY " + myEl2.getMyName());

					// check if node exists
					OrderByNode ptn2 = this.getOrderByNodeFromMyStackElement(myEl2);

					myEl.setMyNode(ptn2);

					reduction.Tag = myEl;
					internalString += ptr + myEl.getMyName() + "\n";
				}
					break;

					//RuleForclauseFor = 123, // <ForClause> ::= FOR <ForVarPlus>
				case (int)RuleConstants.RuleForclauseFor:
				{
					myStackElement myEl = this.getMyStackElementFromProduction(1, reduction);
					myEl.setMyName("FOR " + myEl.getMyName());
					reduction.Tag = myEl;
					internalString += ptr + myEl.getMyName() + "\n";
				}
					break;

					// RuleLetclauseLet = 130, // <LetClause> ::= LET <LetVarPlus>
				case (int)RuleConstants.RuleLetclauseLet:
				{
					myStackElement myEl = this.getMyStackElementFromProduction(1, reduction);
					myEl.setMyName("LET " + myEl.getMyName());
					HelpFunctions.setStructuralJoin((PatternTreeNode)(myEl.getMyNode()), (int)(values.structuralJoinZeroMore));
					reduction.Tag = myEl;
					internalString += ptr + myEl.getMyName() + "\n";
				}
					break;

					// RuleQuantifiedexprSatisfies = 58 , // <QuantifiedExpr> ::= <SomeOrEvery> <VarDeclPlus> SATISFIES <ExprSingle>
				case (int)RuleConstants.RuleQuantifiedexprSatisfies:
				{
					myStackElement myEl0 = this.getMyStackElementFromProduction(0, reduction);
					myStackElement myEl1 = this.getMyStackElementFromProduction(1, reduction);
					myStackElement myEl3 = this.getMyStackElementFromProduction(3, reduction);
					myStackElement myEl = new myStackElement();
					myEl.setMyName(myEl0.getMyName() + " " + myEl1.getMyName() + " SATISFIES " + myEl3.getMyName());


					PatternTreeNode ptn3 = (PatternTreeNode)(myEl3.getMyNode());
					if (!ptn3.getTagName().StartsWith("$"))
					{
						HelpFunctions.errorString += "In quantifiers timber supports only simple paths and predicates. \nThere was a problem with \'" + myEl3.getMyName() + "\'\n";
						HelpFunctions.success = false;
						return true;
					}

					PatternTree pt1 = (PatternTree)(myEl1.getMyTree());
					PatternTree pt3 = new PatternTree(HelpFunctions.treeID++);
					pt3.setRoot(ptn3);
					HelpFunctions.setStructuralJoin((PatternTreeNode)(pt1.getRoot()), (int)(values.structuralJoinZeroMore));
					HelpFunctions.setStructuralJoin(ptn3, (int)(values.structuralJoinZeroOne));
					int countwid = -1;
					if (ptn3.getChildren().Count > 0) countwid = ((PatternTreeNode)(pt1.getRoot())).findWIDAtEndOfPath(); 
					pt1 = HelpFunctions.mergePatternTrees(pt1, pt3, this.variableListCurrent);

					// remove the variable binding from the table info, it will not be used outside the quantifier scope
					VariableMapping vm = null;
					for(int i=0; i<this.variableListCurrent.Count; i++)
					{
						vm = (VariableMapping)(this.variableListCurrent[i]);
						if (vm.getPid() == pt1.getId()) {this.variableListCurrent.Remove(vm); break;}
					}

					QuantifiedPatternTreeNode qpt = new QuantifiedPatternTreeNode(0);
					qpt.setPatternTree(pt1);
					if (myEl0.getMyName() == "every") 
					{
						qpt.setSubType((int)(values.everySubType));					
						qpt.setCountWid(countwid);
					}
					else 
					{
						qpt.setSubType((int)(values.someSubType));
						qpt.setCountWid(-1);
					}
					myEl.setMyNode(qpt);

					reduction.Tag = myEl;
					internalString += ptr + myEl.getMyName() + "\n";
				}
					break;

				// RuleVardeclDollarIn = 59 , // <VarDecl> ::= '$' <QName> IN <ExprSingle> // SOME/EVERY
				case (int)RuleConstants.RuleVardeclDollarIn:
				{
					myStackElement myEl1 = this.getMyStackElementFromProduction(1, reduction);
					myStackElement myEl3 = this.getMyStackElementFromProduction(3, reduction);
					myStackElement myEl = new myStackElement();
					myEl.setMyName("$" + myEl1.getMyName() + " IN " + myEl3.getMyName());

					PatternTree pt = new PatternTree(HelpFunctions.treeID++);
					pt.setRoot(myEl3.getMyNode());
					this.patternTrees.Add(pt);

					// create a mapping for the variable in terms of PIDWID
					// The tree is actually a path, traverse it down to get the wid
					int wid = ((PatternTreeNode)(myEl3.getMyNode())).findWIDAtEndOfPath();
					string docName = HelpFunctions.findDocumentName((PatternTreeNode)(myEl3.getMyNode()), this.variableListCurrent);
					VariableMapping vm = new VariableMapping(myEl1.getMyName(), pt.getId(), wid, -1, docName, (int)(values.everyBinding), (int)(values.noValue));
					if (!this.checkIfVariableNameExists(vm.getName())) this.variableListCurrent.Add(vm);
					else 
					{
						HelpFunctions.errorString += "Variable name used more then once in the query! " + vm.getName() + "\n";
						HelpFunctions.success = false;
						return true;
					}

					myEl.setMyNode(myEl3.getMyNode());
					myEl.setMyTree(pt);

					reduction.Tag = myEl;
					internalString += ptr + myEl.getMyName() + "\n";
				}
					break;

				//RuleForvarDollarIn = 124, // <ForVar> ::= '$' <QName> IN <ExprSingle>
				case (int)RuleConstants.RuleForvarDollarIn:
				{
					myStackElement myEl1 = this.getMyStackElementFromProduction(1, reduction);
					myStackElement myEl3 = this.getMyStackElementFromProduction(3, reduction);
					myStackElement myEl = new myStackElement();
					myEl.setMyName("$" + myEl1.getMyName() + " IN " + myEl3.getMyName());

					if (myEl3.getMyNode().GetType().Name == "FLWORNode")
					{
						FLWORNode flop = (FLWORNode)(myEl3.getMyNode());
						PatternTree pt = null;
						int oid = -1;
						for(int i=0;i<flop.getChildren().Count;i++)
						{
							if (flop.getChildren()[i].GetType().Name == "ReturnNode")
							{
								ReturnNode rn = (ReturnNode)(flop.getChildren()[i]);
								pt = rn.getPatternTree();
								oid = rn.getId();
								break;
							}
						}
						if (pt!=null)
						{
							PatternTreeNode ptroot = (PatternTreeNode)(pt.getRoot());
							int wid = ptroot.getId();
							string docName = HelpFunctions.findDocumentName(ptroot, this.variableListCurrent);
							VariableMapping vm = new VariableMapping(myEl1.getMyName(), pt.getId(), wid, oid, docName, (int)(values.forBinding), (int)(values.nestedQuery));
							if (!this.checkIfVariableNameExists(vm.getName())) this.variableListCurrent.Add(vm);
							else 
							{
								HelpFunctions.errorString += "Variable name used more then once in the query! " + vm.getName() + "\n";
								HelpFunctions.success = false;
								return true;
							}

							myEl.setMyNode(ptroot);
							myEl.setMyTree(pt);
						}
					}
					else
					{
						PatternTree pt = new PatternTree(HelpFunctions.treeID++);
						pt.setRoot(myEl3.getMyNode());
						this.patternTrees.Add(pt);

						// create a mapping for the variable in terms of PIDWID
						// The tree is actually a path, traverse it down to get the wid
						int wid = -1;
						if (myEl3.getMyNode().GetType().Name == "MLCAPatternTreeNode")
						{
							PatternTree pt1 = ((MLCAPatternTreeNode)(myEl3.getMyNode())).getPatternTree();
							//this.patternTrees.Add(pt1);
							wid = pt1.getRoot().getId();
						}
						else wid = ((PatternTreeNode)(myEl3.getMyNode())).findWIDAtEndOfPath();
						string docName = HelpFunctions.findDocumentName((PatternTreeNode)(myEl3.getMyNode()), this.variableListCurrent);
						VariableMapping vm = new VariableMapping(myEl1.getMyName(), pt.getId(), wid, -1, docName, (int)(values.forBinding), (int)(values.noValue));
						if (!this.checkIfVariableNameExists(vm.getName())) this.variableListCurrent.Add(vm);
						else 
						{
							HelpFunctions.errorString += "Variable name used more then once in the query! " + vm.getName() + "\n";
							HelpFunctions.success = false;
							return true;
						}

						myEl.setMyNode(myEl3.getMyNode());
						myEl.setMyTree(pt);
					}

					reduction.Tag = myEl;
					internalString += ptr + myEl.getMyName() + "\n";
				}
					break;

					// RuleLetvarDollarColoneq = 133, // <LetVar> ::= '$' <QName> ':=' <ExprSingle>
				case (int)RuleConstants.RuleLetvarDollarColoneq:
				{
					myStackElement myEl1 = this.getMyStackElementFromProduction(1, reduction);
					myStackElement myEl3 = this.getMyStackElementFromProduction(3, reduction);
					myStackElement myEl = new myStackElement();
					myEl.setMyName("$" + myEl1.getMyName() + " := " + myEl3.getMyName());

					if (myEl3.getMyNode().GetType().Name == "FLWORNode")
					{
						FLWORNode flop = (FLWORNode)(myEl3.getMyNode());
						PatternTree pt = null;
						int oid = -1;
						for(int i=0;i<flop.getChildren().Count;i++)
						{
							if (flop.getChildren()[i].GetType().Name == "ReturnNode")
							{
								ReturnNode rn = (ReturnNode)(flop.getChildren()[i]);
								pt = rn.getPatternTree();
								oid = rn.getId();
								break;
							}
						}
						if (pt!=null)
						{
							PatternTreeNode ptroot = (PatternTreeNode)(pt.getRoot());
							int wid = ptroot.getId();
							string docName = HelpFunctions.findDocumentName(ptroot, this.variableListCurrent);
							VariableMapping vm = new VariableMapping(myEl1.getMyName(), pt.getId(), wid, oid, docName, (int)(values.letBinding), (int)(values.nestedQuery));
							if (!this.checkIfVariableNameExists(vm.getName())) this.variableListCurrent.Add(vm);
							else 
							{
								HelpFunctions.errorString += "Variable name used more then once in the query! " + vm.getName() + "\n";
								HelpFunctions.success = false;
								return true;
							}

							myEl.setMyNode(ptroot);
							myEl.setMyTree(pt);
						}
					}
					else
					{

						PatternTree pt = new PatternTree(HelpFunctions.treeID++);
						pt.setRoot(myEl3.getMyNode());
						this.patternTrees.Add(pt);

						// create a mapping for the variable in terms of PIDWID
						// The tree is actually a path, traverse it down to get the wid
						int wid = -1;
						if (myEl3.getMyNode().GetType().Name == "MLCAPatternTreeNode")
						{
							PatternTree pt1 = ((MLCAPatternTreeNode)(myEl3.getMyNode())).getPatternTree();
							//this.patternTrees.Add(pt1);
							wid = pt1.getRoot().getId();
						}
						else wid = ((PatternTreeNode)(myEl3.getMyNode())).findWIDAtEndOfPath();
						string docName = HelpFunctions.findDocumentName((PatternTreeNode)(myEl3.getMyNode()), this.variableListCurrent);
						VariableMapping vm = new VariableMapping(myEl1.getMyName(), pt.getId(), wid, -1, docName, (int)(values.letBinding), (int)(values.noValue));
						if (!this.checkIfVariableNameExists(vm.getName())) this.variableListCurrent.Add(vm);
						else 
						{
							HelpFunctions.errorString += "Variable name used more then once in the query! " + vm.getName() + "\n";
							HelpFunctions.success = false;
							return true;
						}

						myEl.setMyNode(myEl3.getMyNode());
						myEl.setMyTree(pt);
					}

					reduction.Tag = myEl;
					internalString += ptr + myEl.getMyName() + "\n";
				}
					break;

					// RuleFlworexprReturn = 50 , // <FLWORExpr> ::= <FORLETPlus> <WhereClause> <OrderByClause> RETURN <ExprSingle>
				case (int)RuleConstants.RuleFlworexprReturn:
				{
					myStackElement myEl;
					this.generateFLWORStmtFromReduction(0, 1, 2, 4, reduction, out myEl);
					reduction.Tag = myEl;
					internalString += ptr + myEl.getMyName() + "\n";
				}
					break;

					// RuleFlworexprReturn2 = 51 , // <FLWORExpr> ::= <FORLETPlus> <WhereClause> RETURN <ExprSingle>
				case (int)RuleConstants.RuleFlworexprReturn2:
				{
					myStackElement myEl;
					this.generateFLWORStmtFromReduction(0, 1, -1, 3, reduction, out myEl);
					reduction.Tag = myEl;
					internalString += ptr + myEl.getMyName() + "\n";
				}
					break;

					// RuleFlworexprReturn3 = 52 , // <FLWORExpr> ::= <FORLETPlus> <OrderByClause> RETURN <ExprSingle>
				case (int)RuleConstants.RuleFlworexprReturn3:
				{
					myStackElement myEl;
					this.generateFLWORStmtFromReduction(0, -1, 1, 3, reduction, out myEl);
					reduction.Tag = myEl;
					internalString += ptr + myEl.getMyName() + "\n";
				}
					break;

					//RuleFlworexprReturn4 = 53 , // <FLWORExpr> ::= <FORLETPlus> RETURN <ExprSingle>
				case (int)RuleConstants.RuleFlworexprReturn4:
				{
					myStackElement myEl;
					this.generateFLWORStmtFromReduction(0, -1, -1, 2, reduction, out myEl);
					reduction.Tag = myEl;
					internalString += ptr + myEl.getMyName() + "\n";
				}
					break;

					//RuleForletplus = 54 , // <FORLETPlus> ::= <FORLET> <FORLETPlus>
				case (int)RuleConstants.RuleForletplus:
				{
					myStackElement myEl0 = this.getMyStackElementFromProduction(0, reduction);
					myStackElement myEl1 = this.getMyStackElementFromProduction(1, reduction);
					myStackElement myEl = new myStackElement();
					myEl.setMyName(myEl0.getMyName() + "\n" + myEl1.getMyName());

					// check if node exists
					FLNode ptn0 = this.getFLNodeFromMyStackElement(myEl0);
					FLNode ptn1 = this.getFLNodeFromMyStackElement(myEl1);

					// create path
					ptn1.setParent(ptn0);
					ptn0.addChild(ptn1);

					myEl.setMyNode(ptn0);

					reduction.Tag = myEl;
					internalString += ptr + myEl.getMyName() + "\n";
				}
					break;

					// RuleComparisonexpr2 = 79 , // <ComparisonExpr> ::= <RangeExpr> <ComparisonKind> <RangeExpr>
				case (int)RuleConstants.RuleComparisonexpr2:
				{
					myStackElement myEl0 = this.getMyStackElementFromProduction(0, reduction);
					myStackElement myEl1 = this.getMyStackElementFromProduction(1, reduction);
					myStackElement myEl2 = this.getMyStackElementFromProduction(2, reduction);
					myStackElement myEl = new myStackElement();

					// get the operator
					string opVal = myEl1.getMyName();

					myEl.setMyName(myEl0.getMyName() + " " + opVal + " " + myEl2.getMyName());

					// this is either a join or a comparison
					// the first expression is definetely a node, else catch fire and halt
					if (myEl0.getMyNode() == null) 
					{
						HelpFunctions.errorString += "The first part of a comparison must be a path!";
						HelpFunctions.success = false;
						return true;
					}
					else
					{
						PatternTreeNode node0 = (PatternTreeNode)(myEl0.getMyNode());

						if (myEl2.getMyNode() == null)
						{
							// comparison
							string compVal = myEl2.getMyName();
							if (node0.getSpecial() != (int)(values.specialAggregateNode))
								HelpFunctions.addComparison(node0, opVal, compVal);
							else
							{
								// aggregate function
								node0.setComparisonType(opVal);
								node0.setComparisonValue(compVal);
							}
							myEl.setMyNode(node0);
						}
						else 
						{
							// join
							PatternTreeNode node2 = (PatternTreeNode)(myEl2.getMyNode());
							int wid1 = node0.findWIDAtEndOfPath();
							int wid2 = node2.findWIDAtEndOfPath();
							JoinDualPatternTreeNode jnode = new JoinDualPatternTreeNode(
								HelpFunctions.nodeID++, "JOIN", (int)(values.join), node0, node2, wid1, opVal, wid2);
							myEl.setMyNode(jnode);
						}
					}

					reduction.Tag = myEl;
					internalString += ptr + myEl.getMyName() + "\n";
				}
					break;

					// RuleWhereclauseWhere = 135, // <WhereClause> ::= WHERE <ExprSingle>
				case (int)RuleConstants.RuleWhereclauseWhere:
				{
					myStackElement myEl1 = this.getMyStackElementFromProduction(1, reduction);
					myStackElement myEl = new myStackElement();
					myEl.setMyName("\nWHERE " + myEl1.getMyName());

					// check if node exists
					WhereNode ptn1 = this.getWhereNodeFromMyStackElement(myEl1);

					myEl.setMyNode(ptn1);

					reduction.Tag = myEl;
					internalString += ptr + myEl.getMyName() + "\n";
				}
					break;

					// RuleAndexprAnd = 49 , // <AndExpr> ::= <InstanceofExpr> AND <AndExpr>
				case (int)RuleConstants.RuleAndexprAnd:
				{
					myStackElement myEl0 = this.getMyStackElementFromProduction(0, reduction);
					myStackElement myEl2 = this.getMyStackElementFromProduction(2, reduction);
					myStackElement myEl = new myStackElement();
					myEl.setMyName(myEl0.getMyName() + " AND " + myEl2.getMyName());

					DualPatternTreeNode andNode = new DualPatternTreeNode(
						HelpFunctions.nodeID++, "AND", (int)(values.specialAndNode), myEl0.getMyNode(), myEl2.getMyNode());

					myEl.setMyNode(andNode);

					reduction.Tag = myEl;
					internalString += ptr + myEl.getMyName() + "\n";
				}
					break;

					// RuleOrexprOr = 47 , // <OrExpr> ::= <AndExpr> OR <OrExpr>
				case (int)RuleConstants.RuleOrexprOr:
				{
					myStackElement myEl0 = this.getMyStackElementFromProduction(0, reduction);
					myStackElement myEl2 = this.getMyStackElementFromProduction(2, reduction);
					myStackElement myEl = new myStackElement();
					myEl.setMyName(myEl0.getMyName() + " OR " + myEl2.getMyName());

					OrPatternTreeNode ornode = new OrPatternTreeNode(0, "OR");
					//<ORExp> ::= <orin> "or" <orin> ("or" <orin>)*
					//<orin> ::= (<SimplePredicateExpr> | <AggrPredExpr> | <EveryExpr> | <SomeExpr>)
					PatternTreeNode n0 = (PatternTreeNode)(myEl0.getMyNode());

					if (n0.GetType().Name == "OrPatternTreeNode")
						ornode.addNodeRange(((OrPatternTreeNode)(n0)).getNodes());
					else if((n0.GetType().Name == "AggregatePatternTreeNode")||(n0.GetType().Name == "QuantifiedPatternTreeNode")||(n0.getTagName().StartsWith("$")))
					{
						HelpFunctions.setStructuralJoin(n0, (int)(values.structuralJoinZeroOne));
						ornode.addNode(n0);
					}
					else
					{
						internalString += "The first input to OR is not a simple predicate, aggregate or quantified expression! \n";
						HelpFunctions.errorString += "The first path to OR is not a simple predicate, aggregate or quantified expression! found: " + myEl0.getMyName() + "\n";
						HelpFunctions.success = false;
					}

					if (HelpFunctions.success)
					{
						PatternTreeNode n2 = (PatternTreeNode)(myEl2.getMyNode());
						if (n2.GetType().Name == "OrPatternTreeNode")
							ornode.addNodeRange(((OrPatternTreeNode)(n2)).getNodes());
						else if((n2.GetType().Name == "AggregatePatternTreeNode")||(n2.GetType().Name == "QuantifiedPatternTreeNode")||(n2.getTagName().StartsWith("$")))
						{
							HelpFunctions.setStructuralJoin(n2, (int)(values.structuralJoinZeroOne));
							ornode.addNode(n2);
						}
						else
						{
							internalString += "The second input to OR is not a simple predicate, aggregate or quantified expression! \n";
							HelpFunctions.errorString += "The first path to OR is not a simple predicate, aggregate or quantified expression! found: " + myEl2.getMyName() + "\n";
							HelpFunctions.success = false;
						}
						if (HelpFunctions.success)
							myEl.setMyNode(ornode);
					}
					reduction.Tag = myEl;
					internalString += ptr + myEl.getMyName() + "\n";
				}
					break;

					// RuleAbbreviatedforwardstepAt = 238, // <AbbreviatedForwardStep> ::= '@' <NameTest>
				case (int)RuleConstants.RuleAbbreviatedforwardstepAt:
				{
					//					internalString += "Attributes are currently disabled!";
					//					errorString += "Attributes are currently disabled!";
					//					success = false;
					//					return true;
					myStackElement myEl1 = this.getMyStackElementFromProduction(1, reduction);
					myStackElement myEl = new myStackElement();
					myEl.setMyName("@" + myEl1.getMyName());

					reduction.Tag = myEl;
					internalString += ptr + myEl.getMyName() + "\n";
				}
					break;

					//	RuleExprComma = 38 , // <Expr> ::= <ExprSingle> ',' <Expr>
				case (int)RuleConstants.RuleExprComma:
				{
					myStackElement myEl0 = this.getMyStackElementFromProduction(0, reduction);
					myStackElement myEl2 = this.getMyStackElementFromProduction(2, reduction);
					myStackElement myEl = new myStackElement();
					if (myEl0.getMyList().Count == 0) 
					{
						if (myEl0.getMyNode() == null) 
						{
							PatternTreeNode ptn = new PatternTreeNode(0);
							ptn.setTagName(myEl0.getMyName());
							myEl0.addToMyList(ptn);
						}
						else myEl0.addToMyList(myEl0.getMyNode());
					}
					myEl.addRangeToMyList(myEl0.getMyList());
					if (myEl2.getMyList().Count == 0) 
					{
						if (myEl2.getMyNode() == null) 
						{
							PatternTreeNode ptn = new PatternTreeNode(0);
							ptn.setTagName(myEl2.getMyName());
							myEl2.addToMyList(ptn);
						}
						else myEl2.addToMyList(myEl2.getMyNode());
					}
					myEl.addRangeToMyList(myEl2.getMyList());

					myEl.setMyName(myEl0.getMyName() + ", " + myEl2.getMyName());

					reduction.Tag = myEl;
					internalString += ptr + myEl.getMyName() + "\n";
				}
					break;

					// RuleEnclosedexprLbraceRbrace = 307, // <EnclosedExpr> ::= '{' <Expr> '}'
				case (int)RuleConstants.RuleEnclosedexprLbraceRbrace:
				{
					myStackElement myEl = this.getMyStackElementFromProduction(1, reduction);
					myEl.setMyName("{" + myEl.getMyName() + "}");

					reduction.Tag = myEl;
					internalString += ptr + myEl.getMyName() + "\n";
				}
					break;



					// RuleElementconstructorLtDivgt = 268, // <ElementConstructor> ::= '<' <QName> <AttributeList> '/>'
				case (int)RuleConstants.RuleElementconstructorLtDivgt:
				{
					myStackElement myEl;
					if (this.generateElementConstructorFromReduction(1, 1, -1, 2, reduction, out myEl))
					{
						internalString += "Opening and closing tag names don't match! (" + (int)(rule.TableIndex) + "): " + ptr + "\n";
						HelpFunctions.errorString += "Opening and closing tag names don't match! (" + (int)(rule.TableIndex) + "): " + ptr + "\n";
						HelpFunctions.success = false;
						return true;
					}
					reduction.Tag = myEl;
					internalString += ptr + myEl.getMyName() + "\n";
				}
					break;
		
					// RuleElementconstructorLtDivgt2 = 269, // <ElementConstructor> ::= '<' <QName> '/>'
				case (int)RuleConstants.RuleElementconstructorLtDivgt2:
				{
					myStackElement myEl;
					if (this.generateElementConstructorFromReduction(1, 1, -1, -1, reduction, out myEl))
					{
						internalString += "Opening and closing tag names don't match! (" + (int)(rule.TableIndex) + "): " + ptr + "\n";
						HelpFunctions.errorString += "Opening and closing tag names don't match! (" + (int)(rule.TableIndex) + "): " + ptr + "\n";
						HelpFunctions.success = false;
						return true;
					}
					reduction.Tag = myEl;
					internalString += ptr + myEl.getMyName() + "\n";
				}
					break;

					// RuleElementconstructorLtGtLtdivGt = 270, // <ElementConstructor> ::= '<' <QName> <AttributeList> '>' '</' <QName> '>'
				case (int)RuleConstants.RuleElementconstructorLtGtLtdivGt:
				{
					myStackElement myEl;
					if (this.generateElementConstructorFromReduction(1, 5, -1, 2, reduction, out myEl))
					{
						internalString += "Opening and closing tag names don't match! (" + (int)(rule.TableIndex) + "): " + ptr + "\n";
						HelpFunctions.errorString += "Opening and closing tag names don't match! (" + (int)(rule.TableIndex) + "): " + ptr + "\n";
						HelpFunctions.success = false;
						return true;
					}
					reduction.Tag = myEl;
					internalString += ptr + myEl.getMyName() + "\n";
				}
					break;

					// RuleElementconstructorLtGtLtdivGt2 = 271, // <ElementConstructor> ::= '<' <QName> '>' '</' <QName> '>'
				case (int)RuleConstants.RuleElementconstructorLtGtLtdivGt2:
				{
					myStackElement myEl;
					if (this.generateElementConstructorFromReduction(1, 4, -1, -1, reduction, out myEl))
					{
						internalString += "Opening and closing tag names don't match! (" + (int)(rule.TableIndex) + "): " + ptr + "\n";
						HelpFunctions.errorString += "Opening and closing tag names don't match! (" + (int)(rule.TableIndex) + "): " + ptr + "\n";
						HelpFunctions.success = false;
						return true;
					}
					reduction.Tag = myEl;
					internalString += ptr + myEl.getMyName() + "\n";
				}
					break;

					// RuleElementconstructorLtGtLtdivGt3 = 272, // <ElementConstructor> ::= '<' <QName> <AttributeList> '>' <ElementContentPlus> '</' <QName> '>'
				case (int)RuleConstants.RuleElementconstructorLtGtLtdivGt3:
				{
					myStackElement myEl;
					if (this.generateElementConstructorFromReduction(1, 6, 4, 2, reduction, out myEl))
					{
						internalString += "Opening and closing tag names don't match! (" + (int)(rule.TableIndex) + "): " + ptr + "\n";
						HelpFunctions.errorString += "Opening and closing tag names don't match! (" + (int)(rule.TableIndex) + "): " + ptr + "\n";
						HelpFunctions.success = false;
						return true;
					}
					reduction.Tag = myEl;
					internalString += ptr + myEl.getMyName() + "\n";
				}
					break;


					// RuleElementconstructorLtGtLtdivGt4 = 273, // <ElementConstructor> ::= '<' <QName> '>' <ElementContentPlus> '</' <QName> '>'
				case (int)RuleConstants.RuleElementconstructorLtGtLtdivGt4:
				{
					myStackElement myEl;
					if (this.generateElementConstructorFromReduction(1, 5, 3, -1, reduction, out myEl))
					{
						internalString += "Opening and closing tag names don't match! (" + (int)(rule.TableIndex) + "): " + ptr + "\n";
						HelpFunctions.errorString += "Opening and closing tag names don't match! (" + (int)(rule.TableIndex) + "): " + ptr + "\n";
						HelpFunctions.success = false;
						return true;
					}
					reduction.Tag = myEl;
					internalString += ptr + myEl.getMyName() + "\n";
				}
					break;




					// RuleElementcontentplus2 = 275, // <ElementContentPlus> ::= <ElementContent> <ElementContentPlus>
				case (int)RuleConstants.RuleElementcontentplus2:
				{
					myStackElement myEl0 = this.getMyStackElementFromProduction(0, reduction);
					myStackElement myEl1 = this.getMyStackElementFromProduction(1, reduction);
					myStackElement myEl = new myStackElement();
					myEl.addToMyList(myEl0.getMyNode());
					if (myEl1.getMyList().Count == 0) myEl1.addToMyList(myEl1.getMyNode());
					myEl.addRangeToMyList(myEl1.getMyList());

					myEl.setMyName(myEl0.getMyName() + " " + myEl1.getMyName());

					reduction.Tag = myEl;
					internalString += ptr + myEl.getMyName() + "\n";
				}
					break;

					// RuleAttributelistEq = 297, // <AttributeList> ::= <QName> '=' <AttributeValue>
				case (int)RuleConstants.RuleAttributelistEq:
				{
					myStackElement myEl0 = this.getMyStackElementFromProduction(0, reduction);
					myStackElement myEl2 = this.getMyStackElementFromProduction(2, reduction);

					ConstructAttributePatternTreeNode ca = new ConstructAttributePatternTreeNode(HelpFunctions.lcl++);
					ca.setAttributeTagName(myEl0.getMyName());
					ca.setMyNode((PatternTreeNode)(myEl2.getMyNode()));
					myStackElement myEl = new myStackElement();
					myEl.setMyName(myEl0.getMyName() + "=" + myEl2.getMyName());
					myEl.setMyNode(ca);
					myEl.addToMyList(ca);

					reduction.Tag = myEl;
					internalString += ptr + myEl.getMyName() + "\n";
				}
					break;

					// RuleAttributelistEq2 = 298, // <AttributeList> ::= <QName> '=' <AttributeValue> <AttributeList>
				case (int)RuleConstants.RuleAttributelistEq2:
				{
					myStackElement myEl0 = this.getMyStackElementFromProduction(0, reduction);
					myStackElement myEl2 = this.getMyStackElementFromProduction(2, reduction);// for the second part of AttributeValue
					myStackElement myEl3 = this.getMyStackElementFromProduction(3, reduction);

					ConstructAttributePatternTreeNode ca = new ConstructAttributePatternTreeNode(HelpFunctions.lcl++);
					ca.setAttributeTagName(myEl0.getMyName());
					ca.setMyNode((PatternTreeNode)(myEl2.getMyNode()));
					myStackElement myEl = new myStackElement();
					myEl.setMyName(myEl0.getMyName() + "=" + myEl2.getMyName());
					myEl.setMyNode(ca);
					myEl.addToMyList(ca);
					
					if (myEl3.getMyList().Count == 0) 
					{
						if (myEl3.getMyNode() == null) 
						{
							PatternTreeNode ptn = new PatternTreeNode(0);
							ptn.setTagName(myEl3.getMyName());
							myEl3.addToMyList(ptn);
						}
						else myEl3.addToMyList(myEl3.getMyNode());
					}
					myEl.addRangeToMyList(myEl3.getMyList());

					myEl.setMyName(myEl.getMyName() + " " + myEl3.getMyName());

					reduction.Tag = myEl;
					internalString += ptr + myEl.getMyName() + "\n";
				}
					break;



				///////////////////////////////////////////////// default
				default:
				{
					// do default
					internalString += "Production Not Supported!(" + (int)(rule.TableIndex) + "): " + ptr + "\n";
					HelpFunctions.errorString += "Production Not Supported!(" + (int)(rule.TableIndex) + "): " + ptr + "\n";
					HelpFunctions.success = false;
					return true;

				}
					//break;
			}
			if (!HelpFunctions.success) return true;
			return false;

		}
	
		internal void Execute()
		{
			bool done = false, fatal = false;
			int errors = 0, errorLine = -1;
		
			m_parser.TrimReductions = true;
		
			while (!done && !fatal)
			{								
				ParseMessage result = m_parser.Parse();
							
				switch (result)
				{
					case ParseMessage.TokenRead:
						// do nothing
						break;
					case ParseMessage.Reduction:
						// do nothing
						fatal = doReduction(m_parser.CurrentReduction);
						break;
					case ParseMessage.Accept:
						// program accepted
						done = true;
						break;
					case ParseMessage.LexicalError:
						HelpFunctions.errorString += "LexicalError\n";
						HelpFunctions.success = false;
						fatal = true;
						break;
					case ParseMessage.SyntaxError:
						if (errorLine == (errorLine = m_parser.CurrentLineNumber))
							fatal = true;	// stop if there are multiple errors on one line
						else
						{
							HelpFunctions.success = false;
							errors++;
							HandleSyntaxError();					
						}
						break;
					case ParseMessage.CommentError:
						HelpFunctions.errorString += "CommentError\n";
						HelpFunctions.success = false;
						fatal = true;
						break;
					case ParseMessage.InternalError:
						HelpFunctions.errorString += "Internal error - this is really bad\n";
						HelpFunctions.success = false;
						fatal = true;
						break;
				}
			
				errors = (fatal ? errors + 1 : errors);
				fatal = fatal || (errors > 7);
			}
		
			if (fatal || errors > 0)
				HelpFunctions.errorString += errors + " error(s)\n";
			else
			{
				DumpVisitor visitor = new DumpVisitor();
				m_parser.CurrentReduction.Accept(visitor);
				parseString += visitor.GetResult();
			}
		}
	
		private void HandleSyntaxError()
		{
			int line = m_parser.CurrentLineNumber;
			TokenStack expected = m_parser.GetTokens();

			HelpFunctions.errorString += "Syntax error, line(" + line + ")\n";
			HelpFunctions.errorString += "  found:    " + m_parser.CurrentToken.Data + "\n";
			HelpFunctions.errorString += "  expected: \n";
		
			foreach (Token token in expected)
				HelpFunctions.errorString += token + " \n";
			
			HelpFunctions.errorString += "\n\n";
			m_parser.PushInputToken(expected[0]);
		}	

	}

	
}