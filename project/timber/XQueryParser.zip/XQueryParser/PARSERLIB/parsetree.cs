namespace Timber.XQueryParser
{
	/// <summary>
	/// Used for parse tree nodes
	/// </summary>
	internal class ParseTreeNode : Node
	{
		internal ParseTreeNode():base()
		{
		}
	}


	/// <summary>
	/// Used to generate a customized parse tree
	/// </summary>
	internal class ParseTree : Tree
	{
		internal ParseTree():base()
		{
		}
	}
}