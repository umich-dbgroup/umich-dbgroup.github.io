//COPYRIGHT  � 2000-2004 
//THE REGENTS OF THE UNIVERSITY OF MICHIGAN
//ALL RIGHTS RESERVED
//
//PERMISSION IS GRANTED TO USE, COPY, CREATE DERIVATIVE WORKS AND REDISTRIBUTE 
//THIS SOFTWARE AND SUCH DERIVATIVE WORKS FOR NONCOMMERCIAL EDUCATION AND 
//RESEARCH PURPOSES, SO LONG AS NO FEE IS CHARGED, AND SO LONG AS THE 
//COPYRIGHT NOTICE ABOVE, THIS GRANT OF PERMISSION, AND THE DISCLAIMER 
//BELOW APPEAR IN ALL COPIES MADE; AND SO LONG AS THE NAME OF THE UNIVERSITY 
//OF MICHIGAN IS NOT USED IN ANY ADVERTISING OR PUBLICITY PERTAINING TO THE 
//USE OR DISTRIBUTION OF THIS SOFTWARE WITHOUT SPECIFIC, WRITTEN PRIOR AUTHORIZATION.
//
//THIS SOFTWARE IS PROVIDED AS IS, WITHOUT REPRESENTATION FROM THE UNIVERSITY 
//OF MICHIGAN AS TO ITS FITNESS FOR ANY PURPOSE, AND WITHOUT WARRANTY BY THE 
//UNIVERSITY OF MICHIGAN OF ANY KIND, EITHER EXPRESS OR IMPLIED, INCLUDING 
//WITHOUT LIMITATION THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS 
//FOR A PARTICULAR PURPOSE. THE REGENTS OF THE UNIVERSITY OF MICHIGAN SHALL 
//NOT BE LIABLE FOR ANY DAMAGES, INCLUDING SPECIAL, INDIRECT, INCIDENTAL, 
//OR CONSEQUENTIAL DAMAGES, WITH RESPECT TO ANY CLAIM ARISING OUT OF OR IN 
//CONNECTION WITH THE USE OF THE SOFTWARE, EVEN IF IT HAS BEEN OR IS 
//HEREAFTER ADVISED OF THE POSSIBILITY OF SUCH DAMAGES.

// Author: Stelios Paparizos
// e-mail: spapariz@umich.edu
// Summary: This file contains classes related with the process tree.
// For example FORNode, LETNode etc that is created after the parse tree is processed.
// SelectNode, ProjectNode etc that map directly to logical algebra operators for the final output.

using System;
using System.Collections;

namespace Timber.XQueryParser
{

	/// <summary>
	/// Used for process trees
	/// </summary>
	internal class ProcessTree : Tree
	{
		internal ProcessTree():base(){}
	}

	/// <summary>
	/// Used for process tree nodes
	/// </summary>
	internal class ProcessTreeNode : Node
	{
		internal ProcessTreeNode():base(){}
		internal ProcessTreeNode(int id):base(id){}

		internal virtual int getRootLCL()
		{
			if (this.getChildren().Count == 0) return -1;
			else return ((ProcessTreeNode)(this.getChildren()[0])).getRootLCL();
		}

		internal override string ToStringOut(int level) 
		{
			string s = base.ToStringOut(level);
			//System.Type typ = this.GetType();
			//s += typ.Name;
			s += this.GetType().ToString();
			s += "\t";
			return s;
		}


		/// <summary>
		/// Creates the Logical Algebra plan for a given operator.
		/// </summary>
		/// <param name="patternTreeNodeCountIn">The number of pattern tree nodes in the plan</param>
		/// <param name="patternTreeNodeCountOut">The number of pattern tree nodes in the plan</param>
		/// <param name="patternTreeCountIn">The number of trees in the plan</param>
		/// <param name="patternTreeCountOut">The number of trees in the plan</param>
		/// <param name="processTreeNodeCountIn">The number of process tree nodes in the plan</param>
		/// <param name="processTreeNodeCountOut">The number of process tree nodes in the plan</param>
		/// <param name="patternTreeNodesIn">The string containing information for the pattern tree nodes in the plan</param>
		/// <param name="patternTreeNodesOut">The string containing information for the pattern tree nodes in the plan</param>
		/// <param name="patternTreesIn">The string containing information for the trees in the plan</param>
		/// <param name="patternTreesOut">The string containing information for the trees in the plan</param>
		/// <param name="processTreeNodesIn">The string containing information for the process tree nodes in the plan</param>
		/// <param name="processTreeNodesOut">The string containing information for the process tree nodes in the plan</param>
		/// <param name="processTreeIn">The process tree with the algebraic operators for the plan</param>
		/// <param name="processTreeOut">The process tree with the algebraic operators for the plan</param>
		/// <param name="variableListCurrent">The table containing the variable information and they nodes they point to</param>
		internal virtual void getLogicalPlan(
			int patternTreeNodeCountIn, out int patternTreeNodeCountOut,
			int patternTreeCountIn, out int patternTreeCountOut,
			int processTreeNodeCountIn, out int processTreeNodeCountOut,
			string patternTreeNodesIn, out string patternTreeNodesOut,
			string patternTreesIn, out string patternTreesOut,
			string processTreeNodesIn, out string processTreeNodesOut,
			string processTreeIn, out string processTreeOut,
			ArrayList variableListCurrent) 
		{
			patternTreeNodeCountOut = patternTreeNodeCountIn;
			patternTreeCountOut = patternTreeCountIn;
			processTreeNodeCountOut = processTreeNodeCountIn;
			patternTreeNodesOut = patternTreeNodesIn;
			patternTreesOut = patternTreesIn;
			processTreeNodesOut = processTreeNodesIn;
			processTreeOut = processTreeIn;

			ArrayList myChildren = this.getChildren();
			for(int i = 0; i < myChildren.Count; i++)
			{
				ProcessTreeNode pnode = (ProcessTreeNode)(myChildren[i]);
				pnode.getLogicalPlan(
					patternTreeNodeCountOut, out patternTreeNodeCountOut,
					patternTreeCountOut, out patternTreeCountOut,
					processTreeNodeCountOut, out processTreeNodeCountOut,
					patternTreeNodesOut, out patternTreeNodesOut,
					patternTreesOut, out patternTreesOut,
					processTreeNodesOut, out processTreeNodesOut,
					processTreeOut, out processTreeOut,
					variableListCurrent);

			}
		}
	}//process tree node class



	/// <summary>
	/// A FLW node. Contains a pattern tree. 
	/// It is a associated with a FOR, LET or WHERE binding.
	/// </summary>
	internal class FLWORNode : ProcessTreeNode
	{
		private PatternTree patternTree;	// the associated pattern tree
		
		internal FLWORNode():base()	{}
		internal FLWORNode(int id):base(id)	{}

		internal override int getRootLCL() 
		{
			if (this.patternTree!=null) return this.patternTree.getRoot().getId();
			if (this.getChildren().Count == 0) return -1;
			else return ((FLWORNode)(this.getChildren()[0])).getRootLCL();
		}

		internal virtual int surviveProjection(int wid, bool isNode, bool isOuter) 
		{
			if (this.getChildren().Count == 0) return -1;
			int outval = -1, tmpval = -1;
			for(int i=0; i<this.getChildren().Count; i++)
			{
				tmpval = ((FLWORNode)(this.getChildren()[i])).surviveProjection(wid, isNode, isOuter);
				if (tmpval != -1) outval = tmpval;
			}
			return outval;
		}

		internal PatternTree getPatternTree() {return patternTree;}
		internal void setPatternTree(PatternTree ptin) {patternTree = ptin;}

		internal override string ToStringOut(int level) 
		{
			string s = base.ToStringOut(level);
			if (this.patternTree == null)
			{
				s += "FLWORStmt\n\n";
				return s;
			}
			s += "\n";
			if (this.patternTree != null)
			{
				s += this.patternTree.ToStringOut();
				s += "\n";
			}
			return s;
		}
	}//FLWORNode


	internal class FLNode : FLWORNode
	{
		internal FLNode():base(){}
		internal FLNode(int id):base(id){}

		private int nodeSubType; //create from for, let, where
		internal int getNodeSubType() {return nodeSubType;}
		internal void setNodeSubType(int nodeSubType) {this.nodeSubType = nodeSubType;}

		internal override string ToStringOut(int level) 
		{
			string s = "";
			if (this.nodeSubType == (int)(values.forSubType))
				s = "FORclauses\n";
			else if (this.nodeSubType == (int)(values.letSubType))
				s = "LETclauses\n";
			s += base.ToStringOut(level);
			return s;
		}
	}//FLNode Class

	internal class WhereNode : FLWORNode
	{
		internal WhereNode():base(){}
		internal WhereNode(int id):base(id){}

		internal override string ToStringOut(int level) 
		{
			string s = base.ToStringOut(level);
			return s;
		}
	}//whereNode class

	internal class OrderByNode : FLWORNode
	{
		internal OrderByNode():base(){this.sortList = new ArrayList();}
		internal OrderByNode(int id):base(id){this.sortList = new ArrayList();}

		private ArrayList sortList;
		internal void addToSortList(PatternTreeNode s1){this.sortList.Add(s1);}
		internal ArrayList getSortList(){return this.sortList;}

		internal override string ToStringOut(int level) 
		{
			string s = base.ToStringOut(level);
			return s;
		}

	}//OrderByNode

	internal class ReturnNode : FLWORNode
	{
		internal ReturnNode():base(){}
		internal ReturnNode(int id):base(id){}

		internal override string ToStringOut(int level) 
		{
			string s = base.ToStringOut(level);
			return s;
		}
	}






	internal class SelectNode : FLWORNode
	{
		internal SelectNode():base(){}
		internal SelectNode(int id):base(id){}

		internal override int getRootLCL() 
		{
			return this.getPatternTree().getRoot().getId();
		}

		internal override string ToStringOut(int level) 
		{
			string s = base.ToStringOut(level);
			return s;
		}

		internal override void getLogicalPlan(
			int patternTreeNodeCountIn, out int patternTreeNodeCountOut, int patternTreeCountIn, out int patternTreeCountOut,
			int processTreeNodeCountIn, out int processTreeNodeCountOut,
			string patternTreeNodesIn, out string patternTreeNodesOut, string patternTreesIn, out string patternTreesOut,
			string processTreeNodesIn, out string processTreeNodesOut, string processTreeIn, out string processTreeOut,
			ArrayList variableListCurrent) 
		{
			patternTreeNodeCountOut = patternTreeNodeCountIn; patternTreeCountOut = patternTreeCountIn;
			processTreeNodeCountOut = processTreeNodeCountIn;
			patternTreeNodesOut = patternTreeNodesIn; patternTreesOut = patternTreesIn;
			processTreeNodesOut = processTreeNodesIn; processTreeOut = processTreeIn;

			int nodeCount = 0;
			string nodePattern;
			string treePattern;
			((PatternTreeNode)(this.getPatternTree().getRoot())).getLogicalPlan(
				0, out nodeCount, 
				"", out nodePattern, 
				"", out treePattern, 
				variableListCurrent);

			string[] elements = nodePattern.Split(' ');
			int rootID = int.Parse(elements[0]);
			//0 2 0 PT_NORMAL
			treePattern = this.getPatternTree().getId() + " " + nodeCount + " " + rootID + " PATTERN_TREE\n" + treePattern;
			treePattern = "// pattern tree \n" + treePattern;
			nodePattern = "// list of nodes for pattern tree " + this.getPatternTree().getId() + "\n" + nodePattern;

			patternTreeNodeCountOut = patternTreeNodeCountOut + nodeCount;
			patternTreeCountOut++;
			patternTreeNodesOut += nodePattern;
			patternTreesOut += treePattern;

			//0 SELECTION  0
			processTreeNodesOut += this.getId() + " SELECT " + this.getPatternTree().getId() + "\n";
			if (processTreeNodeCountOut == 0) processTreeOut += this.getId() + " -1\n";
			else processTreeOut += this.getId() + " " + this.getParent().getId() + "\n";

			processTreeNodeCountOut++;
			
			base.getLogicalPlan(
				patternTreeNodeCountOut, out patternTreeNodeCountOut, patternTreeCountOut, out patternTreeCountOut,
				processTreeNodeCountOut, out processTreeNodeCountOut, 
				patternTreeNodesOut, out patternTreeNodesOut, patternTreesOut, out patternTreesOut, 
				processTreeNodesOut, out processTreeNodesOut, processTreeOut, out processTreeOut,
				variableListCurrent);
		}
	}// select node class


	internal class MLCANode : FLWORNode
	{
		private ArrayList mlcaList;

		internal MLCANode():base(){this.mlcaList = new ArrayList();}
		internal MLCANode(int id):base(id){this.mlcaList = new ArrayList();}

		internal override int getRootLCL() 
		{
			return this.getPatternTree().getRoot().getId();
		}

		internal override string ToStringOut(int level) 
		{
			string s = base.ToStringOut(level);
			return s;
		}

		internal void setMLCAList(ArrayList newval){this.mlcaList = newval;}
		internal void addToMLCAList(int wid){this.mlcaList.Add(wid);}
		internal ArrayList getMLCAList(){return this.mlcaList;}

		internal override void getLogicalPlan(
			int patternTreeNodeCountIn, out int patternTreeNodeCountOut, int patternTreeCountIn, out int patternTreeCountOut,
			int processTreeNodeCountIn, out int processTreeNodeCountOut,
			string patternTreeNodesIn, out string patternTreeNodesOut, string patternTreesIn, out string patternTreesOut,
			string processTreeNodesIn, out string processTreeNodesOut, string processTreeIn, out string processTreeOut,
			ArrayList variableListCurrent) 
		{
			patternTreeNodeCountOut = patternTreeNodeCountIn; patternTreeCountOut = patternTreeCountIn;
			processTreeNodeCountOut = processTreeNodeCountIn;
			patternTreeNodesOut = patternTreeNodesIn; patternTreesOut = patternTreesIn;
			processTreeNodesOut = processTreeNodesIn; processTreeOut = processTreeIn;

			int nodeCount = 0;
			string nodePattern;
			string treePattern;
			((PatternTreeNode)(this.getPatternTree().getRoot())).getLogicalPlan(
				0, out nodeCount, 
				"", out nodePattern, 
				"", out treePattern, 
				variableListCurrent);

			string[] elements = nodePattern.Split(' ');
			int rootID = int.Parse(elements[0]);
			treePattern = this.getPatternTree().getId() + " " + nodeCount + " " + rootID + " MLCA_TREE\n" + treePattern;
			treePattern = "// pattern tree \n" + treePattern;
			nodePattern = "// list of nodes for pattern tree " + this.getPatternTree().getId() + "\n" + nodePattern;

			patternTreeNodeCountOut = patternTreeNodeCountOut + nodeCount;
			patternTreeCountOut++;
			patternTreeNodesOut += nodePattern;
			patternTreesOut += treePattern;


			//<mlca node> := <node id> MLCA <pattern tree id> <number of nodes for mlca> <mlca list using LCLs> 
			processTreeNodesOut += this.getId() + " MLCA " + this.getPatternTree().getId();
			processTreeNodesOut += " " + this.mlcaList.Count.ToString();
			for(int i=0; i<this.mlcaList.Count;i++)
				processTreeNodesOut += " " + ((int)(this.mlcaList[i])).ToString();
			processTreeNodesOut += "\n";
			if (processTreeNodeCountOut == 0) processTreeOut += this.getId() + " -1\n";
			else processTreeOut += this.getId() + " " + this.getParent().getId() + "\n";

			processTreeNodeCountOut++;
			
			base.getLogicalPlan(
				patternTreeNodeCountOut, out patternTreeNodeCountOut, patternTreeCountOut, out patternTreeCountOut,
				processTreeNodeCountOut, out processTreeNodeCountOut, 
				patternTreeNodesOut, out patternTreeNodesOut, patternTreesOut, out patternTreesOut, 
				processTreeNodesOut, out processTreeNodesOut, processTreeOut, out processTreeOut,
				variableListCurrent);
		}

	}// MLCA node class


	internal class JoinNode : FLWORNode
	{
		internal int subType; // for cartesian product

		internal JoinNode():base(){this.subType = (int)(values.join);}
		internal JoinNode(int id):base(id){this.subType = (int)(values.join);}

		internal override string ToStringOut(int level) 
		{
			string s = base.ToStringOut(level);
			return s;
		}

		internal override int surviveProjection(int wid, bool isNode, bool isOuter) 
		{
			// stop the survive projection, else it would propagate to nested subqueries
			return -1;
		}


		internal override void getLogicalPlan(
			int patternTreeNodeCountIn, out int patternTreeNodeCountOut, int patternTreeCountIn, out int patternTreeCountOut,
			int processTreeNodeCountIn, out int processTreeNodeCountOut,
			string patternTreeNodesIn, out string patternTreeNodesOut, string patternTreesIn, out string patternTreesOut,
			string processTreeNodesIn, out string processTreeNodesOut, string processTreeIn, out string processTreeOut,
			ArrayList variableListCurrent) 
		{
			patternTreeNodeCountOut = patternTreeNodeCountIn; patternTreeCountOut = patternTreeCountIn;
			processTreeNodeCountOut = processTreeNodeCountIn;
			patternTreeNodesOut = patternTreeNodesIn; patternTreesOut = patternTreesIn;
			processTreeNodesOut = processTreeNodesIn; processTreeOut = processTreeIn;

			int nodeCount = 0;
			string nodePattern;
			string treePattern;
			((PatternTreeNode)(this.getPatternTree().getRoot())).getLogicalPlan(
				0, out nodeCount, 
				"", out nodePattern, 
				"", out treePattern, 
				variableListCurrent);

			string[] elements = nodePattern.Split(' ');
			int rootID = int.Parse(elements[0]);
			//0 2 0 PT_NORMAL
			treePattern = this.getPatternTree().getId() + " " + nodeCount + " " + rootID + " PATTERN_TREE\n" + treePattern;
			treePattern = "// pattern tree \n" + treePattern;
			nodePattern = "// list of nodes for pattern tree " + this.getPatternTree().getId() + "\n" + nodePattern;

			patternTreeNodeCountOut = patternTreeNodeCountOut + nodeCount;
			patternTreeCountOut++;
			patternTreeNodesOut += nodePattern;
			patternTreesOut += treePattern;

			//<join node> := <node id> JOIN <pattern tree id> 
			processTreeNodesOut += this.getId() + " JOIN " + this.getPatternTree().getId() + "\n";
			if (processTreeNodeCountOut == 0) processTreeOut += this.getId() + " -1\n";
			else processTreeOut += this.getId() + " " + this.getParent().getId() + "\n";

			processTreeNodeCountOut++;
			
			base.getLogicalPlan(
				patternTreeNodeCountOut, out patternTreeNodeCountOut, patternTreeCountOut, out patternTreeCountOut,
				processTreeNodeCountOut, out processTreeNodeCountOut, 
				patternTreeNodesOut, out patternTreeNodesOut, patternTreesOut, out patternTreesOut, 
				processTreeNodesOut, out processTreeNodesOut, processTreeOut, out processTreeOut,
				variableListCurrent);
		}
	}



	internal class SortNode : FLWORNode
	{
		private ArrayList sortList;

		internal SortNode():base(){this.sortList = new ArrayList();}

		internal SortNode(int id):base(id){this.sortList = new ArrayList();}

		internal void addToSortList(SortObject so1){this.sortList.Add(so1);}
		internal ArrayList getSortList(){return this.sortList;}

		internal override string ToStringOut(int level) 
		{
			string s = base.ToStringOut(level);
			for(int i=0;i<this.sortList.Count;i++)
				s += ((SortObject)(this.sortList[i])).getSortOutput() + "\n";
			s += "\n";

			return s;
		}

		internal override void getLogicalPlan(
			int patternTreeNodeCountIn, out int patternTreeNodeCountOut, int patternTreeCountIn, out int patternTreeCountOut,
			int processTreeNodeCountIn, out int processTreeNodeCountOut,
			string patternTreeNodesIn, out string patternTreeNodesOut, string patternTreesIn, out string patternTreesOut,
			string processTreeNodesIn, out string processTreeNodesOut, string processTreeIn, out string processTreeOut,
			ArrayList variableListCurrent) 
		{
			patternTreeNodeCountOut = patternTreeNodeCountIn; patternTreeCountOut = patternTreeCountIn;
			processTreeNodeCountOut = processTreeNodeCountIn;
			patternTreeNodesOut = patternTreeNodesIn; patternTreesOut = patternTreesIn;
			processTreeNodesOut = processTreeNodesIn; processTreeOut = processTreeIn;

			//<sort node> :=  <node id> SORT <number of nodes to sort>  [<LCL> <KEY | VALUE> <ASCENDING | DESCENDING> <LEAST | GREATEST>]+
			processTreeNodesOut += this.getId() + " SORT " + this.sortList.Count.ToString() + " "; 
			for(int i=0;i<this.sortList.Count;i++)
				processTreeNodesOut += ((SortObject)(this.sortList[i])).getSortOutput() + " ";
			processTreeNodesOut += "\n";

			if (processTreeNodeCountOut == 0) processTreeOut += this.getId() + " -1\n";
			else processTreeOut += this.getId() + " " + this.getParent().getId() + "\n";

			processTreeNodeCountOut++;
			
			base.getLogicalPlan(patternTreeNodeCountOut, out patternTreeNodeCountOut, patternTreeCountOut, out patternTreeCountOut,
				processTreeNodeCountOut, out processTreeNodeCountOut,
				patternTreeNodesOut, out patternTreeNodesOut, patternTreesOut, out patternTreesOut,
				processTreeNodesOut, out processTreeNodesOut, processTreeOut, out processTreeOut,
				variableListCurrent);
		}

	}//SortNode




	internal class FilterNode : FLWORNode
	{

		private PatternTreeNodeCondition pCondition;

		internal FilterNode():base(){}

		internal FilterNode(int id):base(id){}

		internal override string ToStringOut(int level) 
		{
			string s = base.ToStringOut(level);
			return s;
		}

		internal void setQuantifier(string newval){this.pCondition.setQuantifier(newval);}
		internal string getQuantifier(){return this.pCondition.getQuantifier();}
		internal PatternTreeNodeCondition getCondition(){return pCondition;}
		internal void setCondition(PatternTreeNodeCondition pCondition){this.pCondition = pCondition;}

		internal override void getLogicalPlan(
			int patternTreeNodeCountIn, out int patternTreeNodeCountOut, int patternTreeCountIn, out int patternTreeCountOut,
			int processTreeNodeCountIn, out int processTreeNodeCountOut,
			string patternTreeNodesIn, out string patternTreeNodesOut, string patternTreesIn, out string patternTreesOut,
			string processTreeNodesIn, out string processTreeNodesOut, string processTreeIn, out string processTreeOut,
			ArrayList variableListCurrent) 
		{
			patternTreeNodeCountOut = patternTreeNodeCountIn; patternTreeCountOut = patternTreeCountIn;
			processTreeNodeCountOut = processTreeNodeCountIn;
			patternTreeNodesOut = patternTreeNodesIn; patternTreesOut = patternTreesIn;
			processTreeNodesOut = processTreeNodesIn; processTreeOut = processTreeIn;

			//<filter node> := <node id> FILTER <reference node LCL> <operator> <CONST | REF> <value | LCL> <EVERY | SOME | EXACTLYONE>
			if(this.pCondition.GetType().Name == "PatternTreeJoinCondition")
			{
				//7 FILTER 3 EQS F_REFERENCE 2 SOME
				processTreeNodesOut += this.getId() + " FILTER " + ((PatternTreeJoinCondition)(this.pCondition)).getInfo() + "\n";
			}
			else
			{
				//6 FILTER 5 LTN "45" CONST SOME
				processTreeNodesOut += this.getId() + " FILTER " + this.pCondition.getInfo() + "\n";
			}

			if (processTreeNodeCountOut == 0) processTreeOut += this.getId() + " -1\n";
			else processTreeOut += this.getId() + " " + this.getParent().getId() + "\n";

			processTreeNodeCountOut++;
			
			base.getLogicalPlan(patternTreeNodeCountOut, out patternTreeNodeCountOut, patternTreeCountOut, out patternTreeCountOut,
				processTreeNodeCountOut, out processTreeNodeCountOut,
				patternTreeNodesOut, out patternTreeNodesOut, patternTreesOut, out patternTreesOut,
				processTreeNodesOut, out processTreeNodesOut, processTreeOut, out processTreeOut,
				variableListCurrent);
		}

	}//FilterNode


	internal class OrFilterNode : FLWORNode
	{

		private ArrayList pConditions;

		internal OrFilterNode():base(){this.pConditions = new ArrayList();}

		internal OrFilterNode(int id):base(id){this.pConditions = new ArrayList();}

		internal override string ToStringOut(int level) 
		{
			string s = base.ToStringOut(level);
			return s;
		}

		internal void addCondition(PatternTreeNodeCondition ptnc){this.pConditions.Add(ptnc);}
		internal ArrayList getConditions() {return this.pConditions;}

		internal override void getLogicalPlan(
			int patternTreeNodeCountIn, out int patternTreeNodeCountOut, int patternTreeCountIn, out int patternTreeCountOut,
			int processTreeNodeCountIn, out int processTreeNodeCountOut,
			string patternTreeNodesIn, out string patternTreeNodesOut, string patternTreesIn, out string patternTreesOut,
			string processTreeNodesIn, out string processTreeNodesOut, string processTreeIn, out string processTreeOut,
			ArrayList variableListCurrent) 
		{
			patternTreeNodeCountOut = patternTreeNodeCountIn; patternTreeCountOut = patternTreeCountIn;
			processTreeNodeCountOut = processTreeNodeCountIn;
			patternTreeNodesOut = patternTreeNodesIn; patternTreesOut = patternTreesIn;
			processTreeNodesOut = processTreeNodesIn; processTreeOut = processTreeIn;


			//<orfilter node> := <node id> ORFILTER <number of filters in OR> (<reference node LCL> <operator> <CONST | REF> <value | LCL> <EVERY | SOME | EXACTLYONE>)+
			processTreeNodesOut += this.getId() + " ORFILTER " + this.pConditions.Count + " ";
			for(int i=0;i<this.pConditions.Count;i++)
			{
				PatternTreeNodeCondition ptnc = (PatternTreeNodeCondition)(this.pConditions[i]);
				processTreeNodesOut += ptnc.getInfo() + " ";
			}
			processTreeNodesOut += "\n";

			if (processTreeNodeCountOut == 0) processTreeOut += this.getId() + " -1\n";
			else processTreeOut += this.getId() + " " + this.getParent().getId() + "\n";

			processTreeNodeCountOut++;
			
			base.getLogicalPlan(patternTreeNodeCountOut, out patternTreeNodeCountOut, patternTreeCountOut, out patternTreeCountOut,
				processTreeNodeCountOut, out processTreeNodeCountOut,
				patternTreeNodesOut, out patternTreeNodesOut, patternTreesOut, out patternTreesOut,
				processTreeNodesOut, out processTreeNodesOut, processTreeOut, out processTreeOut,
				variableListCurrent);
		}

	}//OrFilterNode



	internal class AggregateNode : FLWORNode
	{
		private int functionType;// AG_COUNT | AG_MIN | AG_MAX | AG_SUM | AG_AVERAGE
		private int myWID;
		private int refWID;


		internal AggregateNode():base(){}

		internal AggregateNode(int id):base(id){}

		internal override string ToStringOut(int level) 
		{
			string s = base.ToStringOut(level);
			return s;
		}

		internal void setFunctionName(string functionName)
		{
			if (functionName == "count") {this.functionType = (int)(values.aggregateCount); }
			else if (functionName == "sum") {this.functionType = (int)(values.aggregateSum); }
			else if (functionName == "min") {this.functionType = (int)(values.aggregateMin); }
			else if (functionName == "max") {this.functionType = (int)(values.aggregateMax); }
			else if (functionName == "avg") {this.functionType = (int)(values.aggregateAverage); }
		}

		internal void setFunctionType(int functionType){this.functionType = functionType;}
		internal int getFunctionType(){return this.functionType;}
		internal void setRefWID(int refWID){this.refWID = refWID;}
		internal int getRefWID(){return this.refWID;}
		internal void setMyWID(int myWID){this.myWID = myWID;}
		internal int getMyWID(){return this.myWID;}

		internal string getFunctionName()
		{
			string output = "empty";
			switch (this.functionType)
			{
				case (int)(values.aggregateAverage):
					output = "AVERAGE";
					break;
				case (int)(values.aggregateMin):
					output = "MIN";
					break;
				case (int)(values.aggregateMax):
					output = "MAX";
					break;
				case (int)(values.aggregateSum):
					output = "SUM";
					break;
				case (int)(values.aggregateCount):
					output = "COUNT";
					break;
			}
			return output;
		}

		internal override void getLogicalPlan(
			int patternTreeNodeCountIn, out int patternTreeNodeCountOut, int patternTreeCountIn, out int patternTreeCountOut,
			int processTreeNodeCountIn, out int processTreeNodeCountOut,
			string patternTreeNodesIn, out string patternTreeNodesOut, string patternTreesIn, out string patternTreesOut,
			string processTreeNodesIn, out string processTreeNodesOut, string processTreeIn, out string processTreeOut,
			ArrayList variableListCurrent) 
		{
			patternTreeNodeCountOut = patternTreeNodeCountIn; patternTreeCountOut = patternTreeCountIn;
			processTreeNodeCountOut = processTreeNodeCountIn;
			patternTreeNodesOut = patternTreeNodesIn; patternTreesOut = patternTreesIn;
			processTreeNodesOut = processTreeNodesIn; processTreeOut = processTreeIn;

			//<aggregate function node> := <node id> AGGREGATE_FUNCTION <COUNT | MIN | MAX | SUM | AVERAGE> <reference node LCL> <new node id> <new node tagname>
			processTreeNodesOut += this.getId() + " AGGREGATE_FUNCTION " + this.getFunctionName() + " " + 
				this.getRefWID() + " " + this.getMyWID() + " " + this.getFunctionName() + this.getMyWID() + "\n"; 

			if (processTreeNodeCountOut == 0) processTreeOut += this.getId() + " -1\n";
			else processTreeOut += this.getId() + " " + this.getParent().getId() + "\n";

			processTreeNodeCountOut++;
			
			base.getLogicalPlan(patternTreeNodeCountOut, out patternTreeNodeCountOut, patternTreeCountOut, out patternTreeCountOut,
				processTreeNodeCountOut, out processTreeNodeCountOut,
				patternTreeNodesOut, out patternTreeNodesOut, patternTreesOut, out patternTreesOut,
				processTreeNodesOut, out processTreeNodesOut, processTreeOut, out processTreeOut,
				variableListCurrent);
		}

	}//AggregateNode

	internal class DeleteNode : FLWORNode
	{
		private int refWID;
		private bool textOrSubtree; // true for Subtree, false for text

		internal DeleteNode():base(){this.textOrSubtree = true;}
		internal DeleteNode(int id):base(id){this.textOrSubtree = true;}

		internal override string ToStringOut(int level) 
		{
			string s = base.ToStringOut(level);
			return s;
		}

		internal void setText(){this.textOrSubtree = false;}
		internal void setSubTree(){this.textOrSubtree = true;}

		internal void setRefWID(int refWID){this.refWID = refWID;}
		internal int getRefWID(){return this.refWID;}

		internal override void getLogicalPlan(
			int patternTreeNodeCountIn, out int patternTreeNodeCountOut, int patternTreeCountIn, out int patternTreeCountOut,
			int processTreeNodeCountIn, out int processTreeNodeCountOut,
			string patternTreeNodesIn, out string patternTreeNodesOut, string patternTreesIn, out string patternTreesOut,
			string processTreeNodesIn, out string processTreeNodesOut, string processTreeIn, out string processTreeOut,
			ArrayList variableListCurrent) 
		{
			patternTreeNodeCountOut = patternTreeNodeCountIn; patternTreeCountOut = patternTreeCountIn;
			processTreeNodeCountOut = processTreeNodeCountIn;
			patternTreeNodesOut = patternTreeNodesIn; patternTreesOut = patternTreesIn;
			processTreeNodesOut = processTreeNodesIn; processTreeOut = processTreeIn;

			//<delete node> := <node id> DELETE <LCL> <TEXT | SUBTREE>
			processTreeNodesOut += this.getId() + " DELETE " + this.getRefWID();
			if (this.textOrSubtree) processTreeNodesOut += " SUBTREE\n";
			else processTreeNodesOut += " TEXT\n";

			if (processTreeNodeCountOut == 0) processTreeOut += this.getId() + " -1\n";
			else processTreeOut += this.getId() + " " + this.getParent().getId() + "\n";

			processTreeNodeCountOut++;
			
			base.getLogicalPlan(patternTreeNodeCountOut, out patternTreeNodeCountOut, patternTreeCountOut, out patternTreeCountOut,
				processTreeNodeCountOut, out processTreeNodeCountOut,
				patternTreeNodesOut, out patternTreeNodesOut, patternTreesOut, out patternTreesOut,
				processTreeNodesOut, out processTreeNodesOut, processTreeOut, out processTreeOut,
				variableListCurrent);
		}

	}//DeleteNode

	internal class UpdateNode : FLWORNode
	{
		private int refWID;
		private string newValue; 
		private bool reference; // if const or reference for dynamic updates

		internal UpdateNode():base(){}
		internal UpdateNode(int id):base(id){}
		internal UpdateNode(int id, int refWID, string newValue):base(id)
		{
			this.refWID = refWID;
			this.newValue = newValue;
			this.reference = false;
		}

		internal override string ToStringOut(int level) 
		{
			string s = base.ToStringOut(level);
			return s;
		}

		internal void setReference(){this.reference = true;}
		internal void setConst(){this.reference = false;}
		internal bool getReference(){return this.reference;}
		internal void setValue(string newValue){this.newValue = newValue;}
		internal string getValue(){return this.newValue;}
		internal void setRefWID(int refWID){this.refWID = refWID;}
		internal int getRefWID(){return this.refWID;}

		internal override void getLogicalPlan(
			int patternTreeNodeCountIn, out int patternTreeNodeCountOut, int patternTreeCountIn, out int patternTreeCountOut,
			int processTreeNodeCountIn, out int processTreeNodeCountOut,
			string patternTreeNodesIn, out string patternTreeNodesOut, string patternTreesIn, out string patternTreesOut,
			string processTreeNodesIn, out string processTreeNodesOut, string processTreeIn, out string processTreeOut,
			ArrayList variableListCurrent) 
		{
			patternTreeNodeCountOut = patternTreeNodeCountIn; patternTreeCountOut = patternTreeCountIn;
			processTreeNodeCountOut = processTreeNodeCountIn;
			patternTreeNodesOut = patternTreeNodesIn; patternTreesOut = patternTreesIn;
			processTreeNodesOut = processTreeNodesIn; processTreeOut = processTreeIn;

			//<update node> := <node id> UPDATE <LCL> <CONST | REF> <value | LCL>
			processTreeNodesOut += this.getId() + " UPDATE " + this.getRefWID();
			if (this.reference) 
				processTreeNodesOut += " REF " + this.newValue + "\n";
			else 
				processTreeNodesOut += " CONST " + "\"" + this.newValue + "\"\n";

			if (processTreeNodeCountOut == 0) processTreeOut += this.getId() + " -1\n";
			else processTreeOut += this.getId() + " " + this.getParent().getId() + "\n";

			processTreeNodeCountOut++;
			
			base.getLogicalPlan(patternTreeNodeCountOut, out patternTreeNodeCountOut, patternTreeCountOut, out patternTreeCountOut,
				processTreeNodeCountOut, out processTreeNodeCountOut,
				patternTreeNodesOut, out patternTreeNodesOut, patternTreesOut, out patternTreesOut,
				processTreeNodesOut, out processTreeNodesOut, processTreeOut, out processTreeOut,
				variableListCurrent);
		}

	}//UpdateNode

	internal class InsertNode : FLWORNode
	{
		private int refWID;
		private string DocValue; 
		private ArrayList myList;  // for element contenct etc
		private bool insAttr;
		

		internal InsertNode():base()
		{
			myList = new ArrayList();
			insAttr = false;
		}
		internal InsertNode(int id):base(id)
		{
			myList = new ArrayList();
			insAttr = false;
		}
		internal InsertNode(int id, int refWID, string DocValue):base(id)
		{
			this.refWID = refWID;
			this.DocValue = DocValue;
			myList = new ArrayList();
			insAttr = false;
		}

		internal override string ToStringOut(int level) 
		{
			string s = base.ToStringOut(level);
			return s;
		}

		internal void setAttribute(){this.insAttr = true;}
		internal void setDocValue(string DocValue){this.DocValue = DocValue.Trim('"');}
		internal string getDocValue(){return this.DocValue;}
		internal void setRefWID(int refWID){this.refWID = refWID;}
		internal int getRefWID(){return this.refWID;}
		internal void addToList(InsertObject io){this.myList.Add(io);}
		internal ArrayList getList(){return this.myList;}

		internal override void getLogicalPlan(
			int patternTreeNodeCountIn, out int patternTreeNodeCountOut, int patternTreeCountIn, out int patternTreeCountOut,
			int processTreeNodeCountIn, out int processTreeNodeCountOut,
			string patternTreeNodesIn, out string patternTreeNodesOut, string patternTreesIn, out string patternTreesOut,
			string processTreeNodesIn, out string processTreeNodesOut, string processTreeIn, out string processTreeOut,
			ArrayList variableListCurrent) 
		{
			patternTreeNodeCountOut = patternTreeNodeCountIn; patternTreeCountOut = patternTreeCountIn;
			processTreeNodeCountOut = processTreeNodeCountIn;
			patternTreeNodesOut = patternTreeNodesIn; patternTreesOut = patternTreesIn;
			processTreeNodesOut = processTreeNodesIn; processTreeOut = processTreeIn;


			if (this.myList.Count == 0)
			{
				//<insert-file node> := <node id> INSERT_FILE <LCL> <filename>
				processTreeNodesOut += this.getId() + " INSERT_FILE " + this.getRefWID() + " \"" + this.DocValue + "\"\n";
			}
			else
			{

				if (this.insAttr)
				{
					//<insert-attribute node> := <node id> INSERT_ATTRIBUTE <LCL> <tagname> <CONST | REF> <value | LCL>
					processTreeNodesOut += this.getId() + " INSERT_ATTRIBUTE " + this.getRefWID() + " ";
					InsertObject eo = (InsertObject)(this.myList[0]);
					processTreeNodesOut += eo.getInsertObjectInfo();
				}
				else
				{
					//<insert-element node> := <node id> INSERT_ELEMENT <LCL> <tagname> <CONST | REF> <value | LCL> <number of attributes>  [<tagname> <CONST | REF> <value | LCL>]+
					processTreeNodesOut += this.getId() + " INSERT_ELEMENT " + this.getRefWID() + " ";
					InsertObject eo = (InsertObject)(this.myList[0]);
					processTreeNodesOut += eo.getInsertObjectInfo();
					processTreeNodesOut += " " + ((int)(this.myList.Count - 1)).ToString() + " ";
					for(int i=1;i<this.myList.Count;i++)
					{
						InsertObject ao = (InsertObject)(this.myList[i]);
						processTreeNodesOut += ao.getInsertObjectInfo() + " ";
					}
				}

				processTreeNodesOut += "\n";
			}

			if (processTreeNodeCountOut == 0) processTreeOut += this.getId() + " -1\n";
			else processTreeOut += this.getId() + " " + this.getParent().getId() + "\n";

			processTreeNodeCountOut++;
			
			base.getLogicalPlan(patternTreeNodeCountOut, out patternTreeNodeCountOut, patternTreeCountOut, out patternTreeCountOut,
				processTreeNodeCountOut, out processTreeNodeCountOut,
				patternTreeNodesOut, out patternTreeNodesOut, patternTreesOut, out patternTreesOut,
				processTreeNodesOut, out processTreeNodesOut, processTreeOut, out processTreeOut,
				variableListCurrent);
		}

	}//InsertNode


	internal class ConstructNode : FLWORNode
	{
		internal ConstructNode():base(){}

		internal ConstructNode(int id):base(id){}

		internal override string ToStringOut(int level) 
		{
			string s = base.ToStringOut(level);
			return s;
		}

		internal override int surviveProjection(int wid, bool isNode, bool isOuter) 
		{
			if (this.getChildren().Count == 0) return -1;
			int outval = -1;
			for(int i=0; i<this.getChildren().Count; i++)
				outval = ((FLWORNode)(this.getChildren()[i])).surviveProjection(wid, isNode, isOuter);
			if ((outval > 0) && (outval != wid)) wid = outval;
			if (this.getPatternTree()!=null)
			{
				PatternTree pt = this.getPatternTree();
				PatternTreeNode ptn = (PatternTreeNode)(pt.getRoot()); 
				if (ptn.getId() == wid) return wid;
				ConstructReferencePatternTreeNode pref = new ConstructReferencePatternTreeNode(HelpFunctions.lcl++, wid.ToString(), false, (int)(values.descendant), (int)(values.referenceNode));
				if (isNode) pref.setNode();
				if (isOuter) pref.setOuter();
				if (ptn.GetType().Name == "ConstructElementPatternTreeNode") 
					((ConstructElementPatternTreeNode)(ptn)).addContent(pref);
				else ptn.addChild(pref);
				return pref.getId();
			}
			return outval;
		}

		internal override void getLogicalPlan(
			int patternTreeNodeCountIn, out int patternTreeNodeCountOut,
			int patternTreeCountIn, out int patternTreeCountOut,
			int processTreeNodeCountIn, out int processTreeNodeCountOut,
			string patternTreeNodesIn, out string patternTreeNodesOut,
			string patternTreesIn, out string patternTreesOut,
			string processTreeNodesIn, out string processTreeNodesOut,
			string processTreeIn, out string processTreeOut,
			ArrayList variableListCurrent) 
		{
			patternTreeNodeCountOut = patternTreeNodeCountIn;
			patternTreeCountOut = patternTreeCountIn;
			processTreeNodeCountOut = processTreeNodeCountIn;
			patternTreeNodesOut = patternTreeNodesIn;
			patternTreesOut = patternTreesIn;
			processTreeNodesOut = processTreeNodesIn;
			processTreeOut = processTreeIn;

			int nodeCount = 0;
			string nodePattern;
			string treePattern;
			((ConstructReferencePatternTreeNode)(this.getPatternTree().getRoot())).getLogicalConstructPlan(
				0, out nodeCount, 
				"", out nodePattern, 
				"", out treePattern, 
				variableListCurrent);

			string[] elements = nodePattern.Split(' ');
			int rootID = int.Parse(elements[0]);
			//0 2 0 PT_NORMAL
			treePattern = this.getPatternTree().getId() + " " + nodeCount + " " + rootID + " CONSTRUCT_TREE\n" + treePattern;
			treePattern = "// pattern tree \n" + treePattern;
			nodePattern = "// list of nodes for pattern tree " + this.getPatternTree().getId() + "\n" + nodePattern;

			patternTreeNodeCountOut = patternTreeNodeCountOut + nodeCount;
			patternTreeCountOut++;
			patternTreeNodesOut += nodePattern;
			patternTreesOut += treePattern;

			//0 CONSTRUCT  0
			processTreeNodesOut += this.getId() + " CONSTRUCT " + this.getPatternTree().getId() + "\n";
			if (processTreeNodeCountOut == 0)
				processTreeOut += this.getId() + " -1\n";
			else
			{
				processTreeOut += this.getId() + " " + this.getParent().getId() + "\n";
			}

			processTreeNodeCountOut++;
			
			base.getLogicalPlan(
				patternTreeNodeCountOut, out patternTreeNodeCountOut,
				patternTreeCountOut, out patternTreeCountOut,
				processTreeNodeCountOut, out processTreeNodeCountOut,
				patternTreeNodesOut, out patternTreeNodesOut,
				patternTreesOut, out patternTreesOut,
				processTreeNodesOut, out processTreeNodesOut,
				processTreeOut, out processTreeOut,
				variableListCurrent);
		}


	}


	internal class ProjectNode : FLWORNode
	{
		private int pRoot; // for the root of the tree
		private ArrayList projectionList;

		internal ProjectNode():base(){projectionList = new ArrayList();	}
		internal ProjectNode(int id):base(id){projectionList = new ArrayList();	}

		internal void setRoot(int wid)
		{
			this.pRoot = wid;
			// check if root exists in projection list
			if (!this.projectionList.Contains(wid)) this.projectionList.Insert(0, wid);
		}
		internal int getRoot(){return this.pRoot;}
		internal override int getRootLCL() {return this.pRoot;}

		internal void addToProjectionList(int wid){if (!this.projectionList.Contains(wid)) this.projectionList.Add(wid);}
		internal ArrayList getProjectionList(){return this.projectionList;}

		internal override string ToStringOut(int level) 
		{
			string s = base.ToStringOut(level);
			for(int i=0; i<this.projectionList.Count;i++)
			{
				s += ((int)(this.projectionList[i])).ToString() + " ";
			}
			return s;
		}

		internal override int surviveProjection(int wid, bool isNode, bool isOuter) 
		{
			if (!this.projectionList.Contains(wid)) this.projectionList.Add(wid);
			if (this.getChildren().Count == 0) return -1;
			int outval = -1, tmpval = -1;
			for(int i=0; i<this.getChildren().Count; i++)
			{
				tmpval = ((FLWORNode)(this.getChildren()[i])).surviveProjection(wid, isNode, isOuter);
				if (tmpval != -1) outval = tmpval;
			}
			return outval;
		}


		internal override void getLogicalPlan(
			int patternTreeNodeCountIn, out int patternTreeNodeCountOut, int patternTreeCountIn, out int patternTreeCountOut,
			int processTreeNodeCountIn, out int processTreeNodeCountOut,
			string patternTreeNodesIn, out string patternTreeNodesOut, string patternTreesIn, out string patternTreesOut,
			string processTreeNodesIn, out string processTreeNodesOut, string processTreeIn, out string processTreeOut,
			ArrayList variableListCurrent) 
		{
			patternTreeNodeCountOut = patternTreeNodeCountIn; patternTreeCountOut = patternTreeCountIn;
			processTreeNodeCountOut = processTreeNodeCountIn;
			patternTreeNodesOut = patternTreeNodesIn; patternTreesOut = patternTreesIn;
			processTreeNodesOut = processTreeNodesIn; processTreeOut = processTreeIn;

			//<project node> := <node id> PROJECT  <number of nodes to project>  <projection list using LCLs>

			processTreeNodesOut += this.getId() + " PROJECT " + this.projectionList.Count;
			for(int i = 0; i<this.projectionList.Count; i++)
				processTreeNodesOut += " " + ((int)(this.projectionList[i])).ToString();
			processTreeNodesOut += "\n";

			if (processTreeNodeCountOut == 0) processTreeOut += this.getId() + " -1\n";
			else processTreeOut += this.getId() + " " + this.getParent().getId() + "\n";

			processTreeNodeCountOut++;
			
			base.getLogicalPlan(patternTreeNodeCountOut, out patternTreeNodeCountOut, patternTreeCountOut, out patternTreeCountOut,
				processTreeNodeCountOut, out processTreeNodeCountOut,
				patternTreeNodesOut, out patternTreeNodesOut, patternTreesOut, out patternTreesOut,
				processTreeNodesOut, out processTreeNodesOut, processTreeOut, out processTreeOut,
				variableListCurrent);
		}

	}

	internal class DuplicateEliminationNode : FLWORNode
	{
		private int DENode; // lcl for tree root or node
		private int DEType; // id or content

		internal DuplicateEliminationNode():base(){this.DEType = (int)(values.DEonID);}
		internal DuplicateEliminationNode(int id):base(id){	this.DEType = (int)(values.DEonID);	}

		internal void setDEType(int deType){this.DEType = deType;}
		internal int getDEType(){return this.DEType;}
		internal void setDENode(int deNode){this.DENode = deNode;}
		internal int getDENode(){return this.DENode;}

		internal override string ToStringOut(int level) 
		{
			string s = base.ToStringOut(level);
			switch (DEType)
			{
				case (int)(values.DEonID):
					s += "DE_ID ";
					break;
				case (int)(values.DEonContent):
					s += "DE_CONTENT ";
					break;
			}
			s += this.DENode.ToString() + " ";
			return s;
		}

		internal override void getLogicalPlan(
			int patternTreeNodeCountIn, out int patternTreeNodeCountOut, int patternTreeCountIn, out int patternTreeCountOut,
			int processTreeNodeCountIn, out int processTreeNodeCountOut,
			string patternTreeNodesIn, out string patternTreeNodesOut, string patternTreesIn, out string patternTreesOut,
			string processTreeNodesIn, out string processTreeNodesOut, string processTreeIn, out string processTreeOut,
			ArrayList variableListCurrent) 
		{
			patternTreeNodeCountOut = patternTreeNodeCountIn; patternTreeCountOut = patternTreeCountIn;
			processTreeNodeCountOut = processTreeNodeCountIn;
			patternTreeNodesOut = patternTreeNodesIn; patternTreesOut = patternTreesIn;
			processTreeNodesOut = processTreeNodesIn; processTreeOut = processTreeIn;

			//<duplicate elimination node> := <node id> DUPLICATE_ELIMINATION  <ID | TEXT> <LCL>
			string idorcont = " ID ";
			if (this.DEType == (int)(values.DEonContent)) idorcont = " TEXT "; 
			processTreeNodesOut += this.getId() + " DUPLICATE_ELIMINATION" + idorcont + this.DENode.ToString();

			processTreeNodesOut += " \n";

			if (processTreeNodeCountOut == 0) processTreeOut += this.getId() + " -1\n";
			else processTreeOut += this.getId() + " " + this.getParent().getId() + "\n";

			processTreeNodeCountOut++;
			
			base.getLogicalPlan(patternTreeNodeCountOut, out patternTreeNodeCountOut, patternTreeCountOut, out patternTreeCountOut,
				processTreeNodeCountOut, out processTreeNodeCountOut,
				patternTreeNodesOut, out patternTreeNodesOut, patternTreesOut, out patternTreesOut,
				processTreeNodesOut, out processTreeNodesOut, processTreeOut, out processTreeOut,
				variableListCurrent);
		}

	}




}