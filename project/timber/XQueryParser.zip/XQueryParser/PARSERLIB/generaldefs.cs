//COPYRIGHT  � 2000-2004 
//THE REGENTS OF THE UNIVERSITY OF MICHIGAN
//ALL RIGHTS RESERVED
//
//PERMISSION IS GRANTED TO USE, COPY, CREATE DERIVATIVE WORKS AND REDISTRIBUTE 
//THIS SOFTWARE AND SUCH DERIVATIVE WORKS FOR NONCOMMERCIAL EDUCATION AND 
//RESEARCH PURPOSES, SO LONG AS NO FEE IS CHARGED, AND SO LONG AS THE 
//COPYRIGHT NOTICE ABOVE, THIS GRANT OF PERMISSION, AND THE DISCLAIMER 
//BELOW APPEAR IN ALL COPIES MADE; AND SO LONG AS THE NAME OF THE UNIVERSITY 
//OF MICHIGAN IS NOT USED IN ANY ADVERTISING OR PUBLICITY PERTAINING TO THE 
//USE OR DISTRIBUTION OF THIS SOFTWARE WITHOUT SPECIFIC, WRITTEN PRIOR AUTHORIZATION.
//
//THIS SOFTWARE IS PROVIDED AS IS, WITHOUT REPRESENTATION FROM THE UNIVERSITY 
//OF MICHIGAN AS TO ITS FITNESS FOR ANY PURPOSE, AND WITHOUT WARRANTY BY THE 
//UNIVERSITY OF MICHIGAN OF ANY KIND, EITHER EXPRESS OR IMPLIED, INCLUDING 
//WITHOUT LIMITATION THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS 
//FOR A PARTICULAR PURPOSE. THE REGENTS OF THE UNIVERSITY OF MICHIGAN SHALL 
//NOT BE LIABLE FOR ANY DAMAGES, INCLUDING SPECIAL, INDIRECT, INCIDENTAL, 
//OR CONSEQUENTIAL DAMAGES, WITH RESPECT TO ANY CLAIM ARISING OUT OF OR IN 
//CONNECTION WITH THE USE OF THE SOFTWARE, EVEN IF IT HAS BEEN OR IS 
//HEREAFTER ADVISED OF THE POSSIBILITY OF SUCH DAMAGES.

// Author: Stelios Paparizos
// e-mail: spapariz@umich.edu
// Summary: This file contains general classes that help the parser process.
// The HelpFunctions class, the values enumeration, the variable binding class etc


using System.Collections;
using System;
using System.Text;


namespace Timber.XQueryParser
{
	/// <summary>
	/// Abstract class used for all trees.
	/// </summary>	
	internal class Tree
	{
		private Node root;

		internal Tree()	{this.root = null;}
		internal Tree(Node root) {this.root = root;}

		internal Node getRoot(){return this.root;}
		internal void setRoot(Node root){this.root = root;}

		internal virtual string ToStringOut() {return treeString(root, 0);}

		private string treeString(Node node, int level) 
		{
			if (node == null)
				return "Null node!\n";
			//string s = new string('\t', level);
			string s = node.ToStringOut(level);
			//s += node.ToStringOut(level);
			//s += "\n";
			ArrayList mylist = node.getChildren();
			for(int i = 0; i < mylist.Count; i++)
			{
				//s += " child:" + i + " ";
				s += this.treeString(((Node)(mylist[i])), level+1);
			}
			return s;
		}


	}


	


	/// <summary>
	/// Abstract Class used for all nodes.
	/// </summary>
	internal class Node
	{
		private int id;
		private Node parent;
		private ArrayList children;

		internal Node()
		{
			this.id = -1;
			this.children = new ArrayList();
			//this.parent = null;
		}

		internal Node(int id)
		{
			this.id = id;
			this.children = new ArrayList();
		}

		internal int getId(){return this.id;}
		internal void setId(int id){this.id = id;}

		internal Node getParent(){return this.parent;}
		internal void setParent(Node parent){this.parent = parent;}

		internal ArrayList getChildren(){return this.children;}
		internal void addChild(Node child)
		{
			this.children.Add(child);
			if ((child.getParent() == null) || (child.getParent() != this))
				child.setParent(this);
		}
		internal void removeChild(Node child)
		{
			this.children.Remove(child);
		}


		internal virtual string ToStringOut(int level) 
		{
			string s = new string('\t', level);
			//string s = "id=";
			s += this.id;
			s += "\t";
			//s += this.GetType().ToString();
			//s += "\n";
			return s;
		}


	}

	internal class SortObject
	{
		private int sortByType; //<sort option> := SORT_BY_KEY | SORT_BY_VALUE 
		private int sortOrder; // <sort order> := ASCENDING | DESCENDING
		private int emptyleast; // for empty greatest or empty least
		private int LCL;
		private PatternTreeNode myNode;

		internal SortObject()
		{
			this.sortByType = (int)(values.sortByValue);
			this.sortOrder = (int)(values.sortAscending);
			this.emptyleast = (int)(values.sortEmptyGreatest);
			this.LCL = -1;
		}
		internal SortObject(int reflcl)
		{
			this.sortByType = (int)(values.sortByValue);
			this.sortOrder = (int)(values.sortAscending);
			this.emptyleast = (int)(values.sortEmptyGreatest);
			this.LCL = reflcl;
		}

		internal void setSortByType(int sbType){this.sortByType = sbType;}
		internal int getSortByType(){return this.sortByType;}
		internal void setSortOrder(int sortOrder){this.sortOrder = sortOrder;}
		internal int getSortOrder(){return this.sortOrder;}
		internal void setEmptyLeast(int emptyleast){this.emptyleast = emptyleast;}
		internal int getEmptyLeast(){return this.emptyleast;}
		internal void setRefLCL(int RefLCL){this.LCL = RefLCL;}
		internal int getRefLCL(){return this.LCL;}
		internal PatternTreeNode getMyNode() {return myNode;}
		internal void setMyNode(PatternTreeNode newval) {myNode=newval;}


		internal string getSortOutput()
		{
			//<LCL> <KEY | VALUE> <ASCENDING | DESCENDING> <LEAST | GREATEST>
			
			string output = "";
			output += this.LCL.ToString() + " ";
			switch (this.sortByType)
			{
				case (int)(values.sortByKey):
					output += "KEY";
					break;
				case (int)(values.sortByValue):
					output += "VALUE";
					break;
			}
			switch (this.sortOrder)
			{
				case (int)(values.sortAscending):
					output += " ASCENDING ";
					break;
				case (int)(values.sortDescending):
					output += " DESCENDING ";
					break;
			}
			switch (this.emptyleast)
			{
				case (int)(values.sortEmptyLeast):
					output += "LEAST";
					break;
				case (int)(values.sortEmptyGreatest):
					output += "GREATEST";
					break;
			}

			return output;
		}

	}//SortObject

	internal class InsertObject
	{

		private string tagname; // for the tagname
		private PatternTreeNode myNode; // to hold the value
		private string newValue;
		private bool reference;

		internal InsertObject()
		{
			this.tagname = "empty";
			this.newValue = "empty";
			this.reference = false;
		}

		internal void setReference(){this.reference = true;}
		internal void setConst(){this.reference = false;}
		internal bool getReference(){return this.reference;}
		internal void setTagName(string tag){this.tagname = tag;}
		internal string getTagName() {return this.tagname;}
		internal void setValue(string tag){this.newValue = tag;}
		internal string getValue() {return this.newValue;}
		internal PatternTreeNode getMyNode() {return myNode;}
		internal void setMyNode(PatternTreeNode newval) {myNode=newval;}


		internal string getInsertObjectInfo()
		{
			//<tagname> <CONST | REF> <value | LCL>
			string output = this.tagname;
			if (this.reference) 
				output += " REF " + this.newValue; 
			else output += " CONST " + "\"" + this.newValue + "\"";
			return output;
		}


	}//SortObject



	internal class HelpFunctions
	{
		internal static int treeID;
		internal static int nodeID;
		internal static int lcl;
		internal static int reflcl;
		internal static bool success;
		internal static string errorString;

		/// <summary>
		/// Merge two pattern trees. pt2 is the child tree of pt1, or they both start with document
		/// </summary>
		/// <param name="pt1">The parent tree</param>
		/// <param name="pt2">The child tree</param>
		/// <param name="variableMappings">An array containing the variable binding information</param>
		/// <returns></returns>
		internal static PatternTree mergePatternTrees(PatternTree pt1, PatternTree pt2, ArrayList variableMappings)
		{
			PatternTree pt_ret = new PatternTree(pt1.getId());
			if(pt1.getConditions() != null) pt_ret.addConditionRange(pt1.getConditions());
			if(pt2.getConditions() != null) pt_ret.addConditionRange(pt2.getConditions());

			PatternTreeNode root1 = (PatternTreeNode)(pt1.getRoot());
			PatternTreeNode root2 = (PatternTreeNode)(pt2.getRoot());
			System.Type type2 = root2.GetType();

			if (root2.getSpecial() == (int)(values.specialAggregateNode))
			{
				// merge with child
				PatternTreeNode node0 = (PatternTreeNode)(root2.getChildren()[0]);
				node0.setParent(root2.getParent());
				PatternTree ptnode0 = new PatternTree(treeID++);
				ptnode0.setRoot(node0);
				pt_ret = mergePatternTrees(pt1, ptnode0, variableMappings);
				return pt_ret;
			}// case aggregate node


			if (type2.Name == "JoinDualPatternTreeNode")
			{
				JoinDualPatternTreeNode jroot2 = (JoinDualPatternTreeNode)(root2);
				// get node 1, create a pattern tree and merge it
				PatternTreeNode node1 = (PatternTreeNode)(jroot2.getNode1());
				PatternTree ptnode1 = new PatternTree(treeID++);
				ptnode1.setRoot(node1);
				pt_ret = mergePatternTrees(pt1, ptnode1, variableMappings);

				// get node 2. create a pattern tree and merge it
				PatternTreeNode node2 = (PatternTreeNode)(jroot2.getNode2());
				PatternTree ptnode2 = new PatternTree(treeID++);
				ptnode2.setRoot(node2);
				pt_ret = mergePatternTrees(pt_ret, ptnode2, variableMappings);

				// make sure that the join condition is associated with the pattern tree
				PatternTreeJoinCondition ptjc = jroot2.getJoinCondition();
				if (node1.getId() == ptjc.getJoinWID1())
					if (node1.getTagName().StartsWith("$"))
					{
						string myTag = node1.getTagName();
						for(int i=0; i<variableMappings.Count; i++)
						{
							VariableMapping vm = (VariableMapping)(variableMappings[i]);
							if (vm.getName() == myTag)
								ptjc.setJoinWID1(vm.getWid());
						}
					}
				if (node2.getId() == ptjc.getJoinWID2())
					if (node2.getTagName().StartsWith("$"))
					{
						string myTag = node2.getTagName();
						for(int i=0; i<variableMappings.Count; i++)
						{
							VariableMapping vm = (VariableMapping)(variableMappings[i]);
							if (vm.getName() == myTag)
								ptjc.setJoinWID2(vm.getWid());
						}
					}

				PatternTreeNode rootret = (PatternTreeNode)(pt_ret.getRoot());
				System.Type typeret = rootret.GetType();
				if (typeret.Name == "JoinDualPatternTreeNode")
				{
					JoinDualPatternTreeNode jrootret = (JoinDualPatternTreeNode)(rootret);
					if(jrootret.getJoinWID1() == jrootret.getJoinWID2())
					{
						jrootret.setJoinCondition(ptjc);
						jrootret.setTagName(jroot2.getTagName());
						jrootret.setSpecial(jroot2.getSpecial());
					}
					else
						pt_ret.addCondition(ptjc);
				}
				else
					pt_ret.addCondition(ptjc);

				return pt_ret;
			}// case JoinRoot
			else if (type2.Name == "DualPatternTreeNode")
			{
				DualPatternTreeNode jroot2 = (DualPatternTreeNode)(root2);
				// currently only AND nodes are supported
				if (jroot2.getSpecial() == (int)(values.specialAndNode))
				{
					// get node 1, create a pattern tree and merge it
					PatternTreeNode node1 = (PatternTreeNode)(jroot2.getNode1());
					//pt2.setRoot(node1);
					PatternTree ptnode1 = new PatternTree(treeID++);
					ptnode1.setRoot(node1);
					pt_ret = mergePatternTrees(pt1, ptnode1, variableMappings);

					// get node 2. create a pattern tree and merge it
					PatternTreeNode node2 = (PatternTreeNode)(jroot2.getNode2());
					PatternTree ptnode2 = new PatternTree(treeID++);
					ptnode2.setRoot(node2);
					pt_ret = mergePatternTrees(pt_ret, ptnode2, variableMappings);

				}
				else
				{
					success = false;
					errorString = "Only AND is currently supported!";
				}
				return pt_ret;
			}// case AND (dualnode)
			string name2 = root2.getTagName();
			if (name2.StartsWith("$"))
			{
				// case 1, the root is a variable, add tree 2 to tree 1

				// look up variable mappings
				for(int i = 0; i < variableMappings.Count; i++)
				{
					VariableMapping vm = (VariableMapping)(variableMappings[i]);
					if (vm.getName() == name2)
					{
						int nodeWID = vm.getWid();
						PatternTreeNode ret = root1.findPatternTreeNode(nodeWID);
						// iterate over the children of root2 and add them to the node
						string compType = root2.getComparisonTypeSymbol();
						if (compType!=null)
						{
							ret.setComparisonType(compType);
							ret.setComparisonValue(root2.getComparisonValue());
						}
						ArrayList children2 = root2.getChildren();
						for(int j=0; j<children2.Count; j++)
						{
							PatternTreeNode childNode = (PatternTreeNode)(children2[j]);
							childNode.setParent(ret);
							ret.addChild(childNode);

						}
						pt_ret.setRoot(root1);
					}
				}

			}// case variable name is root
			else if (name2.StartsWith("document"))
			{
				// case 2, we are using two document, create artificial root node and merge the trees
				//this.success = false;
				//this.errorString = "Currently only one document is supported in an XQuery expression!";

				JoinDualPatternTreeNode jNode = new JoinDualPatternTreeNode(
					nodeID++, "CPRODUCT", (int)(values.cartesianProduct), root1, root2, 0, "=", 0);

				pt_ret.setRoot(jNode);

			}// case document root
			else 
			{
				// error
				success = false;
				errorString = "Error in merging the two pattern trees";
				return pt_ret;
			}
		

			// look up variable mappings and rearrange them
			for(int i = 0; i < variableMappings.Count; i++)
			{
				VariableMapping vm = (VariableMapping)(variableMappings[i]);
				if ((vm.getPid() == pt1.getId())||(vm.getPid() == pt2.getId()))
					vm.setPid(pt_ret.getId());
			}

			return pt_ret;
		}//mergePatternTrees


		internal static void addComparison(PatternTreeNode ptn, string comparisonType, string comparisonValue)
		{
			// it should be a path and not a tree
			ArrayList children = ptn.getChildren();
			if (children.Count > 0) addComparison((PatternTreeNode)(children[0]), comparisonType, comparisonValue);
			else 
			{
				// this is the last node, add the comparison
				ptn.setComparisonType(comparisonType);
				ptn.setComparisonValue(comparisonValue);
			}
			//return ptn.getId();
		}


		internal static string findDocumentName(PatternTreeNode ptn, ArrayList variableListCurrent)
		{
			string docName = "";
			string myTag = ptn.getTagName();
			if (myTag.StartsWith("document("))
			{
				int start = myTag.IndexOf("\"") + 1;
				int length = myTag.LastIndexOf(".") - start;
				docName = myTag.Substring(start, length);
			}
			else
			{
				if (myTag.StartsWith("$"))
				{
					for(int i=0; i<variableListCurrent.Count ; i++)
					{
						VariableMapping vm = (VariableMapping)(variableListCurrent[i]);
						if (vm.getName() == myTag) docName = vm.getFileName();
					}
				}
				else if(myTag.Length <= 2)
				{
					int wid = -1; 
					try
					{
						wid = int.Parse(myTag);
					}
					catch (System.FormatException)
					{
						PatternTreeNode parent = (PatternTreeNode)(ptn.getParent());
						if (parent!=null) docName = findDocumentName(parent, variableListCurrent);
						return docName;
					}
					for(int i=0; i<variableListCurrent.Count ; i++)
					{
						VariableMapping vm = (VariableMapping)(variableListCurrent[i]);
						if (vm.getWid() == wid)	docName = vm.getFileName();
					}
				}
				else
				{
					PatternTreeNode parent = (PatternTreeNode)(ptn.getParent());
					if (parent!=null) docName = findDocumentName(parent, variableListCurrent);
				}
			}
			return docName;
		}

		internal static void setStructuralJoin(PatternTreeNode ptn, int structuralJoin)
		{
			string myTag = ptn.getTagName();
			if ((!myTag.StartsWith("document("))&&(!myTag.StartsWith("$")))
			{
				ptn.setStructuralJoinType(structuralJoin);
			}
			ArrayList children = ptn.getChildren();
			for(int i = 0; i<children.Count; i++)
			{
				setStructuralJoin((PatternTreeNode)(children[i]), structuralJoin);
			}
	
		}

		internal static PatternTreeJoinCondition switchSidesInJoinCondition(PatternTreeJoinCondition ptjc)
		{
			int wid1 = ptjc.getJoinWID1();
			int wid2 = ptjc.getJoinWID2();
			string compsymbol = ptjc.getCompTypeSymbol();
			if (compsymbol == "<=") compsymbol = ">=";
			else if (compsymbol == ">=") compsymbol = "<=";
			else if (compsymbol == "<") compsymbol = ">";
			else if (compsymbol == ">") compsymbol = "<";

			ptjc.setCompType(compsymbol);
			ptjc.setJoinWID1(wid2);
			ptjc.setJoinWID2(wid1);

			return ptjc;
		}

	}// help functions class



	/// <summary>
	/// This is used to map a variable with the corresponding PIDWID
	/// </summary>
	internal class VariableMapping
	{
		private int pid; // the pattern tree id
		private int wid; // the witness tree id
		private string name; // the variable name
		private string fileName; // the filename associated with this variable
		private int bindingType; // does it bind to a FOR, LET variable, mlca, every
		private int function; // does it bind to a function?
		private int oid; // the operator id

		internal VariableMapping(string name, int pid, int wid, int oid, string fileName, int bindingType, int function)
		{
			this.fileName = fileName;
			if (!(name.StartsWith("$"))) name = "$" + name;
			this.name = name;
			this.pid = pid;
			this.wid = wid;
			this.oid = oid;
			this.bindingType = bindingType;
			this.function = function;
		}


		internal string getFileName() {return fileName;}
		internal void setFileName(string fname) {this.fileName = fname;}
		internal string getName() {return name;}
		internal int getPid() {return pid;}
		internal void setPid(int pid) {this.pid = pid;}
		internal int getWid() {return wid;}
		internal int getOid() {return oid;}
		internal void setOid(int oid) {this.oid = oid;}
		internal void setFOR() {this.bindingType = (int)(values.forBinding);}
		internal void setLET() {this.bindingType = (int)(values.letBinding);}
		internal void setMLCA() {this.bindingType = (int)(values.mlcaBinding);}
		internal void setEVERY() {this.bindingType = (int)(values.everyBinding);}
		internal int getBindingType() {return this.bindingType;}
		internal int getFunction() {return this.function;}
		internal void setFunction(int f) {this.function = f;}

		internal string ToStringOut()
		{
			string output = "Name:" + this.getName() 
				+ " PID:" + this.pid + " WID:" + this.wid + " OID:" + this.oid 
				+ " DocName:" + this.getFileName() + " Binding:";
			if (this.bindingType == (int)(values.forBinding)) output += "FOR"; 
			else if (this.bindingType == (int)(values.letBinding)) output += "LET";
			else if (this.bindingType == (int)(values.mlcaBinding)) output += "MLCA";
			else if (this.bindingType == (int)(values.everyBinding)) output += "EVERY";
			output += " Function:";
			if(this.function == (int)(values.specialAggregateNode)) output += " Aggregate";
			else if (this.function ==(int)(values.nestedQuery)) output += " NestedQuery";

			return output;
		}

	}




	/// <summary>
	/// Enumerate all the possible values
	/// </summary>
	internal enum values
	{
		noValue,
		child,
		descendant,
		attribute,
		join,
		cartesianProduct,
		valueComparison,
		specialAggregateNode,
		specialAndNode,
		specialOrNode,
		specialExtensionNode,
		constructNode,
		forSubType,
		letSubType,
		whereSubType,
		orderbySubType,
		flworSubType,
		structuralJoinZeroOne,
		structuralJoinOne,
		structuralJoinZeroMore,
		structuralJoinOneMore,
		DEonID,
		DEonContent,
		sortByKey,
		sortByValue,
		sortAscending,
		sortDescending,
		sortEmptyLeast,
		sortEmptyGreatest,
		aggregateCount,
		aggregateAverage,
		aggregateSum,
		aggregateMin,
		aggregateMax,
		referenceNode,
		forBinding,
		letBinding,
		mlcaBinding,
		everyBinding,
		aggregateBinding,
		delete,
		insertfile,
		insertelement,
		insertattribute,
		update,
		mlca,
		everySubType,
		someSubType,
		nestedQuery,
	}


	internal class DumpVisitor : GoldParser.IGoldVisitor
	{
		private StringBuilder	m_buffer;		
		private int				m_level;
	
		internal DumpVisitor()
		{
			m_buffer = new StringBuilder();
		}
	
		internal String GetResult()
		{
			return m_buffer.ToString();
		}
	
		public void Visit(GoldParser.Reduction p_reduction)
		{
			string p = p_reduction.ToString();
			Print(p);
			m_level++;
			p_reduction.ChildrenAccept(this);
			m_level--;
		}
	
		private void Print(String p_string)
		{
			m_buffer.Append(new String(' ', m_level));
			m_buffer.Append(p_string).Append("\n");
		}
	
	}

	/// <summary>
	/// Summary description for myStackElement.
	/// Provides Stack functionality for the parser.
	/// Used to pass around information when needed.
	/// </summary>
	internal class myStackElement 
	{
		object myValue;

		internal object value() { return myValue;}
		internal void setValue( object q_value) { myValue = q_value;}

		string myName;

		internal string getMyName() {return myName;}
		internal void setMyName(string newval) {myName=newval;}

		Node myNode;
		internal Node getMyNode() {return myNode;}
		internal void setMyNode(Node newval) {myNode=newval;}

		Tree myTree;
		internal Tree getMyTree() {return myTree;}
		internal void setMyTree(Tree newval) {myTree=newval;}

		ArrayList myList;
		internal ArrayList getMyList() {return myList;}
		internal void setMyList(ArrayList o) {myList = o;}
		internal void addToMyList(object o) {myList.Add(o);}
		internal void addRangeToMyList(ArrayList o) {myList.AddRange(o);}

		internal myStackElement()
		{
			myList = new ArrayList();
			myName = "empty";
		}
	}




}