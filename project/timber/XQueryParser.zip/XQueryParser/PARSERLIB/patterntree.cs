//COPYRIGHT  � 2000-2004 
//THE REGENTS OF THE UNIVERSITY OF MICHIGAN
//ALL RIGHTS RESERVED
//
//PERMISSION IS GRANTED TO USE, COPY, CREATE DERIVATIVE WORKS AND REDISTRIBUTE 
//THIS SOFTWARE AND SUCH DERIVATIVE WORKS FOR NONCOMMERCIAL EDUCATION AND 
//RESEARCH PURPOSES, SO LONG AS NO FEE IS CHARGED, AND SO LONG AS THE 
//COPYRIGHT NOTICE ABOVE, THIS GRANT OF PERMISSION, AND THE DISCLAIMER 
//BELOW APPEAR IN ALL COPIES MADE; AND SO LONG AS THE NAME OF THE UNIVERSITY 
//OF MICHIGAN IS NOT USED IN ANY ADVERTISING OR PUBLICITY PERTAINING TO THE 
//USE OR DISTRIBUTION OF THIS SOFTWARE WITHOUT SPECIFIC, WRITTEN PRIOR AUTHORIZATION.
//
//THIS SOFTWARE IS PROVIDED AS IS, WITHOUT REPRESENTATION FROM THE UNIVERSITY 
//OF MICHIGAN AS TO ITS FITNESS FOR ANY PURPOSE, AND WITHOUT WARRANTY BY THE 
//UNIVERSITY OF MICHIGAN OF ANY KIND, EITHER EXPRESS OR IMPLIED, INCLUDING 
//WITHOUT LIMITATION THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS 
//FOR A PARTICULAR PURPOSE. THE REGENTS OF THE UNIVERSITY OF MICHIGAN SHALL 
//NOT BE LIABLE FOR ANY DAMAGES, INCLUDING SPECIAL, INDIRECT, INCIDENTAL, 
//OR CONSEQUENTIAL DAMAGES, WITH RESPECT TO ANY CLAIM ARISING OUT OF OR IN 
//CONNECTION WITH THE USE OF THE SOFTWARE, EVEN IF IT HAS BEEN OR IS 
//HEREAFTER ADVISED OF THE POSSIBILITY OF SUCH DAMAGES.

// Author: Stelios Paparizos
// e-mail: spapariz@umich.edu
// Summary: This file contains classes associated with the pattern tree.
// The pattern tree and pattern tree node definition as well as any specialized class
// of pattern tree nodes used during parsing or generating the algebraic plan.

using System;
using System.Collections;

namespace Timber.XQueryParser
{
	/// <summary>
	/// Used for pattern trees
	/// </summary>
	internal class PatternTree : Tree
	{
		private ArrayList patternTreeConditions; // the associated conditions with the pattern tree
		private int id;// pattern tree id

		internal PatternTree():base(){id = -1;}

		internal PatternTree(int id):base()	{this.id = id;}


		internal ArrayList getConditions(){return patternTreeConditions;}
		internal void addCondition(PatternTreeNodeCondition patternTreeCondition)
		{
			if (patternTreeConditions == null)
				patternTreeConditions = new ArrayList();
			patternTreeConditions.Add(patternTreeCondition);
		}
		internal void addConditionRange(ArrayList patternTreeConditions)
		{
			if (this.patternTreeConditions == null)
				this.patternTreeConditions = new ArrayList();
			this.patternTreeConditions.AddRange(patternTreeConditions);
		}

		internal int getId(){return this.id;}
		internal void setId(int id){this.id = id;}

		/// <summary>
		/// Convert the tree to a string.
		/// </summary>
		/// <returns>A string representation of the tree</returns>
		internal override string ToStringOut() 
		{
			string s = base.ToStringOut();
			if (patternTreeConditions != null)
			{
				//print all join conditions
				for(int i=0; i<patternTreeConditions.Count;i++)
				{
					PatternTreeNodeCondition pj = (PatternTreeNodeCondition)(patternTreeConditions[i]);
					s += pj.ToStringOut();
				}
			}
			return s;
		}
	}//PatternTree


	/// <summary>
	/// Used for pattern tree nodes
	/// </summary>
	internal class PatternTreeNode : Node
	{
		private string tagName;// the tagname of the node
		private	bool star;	// if it is starred or not (see TAX star)
		private	bool useText;	// if the content or text (ie title/text())
		private int relationWithParent;	// parent, ancestor etc
		private int special; //allows a node to be and, or, extension etc
		private int structuralJoinType; // ? (0-1), - (1), * (0-more), + (1-more)
		private PatternTreeNodeCondition pCondition; // specify the condition on this node (ie year = 1999) 


		private void init()
		{
			tagName = "";
			star = false;
			useText = false;
			relationWithParent = (int)(values.noValue);
			special = (int)(values.noValue);
			structuralJoinType = (int)(values.structuralJoinOne);
		}

		internal PatternTreeNode():base() {this.init();}
		internal PatternTreeNode(int id):base(id) {this.init();}
		internal PatternTreeNode(int id, string tagname):base(id)
		{
			this.tagName = tagname;
			this.star = false;
			this.useText = false;
			relationWithParent = (int)(values.noValue);
			special = (int)(values.noValue);
		}

		internal PatternTreeNode(int id, string tagname, bool starval, int relationWithParent):base(id)
		{
			this.tagName = tagname;
			this.star = starval;
			this.useText = false;
			this.relationWithParent = relationWithParent;
			special = (int)(values.noValue);
		}

		internal PatternTreeNode(int id, string tagname, bool starval, int relationWithParent, int special):base(id)
		{
			this.tagName = tagname;
			this.star = starval;
			this.useText = false;
			this.relationWithParent = relationWithParent;
			this.special = special;
		}


		internal string getTagName(){return tagName;}
		internal void setTagName(string tagname){this.tagName=tagname;}

		internal bool getUseTextValue(){return useText;}
		internal void setUseTextValue(bool useText){this.useText = useText;}

		internal bool getStarVal(){return star;}
		internal void setStarVal(bool starval){this.star=starval;}

		internal int getRelationWithParent(){return relationWithParent;}
		internal void setRelationWithParent(int containment){this.relationWithParent=containment;}

		internal int getSpecial(){return special;}
		internal void setSpecial(int Special){this.special=Special;}

		internal int getStructuralJoinType(){return structuralJoinType;}
		internal void setStructuralJoinType(int structuralJoinType){this.structuralJoinType=structuralJoinType;}

		internal PatternTreeNodeCondition getPatternTreeNodeCondition(){return this.pCondition;}
		internal void setPatternTreeNodeCondition(PatternTreeNodeCondition pc){this.pCondition = pc;}

		internal string getComparisonValue(){if (pCondition!=null) return pCondition.getCompValue(); else return null;}
		internal void setComparisonValue(string comparisonValue)
		{
			if (this.pCondition==null) this.pCondition =  new PatternTreeNodeCondition(this.getId());
			this.pCondition.setCompValue(comparisonValue);
		}

		internal string getComparisonTypeSymbol(){if (pCondition!=null) return pCondition.getCompTypeSymbol(); else return null;}
		internal string getComparisonTypeLetter(){if (pCondition!=null) return pCondition.getCompTypeLetter(); else return null;}
		internal void setComparisonType(string comparisonType)
		{
			if (this.pCondition==null) this.pCondition =  new PatternTreeNodeCondition(this.getId());
			this.pCondition.setCompType(comparisonType);
		}

		internal int getComparisonNodeWID(){if (pCondition!=null) return pCondition.getNodeWID(); else return -1;}
		internal void setComparisonNodeWID(int nodeWID)
		{
			if (this.pCondition==null) this.pCondition =  new PatternTreeNodeCondition(this.getId());
			this.pCondition.setNodeWID(nodeWID);
		}


		internal virtual PatternTreeNode findPatternTreeNode(int WID)
		{
			if (this.getId() == WID) return this;
			ArrayList children = this.getChildren();
			for(int i = 0; i < children.Count; i++)
			{
				PatternTreeNode child = (PatternTreeNode)(children[i]);
				PatternTreeNode ret = child.findPatternTreeNode(WID);
				if (ret.getId() == WID) return ret;
			}
			return this;
		}

		internal virtual int findWIDAtEndOfPath()
		{
			// it should be a path and not a tree
			ArrayList children = this.getChildren();
			if (children.Count > 0) return ((PatternTreeNode)(children[0])).findWIDAtEndOfPath();
			return this.getId();
		}

		/// <summary>
		/// Converts a node to string.
		/// </summary>
		/// <param name="level">The level used for appropriate tabbing</param>
		/// <returns>A string corresponding to the node info</returns>
		internal override string ToStringOut(int level) 
		{
			string s = base.ToStringOut(level);
			s += this.tagName + "\t";
			if (this.relationWithParent == (int)(values.child))
				s += "child";
			else if (this.relationWithParent == (int)(values.descendant))
				s += "descendant";
			else s += "root";
			s += "\t";
			switch (this.structuralJoinType)
			{
				case (int)(values.structuralJoinOne):
					s += "-\t";
					break;
				case (int)(values.structuralJoinOneMore):
					s += "+\t";
					break;
				case (int)(values.structuralJoinZeroOne):
					s += "?\t";
					break;
				case (int)(values.structuralJoinZeroMore):
					s += "*\t";
					break;
			}
			if (this.pCondition != null) s += this.pCondition.ToStringOut() + "\t";
			if (this.useText) s += "text\t";
			if (this.star) s += "star\t";
			if (this.special>0) s += this.special + "\t";
			s += "\n";
			return s;
		}



		internal virtual void getLogicalPlan(
			int nodeCountIn, out int nodeCountOut,
			string nodeStringIn, out string nodeStringOut,
			string treeStringIn, out string treeStringOut,
			ArrayList variableListCurrent) 
		{
			nodeCountOut = nodeCountIn;
			string nodeOutput = nodeStringIn;
			string treeOutput = treeStringIn;

			if(this.tagName.StartsWith("MLCA"))
			{
				//0 MLCA-ROOT
				nodeOutput += this.getId() + " MLCA-ROOT";
			}
			else 
			{
				if(this.tagName.StartsWith("document"))
				{
					//0 DOCUMENT book.xml PARENT -
					int start = this.tagName.IndexOf('"')+1;
					int end = this.tagName.LastIndexOf('"');
					string docname = this.tagName.Substring(start, end-start);
					nodeOutput += this.getId() + " " + "DOCUMENT" + " " + docname + " ";
				}
				else if (this.special == (int)(values.referenceNode))
				{
					//0 REFERENCE 0 PARENT -
					nodeOutput += this.getId() + " " + "REFERENCE" + " " + this.tagName + " "; 
				}
				else
				{
					//0 ELEMENT books1.xml book NULL "" PARENT -
					//2 ELEMENT books1.xml author EQS "John Doe" PARENT -
					string elorattr = " ELEMENT ";
					if (this.special == (int)(values.attribute)) elorattr = " ATTRIBUTE ";
					nodeOutput += this.getId() +  elorattr
						+ HelpFunctions.findDocumentName(this, variableListCurrent) + ".xml " 
						+ this.tagName + " ";
					if (this.pCondition == null)
					{
						nodeOutput += "NULL \"\" ";
					}
					else 
					{
						nodeOutput += this.pCondition.ToStringOut() + " ";
					}
				}

				if (this.getRelationWithParent()==(int)(values.child)) nodeOutput += "PARENT ";
				else nodeOutput += "ANCS ";
				switch (this.structuralJoinType)
				{
					case (int)(values.structuralJoinOne):
						nodeOutput += "-";
						break;
					case (int)(values.structuralJoinOneMore):
						nodeOutput += "+";
						break;
					case (int)(values.structuralJoinZeroOne):
						nodeOutput += "?";
						break;
					case (int)(values.structuralJoinZeroMore):
						nodeOutput += "*";
						break;
				}
			}
				
			nodeOutput += "\n";

			if (nodeCountOut == 0) treeOutput += this.getId() + " -1\n";
			else 
			{
				PatternTreeNode myparent = (PatternTreeNode)(this.getParent());
				treeOutput += this.getId() + " " + myparent.getId() + "\n";
			}

			nodeCountOut++;

			ArrayList children = this.getChildren();
			for(int i=0; i<children.Count; i++)
			{
				PatternTreeNode ptn = ((PatternTreeNode)(children[i]));
				ptn.getLogicalPlan(nodeCountOut, out nodeCountOut, nodeOutput, out nodeOutput, treeOutput, out treeOutput, variableListCurrent);
			}

			nodeStringOut = nodeOutput;
			treeStringOut = treeOutput;
		}

	}//patterntreenode class


	internal class OrPatternTreeNode : PatternTreeNode
	{
		private ArrayList nodes;

		internal OrPatternTreeNode(int id, string tagname):base(id, tagname)
		{
			nodes = new ArrayList();
		}

		internal void addNode(PatternTreeNode node){this.nodes.Add(node);}
		internal void addNodeRange(ICollection node){this.nodes.AddRange(node);}
		internal ArrayList getNodes(){return this.nodes;}

		internal override string ToStringOut(int level) 
		{
			string s = base.ToStringOut(level);
			for(int i=0;i<this.nodes.Count;i++)
			{
				s+= treeString((PatternTreeNode)(this.nodes[i]), level+1);
			}
			s += "\n";
			return s;
		}

		private string treeString(Node node, int level) 
		{
			//string s = new string('\t', level);
			string s = node.ToStringOut(level);
			//s += node.ToStringOut(level);
			//s += "\n";
			ArrayList mylist = node.getChildren();
			for(int i = 0; i < mylist.Count; i++)
			{
				s += this.treeString(((Node)(mylist[i])), level+1);
			}
			return s;
		}

		internal override PatternTreeNode findPatternTreeNode(int WID)
		{
			if (this.getId() == WID) return this;
			for(int i=0;i<this.nodes.Count;i++)
			{
				PatternTreeNode ret = ((PatternTreeNode)(this.nodes[i])).findPatternTreeNode(WID);
				if (ret.getId() == WID) return ret;
			}
			return this;
		}

	}// OrPatternTreeNode class



	/// <summary>
	/// This is used for special kind of pattern tree nodes, eg AND, JOIN, nested Process trees etc
	/// It has 2 child objects used in a special way.
	/// </summary>
	internal class DualPatternTreeNode : PatternTreeNode
	{
		private Node node1;
		private Node node2;

		internal DualPatternTreeNode(
			int id, string tagname, int specialType, 
			Node node1, Node node2):base(id, tagname)
		{
			this.setSpecial(specialType);
			node1.setParent(this);
			this.node1 = node1;
			node2.setParent(this);
			this.node2 = node2;
		}

		internal object getNode1(){return node1;}
		internal void setNode1(Node node1) {node1.setParent(this); this.node1=node1;}
		internal object getNode2(){return node2;}
		internal void setNode2(Node node2) {node2.setParent(this); this.node2=node2;}

		internal override string ToStringOut(int level) 
		{
			string s = base.ToStringOut(level);
			if (this.node1 != null)
			{
				//PatternTreeNode pnode1 = (PatternTreeNode)(this.getNode1());
				s+= treeString((PatternTreeNode)(this.getNode1()), level+1);
			}
			if (this.node2 != null)
			{
				//PatternTreeNode pnode2 = (PatternTreeNode)(this.getNode2());
				//s+= pnode2.ToStringOut(level);
				s+= treeString((PatternTreeNode)(this.getNode2()), level+1);
			}
			s += "\n";
			return s;
		}

		private string treeString(Node node, int level) 
		{
			//string s = new string('\t', level);
			string s = node.ToStringOut(level);
			//s += node.ToStringOut(level);
			//s += "\n";
			ArrayList mylist = node.getChildren();
			for(int i = 0; i < mylist.Count; i++)
			{
				s += this.treeString(((Node)(mylist[i])), level+1);
			}
			return s;
		}


		internal override PatternTreeNode findPatternTreeNode(int WID)
		{
			if (this.getId() == WID) return this;
			PatternTreeNode child1 = (PatternTreeNode)(node1);
			PatternTreeNode ret = child1.findPatternTreeNode(WID);
			if (ret.getId() == WID) return ret;
			PatternTreeNode child2 = (PatternTreeNode)(node2);
			ret = child2.findPatternTreeNode(WID);
			if (ret.getId() == WID) return ret;
			return this;
		}



	}// dualpatterntreenode class


	/// <summary>
	/// A class describing a join condition in a pattern tree.
	/// </summary>
	internal class PatternTreeJoinCondition : PatternTreeNodeCondition
	{
		private int joinWID1; // the wid of the first node
		private int joinWID2; // the wid of the second node
		//private string joinType; // equals etc
		private bool anyLeft; 

		internal PatternTreeJoinCondition(int joinWID1, string joinType, int joinWID2)
		{
			this.joinWID1 = joinWID1;
			this.setCompType(joinType);
			this.joinWID2 = joinWID2;
			this.anyLeft = false;
		}


		internal void setAnyLeft(){this.anyLeft = true;}
		internal bool getAnyLeft(){return this.anyLeft;}
		internal int getJoinWID1(){return joinWID1;}
		internal void setJoinWID1(int joinWID1){this.joinWID1=joinWID1;}
		internal int getJoinWID2(){return joinWID2;}
		internal void setJoinWID2(int joinWID2){this.joinWID2=joinWID2;}
		internal override string getCompTypeLetter()
		{
			// equals and not equals, would do a join comparison
			// less than, greater than would do a number
			string cType = "EQS";
			if (this.getCompTypeSymbol().StartsWith("="))
				cType = "EQS";
			else if (this.getCompTypeSymbol() == "<=")
				cType = "LEN";
			else if (this.getCompTypeSymbol() == ">=")
				cType = "GEN";
			else if (this.getCompTypeSymbol() == "!=")
				cType = "NES";
			else if (this.getCompTypeSymbol().StartsWith("<"))
				cType = "LTN";
			else if (this.getCompTypeSymbol().StartsWith(">"))
				cType = "GTN";
			else if (this.getCompTypeSymbol().EndsWith("not"))
				cType = "ID_NEQ";
			else if (this.getCompTypeSymbol().StartsWith("is"))
				cType = "ID_EQ";
			return cType;
		}
		//internal void setJoinType(string joinType){this.compType=joinType;}

		internal override string ToStringOut()
		{
			return "Join condition:" + this.joinWID1 + " " + this.getCompTypeLetter() + " " + this.joinWID2 + "\n";
		}

		internal override string getInfo()
		{
			//<reference node LCL> <operator> <REF> <LCL> <EVERY | SOME | EXACTLYONE>
			return this.joinWID1 + " " + this.getCompTypeLetter() + " REF " + this.joinWID2 + " " + this.getQuantifier();
		}

	}

	
	
	/// <summary>
	/// Describes a condition on a node (ie year = 1999)
	/// </summary>
	internal class PatternTreeNodeCondition
	{

		private int nodeWID; // the wid of the node
		private string compType; // equals etc
		private string compValue; // the value to compare with
		private string quantifier; // for some, every etc

		
		internal PatternTreeNodeCondition(int nodeWID, string compType, string compValue)
		{
			this.nodeWID = nodeWID;
			this.compType = compType;
			this.compValue = compValue;
			this.quantifier = "SOME";
		}

		internal PatternTreeNodeCondition(int nodeWID)
		{
			this.nodeWID = nodeWID;
			this.quantifier = "SOME";
		}

		internal PatternTreeNodeCondition()	
		{
			this.quantifier = "SOME";
		}


		internal virtual string getCompTypeLetter()
		{
			string beginLetter = "N";
			string cValue = this.compValue.Replace("\"", "");
			try
			{
				float b = float.Parse(cValue);
			}
			catch (FormatException)
			{
				beginLetter = "S";
			}
			string cType = "EQ";
			if (this.compType.StartsWith("="))
				cType = "EQ";
			else if (this.compType == "<=")
				cType = "LE";
			else if (this.compType == ">=")
				cType = "GE";
			else if (this.compType == "!=")
				cType = "NE";
			else if (this.compType.StartsWith("<"))
				cType = "LT";
			else if (this.compType.StartsWith(">"))
				cType = "GT";
			cType += beginLetter;
			return cType;
		}

		internal virtual string getCompTypeSymbol(){return this.compType;}// for =, > etc
		internal void setCompType(string compType){this.compType=compType;}
		internal string getCompValue(){	return compValue.Replace("\"", "");}
		internal void setCompValue(string compValue){this.compValue=compValue;}
		internal int getNodeWID(){return nodeWID;}
		internal void setNodeWID(int nodeWID){this.nodeWID=nodeWID;}
		internal string getQuantifier(){return this.quantifier;}
		internal void setQuantifier(string cV){this.quantifier=cV;}


		internal virtual string ToStringOut()
		{
				return this.getCompTypeLetter() + " " + "\"" + this.getCompValue() + "\"";
		}

		internal virtual string getInfo()
		{
			//<reference node LCL> <operator> <CONST> <value> <EVERY | SOME | EXACTLYONE>
			return this.nodeWID + " " + this.getCompTypeLetter() + " CONST \"" + this.compValue.Trim('"') + "\" " + this.quantifier;
		}
	}



	/// <summary>
	/// Used to create join nodes.
	/// It works as a root containing two pattern trees.
	/// The join is specified by the WIDs of the two nodes.
	/// </summary>
	internal class JoinDualPatternTreeNode : DualPatternTreeNode
	{
		private PatternTreeJoinCondition pJoinCondition;

		internal JoinDualPatternTreeNode(
			int id, string tagname, int specialType, 
			Node node1, Node node2, 
			int joinWID1, string joinType, int joinWID2
			):base(id, tagname + id.ToString(), specialType, node1, node2)
		{
			this.pJoinCondition = new PatternTreeJoinCondition(joinWID1, joinType, joinWID2);
		}

		internal void setAnyLeft(){this.pJoinCondition.setAnyLeft();}
		internal bool getAnyLeft(){return this.pJoinCondition.getAnyLeft();}
		internal int getJoinWID1(){return pJoinCondition.getJoinWID1();}
		internal void setJoinWID1(int joinWID1){pJoinCondition.setJoinWID1(joinWID1);}
		internal int getJoinWID2(){return pJoinCondition.getJoinWID2();}
		internal void setJoinWID2(int joinWID2){pJoinCondition.setJoinWID2(joinWID2);}
		internal string getJoinType(){return pJoinCondition.getCompTypeLetter();}
		internal void setJoinType(string joinType){pJoinCondition.setCompType(joinType);}
		internal PatternTreeJoinCondition getJoinCondition(){return pJoinCondition;}
		internal void setJoinCondition(PatternTreeJoinCondition pjCondition){this.pJoinCondition = pjCondition;}

		internal override string ToStringOut(int level) 
		{
			string s = base.ToStringOut(level);
			s += this.pJoinCondition.ToStringOut();
			return s;
		}

		internal override void getLogicalPlan(
			int nodeCountIn, out int nodeCountOut,
			string nodeStringIn, out string nodeStringOut,
			string treeStringIn, out string treeStringOut,
			ArrayList variableListCurrent) 
		{
			nodeCountOut = nodeCountIn;
			string nodeOutput = nodeStringIn;
			string treeOutput = treeStringIn;

			if(this.getSpecial() == (int)(values.cartesianProduct)) 
				// cartesian product
				//35 CARTESIAN
				nodeOutput += this.getId() + " " + "CARTESIAN" + " ";
			else // regular join
			{
				//35 VALUEJOIN 3 STR_EQ 1
				//<value join pattern tree node> := <node id> VALUEJOIN <ANY|ONE> <left node LCL> <operator> <right node LCL>
				nodeOutput += this.getId() + " " + "VALUEJOIN" + " ";
				if (this.getAnyLeft()) nodeOutput += "ANY "; 
				else nodeOutput += "ONE "; 
				int WID1 = this.getJoinWID1();
				int WID2 = this.getJoinWID2();

				nodeOutput += WID1.ToString() + " " + this.getJoinType() + " " + WID2.ToString();
			}
			nodeOutput += "\n";

			if (nodeCountOut == 0) treeOutput += this.getId() + " -1\n";
			else treeOutput += this.getId() + " " + this.getParent().getId() + "\n";

			nodeCountOut++;

			PatternTreeNode ptn1 = (PatternTreeNode)(this.getNode1());
			ptn1.getLogicalPlan(
				nodeCountOut, out nodeCountOut, nodeOutput, out nodeOutput, treeOutput, out treeOutput, variableListCurrent);
			PatternTreeNode ptn2 = (PatternTreeNode)(this.getNode2());
			ptn2.getLogicalPlan(
				nodeCountOut, out nodeCountOut, nodeOutput, out nodeOutput, treeOutput, out treeOutput, variableListCurrent);

			nodeStringOut = nodeOutput;
			treeStringOut = treeOutput;
		}

	}//JoinDualPatternTreeNode

	
	/// <summary>
	/// Used to generate the construct tree
	/// </summary>
	internal class ConstructElementPatternTreeNode : ConstructReferencePatternTreeNode
	{
		private string enclosingTagName; // there is tag name (ie <result>)
		private ArrayList attributeList; // the attributes of this node
		private ArrayList contentList;   // the content of the node


		internal ConstructElementPatternTreeNode(int id):base(id)
		{
			this.setTagName("CONSTRUCT");
			this.setSpecial((int)(values.constructNode));
			attributeList = new ArrayList();
			contentList = new ArrayList();
		}

		internal ArrayList getAttributeList(){return attributeList;}
		internal void setAttributeList(ArrayList attributeList){this.attributeList = attributeList;}
		internal void addAttribute(object attribute){attributeList.Add(attribute);}
		internal void addRangeAttribute(ArrayList attributes){attributeList.AddRange(attributes);}


		internal ArrayList getContentList(){return contentList;}
		internal void setContentList(ArrayList contentList){this.contentList = contentList;}
		internal void addContent(object content){contentList.Add(content);}
		internal void addRangeContent(ArrayList contents){contentList.AddRange(contents);}

		internal string getEnclosingTagName(){return enclosingTagName;}
		internal void setEnclosingTagName(string enclosingTagName){this.enclosingTagName=enclosingTagName;}

		internal override PatternTreeNode findPatternTreeNode(int WID)
		{
			if (this.getId() == WID) return this;

			for(int i = 0; i < this.contentList.Count; i++)
			{
				PatternTreeNode child = (PatternTreeNode)(this.contentList[i]);
				PatternTreeNode ret = child.findPatternTreeNode(WID);
				if (ret.getId() == WID) return ret;
			}
			for(int i = 0; i < this.attributeList.Count; i++)
			{
				PatternTreeNode child = (PatternTreeNode)(this.attributeList[i]);
				PatternTreeNode ret = child.findPatternTreeNode(WID);
				if (ret.getId() == WID) return ret;
			}

			ArrayList children = this.getChildren();
			for(int i = 0; i < children.Count; i++)
			{
				PatternTreeNode child = (PatternTreeNode)(children[i]);
				PatternTreeNode ret = child.findPatternTreeNode(WID);
				if (ret.getId() == WID) return ret;
			}
			return this;
		}


		/// <summary>
		/// Convert the node to string.
		/// </summary>
		/// <param name="level">The level of the node in the tree</param>
		/// <returns>A string containing the node information</returns>
		internal override string ToStringOut(int level) 
		{
			string s = base.ToStringOut(level);
			s += new string('\t', level+1);
			s += "<" + this.enclosingTagName + ">";
			s += "\n";
			if (this.attributeList.Count != 0)
			{
				for(int i=0; i<this.attributeList.Count; i++)
					if (this.attributeList[i] != null)
						s+= treeString((PatternTreeNode)(this.attributeList[i]), level+1);
			}
			if (this.contentList.Count != 0)
			{
				for(int i=0; i<this.contentList.Count; i++)
				if (this.contentList[i] != null)
					s+= treeString((PatternTreeNode)(this.contentList[i]), level+1);
			}
			s += new string('\t', level+1);
			s += "</" + this.enclosingTagName + ">";
			s += "\n";
			return s;
		}

		private string treeString(Node node, int level) 
		{
			//string s = new string(' ', level);
			string s = node.ToStringOut(level);
			//s += node.ToStringOut(level);
			//s += "\n";
			ArrayList mylist = node.getChildren();
			for(int i = 0; i < mylist.Count; i++)
			{
				//s += " child:" + i + " ";
				s += this.treeString(((Node)(mylist[i])), level+1);
			}
			return s;
		}
	
		internal override void getLogicalConstructPlan(
			int nodeCountIn, out int nodeCountOut,
			string nodeStringIn, out string nodeStringOut,
			string treeStringIn, out string treeStringOut,
			ArrayList variableListCurrent) 
		{
			nodeCountOut = nodeCountIn;
			string nodeOutput = nodeStringIn;
			string treeOutput = treeStringIn;
			//40 CONSTR_ELEMENT_HK result
				
			//<c_tag pattern tree node> := <node id> <C_ELEMENT | C_ATTR> <tagname> 
			nodeOutput += this.getId() + " " + "C_ELEMENT " + this.enclosingTagName + "\n";
			if (nodeCountOut == 0)
				treeOutput += this.getId() + " -1\n";
			else
			{
				treeOutput += this.getId() + " " + this.getParent().getId() + "\n";
			}
			nodeCountOut++;
			nodeStringOut = nodeOutput;
			treeStringOut = treeOutput;

			if (this.attributeList != null)
			{
				for(int i=0; i< this.attributeList.Count; i++)
				{
					ConstructReferencePatternTreeNode ptn = (ConstructReferencePatternTreeNode)(this.attributeList[i]);
					if (ptn!= null)
					{
						ptn.setParent(this);
						ptn.getLogicalConstructPlan(
							nodeCountOut, out nodeCountOut,
							nodeStringOut, out nodeStringOut,
							treeStringOut, out treeStringOut,
							variableListCurrent) ;
					}

				}
			}

			if (this.contentList != null)
			{
				for(int i=0; i< this.contentList.Count; i++)
				{
					ConstructReferencePatternTreeNode ptn = (ConstructReferencePatternTreeNode)(this.contentList[i]);
					if (ptn!= null)
					{
						ptn.setParent(this);
						ptn.getLogicalConstructPlan(
							nodeCountOut, out nodeCountOut,
							nodeStringOut, out nodeStringOut,
							treeStringOut, out treeStringOut,
							variableListCurrent) ;
					}
				}
			}
		}//getLogicalConstructPlan


	}//ConstructElementPatternTreeNode



	/// <summary>
	/// Used to generate the attributes for the construct tree
	/// </summary>
	internal class ConstructAttributePatternTreeNode : ConstructReferencePatternTreeNode
	{

		internal ConstructAttributePatternTreeNode(int id):base(id)
		{
			this.attributeName = "empty";
			myNode = new PatternTreeNode();
		}

		private string attributeName; // tag name (ie <result id={$b/title}>)
		internal string getAttributeTagName(){return attributeName;}
		internal void setAttributeTagName(string attributeName){this.attributeName=attributeName;}

		private PatternTreeNode myNode; // for the $b/title part
		internal PatternTreeNode getMyNode() {return myNode;}
		internal void setMyNode(PatternTreeNode newval) {myNode=newval;}


		/// <summary>
		/// Convert the node to string.
		/// </summary>
		/// <param name="level">The level of the node in the tree</param>
		/// <returns>A string containing the node information</returns>
		internal override string ToStringOut(int level) 
		{
			string s = new string('\t', level);
			s += this.getId() + " " + this.attributeName + " =\n";
			s += treeString(myNode, level+1);
			return s;
		}

		private string treeString(Node node, int level) 
		{
			//string s = new string('\t', level);
			string s = node.ToStringOut(level);
			ArrayList mylist = node.getChildren();
			for(int i = 0; i < mylist.Count; i++)
			{
				s += this.treeString(((Node)(mylist[i])), level+1);
			}
			return s;
		}


		internal override void getLogicalConstructPlan(
			int nodeCountIn, out int nodeCountOut,
			string nodeStringIn, out string nodeStringOut,
			string treeStringIn, out string treeStringOut,
			ArrayList variableListCurrent) 
		{
			nodeCountOut = nodeCountIn;
			string nodeOutput = nodeStringIn;
			string treeOutput = treeStringIn;

			//<c_attribute pattern tree node> := <node id> C_ATTRIBUTE <tagname> <Reference LCL> <TEXT|SUBTREE>
			//<c_attribute pattern tree node> := <node id> C_ATTRIBUTE <tagname> <Reference LCL>
				
			nodeOutput += this.getId() + " C_ATTRIBUTE " + this.attributeName + " " + this.myNode.getTagName();
//			if (this.myNode.getUseTextValue()) nodeOutput += " TEXT";
//			else nodeOutput += " SUBTREE";
			nodeOutput += "\n";

			if (nodeCountOut == 0)
				treeOutput += this.getId() + " -1\n";
			else
			{
				treeOutput += this.getId() + " " + this.getParent().getId() + "\n";
			}
			nodeCountOut++;
			nodeStringOut = nodeOutput;
			treeStringOut = treeOutput;

		}//getLogicalConstructPlan

	}//ConstructAttributePatternTreeNode


	/// <summary>
	/// Used for pattern tree nodes
	/// </summary>
	internal class ConstructReferencePatternTreeNode : PatternTreeNode
	{
		private bool isNode;
		private bool isOuter;

		internal ConstructReferencePatternTreeNode(int id):base(id) {this.isNode = false;}
		internal ConstructReferencePatternTreeNode(int id, string tagname, bool starval, int relationWithParent, int special):base(id, tagname, starval, relationWithParent, special){this.isNode = false;}

		internal void setNode(){this.isNode = true;}
		internal bool getNode(){return this.isNode;}
		internal void setOuter(){this.isOuter = true;}
		internal bool getOuter(){return this.isOuter;}

		internal virtual void getLogicalConstructPlan(
			int nodeCountIn, out int nodeCountOut,
			string nodeStringIn, out string nodeStringOut,
			string treeStringIn, out string treeStringOut,
			ArrayList variableListCurrent) 
		{
			nodeCountOut = nodeCountIn;
			string nodeOutput = nodeStringIn;
			string treeOutput = treeStringIn;

			if (this.getSpecial() == (int)(values.referenceNode))
			{
				//<c_reference pattern tree node> := <node id> C_REFERENCE <Reference LCL> <TEXT|SUBTREE>  
				nodeOutput += this.getId() + " C_REFERENCE " + this.getTagName(); 
				if (this.isNode) nodeOutput += " NODE\n";
				else if (this.isOuter) nodeOutput += " OUTER\n";
				else if (this.getUseTextValue()) nodeOutput += " TEXT\n";
				else nodeOutput += " SUBTREE\n";
			}

			if (nodeCountOut == 0) treeOutput += this.getId() + " -1\n";
			else treeOutput += this.getId() + " " + this.getParent().getId() + "\n";
			
			nodeCountOut++;

			ArrayList children = this.getChildren();
			for(int i=0; i<children.Count; i++)
			{
				ConstructReferencePatternTreeNode ptn = ((ConstructReferencePatternTreeNode)(children[i]));
				ptn.getLogicalConstructPlan(nodeCountOut, out nodeCountOut, nodeOutput, out nodeOutput, treeOutput, out treeOutput, variableListCurrent);
			}
		
			nodeStringOut = nodeOutput;
			treeStringOut = treeOutput;
		
		}//getLogicalConstructPlan

	}//ConstructReferencePatternTreeNode class


	internal class QuantifiedPatternTreeNode : PatternTreeNode
	{
		private PatternTree myTree; // for the $b/title part
		private int subtype; // some or every
		private int countWid;

		internal QuantifiedPatternTreeNode(int id):base(id){}

		internal PatternTree getPatternTree() {return this.myTree;}
		internal void setPatternTree(PatternTree newval) {this.myTree=newval;}

		internal void setSubType(int newval){this.subtype = newval;}
		internal int getSubType() {return this.subtype;}

		internal void setCountWid(int newval){this.countWid = newval;}
		internal int getCountWid() {return this.countWid;}

		/// <summary>
		/// Convert the node to string.
		/// </summary>
		/// <param name="level">The level of the node in the tree</param>
		/// <returns>A string containing the node information</returns>
		internal override string ToStringOut(int level) 
		{
			string s = new string('\t', level);
			s += this.getId() + " \n";
			s += treeString(this.myTree.getRoot(), level+1);
			return s;
		}

		private string treeString(Node node, int level) 
		{
			//string s = new string('\t', level);
			string s = node.ToStringOut(level);
			ArrayList mylist = node.getChildren();
			for(int i = 0; i < mylist.Count; i++)
			{
				s += this.treeString(((Node)(mylist[i])), level+1);
			}
			return s;
		}
	}//QuantifiedPatternTreeNode

	internal class SortPatternTreeNode : PatternTreeNode
	{
		private int sortByType; //<sort option> := SORT_BY_KEY | SORT_BY_VALUE 
		private int sortOrder; // <sort order> := ASCENDING | DESCENDING
		private int emptyleast; // for empty greatest or empty least
		private PatternTreeNode myNode;

		internal SortPatternTreeNode(int id):base(id)
		{
			this.sortByType = (int)(values.sortByValue);
			this.sortOrder = (int)(values.sortAscending);
			this.emptyleast = (int)(values.sortEmptyGreatest);
			myNode = new PatternTreeNode();
		}


		internal void setSortByType(int sbType){this.sortByType = sbType;}
		internal int getSortByType(){return this.sortByType;}
		internal void setSortOrder(int sortOrder){this.sortOrder = sortOrder;}
		internal int getSortOrder(){return this.sortOrder;}
		internal void setEmptyLeast(int emptyleast){this.emptyleast = emptyleast;}
		internal int getEmptyLeast(){return this.emptyleast;}
		internal PatternTreeNode getMyNode() {return myNode;}
		internal void setMyNode(PatternTreeNode newval) {myNode=newval;}



		/// <summary>
		/// Convert the node to string.
		/// </summary>
		/// <param name="level">The level of the node in the tree</param>
		/// <returns>A string containing the node information</returns>
		internal override string ToStringOut(int level) 
		{
			string s = new string('\t', level);
			s += this.getId() + " \n";
			s += treeString(myNode, level+1);
			return s;
		}

		private string treeString(Node node, int level) 
		{
			//string s = new string('\t', level);
			string s = node.ToStringOut(level);
			ArrayList mylist = node.getChildren();
			for(int i = 0; i < mylist.Count; i++)
			{
				s += this.treeString(((Node)(mylist[i])), level+1);
			}
			return s;
		}
	}//SortPatternTreeNode


	internal class AggregatePatternTreeNode : PatternTreeNode
	{

		internal AggregatePatternTreeNode(int id):base(id)
		{
			this.functionName = "empty";
			myNode = new PatternTreeNode();
		}

		private string functionName; 
		internal string getFunctionName(){return functionName;}
		internal void setFunctionName(string functionName){this.functionName=functionName;}

		private PatternTreeNode myNode; // for the $b/title part
		internal PatternTreeNode getMyNode() {return myNode;}
		internal void setMyNode(PatternTreeNode newval) {myNode=newval;}


		/// <summary>
		/// Convert the node to string.
		/// </summary>
		/// <param name="level">The level of the node in the tree</param>
		/// <returns>A string containing the node information</returns>
		internal override string ToStringOut(int level) 
		{
			string s = new string('\t', level);
			s += this.getId() + " " + this.functionName + " \n";
			s += treeString(myNode, level+1);
			return s;
		}

		private string treeString(Node node, int level) 
		{
			//string s = new string('\t', level);
			string s = node.ToStringOut(level);
			ArrayList mylist = node.getChildren();
			for(int i = 0; i < mylist.Count; i++)
			{
				s += this.treeString(((Node)(mylist[i])), level+1);
			}
			return s;
		}
	}//AggregatePatternTreeNode

	internal class DeletePatternTreeNode : PatternTreeNode
	{

		internal DeletePatternTreeNode(int id):base(id)
		{
			myNode = new PatternTreeNode();
		}

		private PatternTreeNode myNode; // for the $b/title part
		internal PatternTreeNode getMyNode() {return myNode;}
		internal void setMyNode(PatternTreeNode newval) {myNode=newval;}


		/// <summary>
		/// Convert the node to string.
		/// </summary>
		/// <param name="level">The level of the node in the tree</param>
		/// <returns>A string containing the node information</returns>
		internal override string ToStringOut(int level) 
		{
			string s = new string('\t', level);
			s += this.getId() + " DELETE \n";
			s += treeString(myNode, level+1);
			return s;
		}

		private string treeString(Node node, int level) 
		{
			//string s = new string('\t', level);
			string s = node.ToStringOut(level);
			ArrayList mylist = node.getChildren();
			for(int i = 0; i < mylist.Count; i++)
			{
				s += this.treeString(((Node)(mylist[i])), level+1);
			}
			return s;
		}
	}

	internal class UpdatePatternTreeNode : PatternTreeNode
	{

		internal UpdatePatternTreeNode(int id):base(id){}

		private PatternTreeNode myNode1; // for the $b/title part
		internal PatternTreeNode getMyNode1() {return myNode1;}
		internal void setMyNode1(PatternTreeNode newval) {myNode1=newval;}
		private PatternTreeNode myNode2; // for the $b/title part
		internal PatternTreeNode getMyNode2() {return myNode2;}
		internal void setMyNode2(PatternTreeNode newval) {myNode2=newval;}


		/// <summary>
		/// Convert the node to string.
		/// </summary>
		/// <param name="level">The level of the node in the tree</param>
		/// <returns>A string containing the node information</returns>
		internal override string ToStringOut(int level) 
		{
			string s = new string('\t', level);
			s += this.getId() + " UPDATE \n";
			s += treeString(myNode1, level+1);
			return s;
		}

		private string treeString(Node node, int level) 
		{
			//string s = new string('\t', level);
			string s = node.ToStringOut(level);
			ArrayList mylist = node.getChildren();
			for(int i = 0; i < mylist.Count; i++)
			{
				s += this.treeString(((Node)(mylist[i])), level+1);
			}
			return s;
		}
	}


	internal class InsertPatternTreeNode : PatternTreeNode
	{

		private PatternTreeNode myNode; // for the $b/title part
		private string fileName;
		private ArrayList myList;  // for element contenct etc

		internal InsertPatternTreeNode(int id):base(id)
		{
			this.myNode = new PatternTreeNode();
			this.myList = new ArrayList();
		}

		internal string getFileName() {return this.fileName;}
		internal void setFileName(string newval) {this.fileName=newval;}
		internal PatternTreeNode getMyNode() {return myNode;}
		internal void setMyNode(PatternTreeNode newval) {this.myNode = newval;}
		internal void addToList(InsertObject io){this.myList.Add(io);}
		internal ArrayList getList(){return this.myList;}


		/// <summary>
		/// Convert the node to string.
		/// </summary>
		/// <param name="level">The level of the node in the tree</param>
		/// <returns>A string containing the node information</returns>
		internal override string ToStringOut(int level) 
		{
			string s = new string('\t', level);
			s += this.getId() + " INSERT \n";
			s += treeString(myNode, level+1);
			return s;
		}

		private string treeString(Node node, int level) 
		{
			//string s = new string('\t', level);
			string s = node.ToStringOut(level);
			ArrayList mylist = node.getChildren();
			for(int i = 0; i < mylist.Count; i++)
			{
				s += this.treeString(((Node)(mylist[i])), level+1);
			}
			return s;
		}
	}

	internal class MLCAPatternTreeNode : PatternTreeNode
	{

		private PatternTree myTree; // for the mlca pattern tree
		private ArrayList nodes;

		internal MLCAPatternTreeNode(int id):base(id)
		{
			this.nodes = new ArrayList();
		}


		internal void addBoundNode(int wid){this.nodes.Add(wid);}
		internal void setBoundNodes(ArrayList newval){this.nodes = newval;}
		internal ArrayList getBoundNodes() {return this.nodes;}

		internal PatternTree getPatternTree() {return this.myTree;}
		internal void setPatternTree(PatternTree newval) {this.myTree=newval;}


		/// <summary>
		/// Convert the node to string.
		/// </summary>
		/// <param name="level">The level of the node in the tree</param>
		/// <returns>A string containing the node information</returns>
		internal override string ToStringOut(int level) 
		{
			string s = new string('\t', level);
			s += this.getId() + " MLCA \n";
			s += treeString(this.myTree.getRoot(), level+1);
			return s;
		}

		private string treeString(Node node, int level) 
		{
			//string s = new string('\t', level);
			string s = node.ToStringOut(level);
			ArrayList mylist = node.getChildren();
			for(int i = 0; i < mylist.Count; i++)
			{
				s += this.treeString(((Node)(mylist[i])), level+1);
			}
			return s;
		}

	}


}