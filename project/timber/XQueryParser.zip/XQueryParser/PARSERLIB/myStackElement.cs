using System;
using System.Collections;

namespace Timber.XQueryParser
{
	/// <summary>
	/// Summary description for myStackElement.
	/// Provides Stack functionality for the parser.
	/// Used to pass around information when needed.
	/// </summary>
	internal class myStackElement //: SSVParseLib.SSYaccStackElement
	{
		object myValue;

		//public MyStackElement() { m_value = 0;}
		internal object value() { return myValue;}
		internal void setValue( object q_value) { myValue = q_value;}

		string myName;

		internal string getMyName() {return myName;}
		internal void setMyName(string newval) {myName=newval;}

		Node myNode;
		internal Node getMyNode() {return myNode;}
		internal void setMyNode(Node newval) {myNode=newval;}

		Tree myTree;
		internal Tree getMyTree() {return myTree;}
		internal void setMyTree(Tree newval) {myTree=newval;}

		ArrayList myList;
		internal ArrayList getMyList() {return myList;}
		internal void setMyList(ArrayList o) {myList = o;}
		internal void addToMyList(object o) {myList.Add(o);}
		internal void addRangeToMyList(ArrayList o) {myList.AddRange(o);}

		internal myStackElement()
		{
			//
			// TODO: Add constructor logic here
			//
			//myValue = new Object();
			//myTree = new Tree();
			//myNode = new PatternTreeNode();
			myList = new ArrayList();
			myName = "empty";
		}
	}



}



