//COPYRIGHT  � 2000-2004 
//THE REGENTS OF THE UNIVERSITY OF MICHIGAN
//ALL RIGHTS RESERVED
//
//PERMISSION IS GRANTED TO USE, COPY, CREATE DERIVATIVE WORKS AND REDISTRIBUTE 
//THIS SOFTWARE AND SUCH DERIVATIVE WORKS FOR NONCOMMERCIAL EDUCATION AND 
//RESEARCH PURPOSES, SO LONG AS NO FEE IS CHARGED, AND SO LONG AS THE 
//COPYRIGHT NOTICE ABOVE, THIS GRANT OF PERMISSION, AND THE DISCLAIMER 
//BELOW APPEAR IN ALL COPIES MADE; AND SO LONG AS THE NAME OF THE UNIVERSITY 
//OF MICHIGAN IS NOT USED IN ANY ADVERTISING OR PUBLICITY PERTAINING TO THE 
//USE OR DISTRIBUTION OF THIS SOFTWARE WITHOUT SPECIFIC, WRITTEN PRIOR AUTHORIZATION.
//
//THIS SOFTWARE IS PROVIDED AS IS, WITHOUT REPRESENTATION FROM THE UNIVERSITY 
//OF MICHIGAN AS TO ITS FITNESS FOR ANY PURPOSE, AND WITHOUT WARRANTY BY THE 
//UNIVERSITY OF MICHIGAN OF ANY KIND, EITHER EXPRESS OR IMPLIED, INCLUDING 
//WITHOUT LIMITATION THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS 
//FOR A PARTICULAR PURPOSE. THE REGENTS OF THE UNIVERSITY OF MICHIGAN SHALL 
//NOT BE LIABLE FOR ANY DAMAGES, INCLUDING SPECIAL, INDIRECT, INCIDENTAL, 
//OR CONSEQUENTIAL DAMAGES, WITH RESPECT TO ANY CLAIM ARISING OUT OF OR IN 
//CONNECTION WITH THE USE OF THE SOFTWARE, EVEN IF IT HAS BEEN OR IS 
//HEREAFTER ADVISED OF THE POSSIBILITY OF SUCH DAMAGES.

// Author: Stelios Paparizos
// e-mail: spapariz@umich.edu
// Summary: Used as the main class for the parser that is seen to anybody using the library.
// It provides the option to parse an Xquery in string or in file and returns the logical algebra string.


using System;

namespace Timber.XQueryParser
{
	/// <summary>
	/// Summary description for XQParser.
	/// </summary>
	public class XQParser
	{
		/// <summary>
		/// Constructor, empty.
		/// </summary>
		public XQParser(){}

		/// <summary>
		/// Input XQuery, output Logical plan
		/// </summary>
		/// <param name="query">The input XQuery in string format</param>
		/// <param name="showOutput">How much of the internal parsing output to be shown on the Console. Pass 0 for nothing.</param>
		/// <returns>Logical Plan in string</returns>
		public string parseString(string query, int showOutput)
		{
			// create new parser object
			Timber.XQueryParser.InternalXQParser myParser = new InternalXQParser();
			string output = myParser.parse(query, true);
			if (showOutput > 0) this.processParseOutput(myParser, showOutput);
			return output;
		}

		/// <summary>
		/// Input XQuery, output Logical plan
		/// </summary>
		/// <param name="queryFileName">The filename for the input XQuery</param>
		/// <param name="showOutput">How much of the internal parsing output to be shown on the Console. Pass 0 for nothing.</param>
		/// <returns>Logical Plan in string</returns>
		public string parseFile(string queryFileName, int showOutput)
		{
			// create new parser object
			Timber.XQueryParser.InternalXQParser myParser = new InternalXQParser();
			string output = myParser.parse(queryFileName, false);
			if (showOutput > 0) this.processParseOutput(myParser, showOutput);
			return output;
		}
	
		/// <summary>
		/// Internal function that processes the output of the parser and generates an execution plan
		/// </summary>
		/// <param name="myparser">The parser object</param>
		/// <param name="showOutput">A flag describing what debug information to output to screen</param>
		/// <returns>An execution plan or an error message</returns>
		private string processParseOutput(InternalXQParser myparser, int showOutput)
		{
			string FLWRStmt = myparser.reproducedQuery;

			if (showOutput >= 5)
			{
				Console.WriteLine("Parse String:\n");
				Console.WriteLine(myparser.parseString);
				Console.WriteLine();
			}
			if (showOutput >= 4)
			{
				Console.WriteLine("Internal String:\n");
				Console.WriteLine(myparser.internalString);
				Console.WriteLine();
			}
			if (showOutput >= 3)
			{
				Console.WriteLine("Error String:\n");
				Console.WriteLine(myparser.parseErrorString);
				Console.WriteLine();
			}
			if (showOutput >= 2)
			{
				Console.WriteLine("\nProcess Tree\n");
				ProcessTree fpt = new ProcessTree();
				fpt.setRoot(myparser.processTreeNode);
				Console.WriteLine(fpt.ToStringOut());
			}

			if (showOutput >= 1)
			{
				Console.WriteLine("\nReproduced query\n");
				Console.WriteLine(FLWRStmt);
				Console.WriteLine("\nVariable Mappings\n");
				Console.WriteLine(myparser.variableString);
			}


			return "success";
		}//processParseOutput
	}// parser class
}
