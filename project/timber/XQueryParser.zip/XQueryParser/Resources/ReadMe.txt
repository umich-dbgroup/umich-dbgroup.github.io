
NOTE: To compile and execute the parser library:

Please make sure that the file called "xquery.cgt" 
is copied in the directory where your executable 
(that references parserlib.dll) will be found.
For the web service the "xquery.cgt" file has to be copied
to <windowsdir>/system32 because Internet Information Server is the executable
and assumes that as its local directory.

eg 
copy to (currentdir)\parserrun\bin\release

