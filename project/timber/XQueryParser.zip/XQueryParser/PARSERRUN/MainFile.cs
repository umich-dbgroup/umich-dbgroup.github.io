//COPYRIGHT  � 2000-2004 
//THE REGENTS OF THE UNIVERSITY OF MICHIGAN
//ALL RIGHTS RESERVED
//
//PERMISSION IS GRANTED TO USE, COPY, CREATE DERIVATIVE WORKS AND REDISTRIBUTE 
//THIS SOFTWARE AND SUCH DERIVATIVE WORKS FOR NONCOMMERCIAL EDUCATION AND 
//RESEARCH PURPOSES, SO LONG AS NO FEE IS CHARGED, AND SO LONG AS THE 
//COPYRIGHT NOTICE ABOVE, THIS GRANT OF PERMISSION, AND THE DISCLAIMER 
//BELOW APPEAR IN ALL COPIES MADE; AND SO LONG AS THE NAME OF THE UNIVERSITY 
//OF MICHIGAN IS NOT USED IN ANY ADVERTISING OR PUBLICITY PERTAINING TO THE 
//USE OR DISTRIBUTION OF THIS SOFTWARE WITHOUT SPECIFIC, WRITTEN PRIOR AUTHORIZATION.
//
//THIS SOFTWARE IS PROVIDED AS IS, WITHOUT REPRESENTATION FROM THE UNIVERSITY 
//OF MICHIGAN AS TO ITS FITNESS FOR ANY PURPOSE, AND WITHOUT WARRANTY BY THE 
//UNIVERSITY OF MICHIGAN OF ANY KIND, EITHER EXPRESS OR IMPLIED, INCLUDING 
//WITHOUT LIMITATION THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS 
//FOR A PARTICULAR PURPOSE. THE REGENTS OF THE UNIVERSITY OF MICHIGAN SHALL 
//NOT BE LIABLE FOR ANY DAMAGES, INCLUDING SPECIAL, INDIRECT, INCIDENTAL, 
//OR CONSEQUENTIAL DAMAGES, WITH RESPECT TO ANY CLAIM ARISING OUT OF OR IN 
//CONNECTION WITH THE USE OF THE SOFTWARE, EVEN IF IT HAS BEEN OR IS 
//HEREAFTER ADVISED OF THE POSSIBILITY OF SUCH DAMAGES.

// Author: Stelios Paparizos
// e-mail: spapariz@umich.edu


using System;
using System.IO;

namespace Timber.RunParser
{
	/// <summary>
	/// The main class for running/testing the xquery parser
	/// </summary>
	class RunParser
	{
		/// <summary>
		/// The main entry point for the application.
		/// </summary>
		[STAThread]
		static void Main(string[] args)
		{
			if (args.Length == 0)
			{
				Console.WriteLine( "Logical Plan Generation:\nUsage  : Executable -l -i xquery -o LogicalPlan\n" );
				Console.WriteLine( "XML Output (make sure a local soar server is running)\nUsage  : Executable -x -i xquery -o xml [-t timeoutinmsecs]\n" );
				//-i d:\xqparser\xquery1.txt -o d:\xqparser\ex1.pln
				return;
			}
			if (args[0] == "-l")
			{
				RunParser t1 = new RunParser();
				int res = t1.runFileQuery(args, false);
			}
			else if (args[0] == "-x")
			{
				RunParser t1 = new RunParser();
				int res = t1.runFileQuery(args, true);
			}
			else if (args[0] == "-d")
			{
				RunParser t1 = new RunParser();
				int res = t1.runFileQuery(args, false);
				Console.WriteLine("\nHit enter to continue...");
				Console.ReadLine();
			}
			else
			{
				Console.WriteLine( "Logical Plan Generation:\nUsage  : Executable -l -i xquery -o LogicalPlan\n" );
				Console.WriteLine( "XML Output (make sure a local soar server is running)\nUsage  : Executable -x -i xquery -o xml [-t timeoutinmsecs]\n" );
				//-i d:\xqparser\xquery1.txt -o d:\xqparser\ex1.pln
				return;
			}

			return;
		}// end main


		/// <summary>
		/// Given an xquery statement, produce a logical algebra plan or an error message.
		/// </summary>
		/// <param name="queryFileName">The input xquery file name</param>
		/// <param name="showOutput">A flag, output to screen debug information, pass 0 for nothing.</param>
		/// <returns>An execution plan or an error message</returns>		
		internal string getXQLogicalPlanFromFile(string queryFileName, int showOutput)
		{
			// generate a string for the input xquery statement
			String q = String.Empty;
			if ( queryFileName != String.Empty ) 
			{                
				try
				{
					FileStream fs = new FileStream(queryFileName, FileMode.Open, FileAccess.Read);
					StreamReader sr = new StreamReader(fs);
					q = sr.ReadToEnd();
					sr.Close();
				}
				catch (Exception e)
				{
					return "ERROR: Query file does not exist!\n\n" + e.ToString();
				}
			}
			else return "ERROR: Query file does not exist!";

			// create a parser object
			Timber.XQueryParser.XQParser myparser = new Timber.XQueryParser.XQParser();
			// parse an xquery statement, create an execution plan
			string LogicalPlan = myparser.parseString(q, showOutput);
			return LogicalPlan;
		}


		/// <summary>
		/// Used to execute a query when the xquery input and the output are local files
		/// </summary>
		/// <param name="args">The parameteres the program was called with</param>
		/// <param name="xmlB">Generate an execution plan or an xml file</param>
		/// <returns>0 if success, -1 if something went wrong</returns>
		internal int runFileQuery(string[] args, bool xmlB)
		{

			String xQueryFileName = String.Empty;        
			String outputFileName = String.Empty;                
			int showOutput = 0;
			int timeout = 330000;

			for ( int i = 0; i < args.Length; i++ ) 
			{
				String arg = args[i];
				if ( arg[0] == '-' ) 
				{
					switch ( arg[1] ) 
					{
						case 'i':
							i++;
							if ( i < args.Length )
								xQueryFileName = args[i];
							break;
						case 'o':
							i++;
							if ( i < args.Length )
								outputFileName = args[i];
							break;
						case 'd':
							i++;
							if ( i < args.Length )
								showOutput = int.Parse(args[i]);
							break;
						case 't':
							i++;
							if ( i < args.Length )
								timeout = int.Parse(args[i]);
							break;
						default:
							break;
					}
				}
			}


			if ( String.Empty == xQueryFileName || String.Empty == outputFileName )  
			{
				Console.WriteLine( "Logical Plan Generation:\nUsage  : Executable -l -i xquery -o LogicalPlan\n" );
				Console.WriteLine( "XML Output (make sure a local soar server is running)\nUsage  : Executable -x -i xquery -o xml [-t timeoutinmsecs]\n" );
				return -1;
			}

			// get the logical plan
			Console.WriteLine("XQuery File:" + xQueryFileName);
			Console.WriteLine("\n\nParsing started ...");
			string LogicalPlan = this.getXQLogicalPlanFromFile(xQueryFileName, showOutput);
			Console.WriteLine("... parsing finished.\n");

			string output = "empty";
			if (!xmlB)
			{
				// the logical plan is generated from the consumed parser dll
				output = LogicalPlan;
			}
			else
			{
				// call the soap server and get the xml output
				Console.WriteLine("\n\nContacting Timber Soap Server ...");
				string evalPlan = this.OptimizerToEvaluator(LogicalPlan, timeout);
				output = this.EvaluatorToOutput(evalPlan, timeout);
				Console.WriteLine("... server procedure finished.\n");
			}
		

			Console.WriteLine("Output\n");
			Console.WriteLine(output);

			if ( outputFileName != String.Empty ) 
			{                
				StreamWriter sw = new StreamWriter(outputFileName);
				sw.Write(output);
				sw.Close();
			}

			return 0;
		}


		private string OptimizerToEvaluator(string query, int timeout)
		{
			if(query.StartsWith("ERROR")) return query;
			string evaluatorPlan = "Optimizer to Evaluation Plan";

			StringReader sr = new StringReader(query);
			string outme = ""; query = "";	
			while((outme = sr.ReadLine())!=null)
			{
				query += outme + "\n";
			}
			sr.Close();

			// create a new timber soap server object
			WebReference2.soapTimber tSoap = new WebReference2.soapTimber();
			tSoap.Url = "http://localhost:18082/";
			tSoap.Timeout = timeout;
			try
			{
				bool isWarning = false;
				bool isError = false;
				string warning = "", error = "";
				//using tag indices only:
				//evaluatorPlan = tSoap.getQueryEvaluationPlan(query, 1, 0, out isWarning, out warning, out isError, out error);
				//availability based:
				evaluatorPlan = tSoap.getQueryEvaluationPlan(query, 2, 0, out isWarning, out warning, out isError, out error);
				if (isWarning) 
				{
					warning = "Warning Message:" + warning;
				}
				if (isError) 
				{
					error = "Error Message:" + error;
					return "ERROR:\n" + error + "\n" + warning;
				}
			}
			catch (Exception e) 
			{
				return "ERROR: There was something wrong with the SOAP connection.\r\n\r\n Check if the server is working.\r\n Exception thrown:\n" + e.ToString();
			}

			StringReader sro = new StringReader(evaluatorPlan);
			outme = ""; evaluatorPlan = "";	
			while((outme = sro.ReadLine())!=null)
			{
				evaluatorPlan += outme + "\r\n";
			}
			sro.Close();

			return evaluatorPlan;
		}

		private string EvaluatorToOutput(string query, int timeout)
		{
			if(query.StartsWith("ERROR")) return query;
			string output = "Evaluator";
			StringReader sr = new StringReader(query);
			string outme = ""; query = "";	
			while((outme = sr.ReadLine())!=null)
			{
				query += outme + "\n";
			}
			sr.Close();

			// create a new timber soap server object
			WebReference2.soapTimber tSoap = new WebReference2.soapTimber();
			tSoap.Url = "http://localhost:18082/";
			tSoap.Timeout = timeout;
			try
			{
				// run the query
				double time;
				int resultcount;
				bool isWarning = false;
				bool isError = false;
				string warning, error;
				time = tSoap.runQuery(query, true, out resultcount, out output, out isWarning, out warning, out isError, out error);
				if (isWarning) 
				{
					warning = "Warning Message:" + warning;
				}
				if (isError) 
				{
					error = "Error Message:" + error;
					return "ERROR:\n" + error + "\n" + warning;
				}
				if (resultcount < 0) return "ERROR: there was something wrong with the execution plan\n";
				output = "Results:" + resultcount.ToString() + "\nTime:" + time.ToString() + "\n\n" + output ;
			}
			catch (Exception e) 
			{
				return "ERROR: There was something wrong with the SOAP connection.\r\n\r\n Check if the server is working.\r\n Exception thrown:\n" + e.ToString();
			}

			StringReader sro = new StringReader(output);
			outme = ""; output = "";	
			while((outme = sro.ReadLine())!=null)
			{
				output += outme + "\r\n";
			}
			sro.Close();

			return output;
		}

	}
}
