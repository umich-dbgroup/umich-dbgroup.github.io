//COPYRIGHT  � 2000-2004 
//THE REGENTS OF THE UNIVERSITY OF MICHIGAN
//ALL RIGHTS RESERVED
//
//PERMISSION IS GRANTED TO USE, COPY, CREATE DERIVATIVE WORKS AND REDISTRIBUTE 
//THIS SOFTWARE AND SUCH DERIVATIVE WORKS FOR NONCOMMERCIAL EDUCATION AND 
//RESEARCH PURPOSES, SO LONG AS NO FEE IS CHARGED, AND SO LONG AS THE 
//COPYRIGHT NOTICE ABOVE, THIS GRANT OF PERMISSION, AND THE DISCLAIMER 
//BELOW APPEAR IN ALL COPIES MADE; AND SO LONG AS THE NAME OF THE UNIVERSITY 
//OF MICHIGAN IS NOT USED IN ANY ADVERTISING OR PUBLICITY PERTAINING TO THE 
//USE OR DISTRIBUTION OF THIS SOFTWARE WITHOUT SPECIFIC, WRITTEN PRIOR AUTHORIZATION.
//
//THIS SOFTWARE IS PROVIDED AS IS, WITHOUT REPRESENTATION FROM THE UNIVERSITY 
//OF MICHIGAN AS TO ITS FITNESS FOR ANY PURPOSE, AND WITHOUT WARRANTY BY THE 
//UNIVERSITY OF MICHIGAN OF ANY KIND, EITHER EXPRESS OR IMPLIED, INCLUDING 
//WITHOUT LIMITATION THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS 
//FOR A PARTICULAR PURPOSE. THE REGENTS OF THE UNIVERSITY OF MICHIGAN SHALL 
//NOT BE LIABLE FOR ANY DAMAGES, INCLUDING SPECIAL, INDIRECT, INCIDENTAL, 
//OR CONSEQUENTIAL DAMAGES, WITH RESPECT TO ANY CLAIM ARISING OUT OF OR IN 
//CONNECTION WITH THE USE OF THE SOFTWARE, EVEN IF IT HAS BEEN OR IS 
//HEREAFTER ADVISED OF THE POSSIBILITY OF SUCH DAMAGES.

// Author: Stelios Paparizos
// e-mail: spapariz@umich.edu


using System;
using System.Drawing;
using System.Collections;
using System.ComponentModel;
using System.Windows.Forms;
using System.Data;
using System.IO;
using System.Diagnostics;

namespace MainGUI
{
	/// <summary>
	/// Summary description for Form1.
	/// </summary>
	public class Form1 : System.Windows.Forms.Form
	{
		private int inputOption;
		private int outputOption;
		private string soapServerPath;
		private string soapServerArgs;
		private string soapServerURL;
		private Form1 f1;
		private int soapTimeOut;


		private System.Windows.Forms.MainMenu mainMenu1;
		private System.Windows.Forms.MenuItem menuItem1;
		private System.Windows.Forms.MenuItem menuItem2;
		private System.Windows.Forms.MenuItem menuItem3;
		private System.Windows.Forms.MenuItem menuItem5;
		private System.Windows.Forms.MenuItem menuItem6;
		private System.Windows.Forms.MenuItem menuItem7;
		private System.Windows.Forms.MenuItem menuItem8;
		private System.Windows.Forms.MenuItem menuItem9;
		private System.Windows.Forms.MenuItem menuItem10;
		private System.Windows.Forms.MenuItem menuItem11;
		private System.Windows.Forms.MenuItem menuItem21;
		private System.Windows.Forms.MenuItem menuItem22;
		private System.Windows.Forms.MenuItem menuItem23;
		private System.Windows.Forms.MenuItem menuItem24;
		private System.Windows.Forms.MenuItem menuItem25;
		private System.Windows.Forms.MenuItem menuItem4;
		private System.Windows.Forms.MenuItem menuItem26;
		private System.Windows.Forms.MenuItem menuItem27;
		private System.Windows.Forms.MenuItem menuItem28;
		private System.Windows.Forms.MenuItem menuItem29;
		private System.Windows.Forms.TextBox textBoxBottom;
		private System.Windows.Forms.GroupBox groupBox1;
		private System.Windows.Forms.TextBox textBoxTop;
		private System.Windows.Forms.Label labelQuery;
		private System.Windows.Forms.Label labelResult;
		private System.Windows.Forms.MenuItem menuItem12;
		private System.Windows.Forms.MenuItem menuItem13;
		private System.Windows.Forms.MenuItem menuItem14;
		private System.Windows.Forms.MenuItem menuItem15;
		private System.Windows.Forms.MenuItem menuItem16;
		private System.Windows.Forms.MenuItem menuItem17;
		private System.Windows.Forms.GroupBox groupBox2;
		private System.Windows.Forms.RadioButton radioXQuery;
		private System.Windows.Forms.RadioButton radioOptimizer;
		private System.Windows.Forms.RadioButton radioEvaluator;
		private System.Windows.Forms.GroupBox groupBox3;
		private System.Windows.Forms.RadioButton radioXML;
		private System.Windows.Forms.RadioButton radioOptimizerOut;
		private System.Windows.Forms.RadioButton radioEvaluatorOut;
		private System.Windows.Forms.Button buttonExit;
		private System.Windows.Forms.Button buttonExecute;
		private System.Windows.Forms.MenuItem menuItem19;
		private System.Windows.Forms.MenuItem menuItem20;
		private System.Windows.Forms.MenuItem menuItem30;
		private System.Windows.Forms.MenuItem menuItem31;
		private System.Windows.Forms.HelpProvider helpProvider1;
		private System.Windows.Forms.MenuItem menuItem18;
		private System.Windows.Forms.MenuItem menuItem32;
		private System.Windows.Forms.Splitter splitter1;
		/// <summary>
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.Container components = null;

		/// <summary>
		/// Constructor for Form1
		/// </summary>
		public Form1()
		{
			InitializeComponent();
			inputOption = -1;
			outputOption = -1;
			this.soapServerPath = "ERROR";
			this.soapServerArgs = "ERROR";
			this.soapServerURL = "ERROR";
			this.soapTimeOut = 330000;
			this.f1 = this;
		}

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		protected override void Dispose( bool disposing )
		{
			if( disposing )
			{
				if (components != null) 
				{
					components.Dispose();
				}
			}
			base.Dispose( disposing );
		}

		#region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			System.Resources.ResourceManager resources = new System.Resources.ResourceManager(typeof(Form1));
			this.buttonExit = new System.Windows.Forms.Button();
			this.textBoxBottom = new System.Windows.Forms.TextBox();
			this.mainMenu1 = new System.Windows.Forms.MainMenu();
			this.menuItem1 = new System.Windows.Forms.MenuItem();
			this.menuItem28 = new System.Windows.Forms.MenuItem();
			this.menuItem27 = new System.Windows.Forms.MenuItem();
			this.menuItem19 = new System.Windows.Forms.MenuItem();
			this.menuItem31 = new System.Windows.Forms.MenuItem();
			this.menuItem30 = new System.Windows.Forms.MenuItem();
			this.menuItem29 = new System.Windows.Forms.MenuItem();
			this.menuItem2 = new System.Windows.Forms.MenuItem();
			this.menuItem3 = new System.Windows.Forms.MenuItem();
			this.menuItem18 = new System.Windows.Forms.MenuItem();
			this.menuItem32 = new System.Windows.Forms.MenuItem();
			this.menuItem4 = new System.Windows.Forms.MenuItem();
			this.menuItem26 = new System.Windows.Forms.MenuItem();
			this.menuItem5 = new System.Windows.Forms.MenuItem();
			this.menuItem6 = new System.Windows.Forms.MenuItem();
			this.menuItem7 = new System.Windows.Forms.MenuItem();
			this.menuItem8 = new System.Windows.Forms.MenuItem();
			this.menuItem20 = new System.Windows.Forms.MenuItem();
			this.menuItem9 = new System.Windows.Forms.MenuItem();
			this.menuItem10 = new System.Windows.Forms.MenuItem();
			this.menuItem12 = new System.Windows.Forms.MenuItem();
			this.menuItem13 = new System.Windows.Forms.MenuItem();
			this.menuItem14 = new System.Windows.Forms.MenuItem();
			this.menuItem21 = new System.Windows.Forms.MenuItem();
			this.menuItem15 = new System.Windows.Forms.MenuItem();
			this.menuItem16 = new System.Windows.Forms.MenuItem();
			this.menuItem11 = new System.Windows.Forms.MenuItem();
			this.menuItem17 = new System.Windows.Forms.MenuItem();
			this.menuItem22 = new System.Windows.Forms.MenuItem();
			this.menuItem23 = new System.Windows.Forms.MenuItem();
			this.menuItem24 = new System.Windows.Forms.MenuItem();
			this.menuItem25 = new System.Windows.Forms.MenuItem();
			this.groupBox1 = new System.Windows.Forms.GroupBox();
			this.splitter1 = new System.Windows.Forms.Splitter();
			this.labelResult = new System.Windows.Forms.Label();
			this.labelQuery = new System.Windows.Forms.Label();
			this.textBoxTop = new System.Windows.Forms.TextBox();
			this.groupBox2 = new System.Windows.Forms.GroupBox();
			this.radioOptimizer = new System.Windows.Forms.RadioButton();
			this.radioEvaluator = new System.Windows.Forms.RadioButton();
			this.radioXQuery = new System.Windows.Forms.RadioButton();
			this.groupBox3 = new System.Windows.Forms.GroupBox();
			this.radioXML = new System.Windows.Forms.RadioButton();
			this.radioOptimizerOut = new System.Windows.Forms.RadioButton();
			this.radioEvaluatorOut = new System.Windows.Forms.RadioButton();
			this.buttonExecute = new System.Windows.Forms.Button();
			this.helpProvider1 = new System.Windows.Forms.HelpProvider();
			this.groupBox1.SuspendLayout();
			this.groupBox2.SuspendLayout();
			this.groupBox3.SuspendLayout();
			this.SuspendLayout();
			// 
			// buttonExit
			// 
			this.buttonExit.Anchor = (System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right);
			this.buttonExit.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
			this.buttonExit.Location = new System.Drawing.Point(936, 504);
			this.buttonExit.Name = "buttonExit";
			this.buttonExit.Size = new System.Drawing.Size(48, 23);
			this.buttonExit.TabIndex = 0;
			this.buttonExit.Text = "Exit";
			this.buttonExit.Click += new System.EventHandler(this.buttonExit_Click);
			// 
			// textBoxBottom
			// 
			this.textBoxBottom.AcceptsReturn = true;
			this.textBoxBottom.AcceptsTab = true;
			this.textBoxBottom.AutoSize = false;
			this.textBoxBottom.Dock = System.Windows.Forms.DockStyle.Bottom;
			this.textBoxBottom.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((System.Byte)(161)));
			this.textBoxBottom.Location = new System.Drawing.Point(3, 253);
			this.textBoxBottom.Multiline = true;
			this.textBoxBottom.Name = "textBoxBottom";
			this.textBoxBottom.ScrollBars = System.Windows.Forms.ScrollBars.Both;
			this.textBoxBottom.Size = new System.Drawing.Size(994, 240);
			this.textBoxBottom.TabIndex = 1;
			this.textBoxBottom.Text = "Result will be shown here";
			this.textBoxBottom.WordWrap = false;
			// 
			// mainMenu1
			// 
			this.mainMenu1.MenuItems.AddRange(new System.Windows.Forms.MenuItem[] {
																					  this.menuItem1,
																					  this.menuItem5,
																					  this.menuItem9,
																					  this.menuItem22});
			// 
			// menuItem1
			// 
			this.menuItem1.Index = 0;
			this.menuItem1.MenuItems.AddRange(new System.Windows.Forms.MenuItem[] {
																					  this.menuItem28,
																					  this.menuItem27,
																					  this.menuItem19,
																					  this.menuItem31,
																					  this.menuItem30,
																					  this.menuItem29,
																					  this.menuItem2,
																					  this.menuItem3,
																					  this.menuItem18,
																					  this.menuItem32,
																					  this.menuItem4,
																					  this.menuItem26});
			this.menuItem1.Text = "Main";
			// 
			// menuItem28
			// 
			this.menuItem28.Index = 0;
			this.menuItem28.Text = "Start Server";
			this.menuItem28.Click += new System.EventHandler(this.menuItem28_Click);
			// 
			// menuItem27
			// 
			this.menuItem27.Index = 1;
			this.menuItem27.Text = "Reboot Server";
			this.menuItem27.Click += new System.EventHandler(this.menuItem27_Click);
			// 
			// menuItem19
			// 
			this.menuItem19.Index = 2;
			this.menuItem19.Text = "Shutdown Server";
			this.menuItem19.Click += new System.EventHandler(this.menuItem19_Click);
			// 
			// menuItem31
			// 
			this.menuItem31.Index = 3;
			this.menuItem31.Text = "Connect to a Local Server";
			this.menuItem31.Click += new System.EventHandler(this.menuItem31_Click);
			// 
			// menuItem30
			// 
			this.menuItem30.Index = 4;
			this.menuItem30.Text = "Connect to a Remote Server";
			this.menuItem30.Click += new System.EventHandler(this.menuItem30_Click);
			// 
			// menuItem29
			// 
			this.menuItem29.Index = 5;
			this.menuItem29.Text = "-";
			// 
			// menuItem2
			// 
			this.menuItem2.Index = 6;
			this.menuItem2.Text = "Load Data";
			this.menuItem2.Click += new System.EventHandler(this.menuItem2_Click);
			// 
			// menuItem3
			// 
			this.menuItem3.Index = 7;
			this.menuItem3.Text = "Build Index";
			this.menuItem3.Click += new System.EventHandler(this.menuItem3_Click);
			// 
			// menuItem18
			// 
			this.menuItem18.Index = 8;
			this.menuItem18.Text = "-";
			// 
			// menuItem32
			// 
			this.menuItem32.Index = 9;
			this.menuItem32.Text = "Change Client Timeout";
			this.menuItem32.Click += new System.EventHandler(this.menuItem32_Click);
			// 
			// menuItem4
			// 
			this.menuItem4.Index = 10;
			this.menuItem4.Text = "-";
			// 
			// menuItem26
			// 
			this.menuItem26.Index = 11;
			this.menuItem26.Text = "Exit";
			this.menuItem26.Click += new System.EventHandler(this.menuItem26_Click);
			// 
			// menuItem5
			// 
			this.menuItem5.Index = 1;
			this.menuItem5.MenuItems.AddRange(new System.Windows.Forms.MenuItem[] {
																					  this.menuItem6,
																					  this.menuItem7,
																					  this.menuItem8,
																					  this.menuItem20});
			this.menuItem5.Text = "File";
			// 
			// menuItem6
			// 
			this.menuItem6.Index = 0;
			this.menuItem6.Text = "New";
			this.menuItem6.Click += new System.EventHandler(this.menuItem6_Click);
			// 
			// menuItem7
			// 
			this.menuItem7.Index = 1;
			this.menuItem7.Text = "Open Query";
			this.menuItem7.Click += new System.EventHandler(this.menuItem7_Click);
			// 
			// menuItem8
			// 
			this.menuItem8.Index = 2;
			this.menuItem8.Text = "Save Query";
			this.menuItem8.Click += new System.EventHandler(this.menuItem8_Click);
			// 
			// menuItem20
			// 
			this.menuItem20.Index = 3;
			this.menuItem20.Text = "Save Results";
			this.menuItem20.Click += new System.EventHandler(this.menuItem20_Click);
			// 
			// menuItem9
			// 
			this.menuItem9.Index = 2;
			this.menuItem9.MenuItems.AddRange(new System.Windows.Forms.MenuItem[] {
																					  this.menuItem10,
																					  this.menuItem21,
																					  this.menuItem11});
			this.menuItem9.Text = "Execute";
			// 
			// menuItem10
			// 
			this.menuItem10.Index = 0;
			this.menuItem10.MenuItems.AddRange(new System.Windows.Forms.MenuItem[] {
																					   this.menuItem12,
																					   this.menuItem13,
																					   this.menuItem14});
			this.menuItem10.Text = "Run XQuery";
			// 
			// menuItem12
			// 
			this.menuItem12.Index = 0;
			this.menuItem12.Text = "To XML";
			this.menuItem12.Click += new System.EventHandler(this.menuItem12_Click);
			// 
			// menuItem13
			// 
			this.menuItem13.Index = 1;
			this.menuItem13.Text = "To Logical Algebra Plan";
			this.menuItem13.Click += new System.EventHandler(this.menuItem13_Click);
			// 
			// menuItem14
			// 
			this.menuItem14.Index = 2;
			this.menuItem14.Text = "To Physical Algebra Plan";
			this.menuItem14.Click += new System.EventHandler(this.menuItem14_Click);
			// 
			// menuItem21
			// 
			this.menuItem21.Index = 1;
			this.menuItem21.MenuItems.AddRange(new System.Windows.Forms.MenuItem[] {
																					   this.menuItem15,
																					   this.menuItem16});
			this.menuItem21.Text = "Run Logical Plan";
			// 
			// menuItem15
			// 
			this.menuItem15.Index = 0;
			this.menuItem15.Text = "To XML";
			this.menuItem15.Click += new System.EventHandler(this.menuItem15_Click);
			// 
			// menuItem16
			// 
			this.menuItem16.Index = 1;
			this.menuItem16.Text = "To Physical Algebra Plan";
			this.menuItem16.Click += new System.EventHandler(this.menuItem16_Click);
			// 
			// menuItem11
			// 
			this.menuItem11.Index = 2;
			this.menuItem11.MenuItems.AddRange(new System.Windows.Forms.MenuItem[] {
																					   this.menuItem17});
			this.menuItem11.Text = "Run Physical Plan";
			// 
			// menuItem17
			// 
			this.menuItem17.Index = 0;
			this.menuItem17.Text = "To XML";
			this.menuItem17.Click += new System.EventHandler(this.menuItem17_Click);
			// 
			// menuItem22
			// 
			this.menuItem22.Index = 3;
			this.menuItem22.MenuItems.AddRange(new System.Windows.Forms.MenuItem[] {
																					   this.menuItem23,
																					   this.menuItem24,
																					   this.menuItem25});
			this.menuItem22.Text = "Help";
			// 
			// menuItem23
			// 
			this.menuItem23.Index = 0;
			this.menuItem23.Text = "Help";
			this.menuItem23.Click += new System.EventHandler(this.menuItem23_Click);
			// 
			// menuItem24
			// 
			this.menuItem24.Index = 1;
			this.menuItem24.Text = "-";
			// 
			// menuItem25
			// 
			this.menuItem25.Index = 2;
			this.menuItem25.Text = "About";
			this.menuItem25.Click += new System.EventHandler(this.menuItem25_Click);
			// 
			// groupBox1
			// 
			this.groupBox1.Controls.AddRange(new System.Windows.Forms.Control[] {
																					this.splitter1,
																					this.labelResult,
																					this.labelQuery,
																					this.textBoxTop,
																					this.textBoxBottom});
			this.groupBox1.Dock = System.Windows.Forms.DockStyle.Top;
			this.groupBox1.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
			this.groupBox1.Name = "groupBox1";
			this.groupBox1.Size = new System.Drawing.Size(1000, 496);
			this.groupBox1.TabIndex = 2;
			this.groupBox1.TabStop = false;
			// 
			// splitter1
			// 
			this.splitter1.Location = new System.Drawing.Point(3, 248);
			this.splitter1.Name = "splitter1";
			this.splitter1.Size = new System.Drawing.Size(3, 5);
			this.splitter1.TabIndex = 6;
			this.splitter1.TabStop = false;
			// 
			// labelResult
			// 
			this.labelResult.Anchor = System.Windows.Forms.AnchorStyles.Right;
			this.labelResult.BackColor = System.Drawing.SystemColors.Window;
			this.labelResult.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
			this.labelResult.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((System.Byte)(161)));
			this.labelResult.Location = new System.Drawing.Point(888, 264);
			this.labelResult.Name = "labelResult";
			this.labelResult.Size = new System.Drawing.Size(80, 32);
			this.labelResult.TabIndex = 5;
			this.labelResult.Text = "Result";
			this.labelResult.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
			// 
			// labelQuery
			// 
			this.labelQuery.Anchor = (System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right);
			this.labelQuery.BackColor = System.Drawing.SystemColors.Window;
			this.labelQuery.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
			this.labelQuery.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
			this.labelQuery.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((System.Byte)(161)));
			this.labelQuery.Location = new System.Drawing.Point(888, 24);
			this.labelQuery.Name = "labelQuery";
			this.labelQuery.Size = new System.Drawing.Size(80, 23);
			this.labelQuery.TabIndex = 4;
			this.labelQuery.Text = "Query";
			this.labelQuery.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
			// 
			// textBoxTop
			// 
			this.textBoxTop.AcceptsReturn = true;
			this.textBoxTop.AcceptsTab = true;
			this.textBoxTop.AutoSize = false;
			this.textBoxTop.Dock = System.Windows.Forms.DockStyle.Top;
			this.textBoxTop.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((System.Byte)(161)));
			this.textBoxTop.Location = new System.Drawing.Point(3, 16);
			this.textBoxTop.Multiline = true;
			this.textBoxTop.Name = "textBoxTop";
			this.textBoxTop.ScrollBars = System.Windows.Forms.ScrollBars.Both;
			this.helpProvider1.SetShowHelp(this.textBoxTop, false);
			this.textBoxTop.Size = new System.Drawing.Size(994, 232);
			this.textBoxTop.TabIndex = 3;
			this.textBoxTop.Text = "Query will be shown here";
			this.textBoxTop.WordWrap = false;
			// 
			// groupBox2
			// 
			this.groupBox2.Anchor = (System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left);
			this.groupBox2.Controls.AddRange(new System.Windows.Forms.Control[] {
																					this.radioOptimizer,
																					this.radioEvaluator,
																					this.radioXQuery});
			this.groupBox2.Location = new System.Drawing.Point(8, 496);
			this.groupBox2.Name = "groupBox2";
			this.groupBox2.Size = new System.Drawing.Size(304, 48);
			this.groupBox2.TabIndex = 3;
			this.groupBox2.TabStop = false;
			this.groupBox2.Text = "Input";
			// 
			// radioOptimizer
			// 
			this.radioOptimizer.Location = new System.Drawing.Point(80, 16);
			this.radioOptimizer.Name = "radioOptimizer";
			this.radioOptimizer.TabIndex = 0;
			this.radioOptimizer.Text = "Logical Algebra";
			this.radioOptimizer.CheckedChanged += new System.EventHandler(this.radioOptimizer_CheckedChanged);
			// 
			// radioEvaluator
			// 
			this.radioEvaluator.Location = new System.Drawing.Point(184, 16);
			this.radioEvaluator.Name = "radioEvaluator";
			this.radioEvaluator.Size = new System.Drawing.Size(112, 24);
			this.radioEvaluator.TabIndex = 0;
			this.radioEvaluator.Text = "Physical Algebra";
			this.radioEvaluator.CheckedChanged += new System.EventHandler(this.radioEvaluator_CheckedChanged);
			// 
			// radioXQuery
			// 
			this.radioXQuery.Location = new System.Drawing.Point(16, 16);
			this.radioXQuery.Name = "radioXQuery";
			this.radioXQuery.Size = new System.Drawing.Size(64, 24);
			this.radioXQuery.TabIndex = 0;
			this.radioXQuery.Text = "XQuery";
			this.radioXQuery.CheckedChanged += new System.EventHandler(this.radioXQuery_CheckedChanged);
			// 
			// groupBox3
			// 
			this.groupBox3.Anchor = (System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left);
			this.groupBox3.Controls.AddRange(new System.Windows.Forms.Control[] {
																					this.radioXML,
																					this.radioOptimizerOut,
																					this.radioEvaluatorOut});
			this.groupBox3.Location = new System.Drawing.Point(320, 496);
			this.groupBox3.Name = "groupBox3";
			this.groupBox3.Size = new System.Drawing.Size(280, 48);
			this.groupBox3.TabIndex = 3;
			this.groupBox3.TabStop = false;
			this.groupBox3.Text = "Output";
			// 
			// radioXML
			// 
			this.radioXML.Location = new System.Drawing.Point(8, 16);
			this.radioXML.Name = "radioXML";
			this.radioXML.Size = new System.Drawing.Size(48, 24);
			this.radioXML.TabIndex = 0;
			this.radioXML.Text = "XML";
			this.radioXML.CheckedChanged += new System.EventHandler(this.radioXML_CheckedChanged);
			// 
			// radioOptimizerOut
			// 
			this.radioOptimizerOut.Location = new System.Drawing.Point(56, 16);
			this.radioOptimizerOut.Name = "radioOptimizerOut";
			this.radioOptimizerOut.TabIndex = 0;
			this.radioOptimizerOut.Text = "Logical Algebra";
			this.radioOptimizerOut.CheckedChanged += new System.EventHandler(this.radioOptimizerOut_CheckedChanged);
			// 
			// radioEvaluatorOut
			// 
			this.radioEvaluatorOut.Location = new System.Drawing.Point(160, 16);
			this.radioEvaluatorOut.Name = "radioEvaluatorOut";
			this.radioEvaluatorOut.Size = new System.Drawing.Size(112, 24);
			this.radioEvaluatorOut.TabIndex = 0;
			this.radioEvaluatorOut.Text = "Physical Algebra";
			this.radioEvaluatorOut.CheckedChanged += new System.EventHandler(this.radioEvaluatorOut_CheckedChanged);
			// 
			// buttonExecute
			// 
			this.buttonExecute.Anchor = (System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right);
			this.buttonExecute.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
			this.buttonExecute.Location = new System.Drawing.Point(856, 504);
			this.buttonExecute.Name = "buttonExecute";
			this.buttonExecute.TabIndex = 0;
			this.buttonExecute.Text = "Run Query";
			this.buttonExecute.Click += new System.EventHandler(this.buttonExecute_Click);
			// 
			// helpProvider1
			// 
			this.helpProvider1.HelpNamespace = "http://www.eecs.umich.edu/db/timber/help/";
			// 
			// Form1
			// 
			this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
			this.AutoScroll = true;
			this.ClientSize = new System.Drawing.Size(1000, 545);
			this.Controls.AddRange(new System.Windows.Forms.Control[] {
																		  this.groupBox2,
																		  this.groupBox3,
																		  this.groupBox1,
																		  this.buttonExit,
																		  this.buttonExecute});
			this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
			this.Menu = this.mainMenu1;
			this.Name = "Form1";
			this.helpProvider1.SetShowHelp(this, true);
			this.Text = "University of Michigan - The Timber Project";
			this.Resize += new System.EventHandler(this.Form1_Resize);
			this.Load += new System.EventHandler(this.Form1_Load);
			this.groupBox1.ResumeLayout(false);
			this.groupBox2.ResumeLayout(false);
			this.groupBox3.ResumeLayout(false);
			this.ResumeLayout(false);

		}
		#endregion

		/// <summary>
		/// The main entry point for the application.
		/// </summary>
		[STAThread]
		static void Main() 
		{
			Application.Run(new Form1());
		
		}

		private void buttonExit_Click(object sender, System.EventArgs e)
		{
			this.exitApp();
		}

		private void exitApp()
		{
			// create a new timber soap server object
			WebReference1.soapTimber tSoap = new WebReference1.soapTimber();
			//if (!this.soapServerURL.StartsWith("ERROR")) tSoap.Url = this.soapServerURL;
			if (this.soapServerURL.Equals("http://localhost:18082/")) 
			{
				tSoap.Timeout = this.soapTimeOut;
				try
				{
					bool isWarning = false, isError = false;
					string warning, error;
					isWarning = tSoap.shutDownSoapServer(out warning, out isError, out error);
					if (isWarning) MessageBox.Show(warning, "Warning", MessageBoxButtons.OK, MessageBoxIcon.Warning);
					if (isError) MessageBox.Show(error, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
				}
				catch (Exception exc) 
				{
					string excOutput = exc.ToString();
				}
			}
			this.Close();
		}

		private void menuItem25_Click(object sender, System.EventArgs e)
		{
			string message = "";
			message += "The TIMBER Project\n";
			message += "University of Michigan\n";
			message += "http://www.eecs.umich.edu/db/timber/\n";
			message += "timber@umich.edu\n\n";

//			message += "People\n\n";
//			message += "Faculty\n \tH.V. Jagadish\n \tJignesh M. Patel\n\n";
//			message += "Graduate Students\n \tShurug Al-Khalifa\n \tAdriane Chapman\n \tAndrew Nierman\n \tStelios Paparizos\n \tKanda Runapongsa\n \tNuwee Wiwatwattana\n \tYuqing Wu\n \tCong Yu\n\n";
//			message += "TIMBER Alumni\n \tKeith Thompson\n\n";
//			message += "In Collaboration with\n \tNick Koudas, AT&T Labs\n \tLaks V S Lakshmanan, Univ. of British Columbia\n \tDivesh Srivastava, AT&T Labs\n\n";
			
			MessageBox.Show(message, "About Timber...", MessageBoxButtons.OK, MessageBoxIcon.Information);
		}

		private void menuItem26_Click(object sender, System.EventArgs e)
		{
			this.exitApp();
		}

		private void menuItem7_Click(object sender, System.EventArgs e)
		{
			OpenFileDialog openQuery = new OpenFileDialog();
			textBoxBottom.Text = "Results will appear here once the query is executed";
			this.labelResult.Text = "Result";

			//openQuery.InitialDirectory = ".\\" ;
			openQuery.Filter = "txt files (*.txt)|*.txt|All files (*.*)|*.*" ;
			openQuery.FilterIndex = 2 ;
			openQuery.RestoreDirectory = true ;

			if(openQuery.ShowDialog() == DialogResult.OK)
			{
				Stream myStream;
				if((myStream = openQuery.OpenFile())!= null)
				{
					// Insert code to read the stream here.
					String myQuery;
					StreamReader t = new StreamReader(myStream);
					myQuery = t.ReadToEnd();
					t.Close();
					myStream.Close();
					textBoxTop.Text = myQuery;

					string filename = openQuery.FileName;
					filename = filename.Substring(filename.LastIndexOf('\\')+1); 
				}
			}

		}

		private void menuItem8_Click(object sender, System.EventArgs e)
		{
			Stream myStream ;
			SaveFileDialog saveQuery = new SaveFileDialog();
 
			saveQuery.Filter = "txt files (*.txt)|*.txt|All files (*.*)|*.*"  ;
			saveQuery.FilterIndex = 2 ;
			saveQuery.RestoreDirectory = true ;
 
			if(saveQuery.ShowDialog() == DialogResult.OK)
			{
				if((myStream = saveQuery.OpenFile()) != null)
				{
					String output = textBoxTop.Text;
					// Code to write the stream goes here.
					StreamWriter sw = new StreamWriter(myStream);
					sw.Write(output);
					sw.Close();
					myStream.Close();
				}
			}
		
		}

		private void menuItem6_Click(object sender, System.EventArgs e)
		{
			textBoxTop.Text = "Please type your query here";
			textBoxBottom.Text = "Results will appear here once the query is executed";
			this.labelResult.Text = "Result";
		}

		private void menuItem23_Click(object sender, System.EventArgs e)
		{
			MessageBox.Show("For help, just click anywhere in the client application and press F1.\nPlease e-mail us at timber@umich.edu for further assistance.", "Help", MessageBoxButtons.OK, MessageBoxIcon.Information);
		}

		private void execute(int iOption, int oOption)
		{
			if (this.soapServerURL.StartsWith("ERROR")) {MessageBox.Show("Not connected to a Server!"); return;}
			string output = "Unsupported Type";

			textBoxBottom.Text = "Running query ...";
			this.labelResult.Text = "Result";

			switch(iOption)
			{
				case (int)(values.XQuery):
					output = inputXQuery(oOption);
					break;
				case (int)(values.Optimizer):
					output = inputOptimizer(oOption);
					break;
				case (int)(values.Evaluator):
					output = inputEvaluator(oOption);
					break;
			}

			textBoxBottom.Text = output;

		}

		private string XQueryToOptimizer(string xQuery)
		{
			string optimizerPlan = "XQuery to Optimizer Plan";

			// create evaluation plan
			// create a parser object
			Timber.XQueryParser.XQParser myparser = new Timber.XQueryParser.XQParser();
			// parse an xquery statement, create an execution plan
			optimizerPlan = myparser.parseString(xQuery, 0);

			StringReader sr = new StringReader(optimizerPlan);
			string outme = "";	optimizerPlan = "";
			while((outme = sr.ReadLine())!=null)
			{
				optimizerPlan += outme + "\r\n";
			}
			sr.Close();
			return optimizerPlan;
		}

		private string OptimizerToEvaluator(string query)
		{
			if(query.StartsWith("ERROR")) return query;
			string evaluatorPlan = "Optimizer to Evaluation Plan";

			StringReader sr = new StringReader(query);
			string outme = ""; query = "";	
			while((outme = sr.ReadLine())!=null)
			{
				query += outme + "\n";
			}
			sr.Close();

			// create a new timber soap server object
			WebReference1.soapTimber tSoap = new WebReference1.soapTimber();
			if (!this.soapServerURL.StartsWith("ERROR")) tSoap.Url = this.soapServerURL;
			tSoap.Timeout = this.soapTimeOut;
			try
			{
				bool isWarning = false;
				bool isError = false;
				string warning, error;
				//using tag indices only:
				//evaluatorPlan = tSoap.getQueryEvaluationPlan(query, 1, 0, out isWarning, out warning, out isError, out error);
				//availability based:
				evaluatorPlan = tSoap.getQueryEvaluationPlan(query, 2, 0, out isWarning, out warning, out isError, out error);
				if (isWarning) MessageBox.Show(warning, "Warning", MessageBoxButtons.OK, MessageBoxIcon.Warning);
				if (isError) evaluatorPlan = error;
			}
			catch (Exception e) 
			{
				return "ERROR: There was something wrong with the SOAP connection.\r\n\r\n" + e.ToString();
			}

			StringReader sro = new StringReader(evaluatorPlan);
			outme = ""; evaluatorPlan = "";	
			while((outme = sro.ReadLine())!=null)
			{
				evaluatorPlan += outme + "\r\n";
			}
			sro.Close();

			return evaluatorPlan;
		}

		private string EvaluatorToOutput(string query, int option)
		{
			if(query.StartsWith("ERROR")) return query;
			string evaluatorPlan = "Evaluator";
			StringReader sr = new StringReader(query);
			string outme = ""; query = "";	
			while((outme = sr.ReadLine())!=null)
			{
				query += outme + "\n";
			}
			sr.Close();

			if (option == (int)(values.XML)) //XML output
			{
				// create a new timber soap server object
				WebReference1.soapTimber tSoap = new WebReference1.soapTimber();
				if (!this.soapServerURL.StartsWith("ERROR")) tSoap.Url = this.soapServerURL;
				tSoap.Timeout = this.soapTimeOut;
				try
				{
					// run the query
					double time;
					int resultcount;
					bool isWarning = false;
					bool isError = false;
					string warning, error;
					time = tSoap.runQuery(query, true, out resultcount, out evaluatorPlan, out isWarning, out warning, out isError, out error);
					if (isWarning) MessageBox.Show(warning, "Warning", MessageBoxButtons.OK, MessageBoxIcon.Warning);
					if (isError) 
					{
						evaluatorPlan = error;
						//AN: the error stack is hard to read, so we'll use the StringReader below to add \r\n to each line
						//return "ERROR:" + error;
					}
					else 
					{
						this.labelResult.Text = "Results:" + resultcount.ToString() + "\nTime:" + time.ToString() ;
						if (resultcount < 0) return "ERROR: there was something wrong with the execution plan";
					}
				}
				catch (Exception e) 
				{
					return "ERROR: There was something wrong with the SOAP connection.\r\n\r\n" + e.ToString();
				}
			}

			StringReader sro = new StringReader(evaluatorPlan);
			outme = ""; evaluatorPlan = "";	
			while((outme = sro.ReadLine())!=null)
			{
				evaluatorPlan += outme + "\r\n";
			}
			sro.Close();

			return evaluatorPlan;
		}


		private string inputXQuery(int option)
		{
			string output = "Unsupported";
			string xQuery = textBoxTop.Text;

			switch(option)
			{
				case (int)(values.XML): // XQuery to XML
				{
					string optPlan = this.XQueryToOptimizer(xQuery);
					string evalPlan = this.OptimizerToEvaluator(optPlan);
					output = this.EvaluatorToOutput(evalPlan, (int)(values.XML));
				}
					break;
				case (int)(values.Optimizer): // XQuery to Optimizer Plan
					output = this.XQueryToOptimizer(xQuery);
					break;
				case (int)(values.Evaluator): // XQuery to Evaluation Plan
				{
					string optPlan = this.XQueryToOptimizer(xQuery);
					output = this.OptimizerToEvaluator(optPlan);
				}
					break;
			}
			
			return output;
		}


		private string inputOptimizer(int option)
		{
			string output = "Unsupported";
			string query = textBoxTop.Text;

			switch(option)
			{
				case (int)(values.XML): // Optimizer to XML
				{
					string evalPlan = this.OptimizerToEvaluator(query);
					output = this.EvaluatorToOutput(evalPlan, (int)(values.XML));
				}
					break;
				case (int)(values.Optimizer): // Optimizer to Optimizer Plan
					output = query;
					break;
				case (int)(values.Evaluator): // Optimizer to Evaluation Plan
					output = this.OptimizerToEvaluator(query);
					break;
			}

			return output;
		}

		private string inputEvaluator(int option)
		{
			string output = "Unsupported";
			string query = textBoxTop.Text;

			switch(option)
			{
				case (int)(values.XML): // Evaluator to XML
					output = this.EvaluatorToOutput(query, (int)(values.XML));
					break;
				case (int)(values.Optimizer): // Evaluator to Optimizer Plan
					output = "Cannot convert Evaluator Plan to Optimizer Plan";
					break;
				case (int)(values.Evaluator): // Evaluator to Evaluation Plan
					output = query;
					break;
			}
			
			return output;
		}


		private void menuItem12_Click(object sender, System.EventArgs e)
		{
			//call XQuery to XML
			execute((int)(values.XQuery), (int)(values.XML));
		}

		private void menuItem13_Click(object sender, System.EventArgs e)
		{
			//call XQuery to Optimizer
			execute((int)(values.XQuery), (int)(values.Optimizer));
		}

		private void menuItem14_Click(object sender, System.EventArgs e)
		{
			//call XQuery to Evaluator
			execute((int)(values.XQuery), (int)(values.Evaluator));
		}

		private void buttonExecute_Click(object sender, System.EventArgs e)
		{
			if ((inputOption == -1) || (outputOption == -1))
				MessageBox.Show("Please make sure you have selected the Input and Output types.");
			else
			{
				execute(inputOption, outputOption);
			}

		}

		private void radioXQuery_CheckedChanged(object sender, System.EventArgs e)
		{
			inputOption = (int)(values.XQuery);
		}

		private void radioOptimizer_CheckedChanged(object sender, System.EventArgs e)
		{
			inputOption = (int)(values.Optimizer);
		}

		private void radioEvaluator_CheckedChanged(object sender, System.EventArgs e)
		{
			inputOption = (int)(values.Evaluator);
		}

		private void radioXML_CheckedChanged(object sender, System.EventArgs e)
		{
			outputOption = (int)(values.XML);
		}

		private void radioOptimizerOut_CheckedChanged(object sender, System.EventArgs e)
		{
			outputOption = (int)(values.Optimizer);
		}

		private void radioEvaluatorOut_CheckedChanged(object sender, System.EventArgs e)
		{
			outputOption = (int)(values.Evaluator);
		}



		private void menuItem15_Click(object sender, System.EventArgs e)
		{
			execute((int)(values.Optimizer), (int)(values.XML));//Optimizer to XML
		}

		private void menuItem16_Click(object sender, System.EventArgs e)
		{
			execute((int)(values.Optimizer), (int)(values.Evaluator));//Optimizer to Evaluator
		}

		private void menuItem17_Click(object sender, System.EventArgs e)
		{
			execute((int)(values.Evaluator), (int)(values.XML));//Evaluator to XML
		}

		private void Form1_Resize(object sender, System.EventArgs e)
		{
			this.groupBox1.Size = new System.Drawing.Size(this.Size.Width-8, this.Size.Height - 100);
			this.textBoxTop.Size = new System.Drawing.Size(this.groupBox1.Width-8, this.groupBox1.Height/2-10);
			this.textBoxBottom.Size = new System.Drawing.Size(this.groupBox1.Width-8, this.groupBox1.Height/2-10);
		
		}

		private void Form1_Load(object sender, System.EventArgs e)
		{
			this.radioXML.Checked = true;
			this.radioXQuery.Checked = true;
			this.groupBox2.Visible = true;
			this.groupBox3.Visible = true;
		}


		private void menuItem19_Click(object sender, System.EventArgs e)
		{
			// create a new timber soap server object
			WebReference1.soapTimber tSoap = new WebReference1.soapTimber();
			if (this.soapServerURL.Equals("http://localhost:18082/")) 
			{
				tSoap.Timeout = this.soapTimeOut;
				try
				{
					bool isWarning = false, isError = false;
					string warning, error;
					isWarning = tSoap.shutDownSoapServer(out warning, out isError, out error);
					if (isWarning) MessageBox.Show(warning, "Warning", MessageBoxButtons.OK, MessageBoxIcon.Warning);
					if (isError) MessageBox.Show(error, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
				}
				catch (Exception exc) 
				{
					this.textBoxBottom.Text =  "ERROR: There was something wrong with the SOAP connection.\r\n\r\n" + exc.ToString();
				}
			}
			else
			{
				textBoxBottom.Text = "ERROR: You can only shutdown a local server";
				MessageBox.Show(textBoxBottom.Text, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
			}

		}


		private void menuItem20_Click(object sender, System.EventArgs e)
		{
		
			Stream myStream ;
			SaveFileDialog saveQuery = new SaveFileDialog();
 
			saveQuery.Filter = "txt files (*.txt)|*.txt|All files (*.*)|*.*"  ;
			saveQuery.FilterIndex = 2 ;
			saveQuery.RestoreDirectory = true ;
 
			if(saveQuery.ShowDialog() == DialogResult.OK)
			{
				if((myStream = saveQuery.OpenFile()) != null)
				{
					String output = this.textBoxBottom.Text;
					StreamWriter sw = new StreamWriter(myStream);
					sw.Write(output);
					sw.Close();
					myStream.Close();
				}
		
			}
		}

		private void menuItem2_Click(object sender, System.EventArgs e)
		{
			if (this.soapServerURL.StartsWith("ERROR")) {MessageBox.Show("Not connected to a Server!"); return;}
			OpenFileDialog openQuery = new OpenFileDialog();
			textBoxBottom.Text = "Loading Data ....\r\nPlease wait ....\r\n";

			//openQuery.InitialDirectory = ".\\" ;
			openQuery.Filter = "xml files (*.xml)|*.xml|txt files (*.txt)|*.txt|All files (*.*)|*.*" ;
			openQuery.FilterIndex = 1 ;
			openQuery.RestoreDirectory = true ;

			string pathToData = "ERROR";

			if(openQuery.ShowDialog() == DialogResult.OK)
			{
				Stream myStream;
				if((myStream = openQuery.OpenFile())!= null)
				{
					pathToData = openQuery.FileName;
					myStream.Close();
				}
				else 
				{
					pathToData = "ERROR: The data file does not exist!";
					MessageBox.Show(pathToData);
					return;
				}
			}
			else 
			{
				this.textBoxBottom.Text += "\r\n...Loading process is cancelled!";
				return;
			} 

			if (this.soapServerURL.Equals("http://localhost:18082/")) 
			{
				// create a new timber soap server object
				WebReference1.soapTimber tSoap = new WebReference1.soapTimber();
				tSoap.Timeout = this.soapTimeOut;
				try
				{
					bool isWarning = false, isError = false;
					string warning, error;
					isWarning = tSoap.loadDataFromFile(pathToData, out warning, out isError, out error);
					if (isWarning) MessageBox.Show(warning, "Warning", MessageBoxButtons.OK, MessageBoxIcon.Warning);
					if (isError) MessageBox.Show(error, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
					this.textBoxBottom.Text += "\r\n...Loading process is finished";
				}
				catch (Exception exc) 
				{
					this.textBoxBottom.Text = "ERROR: There was something wrong with Loading!\n" + exc.ToString();
					MessageBox.Show("There was something wrong with Loading!");
				}
			}
			else
			{
				this.textBoxBottom.Text = "ERROR: You are not connected to a local server!\r\n";
				MessageBox.Show(this.textBoxBottom.Text);
			}


		}

		private void menuItem3_Click(object sender, System.EventArgs e)
		{
			if (this.soapServerURL.StartsWith("ERROR")) {MessageBox.Show("Not connected to a Server!"); return;}
			
			if (this.soapServerURL.Equals("http://localhost:18082/")) 
			{
				textBoxBottom.Text = "Building Index ....\r\nPlease wait ....\r\n";
				Form2 form2 = new Form2();
				form2.ShowDialog();
				if (form2.DialogResult == DialogResult.OK)
				{
					string index = form2.result;
					// create a new timber soap server object
					WebReference1.soapTimber tSoap = new WebReference1.soapTimber();
					tSoap.Timeout = this.soapTimeOut;
					try
					{
						bool isWarning = false, isError = false;
						string warning, error;
						isWarning = tSoap.buildIndex(index, out warning, out isError, out error);
						if (isWarning) MessageBox.Show(warning, "Warning", MessageBoxButtons.OK, MessageBoxIcon.Warning);
						if (isError) MessageBox.Show(error, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
						this.textBoxBottom.Text += "\r\n...Building Index Process is finished";
					}
					catch (Exception exc) 
					{
						this.textBoxBottom.Text = "ERROR: There was something wrong with Building Index!\r\n" + exc.ToString();
						MessageBox.Show("There was something wrong with Building Index!");
					}

				}
				else
				{
					this.textBoxBottom.Text += "\r\n...Request Cancelled";
				}
			}
			else
			{
				this.textBoxBottom.Text = "ERROR: You are not connected to a local server!\r\n";
				MessageBox.Show(this.textBoxBottom.Text);
			}
		}
		
		private void menuItem28_Click(object sender, System.EventArgs e)
		{
			if(!this.soapServerPath.StartsWith("ERROR"))
			{
				if (this.soapServerURL.Equals("http://localhost:18082/")) 
				{
					// create a new timber soap server object
					WebReference1.soapTimber tSoap = new WebReference1.soapTimber();
					tSoap.Timeout = this.soapTimeOut;
					try
					{
						bool isWarning = false, isError = false;
						string warning, error;
						isWarning = tSoap.shutDownSoapServer(out warning, out isError, out error);
						if (isWarning) MessageBox.Show(warning, "Warning", MessageBoxButtons.OK, MessageBoxIcon.Warning);
						if (isError) MessageBox.Show(error, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
					}
					catch (Exception exc) 
					{
						string output = exc.ToString();
					}
				}
			}

			string soapServerFileName = "ERROR: The soap server did not start successfully";
			string serverArgs = "localhost ";

			textBoxBottom.Text = "Please select the soap server executable";
			OpenFileDialog openSoapServer = new OpenFileDialog();
			openSoapServer.Filter = "exe files (*.exe)|*.exe|All files (*.*)|*.*" ;
			openSoapServer.FilterIndex = 1 ;
			openSoapServer.RestoreDirectory = true ;
			openSoapServer.Title = textBoxBottom.Text;

			if(openSoapServer.ShowDialog() == DialogResult.OK)
			{
				Stream myStream;
				if((myStream = openSoapServer.OpenFile())!= null)
				{
					soapServerFileName = openSoapServer.FileName;
					myStream.Close();
				}
				else soapServerFileName = "ERROR: The soap server executable does not exist!";
			}

			if (soapServerFileName.StartsWith("ERROR"))
			{
				textBoxBottom.Text = soapServerFileName;
				MessageBox.Show(textBoxBottom.Text, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
			}
			else
			{
				textBoxBottom.Text = "Please select the database device to use";
				OpenFileDialog openDevice = new OpenFileDialog();
				openDevice.Filter = "text files (*.txt)|*.txt|All files (*.*)|*.*" ;
				openDevice.FilterIndex = 2 ;
				openDevice.RestoreDirectory = true ;
				openDevice.Title = textBoxBottom.Text;

				if(openDevice.ShowDialog() == DialogResult.OK)
				{
					Stream myStream;
					if((myStream = openDevice.OpenFile())!= null)
					{
						serverArgs += "\"" + openDevice.FileName + "\"";
						myStream.Close();
					}
					else serverArgs = "ERROR: The device does not exist!";
				}

				if (serverArgs.StartsWith("ERROR"))
				{
					textBoxBottom.Text = serverArgs;
					MessageBox.Show(textBoxBottom.Text, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
				}
				else
				{
					Process newp = new Process();
					newp.StartInfo.FileName = soapServerFileName;
					newp.StartInfo.Arguments = serverArgs;
					string workingDirectory = soapServerFileName.Substring(0, soapServerFileName.LastIndexOf('\\')); 
					newp.StartInfo.WorkingDirectory = workingDirectory;
					this.soapServerPath = soapServerFileName; this.soapServerArgs = serverArgs;
					newp.Start();
					this.soapServerURL = "http://localhost:18082/";
					this.f1.Text = "University of Michigan - The Timber Project - Connected to Local Server at: " + this.soapServerURL;
				}
			}
		}

		private void menuItem27_Click(object sender, System.EventArgs e)
		{
			if(this.soapServerPath.StartsWith("ERROR"))
			{
				textBoxBottom.Text = "ERROR: You need to start the server successfully from the GUI before using the reboot option";
				MessageBox.Show(textBoxBottom.Text, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
			}
			else
			{
				if (this.soapServerURL.Equals("http://localhost:18082/")) 
				{
					// create a new timber soap server object
					WebReference1.soapTimber tSoap = new WebReference1.soapTimber();
					tSoap.Timeout = this.soapTimeOut;
					try
					{
						bool isWarning = false, isError = false;
						string warning, error;
						isWarning = tSoap.shutDownSoapServer(out warning, out isError, out error);
						if (isWarning) MessageBox.Show(warning, "Warning", MessageBoxButtons.OK, MessageBoxIcon.Warning);
						if (isError) MessageBox.Show(error, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
					}
					catch (Exception exc) 
					{
						string output = exc.ToString();
					}

					Process newp = new Process();
					newp.StartInfo.FileName = this.soapServerPath;
					newp.StartInfo.Arguments = this.soapServerArgs;
					string workingDirectory = this.soapServerPath.Substring(0, this.soapServerPath.LastIndexOf('\\')); 
					newp.StartInfo.WorkingDirectory = workingDirectory;
					newp.Start();
					this.soapServerURL = "http://localhost:18082/";
				}
				else 
				{
					textBoxBottom.Text = "ERROR: You can only reboot a local server";
					MessageBox.Show(textBoxBottom.Text, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
				}
			}
		
		}

		private void menuItem30_Click(object sender, System.EventArgs e)
		{
			Form4 form4 = new Form4();
			form4.l1 = "Server URL:";
			form4.l2 = "e.g. http://review.eecs.umich.edu:18082/";
			form4.t1 = "http://serverURI:18082/";
			form4.initlabels();
			
			form4.ShowDialog();
			if (form4.DialogResult == DialogResult.OK)
				this.soapServerURL = form4.result;
			this.menuItem19.Enabled = false;
			this.menuItem27.Enabled = false;
			this.menuItem28.Enabled = false;
			this.menuItem2.Enabled = false;
			this.menuItem3.Enabled = false;
			this.f1.Text = "University of Michigan - The Timber Project - Connected to Remote Server at: " + this.soapServerURL;
			
		}

		private void menuItem31_Click(object sender, System.EventArgs e)
		{
			this.soapServerURL = "http://localhost:18082/";
			this.menuItem19.Enabled = true;
			this.menuItem27.Enabled = true;
			this.menuItem28.Enabled = true;
			this.menuItem2.Enabled = true;
			this.menuItem3.Enabled = true;
			this.f1.Text = "University of Michigan - The Timber Project - Connected to Local Server at: " + this.soapServerURL;
		}

		private void menuItem32_Click(object sender, System.EventArgs e)
		{
			Form4 form4 = new Form4();
			form4.l1 = "Client Timeout:";
			form4.l2 = "e.g. 330000 milliseconds";
			form4.t1 = "330000";
			form4.initlabels();
			
			form4.ShowDialog();
			if (form4.DialogResult == DialogResult.OK)
				this.soapTimeOut = int.Parse(form4.result);

		}






	}
}
