using System;
using System.Drawing;
using System.Collections;
using System.ComponentModel;
using System.Windows.Forms;

namespace MainGUI
{
	/// <summary>
	/// Summary description for Form2.
	/// </summary>
	internal class Form2 : System.Windows.Forms.Form
	{
		private System.Windows.Forms.Label indexcommand;
		private System.Windows.Forms.Button button1;
		private System.Windows.Forms.Button button2;
		/// <summary>
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.Container components = null;
		private System.Windows.Forms.GroupBox groupBox2;
		private System.Windows.Forms.GroupBox groupBox3;
		private System.Windows.Forms.RadioButton radioButton1;
		private System.Windows.Forms.RadioButton radioButton2;
		private System.Windows.Forms.RadioButton radioButton3;
		private System.Windows.Forms.RadioButton radioButton4;
		private System.Windows.Forms.TextBox textBox1;
		internal string result;
		private string document;
		private string type;
		private System.Windows.Forms.RadioButton radioButton5;
		private System.Windows.Forms.RadioButton radioButton6;
		private System.Windows.Forms.RadioButton radioButton7;
		private System.Windows.Forms.RadioButton radioButton8;
		private System.Windows.Forms.RadioButton radioButton9;
		private System.Windows.Forms.RadioButton radioButton10;
		private System.Windows.Forms.RadioButton radioButton11;
		private System.Windows.Forms.RadioButton radioButton12;
		private System.Windows.Forms.RadioButton radioButton13;
		private System.Windows.Forms.RadioButton radioButton14;
		private System.Windows.Forms.GroupBox groupBox4;
		private System.Windows.Forms.RadioButton radioButton15;
		private System.Windows.Forms.TextBox elementContent;
		private System.Windows.Forms.TextBox attributeContent;
		private System.Windows.Forms.GroupBox groupBox5;
		private string parameters;

		internal Form2()
		{
			//
			// Required for Windows Form Designer support
			//
			InitializeComponent();
			this.result = "error";
			this.document = "sbook.xml";
			this.type = "i";
			this.parameters = "et";

			//
			// TODO: Add any constructor code after InitializeComponent call
			//
		}

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		protected override void Dispose( bool disposing )
		{
			if( disposing )
			{
				if(components != null)
				{
					components.Dispose();
				}
			}
			base.Dispose( disposing );
		}

		#region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			System.Resources.ResourceManager resources = new System.Resources.ResourceManager(typeof(Form2));
			this.indexcommand = new System.Windows.Forms.Label();
			this.button1 = new System.Windows.Forms.Button();
			this.button2 = new System.Windows.Forms.Button();
			this.groupBox2 = new System.Windows.Forms.GroupBox();
			this.radioButton4 = new System.Windows.Forms.RadioButton();
			this.radioButton3 = new System.Windows.Forms.RadioButton();
			this.radioButton2 = new System.Windows.Forms.RadioButton();
			this.radioButton1 = new System.Windows.Forms.RadioButton();
			this.groupBox3 = new System.Windows.Forms.GroupBox();
			this.elementContent = new System.Windows.Forms.TextBox();
			this.radioButton15 = new System.Windows.Forms.RadioButton();
			this.radioButton14 = new System.Windows.Forms.RadioButton();
			this.radioButton13 = new System.Windows.Forms.RadioButton();
			this.radioButton12 = new System.Windows.Forms.RadioButton();
			this.radioButton11 = new System.Windows.Forms.RadioButton();
			this.radioButton10 = new System.Windows.Forms.RadioButton();
			this.radioButton9 = new System.Windows.Forms.RadioButton();
			this.radioButton8 = new System.Windows.Forms.RadioButton();
			this.radioButton7 = new System.Windows.Forms.RadioButton();
			this.radioButton6 = new System.Windows.Forms.RadioButton();
			this.radioButton5 = new System.Windows.Forms.RadioButton();
			this.attributeContent = new System.Windows.Forms.TextBox();
			this.textBox1 = new System.Windows.Forms.TextBox();
			this.groupBox4 = new System.Windows.Forms.GroupBox();
			this.groupBox5 = new System.Windows.Forms.GroupBox();
			this.groupBox2.SuspendLayout();
			this.groupBox3.SuspendLayout();
			this.groupBox4.SuspendLayout();
			this.groupBox5.SuspendLayout();
			this.SuspendLayout();
			// 
			// indexcommand
			// 
			this.indexcommand.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((System.Byte)(161)));
			this.indexcommand.Location = new System.Drawing.Point(8, 16);
			this.indexcommand.Name = "indexcommand";
			this.indexcommand.Size = new System.Drawing.Size(384, 16);
			this.indexcommand.TabIndex = 1;
			this.indexcommand.Text = "sbook.xml i et";
			// 
			// button1
			// 
			this.button1.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
			this.button1.Location = new System.Drawing.Point(248, 352);
			this.button1.Name = "button1";
			this.button1.TabIndex = 2;
			this.button1.Text = "OK";
			this.button1.Click += new System.EventHandler(this.button1_Click);
			// 
			// button2
			// 
			this.button2.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
			this.button2.Location = new System.Drawing.Point(336, 352);
			this.button2.Name = "button2";
			this.button2.TabIndex = 3;
			this.button2.Text = "Cancel";
			this.button2.Click += new System.EventHandler(this.button2_Click);
			// 
			// groupBox2
			// 
			this.groupBox2.Controls.AddRange(new System.Windows.Forms.Control[] {
																					this.radioButton4,
																					this.radioButton3,
																					this.radioButton2,
																					this.radioButton1});
			this.groupBox2.Location = new System.Drawing.Point(8, 80);
			this.groupBox2.Name = "groupBox2";
			this.groupBox2.Size = new System.Drawing.Size(120, 120);
			this.groupBox2.TabIndex = 5;
			this.groupBox2.TabStop = false;
			this.groupBox2.Text = "Type";
			// 
			// radioButton4
			// 
			this.radioButton4.Location = new System.Drawing.Point(8, 88);
			this.radioButton4.Name = "radioButton4";
			this.radioButton4.TabIndex = 3;
			this.radioButton4.Text = "double";
			this.radioButton4.CheckedChanged += new System.EventHandler(this.radioButton4_CheckedChanged);
			// 
			// radioButton3
			// 
			this.radioButton3.Location = new System.Drawing.Point(8, 64);
			this.radioButton3.Name = "radioButton3";
			this.radioButton3.TabIndex = 2;
			this.radioButton3.Text = "float";
			this.radioButton3.CheckedChanged += new System.EventHandler(this.radioButton3_CheckedChanged);
			// 
			// radioButton2
			// 
			this.radioButton2.Location = new System.Drawing.Point(8, 40);
			this.radioButton2.Name = "radioButton2";
			this.radioButton2.TabIndex = 1;
			this.radioButton2.Text = "integer";
			this.radioButton2.CheckedChanged += new System.EventHandler(this.radioButton2_CheckedChanged);
			// 
			// radioButton1
			// 
			this.radioButton1.Location = new System.Drawing.Point(8, 16);
			this.radioButton1.Name = "radioButton1";
			this.radioButton1.TabIndex = 0;
			this.radioButton1.Text = "string";
			this.radioButton1.CheckedChanged += new System.EventHandler(this.radioButton1_CheckedChanged);
			// 
			// groupBox3
			// 
			this.groupBox3.Controls.AddRange(new System.Windows.Forms.Control[] {
																					this.elementContent,
																					this.radioButton15,
																					this.radioButton14,
																					this.radioButton13,
																					this.radioButton12,
																					this.radioButton11,
																					this.radioButton10,
																					this.radioButton9,
																					this.radioButton8,
																					this.radioButton7,
																					this.radioButton6,
																					this.radioButton5,
																					this.attributeContent});
			this.groupBox3.Location = new System.Drawing.Point(144, 8);
			this.groupBox3.Name = "groupBox3";
			this.groupBox3.Size = new System.Drawing.Size(272, 288);
			this.groupBox3.TabIndex = 6;
			this.groupBox3.TabStop = false;
			this.groupBox3.Text = "Parameters";
			// 
			// elementContent
			// 
			this.elementContent.Enabled = false;
			this.elementContent.Location = new System.Drawing.Point(128, 40);
			this.elementContent.Name = "elementContent";
			this.elementContent.Size = new System.Drawing.Size(136, 20);
			this.elementContent.TabIndex = 11;
			this.elementContent.Text = "value";
			this.elementContent.TextChanged += new System.EventHandler(this.elementContent_TextChanged);
			// 
			// radioButton15
			// 
			this.radioButton15.Location = new System.Drawing.Point(8, 256);
			this.radioButton15.Name = "radioButton15";
			this.radioButton15.TabIndex = 10;
			this.radioButton15.Text = "Parent";
			this.radioButton15.CheckedChanged += new System.EventHandler(this.radioButton15_CheckedChanged);
			// 
			// radioButton14
			// 
			this.radioButton14.Location = new System.Drawing.Point(8, 232);
			this.radioButton14.Name = "radioButton14";
			this.radioButton14.Size = new System.Drawing.Size(168, 24);
			this.radioButton14.TabIndex = 9;
			this.radioButton14.Text = "Inverted Element no Stem";
			this.radioButton14.CheckedChanged += new System.EventHandler(this.radioButton14_CheckedChanged);
			// 
			// radioButton13
			// 
			this.radioButton13.Location = new System.Drawing.Point(8, 208);
			this.radioButton13.Name = "radioButton13";
			this.radioButton13.Size = new System.Drawing.Size(160, 24);
			this.radioButton13.TabIndex = 8;
			this.radioButton13.Text = "Inverted Element with Stem";
			this.radioButton13.CheckedChanged += new System.EventHandler(this.radioButton13_CheckedChanged);
			// 
			// radioButton12
			// 
			this.radioButton12.Location = new System.Drawing.Point(8, 184);
			this.radioButton12.Name = "radioButton12";
			this.radioButton12.Size = new System.Drawing.Size(136, 24);
			this.radioButton12.TabIndex = 7;
			this.radioButton12.Text = "Inverted Text no Stem";
			this.radioButton12.CheckedChanged += new System.EventHandler(this.radioButton12_CheckedChanged);
			// 
			// radioButton11
			// 
			this.radioButton11.Location = new System.Drawing.Point(8, 160);
			this.radioButton11.Name = "radioButton11";
			this.radioButton11.Size = new System.Drawing.Size(144, 24);
			this.radioButton11.TabIndex = 6;
			this.radioButton11.Text = "Inverted Text with Stem";
			this.radioButton11.CheckedChanged += new System.EventHandler(this.radioButton11_CheckedChanged);
			// 
			// radioButton10
			// 
			this.radioButton10.Location = new System.Drawing.Point(8, 136);
			this.radioButton10.Name = "radioButton10";
			this.radioButton10.TabIndex = 5;
			this.radioButton10.Text = "Text Value";
			this.radioButton10.CheckedChanged += new System.EventHandler(this.radioButton10_CheckedChanged);
			// 
			// radioButton9
			// 
			this.radioButton9.Location = new System.Drawing.Point(8, 112);
			this.radioButton9.Name = "radioButton9";
			this.radioButton9.Size = new System.Drawing.Size(112, 24);
			this.radioButton9.TabIndex = 4;
			this.radioButton9.Text = "Attribute Content";
			this.radioButton9.CheckedChanged += new System.EventHandler(this.radioButton9_CheckedChanged);
			// 
			// radioButton8
			// 
			this.radioButton8.Location = new System.Drawing.Point(8, 88);
			this.radioButton8.Name = "radioButton8";
			this.radioButton8.TabIndex = 3;
			this.radioButton8.Text = "Attribute Value";
			this.radioButton8.CheckedChanged += new System.EventHandler(this.radioButton8_CheckedChanged);
			// 
			// radioButton7
			// 
			this.radioButton7.Location = new System.Drawing.Point(8, 64);
			this.radioButton7.Name = "radioButton7";
			this.radioButton7.TabIndex = 2;
			this.radioButton7.Text = "Attribute Name";
			this.radioButton7.CheckedChanged += new System.EventHandler(this.radioButton7_CheckedChanged);
			// 
			// radioButton6
			// 
			this.radioButton6.Location = new System.Drawing.Point(8, 40);
			this.radioButton6.Name = "radioButton6";
			this.radioButton6.Size = new System.Drawing.Size(112, 24);
			this.radioButton6.TabIndex = 1;
			this.radioButton6.Text = "Element Content";
			this.radioButton6.CheckedChanged += new System.EventHandler(this.radioButton6_CheckedChanged);
			// 
			// radioButton5
			// 
			this.radioButton5.Location = new System.Drawing.Point(8, 16);
			this.radioButton5.Name = "radioButton5";
			this.radioButton5.TabIndex = 0;
			this.radioButton5.Text = "Element Tag";
			this.radioButton5.CheckedChanged += new System.EventHandler(this.radioButton5_CheckedChanged);
			// 
			// attributeContent
			// 
			this.attributeContent.Enabled = false;
			this.attributeContent.Location = new System.Drawing.Point(128, 112);
			this.attributeContent.Name = "attributeContent";
			this.attributeContent.Size = new System.Drawing.Size(136, 20);
			this.attributeContent.TabIndex = 11;
			this.attributeContent.Text = "value";
			this.attributeContent.TextChanged += new System.EventHandler(this.attributeContent_TextChanged);
			// 
			// textBox1
			// 
			this.textBox1.Location = new System.Drawing.Point(8, 16);
			this.textBox1.Name = "textBox1";
			this.textBox1.Size = new System.Drawing.Size(104, 20);
			this.textBox1.TabIndex = 7;
			this.textBox1.Text = "sbook.xml";
			this.textBox1.TextChanged += new System.EventHandler(this.textBox1_TextChanged);
			// 
			// groupBox4
			// 
			this.groupBox4.Controls.AddRange(new System.Windows.Forms.Control[] {
																					this.textBox1});
			this.groupBox4.Location = new System.Drawing.Point(8, 8);
			this.groupBox4.Name = "groupBox4";
			this.groupBox4.Size = new System.Drawing.Size(120, 48);
			this.groupBox4.TabIndex = 10;
			this.groupBox4.TabStop = false;
			this.groupBox4.Text = "Document";
			// 
			// groupBox5
			// 
			this.groupBox5.Controls.AddRange(new System.Windows.Forms.Control[] {
																					this.indexcommand});
			this.groupBox5.Location = new System.Drawing.Point(8, 304);
			this.groupBox5.Name = "groupBox5";
			this.groupBox5.Size = new System.Drawing.Size(408, 40);
			this.groupBox5.TabIndex = 11;
			this.groupBox5.TabStop = false;
			this.groupBox5.Text = "Index Command";
			// 
			// Form2
			// 
			this.AutoScale = false;
			this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
			this.ClientSize = new System.Drawing.Size(424, 383);
			this.Controls.AddRange(new System.Windows.Forms.Control[] {
																		  this.groupBox5,
																		  this.groupBox4,
																		  this.groupBox3,
																		  this.groupBox2,
																		  this.button2,
																		  this.button1});
			this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog;
			this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
			this.MaximizeBox = false;
			this.Name = "Form2";
			this.Text = "Build Index";
			this.Load += new System.EventHandler(this.Form2_Load);
			this.groupBox2.ResumeLayout(false);
			this.groupBox3.ResumeLayout(false);
			this.groupBox4.ResumeLayout(false);
			this.groupBox5.ResumeLayout(false);
			this.ResumeLayout(false);

		}
		#endregion

		private void button1_Click(object sender, System.EventArgs e)
		{
			this.DialogResult = DialogResult.OK;
			this.Close();
		}

		private void button2_Click(object sender, System.EventArgs e)
		{
			this.DialogResult = DialogResult.Cancel;
			this.Close();

		}


		private void textBox1_TextChanged(object sender, System.EventArgs e)
		{
			this.document = this.textBox1.Text;
			this.resetIndexCommand();
		}

		private void resetIndexCommand()
		{
			this.result = this.document + "\t" + this.type + "\t" + this.parameters;
			this.indexcommand.Text = this.result.Replace("\t", " ");
		}

		private void gist_CheckedChanged(object sender, System.EventArgs e)
		{
			this.resetIndexCommand();
		}

		private void shore_CheckedChanged(object sender, System.EventArgs e)
		{
			this.resetIndexCommand();
		
		}

		private void radioButton1_CheckedChanged(object sender, System.EventArgs e)
		{
			this.type = "s";
			this.resetIndexCommand();
		}

		private void radioButton2_CheckedChanged(object sender, System.EventArgs e)
		{
			this.type = "i";
			this.resetIndexCommand();

		}

		private void radioButton3_CheckedChanged(object sender, System.EventArgs e)
		{
			this.type = "f";
			this.resetIndexCommand();

		}

		private void radioButton4_CheckedChanged(object sender, System.EventArgs e)
		{
			this.type = "d";
			this.resetIndexCommand();

		}

		private void radioButton5_CheckedChanged(object sender, System.EventArgs e)
		{
			this.elementContent.Enabled = false;
			this.attributeContent.Enabled = false;
			this.parameters = "et";
			this.resetIndexCommand();
		
		}

		private void radioButton6_CheckedChanged(object sender, System.EventArgs e)
		{
			this.elementContent.Enabled = true;
			this.attributeContent.Enabled = false;
			this.parameters = "ec" + "\t" + this.elementContent.Text;
			this.resetIndexCommand();
		}

		private void elementContent_TextChanged(object sender, System.EventArgs e)
		{
			this.parameters = "ec" + "\t" + this.elementContent.Text;
			this.resetIndexCommand();		
		}

		private void radioButton7_CheckedChanged(object sender, System.EventArgs e)
		{
			this.elementContent.Enabled = false;
			this.attributeContent.Enabled = false;
			this.parameters = "an";
			this.resetIndexCommand();
		}

		private void radioButton8_CheckedChanged(object sender, System.EventArgs e)
		{
			this.elementContent.Enabled = false;
			this.attributeContent.Enabled = false;
			this.parameters = "av";
			this.resetIndexCommand();
		}

		private void radioButton9_CheckedChanged(object sender, System.EventArgs e)
		{
			this.elementContent.Enabled = false;
			this.attributeContent.Enabled = true;
			this.parameters = "ac" + "\t" + this.attributeContent.Text;
			this.resetIndexCommand();		
		}

		private void attributeContent_TextChanged(object sender, System.EventArgs e)
		{
			this.parameters = "ac" + "\t" + this.attributeContent.Text;
			this.resetIndexCommand();				
		}

		private void radioButton10_CheckedChanged(object sender, System.EventArgs e)
		{
			this.elementContent.Enabled = false;
			this.attributeContent.Enabled = false;
			this.parameters = "v";
			this.resetIndexCommand();		
		}

		private void radioButton11_CheckedChanged(object sender, System.EventArgs e)
		{
			this.elementContent.Enabled = false;
			this.attributeContent.Enabled = false;
			this.parameters = "its";
			this.resetIndexCommand();		
		}

		private void radioButton12_CheckedChanged(object sender, System.EventArgs e)
		{
			this.elementContent.Enabled = false;
			this.attributeContent.Enabled = false;
			this.parameters = "itn";
			this.resetIndexCommand();		
		}

		private void radioButton13_CheckedChanged(object sender, System.EventArgs e)
		{
			this.elementContent.Enabled = false;
			this.attributeContent.Enabled = false;
			this.parameters = "ies";
			this.resetIndexCommand();		
		}

		private void radioButton14_CheckedChanged(object sender, System.EventArgs e)
		{
			this.elementContent.Enabled = false;
			this.attributeContent.Enabled = false;
			this.parameters = "ien";
			this.resetIndexCommand();		
		}

		private void radioButton15_CheckedChanged(object sender, System.EventArgs e)
		{
			this.elementContent.Enabled = false;
			this.attributeContent.Enabled = false;
			this.parameters = "p";
			this.resetIndexCommand();		
		}

		private void Form2_Load(object sender, System.EventArgs e)
		{
			this.radioButton2.Checked = true;
			this.radioButton5.Checked = true;
		}

	}
}
