package edu.umich.db.af;



import edu.mit.broad.genome.XLogger;
import edu.mit.broad.genome.objects.GeneSet;
import edu.mit.broad.genome.objects.RankedList;
import org.apache.log4j.Logger;
import edu.mit.broad.genome.alg.gsea.*;



public class Scoringtable {

    private static final Logger klog = XLogger.getLogger(Scoringtable.class);

    static abstract class AbstractScoringTable implements GeneSetScoringTable {


        public AbstractScoringTable() {
        }

        public int hashCode() {
            return getName().hashCode();
        }

        public boolean equals(Object obj) {

            if (obj instanceof GeneSetScoringTable) {
                return getName().equalsIgnoreCase(((GeneSetScoringTable) obj).getName());
            }

            return false;
        }

        public String toString() {
            return getName();
        }
    }


    // Needed as cdna give some nans for the class metric
    private static float _abs(float score) {
        if (Float.isNaN(score) || Float.isInfinite(score)) {
            return 0.01f;
        } else {
            return Math.abs(score);
        }
    }


    public static class Weighted extends AbstractScoringTable {

        private static final String NAME = "weighted";
        private float totalWeight;
        private float nhExpected;

        private float miss_score;
        private GeneSet gset;
        private RankedList rankedList;

       
        public Weighted() {
        }
        
   //change weighting based on appearance frequency
        public Weighted(final GeneSet gset, final RankedList rl) {
            this.gset = gset;
            this.nhExpected = gset.getNumMembers();
            if (nhExpected == 0) {
                throw new IllegalArgumentException("Number of members in gene set cannot be 0: " + gset.getName());
            }
            this.rankedList = rl;
            for (int i = 0; i < this.gset.getNumMembers(); i++) {
            	String probename=gset.getMember(i);
            	float score=this.rankedList.getScore(probename);
            	float weightedscore=score;          
            	if (GSWparser.inthelist(probename)==true){
        			String weight=GSWparser.getweight(probename);
        			float f = Float.valueOf(weight).floatValue();
        		    double para=Math.log(195/f);
        			weightedscore=(float) Math.pow(_abs(score),4/para);
        			totalWeight += _abs(weightedscore);
            	}
        		else{
        			totalWeight += _abs(score);            		
        		}
        	final float Total = rankedList.getSize();
        	this.miss_score = 1.0f / (Total - nhExpected);
      
           }
        }

       
       

        public String getName() {
            return NAME;
        }

        public RankedList getRankedList() {
            return rankedList;
        }

        public boolean isTwoSidedEs() {
            return false;
        }

        public GeneSetScoringTable createTable(final GeneSet gset, final RankedList rl, final RankedList realRankedList) {
        	return new Weighted(gset, rl);
        }

        public float getHitScore(final String name) {
            float score = rankedList.getScore(name);
            score = _abs(score);
            float weightedscore=score;
            if (GSWparser.inthelist(name)==true){
        			String weight=GSWparser.getweight(name);
        			float f = Float.valueOf(weight).floatValue();
        			double para=Math.log(195/f);
        			weightedscore=(float) Math.pow(score,4/para);
        		}
        	else{
        			weightedscore=score;           		
        	}
        		return weightedscore/totalWeight;
       
        }      

        // misses are not weighted
        public float getMissScore(String name) {
            return miss_score;
        }
        
    } // End class Weighted

}