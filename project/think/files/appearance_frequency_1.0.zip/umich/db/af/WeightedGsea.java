package edu.umich.db.af;

public class WeightedGsea implements Comparable{	
	
	
	public String setname;
	public float nes;
	public float es;
	public float np;

	public WeightedGsea(String setname,float nes,float es,float np){
		this.setname=setname;
		this.nes=nes;
		this.es=es;
		this.np=np;
	}
	
	public int compareTo(Object obj){
		WeightedGsea wge=(WeightedGsea)obj;
		if(this.nes<wge.nes){
			return -1;
		}else if (this.nes>wge.nes){
			return 1;
		}
		return 0;
	}
}
