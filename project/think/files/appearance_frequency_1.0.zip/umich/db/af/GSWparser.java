package edu.umich.db.af;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.io.StreamTokenizer;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.HashMap;
import java.util.Set;
import java.util.StringTokenizer;
import java.util.Vector;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import edu.mit.broad.vdb.chip.Chip;

public class GSWparser {

	public static Map<String, String> GSW1=new HashMap<String, String>();
	
    static Map<String,Vector<String>> chipmap=new HashMap<String,Vector<String>>();

    
    public static void matchname(String chipname) throws IOException{
    
    	String thisline;
    	BufferedReader line=new BufferedReader(new FileReader(chipname));
    	 while((thisline=line.readLine())!=null){
    		 Pattern path=Pattern.compile("(.*?)(\\s)(.*?)(\\s)(.*?)");
             Matcher match=path.matcher(thisline);
             if(match.find()){
             	//System.out.println(match.group(1)+" "+match.group(3));
            	 String probname=match.group(1);
            	 String genesymbol=match.group(3);
            	 if(!chipmap.containsKey(genesymbol)){
            		 Vector<String> probvector=new Vector<String>();
            		 probvector.add(probname);
            		 chipmap.put(genesymbol,probvector);	 
            	 }
            	 else{
            		 Vector<String> oldvector=chipmap.get(genesymbol);
            		 oldvector.add(probname);
            		 chipmap.put(genesymbol, oldvector);
            	 }
             }
    	 }
    }
	
	
	
	
	public static void parse(String chipname, String filename) throws IOException{
		    try {
				//Chip target_chip = ParserFactory.readChip(new File(chipname), false);
				GSWparser.matchname(chipname);
				File readfile=new File(filename);
				String path=readfile.getAbsolutePath();
				BufferedReader bin = new BufferedReader(new FileReader(path));
				String[] temp;
				String delimeter="\t";
				String currline,genename,weightsymbol;
				currline=bin.readLine();
				while ((currline=bin.readLine())!=null){
			    	temp=currline.split(delimeter);
			    	genename=temp[0].toUpperCase();
			    	//System.out.println(genename);
			    	Vector<String> probes=chipmap.get(genename);
					//Set probes=target_chip.getProbeNames(genename);
					if (probes!=null){
						Iterator it=probes.iterator();
						while(it.hasNext()){
							String probe=(String) it.next();
							for (int i=1;i<temp.length;i++){
									int row=i;
									weightsymbol=temp[i];
									//System.out.println(i+" "+probe+" "+weightsymbol);
									GSW1.put(probe,weightsymbol);
								}		
						}
					}
					else{
						for (int i=1;i<temp.length;i++){
								int row=i;
								weightsymbol=temp[i];					
								GSW1.put(genename,weightsymbol);
							}
					}
				}
			} catch (Exception e) {
				e.printStackTrace();
			}	
	}		
	
	public static boolean inthelist(String genename)
	{
		boolean yesorno=true;
		yesorno=GSW1.containsKey(genename);
		return yesorno;
		
	}
	
	public static String getweight(String probename){
		String geneweight = null;
		geneweight=GSW1.get(probename);
		return geneweight;	
	}
}
