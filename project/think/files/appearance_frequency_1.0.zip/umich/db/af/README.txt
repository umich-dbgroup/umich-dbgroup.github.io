1. Download the GSEA code from GSEA website.

http://www.broadinstitute.org/cancer/software/gsea/wiki/index.php/Java_Source_Code

2. Open the GSEA code in Eclipse.

3. Include all the reference libraries from lib folder of GSEA code.

4. Include the umich package in the GSEA code.

5. Change the name of data file. "AFkegg.txt" has the appearance frequence of genes in KEGG database. "AFrandom.txt" has the random apperance frequency of genes. "AFinverse.txt" has the inverse apperance frequency of genes. 

6. Run the code from the umich.db.af.


