package edu.umich.db.af;

import edu.mit.broad.genome.alg.DatasetMetrics;
import edu.mit.broad.genome.alg.GeneSetGenerators;
import edu.mit.broad.genome.alg.gsea.*;
import edu.mit.broad.genome.objects.Dataset;
import edu.mit.broad.genome.objects.GeneSet;
import edu.mit.broad.genome.objects.GeneSetMatrix;
import edu.mit.broad.genome.objects.Template;
import edu.mit.broad.genome.objects.esmatrix.db.EnrichmentDb;
import edu.mit.broad.genome.objects.esmatrix.db.EnrichmentResult;
import edu.mit.broad.genome.parsers.ClsParser;
import edu.mit.broad.genome.parsers.GctParser;
import edu.mit.broad.genome.parsers.GmtParser;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.PrintWriter;
import java.lang.reflect.Array;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;


public class Main{

	public static void  main(String[] args) {
        try {
        	//chip used for study
        	String chipname="HG_U95Av2.chip";
        	//String chipname="HU6800.chip";
        	//String chipname="HG_U133A.chip";
            //weighting method
        	String weightfile="AFkegg.txt";
        	//chip map to probes
            String mapname="mappedkegg95Av2.gmt";
            //String mapname="mappedkeggHU.gmt";
            //String mapname="mappedkegg.gmt";
        	//data file
        	String dbfile="Lung_Boston_hgu95av2.gct";
        	//String dbfile="Lung_Michigan_hu6800.gct";
        	//String dbfile="expns3994.gct";
        	//chip format file
        	String clsfile="Lung_Boston.cls";
            //String clsfile="Lung_Michigan.cls";
        	//String clsfile="3994.cls";
        	//save result to file 
        	String savefile="lungboston.txt";
            //String savefile="3994random.txt";
        	//parse weighting file
            GSWparser.parse(chipname,weightfile);
            
            Dataset ds = (Dataset) new GctParser().parse("my_ds", new File(dbfile)).get(0);
            GeneSetMatrix gm = (GeneSetMatrix) new GmtParser().parse("foo", new File(mapname)).get(0);
            Template t = (Template) new ClsParser().parse("my_phenotype", new File(clsfile)).get(0);
             
            int min_set_size = 25;
            int max_set_size = 500;
            // @note that the gene sets are first restricted to the dataset feature space and then the size thresholds are pplied
            GeneSet[] gsets = GeneSetGenerators.removeGeneSetsBySize(gm, min_set_size, max_set_size, ds);

            ModKSTests tests = new ModKSTests();
            int num_permutations = 100;
            int num_markers = 100; // used only for marker analysis - not a gsea algorithm parameter

            boolean permute_phenotype = true; // if false, then gene sets are permuted
            int limit=1;
            //rank metrix
            Map<String,int[]> ranklist=new HashMap<String,int[]>();
            // OK, parameters all done, make the call 	
            
	        BufferedWriter resultfile;
            resultfile=new BufferedWriter(new FileWriter(savefile));
            
            GeneSetScoringTable scoring_scheme = new Scoringtable.Weighted();
            EnrichmentDb edb = tests.executeGsea(ds, t, gsets, num_permutations, scoring_scheme, permute_phenotype, num_markers);
            System.out.println("Done gsea executing");
            
            // EDB now has the stats but not the FDRs yet
            // FDRs can be calc in many ways, heres the gsea way:
            PValueCalculator pvc = new PValueCalculatorImpls.GseaImpl("meandiv");
            final EnrichmentResult[] results = pvc.calcNPValuesAndFDR(edb.getResults());
            final EnrichmentDb edb_with_fdr = edb.cloneDeep(results);
            //save NES value for sorting
            WeightedGsea[] array=new WeightedGsea[edb_with_fdr.getNumResults()];
            for (int i = 0; i < edb_with_fdr.getNumResults(); i++) {
            		EnrichmentResult result = edb_with_fdr.getResult(i);
            		String setname=result.getGeneSetName();
            		float nes=result.getScore().getNES();
            		float es=result.getScore().getES();
            		float np=result.getScore().getNP();
            		array[i]=new WeightedGsea(setname,nes,es,np);    	
            }
            Arrays.sort(array);
            for(int i=0;i<array.length;i++){
            		resultfile.write(i+" "+"name: " + array[i].setname +" NES: " + array[i].nes+" ES: "+array[i].es+" NP:"+array[i].np);
        	        resultfile.newLine();
            }
    	    resultfile.close();
        }
        catch (Throwable t) {
        	t.printStackTrace();
        }
	}
}