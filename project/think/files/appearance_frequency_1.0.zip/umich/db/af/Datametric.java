package edu.umich.db.af;

import edu.mit.broad.genome.Headers;
import edu.mit.broad.genome.MismatchedSizeException;
import edu.mit.broad.genome.XLogger;
import edu.mit.broad.genome.alg.markers.PermutationTest;
import edu.mit.broad.genome.alg.markers.PermutationTestImpl;
import edu.mit.broad.genome.math.*;
import edu.mit.broad.genome.math.Vector;
import edu.mit.broad.genome.objects.*;
import edu.mit.broad.genome.objects.strucs.DatasetTemplate;
import edu.mit.broad.genome.objects.strucs.TemplateRandomizerType;
import edu.mit.broad.xbench.prefs.XPreferencesFactory;
import org.apache.log4j.Logger;
import edu.mit.broad.genome.alg.gsea.*;
import edu.mit.broad.genome.alg.*;

import java.util.*;

public class Datametric {

    private final Logger log = XLogger.getLogger(this.getClass());

    public Datametric() {
    }
    
    public ScoredDataset scoreDataset(final Metric metric,
                                      final SortMode sort,
                                      final Order order,
                                      final Map metricParams,
                                      final LabelledVectorProcessor lvp,
                                      final Dataset ds,
                                      final Template template) {

        AddressedVector av = calcSortedMetric(metric, sort, order, metricParams, lvp, ds, template);

        return new ScoredDatasetImpl(av, ds);
    }


    public AddressedVector calcSortedMetric(final Metric metric,
                                            final SortMode sort,
                                            final Order order,
                                            final Map metricParams,
                                            final LabelledVectorProcessor lvp,
                                            final Dataset ds,
                                            final Template template) {

        return calcSortedMetricStruc(metric, sort, order, metricParams, lvp, ds, template).av;
    }

    public ScoredStruc calcSortedMetricStruc(final Metric metric,
                                             final SortMode sort,
                                             final Order order,
                                             final Map metricParams,
                                             final LabelledVectorProcessor lvp,
                                             final Dataset ds,
                                             final Template template) {

        if (ds == null) {
            throw new IllegalArgumentException("Param ds cannot be null");
        }

        // DONT check for Template -- it can be null for some metrics
        if (sort == null) {
            throw new IllegalArgumentException("Param sort cannot be null");
        }

        if (order == null) {
            throw new IllegalArgumentException("Param order cannot be null");
        }

        List dels = new ArrayList(ds.getNumRow());
        DoubleElement[] datasetSynchedDels = new DoubleElement[ds.getNumRow()];
        for (int i = 0; i < ds.getNumRow(); i++) {
        	String rowname=ds.getRowName(i);
            double dist = metric.getScore(ds.getRow(i), template, metricParams);
            double weighteddist=dist;
            //change rank? used for LRpath
            boolean putweight=false;
             if (putweight==true){
            		 if (GSWparser.inthelist(rowname)==true){
             			String weight=GSWparser.getweight(rowname);
             			float f = Float.valueOf(weight).floatValue();
             			double para=Math.log(195/f);
             			if (dist<0){
             				weighteddist=(float) Math.pow(Math.abs(dist),para/4);
             				weighteddist=-weighteddist;
             			}
             			else{
             				weighteddist=(float) Math.pow(dist,4/para);
             			}
            		 }
            		 else{
            			 weighteddist=dist;		
            		 }
             }
             
            DoubleElement del = new DoubleElement(i, weighteddist);     
            dels.add(del);
            datasetSynchedDels[i] = del;
        }
        DoubleElement.sort(sort, order, dels);
        lvp.process(dels); // @note
        return new ScoredStruc(datasetSynchedDels, new AddressedVector(dels));
    }

 
    public static class ScoredStruc {
        public AddressedVector av;
        public DoubleElement[] datasetSynchedDels; // synched with the dataset that was scored, but not score sorted

        public ScoredDataset sds;

        ScoredStruc(DoubleElement[] dels, AddressedVector av) {
            this.datasetSynchedDels = dels;
            this.av = av;
        }

        public float[] getDatasetSynchedScores() {
            float[] fls = new float[datasetSynchedDels.length];
            for (int f = 0; f < datasetSynchedDels.length; f++) {
                fls[f] = (float) datasetSynchedDels[f].fValue;
            }

            return fls;
        }

    }
 }

