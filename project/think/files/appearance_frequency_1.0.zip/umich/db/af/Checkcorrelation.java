package edu.umich.db.af;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.Arrays;
import java.util.HashMap;
import java.util.Collections;
import java.util.Iterator;
import java.util.List;
import java.util.ArrayList;
import java.util.Vector;
import java.util.regex.Matcher;
import java.util.regex.Pattern;


public class Checkcorrelation {

		/**
		 * @param args
		 * @throws FileNotFoundException 
		 */
	
  public static double getPearsonCorrelation(Double[] scores1,Double[] scores2){
        double result = 0;
        double sum_sq_x = 0;
        double sum_sq_y = 0;
        double sum_coproduct = 0;
        double mean_x = scores1[0];
        double mean_y = scores2[0];
        for(int i=2;i<scores1.length+1;i+=1){
            double sweep =Double.valueOf(i-1)/i;
            double delta_x = scores1[i-1]-mean_x;
            double delta_y = scores2[i-1]-mean_y;
            sum_sq_x += delta_x * delta_x * sweep;
            sum_sq_y += delta_y * delta_y * sweep;
            sum_coproduct += delta_x * delta_y * sweep;
            mean_x += delta_x / i;
            mean_y += delta_y / i;
        }
        double pop_sd_x = (double) Math.sqrt(sum_sq_x/scores1.length);
        double pop_sd_y = (double) Math.sqrt(sum_sq_y/scores1.length);
        double cov_x_y = sum_coproduct / scores1.length;
        result = cov_x_y / (pop_sd_x*pop_sd_y);
        return result;
    }
	
 static HashMap<String, double[]> NEShash=new HashMap<String, double[]>();
	
  public static void extractNES(String filename){
	    Vector<String> pvalues = new Vector();
	    try{
	    String thisline;
	    File readfile=new File(filename);
		String path=readfile.getAbsolutePath();
		BufferedReader in = new BufferedReader(new FileReader(path));	
		while((thisline=in.readLine())!=null){
			Pattern p=Pattern.compile("(name: )(.*?)(NES:)(.*?)(\\s)(ES:)");
			Matcher match=p.matcher(thisline);
			if(match.find()){
				 String name=match.group(2);
				 String nesvalue=match.group(4);
				 double[] nesarray=new double[2];
				 if(!NEShash.containsKey(name)){
					 nesarray[0]=Double.parseDouble(nesvalue);
					 NEShash.put(name, nesarray);
				 }
				 else{
					 nesarray=NEShash.get(name);
					 nesarray[1]=Double.parseDouble(nesvalue);
					 NEShash.put(name, nesarray);
				 }
			//	 System.out.println(name+"\t"+nesarray[0]+"\t"+nesarray[1]);
			}	
		}
	    } catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
}
		


		public void checkNES(String filename1,String filename2){
			Checkcorrelation.extractNES(filename1);
			Checkcorrelation.extractNES(filename2);
		    ArrayList<Double> name1rank=new ArrayList<Double>();
		    ArrayList<Double> name2rank=new ArrayList<Double>();
		    Iterator<String> itr=NEShash.keySet().iterator();
		    double[] nesarray=new double[2];
		    while(itr.hasNext()){
		    	String name=itr.next();
		    	nesarray=NEShash.get(name);
		    	if(nesarray[0]!=0 && nesarray[1]!=0){
		    	name1rank.add(nesarray[0]);
		    	name2rank.add(nesarray[1]);
		    	System.out.println(name+"\t"+nesarray[0]+"\t"+nesarray[1]);
		    	}
		    }
//			System.out.println(a);
		    Double pearson=getPearsonCorrelation(name1rank.toArray(new Double[name1rank.size()]), name2rank.toArray(new Double[name2rank.size()]));
	        System.out.println(pearson);
		}
		
		
		public static void main(String[] args) throws IOException {
			    String filename1="lungboston.txt";
			    String filename2="lungmichigan.txt";
			    Checkcorrelation check=new Checkcorrelation();
			    check.checkNES(filename1,filename2);	 
		}
	}

