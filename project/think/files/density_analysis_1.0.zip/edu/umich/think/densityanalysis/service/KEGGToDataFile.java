package edu.umich.think.densityanalysis.service;

import java.util.ArrayList;
import java.util.HashMap;


public class KEGGToDataFile {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		String s[] = { "hsa04115", "hsa05200", "hsa05210", "hsa05212",
				"hsa05214", "hsa05216", "hsa05221", "hsa05220", "hsa05217",
				"hsa05218", "hsa05211", "hsa05219", "hsa05213", "hsa05222",
				"hsa05223", "hsa05215", "hsa05310", "hsa05322", "hsa05320",
				"hsa05330", "hsa05332", "hsa05340", "hsa05010", "hsa05012",
				"hsa05014", "hsa05016", "hsa05020", "hsa05410", "hsa05412",
				"hsa05414", "hsa04940", "hsa04930", "hsa04950", "hsa05110",
				"ko05111", "hsa05120", "hsa05130", "hsa02010", "hsa02060",
				"hsa03070", "hsa03060", "hsa02020", "hsa04010", "hsa04310",
				"hsa04330", "hsa04340", "hsa04350", "hsa04012", "hsa04370",
				"hsa04630", "hsa04020", "hsa04070", "hsa04150", "hsa04080",
				"hsa04060", "hsa04512", "hsa04514", "hsa04144", "hsa04142",
				"hsa04140", "hsa02030", "hsa04810", "hsa04110", "hsa04210",
				"hsa04510", "hsa04520", "hsa04530", "hsa04540", "hsa04260",
				"hsa04270", "hsa04910", "hsa04920", "hsa03320", "hsa04912",
				"hsa04914", "hsa04916", "hsa04614", "hsa04640", "hsa04610",
				"hsa04620", "hsa04621", "hsa04622", "hsa04650", "hsa04612",
				"hsa04660", "hsa04662", "hsa04664", "hsa04666", "hsa04670",
				"hsa04062", "hsa04720", "hsa04730", "hsa04722", "hsa04740",
				"hsa04742", "hsa04320", "hsa04360", "hsa04710" };

		// Stores GSEA vs KEGG gene name mappings
		HashMap<String, String> nameMappings = new HashMap<String, String>();
		PathwayBuilder p = new PathwayBuilder();

		for (int i = 0; i < s.length; i++) {
			String curr = "path:" + s[i];

			// Creating mapping between the element ids and the corresponding
			// KEGG objects
			ArrayList<String> elementMap = p
					.getGenesByPathway(curr);

			HashMap<String, Integer> entered = new HashMap<String, Integer>();

			System.out.print(s[i] + "\tna");
			for (String gene : elementMap) {
				String name = gene;
				String geneName;

				if (entered.containsKey(name)) {
					continue;
				}
				entered.put(name, 1);

				if (nameMappings.containsKey(name)) {
					geneName = nameMappings.get(name);
				} else {
					geneName = p.findname(name);
					if (geneName != null) {
						nameMappings.put(name, geneName);
					}
				}
				if (geneName != null) {
					System.out.print("\t" + geneName);
				}
			}
			System.out.println();
		}
	}
}
