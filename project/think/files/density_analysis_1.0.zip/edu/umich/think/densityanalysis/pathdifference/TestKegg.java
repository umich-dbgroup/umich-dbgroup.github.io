package edu.umich.think.densityanalysis.pathdifference;

import keggapi.*;

public class TestKegg {

	public static void main(String[] args) throws Exception {
		KEGGLocator locator = new KEGGLocator();
		KEGGPortType serv = locator.getKEGGPort();

		String query = "path:bsu00010";
		PathwayElementRelation[] results = serv.get_element_relations_by_pathway("path:bsu00010");

		for (int i = 0; i < results.length; i++) {
			System.out.println(results[i]);
		}
	}
}
