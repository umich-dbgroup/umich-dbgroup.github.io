package edu.umich.think.densityanalysis.service;

import java.io.BufferedReader;
import java.io.FileReader;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;
import java.util.Vector;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import keggapi.KEGGLocator;
import keggapi.KEGGPortType;
import keggapi.PathwayElement;
import keggapi.PathwayElementRelation;
import keggapi.Subtype;
import edu.umich.think.densityanalysis.model.PathwayGraphNode;

/**
 * Class used to build a graph from pathway information retrieved from KEGG.
 */
public class PathwayBuilder {

	public HashMap<Integer, PathwayElement> createElementMap(String pathwayid) {
		
		KEGGLocator locator = new KEGGLocator();
		HashMap<Integer, PathwayElement> elementmap = new HashMap<Integer, PathwayElement>();
		try {
			KEGGPortType serv = locator.getKEGGPort();
			PathwayElement[] results = serv.get_elements_by_pathway(pathwayid);
			for (int i = 0; i < results.length; i++) {
				int elementid = results[i].getElement_id();
				elementmap.put(elementid, results[i]);

			}
		} catch (Exception e) {
			System.out.println(e.getMessage());
		}
		return elementmap;
	}

	public ArrayList<String> getGenesByPathway(String pathwayid) {
		KEGGLocator locator = new KEGGLocator();
		ArrayList<String> elementmap = new ArrayList<String>();
		String[] results;
		try {
			KEGGPortType serv = locator.getKEGGPort();
			results = serv.get_genes_by_pathway(pathwayid);
			for (String gene : results) {
				elementmap.add(gene);
			}
		} catch (Exception e) {
			System.out.println(e.getMessage());
		}
		return elementmap;
	}

	public ArrayList<PathwayGraphNode> buildPathwayGraph(String pathwayId) {
		
		HashMap<Integer, PathwayGraphNode> allNodes = new HashMap<Integer, PathwayGraphNode>();
		createElementMap(pathwayId);
		KEGGLocator locator = new KEGGLocator();
		try {

			KEGGPortType serv = locator.getKEGGPort();
			PathwayElementRelation[] relations = serv
					.get_element_relations_by_pathway(pathwayId);
			for (PathwayElementRelation relation : relations) {
				if (allNodes.get(relation.getElement_id1()) == null) {
					PathwayGraphNode node = new PathwayGraphNode(relation
							.getElement_id1());
					allNodes.put(relation.getElement_id1(), node);
				}
				if (allNodes.get(relation.getElement_id2()) == null) {
					PathwayGraphNode node = new PathwayGraphNode(relation
							.getElement_id2());
					allNodes.put(relation.getElement_id2(), node);
				}

				String type = relation.getType();
				if (type.equals("ECrel")) {
					// System.out.println("ECRel found");
					continue;
				}
				if (type.equals("maplink")) {
					// System.out.println("maplink found");
					continue;
				}
				Subtype[] subtypes = relation.getSubtypes();
				int relationType = 1;
				for (int i = 0; i < subtypes.length; i++) {
					String relationdetail = subtypes[i].getRelation();
					relationType = 1;
					if (relationdetail.equals("inhibition")) {
						// System.out.println("Found inhibition");
						relationType = -1;
						break;
					}
				}
				allNodes.get(relation.getElement_id1()).childNodes.add(allNodes
						.get(relation.getElement_id2()));
				allNodes.get(relation.getElement_id1()).relationType.put(
						new Integer(relation.getElement_id2()), new Integer(
								relationType));
				allNodes.get(relation.getElement_id2()).parentNodes
						.add(allNodes.get(relation.getElement_id1()));
			}
		} catch (Exception e) {
			System.out.println(e.getStackTrace());
		}
		ArrayList<PathwayGraphNode> data = new ArrayList<PathwayGraphNode>();
		for (Object o : allNodes.values()) {
			data.add((PathwayGraphNode) o);
		}
		return data;
	}

	public ArrayList<PathwayGraphNode> getRootNodes(
			ArrayList<PathwayGraphNode> nodes) {
		ArrayList<PathwayGraphNode> rootNodes = new ArrayList<PathwayGraphNode>();
		for (PathwayGraphNode node : nodes) {
			if (node.parentNodes.isEmpty()) {
				rootNodes.add(node);
			}
		}
		return rootNodes;
	}

	static Map<String, Vector<String>> chipmap = new HashMap<String, Vector<String>>();
	public static Map<String, String> genemap = new HashMap<String, String>();

	public static void matchname(String dataSrouce, String chipname) {

		String thisline;
		try {
			BufferedReader line = new BufferedReader(new FileReader(dataSrouce + 
					chipname));
			while ((thisline = line.readLine()) != null) {
				Pattern path = Pattern.compile("(.*?)(\\s)(.*?)(\\s)(.*?)");
				Matcher match = path.matcher(thisline);
				if (match.find()) {
					// System.out.println(match.group(1)+" "+match.group(3));
					String probname = match.group(1);
					String genesymbol = match.group(3);
					genemap.put(probname, genesymbol);
					if (!chipmap.containsKey(genesymbol)) {
						Vector<String> probvector = new Vector<String>();
						probvector.add(probname);
						chipmap.put(genesymbol, probvector);
					} else {
						Vector<String> oldvector = chipmap.get(genesymbol);
						oldvector.add(probname);
						chipmap.put(genesymbol, oldvector);
					}
				}
			}
		} catch (Exception e) {
			System.out.println(e.getMessage());
		}
	}

	public String findname(String name) {
		KEGGLocator locator = new KEGGLocator();
		try {
			KEGGPortType serv = locator.getKEGGPort();
			if (!name.equals("undefined")) {
				String genedef = serv.btit(name);
				String[] genedefs = genedef.split(";");
				String[] findname = genedefs[0].split(" ");
				/**
				 * FFARFAN 20100810
				 * KEGG is now returning an extra comma :( ...
				 */
				String[] genename = findname[1].split(",");
				return genename[0];
			} else {

				return name;
			}
		} catch (Exception e) {
			System.out.println(e.getMessage());
		}
		return null;
	}

}