package edu.umich.think.densityanalysis.pathdifference;

/**
 * THE WHOLE BODY OF THE CLASS HAS BEEN COMMENTED TO AVOID ERROR DECLARATION.
 * Date: 04/12/2010
 * 
 * @author FFarfan
 *
 */

//import java.io.BufferedReader;
//import java.io.BufferedWriter;
//import java.io.File;
//import java.io.FileNotFoundException;
//import java.io.FileOutputStream;
//import java.io.FileReader;
//import java.io.FileWriter;
//import java.io.IOException;
//import java.io.PrintStream;
//import java.lang.reflect.Method;
//import java.rmi.RemoteException;
//import java.util.ArrayList;
//import java.util.Arrays;
//import java.util.HashMap;
//import java.util.HashSet;
//import java.util.Iterator;
//import java.util.List;
//import java.util.Map;
//import java.util.Set;
//import java.util.StringTokenizer;
//import java.util.Vector;
//import java.util.regex.Matcher;
//import java.util.regex.Pattern;
//
//import javax.xml.namespace.QName;
//import javax.xml.rpc.ParameterMode;
//import javax.xml.rpc.ServiceException;
//import javax.xml.soap.MessageFactory;
//import javax.xml.soap.Name;
//import javax.xml.soap.SOAPBody;
//import javax.xml.soap.SOAPBodyElement;
//import javax.xml.soap.SOAPConnection;
//import javax.xml.soap.SOAPConnectionFactory;
//import javax.xml.soap.SOAPFactory;
//import javax.xml.soap.SOAPHeader;
//import javax.xml.soap.SOAPMessage;
//
//import junit.framework.TestCase;
//
//import org.apache.axis.Message;
//import org.apache.axis.MessageContext;
//import org.apache.axis.client.Call;
//import org.apache.axis.client.Service;
//import org.apache.axis.encoding.ser.ArrayDeserializerFactory;
//import org.apache.axis.encoding.ser.ArraySerializerFactory;
//import org.apache.axis.encoding.ser.BeanDeserializerFactory;
//import org.apache.axis.encoding.ser.BeanSerializerFactory;
//import org.apache.axis.encoding.ser.EnumDeserializerFactory;
//import org.apache.axis.encoding.ser.EnumSerializerFactory;
//import org.apache.log4j.BasicConfigurator;
//import org.jdom.Document;
//import org.jdom.input.DOMBuilder;
//import org.jdom.output.Format;
//import org.jdom.output.XMLOutputter;
//import org.reactome.cabig.domain.*;
//import org.reactome.servlet.InstanceNotFoundException;
//import org.reactome.servlet.ReactomeRemoteException;
//
//import connection.DB;
//import edu.umich.eureka.densityanalysis.model.Target;
//
//import sun.misc.Regexp;
//import keggapi.*;

public class Findmember {

//	private final Object[] EMPTY_ARG = new Object[]{};
//    //private static Logger logger = Logger.getLogger(WSUnitTest.class);
//    //private final String SERVICE_URL_NAME = "http://localhost:8080/caBIOWebApp/services/caBIOService";
//    //private final String SERVICE_URL_NAME="http://stinson.cshl.edu:8080/caBIOWebApp/services/caBIOService";
//    private final String SERVICE_URL_NAME="http://www.reactome.org:8080/caBIOWebApp/services/caBIOService";
//    private Service caBIOService;
//
//    private static SOAPFactory soapFactory;
//    
//    private String lowerFirst(String propName) {
//        return propName.substring(0, 1).toLowerCase() + propName.substring(1);
//    }
//    
//    private SOAPMessage generateRequestMessage() throws Exception {
//        MessageFactory factory = MessageFactory.newInstance();
//        SOAPMessage message = factory.createMessage();
//        SOAPHeader header = message.getSOAPHeader();
//        header.detachNode();
//        return message;
//    }
//    
//    private SOAPMessage getResponseMessage(SOAPMessage requestMessage) throws Exception {
//        SOAPConnectionFactory soapConnectionFactory = SOAPConnectionFactory.newInstance();
//        SOAPConnection connection = soapConnectionFactory.createConnection();
//        SOAPMessage response = connection.call(requestMessage, SERVICE_URL_NAME);
//        connection.close();
//        return response;
//    }
//    
//    private void displayMessage(SOAPMessage message) throws IOException {
//        DOMBuilder builder = new DOMBuilder();
//        Document elm = builder.build(message.getSOAPPart());
//        XMLOutputter outputter = new XMLOutputter(Format.getPrettyFormat());
//        outputter.output(elm, System.out);
//        System.out.println("\n");
//    }
//    
//    
//    public void QueryPathwaysForReferenceEntities() throws Exception {
//        long time1 = System.currentTimeMillis();
//        //String[] identifiers = new String[3];
//        //identifiers[0] = "Q9Y266";
//        //identifiers[1] = "P17480";
//        //identifiers[2] = "P20248";
//        Call call = null;
//        String[] identifiers = new String[1];
//        identifiers[0] = "P61218";
//        call = createCall("queryPathwaysForReferenceIdentifiers");
//        Pathway[] pathways = (Pathway[]) call.invoke(new Object[]{identifiers});
//        long time2 = System.currentTimeMillis();
//        System.out.printf("Pathway for a list of identifiers: %d (%d)%n", 
//                pathways.length, (time2 - time1));
//        outputArray(pathways);
//    }
//    
//    public void ListParticipants() throws Exception {
//        Call call = null;
//        long time1 = System.currentTimeMillis();
//        Pathway pathway = new Pathway();
//        //pathway.setId(109581L);
//        pathway.setId(170834L);
//        //pathway.setId(69306L);
//        call = createCall("listPathwayParticipants");
//        Object[] rtn = (Object[]) call.invoke(new Object[]{pathway});
//        long time2 = System.currentTimeMillis();
//        System.out.printf("Participant in Pathway 170834: %d (%d)%n", rtn.length, (time2 - time1));
//        call = createCall("queryByObjects");
//        rtn = (Object[]) call.invoke(new Object[]{rtn});
//        // Check if any Proteins are in
//        Set<ReferenceSequence> proteins = new HashSet<ReferenceSequence>();
//        List<EventEntity> members=new ArrayList<EventEntity>();
//        for (int i = 0; i < rtn.length; i++) {
//            System.out.println(rtn[i].toString());
//            if (rtn[i] instanceof GenomeEncodedEntity) {
//                GenomeEncodedEntity entity = (GenomeEncodedEntity) rtn[i];
//                if (entity.getReferenceEntity() instanceof ReferenceSequence){
//                	//ReferenceSequence protein=entity.getReferenceEntity();
//                    proteins.add(entity.getReferenceEntity());
//                }
//            }
//        }
//        System.out.println("Total proteins: " + proteins.size());
//        int c = 0;
//        for (ReferenceSequence protein: proteins) {
//        	String uniport=protein.getName();
//            System.out.printf("%d: %s%n", c++, uniport);
//        }
//        
//        //call = createCall("listPathwayParticipantsForId");
//        //Object[] rtn1 = (Object[]) call.invoke(new Object[]{new Long(109581L)});
//       // Object[] rtn1 = (Object[]) call.invoke(new Object[]{new Long(170834L)});
//       // assertEquals(rtn1.length, rtn.length);
//        //showCall(call);
//    }
//    
//    
//    
//    private Call createCall(String callName) throws Exception {
//        if (caBIOService == null) {
//            caBIOService = new Service(SERVICE_URL_NAME + "?wsdl", 
//                                       new QName(SERVICE_URL_NAME, 
//                                                 "CaBioDomainWSEndPointService"));
//        }
//        String portName = "caBIOService";
//        Call call = (Call) caBIOService.createCall(new QName(SERVICE_URL_NAME, portName),
//                                                   callName);
//        registerTypeMappings(call);
//        return call;
//    }
//    
//    private void outputArray(Object[] objects) throws Exception {
//        for (Object obj : objects) {
//            printOutput(obj);
//        }
//    }
//    
//    private void printOutput(Object obj) throws Exception {
//        System.out.printf("%s -> %s%n", obj.getClass(), obj.toString());
//        Method[] methods = obj.getClass().getMethods();
//        // Get all getMethods
//        for (Method m : methods) {
//            String mName = m.getName();
//            if (mName.startsWith("get")) {
//                String propName = lowerFirst(mName.substring(3));
//                System.out.printf("\t%s: %s%n", propName, m.invoke(obj, EMPTY_ARG));
//            }
//        }
//    }
//
//    
//    private void registerTypeMappings(Call call) {
//        QName instanceNotFoundModel = new QName("http://www.reactome.org/caBIOWebApp/schema", 
//                                                "InstanceNotFoundException");
//        call.registerTypeMapping(InstanceNotFoundException.class, instanceNotFoundModel,
//                new BeanSerializerFactory(InstanceNotFoundException.class, instanceNotFoundModel),
//                new BeanDeserializerFactory(InstanceNotFoundException.class, instanceNotFoundModel));
//        QName reactomeAxisFaultModel = new QName("http://www.reactome.org/caBIOWebApp/schema", 
//                                                 "ReactomeRemoteException");
//        call.registerTypeMapping(ReactomeRemoteException.class, reactomeAxisFaultModel,
//                new BeanSerializerFactory(ReactomeRemoteException.class, reactomeAxisFaultModel),
//                new BeanDeserializerFactory(ReactomeRemoteException.class, reactomeAxisFaultModel));
//        QName CatalystActivityModel= new QName("http://www.reactome.org/caBIOWebApp/schema", 
//                                               "CatalystActivity");
//        call.registerTypeMapping(CatalystActivity.class, CatalystActivityModel,
//              new BeanSerializerFactory(CatalystActivity.class, CatalystActivityModel),
//              new BeanDeserializerFactory(CatalystActivity.class, CatalystActivityModel));
//        QName ComplexModel= new QName("http://www.reactome.org/caBIOWebApp/schema", 
//                                      "Complex");
//        call.registerTypeMapping(Complex.class, ComplexModel,
//              new BeanSerializerFactory(Complex.class, ComplexModel),
//              new BeanDeserializerFactory(Complex.class, ComplexModel));
//        QName DatabaseCrossReferenceModel= new QName("http://www.reactome.org/caBIOWebApp/schema", "DatabaseCrossReference");
//        call.registerTypeMapping(DatabaseCrossReference.class, DatabaseCrossReferenceModel,
//              new BeanSerializerFactory(DatabaseCrossReference.class, DatabaseCrossReferenceModel),
//              new BeanDeserializerFactory(DatabaseCrossReference.class, DatabaseCrossReferenceModel));
//        QName EventModel= new QName("http://www.reactome.org/caBIOWebApp/schema", "Event");
//        call.registerTypeMapping(Event.class, EventModel,
//              new BeanSerializerFactory(Event.class, EventModel),
//              new BeanDeserializerFactory(Event.class, EventModel));
//        QName EventEntityModel= new QName("http://www.reactome.org/caBIOWebApp/schema", "EventEntity");
//        call.registerTypeMapping(EventEntity.class, EventEntityModel,
//              new BeanSerializerFactory(EventEntity.class, EventEntityModel),
//              new BeanDeserializerFactory(EventEntity.class, EventEntityModel));
//        QName EventEntitySetModel= new QName("http://www.reactome.org/caBIOWebApp/schema", "EventEntitySet");
//        call.registerTypeMapping(EventEntitySet.class, EventEntitySetModel,
//              new BeanSerializerFactory(EventEntitySet.class, EventEntitySetModel),
//              new BeanDeserializerFactory(EventEntitySet.class, EventEntitySetModel));
//        QName GeneOntologyModel= new QName("http://www.reactome.org/caBIOWebApp/schema", "GeneOntology");
//        call.registerTypeMapping(GeneOntology.class, GeneOntologyModel,
//              new BeanSerializerFactory(GeneOntology.class, GeneOntologyModel),
//              new BeanDeserializerFactory(GeneOntology.class, GeneOntologyModel));
//        QName GeneOntologyRelationshipModel= new QName("http://www.reactome.org/caBIOWebApp/schema", "GeneOntologyRelationship");
//        call.registerTypeMapping(GeneOntologyRelationship.class, GeneOntologyRelationshipModel,
//              new BeanSerializerFactory(GeneOntologyRelationship.class, GeneOntologyRelationshipModel),
//              new BeanDeserializerFactory(GeneOntologyRelationship.class, GeneOntologyRelationshipModel));
//        QName GenomeEncodedEntityModel= new QName("http://www.reactome.org/caBIOWebApp/schema", "GenomeEncodedEntity");
//        call.registerTypeMapping(GenomeEncodedEntity.class, GenomeEncodedEntityModel,
//              new BeanSerializerFactory(GenomeEncodedEntity.class, GenomeEncodedEntityModel),
//              new BeanDeserializerFactory(GenomeEncodedEntity.class, GenomeEncodedEntityModel));
//        QName ModifiedResidueModel= new QName("http://www.reactome.org/caBIOWebApp/schema", "ModifiedResidue");
//        call.registerTypeMapping(ModifiedResidue.class, ModifiedResidueModel,
//              new BeanSerializerFactory(ModifiedResidue.class, ModifiedResidueModel),
//              new BeanDeserializerFactory(ModifiedResidue.class, ModifiedResidueModel));
//        QName PathwayModel= new QName("http://www.reactome.org/caBIOWebApp/schema", "Pathway");
//        call.registerTypeMapping(Pathway.class, PathwayModel,
//              new BeanSerializerFactory(Pathway.class, PathwayModel),
//              new BeanDeserializerFactory(Pathway.class, PathwayModel));
//        QName PolymerModel= new QName("http://www.reactome.org/caBIOWebApp/schema", "Polymer");
//        call.registerTypeMapping(Polymer.class, PolymerModel,
//              new BeanSerializerFactory(Polymer.class, PolymerModel),
//              new BeanDeserializerFactory(Polymer.class, PolymerModel));
//        QName PublicationSourceModel= new QName("http://www.reactome.org/caBIOWebApp/schema", "PublicationSource");
//        call.registerTypeMapping(PublicationSource.class, PublicationSourceModel,
//              new BeanSerializerFactory(PublicationSource.class, PublicationSourceModel),
//              new BeanDeserializerFactory(PublicationSource.class, PublicationSourceModel));
//        QName ReactionModel= new QName("http://www.reactome.org/caBIOWebApp/schema", "Reaction");
//        call.registerTypeMapping(Reaction.class, ReactionModel,
//              new BeanSerializerFactory(Reaction.class, ReactionModel),
//              new BeanDeserializerFactory(Reaction.class, ReactionModel));
//        QName ReferenceChemicalModel= new QName("http://www.reactome.org/caBIOWebApp/schema", "ReferenceChemical");
//        call.registerTypeMapping(ReferenceChemical.class, ReferenceChemicalModel,
//              new BeanSerializerFactory(ReferenceChemical.class, ReferenceChemicalModel),
//              new BeanDeserializerFactory(ReferenceChemical.class, ReferenceChemicalModel));
//        QName ReferenceEntityModel= new QName("http://www.reactome.org/caBIOWebApp/schema", "ReferenceEntity");
//        call.registerTypeMapping(ReferenceEntity.class, ReferenceEntityModel,
//              new BeanSerializerFactory(ReferenceEntity.class, ReferenceEntityModel),
//              new BeanDeserializerFactory(ReferenceEntity.class, ReferenceEntityModel));
//        QName ReferenceGeneModel= new QName("http://www.reactome.org/caBIOWebApp/schema", "ReferenceGene");
//        call.registerTypeMapping(ReferenceGene.class, ReferenceGeneModel,
//              new BeanSerializerFactory(ReferenceGene.class, ReferenceGeneModel),
//              new BeanDeserializerFactory(ReferenceGene.class, ReferenceGeneModel));
//        QName ReferenceProteinModel= new QName("http://www.reactome.org/caBIOWebApp/schema", "ReferenceProtein");
//        call.registerTypeMapping(ReferenceProtein.class, ReferenceProteinModel,
//              new BeanSerializerFactory(ReferenceProtein.class, ReferenceProteinModel),
//              new BeanDeserializerFactory(ReferenceProtein.class, ReferenceProteinModel));
//        QName ReferenceRNAModel= new QName("http://www.reactome.org/caBIOWebApp/schema", "ReferenceRNA");
//        call.registerTypeMapping(ReferenceRNA.class, ReferenceRNAModel,
//              new BeanSerializerFactory(ReferenceRNA.class, ReferenceRNAModel),
//              new BeanDeserializerFactory(ReferenceRNA.class, ReferenceRNAModel));
//        QName ReferenceSequenceModel= new QName("http://www.reactome.org/caBIOWebApp/schema", "ReferenceSequence");
//        call.registerTypeMapping(ReferenceSequence.class, ReferenceSequenceModel,
//              new BeanSerializerFactory(ReferenceSequence.class, ReferenceSequenceModel),
//              new BeanDeserializerFactory(ReferenceSequence.class, ReferenceSequenceModel));
//        QName RegulationModel= new QName("http://www.reactome.org/caBIOWebApp/schema", "Regulation");
//        call.registerTypeMapping(Regulation.class, RegulationModel,
//              new BeanSerializerFactory(Regulation.class, RegulationModel),
//              new BeanDeserializerFactory(Regulation.class, RegulationModel));
//        QName RegulationTypeModel= new QName("http://www.reactome.org/caBIOWebApp/schema", "RegulationType");
//        call.registerTypeMapping(RegulationType.class, RegulationTypeModel,
//              new EnumSerializerFactory(RegulationType.class, RegulationTypeModel),
//              new EnumDeserializerFactory(RegulationType.class, RegulationTypeModel));
//        QName RegulatorModel= new QName("http://www.reactome.org/caBIOWebApp/schema", "Regulator");
//        call.registerTypeMapping(Regulator.class, RegulatorModel,
//              new BeanSerializerFactory(Regulator.class, RegulatorModel),
//              new BeanDeserializerFactory(Regulator.class, RegulatorModel));
//        QName SmallMoleculeEntityModel= new QName("http://www.reactome.org/caBIOWebApp/schema", "SmallMoleculeEntity");
//        call.registerTypeMapping(SmallMoleculeEntity.class, SmallMoleculeEntityModel,
//              new BeanSerializerFactory(SmallMoleculeEntity.class, SmallMoleculeEntityModel),
//              new BeanDeserializerFactory(SmallMoleculeEntity.class, SmallMoleculeEntityModel));
//        QName SummationModel= new QName("http://www.reactome.org/caBIOWebApp/schema", "Summation");
//        call.registerTypeMapping(Summation.class, SummationModel,
//              new BeanSerializerFactory(Summation.class, SummationModel),
//              new BeanDeserializerFactory(Summation.class, SummationModel));
//        QName TaxonModel= new QName("http://www.reactome.org/caBIOWebApp/schema", "Taxon");
//        call.registerTypeMapping(Taxon.class, TaxonModel,
//              new BeanSerializerFactory(Taxon.class, TaxonModel),
//              new BeanDeserializerFactory(Taxon.class, TaxonModel));
//        // {http://localhost:8080/caBIOWebApp/services/caBIOService}ArrayOf_xsd_anyType
//        QName arrayModel = new QName("http://www.reactome.org/caBIOWebApp/services/caBIOService", "ArrayOf_xsd_anyType");
//        QName componentModel = new QName("http://www.w3.org/2001/XMLSchema", "anyType");
//        call.registerTypeMapping(Object[].class, arrayModel,
//                new ArraySerializerFactory(Object.class, componentModel),
//                new ArrayDeserializerFactory(componentModel));
////        arrayModel = new QName("http://localhost:8080/caBIOWebApp/services/caBIOService", "queryByIds");
////        componentModel = new QName("http://www.w3.org/2001/XMLSchema", "long");
////        call.registerTypeMapping(Long[].class, arrayModel,
////                new ArraySerializerFactory(Long.class, componentModel),
////                new ArrayDeserializerFactory(componentModel));
//        arrayModel = new QName("http://www.reactome.org/caBIOWebApp/schema", "ArrayOfAnyType");
//        componentModel = new QName("http://www.w3.org/2001/XMLSchema", "anyType");
//        call.registerTypeMapping(Object.class, arrayModel,
//                new ArraySerializerFactory(Object.class, componentModel),
//                new ArrayDeserializerFactory(componentModel));
//       
//    }
//    
//    
//    
//    
//    private Vector<String>GetGenesByPathway(String query) throws Exception{
//    	KEGGLocator  locator = new KEGGLocator();
//        KEGGPortType serv    = locator.getKEGGPort();
//        //BufferedWriter resultfile=new BufferedWriter(new FileWriter("uniprotfile.txt"));
//        //String   query   = "path:hsa04210";
//        PathwayElement[] results = serv.get_elements_by_pathway(query);
//        Vector<String> uniprots=new Vector<String>();
//        for (int i = 0; i < results.length; i++) {
//        	String[] names=results[i].getNames();
//            for  (String name:names){
//            	//	String uniport=serv.bget(name);
//                  //  System.out.println(uniport);
//                //resultfile.write(uniport);
//               
//            	Pattern path=Pattern.compile("(^path\\:)(hsa\\d{5})");
//                Matcher match=path.matcher(name);
//                if(match.find()){
//                	System.out.println(match.group(2));
//                }
//        /*    	Pattern p=Pattern.compile("(UniProt:\\s++)(\\w{6}|\\w{6}\\s\\w{6})(\\sSTRUCTURE|\\sCODON_USAGE)");
//                Matcher match=p.matcher(uniport);
//            	//String[] items=uniport.split("UniProt:");
//            	if(match.find()){
//            		String[] uninames=match.group(2).split(" ");
//            		for (String uniname:uninames){
//            			if (!uniprots.contains(uniname)){
//            				uniprots.add(uniname);
//            			}
//            		}
//            		//System.out.println(match.group(2));
//            	}*/
//            }
//         }
//        return uniprots;
//     }
//    
//    public String[] getlinkedpathways(String pathwayid) throws RemoteException, ServiceException{
//    	KEGGLocator  locator = new KEGGLocator();
//        KEGGPortType serv    = locator.getKEGGPort();
//        String[] pathways=serv.get_linked_pathways(pathwayid);
//    	return pathways; 	
//    }
//    
//    
//    public static String printname(int keyelement) throws RemoteException, ServiceException{
//    	String[] names=elementmap.get(keyelement).getNames();
//    	/*
//    	for(String name:names){
//    		System.out.print(findname(name)+" ");
//    	}
//    	*/
//    	String genesymbol=findname(names[0]);
//    	//System.out.print(genesymbol+" ");
//    	//System.out.println();
//    	return genesymbol;
//    }
//    
//    
//    public static String findname(String name) throws ServiceException, RemoteException{
//    	KEGGLocator  locator = new KEGGLocator();
//        KEGGPortType serv    = locator.getKEGGPort();
//        if(!name.equals("undefined")){
//        	String genedef=serv.btit(name);
//        	String[] genedefs=genedef.split(";");
//        	String[] findname=genedefs[0].split(" ");
//        	String genename=findname[1];
//        	return genename;
//        }
//        else{
//    
//        	return name;
//        }
//    }
//    
//    
//    public void getlinkdbbetweendatabases(String pathwayid) throws RemoteException, ServiceException{
//    	KEGGLocator  locator = new KEGGLocator();
//        KEGGPortType serv    = locator.getKEGGPort();
//        LinkDBRelation[] pathways=serv.get_linkdb_by_entry(pathwayid,"pathway",1,100);
//    	for(LinkDBRelation pathway:pathways){
//    		String path=pathway.getEntry_id2();
//    		System.out.println(path);
//    	}
//    }
//    
//    Map<Integer,Vector<Target>> targetmap=new HashMap<Integer,Vector<Target>>();
//    Vector<ArrayList<Target>> allpaths=new Vector<ArrayList<Target>>();
//    
//    public void findpath(Target start, ArrayList<Target> path){
//             if(targetmap.containsKey(start.getid())){
//            	  Vector<Target> targets=(Vector<Target>) targetmap.get(start.getid());
//                  for (Target target:targets){
//                	  path.add(target);
//                	  findpath(target,path);
//        	       }
//                  path.remove(path.size()-1);
//                  return;
//             }          
//             else{
//            	 allpaths.add(new ArrayList(path));
//            	 for(Target element:path){
//            		 System.out.print(element.getid()+" "+element.getrelation()+" ");
//            	 }
//            	 System.out.println();
//            	 path.remove(path.size()-1);
//            	 return;
//             }
//    }
//    
// static Map<Integer,PathwayElement> elementmap=new HashMap<Integer,PathwayElement>();
//    
//    public void Getelementbypathway(String pathwayid) throws RemoteException, ServiceException{
//    	KEGGLocator  locator = new KEGGLocator();
//        KEGGPortType serv    = locator.getKEGGPort();
//        PathwayElement[] results = serv.get_elements_by_pathway(pathwayid);
//        for(int i=0;i<results.length;i++){
//        	int elementid=results[i].getElement_id();
//        	elementmap.put(elementid, results[i]);
//        	/*
//            String[] members=results[i].getNames();
//        	int[] components=results[i].getComponents();
//        	System.out.println(elementid);
//        	//System.out.println(results[i].getType());
//        	for(String member:members){
//        		System.out.print(member+" ");
//        	}
//        	System.out.println();
//        	for(int component:components){
//        		System.out.println(component+" ");	
//        	}
//        	*/
//        }
//    }
//    
//    
//    public void getrelation(String pathwayid) throws ServiceException,RemoteException{
//    	KEGGLocator locator=new KEGGLocator();
//    	KEGGPortType serv=locator.getKEGGPort();
//    	PathwayElementRelation[] relations=serv.get_element_relations_by_pathway(pathwayid);
//    	Vector<Integer> keylist=new Vector<Integer>();
//    	Vector<Integer> targetlist=new Vector<Integer>();
//    	for(PathwayElementRelation relation:relations){
//        	int elementid1=relation.getElement_id1();
//        	if(!keylist.contains(elementid1)){
//        		keylist.add(elementid1);
//        	}
//        	int elementid2=relation.getElement_id2();
//        	if(!targetlist.contains(elementid2)){
//        		targetlist.add(elementid2);
//        	}
//        	String type=elementmap.get(elementid2).getType();
//        	if(type.equals("gene")){
//        	Subtype[] subtypes=relation.getSubtypes();
//            Vector<Target> targetvector=new Vector<Target>();
//        	for(int i=0;i<subtypes.length;i++){
//            	String relationdetail=subtypes[i].getRelation();
//            	Target target=new Target(elementid2,relationdetail);
//            	if(!targetmap.containsKey(elementid1)){
//            		targetvector.add(target);
//                	targetmap.put(elementid1, targetvector);
//                }
//                else{
//                	if (relationdetail.equals("activation")||relationdetail.equals("inhibition")||relationdetail.equals("expression")||relationdetail.equals("repression")){
//                		Vector<Target> oldtargetvector=targetmap.get(elementid1);	
//                		oldtargetvector.add(target);
//                		targetmap.put(elementid1,oldtargetvector);
//                	}
//                	else{
//                		Vector<Target> oldtargetvector=targetmap.get(elementid1);	
//                		oldtargetvector.clear();
//                		oldtargetvector.add(target);
//                		targetmap.put(elementid1,oldtargetvector);
//                	}
//                }
//            	//String typedetail=type.getType();
//            	//System.out.println(relationdetail+"\n"+typedetail);
//            }	
//        	}
//        	if(type.equals("group")){
//        		int[] components=elementmap.get(elementid2).getComponents();
//        		Subtype[] subtypes=relation.getSubtypes();
//                Vector<Target> targetvector=new Vector<Target>();
//            	for(int i=0;i<subtypes.length;i++){
//                	String relationdetail=subtypes[i].getRelation();
//                	for(int j=0;j<components.length;j++){
//                		Target target=new Target(components[j],relationdetail);
//                    	if(!targetmap.containsKey(elementid1)){
//                    		targetvector.add(target);
//                        	targetmap.put(elementid1, targetvector);
//                        }
//                        else{
//                        	Vector<Target> oldtargetvector=targetmap.get(elementid1);	
//                        	if(!oldtargetvector.contains(target)){
//                        		oldtargetvector.add(target);
//                        		targetmap.put(elementid1,oldtargetvector);
//                        	}
//                        }
//                	}
//                }
//        	}
//        }
//    	
//    	for(Integer targetelement:targetlist){
//    		if(keylist.contains(targetelement)){
//    			keylist.remove(targetelement);
//    		}
//    	}
//    	Arrays.sort(keylist.toArray());
//    	for(Integer keyelement:keylist){
//    		ArrayList<Target> path=new ArrayList<Target>();
//    		System.out.println(elementmap.get(keyelement).getNames()[0]);
//    		Target start=new Target(keyelement);
//            path.add(start);
//            findpath(start,path);
//            
//    	}
//       /*
//        for (int j=keylist.length-1;j>=0;j--){	
//        	Integer keyid=(Integer) key[j];
//        	System.out.println(elementmap.get(keyid).getNames()[0]);
//        	Vector<Target> targets=targetmap.get(keyid);
//        	for(Target target:targets){
//        		System.out.println(elementmap.get(target.getid()).getNames()[0]+" "+target.getrelation());	
//            }
//        }
//        */
//    }
//    
//   
//    public void testQueryPathwaysForReferenceEntities(Vector<String> identifiers) throws Exception {
//        long time1 = System.currentTimeMillis();
//        Call call = null;
//        call = createCall("queryPathwaysForReferenceIdentifiers");
//        Pathway[] pathways = (Pathway[]) call.invoke(new Object[]{identifiers});
//        long time2 = System.currentTimeMillis();
//        System.out.printf("Pathway for a list of identifiers: %d (%d)%n", 
//                pathways.length, (time2 - time1));
//        outputArray(pathways);
//    }
//    
//    static Map<Integer,Vector<Integer>> genemap=new HashMap<Integer,Vector<Integer>>();
//    
//    public static Vector<Integer> addelement2(int elementid2, Vector<Integer> list){
//    	if(elementmap.get(elementid2).getType().equals("gene")){
//    		list.add(elementid2);
//    	}
//    	else if(elementmap.get(elementid2).getType().equals("group")){
//    		int[] components=elementmap.get(elementid2).getComponents();
//    		for(int component:components){
//    			list.add(component);
//    		}
//    	}
//    	return list;
//    }
//    
//    
//    public static void putintomap(int elementid1,int elementid2) throws RemoteException, ServiceException{
//    	if(elementmap.get(elementid1).getType().equals("gene")){
//    		if(genemap.containsKey(elementid1)){
//    			Vector<Integer> oldlist=genemap.get(elementid1);
//    			//oldlist.add(elementid2);
//    			oldlist=Findmember.addelement2(elementid2, oldlist);
//    			genemap.put(elementid1, oldlist);
//    		}
//    		else{
//    			Vector<Integer> newlist=new Vector<Integer>();
//    			//newlist.add(elementid2);
//    			newlist=Findmember.addelement2(elementid2, newlist);
//    			genemap.put(elementid1, newlist);
//    		}
//    	}
//    	else if(elementmap.get(elementid1).getType().equals("group")){ 
//    		int[] components=elementmap.get(elementid1).getComponents();
//    		//System.out.println(elementid1+" :");
//    		for(int component:components){
//    			if(genemap.containsKey(component)){
//        			Vector<Integer> oldlist=genemap.get(component);
//        			//oldlist.add(elementid2);
//        			oldlist=Findmember.addelement2(elementid2, oldlist);
//        			genemap.put(component, oldlist);
//        		}
//        		else{
//        			Vector<Integer> newlist=new Vector<Integer>();
//        			//newlist.add(elementid2);
//        			newlist=Findmember.addelement2(elementid2, newlist);
//        			genemap.put(component, newlist);
//        		}
//    	    }
//    	}
//    }
//    
//    public void generelation(String pathwayid) throws ServiceException,RemoteException{
//    	KEGGLocator locator=new KEGGLocator();
//    	KEGGPortType serv=locator.getKEGGPort();
//    	PathwayElementRelation[] relations=serv.get_element_relations_by_pathway(pathwayid);
//    	for(PathwayElementRelation relation:relations){
//        	int elementid1=relation.getElement_id1();
//        	int elementid2=relation.getElement_id2();
//        	Findmember.putintomap(elementid1,elementid2);
//        	Findmember.putintomap(elementid2,elementid1);
//        	//System.out.println(elementid1+" "+elementid2);
//    	}
//    	    Iterator iterator = genemap.keySet().iterator();  
//    	   while (iterator.hasNext()) {  
//    	       Integer key = (Integer) iterator.next();  
//    	       Vector<Integer> values =genemap.get(key);  
//               String corename=printname(key);
//    	       System.out.println(corename+" :"); 
//    	       //System.out.print("Interactors: ");
//    	       for (Integer value:values){
//    	    	  // System.out.print(" " + value);
//    	    	   String genesymbol=printname(value);
//    	    	   if(chipmap.containsKey(genesymbol)){
//    	    		   Vector<String> probs =chipmap.get(genesymbol);
//    	    		   for(String prob:probs){
//    	    			   if(probexpression.containsKey(prob)){
//    	    				   
//    	    			   }
//    	    			   //System.out.print(prob+" ");
//    	    		   }
//    	    	   }
//               }
//    	       System.out.println();
//           }  
//    }
//    
//    
//    static Map<String,Vector<String>> chipmap=new HashMap<String,Vector<String>>();
//
//    
//    public static void matchname() throws IOException{
//    	String chipname="HG_U133A.chip";
//    	String thisline;
//    	BufferedReader line=new BufferedReader(new FileReader(chipname));
//    	 while((thisline=line.readLine())!=null){
//    		 Pattern path=Pattern.compile("(.*?)(\\s)(.*?)(\\s)(.*?)");
//             Matcher match=path.matcher(thisline);
//             if(match.find()){
//             	//System.out.println(match.group(1)+" "+match.group(3));
//            	 String probname=match.group(1);
//            	 String genesymbol=match.group(3);
//            	 if(!chipmap.containsKey(genesymbol)){
//            		 Vector<String> probvector=new Vector<String>();
//            		 probvector.add(probname);
//            		 chipmap.put(genesymbol,probvector);	 
//            	 }
//            	 else{
//            		 Vector<String> oldvector=chipmap.get(genesymbol);
//            		 oldvector.add(probname);
//            		 chipmap.put(genesymbol, oldvector);
//            	 }
//             }
//    	 }
//    	 /*
//    	 Iterator iterator = chipmap.keySet().iterator();  
//  	   	 while (iterator.hasNext()) {  
//  	       String key = (String) iterator.next();  
//  	       Vector<String> values =chipmap.get(key);  
//  	       System.out.println(key+" :"); 
//  	       for (String value:values){
//  	    	   System.out.print(" " + value);
//             }
//  	       System.out.println();
//         }  
//    	 */
//    }
//    
//    static Map<String,Float> probexpression=new HashMap<String,Float>();
//  
//    
//    public static void readcoefficient() throws IOException{
//    	String filename="foldchange.txt";
//    	String thisline;
//    	BufferedReader line=new BufferedReader(new FileReader(filename));
//    	while((thisline=line.readLine())!=null){
//        	String[] genedefs=thisline.split("\"");
//        	float f = Float.valueOf(genedefs[2]).floatValue();
//        	probexpression.put(genedefs[1],Math.abs(f));
//    	}
//    }
//    
//    public static void main(String[] args) {
//        try {
//
//        	//BasicConfigurator.configure();
//            //soapFactory = SOAPFactory.newInstance();
//            //KEGGLocator  locator = new KEGGLocator();
//            //KEGGPortType serv    = locator.getKEGGPort();
//            Findmember findmember=new Findmember();
//            String querykegg="path:hsa04110";
//            findmember.Getelementbypathway(querykegg);
//            findmember.readcoefficient();
//            findmember.matchname();
//            findmember.getrelation(querykegg);
//            //findmember.generelation(querykegg);
//            //Vector<String> uniprots=findmember.GetGenesByPathway(querykegg);
//            //findmember.testQueryPathwaysForReferenceEntities(uniprots);
//        
//            
//        }
//        catch(Exception e) {
//            e.printStackTrace();
//        }
//    }

}
