package edu.umich.think.densityanalysis.pathdifference;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Stack;

import edu.umich.think.densityanalysis.model.PathwayGraphNode;
import edu.umich.think.densityanalysis.service.PathwayBuilder;


import keggapi.PathwayElement;

/*
 * This class is similar to the pathway depth first class.
 * Please refer to the comments in that class to understand the
 * procedure.
 * 
 * The only difference here is that the a weighted sum based
 * statistics is used to differentiate between the significant 
 * vs. non signification paths. 
 * 
 * The results obtained via this technique were not good.
 */
public class PathwayGraphDepthFirstWeighted {

	public void getPaths(HashMap<Integer, PathwayElement> elementMap,
			ArrayList<PathwayGraphNode> graphNodes) {

		PathwayBuilder p = new PathwayBuilder();
		ArrayList<PathwayGraphNode> roots = p.getRootNodes(graphNodes);
		ArrayList<Double> positiveScores = new ArrayList<Double>();
		final double normalScore = 0;
		final double increment = .1;
		final double multiplicativeFactor = 1;

		for (PathwayGraphNode root : roots) {
			Stack<PathwayGraphNode> path = new Stack<PathwayGraphNode>();
			HashMap<Integer, Integer> visited = new HashMap<Integer, Integer>();
			path.push(root);
			while (!path.empty()) {
				PathwayGraphNode currNode = path.peek();
				if (currNode.childNodes.isEmpty()) {
					double score = normalScore;
					double localMultiplicativeFactor = multiplicativeFactor;
					for (int i = 0; i < path.size(); i++) {
						if (path.elementAt(i).isKnown = false) {
							continue;
						}
						if (path.elementAt(i).isDiffExpressed == true) {
							score = score + (increment * localMultiplicativeFactor);
							localMultiplicativeFactor += .5;
						} else {
							score = score - (increment/multiplicativeFactor);
							if (localMultiplicativeFactor >= 1.5) {
								localMultiplicativeFactor -= .5;
							}
						}
					}
					if (score > 0) {
						positiveScores.add(score);
					}
					path.pop();
					continue;
				}
				boolean foundNext = false;
				for (PathwayGraphNode child : currNode.childNodes) {
					if (!visited.containsKey(child.elementId)) {
						visited.put(child.elementId, 1);
						path.push(child);
						foundNext = true;
						break;
					}
				}
				if (foundNext == false) {
					for (PathwayGraphNode child : currNode.childNodes) {
						visited.remove(child);
					}
					path.pop();
				}
			}	
		}
		double total = 0;
		for (double value:positiveScores) {
			total += value;
		}
		System.out.println("The pathway score is: " + total);
	}
}
