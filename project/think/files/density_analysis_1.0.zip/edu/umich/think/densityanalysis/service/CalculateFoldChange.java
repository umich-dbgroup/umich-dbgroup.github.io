package edu.umich.think.densityanalysis.service;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.util.HashMap;

import edu.mit.broad.genome.math.Vector;
import edu.mit.broad.genome.objects.Dataset;

/*
 * Class to calculate log of fold change of the differential expression values.
 */
public class CalculateFoldChange {
	/*
	 * This function accepts the expression value data set and the clsFile name
	 * to differentiate between the two sets of data.
	 * 
	 * The variable "probe" is used to mark that whether gene names are used in
	 * the data set or the probe name is used in the data set. If probe is set
	 * to true then the function automatically converts the probe name into the
	 * appropriate gene name.
	 */
	static public HashMap<String, Double> foldChange(Dataset ds, boolean probe,
			String dataSource, String clsFile, String chipName) {
		
		HashMap<String, Double> f = new HashMap<String, Double>();
		PathwayBuilder.matchname(dataSource, chipName);
		int mid = calculateMid(dataSource + clsFile);
		for (int i = 0; i < ds.getNumRow(); i++) {
			double firstMean = 0;
			double secondMean = 0;
			Vector v = ds.getRow(i);
			for (int j = 0; j < mid; j++) {
				firstMean += v.getElement(j);
			}
			for (int j = mid; j < ds.getNumCol(); j++) {
				secondMean += v.getElement(j);
			}
			firstMean = firstMean / mid;
			secondMean = secondMean / (ds.getNumCol() - mid);

			double change;
			if (firstMean > secondMean) {
				change = firstMean / secondMean;
			} else {
				if (secondMean > firstMean) {
					change = (secondMean / firstMean) * (-1);
				} else {
					change = 1;
				}
			}
			String name = ds.getRowName(i);
			if (probe == true) {
				name = PathwayBuilder.genemap.get(name);
			}
			if (name != null) {
				change = Math.abs(Math.log(Math.abs(change)));
				f.put(name, change);
			}
		}
		return f;
	}

	/*
	 * Function to calculate the number of samples representing the first set.
	 */
	static private int calculateMid(String clsFile) {
		File file = new File(clsFile);
		InputStream inputStream;
		InputStreamReader inputStreamReader;
		BufferedReader bufferedReader;
		String line;
		int mid = -1;
		try {
			inputStream = new FileInputStream(file);
			inputStreamReader = new InputStreamReader(inputStream);
			bufferedReader = new BufferedReader(inputStreamReader);

			line = bufferedReader.readLine();
			line = bufferedReader.readLine();
			// We need the third line
			line = bufferedReader.readLine();

			String data[] = line.split(" ");

			String firstSet = data[0];
			String next = data[1];
			int count = 1;

			while (next.equals(firstSet)) {
				count++;
				next = data[count];
			}

			return count;

		} catch (Exception e) {
			e.printStackTrace();
		}
		System.out.println("ERROR: There was an error in parsing the cls file");
		System.exit(0);
		return mid;
	}
}
