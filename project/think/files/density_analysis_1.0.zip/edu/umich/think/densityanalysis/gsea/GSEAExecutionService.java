package edu.umich.think.densityanalysis.gsea;

import java.io.File;

import edu.mit.broad.genome.alg.GeneSetGenerators;
import edu.mit.broad.genome.alg.gsea.GeneSetScoringTable;
import edu.mit.broad.genome.alg.gsea.GeneSetScoringTables;
import edu.mit.broad.genome.alg.gsea.KSTests;
import edu.mit.broad.genome.alg.gsea.PValueCalculator;
import edu.mit.broad.genome.alg.gsea.PValueCalculatorImpls;
import edu.mit.broad.genome.objects.Dataset;
import edu.mit.broad.genome.objects.GeneSet;
import edu.mit.broad.genome.objects.GeneSetMatrix;
import edu.mit.broad.genome.objects.Template;
import edu.mit.broad.genome.objects.esmatrix.db.EnrichmentDb;
import edu.mit.broad.genome.objects.esmatrix.db.EnrichmentResult;
import edu.mit.broad.genome.parsers.ClsParser;
import edu.mit.broad.genome.parsers.GctParser;
import edu.mit.broad.genome.parsers.GmtParser;

/**
 * This class encapsules the calls to the GSEA library.
 * 
 * @author Vaibhav Aggarwal, Fernando Farfan
 *
 */
public class GSEAExecutionService {

	/**
	 * Performs the GSEA computation.
	 * 
	 * @param data Path of the data file
	 * @param keggData Path of the KEGG data file
	 * @param template
	 * @return
	 */
	public EnrichmentDb executeGSEA(String data, String keggData, String template) {
		Dataset ds = null;
		GeneSetMatrix gm = null;
		Template t = null;
		try {
			ds = (Dataset) new GctParser().parse("my_dataset", new File(data)).get(0);
			gm = (GeneSetMatrix) new GmtParser().parse("my_pathway", new File(keggData)).get(0);
			t = (Template) new ClsParser().parse("my_phenotype", new File(template)).get(0);
		} catch (Exception e) {
			e.printStackTrace();
			System.exit(0);
		}

        int min_set_size = 25;
        int max_set_size = 500;
        // @note that the gene sets are first restricted to the dataset feature space and then the size thresholds are pplied
        GeneSet[] gsets = GeneSetGenerators.removeGeneSetsBySize(gm, min_set_size, max_set_size, ds);

        KSTests tests = new KSTests();

        /**
         * ffarfan 20100603
         * Changed num_permutations to 5000 according to this paragraph in GSEA
         * documentation:
         * 
         * "In the GSEA report, a p value of zero (0.0) indicates an actual p 
         * value of less than 1/number-of-permutations. For example, if the 
         * analysis performed 100 permutations, a reported p value of 0.0 
         * indicates an actual p value of less than 0.001. For a more accurate p 
         * value, increase the number of permutations performed by the analysis. 
         * Typically, you will want to perform 1000 permutations (phenotype or 
         * gene_set). (If you attempt to perform significantly more than 1000 
         * permutations, GSEA may run out of memory.)"
         */
        int num_permutations = 5000;
        int num_markers = 100; // used only for marker analysis - not a gsea algorithm parameter

        boolean permute_phenotype = true; // if false, then gene sets are permuted

        GeneSetScoringTable scoring_scheme = new GeneSetScoringTables.Weighted();
        // another option is the classic kolmogorov-smirnov statistic
        //GeneSetScoringTable scoring_scheme = new GeneSetScoringTables.Classic();

        // OK, parameters all done, make the call
        EnrichmentDb edb = tests.executeGsea(ds, t, gsets, num_permutations, scoring_scheme, permute_phenotype, num_markers);
        System.out.println("GSEA Execution Complete!");

        // EDB now has the stats but not the FDRs yet
        // FDRs can be calc in many ways, heres the gsea way:

        PValueCalculator pvc = new PValueCalculatorImpls.GseaImpl("meandiv");
        final EnrichmentResult[] results = pvc.calcNPValuesAndFDR(edb.getResults());
        final EnrichmentDb edb_with_fdr = edb.cloneDeep(results);
        
        return edb_with_fdr;
	}
}
