package edu.umich.think.densityanalysis;

import java.io.File;
import java.util.ArrayList;
import java.util.HashMap;

import keggapi.PathwayElement;
import edu.mit.broad.genome.XLogger;
import edu.mit.broad.genome.objects.Dataset;
import edu.mit.broad.genome.objects.esmatrix.db.EnrichmentDb;
import edu.mit.broad.genome.objects.esmatrix.db.EnrichmentResult;
import edu.mit.broad.genome.parsers.GctParser;
import edu.umich.think.densityanalysis.gsea.GSEAExecutionService;
import edu.umich.think.densityanalysis.model.PathwayGraphNode;
import edu.umich.think.densityanalysis.service.CalculateFoldChange;
import edu.umich.think.densityanalysis.service.CorrelationService;
import edu.umich.think.densityanalysis.service.PathwayBuilder;

/**
 * <p>Driver class to perform the Density Score Analysis.</p>
 * <p>The computation has two steps:
 * 
 * <ol>
 * 	<li>The Density score is computed for every KEGG pathway.</li>
 *  <li>GSEA is computed for the input microarray experiment, and the resulting
 *  P-values are adjusted using the density scores computed in Step 1.</li>
 * </ol> 
 * </p>
 * 
 * @author Vaibhav Aggarwal and Fernando Farfan
 */
public class DEDensityAnalysisDriver {
	
	/**
	 * <p>Main method. It receives all the input files as arguments.</p>
	 * <p>This is a brief description of the file formats that we use for the
	 * analysis:
	 * <ul>
	 * 	<li><strong>Expression dataset files (GCT):</strong>
	 *    1. Probes in rows
	 *    2. Gene names in columns
	 *  </li>
	 *  <li><strong>Phenotype label file (CLS):</strong> Associates each sample 
	 *  in your dataset with a phenotype.</li>
	 *  <li><strong>Gene sets / Pathway data:</strong>
	 *  <ul> 
	 *   <li>Use keggdata.txt with gene name based files.</li>
	 *   <li>Use keggdata2.gmt with probe names based files.</li> 
	 *   <li>Make sure to set the isProbe variable accordingly.</li>
	 *  </ul> 
	 *  </ul>  
	 * </p>
	 * @param args
	 * @throws Exception
	 */
	public static void main(String[] args) throws Exception {

		// Checks valid number of arguments 
		if(args.length != 6) {
			System.err.println( "Number of parameters invalid! \n" +
					"Usage: DEDensityAnalysisDriver " +
					"<DataFile1> " +
					"<DataFile2> " +
					"<ClassFile1> " +
					"<ClassFile2> " +
					"<PathwayFile> " +
					"<ChipName>" );
			System.exit(1);
		}
		
		printBanner();
		
		// Capture parameters
		String dataFile1 = args[0];
		String dataFile2 = args[1];
		String clsFile1 = args[2];
		String clsFile2 = args[3];
		String pathwayFile = args[4];
		String chipName = args[5];

		// Variable to differentiate between using probe names and gene names
		Boolean isProbe = false;
		

		// Pathways to analyze ...
		String lstPathways[] = { "hsa04115", "hsa04210", "hsa05200", "hsa05210",
				"hsa05212", "hsa05214", "hsa05216", "hsa05221", "hsa05220",
				"hsa05217", "hsa05218", "hsa05211", "hsa05219", "hsa05213",
				"hsa05222", "hsa05223", "hsa05215", "hsa05310", "hsa05322",
				"hsa05320", "hsa05330", "hsa05332", "hsa05340", "hsa05010",
				"hsa05012", "hsa05014", "hsa05016", "hsa05020", "hsa05410",
				"hsa05412", "hsa05414", "hsa04940", "hsa04930", "hsa04950",
				"hsa05110", "hsa05120", "hsa05130", "hsa02010", "hsa02060",
				"hsa03070", "hsa03060", "hsa02020", "hsa04010", "hsa04310",
				"hsa04330", "hsa04340", "hsa04350", "hsa04012", "hsa04370",
				"hsa04630", "hsa04020", "hsa04070", "hsa04150", "hsa04080",
				"hsa04060", "hsa04512", "hsa04514", "hsa04144", "hsa04142",
				"hsa04140", "hsa02030", "hsa04810", "hsa04110", "hsa04210",
				"hsa04510", "hsa04520", "hsa04530", "hsa04540", "hsa04260",
				"hsa04270", "hsa04910", "hsa04920", "hsa03320", "hsa04912",
				"hsa04914", "hsa04916", "hsa04614", "hsa04640", "hsa04610",
				"hsa04620", "hsa04621", "hsa04622", "hsa04650", "hsa04612",
				"hsa04660", "hsa04662", "hsa04664", "hsa04666", "hsa04670",
				"hsa04062", "hsa04720", "hsa04730", "hsa04722", "hsa04740",
				"hsa04742", "hsa04320", "hsa04360", "hsa04710" };
		
		// First call to Density Analysis with first set of input files ...
		HashMap<String, ArrayList<Double>> ranks1 = runDensityAnalysis( 
				dataFile1, clsFile1, pathwayFile, chipName, isProbe, lstPathways);
		
		System.out.println("\n\n\n\n");
		
		// Second call to Density Analysis with second set of input files ...
		HashMap<String, ArrayList<Double>> ranks2 = runDensityAnalysis( 
				dataFile2, clsFile2, pathwayFile, chipName, isProbe, lstPathways);

		// Calculating Pearson Correlation between scores ...
		double oldGseaScore = CorrelationService.getPearsonCorrelation(
				ranks1.get("GSEA_Score"), ranks2.get("GSEA_Score"));
		double oldGseaRank = CorrelationService.getPearsonCorrelation(
				ranks1.get("GSEA_Rank"), ranks2.get("GSEA_Rank"));
		double newGseaScore = CorrelationService.getPearsonCorrelation(
				ranks1.get("GSEA_DS_Score"), ranks2.get("GSEA_DS_Score"));
		double newGseaRank = CorrelationService.getPearsonCorrelation(
				ranks1.get("GSEA_DS_Rank"), ranks2.get("GSEA_DS_Rank"));
		double varScore = CorrelationService.getPearsonCorrelation(
				ranks1.get("DS_Score"), ranks2.get("DS_Score"));
		double varRank = CorrelationService.getPearsonCorrelation(
				ranks1.get("DS_Rank"), ranks2.get("DS_Rank"));

		// Printing Pearson Correlation results ...
		System.out.println("\n\nPEARSON CORRELATION COEFFICIENTS\n================================");
		System.out.println("GSEA Score Correlation :     " + oldGseaScore);
		System.out.println("GSEA-DS Score Correlation :  " + newGseaScore);
		System.out.println("DS Score Correlation :       " + varScore);
		System.out.println("");
		System.out.println("GSEA Rank Correlation is:    " + oldGseaRank);
		System.out.println("GSEA-DS Rank Correlation is: " + newGseaRank);
		System.out.println("DS Rank Correlation is:      " + varRank);

	}

	private static HashMap<String, ArrayList<Double>> runDensityAnalysis(
			String dataFile, String clsFile, String pathwayFile, 
			String chipName, Boolean isProbe, String[] pathways) 
	throws Exception {

		XLogger.setLoggingOff();
		
		System.out.println("********\n" +
				"** DENSITY SCORE ANALYSIS\n" +
				"** \n" +
				"** GCT File:     " + dataFile + "\n" + 
				"** Class File:   " + clsFile + "\n" +
				"** Pathway File: " + pathwayFile + "\n" +
				"** Chip File:    " + chipName + "\n" +
				"********\n");

		/***********************************************************************
		 * PREPARE INPUT DATA
		 */
		// GSEA Dataset object
		Dataset dataset = null;
		try {
			dataset = (Dataset) new GctParser().parse("my_ds", new File(dataFile)).get(0);
		} catch (Exception e) {
			throw new Exception("Unable to parse Dataset.\n" + e.toString());
		}

		// Stores the filan Variance values for each pathway
		HashMap<String, Double> mapVarianceValues = new HashMap<String, Double>();

		// Get the fold change
		HashMap<String, Double> foldChange = CalculateFoldChange.foldChange(
				dataset, isProbe, "", clsFile, chipName);
		dataset = null;

		HashMap<String, Integer> mapPathwayOrder = new HashMap<String, Integer>();
		int rank = 0;
		for (String pathway : pathways) {
			mapPathwayOrder.put(pathway, rank++);
		}

		// Stores GSEA vs KEGG gene name mappings
		HashMap<String, String> mapPathwayNames = new HashMap<String, String>();
		PathwayBuilder pathwayBuilder = new PathwayBuilder();

		/***********************************************************************
		 * PHASE 1 Begins
		 * Compute Density score for every pathway
		 */
		System.out.println("Computing Pathway Density Scores\n================================");
		for(String pathway : pathways) {
			String currPathway = "path:" + pathway; 

			System.out.print(currPathway + " : ");

			/**
			 * Step 1
			 * Create subgraph representation
			 */
			// Building the graph from KEGG data
			ArrayList<PathwayGraphNode> allNodes = pathwayBuilder.buildPathwayGraph(currPathway);

			// Creating mapping between the element ids and the corresponding
			// KEGG objects
			HashMap<Integer, PathwayElement> elements = pathwayBuilder
					.createElementMap(currPathway);
			HashMap<Integer, Double> diffExpression = new HashMap<Integer, Double>();

			// Computing the differential expression for each gene and marking
			// differentially expressed nodes
			for (PathwayGraphNode pnode : allNodes) {
				String name = elements.get(pnode.elementId).getNames()[0];
				String geneName;
				if (mapPathwayNames.containsKey(name)) {
					geneName = mapPathwayNames.get(name);
				} else {
					geneName = pathwayBuilder.findname(name);
					mapPathwayNames.put(name, geneName);
				}
				if(foldChange.get(geneName) != null) {
					diffExpression.put(pnode.elementId, foldChange.get(geneName));
				} else {
					pnode.isKnown = false;
				}
			}

			/**
			 * Step 2
			 * Calculate pair-wise shortest paths
			 */
			//System.out.println("Calculating score on each node");
			DistanceCalculator dc = new DistanceCalculator();
			HashMap<Integer, HashMap<Integer, Integer>> distanceMap = dc
					.calculateDistances(allNodes);

			/**
			 * Step 3
			 * Calculate density score for each gene
			 */
			//System.out.println("Calculating variance of the pathway");
			DEDensityCalculator deDensityCalculator = new DEDensityCalculator();
			HashMap<Integer, Double> densities = deDensityCalculator
					.calculateDEDensity(distanceMap, diffExpression);

			/**
			 * Step 4
			 * Calculate the score for the pathway
			 */
			double variance = deDensityCalculator.calculateVariance(densities
					.values());
			mapVarianceValues.put(pathway, variance);
			// Print the Density Score (Variance) for the current pathway ...
			System.out.println(variance);
		}
		/**
		 * PHASE 1 Ends
		 **********************************************************************/
		
		/***********************************************************************
		 * PHASE 2 Begins
		 * - Compute traditional GSEA scores
		 * - Adjust GSEA scores with density scores 
		 */
		// Using traditional GSEA to calculate Enrichment Score
		GSEAExecutionService gsea = new GSEAExecutionService();
		EnrichmentDb gseaResults = gsea.executeGSEA(dataFile, pathwayFile, clsFile);

		
		// Calculating mean of variance values
		// meanVar corresponds to E(S0) in the formula
		double meanVar = 0.0;
		HashMap<String, Double> removeNan = new HashMap<String, Double>();
		for (String pway : mapVarianceValues.keySet()) {
			if (!mapVarianceValues.get(pway).isNaN()) {
				removeNan.put(pway, mapVarianceValues.get(pway));
			}
		}
		mapVarianceValues = removeNan;

		for (String pway : mapVarianceValues.keySet()) {
			if (mapVarianceValues.get(pway) == Double.NaN) {
				continue;
			}
			meanVar += mapVarianceValues.get(pway);
		}
		meanVar = meanVar / mapVarianceValues.size();

		// Calculating variance of variance
		// varOfVar corresponds to Var(S0) in the formula
		DEDensityCalculator deDensityCalculator = new DEDensityCalculator();
		double varOfVar = deDensityCalculator
				.calculateVariance(mapVarianceValues.values());

		// Calculating omega
		HashMap<String, Double> omegaScores = new HashMap<String, Double>();
		for(String pathway : mapVarianceValues.keySet()) {
			if (mapVarianceValues.get(pathway) == Double.NaN)
				continue;
			double omega = Math.abs((mapVarianceValues.get(pathway)) / (Math.sqrt(varOfVar)));
			omegaScores.put(pathway, omega);
		}
		
		// Calculating mean omega
		double omegaBar = 0.0;
		for (String pathway : omegaScores.keySet()) {
			omegaBar += omegaScores.get(pathway);
		}
		omegaBar = omegaBar / omegaScores.size();

		// Calculating weight for each pathway
		HashMap<String, Double> pathwayWeight = new HashMap<String, Double>();
		for (String pathway : mapVarianceValues.keySet()) {
			if (mapVarianceValues.get(pathway).isNaN())
				continue;
			double weight = omegaScores.get(pathway) / omegaBar;
			pathwayWeight.put(pathway, weight);
		}
		
		HashMap<String, Double> gseaScores = new HashMap<String, Double>();
		HashMap<String, Double> gseadsScores = new HashMap<String, Double>();

		// Creating a modified and original score list
		for (int i = 0; i < gseaResults.getNumResults(); i++) {
			EnrichmentResult result = gseaResults.getResult(i);
			String pWay = result.getGeneSetName().toLowerCase();
			if (!pathwayWeight.containsKey(pWay)) {
				continue;
			}
			// Note: here we are using z scores directly. 
			// We do not need the pathway weight as of now.
			double varRes = omegaScores.get(pWay);
			/*
			 * ffarfan 20100524
			 * The weight is the nominal P-value and the adjusted weight is 
			 * the division
			 */
			double nominalP = result.getScore().getNP();
			double adjustedWeight = nominalP / varRes;
			
			gseaScores.put(pWay, nominalP);
			gseadsScores.put(pWay, adjustedWeight);
		}
//		System.out.println("\nGSEA = " + gseaScores.toString());
//		System.out.println("\nGSEA-DS = " + gseadsScores.toString());

		// Printing ranked list for GSEA Scores
		System.out.println("\nRanking for GSEA Scores");
		ArrayList<Double> oldGseaRank = new ArrayList<Double>();
		ArrayList<Double> oldGseaScore = new ArrayList<Double>();
		HashMap<String, Integer> done = new HashMap<String, Integer>();
		double min;
		String pathway = null;
		for (int i = 0; i < gseaScores.size(); i++) {
			min = Double.MAX_VALUE;
			for (String pway : gseaScores.keySet()) {
				if (done.containsKey(pway)) {
					continue;
				}
				if (gseaScores.get(pway).isNaN()) {
					done.put(pway, 1);
					continue;
				}
				if (gseaScores.get(pway) < min) {
					min = gseaScores.get(pway);
					pathway = pway;
				}
			}
			done.put(pathway, i + 1);
			System.out.print(pathway + ": " + min + "\n");
		}

		for (int i = 0; i < pathways.length; i++) {
			if (done.containsKey(pathways[i])) {
				oldGseaScore.add(gseaScores.get(pathways[i]));
				oldGseaRank.add((double) done.get(pathways[i]));
			}
		}

		// Printing ranked list for GSEA-DS Scores
		System.out.println("\n\nRanking for GSEA-DS Scores");
		done = new HashMap<String, Integer>();
		ArrayList<Double> newGseaRank = new ArrayList<Double>();
		ArrayList<Double> newGseaScore = new ArrayList<Double>();
		for (int i = 0; i < gseadsScores.size(); i++) {
			min = Double.MAX_VALUE;
			for (String pway : gseadsScores.keySet()) {
				if (done.containsKey(pway)) {
					continue;
				}
				if (gseadsScores.get(pway).isNaN()) {
					done.put(pway, 1);
					continue;
				}
				if (gseadsScores.get(pway) < min) {
					min = gseadsScores.get(pway);
					pathway = pway;
				}
			}
			done.put(pathway, i + 1);
			System.out.print(pathway + ": " + min + "\n");
		}

		for (int i = 0; i < pathways.length; i++) {
			if (done.containsKey(pathways[i])) {
				newGseaScore.add(gseadsScores.get(pathways[i]));
				newGseaRank.add((double) done.get(pathways[i]));
			}
		}

		// Printing ranked list using variance only
		System.out.println("\n\nRanking for DS Scores");
		ArrayList<Double> varRank = new ArrayList<Double>();
		ArrayList<Double> varScore = new ArrayList<Double>();
		double max;
		done = new HashMap<String, Integer>();
		for (int i = 0; i < mapVarianceValues.size(); i++) {
			max = -1;
			for (String pway : mapVarianceValues.keySet()) {
				if (done.containsKey(pway)) {
					continue;
				}
				if (mapVarianceValues.get(pway).isNaN()) {
					done.put(pway, 1);
					continue;
				}
				if (mapVarianceValues.get(pway) > max) {
					max = mapVarianceValues.get(pway);
					pathway = pway;
				}
			}
			done.put(pathway, i + 1);
			System.out.print(pathway + ": " + max + "\n");
		}

		for (int i = 0; i < pathways.length; i++) {
			if (done.containsKey(pathways[i])) {
				varScore.add(mapVarianceValues.get(pathways[i]));
				varRank.add((double) done.get(pathways[i]));
			}
		}

		// Need to return three ranked lists here
		// 1. Ranking based on DS
		// 2. Ranking based on GSEA
		// 3. Ranking based on GSEA-DS
		// The ranks are indexed by the order of pathways[]
		HashMap<String, ArrayList<Double>> retValue = new HashMap<String, ArrayList<Double>>();
		retValue.put("GSEA_Score", oldGseaScore);
		retValue.put("GSEA_Rank", oldGseaRank);
		retValue.put("GSEA_DS_Score", newGseaScore);
		retValue.put("GSEA_DS_Rank", newGseaRank);
		retValue.put("DS_Score", varScore);
		retValue.put("DS_Rank", varRank);

		return retValue;
	}
	
	private static void printBanner() {
		System.out.println(
				"************************************************************************\n" +
				"**\n" +
				"** UNIVERSITY OF MICHIGAN\n" +
				"** THINK Back: KNowledge-based Interpretation of High Throughput data\n" +
				"** http://eecs.umich.edu/db/think/\n" +
				"**\n" +
				"************************************************************************\n"
		);
	}
}
