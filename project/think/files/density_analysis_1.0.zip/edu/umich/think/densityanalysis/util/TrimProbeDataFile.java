package edu.umich.think.densityanalysis.util;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileWriter;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.util.HashMap;

import edu.umich.think.densityanalysis.service.PathwayBuilder;


public class TrimProbeDataFile {
	public static void main(String args[]) {
		File file1 = new File("Lung_Michigan_collapsed_symbols.gct");
		File file2 = new File("expns2990.gct");
		String dataSource = args[0];
		String chipName = "HG_U133A.chip";
		
		InputStream inputStream;
		InputStreamReader inputStreamReader;
		BufferedReader bufferedReader;
		PathwayBuilder.matchname(dataSource, chipName);
		String data[];

		String line;
		try {
			inputStream = new FileInputStream("keggdata.txt");
			inputStreamReader = new InputStreamReader(inputStream);
			bufferedReader = new BufferedReader(inputStreamReader);

			HashMap<String, Integer> requiredGenes = new HashMap<String, Integer>();
			while ((line = bufferedReader.readLine()) != null) {
				data = line.split("\t");
				for (String gene : data) {
					requiredGenes.put(gene, 1);
				}
			}

			inputStream = new FileInputStream(file1);
			inputStreamReader = new InputStreamReader(inputStream);
			bufferedReader = new BufferedReader(inputStreamReader);

			line = bufferedReader.readLine();
			line = bufferedReader.readLine();
			line = bufferedReader.readLine();

			HashMap<String, Integer> geneNames = new HashMap<String, Integer>();

			while ((line = bufferedReader.readLine()) != null) {
				data = line.split("\t");
				geneNames.put(data[0], 1);
			}

			inputStream = new FileInputStream(file2);
			inputStreamReader = new InputStreamReader(inputStream);
			bufferedReader = new BufferedReader(inputStreamReader);

			FileWriter fstream = new FileWriter("expns2990_2.gct");
			BufferedWriter out = new BufferedWriter(fstream);
			HashMap<String, Integer> copiedGenes = new HashMap<String, Integer>();

			line = bufferedReader.readLine();
			out.write(line + "\n");
			System.out.println(line);
			line = bufferedReader.readLine();
			out.write(line + "\n");
			System.out.println(line);
			line = bufferedReader.readLine();
			out.write(line + "\n");
			System.out.println(line);

			while ((line = bufferedReader.readLine()) != null) {
				data = line.split("\t");
				String geneName = PathwayBuilder.genemap.get(data[0]);
				if (copiedGenes.containsKey(geneName)) {
					continue;
				}
				if (geneName.equals("---")) {
					continue;
				}
				if ((!geneNames.containsKey(geneName))
						&& (!requiredGenes.containsKey(geneName))) {
					continue;
				}
				copiedGenes.put(geneName, 1);
				String newEntry = geneName;
				for (int i = 1; i < data.length; i++) {
					newEntry += "\t" + data[i];
				}
				newEntry += "\n";
				out.write(newEntry);
				System.out.println(newEntry);
			}
			out.close();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
}
