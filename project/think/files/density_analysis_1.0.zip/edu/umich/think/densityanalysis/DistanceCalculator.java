package edu.umich.think.densityanalysis;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Stack;

import keggapi.PathwayElement;
import edu.umich.think.densityanalysis.model.PathwayGraphNode;
import edu.umich.think.densityanalysis.service.PathwayBuilder;

/*
 * Class to compute the all pair shortest path
 */
public class DistanceCalculator {

	HashMap<Integer, HashMap<Integer, Integer>> distanceMap;

	public DistanceCalculator() {
		distanceMap = new HashMap<Integer, HashMap<Integer, Integer>>();
	}

	public HashMap<Integer, HashMap<Integer, Integer>> calculateDistances(
			// HashMap<Integer, PathwayElement> elementMap,
			ArrayList<PathwayGraphNode> graphNodes) {

		PathwayBuilder p = new PathwayBuilder();
		ArrayList<PathwayGraphNode> roots = p.getRootNodes(graphNodes);

		for (PathwayGraphNode root : roots) {
			Stack<PathwayGraphNode> path = new Stack<PathwayGraphNode>();
			HashMap<Integer, Integer> visited = new HashMap<Integer, Integer>();
			path.push(root);
			
			// Traversing the graph in depth first order
			while (!path.empty()) {
				PathwayGraphNode currNode = path.peek();
				if (currNode.childNodes.isEmpty()) {
					path.pop();
					continue;
				}
				boolean foundNext = false;
				for (PathwayGraphNode child : currNode.childNodes) {
					if (!visited.containsKey(child.elementId)) {
						visited.put(child.elementId, 1);
						if (child.isKnown) {
							updateDistances(path, child);
						}
						path.push(child);
						foundNext = true;
						break;
					}
				}
				// Reached the end of a path
				if (foundNext == false) {
					for (PathwayGraphNode child : currNode.childNodes) {
						visited.remove(child);
					}
					path.pop();
				}
			}
		}
		
		// Using the relaxation procedure to compute the shortest path between all pairs
		// of nodes in the graph
		HashMap<Integer, HashMap<Integer, Integer>> distanceMap2 = deepCloneDistanceMap();
		for (int i=0; i<distanceMap.size(); i++) {
			//System.out.println("Num iteration is " + i);
			for (int id1:distanceMap.keySet()) {
				for (int id2:distanceMap.get(id1).keySet()) {
					for (int id3:distanceMap.get(id2).keySet()) {
						if (id3 == id1) {
							continue;
						}
						if (distanceMap.get(id1).containsKey(id3)) {
							int d1 = distanceMap.get(id1).get(id2) + distanceMap.get(id2).get(id3);
							int d2 = distanceMap.get(id1).get(id3);
							if (d1<d2) {
								distanceMap2.get(id1).put(id3, d1);
							}
						} else {
							distanceMap2.get(id1).put(id3, distanceMap.get(id1).get(id2) + distanceMap.get(id2).get(id3));
						}
					}
				}
			}
			distanceMap = distanceMap2;
			distanceMap2 = deepCloneDistanceMap();	
		}
		//printDistances(elementMap);
		return distanceMap;
	}
	
	private void printDistances(HashMap<Integer, PathwayElement> elementMap) {
		for (int id1:distanceMap.keySet()) {
			System.out.println("ID is " + elementMap.get(id1).getNames()[0]);
			for (int id2:distanceMap.get(id1).keySet()) {
				System.out.print(elementMap.get(id2).getNames()[0] + ":" + distanceMap.get(id1).get(id2) + "   ");
			}
			System.out.println();
		}
	}
	
	private HashMap<Integer, HashMap<Integer,Integer>> deepCloneDistanceMap() {
		HashMap<Integer, HashMap<Integer,Integer>> deepCopy = new HashMap<Integer, HashMap<Integer,Integer>>();
		for (int id1:distanceMap.keySet()) {
			deepCopy.put(id1, new HashMap<Integer, Integer>());
			for (int id2:distanceMap.get(id1).keySet()) {
				deepCopy.get(id1).put(id2, distanceMap.get(id1).get(id2));
			}
		}
		return deepCopy;
	}

	private void updateDistances(Stack<PathwayGraphNode> path,
			PathwayGraphNode node) {
		if (!node.isKnown) {
			return;
		}
		PathwayGraphNode currNode;
		if (path.size() == 0) {
			return;
		}
		int distance = path.size();

		if (!distanceMap.containsKey(node.elementId)) {
			distanceMap.put(node.elementId, new HashMap<Integer, Integer>());
		}

		// Updating the distance of each node from the newly discovered node
		Iterator<PathwayGraphNode> iter = path.iterator();
		while (iter.hasNext()) {
			currNode = iter.next();
			if (! currNode.isKnown) {
				distance--;
				continue;
			}
			if (!distanceMap.containsKey(currNode.elementId)) {
				distanceMap.put(currNode.elementId, new HashMap<Integer, Integer>());
			}
			if (distanceMap.get(node.elementId).containsKey(currNode.elementId)) {
				if (distanceMap.get(node.elementId).get(currNode.elementId) > distance) {
					distanceMap.get(node.elementId).put(currNode.elementId,
							distance);
					distanceMap.get(currNode.elementId).put(node.elementId,
							distance);
				}
			} else {
				distanceMap.get(node.elementId).put(currNode.elementId,
						distance);
				distanceMap.get(currNode.elementId).put(node.elementId,
						distance);
			}
			distance--;
		}
	}
}
