package edu.umich.think.densityanalysis;

import java.util.Collection;
import java.util.HashMap;

import org.apache.commons.math.stat.descriptive.moment.Variance;

/*
 * Class to compute the density of differential expression at each
 * gene node in a pathway,
 */
public class DEDensityCalculator {

	public HashMap<Integer, Double> calculateDEDensity(
			HashMap<Integer, HashMap<Integer, Integer>> distanceMap,
			HashMap<Integer, Double> de) {
		HashMap<Integer, Double> densities = new HashMap<Integer, Double>();

		for (int i : distanceMap.keySet()) {
			double score = de.get(i);
			if (distanceMap.get(i).keySet().size() < 2) {
				continue;
			}
			for (int j : distanceMap.get(i).keySet()) {
				score += (de.get(j)/(distanceMap.get(i).get(j) + 1));
			}
			densities.put(i, score);
		}
		return densities;
	}

	public double calculateVariance(Collection<Double> densityValues) {
		Variance v = new Variance();
		double[] d = new double[densityValues.size()];
		int i=0;
		for (double val: densityValues) {
			d[i] = val;
			i++;
		}
		return v.evaluate(d);
	}
}
