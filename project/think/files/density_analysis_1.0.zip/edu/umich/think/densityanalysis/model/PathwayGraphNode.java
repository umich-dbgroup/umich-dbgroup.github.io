package edu.umich.think.densityanalysis.model;

import java.util.ArrayList;
import java.util.HashMap;

/**
 * This class represents a graph node that belongs to a pathway graph.
 * 
 * @author Vaibhav Aggarwal
 *
 */
public class PathwayGraphNode {
	
	/**
	 * Id of the element
	 */
	public Integer elementId;
	/**
	 * {@link ArrayList} of child nodes. 
	 */
	public ArrayList<PathwayGraphNode> childNodes;
	/**
	 * {@link ArrayList} of parent nodes.
	 */
	public ArrayList<PathwayGraphNode> parentNodes;
	/**
	 * {@link HashMap} of relation types.
	 */
	public HashMap<Integer, Integer> relationType;
	/**
	 * Checks whether the element is differentially expressed.
	 */
	public boolean isDiffExpressed;
	/**
	 * Differential expression value.
	 */
	public double differentialExpression;
	/**
	 * Checks whether the element is known.
	 */
	public boolean isKnown;
	
	/**
	 * Constructor.
	 * 
	 * @param elementId Id of the element node.
	 */
	public PathwayGraphNode(int elementId) {
		
		this.elementId = elementId;
		childNodes = new ArrayList<PathwayGraphNode>();
		parentNodes = new ArrayList<PathwayGraphNode>();
		relationType = new HashMap<Integer, Integer>();
		isDiffExpressed = false;
		isKnown = true;
	}
}
