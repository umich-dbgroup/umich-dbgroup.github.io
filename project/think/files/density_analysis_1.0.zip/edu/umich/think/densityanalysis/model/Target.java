package edu.umich.think.densityanalysis.model;

public class Target {
	
	int targetid;
	String relation;
	
	public Target(int targetid, String relation) {
		this.targetid=targetid;
		this.relation=relation;
		
	}
	
	public Target(int targetid) {
		this.targetid=targetid;
		this.relation="start";
	}
	
	public int getid(){
		return this.targetid;
	}

	public String getrelation(){
		return this.relation;
	}
}
