package edu.umich.think.densityanalysis.pathdifference;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Stack;

import edu.umich.think.densityanalysis.model.PathwayGraphNode;
import edu.umich.think.densityanalysis.service.PathwayBuilder;


import keggapi.PathwayElement;

/*
 * Class to do a depth first traversal of directed graph.
 */
public class PathwayGraphDepthFirst {

	public void getPaths(HashMap<Integer, PathwayElement> elementMap,
			ArrayList<PathwayGraphNode> graphNodes) {

		PathwayBuilder p = new PathwayBuilder();
		ArrayList<PathwayGraphNode> roots = p.getRootNodes(graphNodes);
		int totalPaths = 0;
		int totalNodes = 0;

		for (PathwayGraphNode root : roots) {
			Stack<PathwayGraphNode> path = new Stack<PathwayGraphNode>();
			HashMap<Integer, Integer> visited = new HashMap<Integer, Integer>();
			path.push(root);
			while (!path.empty()) {
				PathwayGraphNode currNode = path.peek();
				// Have reached the end of a path
				if (currNode.childNodes.isEmpty()) {
					boolean diffExp = true;
					int count = 0;
					int pathLength = 0;
					for (int i = 0; i < path.size(); i++) {
						// Skipping the analysis of unknown nodes in the graph
						if (path.elementAt(i).isKnown = false) {
							continue;
						}
						pathLength++;
						if (path.elementAt(i).isDiffExpressed == false) {
							count++;
						}
					}
					// Only the paths which are more than 50% significant are counted
					if(count > (pathLength / 2)) {
						diffExp = false;
					}
					// Incrementing the number of paths which are differentially expressed
					// in the pathway.
					if (diffExp) {
						for (int i = 0; i < path.size(); i++) {
							totalNodes++;
					//		System.out.print(elementMap.get(
					//				path.elementAt(i).elementId).getNames()[0]
					//				+ "   ");
						}
						totalPaths++;
						//System.out.println("");
					}
					path.pop();
					continue;
				}
				boolean foundNext = false;
				// Checking for cycles
				// Note: Cycles are not counted as paths in this implementation
				for (PathwayGraphNode child : currNode.childNodes) {
					if (!visited.containsKey(child.elementId)) {
						visited.put(child.elementId, 1);
						path.push(child);
						foundNext = true;
						break;
					}
				}
				// We have completely explore this path
				if (foundNext == false) {
					for (PathwayGraphNode child : currNode.childNodes) {
						visited.remove(child);
					}
					path.pop();
				}
			}	
		}
		System.out.println("Total nodes are: " + totalNodes);
		System.out.println("Total paths are: " + totalPaths + "\n");
	}
}
