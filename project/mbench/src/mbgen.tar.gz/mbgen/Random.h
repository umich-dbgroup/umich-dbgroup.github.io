/****************************************************************************
* The Michigan Benchmark Data Generator V 1.0
*
* Copyright (c) 2001-2002     EECS Department, University of Michigan
*
* All Rights Reserved.
*
* Permission to use, copy, modify and distribute this software and its
* documentation is hereby granted, provided that both the copyright
* notice and this permission notice appear in all copies of the
* software, derivative works or modified versions, and any portions
* thereof, and that both notices appear in supporting documentation.
* 
* THE AUTHORS AND THE EECS DEPARTMENT OF THE UNIVERSITY
* OF MICHIGAN ALLOW FREE USE OF THIS SOFTWARE IN ITS
* "AS IS" CONDITION, AND THEY DISCLAIM ANY LIABILITY OF ANY KIND
* FOR ANY DAMAGES WHATSOEVER RESULTING FROM THE USE OF THIS SOFTWARE.
*
* Code Authors: Kanda Runapongsa and Jignesh M. Patel
*		
* Description: 
//@{
//This class generates random numbers
//@}
*
* Filename: Random.h
****************************************************************************/

#ifndef _RANDOM_H_
#define _RANDOM_H

#ifdef use_namespace
namespace MIBENCH {
#endif
   
   const int a = 16807; /* multiplier */
   const unsigned long m = 2147483647; /* 2^31 - 1 */
   const unsigned long q = 127773; /* m div a */
   const int r = 2836; /* m mod a */
   
   
   class Random {
   public:
      Random();           // default seed is 1
      Random(unsigned long _seed);
      void initSeed(unsigned long s);  // resets the seed
      unsigned long getNext();      // returns the next random number in the sequence
      double getNextUniform();
      void setMethod(int _method);
      
      //@{
      // Generate bucket number
      // @param lowerBnd The lower bound of the generated numbers
      // @param upperBnd The upper bound of the generated numbers
      // @returns The integer number between the lower and upper bounds
      //@}
      unsigned long genNum(int lowerBnd, int upperBnd);
      
      unsigned long getSeed() {
         return seed;
      }
      
      
   private:
      unsigned long seed;				// current seed value
   };
   
   
#ifdef use_namespace
}
#endif


#endif
