/****************************************************************************
* The Michigan Benchmark Data Generator V 1.0
*
* Copyright (c) 2001-2002     EECS Department, University of Michigan
*
* All Rights Reserved.
*
* Permission to use, copy, modify and distribute this software and its
* documentation is hereby granted, provided that both the copyright
* notice and this permission notice appear in all copies of the
* software, derivative works or modified versions, and any portions
* thereof, and that both notices appear in supporting documentation.
* 
* THE AUTHORS AND THE EECS DEPARTMENT OF THE UNIVERSITY
* OF MICHIGAN ALLOW FREE USE OF THIS SOFTWARE IN ITS
* "AS IS" CONDITION, AND THEY DISCLAIM ANY LIABILITY OF ANY KIND
* FOR ANY DAMAGES WHATSOEVER RESULTING FROM THE USE OF THIS SOFTWARE.
*
* Code Authors: Kanda Runapongsa and Jignesh M. Patel
*		
* Description: Check and handle error conditions
*
* Filename:   ErrorHandlers.cpp
****************************************************************************/
//
// Definitions of ErrorHandler functions
//
#include "ErrorHandlers.h"
#include <iostream.h>
#include <stdlib.h>


//============================================================================
// Print an error message and then exit
//============================================================================
void exitError(const char *msg) {
   //cerr << "Data Generator error:" << msg << endl;
   cerr << msg << endl;
   exit(1);
}  

//============================================================================
// Check if the error condition, 'errCond', is true.  
// If it is, print an error and then exit
//============================================================================
void checkError(const bool errCond, const char *msg) {
   if (errCond == true) {
      exitError(msg);
   } 
   
}  
