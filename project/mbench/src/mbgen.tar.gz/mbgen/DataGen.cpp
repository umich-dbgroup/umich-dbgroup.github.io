/****************************************************************************
* The Michigan Benchmark Data Generator V 1.0
*
* Copyright (c) 2001-2002     EECS Department, University of Michigan
*
* All Rights Reserved.
*
* Permission to use, copy, modify and distribute this software and its
* documentation is hereby granted, provided that both the copyright
* notice and this permission notice appear in all copies of the
* software, derivative works or modified versions, and any portions
* thereof, and that both notices appear in supporting documentation.
* 
* THE AUTHORS AND THE EECS DEPARTMENT OF THE UNIVERSITY
* OF MICHIGAN ALLOW FREE USE OF THIS SOFTWARE IN ITS
* "AS IS" CONDITION, AND THEY DISCLAIM ANY LIABILITY OF ANY KIND
* FOR ANY DAMAGES WHATSOEVER RESULTING FROM THE USE OF THIS SOFTWARE.
*
* Code Authors: Kanda Runapongsa and Jignesh M. Patel
*
* Filename:   DataGen.cpp
****************************************************************************/


#include "DataGen.h"
#include "DocGen.h"
#include "ErrorHandlers.h"
#include <math.h>
#include <time.h>

//=============================================================================
// Constructor.
// Initialize common default settings of documents in the data set.
//=============================================================================
DataGen::DataGen() {
   // Enum are defined for scale factors to be easily indexed in an array
   // Valid scale factors are 0.1, 1,10,100.  
   scaleFactor = one;
   supportSchemaFlag = true;
   prtElemContFlag = true;
   supportDTDFlag = false;
   verbose = false;
   rootLevel = 1;
   strcpy(filenamePrefix,"doc");
}



//=============================================================================
// Destructor.
//=============================================================================
DataGen::~DataGen() {
   
}


//=============================================================================
// Set scale factor as requested.  Currently, only 3 options of scale factors
// are available: 1,10, and 100
//=============================================================================
void DataGen::setScaleFactor(double _scaleFactor) {
   if (_scaleFactor == 0.1) {
      scaleFactor = oneTenth;
   } else if (_scaleFactor == 1) {
      scaleFactor = one;
   } else if (_scaleFactor == 10) {
      scaleFactor = ten;
   } else if (_scaleFactor == 100) {
      scaleFactor = oneHundred;
   }
}

//=============================================================================
// Print options of the program generator
// Available options allow the users to
//  - Set the scale factor. Valid values are {1,10,100}
//  - Set the root level of the data set. Valid values are {1-16} 
//  - Set the prefix of the document name
//  - Set the schema support flag
//  - Print available options  
//=============================================================================

void DataGen::printUsage() {
   cout << "usage: mbgen (options)" << endl;
   cout << "options:" << endl;
   cout.setf(ios::left);
   
   // scale factor
   cout << setw(5)  << ""  << setw(20) << "-sf=scale_factor" 
      << setw(50) << "Valid scale factors are {0.1, 1, 10, 100} [default=1]" 
      << endl;
   
   // document name
   cout << setw(5)  << ""  << setw(20) << "-n=doc_name"		  
      << setw(50) << "Set document file name [default='doc'] " << endl;
   
   // schema support
   cout << setw(5)  << ""  << setw(20) << "-s | -S"		  
      << setw(50) << "Turn off schema support [default=on]" << endl;
   
   // print element content
   cout << setw(5)  << ""  << setw(20) << "-c | -C"		  
      << setw(50) << "Turn off element content printed out [default=on]" << endl;
   
   // DTD support
   cout << setw(5)  << ""  << setw(20) << "-d | -D"		  
      << setw(50) << "Turn on DTD support [default=off]" << endl;
   
   // Toggle Verbose
   cout << setw(5)  << ""  << setw(20) << "-v | -V"		  
      << setw(50) << "Turn on verbose message printing [default=off]" << endl;
   
   // print program usage
   cout << setw(5)  << ""  << setw(20) << "-h | -H" 
      << setw(50) << "Print available options" << endl;
   
   exit(0);
}

// Change schema support flag
//=============================================================================
void DataGen::toggleSchemaSupport() {
   supportSchemaFlag = !supportSchemaFlag;
}

// Change print element content flag
//=============================================================================
void DataGen::togglePrtElemCont() {
   prtElemContFlag = !prtElemContFlag;
}


// Change DTD support flag
//=============================================================================
void DataGen::toggleDTDSupport() {
   supportDTDFlag = !supportDTDFlag;
}

// Toggle Verbose flag
//=============================================================================
void DataGen::toggleVerbose() {
   verbose = !verbose;
}

// Change print element content flag
//=============================================================================
// Write XML documents
//=============================================================================
void DataGen::writeDocs() {
   DocGen docGen(this);
   docGen.writeDocs();
}

int main(int argC, char *argV[]) 
{
   DataGen dg;
   
   int argInd;
   for (argInd = 1; argInd < argC; argInd++) {
      
      // Break out on first non-dash parameter
      if (argV[argInd][0] != '-')
         break;
      
      // scale factor
      if (!strncmp(argV[argInd],"-sf=",4)  ||
         !strncmp(argV[argInd],"-SF=",4)) {
         const char* const param = &argV[argInd][4];
         double sf = atof(param);
         if (sf == 0.1 || sf == 1 || sf == 10 || sf == 100) {
            dg.setScaleFactor(sf);
         } else {
            cerr << sf << " is NOT a valid scale factor. ";
            cerr << "Valid scale factors are {0.1, 1, 10, 100}" << endl;
         }	 
         
         // schema support
      } else if (!strcmp(argV[argInd],"-s") ||
         !strcmp(argV[argInd],"-S")) {
         dg.toggleSchemaSupport();
         // print element content
      } else if (!strcmp(argV[argInd],"-c") ||
         !strcmp(argV[argInd],"-C")) {
         dg.togglePrtElemCont();
         // DTD support
      } else if (!strcmp(argV[argInd],"-d") ||
         !strcmp(argV[argInd],"-D")) {
         dg.toggleDTDSupport();
         // prefix document name
      } else if (!strncmp(argV[argInd],"-n=",3) ||
         !strncmp(argV[argInd],"-N=",3)) {
         dg.setDocName(&argV[argInd][3]);
         
         // turn on verbose mode
      } else if (!strcmp(argV[argInd],"-v") ||
         !strcmp(argV[argInd],"-V")) {
         dg.toggleVerbose();
         
         // print help info
      } else if (!strcmp(argV[argInd],"-h") ||
         !strcmp(argV[argInd],"-H")) {
         dg.printUsage();
         
      } else {
         cerr << "Unknown option," << argV[argInd] << endl;
         dg.printUsage();
      }
   }
   
   // start timing
   clock_t start, end;
   start = clock();
   
   // write documents
   dg.writeDocs();
   
   // end timing
   end = clock();
   
   cout << endl << "Document generation time is "
        << (end - start)/CLOCKS_PER_SEC  << " seconds " << endl; 
   
   return 0;
}

