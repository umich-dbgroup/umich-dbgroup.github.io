/****************************************************************************
* The Michigan Benchmark Data Generator V 1.0
*
* Copyright (c) 2001-2002     EECS Department, University of Michigan
*
* All Rights Reserved.
*
* Permission to use, copy, modify and distribute this software and its
* documentation is hereby granted, provided that both the copyright
* notice and this permission notice appear in all copies of the
* software, derivative works or modified versions, and any portions
* thereof, and that both notices appear in supporting documentation.
* 
* THE AUTHORS AND THE EECS DEPARTMENT OF THE UNIVERSITY
* OF MICHIGAN ALLOW FREE USE OF THIS SOFTWARE IN ITS
* "AS IS" CONDITION, AND THEY DISCLAIM ANY LIABILITY OF ANY KIND
* FOR ANY DAMAGES WHATSOEVER RESULTING FROM THE USE OF THIS SOFTWARE.
*
* Code Authors: Kanda Runapongsa and Jignesh M. Patel
*		
* Description: 
//@{
// This class checks and handles error conditions
//
//@}
*
* Filename:   ErrorHandlers.h
****************************************************************************/

#ifndef _ERROR_HANDLERS_H
#define _ERROR_HANDLERS_H



#ifdef use_namespace
namespace MBENCH {
#endif
   
   //@{
   // Print out the error message and then exit the program
   // @param errMsg  The error message to be printed out
   //@}	
   void exitError(const char *errMsg);
   
   //@{
   // Check whether the error condition is true.  If it is,
   // then call 'exitError'.  
   // @param errCond The error condition
   // @param errMsg  The error message to be printed out
   //@}
   void checkError(const bool errCond, const char *errMsg);
   
#ifdef use_namespace
}
#endif 
#endif
