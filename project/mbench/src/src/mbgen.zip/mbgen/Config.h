/****************************************************************************
* The Michigan Benchmark Data Generator V 1.0
*
* Copyright (c) 2001-2002     EECS Department, University of Michigan
*
* All Rights Reserved.
*
* Permission to use, copy, modify and distribute this software and its
* documentation is hereby granted, provided that both the copyright
* notice and this permission notice appear in all copies of the
* software, derivative works or modified versions, and any portions
* thereof, and that both notices appear in supporting documentation.
* 
* THE AUTHORS AND THE EECS DEPARTMENT OF THE UNIVERSITY
* OF MICHIGAN ALLOW FREE USE OF THIS SOFTWARE IN ITS
* "AS IS" CONDITION, AND THEY DISCLAIM ANY LIABILITY OF ANY KIND
* FOR ANY DAMAGES WHATSOEVER RESULTING FROM THE USE OF THIS SOFTWARE.
*
* Code Authors: Kanda Runapongsa and Jignesh M. Patel
*		
* Description:
//@{
// Configuration of the schema of the documents in the data set
//@}
* Filename:   Config.h
****************************************************************************/


#ifndef _RANDOM_H_
#define _RANDOM_H

// number of levels in the document
static const unsigned MAX_NUM_LEVELS = 16;

// fanouts at each level 
//@{
// For the data set with scale factor =0.1(1, 10,100), 
// each level in the tree has  a fanout of 2, except for levels 5,6,7, and 8
// The levels 5,6,and 7 have a fanout of 4(13,39,111), where as level 8 has a 
// fanout of 1/4(1/13,1/39, 1/111).  This choice of fanout implies that the number of 
// nodes at levels 7 and 9 is 256.
//@}
static const int NUM_SCALE_FACTORS = 4;
static const double fanout[NUM_SCALE_FACTORS][MAX_NUM_LEVELS+1] =  
{
   {0, 2, 2, 2, 2,   4,   4,   4, (double) 1/4,   2, 2, 2, 2, 2, 2, 2, 0},
   {0, 2, 2, 2, 2,  13,  13,  13, (double) 1/13,  2, 2, 2, 2, 2, 2, 2, 0},
   {0, 2, 2, 2, 2,  39,  39,  39, (double) 1/39,  2, 2, 2, 2, 2, 2, 2, 0},
   {0, 2, 2, 2, 2, 111, 111, 111, (double) 1/111, 2, 2, 2, 2, 2, 2, 2, 0}
}; 

enum ScaleFactor {oneTenth, one, ten, oneHundred};
static const double mapScales[] = {0.1, 1, 10, 100};

typedef unsigned long myBigUnsigned; // used for generating large unsigned numbers

#endif
