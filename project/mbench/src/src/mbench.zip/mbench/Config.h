/****************************************************************************
 * The Michigan Benchmark Data Generator V 1.0
 *
 * COPYRIGHT 2002 THE REGENTS OF THE UNIVERSITY OF MICHIGAN
 * 
 * ALL RIGHTS RESERVED
 *
 * PERMISSION IS GRANTED TO USE, COPY, CREATE DERIVATIVE WORKS AND 
 * REDISTRIBUTE THIS SOFTWARE AND SUCH DERIVATIVE WORKS FOR ANY 
 * PURPOSE, SO LONG AS NO FEE IS CHARGED, AND SO LONG AS THE COPYRIGHT 
 * NOTICE ABOVE, THIS GRANT OF PERMISSION, AND THE DISCLAIMER BELOW 
 * APPEAR IN ALL COPIES MADE; AND SO LONG AS THE NAME OF THE UNIVERSITY 
 * OF MICHIGAN IS NOT USED IN ANY ADVERTISING OR PUBLICITY PERTAINING 
 * TO THE USE OR DISTRIBUTION OF THIS SOFTWARE WITHOUT SPECIFIC, 
 * WRITTEN PRIOR AUTHORIZATION.
 *
 * THIS SOFTWARE IS PROVIDED AS IS, WITHOUT REPRESENTATION FROM 
 * THE UNIVERSITY OF MICHIGAN AS TO ITS FITNESS FOR ANY PURPOSE, AND 
 * WITHOUT WARRANTY BY THE UNIVERSITY OF MICHIGAN OF ANY KIND, EITHER 
 * EXPRESS OR IMPLIED, INCLUDING WITHOUT LIMITATION THE IMPLIED 
 * WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE. 
 * THE REGENTS OF THE UNIVERSITY OF MICHIGAN SHALL NOT BE LIABLE FOR 
 * ANY DAMAGES, INCLUDING SPECIAL, INDIRECT, INCIDENTAL, OR 
 * CONSEQUENTIAL DAMAGES, WITH RESPECT TO ANY CLAIM ARISING OUT OF OR 
 * IN CONNECTION WITH THE USE OF THE SOFTWARE, EVEN IF IT HAS BEEN OR 
 * IS HEREAFTER ADVISED OF THE POSSIBILITY OF SUCH DAMAGES.
 *
 ***************************************************************************/

/***************************************************************************
 *
 * CREDITS: 
 * Code Authors (2002): Kanda Runapongsa and Jignesh M. Patel
 *                      EECS Department, University of Michigan
 *
 **************************************************************************/

/****************************************************************************
* Description:
//@{
// Configuration of the schema of the documents in the data set
//@}
* Filename:   Config.h
****************************************************************************/


#ifndef _RANDOM_H_
#define _RANDOM_H

// number of levels in the document
static const unsigned MAX_NUM_LEVELS = 16;

// fanouts at each level 
//@{
// For the data set with scale factor =0.1(1, 10,100), 
// each level in the tree has  a fanout of 2, except for levels 5,6,7, and 8
// The levels 5,6,and 7 have a fanout of 4(13,39,111), where as level 8 has a 
// fanout of 1/4(1/13,1/39, 1/111).  This choice of fanout implies that the number of 
// nodes at levels 7 and 9 is 256.
//@}
static const int NUM_SCALE_FACTORS = 4;
static const double fanout[NUM_SCALE_FACTORS][MAX_NUM_LEVELS+1] =  
{
   {0, 2, 2, 2, 2,   4,   4,   4, (double) 1/4,   2, 2, 2, 2, 2, 2, 2, 0},
   {0, 2, 2, 2, 2,  13,  13,  13, (double) 1/13,  2, 2, 2, 2, 2, 2, 2, 0},
   {0, 2, 2, 2, 2,  39,  39,  39, (double) 1/39,  2, 2, 2, 2, 2, 2, 2, 0},
   {0, 2, 2, 2, 2, 111, 111, 111, (double) 1/111, 2, 2, 2, 2, 2, 2, 2, 0}
}; 

enum ScaleFactor {oneTenth, one, ten, oneHundred};
static const double mapScales[] = {0.1, 1, 10, 100};

typedef unsigned long myBigUnsigned; // used for generating large unsigned numbers

#endif
