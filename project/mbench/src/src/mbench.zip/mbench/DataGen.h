/****************************************************************************
 * The Michigan Benchmark Data Generator V 1.0
 *
 * COPYRIGHT 2002 THE REGENTS OF THE UNIVERSITY OF MICHIGAN
 * 
 * ALL RIGHTS RESERVED
 *
 * PERMISSION IS GRANTED TO USE, COPY, CREATE DERIVATIVE WORKS AND 
 * REDISTRIBUTE THIS SOFTWARE AND SUCH DERIVATIVE WORKS FOR ANY 
 * PURPOSE, SO LONG AS NO FEE IS CHARGED, AND SO LONG AS THE COPYRIGHT 
 * NOTICE ABOVE, THIS GRANT OF PERMISSION, AND THE DISCLAIMER BELOW 
 * APPEAR IN ALL COPIES MADE; AND SO LONG AS THE NAME OF THE UNIVERSITY 
 * OF MICHIGAN IS NOT USED IN ANY ADVERTISING OR PUBLICITY PERTAINING 
 * TO THE USE OR DISTRIBUTION OF THIS SOFTWARE WITHOUT SPECIFIC, 
 * WRITTEN PRIOR AUTHORIZATION.
 *
 * THIS SOFTWARE IS PROVIDED AS IS, WITHOUT REPRESENTATION FROM 
 * THE UNIVERSITY OF MICHIGAN AS TO ITS FITNESS FOR ANY PURPOSE, AND 
 * WITHOUT WARRANTY BY THE UNIVERSITY OF MICHIGAN OF ANY KIND, EITHER 
 * EXPRESS OR IMPLIED, INCLUDING WITHOUT LIMITATION THE IMPLIED 
 * WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE. 
 * THE REGENTS OF THE UNIVERSITY OF MICHIGAN SHALL NOT BE LIABLE FOR 
 * ANY DAMAGES, INCLUDING SPECIAL, INDIRECT, INCIDENTAL, OR 
 * CONSEQUENTIAL DAMAGES, WITH RESPECT TO ANY CLAIM ARISING OUT OF OR 
 * IN CONNECTION WITH THE USE OF THE SOFTWARE, EVEN IF IT HAS BEEN OR 
 * IS HEREAFTER ADVISED OF THE POSSIBILITY OF SUCH DAMAGES.
 *
 ***************************************************************************/

/***************************************************************************
 *
 * CREDITS: 
 * Code Authors (2002): Kanda Runapongsa and Jignesh M. Patel
 *                      EECS Department, University of Michigan
 *
 **************************************************************************/

/****************************************************************************
* Description:  
//@{
// This class accepts the program options provided by the users and set 
// the configuration parameters of the data set accordingly.  
//
// Generate a set of XML documents with three different scaling 
//			factors (1,10,100).  The default scale factor is 1.
//@}
*
* Filename:   DataGen.h
****************************************************************************/
#ifndef _DATA_GENERATOR_H
#define _DATA_GENERATOR_H

#include <string.h>
#include <stdlib.h>
#include <iostream.h>
#include <fstream.h>
#include <assert.h>
#include <iomanip.h>

#ifdef _MSC_VER
#include <strstrea.h>
#else
#include <strstream.h>
#endif

#include "StrGen.h"
#include "Config.h"

#ifdef use_namespace
namespace MBENCH {
#endif 
   
   // maximum number of characters of the prefix of the document name
   const int PREFIX_FILENAME_LEN = 10;
   
   class DataGen {
      friend class DocGen;
   public:
      //@{
      // Default constructor
      //@}
      DataGen();
      
      
      //@{
      // Destructor
      //@}
      ~DataGen();
      
      
      
      //@{
      // Set the scaling factor of the generated document
      // @param  scaleFactor  The scaling factor of the document
      //@}
      void setScaleFactor(double scaleFactor);
      
      
      
      //@{
      // Print program usage
      //@}
      void printUsage();
      
      
      //@{
      // Turn on/off schema support
      //@}
      void toggleSchemaSupport();
      
      //@{
      // Turn on/off DTD support
      //@}
      void toggleDTDSupport();
      
      //@{
      // Turn on/off print element content
      //@}
      void togglePrtElemCont();
      
      
      //@{
      // Turn on/off printing verbose messages during data generation 
      //@}
      void toggleVerbose();
      
      //@{
      // Set the root level of the document in the data set
      // When the root level = 1, there is a single document generated
      //@}
      void setRootLevel(int _rootLevel) {
         rootLevel = _rootLevel;
      }
      
      //@{
      // Write documents in the data set
      //@}
      void writeDocs();
      
      //@{
      // Set the prefix of the document file name
      //@}
      void setDocName(char *prefix) {
         strcpy(filenamePrefix,prefix);
      }
      
   private:
      
      // prefix filename of XML documents
      char filenamePrefix[PREFIX_FILENAME_LEN];
      
      // scale factor
      ScaleFactor scaleFactor;
      
      // boolean to tell us whether it supports XML schema
      bool supportSchemaFlag;
      
      // boolean to tell us whether to print element content
      bool prtElemContFlag;
      
      // boolean to tell us whether it supports DTD declaration
      bool supportDTDFlag;
      
      // boolean to indicate if verbose is on during data generation
      bool verbose;
      
      // root level of the documents in the data set
      int rootLevel;
      
   };
   
#ifdef use_namespace
}
#endif 

#endif

