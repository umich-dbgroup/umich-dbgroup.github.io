/****************************************************************************
 * The Michigan Benchmark Data Generator V 1.0
 *
 * COPYRIGHT 2002 THE REGENTS OF THE UNIVERSITY OF MICHIGAN
 * 
 * ALL RIGHTS RESERVED
 *
 * PERMISSION IS GRANTED TO USE, COPY, CREATE DERIVATIVE WORKS AND 
 * REDISTRIBUTE THIS SOFTWARE AND SUCH DERIVATIVE WORKS FOR ANY 
 * PURPOSE, SO LONG AS NO FEE IS CHARGED, AND SO LONG AS THE COPYRIGHT 
 * NOTICE ABOVE, THIS GRANT OF PERMISSION, AND THE DISCLAIMER BELOW 
 * APPEAR IN ALL COPIES MADE; AND SO LONG AS THE NAME OF THE UNIVERSITY 
 * OF MICHIGAN IS NOT USED IN ANY ADVERTISING OR PUBLICITY PERTAINING 
 * TO THE USE OR DISTRIBUTION OF THIS SOFTWARE WITHOUT SPECIFIC, 
 * WRITTEN PRIOR AUTHORIZATION.
 *
 * THIS SOFTWARE IS PROVIDED AS IS, WITHOUT REPRESENTATION FROM 
 * THE UNIVERSITY OF MICHIGAN AS TO ITS FITNESS FOR ANY PURPOSE, AND 
 * WITHOUT WARRANTY BY THE UNIVERSITY OF MICHIGAN OF ANY KIND, EITHER 
 * EXPRESS OR IMPLIED, INCLUDING WITHOUT LIMITATION THE IMPLIED 
 * WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE. 
 * THE REGENTS OF THE UNIVERSITY OF MICHIGAN SHALL NOT BE LIABLE FOR 
 * ANY DAMAGES, INCLUDING SPECIAL, INDIRECT, INCIDENTAL, OR 
 * CONSEQUENTIAL DAMAGES, WITH RESPECT TO ANY CLAIM ARISING OUT OF OR 
 * IN CONNECTION WITH THE USE OF THE SOFTWARE, EVEN IF IT HAS BEEN OR 
 * IS HEREAFTER ADVISED OF THE POSSIBILITY OF SUCH DAMAGES.
 *
 ***************************************************************************/

/***************************************************************************
 *
 * CREDITS: 
 * Code Authors (2002): Kanda Runapongsa and Jignesh M. Patel
 *                      EECS Department, University of Michigan
 *
 **************************************************************************/

/****************************************************************************
* Description: Generate a set of XML documents with three different scaling 
*              factors (1,10,100).  The default scaling factor is 1.
* Filename:   DocGen.cpp
****************************************************************************/

#include "DocGen.h"
#include "ErrorHandlers.h"
#include <math.h>

// element tag name
const char *BASETYPE_ELEM_NAME = "eNest";
const char *OCCASIONAL_ELEM_NAME = "eOccasional";
const char *ROOT_ELEM_NAME = "eNest";

const unsigned MAX_STR_LENGTH = 600;

const myBigUnsigned ROOT_ID = 1;

// namespace references
const char *XMLNS_XSI = "\"http://www.w3.org/2001/XMLSchema-instance\"";
const char *SCHEMA_LOCATION ="\"http://www.eecs.umich.edu/db/mbench/bm.xsd\"";

const int NUM_NODES_PRINT_STEP = 500000;
const int NUM_NODES_PRINT_SMALL_STEP = NUM_NODES_PRINT_STEP/10;



//=============================================================================
// Constructor.
//=============================================================================
DocGen::DocGen() {
}

DocGen::DocGen(DataGen *_dg) {
   dg = _dg;
}


//=============================================================================
// Destructor.
//=============================================================================
DocGen::~DocGen() {
}


//=============================================================================
// Set configuration of the document according to the scaling factor.
// The configuration here includes the number of (cumulative) nodes at
// each level and number of nodes in the document
//=============================================================================
void DocGen::setConfig() {
   myBigUnsigned i;
   
   // copy these variables to avoid the overhead in making references
   rootLevel = dg->rootLevel;
   scaleFactor = dg->scaleFactor;
   
   // initialize counter at each level.  this is useful for 
   // aUnique1 assignment
   for (i = 1; i <= MAX_NUM_LEVELS; i++) {
      nodes[i] = 0;
   }
   
   // compute number of nodes at each level
   computeNumNodes();
   
   // we need to have a unique random number generated for aUnique2 attribute
   // initialize flag of each number not used.  we need to do this to 
   // ensure that we don't reuse the numbers that were 
   // already used.
   numDocs = numNodes[rootLevel];
   filenameWidth = static_cast<unsigned>(floor(log10(numDocs))) + 1; 
   
   numDatasetNodes = numTotalNodes[MAX_NUM_LEVELS];
   
   aUnique1Used = new bool[numDatasetNodes+1];
   aUnique2Used = new bool[numDatasetNodes+1];
   for (i = 1; i <= numDatasetNodes; i++) {
      aUnique1Used[i] = false;
      aUnique2Used[i] = false;
   }
   
   curNumDocs = 1;
   
}



//=============================================================================
// Set number of nodes at each level according to the scale factor
// This function depends on the fanout at each level which is defined in the 
// constant global variable 'fanout' 
//=============================================================================
void DocGen::computeNumNodes() {
   unsigned l;
   
   // init num nodes per level per data set
   numNodes[0] = 0;
   numNodes[1] = 1;
   for (l = 2; l <= MAX_NUM_LEVELS; l++) 
   { 
      if (fanout[scaleFactor][l-1] < 1) 
      {
         numNodes[l] = 
            static_cast<myBigUnsigned>(numNodes[l-1]/fanout[scaleFactor][l-2]);
      } 
      else 
      { 
         numNodes[l] = 
            static_cast<myBigUnsigned>(numNodes[l-1]*fanout[scaleFactor][l-1]);
      }
   }
   
   numTotalNodes[0] = 0;
   numTotalNodes[1] = 1;
   for (l = 2; l <= MAX_NUM_LEVELS; l++) {	
      numTotalNodes[l] = numTotalNodes[l-1] + numNodes[l];
   }
   
   numDocs = numNodes[rootLevel];
   docNumCumNodes[rootLevel-1] = 0;
   docNumCumNodes[rootLevel] = 1;
   for (l = rootLevel+1; l <= MAX_NUM_LEVELS; l++) {
      docNumCumNodes[l] = docNumCumNodes[l-1] + numNodes[l]/numDocs;
   }
}

//=============================================================================
// Initialize the fanouts, node counters, and random generator methods
//=============================================================================
void DocGen::initDoc() {
   
   // initialize current level to be one less than rootLevel since
   // we always increment the level as we start to write begin tag
   
   
   level = 0;
   
   // total number of nodes in the document
   numNodesCount = 0;
   
   // initialize total number of eNest nodes
   numENestNodes = 0;
   
   // initialize total number of eOccasional nodes
   numEOccNodes = 0;	
   
   
}


//=============================================================================
// Compute the reference attribute.
//=============================================================================
myBigUnsigned DocGen::computeARef(myBigUnsigned parentID) {
   
   // currently, the reference attribute is computed by subtracting
   // 11 from the parentID.
   if (parentID < 11+ROOT_ID)
      return ROOT_ID;
   else
      return parentID - 11;
}

//=============================================================================
// Write string attributes and element content
//=============================================================================
void DocGen::writeStrAttrs(myBigUnsigned aUnique1, myBigUnsigned aSixtyFour) {
   char *word = new char[MAX_WORD_LENGTH];
   char *str = new char[MAX_STR_LENGTH];
   
   
   
   // this is content of string attribute 
   gs.genWord(word);
   
   
   fpOut << " aString=\"";
   fpOut << "Sing a song of " << word;
   fpOut << "\">" << endl;
   numENestNodes++;
   numNodesCount++;
   
   
   if (dg->prtElemContFlag) {
      
      strcpy(str,"Sing a song of ");
      strcat(str,word);
      strcat(str,"\n");
      
      
      // we generate each word for each line in the template
      gs.genWord(word);
      
      
      strcat(str,"A pocket full of ");
      strcat(str,word);
      strcat(str,"\n");
      
      
      gs.genWord(word);
      
      
      strcat(str,"Four and twenty ");
      strcat(str,word);
      strcat(str,"\n");
      
      
      gs.genWord(word);
      
      
      strcat(str,"All baked in a ");
      strcat(str,word);
      strcat(str,".\n\n");
      
      
      gs.genWord(word);
      
      
      strcat(str,"When the ");
      strcat(str,word);
      strcat(str," was opened,\n");
      
      
      gs.genWord(word);
      
      
      strcat(str,"The ");
      strcat(str,word);
      strcat(str," began to sing;\n");
      
      
      gs.genWord(word);
      
      
      strcat(str,"Wasn't that a dainty ");
      strcat(str,word);
      strcat(str,"\n");
      
      
      gs.genWord(word);
      
      
      strcat(str,"To set before the ");
      strcat(str,word);
      strcat(str,"?\n\n");
      
      
      gs.genWord(word);
      
      
      strcat(str,"The King was in his ");
      strcat(str,word);
      strcat(str,",\n");
      
      
      gs.genWord(word);
      
      strcat(str,"Counting out his ");
      strcat(str,word);
      strcat(str,";\n");
      
      gs.genWord(word);
      
      
      strcat(str,"The Queen was in the ");
      strcat(str,word);
      strcat(str,"\n");
      
      
      gs.genWord(word);
      
      
      strcat(str,"Eating bread and ");
      strcat(str,word);
      strcat(str,".\n\n");
      
      
      gs.genWord(word);
      
      
      strcat(str,"The maid was in the ");
      strcat(str,word);
      strcat(str,"\n");
      
      
      gs.genWord(word);
      
      
      strcat(str,"Hanging out the ");
      strcat(str,word);
      strcat(str,";\n");
      
      
      gs.genWord(word);
      
      
      strcat(str,"When down came a ");
      strcat(str,word);
      strcat(str,",\n");
      
      
      gs.genWord(word);
      
      
      strcat(str,"And snipped off her ");
      strcat(str,word);
      strcat(str,"!\n");
      fpOut << str;  
      
  }
  write_eOccasional(aUnique1, aSixtyFour, str);
  
  delete[] word;
  delete[] str;  
}

//=============================================================================
// Write eOccasional element if the condition is satisfied.
//=============================================================================
void DocGen::write_eOccasional(myBigUnsigned aUnique1, myBigUnsigned aSixtyFour, char *str) {
   
   // The presence or absence of the eOccasionalType element is determined
   // by the value of the attribute aSixtyFour
   if (aSixtyFour == 0) {
      numEOccNodes++;
      numNodesCount++;
      unsigned l;
      for (l = 1; l < level; l++) {
         fpOut << "   ";
      }
      fpOut << "<eOccasional aRef=\"" 
         << computeARef(aUnique1) << "\">" << endl;
      if (dg->prtElemContFlag) 
         fpOut << str;
      for (l = 1; l < level; l++) {
         fpOut << "   ";
      }
      fpOut << "</eOccasional>" << endl;
   } 
}


//=============================================================================
// Computer aUnique1 attribute
//=============================================================================
myBigUnsigned DocGen::computeAUnique1() {
   
   // aUnique1 is a unique integer value generated by traversing the entire
   // data tree in a breadth-first manner
   
   unsigned l = level;
   myBigUnsigned aUnique1;
   
   nodes[l]++;
   
   aUnique1 = numTotalNodes[l-1]  + nodes[l];
   
   if (aUnique1Used[aUnique1] == true) {
      cout << "aUnique1 " << aUnique1 << " is repeated at level " << level 
         << " numTotalNodes[l-1] " << numTotalNodes[l-1] << " nodes[l]: "
         << nodes[l] << endl;
      exit(1);
   } 
   
   
   return aUnique1;
}

//=============================================================================
// Computer aUnique2 attribute
//=============================================================================
myBigUnsigned DocGen::computeAUnique2() {
   
   // aUnique2: a unique integer value generated randomly
   myBigUnsigned u2index = aUnique2RNG.genNum(1,numDatasetNodes);
   
   while (aUnique2Used[u2index] == true) {
      u2index = aUnique2RNG.genNum(1,numDatasetNodes);
   }
   
   aUnique2Used[u2index] = true;
   
   return u2index;
}

//=============================================================================
// Compute attributes that are based on the mod  operation between two numbers
//=============================================================================
myBigUnsigned DocGen::computeAttr(myBigUnsigned baseNum, unsigned modNum) {
   return baseNum % modNum;
}

//=============================================================================
// Write element begin tag along with the attributes of the element
//=============================================================================
void DocGen::writeBeginTag(const char *elemName, unsigned level) {
   for (unsigned l = 1; l < level; l++) {
      fpOut << "   ";
   }
   
   if (level > rootLevel) {
      // open begin element tag
      fpOut << "<" << elemName;
   } else {
      fpOut << "<" << ROOT_ELEM_NAME;
      // print out schema-reference only if XML schema sis supported
      if (dg->supportSchemaFlag == true) {
         fpOut   << " xmlns:xsi=" << XMLNS_XSI  
            << " xsi:schemaLocation=" << SCHEMA_LOCATION 
            << " ";
      }
   }
   
   
   // aUnique1: a unique integer generated by traversing the entire data tree
   // in a breadth-first manner
   myBigUnsigned aUnique1 = computeAUnique1();
   
   
   if (aUnique1Used[aUnique1] == false) {
      
      // aUnique2: a unique integer value generated randomly.
      myBigUnsigned aUnique2 = computeAUnique2();
      
      
      
      // aFour: set to aUnique1 mod 4
      myBigUnsigned aFour = computeAttr(aUnique2,4);
      
      // aSixteen: set to aUnique2 mod 16
      myBigUnsigned aSixteen = computeAttr(aUnique1 + aUnique2,16);
      
      // aSixtyFour: set to aUnique2 mod 64
      myBigUnsigned aSixtyFour = computeAttr(aUnique2,64);
      
      
      
      fpOut << " aUnique1=\"" << aUnique1 << "\"";
      fpOut << " aUnique2=\"" << aUnique2 << "\"";
      
      // aLevel: an integer avlaue to store the level of the node
      fpOut << " aLevel=\"" << level << "\"";
      fpOut << " aFour=\"" << aFour << "\"";
      fpOut << " aSixteen=\"" << aSixteen << "\"" ;
      fpOut << " aSixtyFour=\"" << aSixtyFour << "\"";
      
      
      // write string attributes and content
      writeStrAttrs(aUnique1, aSixtyFour);
   }
   aUnique1Used[aUnique1] = true;
}

//=============================================================================
// Write element end tag 
//=============================================================================
void DocGen::writeEndTag(const char *elemName, unsigned level) {
   for (unsigned l = 1; l < level; l++) {
      fpOut << "   ";
   }
   
   
   // to test the correctness of producing expected number of nodes 
   // in each level
   // fpOut << "</" << elemName << " L" << level << " N" << nodes[level] 
   // << ">" << endl; 
   fpOut << "</" << elemName << ">" << endl; 
}

//=============================================================================
// Write element content
//=============================================================================
void DocGen::writeContent(const char *elemContent) {
   fpOut << elemContent;
}


//=============================================================================
// Write element 
//=============================================================================
void DocGen::writeElem() {
   
   level++;
   
   
   // need to distinguish between the root element and non-root elements
   // since the root element has special element tag name.
   if (level == rootLevel) 
      writeBeginTag(ROOT_ELEM_NAME, rootLevel);
   else
      writeBeginTag(BASETYPE_ELEM_NAME, level);
   
   
   if ((numNodesCount % NUM_NODES_PRINT_SMALL_STEP) == 0) {
      if ((numNodesCount % NUM_NODES_PRINT_STEP) == 0) {
         cout << ". Wrote " << numNodesCount/1000 << "K elements "; 
      } else {
         cout << "." << flush; 
      }
   }
   
   // if number of fanouts at the current level is greater than 0, then
   // we need to call this function recursively so that we generate data
   // in depth-first tarversal manner
   unsigned l = level;
   
   
   if (l < MAX_NUM_LEVELS && fanout[scaleFactor][l] > 0) {
      writeContent("\n");
      if (fanout[scaleFactor][l] > 1) {
         for (unsigned i = 0; i < fanout[scaleFactor][l]; i++) {
            writeElem();
         } 
      } else {
         //  To avoid round off error with doubles, use 
         //  scalefactor of the previous level
         // myBigUnsigned f = (myBigUnsigned) (1/fanout[scaleFactor][l]);
         myBigUnsigned f = (myBigUnsigned) (fanout[scaleFactor][l-1]);
         if (((nodes[l]+1) % f) == 0) {
            writeElem();  
         }
      }
   }
   
   // need to distinguish between the root element and non-root elements
   // since the root element has special element tag name.
   if (level == rootLevel)
      writeEndTag(ROOT_ELEM_NAME,rootLevel);
   else
      writeEndTag(BASETYPE_ELEM_NAME, level);
   
   
   
   curNumNodes++;
   
   
   
   level--;
}

//=============================================================================
// Write document declaration
//=============================================================================
void DocGen::writeDocDeclaration() {
   fpOut << "<?xml version=\"1.0\"?>" << endl;
}

//=============================================================================
// Write DTD declaration
//=============================================================================
void DocGen::writeDTDDeclaration() {
   fpOut << "<!DOCTYPE root SYSTEM \"mbench.dtd\">" << endl;
}
//=============================================================================
// Write statistics of the generated documents
//=============================================================================
void DocGen::writeStats() {
   cout << endl << endl << "Statistics  of this data set:" << endl;	
   cout		 << "============================" << endl;
   cout << "There are total " << numENestNodes << " 'eNest' nodes" << endl;
   cout << "There are total " << numEOccNodes << " 'eOccasional' nodes" << endl;
   cout << "There are total " << numNodesCount << " nodes " << endl;
}

//=============================================================================
// Write an XML document
//=============================================================================
void DocGen::writeDoc(unsigned docIndex) {
   
   if (dg->verbose) prtConfig(); 
   
   strstream filename;
   filename << dg->filenamePrefix << setw(filenameWidth) 
      << setfill('0') << docIndex << ".xml" << ends;	
   cout << "Writing to file '" << filename.str() << "' ..." << endl;
   cout << "Progress: " << flush;
   
   
   fpOut.open(filename.str(),ios::out);
   if (fpOut.good()) {
      writeDocDeclaration();
      if (dg->supportDTDFlag == true) {
         writeDTDDeclaration();
      }
      curNumNodes = 0;
      writeElem();
      fpOut.close();
      writeStats();
      exit(0);
   }
}


void DocGen::prtConfig() {
   cout << "Configuration of this data set:" << endl;
   cout << "===============================" << endl;
   cout << "the root level = " << rootLevel << endl;
   cout << "the scale factor = " << mapScales[scaleFactor] << endl;
   if (dg->supportDTDFlag == true) {
      cout << "DTD declaration included" << endl;
   } else {
      cout << "No DTD declaration" << endl;
   }
   if (dg->supportSchemaFlag == true) {
      cout << "XML Schema is referenced" << endl;
   } else {
      cout <<  "XML Schema is NOT referenced" << endl;
   }
   if (dg->prtElemContFlag == true) {
      cout << "Element content is printed" << endl;
   } else {
      cout << "Element content is not printed" << endl;
   }	
   
   unsigned l;
   cout << "   Level (  fanout,   #nodes,  cummulative): " << endl;
   for (l = 1; l <= MAX_NUM_LEVELS; l++) 
   {
      cout << setw(8) << l << " (" ;
      if (l == 8) { 
         cout << setw(7-(unsigned) log10(fanout[scaleFactor][l-1])) 
            << "1/" << fanout[scaleFactor][l-1]; 
      }
      else { 
         cout << setw(8) << fanout[scaleFactor][l]; 
      }
      cout << ", " << setw(8) << numNodes[l] << ", "
         << setw(12) << numTotalNodes[l] << ")" << endl;
   }
   
   if (numDocs > 1) cout << "Generating " << numDocs << " documents " << endl;
   cout << "===========" << setw(filenameWidth) << setfill('=') 
      << "========== " << endl;
}

//=============================================================================
// Write a set of XML documents in the data set.
//=============================================================================
void DocGen::writeDocs() {
   setConfig();
   initDoc();
   writeDoc(curNumDocs);
}


