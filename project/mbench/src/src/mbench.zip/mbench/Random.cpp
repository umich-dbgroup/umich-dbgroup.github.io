/****************************************************************************
 * The Michigan Benchmark Data Generator V 1.0
 *
 * COPYRIGHT 2002 THE REGENTS OF THE UNIVERSITY OF MICHIGAN
 * 
 * ALL RIGHTS RESERVED
 *
 * PERMISSION IS GRANTED TO USE, COPY, CREATE DERIVATIVE WORKS AND 
 * REDISTRIBUTE THIS SOFTWARE AND SUCH DERIVATIVE WORKS FOR ANY 
 * PURPOSE, SO LONG AS NO FEE IS CHARGED, AND SO LONG AS THE COPYRIGHT 
 * NOTICE ABOVE, THIS GRANT OF PERMISSION, AND THE DISCLAIMER BELOW 
 * APPEAR IN ALL COPIES MADE; AND SO LONG AS THE NAME OF THE UNIVERSITY 
 * OF MICHIGAN IS NOT USED IN ANY ADVERTISING OR PUBLICITY PERTAINING 
 * TO THE USE OR DISTRIBUTION OF THIS SOFTWARE WITHOUT SPECIFIC, 
 * WRITTEN PRIOR AUTHORIZATION.
 *
 * THIS SOFTWARE IS PROVIDED AS IS, WITHOUT REPRESENTATION FROM 
 * THE UNIVERSITY OF MICHIGAN AS TO ITS FITNESS FOR ANY PURPOSE, AND 
 * WITHOUT WARRANTY BY THE UNIVERSITY OF MICHIGAN OF ANY KIND, EITHER 
 * EXPRESS OR IMPLIED, INCLUDING WITHOUT LIMITATION THE IMPLIED 
 * WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE. 
 * THE REGENTS OF THE UNIVERSITY OF MICHIGAN SHALL NOT BE LIABLE FOR 
 * ANY DAMAGES, INCLUDING SPECIAL, INDIRECT, INCIDENTAL, OR 
 * CONSEQUENTIAL DAMAGES, WITH RESPECT TO ANY CLAIM ARISING OUT OF OR 
 * IN CONNECTION WITH THE USE OF THE SOFTWARE, EVEN IF IT HAS BEEN OR 
 * IS HEREAFTER ADVISED OF THE POSSIBILITY OF SUCH DAMAGES.
 *
 ***************************************************************************/

/***************************************************************************
 *
 * CREDITS: 
 * Code Authors (2002): Kanda Runapongsa and Jignesh M. Patel
 *                      EECS Department, University of Michigan
 *
 **************************************************************************/

/****************************************************************************
*
* Filename: Random.cpp
* Description: Generate random numbers
*
****************************************************************************/

#include <iostream.h>
#include <math.h>

#include "Random.h"

#ifdef use_namespace
namespace RANDOM
#endif

//=============================================================================
// Constructor.
//============================================================================= 
Random::Random() {
   seed = 1; 
}

//=============================================================================
// Constructor.
//=============================================================================
Random::Random(unsigned long _seed) {
   seed = _seed;
}

//=============================================================================
// Initialize seed
//=============================================================================
void Random::initSeed(unsigned long newSeed) {
   // seed must be from 1,2,..,m-1
   if (newSeed >= 1 && newSeed < m)
      seed = newSeed;
}

// getNext() and getNextUniform() methods are the methods that generate random
// numbers based on the algorithm presented in the paper, "Random Number 
// Generators: Good Ones are Hard to Find" by S.K. Park and K.W. Miller, 
// Communications of the ACM 31:10 (Oct 1988)

//=============================================================================
// getNext(): return long number that is in the range 1 to m-1
//=============================================================================
unsigned long Random::getNext() {
   unsigned long lo, hi;
   hi = seed / q;
   lo = seed % q;
   long test = a*lo - r*hi;
   if (test > 0)
      seed = test;
   else
      seed = test + m;
   return seed;	
}

//=============================================================================
// getNextUniform(): return long number that is between 0 and 1
//=============================================================================
double Random::getNextUniform() {  
   return (double) (getNext()/(double) m);
}



// ============================================================================
// Generate number that is randomly distributed between the given lower bound
// and the given upper bound.
// ============================================================================
unsigned long Random::genNum(int lowerBnd, int upperBnd) {
   double rand = getNextUniform();
   
   double step = static_cast<double>(upperBnd - lowerBnd + 1);
   return (static_cast<unsigned long>(lowerBnd + step*rand));
}
