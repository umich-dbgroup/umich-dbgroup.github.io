/****************************************************************************
 * The Michigan Benchmark Data Generator V 1.0
 *
 * COPYRIGHT 2002 THE REGENTS OF THE UNIVERSITY OF MICHIGAN
 * 
 * ALL RIGHTS RESERVED
 *
 * PERMISSION IS GRANTED TO USE, COPY, CREATE DERIVATIVE WORKS AND 
 * REDISTRIBUTE THIS SOFTWARE AND SUCH DERIVATIVE WORKS FOR ANY 
 * PURPOSE, SO LONG AS NO FEE IS CHARGED, AND SO LONG AS THE COPYRIGHT 
 * NOTICE ABOVE, THIS GRANT OF PERMISSION, AND THE DISCLAIMER BELOW 
 * APPEAR IN ALL COPIES MADE; AND SO LONG AS THE NAME OF THE UNIVERSITY 
 * OF MICHIGAN IS NOT USED IN ANY ADVERTISING OR PUBLICITY PERTAINING 
 * TO THE USE OR DISTRIBUTION OF THIS SOFTWARE WITHOUT SPECIFIC, 
 * WRITTEN PRIOR AUTHORIZATION.
 *
 * THIS SOFTWARE IS PROVIDED AS IS, WITHOUT REPRESENTATION FROM 
 * THE UNIVERSITY OF MICHIGAN AS TO ITS FITNESS FOR ANY PURPOSE, AND 
 * WITHOUT WARRANTY BY THE UNIVERSITY OF MICHIGAN OF ANY KIND, EITHER 
 * EXPRESS OR IMPLIED, INCLUDING WITHOUT LIMITATION THE IMPLIED 
 * WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE. 
 * THE REGENTS OF THE UNIVERSITY OF MICHIGAN SHALL NOT BE LIABLE FOR 
 * ANY DAMAGES, INCLUDING SPECIAL, INDIRECT, INCIDENTAL, OR 
 * CONSEQUENTIAL DAMAGES, WITH RESPECT TO ANY CLAIM ARISING OUT OF OR 
 * IN CONNECTION WITH THE USE OF THE SOFTWARE, EVEN IF IT HAS BEEN OR 
 * IS HEREAFTER ADVISED OF THE POSSIBILITY OF SUCH DAMAGES.
 *
 ***************************************************************************/

/***************************************************************************
 *
 * CREDITS: 
 * Code Authors (2002): Kanda Runapongsa and Jignesh M. Patel
 *                      EECS Department, University of Michigan
 *
 **************************************************************************/

/**************************************************************************
 * Filename:   DataGen.cpp
 **************************************************************************/

#include "DataGen.h"
#include "DocGen.h"
#include "ErrorHandlers.h"
#include <math.h>
#include <time.h>

//=============================================================================
// Constructor.
// Initialize common default settings of documents in the data set.
//=============================================================================
DataGen::DataGen() {
   // Enum are defined for scale factors to be easily indexed in an array
   // Valid scale factors are 0.1, 1,10,100.  
   scaleFactor = one;
   supportSchemaFlag = true;
   prtElemContFlag = true;
   supportDTDFlag = false;
   verbose = false;
   rootLevel = 1;
   strcpy(filenamePrefix,"doc");
}



//=============================================================================
// Destructor.
//=============================================================================
DataGen::~DataGen() {
   
}


//=============================================================================
// Set scale factor as requested.  Currently, only 3 options of scale factors
// are available: 1,10, and 100
//=============================================================================
void DataGen::setScaleFactor(double _scaleFactor) {
   if (_scaleFactor == 0.1) {
      scaleFactor = oneTenth;
   } else if (_scaleFactor == 1) {
      scaleFactor = one;
   } else if (_scaleFactor == 10) {
      scaleFactor = ten;
   } else if (_scaleFactor == 100) {
      scaleFactor = oneHundred;
   }
}

//=============================================================================
// Print options of the program generator
// Available options allow the users to
//  - Set the scale factor. Valid values are {1,10,100}
//  - Set the root level of the data set. Valid values are {1-16} 
//  - Set the prefix of the document name
//  - Set the schema support flag
//  - Print available options  
//=============================================================================

void DataGen::printUsage() {
   cout << "usage: mbgen (options)" << endl;
   cout << "options:" << endl;
   cout.setf(ios::left);
   
   // scale factor
   cout << setw(5)  << ""  << setw(20) << "-sf=scale_factor" 
      << setw(50) << "Valid scale factors are {0.1, 1, 10, 100} [default=1]" 
      << endl;
   
   // document name
   cout << setw(5)  << ""  << setw(20) << "-n=doc_name"		  
      << setw(50) << "Set document file name [default='doc'] " << endl;
   
   // schema support
   cout << setw(5)  << ""  << setw(20) << "-s | -S"		  
      << setw(50) << "Turn off schema support [default=on]" << endl;
   
   // print element content
   cout << setw(5)  << ""  << setw(20) << "-c | -C"		  
      << setw(50) << "Turn off element content printed out [default=on]" << endl;
   
   // DTD support
   cout << setw(5)  << ""  << setw(20) << "-d | -D"		  
      << setw(50) << "Turn on DTD support [default=off]" << endl;
   
   // Toggle Verbose
   cout << setw(5)  << ""  << setw(20) << "-v | -V"		  
      << setw(50) << "Turn on verbose message printing [default=off]" << endl;
   
   // print program usage
   cout << setw(5)  << ""  << setw(20) << "-h | -H" 
      << setw(50) << "Print available options" << endl;
   
   exit(0);
}

// Change schema support flag
//=============================================================================
void DataGen::toggleSchemaSupport() {
   supportSchemaFlag = !supportSchemaFlag;
}

// Change print element content flag
//=============================================================================
void DataGen::togglePrtElemCont() {
   prtElemContFlag = !prtElemContFlag;
}


// Change DTD support flag
//=============================================================================
void DataGen::toggleDTDSupport() {
   supportDTDFlag = !supportDTDFlag;
}

// Toggle Verbose flag
//=============================================================================
void DataGen::toggleVerbose() {
   verbose = !verbose;
}

// Change print element content flag
//=============================================================================
// Write XML documents
//=============================================================================
void DataGen::writeDocs() {
   DocGen docGen(this);
   docGen.writeDocs();
}

int main(int argC, char *argV[]) 
{
   cout << "   Running The Michigan Benchmark Data Generator" << endl;
   cout << "    (c) 2002 The Regents of the University OF Michigan" << endl;
   cout << "    All Rights Reserved" << endl;
   
   DataGen dg;
   
   int argInd;
   for (argInd = 1; argInd < argC; argInd++) {
      
      // Break out on first non-dash parameter
      if (argV[argInd][0] != '-')
         break;
      
      // scale factor
      if (!strncmp(argV[argInd],"-sf=",4)  ||
         !strncmp(argV[argInd],"-SF=",4)) {
         const char* const param = &argV[argInd][4];
         double sf = atof(param);
         if (sf == 0.1 || sf == 1 || sf == 10 || sf == 100) {
            dg.setScaleFactor(sf);
         } else {
            cerr << sf << " is NOT a valid scale factor. ";
            cerr << "Valid scale factors are {0.1, 1, 10, 100}" << endl;
         }	 
         
         // schema support
      } else if (!strcmp(argV[argInd],"-s") ||
         !strcmp(argV[argInd],"-S")) {
         dg.toggleSchemaSupport();
         // print element content
      } else if (!strcmp(argV[argInd],"-c") ||
         !strcmp(argV[argInd],"-C")) {
         dg.togglePrtElemCont();
         // DTD support
      } else if (!strcmp(argV[argInd],"-d") ||
         !strcmp(argV[argInd],"-D")) {
         dg.toggleDTDSupport();
         // prefix document name
      } else if (!strncmp(argV[argInd],"-n=",3) ||
         !strncmp(argV[argInd],"-N=",3)) {
         dg.setDocName(&argV[argInd][3]);
         
         // turn on verbose mode
      } else if (!strcmp(argV[argInd],"-v") ||
         !strcmp(argV[argInd],"-V")) {
         dg.toggleVerbose();
         
         // print help info
      } else if (!strcmp(argV[argInd],"-h") ||
         !strcmp(argV[argInd],"-H")) {
         dg.printUsage();
         
      } else {
         cerr << "Unknown option," << argV[argInd] << endl;
         dg.printUsage();
      }
   }
   
   // start timing
   clock_t start, end;
   start = clock();
   
   // write documents
   dg.writeDocs();
   
   // end timing
   end = clock();
   
   cout << endl << "Document generation time is "
      << (end - start)/CLOCKS_PER_SEC  << " seconds " << endl; 
   
   return 0;
}

