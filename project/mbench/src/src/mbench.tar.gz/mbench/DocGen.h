/****************************************************************************
 * The Michigan Benchmark Data Generator V 1.0
 *
 * COPYRIGHT 2002 THE REGENTS OF THE UNIVERSITY OF MICHIGAN
 * 
 * ALL RIGHTS RESERVED
 *
 * PERMISSION IS GRANTED TO USE, COPY, CREATE DERIVATIVE WORKS AND 
 * REDISTRIBUTE THIS SOFTWARE AND SUCH DERIVATIVE WORKS FOR ANY 
 * PURPOSE, SO LONG AS NO FEE IS CHARGED, AND SO LONG AS THE COPYRIGHT 
 * NOTICE ABOVE, THIS GRANT OF PERMISSION, AND THE DISCLAIMER BELOW 
 * APPEAR IN ALL COPIES MADE; AND SO LONG AS THE NAME OF THE UNIVERSITY 
 * OF MICHIGAN IS NOT USED IN ANY ADVERTISING OR PUBLICITY PERTAINING 
 * TO THE USE OR DISTRIBUTION OF THIS SOFTWARE WITHOUT SPECIFIC, 
 * WRITTEN PRIOR AUTHORIZATION.
 *
 * THIS SOFTWARE IS PROVIDED AS IS, WITHOUT REPRESENTATION FROM 
 * THE UNIVERSITY OF MICHIGAN AS TO ITS FITNESS FOR ANY PURPOSE, AND 
 * WITHOUT WARRANTY BY THE UNIVERSITY OF MICHIGAN OF ANY KIND, EITHER 
 * EXPRESS OR IMPLIED, INCLUDING WITHOUT LIMITATION THE IMPLIED 
 * WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE. 
 * THE REGENTS OF THE UNIVERSITY OF MICHIGAN SHALL NOT BE LIABLE FOR 
 * ANY DAMAGES, INCLUDING SPECIAL, INDIRECT, INCIDENTAL, OR 
 * CONSEQUENTIAL DAMAGES, WITH RESPECT TO ANY CLAIM ARISING OUT OF OR 
 * IN CONNECTION WITH THE USE OF THE SOFTWARE, EVEN IF IT HAS BEEN OR 
 * IS HEREAFTER ADVISED OF THE POSSIBILITY OF SUCH DAMAGES.
 *
 ***************************************************************************/

/***************************************************************************
 *
 * CREDITS: 
 * Code Authors (2002): Kanda Runapongsa and Jignesh M. Patel
 *                      EECS Department, University of Michigan
 *
 **************************************************************************/

/****************************************************************************
* Description:  
//@{
// This class generate documents that have specified attributes and elements
// according to the Michigan Benchmark (http://www.eecs.umich.edu/db/mbench
//@}
* 
* Filename:   DocGen.h
****************************************************************************/
#ifndef _DOC_GEN_H
#define _DOC_GEN_H

#include <string.h>
#include <stdlib.h>
#include <iostream.h>
#include <fstream.h>
#include <assert.h>
#include <iomanip.h>

#ifdef _MSC_VER
#include <strstrea.h>
#else
#include <strstream.h>
#endif

#include "StrGen.h"
#include "DataGen.h"

#ifdef use_namespace
namespace MBENCH {
#endif 
   
   
   class DataGen;
   
   class DocGen {
      friend class DataGen;
   public:
      //@{
      // Default constructor
      //@}
      DocGen();
      
      //@{
      // Constructor associated with the data generator
      //@}
      DocGen(DataGen *dg);
      
      //@{
      // Destructor
      //@}
      ~DocGen();
      
      //@{
      // Write document
      //@}
      void writeDoc(unsigned docIndex);
      
      //@{
      // Write a set of documents in this data set
      //@}
      void writeDocs();
      
      //@{
      // Write statistics of the generated documents
      //@}
      void writeStats();
      
      //@{
      // Set configuration of the document 
      //@}
      void setConfig();	
      
      //@{
      // Compute number of nodes at each level.  
      //@}
      void computeNumNodes();
      
      //@{
      // Print out the configuration
      //@}
      void prtConfig();
      
   private:
      
      // counter to keep track of number of nodes in each level
      // want to start to access at index = 1, so we increment
      // the number of allocated slots
      myBigUnsigned nodes[MAX_NUM_LEVELS+1];	
      
      // Cumulative number of nodes at each level
      myBigUnsigned numTotalNodes[MAX_NUM_LEVELS+1];
      
      // number of nodes at each level
      myBigUnsigned numNodes[MAX_NUM_LEVELS+1];
      
      // number of cumulative nodes per document
      myBigUnsigned docNumCumNodes[MAX_NUM_LEVELS+1];
      
      // current level that data is written in the document
      unsigned level;
      
      // file(s) output stream
      ofstream fpOut;
      
      // string generator
      StrGen gs;
      
      
      // total number of nodes in the document
      myBigUnsigned totalNumNodes;
      
      // random number generator for aUnique2
      Random aUnique2RNG;
      
      myBigUnsigned numNodesCount; // total number of nodes
      myBigUnsigned numENestNodes; // total number of 'eNest' nodes (counted)
      myBigUnsigned numEOccNodes;
      myBigUnsigned numDatasetNodes; // total number of 'eNest' nodes (estimated)
      
      // the data generator that it associates with
      DataGen *dg;
      
      // configuration parameters of the data set, get from
      // the data generator class 
      unsigned rootLevel;
      ScaleFactor scaleFactor;
      
      // depends on the number of documents
      unsigned filenameWidth;
      
      
      // the size of this array depends on the scale factor
      // of the document
      
      // these two variables to check or ensure that aUnique1 
      // and aUnique2 are really unique.
      bool *aUnique1Used;
      bool *aUnique2Used;
      
      // number of generated documents
      unsigned numDocs;
      
      myBigUnsigned curNumNodes;
      unsigned curNumDocs;
      
      
      //-------------- private methods ---------------------------------
      //@{
      // Initialize fanout and node counters in each level
      //@}
      void initDoc();
      
      //@{
      // Write begin element tag
      // @param elemName Element tag name
      // @param level Level of the element 
      //@}
      void writeBeginTag(const char *elemName, unsigned level);
      
      
      //@{
      // Write end element tag
      // @param elemName Element tag name
      // @param level Level of the element 
      //@}
      void writeEndTag(const char *elemName, unsigned level);
      
      
      //@{
      // Write element content
      // @param fpOut File output stream of the document
      // @param elemContent Element content 
      //@}
      void writeContent(const char *elemContent);
      
      //@{
      // Write element
      // recursive function
      //@}
      void writeElem();
      
      //@{
      // Write long string
      // @param aUnique1 The value of aUnique1 attribute
      // @param aSixtyFour The value of aSixtyFour attribute
      //@}
      void writeStrAttrs(myBigUnsigned aUnique1, myBigUnsigned aSixtyFour);
      
      //@{
      // Write optional eOccasional element
      // @param aUnique1 The value of aUnique1 attribute
      // @param aSixtyFour The value of aSixtyFour attribute
      // @param str The string content of eOccasional element
      //@}
      void write_eOccasional(myBigUnsigned aUnique1, myBigUnsigned aSixtyFour, char *str);
      
      //@{
      // Write document declaration
      //@}
      void writeDocDeclaration();
      
      //@{
      // Write DTD declaration
      //@}
      void writeDTDDeclaration();
      
      //@{
      // Compute aUnique1 attribute
      //@}
      myBigUnsigned computeAUnique1();
      
      //@{
      // Compute aUnique2 attribute
      //@}
      myBigUnsigned computeAUnique2();
      
      //@{
      // Compute other attributes based on aUnique2
      // @param baseNum The base number
      // @param modNum The mod number
      //@}
      myBigUnsigned computeAttr(myBigUnsigned baseNum, unsigned modNum);
      
      //@{
      // Compute aRef attribute
      // @param parentID The parentID of the element of the element that
      //                 aRef attribute is belong to
      //@}
      myBigUnsigned computeARef(myBigUnsigned parentID);
      
};

#ifdef use_namespace
}
#endif 

#endif








