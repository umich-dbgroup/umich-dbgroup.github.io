/****************************************************************************
 * The Michigan Benchmark Data Generator V 1.0
 *
 * COPYRIGHT 2002 THE REGENTS OF THE UNIVERSITY OF MICHIGAN
 * 
 * ALL RIGHTS RESERVED
 *
 * PERMISSION IS GRANTED TO USE, COPY, CREATE DERIVATIVE WORKS AND 
 * REDISTRIBUTE THIS SOFTWARE AND SUCH DERIVATIVE WORKS FOR ANY 
 * PURPOSE, SO LONG AS NO FEE IS CHARGED, AND SO LONG AS THE COPYRIGHT 
 * NOTICE ABOVE, THIS GRANT OF PERMISSION, AND THE DISCLAIMER BELOW 
 * APPEAR IN ALL COPIES MADE; AND SO LONG AS THE NAME OF THE UNIVERSITY 
 * OF MICHIGAN IS NOT USED IN ANY ADVERTISING OR PUBLICITY PERTAINING 
 * TO THE USE OR DISTRIBUTION OF THIS SOFTWARE WITHOUT SPECIFIC, 
 * WRITTEN PRIOR AUTHORIZATION.
 *
 * THIS SOFTWARE IS PROVIDED AS IS, WITHOUT REPRESENTATION FROM 
 * THE UNIVERSITY OF MICHIGAN AS TO ITS FITNESS FOR ANY PURPOSE, AND 
 * WITHOUT WARRANTY BY THE UNIVERSITY OF MICHIGAN OF ANY KIND, EITHER 
 * EXPRESS OR IMPLIED, INCLUDING WITHOUT LIMITATION THE IMPLIED 
 * WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE. 
 * THE REGENTS OF THE UNIVERSITY OF MICHIGAN SHALL NOT BE LIABLE FOR 
 * ANY DAMAGES, INCLUDING SPECIAL, INDIRECT, INCIDENTAL, OR 
 * CONSEQUENTIAL DAMAGES, WITH RESPECT TO ANY CLAIM ARISING OUT OF OR 
 * IN CONNECTION WITH THE USE OF THE SOFTWARE, EVEN IF IT HAS BEEN OR 
 * IS HEREAFTER ADVISED OF THE POSSIBILITY OF SUCH DAMAGES.
 *
 ***************************************************************************/

/***************************************************************************
 *
 * CREDITS: 
 * Code Authors (2002): Kanda Runapongsa and Jignesh M. Patel
 *                      EECS Department, University of Michigan
 *
 **************************************************************************/

/****************************************************************************
* Description: 
//@{
//This class generates random numbers
//@}
*
* Filename: Random.h
****************************************************************************/

#ifndef _RANDOM_H_
#define _RANDOM_H

#ifdef use_namespace
namespace MIBENCH {
#endif
   
   const int a = 16807; /* multiplier */
   const unsigned long m = 2147483647; /* 2^31 - 1 */
   const unsigned long q = 127773; /* m div a */
   const int r = 2836; /* m mod a */
   
   
   class Random {
   public:
      Random();           // default seed is 1
      Random(unsigned long _seed);
      void initSeed(unsigned long s);  // resets the seed
      unsigned long getNext();      // returns the next random number in the sequence
      double getNextUniform();
      void setMethod(int _method);
      
      //@{
      // Generate bucket number
      // @param lowerBnd The lower bound of the generated numbers
      // @param upperBnd The upper bound of the generated numbers
      // @returns The integer number between the lower and upper bounds
      //@}
      unsigned long genNum(int lowerBnd, int upperBnd);
      
      unsigned long getSeed() {
         return seed;
      }
      
      
   private:
      unsigned long seed;				// current seed value
   };
   
   
#ifdef use_namespace
}
#endif


#endif
